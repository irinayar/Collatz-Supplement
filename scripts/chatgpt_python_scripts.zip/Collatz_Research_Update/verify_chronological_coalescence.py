#!/usr/bin/env python3
"""Exact coalescence-mask and retained-credit controls (standard library only).

The general proof is in Chronological_Multiplicity_Research.md.  This program
replays fixed genuine first returns; it performs no search and proves no census
claim.  The imported bound on the number of core-bearing profiles is identified
explicitly in the output.  All decisions use integers or Fraction.
"""
import argparse
from collections import defaultdict
from fractions import Fraction as F
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Run without -O: exact certificate checks use assertions.")

SEEDS = [{'name': 'asynchronous',
  'n': '1049728399491224013995397943',
  'cut': '1438089652701205314467159035',
  'sources': [{'u': '1244122547545154386957508671',
               'word': [1,
                        1,
                        1,
                        1,
                        1,
                        4,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        4,
                        3,
                        3,
                        2,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        3,
                        1,
                        1,
                        5,
                        1,
                        2,
                        1,
                        2,
                        2,
                        2],
               'expected_core': [26, 28, 30, 32, 33, 35]},
              {'u': '1399637865988298685327197255',
               'word': [1,
                        1,
                        2,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        4,
                        3,
                        3,
                        2,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        3,
                        1,
                        1,
                        5,
                        1,
                        2,
                        1,
                        2,
                        2,
                        2],
               'expected_core': [23, 24, 26, 28, 30, 31, 33]}]},
 {'name': 'synchronized',
  'n': '26645514422485486121914504906678081',
  'cut': '46829908344240507685503717632961643',
  'sources': [{'u': '35527352563313981495886006542237435',
               'word': [1,
                        2,
                        1,
                        2,
                        1,
                        1,
                        3,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        2,
                        1,
                        1,
                        1,
                        2,
                        1,
                        2,
                        4,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        1,
                        1,
                        1,
                        2,
                        2,
                        1,
                        3,
                        2,
                        2,
                        2,
                        1,
                        3,
                        2,
                        1,
                        3,
                        1,
                        1,
                        1,
                        3,
                        1,
                        4],
               'expected_core': [23, 24, 26, 28, 30, 31, 33, 35, 36, 38, 40]},
              {'u': '35527352563313981495886006542237439',
               'word': [1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        4,
                        3,
                        3,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        2,
                        1,
                        1,
                        1,
                        2,
                        1,
                        2,
                        4,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        1,
                        1,
                        1,
                        2,
                        2,
                        1,
                        3,
                        2,
                        2,
                        2,
                        1,
                        3,
                        2,
                        1,
                        3,
                        1,
                        1,
                        1,
                        3,
                        1,
                        4],
               'expected_core': [40]}]},
 {'name': 'nonzero_terminal_phase_disagreement',
  'n': '35763428846815493451095888695',
  'cut': '48994594215654671853419387899',
  'sources': [{'u': '42386286040670214460558090303',
               'word': [1,
                        1,
                        1,
                        1,
                        1,
                        4,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        4,
                        4,
                        1,
                        1,
                        2,
                        1,
                        2,
                        1,
                        3,
                        1,
                        1,
                        1,
                        1,
                        2,
                        3,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        1,
                        3,
                        2,
                        1,
                        2,
                        1,
                        1,
                        2,
                        2,
                        1,
                        1,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        4,
                        1,
                        4,
                        1,
                        2,
                        1,
                        2,
                        2,
                        2,
                        1,
                        3,
                        3,
                        1,
                        1,
                        1,
                        4]},
              {'u': '47684571795753991268127851591',
               'word': [1,
                        1,
                        2,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        1,
                        4,
                        4,
                        1,
                        1,
                        2,
                        1,
                        2,
                        1,
                        3,
                        1,
                        1,
                        1,
                        1,
                        2,
                        3,
                        1,
                        1,
                        1,
                        1,
                        1,
                        1,
                        2,
                        1,
                        1,
                        2,
                        1,
                        1,
                        3,
                        2,
                        1,
                        2,
                        1,
                        1,
                        2,
                        2,
                        1,
                        1,
                        2,
                        1,
                        2,
                        1,
                        1,
                        1,
                        1,
                        4,
                        1,
                        4,
                        1,
                        2,
                        1,
                        2,
                        2,
                        2,
                        1,
                        3,
                        3,
                        1,
                        1,
                        1,
                        4]}],
  'expected_nonzero_defect': True}]


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def ceil_div(a, b):
    return -((-a) // b)


def source_count(n):
    """Reconstruct the prescribed P_* definition, not the number of controls."""
    H = (4*n-2)//3
    k = (H-n).bit_length()
    row = {2: 1}
    short = 0
    for depth in range(3, k+1):
        short += sum(count for odds, count in row.items()
                     if (3*n-k)*2**depth < 3*H*3**odds
                     and n*3**odds < H*2**depth)
        nxt = defaultdict(int)
        for odds, count in row.items():
            for bit in (0, 1):
                r = odds+bit
                if 2**depth*n**r < (3*n+1)**r:
                    nxt[r] += count
        row = dict(nxt)
    bandwidth = short + sum(row.values())
    row = {2: 1}
    for depth in range(3, H.bit_length()+1):
        nxt = defaultdict(int)
        for odds, count in row.items():
            for bit in (0, 1):
                r = odds+bit
                if 3**r > 2**(depth-1):
                    nxt[r] += count
        row = dict(nxt)
    return min(bandwidth, 2*sum(row.values()))


def replay(n, source):
    u = int(source['u'])
    word = source['word']
    H = (4*n-2)//3
    assert n >= 2**71 and n % 2
    assert n <= u <= H and u % 2
    odd, times, numerators, phases, shortcut = [u], [0], [0], [F(0)], [u]
    E = U = 0
    for g, e in enumerate(word, 1):
        a = odd[-1]
        assert e == v2(3*a+1)
        x = (3*a+1)//2
        shortcut.append(x)
        for _ in range(e-1):
            assert x % 2 == 0
            x //= 2
            shortcut.append(x)
        assert x % 2
        U = 3*U+2**E
        E += e
        odd.append(x)
        times.append(E)
        numerators.append(U)
        phases.append(F(U, 3**g))
        assert 2**E*x == 3**g*u+U
    w = odd[-1]
    assert n <= w <= H
    assert all(x > H for x in odd[1:-1])
    assert len(set(shortcut[:-1])) == len(shortcut)-1
    assert times[-1] == len(shortcut)-1
    g = len(word)
    modulus = 2**(E+1)
    residue = ((2**E-U)*pow(3**g, -1, modulus)) % modulus
    low = max(n, ceil_div(2**E*n-U, 3**g))
    high = min(H, (2**E*H-U)//3**g)
    for i in range(1, g):
        low = max(low, (2**times[i]*H-numerators[i])//3**i+1)
    assert low+(residue-low) % modulus == u <= high
    # Independent shortcut inverse-parity calculation at every observed prefix.
    inv_U = inv_r = 0
    for depth, x in enumerate(shortcut[:-1], 1):
        if x % 2:
            inv_U = 3*inv_U+2**(depth-1)
            inv_r += 1
        a_depth = (-inv_U*pow(3**inv_r, -1, 2**depth)) % 2**depth
        assert a_depth == u % 2**depth
        assert 2**depth*shortcut[depth] == 3**inv_r*u+inv_U
    kappa = F(n-1, n+1)
    runs, start = [], 0
    for end, e in enumerate(word, 1):
        if e < 2:
            continue
        a, b = odd[start], odd[end]
        s = end-start
        beta = 1-F(2, 3)**s
        delta = beta/a
        flux = F(1, a)-F(1, b)
        t = kappa*delta+flux
        credit = max(F(0), -flux-delta/15)
        mark = t+credit
        assert flux <= delta
        assert (kappa-F(1, 15))*delta <= mark <= (kappa+1)*delta
        assert phases[end]-phases[start] == (u+phases[start])*delta
        assert s == v2(a+1)
        runs.append(dict(a=a, b=b, i=start, end=end, time=times[start],
                         s=s, e=e, q=phases[start], qend=phases[end],
                         delta=delta, flux=flux, t=t, credit=credit, mark=mark))
        start = end
    assert start == g
    assert 1+phases[-1]/u < F(47, 32)
    rho_minus_one = (phases[-1]+5*(F(2**E, 3**g)-1))/(u+5)
    assert rho_minus_one > 0
    return dict(n=n, H=H, u=u, w=w, runs=runs, phases=phases, times=times,
                shortcut=shortcut, E=E, Q=phases[-1], g=g, kappa=kappa,
                residue=residue, modulus=modulus, rho_minus_one=rho_minus_one)


def core(p, Pstar):
    n, H = p['n'], p['H']
    L, m = n.bit_length()-1, n.bit_length()
    B = 5+F(n, 100000*Pstar)
    result = set()
    for k, r in enumerate(p['runs']):
        ell = r['a'].bit_length()-1
        height = ell-L
        assert height >= 0
        J = 2**ell//(2000*Pstar*(height+1)*(height+2))
        canonical = r['time']+ell
        if (r['i'] > 0 and H < r['a'] < 2**(64*m)
            and canonical < p['E'] and 64*p['shortcut'][canonical] > r['a']
            and r['q'] > B and p['Q']-r['q'] > B
            and k > J and len(p['runs'])-k > J):
            result.add(k)
            assert p['u'] < 2**canonical
    return result


def score(runs, selected):
    return sum((r['t'] if i in selected else -r['credit']
                for i, r in enumerate(runs)), F(0))


def terminal_alignment(profiles, cores, B):
    """Align only the terminal-phase predicate over whole original profiles."""
    assert all(cores)  # Core-empty profiles remain unchanged outside this group.
    w = profiles[0]['w']
    assert all(p['w'] == w for p in profiles)
    taus = [F(2**p['E'], 3**p['g']) for p in profiles]
    tau_min = min(taus)
    n = profiles[0]['n']
    assert tau_min*w > n+2*B
    clock_by_state = {}
    shared_clock_checks = 0
    defect = F(0)
    aligned_cores = []
    loss_rows = []
    for p, C, tau in zip(profiles, cores, taus):
        assert tau*w == p['u']+p['Q']
        Cp = set()
        loss_mass = F(0)
        for i, r in enumerate(p['runs']):
            Ds = F(2**(p['E']-r['time']), 3**(p['g']-r['i']))
            Ds_next = F(2**(p['E']-p['times'][r['end']]),
                        3**(p['g']-r['end']))
            R = w-F(r['a'], 1)/Ds
            Rnext = w-F(r['b'], 1)/Ds_next
            assert R == (p['Q']-r['q'])/tau
            assert Rnext == (p['Q']-r['qend'])/tau
            assert 0 <= Rnext < R < w
            assert r['delta'] == (R-Rnext)/(w-R)
            if r['a'] in clock_by_state:
                assert R == clock_by_state[r['a']]
                shared_clock_checks += 1
            clock_by_state[r['a']] = R
            if i in C:
                if tau_min*R > B:
                    Cp.add(i)
                else:
                    assert tau > tau_min and tau*R > B
                    defect += r['mark']
                    loss_mass += r['delta']
                    loss_rows.append(dict(source=p['u'], state=r['a'],
                                          terminal_clock=R, mark=r['mark']))
        assert loss_mass <= B/(tau_min*w-B) < B/(n+B)
        aligned_cores.append(Cp)
    M = sum(tau > tau_min for tau in taus)
    bound = (profiles[0]['kappa']+1)*B*M/(n+B)
    assert 0 <= defect <= bound
    original = sum((score(p['runs'], C) for p, C in zip(profiles, cores)), F(0))
    aligned = sum((score(p['runs'], C) for p, C in zip(profiles, aligned_cores)), F(0))
    assert original == aligned+defect
    return dict(terminal_multipliers=taus, minimum_terminal_multiplier=tau_min,
                original_core_sizes=list(map(len, cores)),
                aligned_core_sizes=list(map(len, aligned_cores)),
                original_signed_score=original, aligned_signed_score=aligned,
                defect=defect, defect_bound=bound, affected_scale_count=M,
                shared_terminal_clock_checks=shared_clock_checks,
                loss_rows=loss_rows)


def one_group(seed):
    n, y = int(seed['n']), int(seed['cut'])
    Pstar = source_count(n)
    B = 5+F(n, 100000*Pstar)
    profiles = [replay(n, source) for source in seed['sources']]
    cores = [core(p, Pstar) for p in profiles]
    terminal = terminal_alignment(profiles, cores, B)
    cuts = [next(i for i, r in enumerate(p['runs']) if r['a'] == y)
            for p in profiles]
    for p, C, cut, source in zip(profiles, cores, cuts, seed['sources']):
        assert cut in C
        if 'expected_core' in source:
            assert [p['runs'][i]['i'] for i in sorted(C)] == source['expected_core']
    lambdas = [F(2**p['runs'][cut]['time'], 3**p['runs'][cut]['i'])
               for p, cut in zip(profiles, cuts)]
    lam_min, Rmin = min(lambdas), min(cuts)
    assert Rmin >= 1
    tails = [p['runs'][cut:] for p, cut in zip(profiles, cuts)]
    common_states = [(r['a'], r['b']) for r in tails[0]]
    assert all([(r['a'], r['b']) for r in tail] == common_states for tail in tails)
    p0, cut0, lam0 = profiles[0], cuts[0], lambdas[0]
    qpre0 = p0['runs'][cut0]['q']
    Qs = (p0['Q']-qpre0)/lam0
    q = [(r['q']-qpre0)/lam0 for r in tails[0]]
    qe = [(r['qend']-qpre0)/lam0 for r in tails[0]]
    assert q[0] == 0 and qe[-1] == Qs
    assert lam_min*y > n+B
    assert lam_min*(y+Qs)-B > n+B
    T = len(tails[0])
    common = set()
    phase_ok, reset_ok = [], []
    for j, r in enumerate(tails[0]):
        ell = r['a'].bit_length()-1
        height = ell-(n.bit_length()-1)
        J = 2**ell//(2000*Pstar*(height+1)*(height+2))
        canonical = r['time']+ell
        shared_predicates = (p0['H'] < r['a'] < 2**(64*n.bit_length())
                             and canonical < p0['E']
                             and 64*p0['shortcut'][canonical] > r['a']
                             and T-j > J)
        phase_ok.append(lam_min*(Qs-q[j]) > B)
        reset_ok.append(Rmin+j > J)
        if shared_predicates and phase_ok[j] and reset_ok[j]:
            common.add(j)
        assert qe[j]-q[j] == (y+q[j])*r['delta']
    actual_tail_sets = [{i-cut for i in C if i >= cut} for C, cut in zip(cores, cuts)]
    assert common == set.intersection(*actual_tail_sets)
    defect = phase_defect = reset_defect = F(0)
    max_phase_mass = F(0)
    loss_rows = []
    for p, tail, Ctail, cut, lam in zip(profiles, tails, actual_tail_sets, cuts, lambdas):
        qpre = p['runs'][cut]['q']
        assert lam*y == p['u']+qpre
        phase_mass = reset_mass = F(0)
        reset_shell_counts = defaultdict(int)
        for j, r in enumerate(tail):
            assert r['q'] == qpre+lam*q[j]
            assert p['Q']-r['q'] == lam*(Qs-q[j])
            assert r['q'] > B
            if j not in Ctail-common:
                continue
            defect += r['mark']
            if not phase_ok[j]:
                assert lam > lam_min
                phase_mass += r['delta']
                phase_defect += r['mark']
                cause = 'terminal_phase'
            else:
                assert not reset_ok[j] and cut > Rmin
                reset_mass += r['delta']
                reset_defect += r['mark']
                cause = 'incoming_reset'
                ell = r['a'].bit_length()-1
                height = ell-(n.bit_length()-1)
                J = 2**ell//(2000*Pstar*(height+1)*(height+2))
                assert j <= J-Rmin
                reset_shell_counts[height] += 1
                assert reset_shell_counts[height] <= max(0, J-Rmin+1) <= J
            loss_rows.append(dict(source=p['u'], state=r['a'], suffix_run=j,
                                  odd_index=r['i'], cause=cause, mark=r['mark']))
        assert phase_mass <= B/(lam_min*(y+Qs)-B) < B/(n+B)
        assert reset_mass <= F(1, 2000*Pstar)
        max_phase_mass = max(max_phase_mass, phase_mass)
    Mphase = sum(lam > lam_min for lam in lambdas)
    Mreset = sum(cut > Rmin for cut in cuts)
    kappa = profiles[0]['kappa']
    defect_bound = (kappa+1)*(B*F(Mphase, 1)/(n+B)+F(Mreset, 2000*Pstar))
    assert phase_defect+reset_defect == defect <= defect_bound
    tail_total = sum((score(tail, C) for tail, C in zip(tails, actual_tail_sets)), F(0))
    common_score = score(tails[0], common)
    assert tail_total == len(profiles)*common_score+defect
    prefixes = [score(p['runs'][:cut], {i for i in C if i < cut})
                for p, C, cut in zip(profiles, cores, cuts)]
    total = sum((score(p['runs'], C) for p, C in zip(profiles, cores)), F(0))
    assert total == sum(prefixes, F(0))+len(profiles)*common_score+defect
    assert Mphase <= len(profiles)-1 and Mreset <= len(profiles)-1
    # Fixed odd depth forces the same incoming exponent, hence the same scale.
    incoming_g = [p['runs'][cut]['i'] for p, cut in zip(profiles, cuts)]
    if len(set(incoming_g)) == 1:
        assert len(set(lambdas)) == 1 and Mphase == 0
    if seed.get('expected_nonzero_defect'):
        assert defect > 0
    return dict(name=seed['name'], n=n, H=profiles[0]['H'], Pstar=Pstar, B=B,
                source_count=len(profiles), cut=y, incoming_odd_depths=incoming_g,
                incoming_reset_counts=cuts, incoming_scales=lambdas,
                original_core_sizes=list(map(len, cores)),
                tail_core_sizes=list(map(len, actual_tail_sets)),
                common_core_size=len(common), Mphase=Mphase, Mreset=Mreset,
                total_signed_score=total, prefix_scores=prefixes,
                common_suffix_score=common_score, defect=defect,
                scaled_defect=(profiles[0]['H']+1)*defect,
                defect_bound=defect_bound, phase_defect=phase_defect,
                reset_defect=reset_defect, loss_rows=loss_rows,
                global_terminal_alignment=terminal,
                profiles=[dict(u=p['u'], w=p['w'], odd_steps=p['g'],
                               shortcut_steps=p['E'], least_residue=p['residue'],
                               full_cylinder_modulus=p['modulus'],
                               positive_whole_charge=p['rho_minus_one'])
                          for p in profiles])


def encode(value):
    if isinstance(value, F):
        return {'numerator': str(value.numerator), 'denominator': str(value.denominator)}
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return [encode(x) for x in value]
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    return value


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path,
                    default=Path(__file__).with_name('chronological_coalescence_certificate.json'))
    args = ap.parse_args()
    rows = [one_group(seed) for seed in SEEDS]
    # This count theorem is imported; the rational comparison is verified here.
    c = F(620751769493359576, 1180591620717411303425)
    n0 = 2**71+1
    universal_defect_majorant = (F(40, 3)+F(10, 3*n0))*c+F(51, 50000)
    assert universal_defect_majorant < F(8031, 1000000)
    global_terminal_majorant = (F(40, 3)+F(10, 3*n0))*c+F(1, 50000)
    assert global_terminal_majorant < F(7031, 1000000)
    # Explicit integer checks of the floor/ordinal counting used in the proof.
    ordinal_cases = 0
    for Rmin in range(1, 33):
        for J in range(65):
            observed = sum(j+Rmin <= J for j in range(J+2))
            assert observed == max(0, J-Rmin+1) <= J
            ordinal_cases += 1
    cert = dict(status='PASS', arithmetic='integer and Fraction only',
                scope='Fixed actual-core controls, not an exhaustive census or a proof of the full aggregate target.',
                imported_count_theorem='D_n/(H+1) <= 620751769493359576/1180591620717411303425',
                uniform_defect_majorant=universal_defect_majorant,
                convenient_uniform_defect_bound=F(8031, 1000000),
                global_terminal_majorant=global_terminal_majorant,
                convenient_global_terminal_bound=F(7031, 1000000),
                ordinal_endpoint_cases=ordinal_cases, groups=rows)
    args.output.write_text(json.dumps(encode(cert), indent=2, sort_keys=True)+'\n')
    print('PASS: three actual coalescence controls; exact mask identity and signed-credit preservation.')
    print('Uniform mask-disagreement bound:', float(universal_defect_majorant), '< 0.008031')
    print('Global terminal-phase disagreement bound:', float(global_terminal_majorant), '< 0.007031')
    for row in rows:
        print(row['name'], 'tail cores', row['tail_core_sizes'],
              'common', row['common_core_size'], 'scaled defect', float(row['scaled_defect']))


if __name__ == '__main__':
    main()
