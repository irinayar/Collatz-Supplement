#!/usr/bin/env python3
"""Exact certificate for a joint actual-core height and run-length tail.

Standard library only. Source injection/count theorems are declared imports;
the count recurrence and every new constant are independently reconstructed.
The analytic proof of Holder's inequality is in the accompanying note.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from math import comb
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Assertions must remain enabled.")


def arithmetic():
    r = F(1923, 2000)
    cbrt_upper = F(125993, 100000)
    assert cbrt_upper**3 > 2
    lower_denominator = 15 - 12*cbrt_upper**2 + 6*cbrt_upper
    assert lower_denominator > 3/r**4
    assert 3**883 < 2**1400
    assert 2**50 * 1923**883 < 2000**883
    assert 3000**22 < 2**256
    assert 1/(1-r) == F(2000, 77)
    assert 1 + 1/(1-r) == F(2077, 77)
    assert 2 + 1/(1-r) == F(2154, 77)
    assert sum(F(7, 10)**j / factorial(j) for j in range(5)) > 2
    # Finite controls of the stated all-M elementary boundary induction.
    for M in range(1, 513):
        assert 2*(29*M+1) <= 2**(28*M)
        S = 883*M//50
        assert 3**S < 2**(28*M)
        assert r**(S+1) < F(1, 2**M)
    return {
        "holder_exponents": ["4", "4/3"],
        "geometric_ratio_upper": str(r),
        "cube_root_two_upper": str(cbrt_upper),
        "denominator_lower": str(lower_denominator),
        "ratio_fourth_power_margin": str(lower_denominator-3/r**4),
        "integer_certificates": ["3^883 < 2^1400", "2^50*1923^883 < 2000^883",
                                 "3000^22 < 2^256"],
        "core_interior_high_coefficient": str(F(2077, 77)),
        "all_input_high_coefficient": str(F(2154, 77)),
        "finite_boundary_controls": 512,
    }


def factorial(k):
    out = 1
    for j in range(2, k+1):
        out *= j
    return out


def counts():
    state = {2: 1}
    rows = []
    for width in range(3, 256):
        nxt = defaultdict(int)
        for ones, count in state.items():
            for bit in (0, 1):
                if 3**(ones+bit) > 2**width:
                    nxt[ones+bit] += count
        state = dict(nxt)
        if width < 70:
            continue
        n0 = max(2**71+1, 3*2**(width-1)+3)
        m0 = n0.bit_length()
        P = sum(state.values())
        rows.append({"width": width, "minimum_n": str(n0), "m": m0,
                     "long_count": str(P),
                     "ratio_power": str(F(P, 2**m0)),
                     "ratio_minus_one": str(F(P, 2**m0-1)),
                     "ratio_m_minus_one": str(F(P*m0, 2**m0-1))})
    assert len(rows) == 186
    for key in ("ratio_power", "ratio_minus_one", "ratio_m_minus_one"):
        assert max(rows, key=lambda row: F(row[key]))["width"] == 71
    peak = next(row for row in rows if row["width"] == 71)
    P0, m0 = int(peak["long_count"]), peak["m"]
    assert P0 == 2483007077973438304 and m0 == 72
    c0 = 2*F(P0, 2**m0-1)*(1+F(98*m0, 5)) + F(4154, 77)*F(P0, 2**m0)
    c1 = F(196*P0, 5*(2**m0-1))
    assert c0 < F(53, 35) and c1 < F(1, 48)
    # Two coefficient checks certify every K>=0, not just a sampled K grid.
    analytic_high = F(4154, 77)*F(96, 258*3000)
    analytic_c0 = F(192*98, 3000*5) + analytic_high
    analytic_c1 = F(192*98, 3000*5*258)
    assert analytic_c0 < c0 and analytic_c1 < c1
    exact16 = c0 + 16*c1
    assert exact16 < F(37, 20)
    fixed_long = 2*F(P0, 2**m0-1)*(1+F(98*(m0+16), 5))
    fixed_high = F(4154, 77)*F(P0, 2**m0)
    assert fixed_long < F(91, 50) and fixed_high < F(3, 100)
    assert exact16 == fixed_long + fixed_high
    for row in rows:
        P, m = int(row["long_count"]), row["m"]
        intercept = 2*F(P, 2**m-1)*(1+F(98*m, 5)) + F(4154, 77)*F(P, 2**m)
        slope = F(196*P, 5*(2**m-1))
        assert intercept <= c0 and slope <= c1
        row["joint_intercept"] = str(intercept)
        row["joint_slope"] = str(slope)
    return rows, {
        "peak_width": 71, "peak_m": 72, "peak_long_count": str(P0),
        "uniform_intercept": str(c0), "uniform_slope": str(c1),
        "rounded_intercept": "53/35", "rounded_slope": "1/48",
        "analytic_intercept_envelope": str(analytic_c0),
        "analytic_slope_envelope": str(analytic_c1),
        "K16_scaled_exact_envelope": str(exact16),
        "K16_scaled_margin": str(F(37, 20)-exact16),
        "K16_signed_budget": str(F(37, 1310720)),
        "K16_weight_budget": str(F(37, 2621440)),
        "K16_height_only_scaled_envelope": str(fixed_high),
        "K16_low_long_scaled_envelope": str(fixed_long),
    }


def trajectory_controls():
    r = F(1923, 2000)
    inputs = (3, 7, 27, 97, 703, 2**71+1, 2**80-1)
    controls = []
    pair_count = 0
    nonempty_high = 0
    for start in inputs:
        path = [start]
        seen = set()
        while path[-1] != 1:
            x = path[-1]
            assert x not in seen
            seen.add(x)
            path.append((3*x+1)//2 if x & 1 else x//2)
            assert len(path) < 10000
        N = len(path)-1
        prefix = [0]
        for x in path[:-1]:
            prefix.append(prefix[-1]+(x & 1))
        cells = defaultdict(int)
        endpoint_rows = defaultdict(set)
        interior = []
        for t, a in enumerate(path[:-1]):
            if not a & 1:
                continue
            j = a.bit_length()-1
            if t+j >= N:
                continue
            odd_count = prefix[t+j]-prefix[t]
            y = path[t+j]
            assert 3**odd_count < y < 2*3**odd_count and y % 3
            assert y not in endpoint_rows[odd_count]
            endpoint_rows[odd_count].add(y)
            cells[j, odd_count] += 1
            interior.append(a)
        for (j, s), count in cells.items():
            assert count <= comb(j-1, s-1)
        for s, endpoints in endpoint_rows.items():
            assert len(endpoints) <= 2*3**(s-1)
        for L in (1, 2, 4, 8, 16, 29, 32, 58, 64, 80, 87, 116):
            whole = sum((F(1, a) for a in path[:-1] if a & 1 and a >= 2**L), F(0))
            local = sum((F(1, a) for a in interior if a >= 2**L), F(0))
            for S in (0, 1, 2, 4, 8, 16, 32, 64):
                bound = F(3**S-1, 2**L)+F(2000, 77)*r**(S+1)
                assert local < bound
                assert whole < bound + F(L+1, 2**(L-1))
                pair_count += 1
            if local:
                nonempty_high += 1
        controls.append({"start": str(start), "shortcut_steps": N,
                         "distinct_inputs": len(seen), "interior_odd_starts": len(interior),
                         "canonical_cells": len(cells), "endpoint_rows": len(endpoint_rows),
                         "scope": "actual pre-hit path controls; actual research core not asserted"})
    return {"paths": controls, "height_split_checks": pair_count,
            "nonempty_high_interior_cases": nonempty_high}


def progression_controls():
    data = []
    for S in (1, 2, 5, 12, 72, 88):
        for d in (0, 1, 3, 6, 10):
            M, N = 2**S, 2**d
            actual = sum((F(1, M*j-1) for j in range(1, N+1)), F(0))
            bound = (1+F(7*d, 10))/(M-1)
            assert actual <= bound
            data.append({"S": S, "count_exponent": d, "terms": N,
                         "upper_bound": str(bound)})
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="short_run_height_certificate.json")
    args = parser.parse_args()
    ar = arithmetic()
    rows, envelope = counts()
    certificate = {"status": "PASS", "scope": "uniform joint tail, not a bound on the remaining aggregate",
                   "arithmetic": ar, "envelope": envelope, "finite_rows": rows,
                   "trajectory_controls": trajectory_controls(),
                   "progression_controls": progression_controls(),
                   "imports": ["actual source injection and finite necessary-code count",
                               "analytic core-bearing count <=96*n^(21/22)/(m_s+1)"]}
    out = Path(args.output)
    out.write_text(json.dumps(certificate, indent=2)+"\n")
    print(json.dumps({"status": "PASS", "finite_rows": len(rows), "envelope": envelope,
                      "trajectory_checks": certificate["trajectory_controls"]["height_split_checks"],
                      "certificate": str(out)}, indent=2))


if __name__ == "__main__":
    main()
