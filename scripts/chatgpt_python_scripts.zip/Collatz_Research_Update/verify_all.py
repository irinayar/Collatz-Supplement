#!/usr/bin/env python3
"""Reproduce the complete, bounded Collatz research packet offline."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

if not __debug__:
    raise SystemExit("Run without -O: exact verifiers rely on assertions.")

CHECKS = [
    ("verify_multiple_groups_retained_credits.py",
     "multiple_groups_retained_credits_certificate.json"),
    ("verify_short_run_height.py", "short_run_height_certificate.json"),
    ("verify_forced_prefix_tail.py", "forced_prefix_tail_certificate.json"),
    ("verify_chronological_coalescence.py", "chronological_coalescence_certificate.json"),
    ("verify_combined_research.py", "combined_research_certificate.json"),
]


def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()
                if key != "runtime_seconds"}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    return value


def verify_manifest(root):
    manifest = json.loads((root/"MANIFEST.json").read_text())
    files = manifest["files"]
    for row in files:
        path = root/row["path"]
        assert path.is_file(), "Missing file: "+row["path"]
        data = path.read_bytes()
        assert len(data) == row["bytes"], "Size mismatch: "+row["path"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"], "Hash mismatch: "+row["path"]
    return len(files)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", type=Path,
                    help="Optional location for the reproduction report; default prints it only.")
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    start = time.monotonic()
    count = verify_manifest(root)
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    records = []
    with tempfile.TemporaryDirectory(prefix="collatz_research_replay_") as dirname:
        temporary = Path(dirname)
        for script, certificate in CHECKS:
            destination = temporary/certificate
            command = [sys.executable, str(root/"verifiers"/script),
                       "--output", str(destination)]
            if script == "verify_combined_research.py":
                command += ["--certificates-dir", str(temporary)]
            run = subprocess.run(command, cwd=root, env=env,
                                 text=True, capture_output=True, timeout=120)
            if run.returncode:
                raise RuntimeError(script+"\n"+run.stdout[-5000:]+"\n"+run.stderr[-5000:])
            expected = json.loads((root/"certificates"/certificate).read_text())
            observed = json.loads(destination.read_text())
            assert normalized(expected) == normalized(observed), "Certificate mismatch: "+certificate
            assert observed["status"] == "PASS"
            records.append({"verifier": script,
                            "certificate": certificate,
                            "exit_code": run.returncode,
                            "mathematical_certificate_equal": True})
            print("PASS:", script, flush=True)
    result = {
        "status": "PASS",
        "manifest_files_verified": count,
        "checks": records,
        "excluded_comparison_fields": ["runtime_seconds"],
        "runtime_seconds": round(time.monotonic()-start, 6),
        "unrestricted_central_bound": "UNPROVED",
    }
    if args.report:
        args.report.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
