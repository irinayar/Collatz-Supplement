#!/usr/bin/env python3
"""Exact checks for the forced-prefix canonical long-run tail.

Standalone standard library. Global source injection/count facts are imports.
All new arithmetic and the finite count recurrence are rebuilt here.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from math import comb
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Assertions must remain enabled.")


def v2(x):
    assert x > 0
    return (x & -x).bit_length()-1


def constants():
    assert F(276, 125)**7 < 256
    assert F(151, 125)**35 > 3**6
    assert 3*40**8*125**7 < 39**8*151**7
    assert 3000**22 < 2**256
    # Independent exact checks of the imported new high-tail constants.
    z = F(125993, 100000)
    assert z**3 > 2
    assert 15-12*z*z+6*z > 3*F(2000, 1923)**4
    assert 3**883 < 2**1400
    assert 2**50*1923**883 < 2000**883
    assert 82+F(2077, 77) == F(8391, 77)
    return {"holder_exponents": ["8", "8/7"],
            "odd_count_tail_start": "6S", "low_rows_coefficient": "10S",
            "high_rows_coefficient": 80, "corner_coefficient": 2,
            "interior_long_reciprocal_bound": "(10S+82)*2^(-S)",
            "certificates": ["(276/125)^7 < 256", "(151/125)^35 > 3^6",
                             "3*40^8*125^7 < 39^8*151^7"],
            "high_tail_interior_coefficient": "2077/77"}


def source_rows():
    state = {2: 1}
    rows = []
    for k in range(3, 256):
        nxt = defaultdict(int)
        for odd, multiplicity in state.items():
            for bit in (0, 1):
                if 3**(odd+bit) > 2**k:
                    nxt[odd+bit] += multiplicity
        state = dict(nxt)
        if k < 70:
            continue
        n = max(2**71+1, 3*2**(k-1)+3)
        m = n.bit_length()
        P = sum(state.values())
        rows.append({"width": k, "minimum_n": str(n), "m": m,
                     "count": str(P), "ratio": str(F(P, 2**m)),
                     "m_ratio": str(F(m*P, 2**m)),
                     "joint_intercept": str(2*F(P, 2**m)*(10*m+F(8391, 77))),
                     "joint_slope": str(20*F(P, 2**m)),
                     "long_only_intercept": str(2*F(P, 2**m)*(10*m+82))})
    assert len(rows) == 186
    for key in ("ratio", "m_ratio", "joint_intercept", "joint_slope", "long_only_intercept"):
        assert max(rows, key=lambda r: F(r[key]))["width"] == 71
    peak = next(r for r in rows if r["width"] == 71)
    assert peak["m"] == 72 and int(peak["count"]) == 2483007077973438304
    a, b = F(peak["joint_intercept"]), F(peak["joint_slope"])
    assert a == F(4952900774816329386957, 5681597174702541897728)
    assert b == F(387969855933349735, 36893488147419103232)
    analytic_a = F(192, 3000)*(10+(F(8391, 77)-10)/258)
    analytic_b = F(1920, 3000*258)
    assert analytic_a < a and analytic_b < b
    assert a+16*b < F(26, 25)
    assert a+15*b < F(33, 32)
    assert F(26, 25)-a-16*b == F(64046363510991003, 142039929367563547443200)
    for row in rows:
        assert F(row["joint_intercept"]) <= a
        assert F(row["joint_slope"]) <= b
    return rows, {"peak_width": 71, "peak_m": 72,
                  "joint_intercept": str(a), "joint_slope": str(b),
                  "long_only_intercept": peak["long_only_intercept"],
                  "analytic_intercept": str(analytic_a),
                  "analytic_slope": str(analytic_b),
                  "K16_scaled_exact": str(a+16*b),
                  "K16_scaled_margin": str(F(26, 25)-a-16*b),
                  "K16_signed_budget": str(F(13, 819200)),
                  "K16_weight_budget": str(F(13, 1638400)),
                  "K15_scaled_exact": str(a+15*b),
                  "K15_scaled_margin": str(F(33, 32)-a-15*b),
                  "K15_signed_budget": str(F(33, 1048576)),
                  "K15_weight_budget": str(F(33, 2097152))}


def series_controls():
    # Exact positive-series partial sums and the closed full sum at z=1/2.
    records = []
    for S in (1, 2, 3, 5, 8, 16):
        for r in (S, S+1, 2*S, 6*S):
            partial = sum((F(comb(j-S, r-S), 2**j) for j in range(r, r+80)), F(0))
            whole = F(1, 2**(S-1))
            assert partial <= whole
            # A second rational argument checks the general generating function
            # using derivatives of the geometric series in a finite recurrence.
            z = F(2, 5)
            exact = z**r/(1-z)**(r-S+1)
            partial_z = sum((comb(j-S, r-S)*z**j for j in range(r, r+80)), F(0))
            assert partial_z <= exact
            assert exact == z**(S-1)*(z/(1-z))**(r-S+1)
            records.append({"S": S, "odd_count": r, "partial_terms": 80,
                            "half_weight_full_series": str(whole)})
    return records


def actual_controls():
    seeds = (3, 7, 27, 97, 2**20-1, 2**40-1, 2**80-1)
    checks, corners, prefix_cells = [], 0, 0
    for seed in seeds:
        path = [seed]
        seen = set()
        while path[-1] != 1:
            a = path[-1]
            assert a not in seen
            seen.add(a)
            path.append((3*a+1)//2 if a & 1 else a//2)
            assert len(path) < 10000
        N = len(path)-1
        odd_prefix = [0]
        for a in path[:-1]:
            odd_prefix.append(odd_prefix[-1]+(a & 1))
        for S in (1, 2, 3, 4, 8, 16, 20, 32, 40, 64, 72, 80):
            mass = F(0)
            cells = defaultdict(int)
            endpoints = defaultdict(set)
            local_corners = []
            for t, a in enumerate(path[:-1]):
                if not a & 1 or v2(a+1) < S:
                    continue
                j = a.bit_length()-1
                if t+j >= N:
                    continue
                mass += F(1, a)
                if j < S:
                    assert j == S-1 and a == 2**S-1
                    local_corners.append(a)
                    continue
                assert all(path[t+i] & 1 for i in range(S))
                r = odd_prefix[t+j]-odd_prefix[t]
                assert r >= S
                y = path[t+j]
                assert 3**r < y < 2*3**r and y % 3
                assert y not in endpoints[r]
                endpoints[r].add(y)
                cells[j, r] += 1
            assert len(local_corners) <= 1
            corners += len(local_corners)
            for (j, r), count in cells.items():
                assert count <= comb(j-S, r-S)
                prefix_cells += 1
            for r, values in endpoints.items():
                assert len(values) <= 2*3**(r-1)
            bound = F(10*S+82, 2**S)
            assert mass < bound
            checks.append({"seed": str(seed), "S": S,
                           "actual_mass_positive": mass > 0,
                           "actual_numerator_bits": mass.numerator.bit_length(),
                           "actual_denominator_bits": mass.denominator.bit_length(),
                           "bound": str(bound),
                           "prefix_cells": len(cells), "corner_count": len(local_corners),
                           "scope": "actual canonical pre-hit controls, research core not asserted"})
    return {"checks": checks, "path_threshold_pairs": len(checks),
            "nonempty_corner_cases": corners, "restricted_cell_checks": prefix_cells}


def unfinished_controls():
    records = []
    nonempty_boundary_cases = 0
    for seed in (3, 27, 2**20-1, 2**80-1):
        path = [seed]
        seen = set()
        while path[-1] != 1:
            a = path[-1]
            assert a not in seen
            seen.add(a)
            path.append((3*a+1)//2 if a & 1 else a//2)
            assert len(path) < 10000
        cuts = sorted({min(c, len(path)-1) for c in (1, 2, 3, 7, 15, 31, 63, 127)})
        for N in cuts:
            assert len(set(path[:N])) == N
            for S in (1, 2, 3, 4, 8, 16, 20, 40, 80):
                d = (S-1).bit_length()
                assert 2**d >= S and d <= S-1
                assert 2*(S+d+1) <= 4*2**d
                interior, boundary, corner = F(0), F(0), F(0)
                corner_count = 0
                shell_counts = defaultdict(int)
                for t, a in enumerate(path[:N]):
                    if a <= 1 or not a & 1 or v2(a+1) < S:
                        continue
                    j = a.bit_length()-1
                    if j < S:
                        assert j == S-1 and a == 2**S-1
                        corner_count += 1
                        corner += F(1, a)
                    elif t+j < N:
                        interior += F(1, a)
                    else:
                        boundary += F(1, a)
                        shell_counts[j] += 1
                assert corner_count <= 1 and corner < F(2, 2**S)
                for j, count in shell_counts.items():
                    assert count <= min(j, 2**(j-S))
                assert interior < F(10*S+80, 2**S)
                assert boundary <= F(d+4, 2**S)
                mass = interior+boundary+corner
                bound = F(10*S+d+86, 2**S)
                assert mass < bound
                nonempty_boundary_cases += bool(boundary)
                records.append({"seed": str(seed), "prefix_steps": N, "S": S,
                                "d": d, "boundary_nonempty": boundary > 0,
                                "corner_count": corner_count, "bound": str(bound),
                                "scope": "actual distinct-input finite prefix, completion not used"})
    return {"checks": records, "prefix_threshold_pairs": len(records),
            "nonempty_boundary_cases": nonempty_boundary_cases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="forced_prefix_tail_certificate.json")
    args = parser.parse_args()
    exact = constants()
    rows, envelope = source_rows()
    certificate = {"status": "PASS", "scope": "forced-prefix tail, not a remaining-aggregate theorem",
                   "constants": exact, "envelope": envelope, "finite_rows": rows,
                   "series_controls": series_controls(), "actual_controls": actual_controls(),
                   "unfinished_controls": unfinished_controls(),
                   "imports": ["actual source injection/count theorem",
                               "analytic count <=96*n^(21/22)/(m_s+1)"]}
    out = Path(args.output)
    out.write_text(json.dumps(certificate, indent=2)+"\n")
    print(json.dumps({"status": "PASS", "envelope": envelope,
                      "actual_controls": certificate["actual_controls"]["path_threshold_pairs"],
                      "corner_cases": certificate["actual_controls"]["nonempty_corner_cases"],
                      "unfinished_pairs": certificate["unfinished_controls"]["prefix_threshold_pairs"],
                      "nonempty_boundary_cases": certificate["unfinished_controls"]["nonempty_boundary_cases"],
                      "certificate": str(out)}, indent=2))


if __name__ == "__main__":
    main()
