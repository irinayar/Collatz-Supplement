#!/usr/bin/env python3
"""Exact finite certificate for arbitrarily many separated long K180 groups.

This script uses only the Python standard library. It computes the complete
6**8 source-residue tree twice, by forward numerator composition and by backward
2-adic inversion. It certifies a finite threshold range, not an unrestricted
Collatz theorem or the existence of profiles whose actual core has this grammar.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import hashlib
import json
import time

if not __debug__:
    raise SystemExit("Run without -O: exact certificate checks use assertions.")


LABELS = tuple(sorted({"".join(p) for p in permutations("2233")}))
DEPTH = 8
K4 = F(1814421282246, 7551629537)
EXPECTED_MIN = int("21346342495854702470833795683269374440106412456159662460927218553844507600380763285371")
EXPECTED_CODE = (2, 4, 4, 1, 4, 4, 2, 0)


def macro(label: str) -> tuple[int, ...]:
    return sum(((1, 2) * int(c) + (2,) for c in label), ())


def affine(word):
    A, B, E = 1, 0, 0
    for e in word:
        B = 3 * B + (1 << E)
        A *= 3
        E += e
    return A, B, 1 << E


def exact_trace(a, word):
    states = [a]
    for e in word:
        z = 3 * a + 1
        assert z % (1 << e) == 0 and (z >> e) % 2 == 1
        a = z >> e
        states.append(a)
    return states


def metadata():
    out = []
    for label in LABELS + ("23", "32"):
        word = macro(label)
        A, B, D = affine(word)
        j = E = 0
        C = F(0)
        for c in label:
            for _ in range(int(c)):
                C += F(2, 3) * F(1 << E, 3**j)
                j += 2
                E += 3
            j += 1
            E += 2
        K = C * A / (A - D)
        mult = F(1)
        minimum = F(1)
        for e in word:
            mult *= F(3, 1 << e)
            minimum = min(minimum, mult)
        assert A > D
        assert K <= K4
        assert minimum >= F(243, 256)**2 > F(1, 2)
        out.append({"label": label, "A": str(A), "B": str(B), "D": str(D),
                    "K": str(K), "minimum_partial_multiplier": str(minimum)})
    return out


def residue_histograms():
    maps = [affine(macro(label)) for label in LABELS]
    A, _, D = maps[0]
    assert all(a == A and d == D for a, _, d in maps)
    offsets = [b for _, b, _ in maps]
    Dpow = [D**j for j in range(DEPTH + 1)]
    modulus = 2 * Dpow[DEPTH]
    assert modulus == 1 << 305
    inverse = pow(A**DEPTH, -1, modulus)
    forwards = Counter()
    residues_mod3 = Counter()
    minimum, mincode, leaves = modulus, (), 0

    def forward(U, code):
        nonlocal minimum, mincode, leaves
        j = len(code)
        if j < DEPTH:
            for c, B in enumerate(offsets):
                forward(A * U + Dpow[j] * B, code + (c,))
            return
        a = ((Dpow[DEPTH] - U) * inverse) % modulus
        assert a & 1
        key = (a.bit_length() - 1, a % 3)
        forwards[key] += 1
        residues_mod3[a % 3] += 1
        leaves += 1
        if a < minimum:
            minimum, mincode = a, code

    forward(0, ())
    assert leaves == 6**8
    assert minimum == EXPECTED_MIN and mincode == EXPECTED_CODE
    assert minimum > (1 << 283) > (1 << 273)

    # A separate inverse-composition tree, prepending macro words. This has a
    # different recursion and never uses the composed forward numerator U.
    inverses = [pow(A, -1, 2 * Dpow[j]) for j in range(DEPTH + 1)]
    backwards = Counter()
    backwards_min = modulus
    backwards_leaves = 0

    def backward(j, a):
        nonlocal backwards_min, backwards_leaves
        if j == DEPTH:
            backwards[(a.bit_length() - 1, a % 3)] += 1
            backwards_min = min(backwards_min, a)
            backwards_leaves += 1
            return
        M = 2 * Dpow[j + 1]
        for B in offsets:
            b = ((D * a - B) * inverses[j + 1]) % M
            backward(j + 1, b)

    backward(0, 1)
    assert backwards == forwards
    assert backwards_min == minimum and backwards_leaves == leaves
    word = sum((macro(LABELS[c]) for c in mincode), ())
    trace = exact_trace(minimum, word)
    assert trace[-1] > trace[0]
    assert min(F(x, trace[0]) for x in trace) >= F(243, 256)**2

    # Upper bound sum_{a in residues, 3 does not divide a} 1/a by dyadic bins.
    # Every exponent is <=304, so one common power-of-two denominator suffices.
    numerator = sum(count * (1 << (304 - bit))
                    for (bit, rem), count in forwards.items() if rem != 0)
    principal = F(numerator, 1 << 304)
    all_principal = sum((F(count, 1 << bit)
                         for (bit, rem), count in forwards.items()), F(0))
    return {"modulus": str(modulus), "leaves": leaves,
            "independent_backward_leaves": backwards_leaves,
            "histograms_equal": True, "minimum": str(minimum),
            "minimum_code": list(mincode),
            "residue_mod3_counts": {str(r): residues_mod3[r] for r in range(3)},
            "histogram": [{"floor_log2": bit, "mod3": rem, "count": count}
                          for (bit, rem), count in sorted(forwards.items())],
            "principal_dyadic_bound": str(principal),
            "principal_dyadic_bound_without_mod3": str(all_principal),
            "minimal_residue_actual_valuation_replay": True}, principal


def small_harmonic_controls():
    # Verify the sharper discrete intermediate bound used to prove the tail
    # lemma. The proof works for all N; this is only an implementation control.
    controls = []
    sums = [F(0), F(0), F(0)]
    harmonic = F(0)
    for N in range(1, 301):
        harmonic += F(1, N)
        for omitted in range(3):
            if N % 3 != omitted:
                sums[omitted] += F(1, N)
            assert sums[omitted] <= F(2, 3) * harmonic + F(5, 6)
        if N in (1, 2, 3, 4, 10, 30, 100, 300):
            controls.append({"N": N, "largest_sum": str(max(sums)),
                             "upper_bound": str(F(2, 3)*harmonic + F(5, 6))})
    return controls


def numeric_bound(principal):
    M = 1 << 305
    J = 6**8
    max_m = 272
    tail_log2 = 64 * max_m + 1 - 305
    assert tail_log2 == 17104
    # Proof uses H_N <= 1 + ln N, ln2 < 7/10. Lemma constants below are exact.
    tail_per_class = F(3, 2) + F(7, 15) * tail_log2
    # 3/2 follows from 2/3 H_N +5/6; a coarse bound 2 would also work.
    harmonic_tail = F(J, M) * tail_per_class
    assert 5000**22 < 1 << 272
    population = F(96 * (1 << 272), 258 * 5000)
    # Small thresholds use only the elementary count of odd band sources.
    assert F((1 << 256) + 4, 6) < population
    principal_charge = K4 * population * principal
    tail_charge = K4 * population * harmonic_tail
    charge = principal_charge + tail_charge
    target = F(116073, 3904000)
    convenient = F(7, 250)
    assert charge < convenient < target
    b0, a0, T = F(3000, 2797), F(8850, 170617), F(327, 3904)
    central = b0 * convenient + a0
    assert central < T
    residual = F(488, 375) * central + F(59, 1000)
    assert residual < F(21, 125)
    return {"max_threshold_exclusive": str(1 << 272), "max_bitlength": max_m,
            "tail_log2": tail_log2, "population_bound": str(population),
            "AP_tail_per_class_times_modulus": str(tail_per_class),
            "principal_charge_upper": str(principal_charge),
            "principal_charge_decimal": float(principal_charge),
            "AP_tail_charge_upper": str(tail_charge),
            "AP_tail_charge_decimal": float(tail_charge),
            "total_charge_upper": str(charge), "total_charge_decimal": float(charge),
            "convenient_bound": str(convenient),
            "target_Y_star": str(target), "target_margin": str(target-charge),
            "central_from_convenient_bound": str(central),
            "central_target": str(T), "central_margin": str(T-central),
            "residual_from_convenient_bound": str(residual),
            "residual_target": "21/125",
            "residual_margin": str(F(21, 125)-residual)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("multiple_groups_retained_credits_certificate.json"))
    args = parser.parse_args()
    start = time.monotonic()
    table = metadata()
    tree, principal = residue_histograms()
    result = {"status": "PASS", "theorem_domain": "2^71 <= odd n < 2^272",
              "group_condition": "Disjoint actual B4*B2^{0,1} groups, each with >=8 B4 words, start >H and containing an original core occurrence",
              "warning": "This is not an unrestricted core-covering or aggregate theorem.",
              "macro_table": table, "residue_tree": tree,
              "harmonic_lemma_controls": small_harmonic_controls(),
              "numerical_inequalities": numeric_bound(principal),
              "runtime_seconds": round(time.monotonic()-start, 6),
              "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "leaves_each_direction": tree["leaves"],
                      "principal_charge": result["numerical_inequalities"]["principal_charge_decimal"],
                      "tail_charge": result["numerical_inequalities"]["AP_tail_charge_decimal"],
                      "total_charge": result["numerical_inequalities"]["total_charge_decimal"],
                      "certified_simplification": "< 7/250", "output": str(args.output),
                      "runtime_seconds": result["runtime_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
