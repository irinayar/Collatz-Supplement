#!/usr/bin/env python3
"""Exact symbolic join of one parity cylinder and one target word; no external deps."""
from math import gcd

def word_affine(w):
    U=A=0
    for i,c in enumerate(w):
        if c=='1': U=3*U+2**i; A+=1
        elif c!='0': raise ValueError(w)
    return len(w),A,U

def residue(w):
    # Unique starting residue modulo 2^j; construct bits iteratively.
    r=0
    for i,bit in enumerate(w):
        z=r
        for c in w[:i]: z=(3*z+1)//2 if z%2 else z//2
        if (z&1)!=int(bit): r+=1<<i
    return r

def join(w,v):
    j,a,U=word_affine(w); ell,b,V=word_affine(v)
    n0=residue(w); y0=(3**a*n0+U)//2**j
    assert (3**a*n0+U)%2**j==0
    Q=3**b; C=2**ell*3**a; B=2**ell*y0-V
    g=gcd(C,Q)
    if B%g: return {'w':w,'v':v,'possible':False,'reason':'incompatible modulo gcd','gcd':g}
    modulus=Q//g
    t0= ((-B//g)*pow(C//g,-1,modulus))%modulus if modulus>1 else 0
    # n=n0+2^j(t0+modulus*z); m=(B+C*t)/Q
    m0=(B+C*t0)//Q
    stepm=C*modulus//Q
    stepn=2**j*modulus
    return dict(w=w,v=v,possible=True,n0=n0,t0=t0,modulus=modulus,
                n_base=n0+2**j*t0,m_base=m0,n_step=stepn,m_step=stepm,
                slope_num=C,slope_den=2**j*Q,
                eventual_affordable=(stepm<stepn),
                eventually_unaffordable=(stepm>stepn))

def simulate(n,w):
    x=n
    for c in w:
        assert x%2==int(c),(n,w,x,c)
        x=(3*x+1)//2 if x%2 else x//2
    return x

def test():
    words=['1','0','11','110','111','1110','101','1010','1100','1011','11100','11010']
    checked=0
    for w in words:
        for v in words:
            z=join(w,v)
            if not z['possible']: continue
            for k in range(20):
                n=z['n_base']+z['n_step']*k
                m=z['m_base']+z['m_step']*k
                if n>0 and m>0:
                    assert simulate(n,w)==simulate(m,v)
                    checked+=1
    example=join('11','111')
    assert example['n_base']==11 and example['m_base']==7
    assert example['n_step']==12 and example['m_step']==8
    print('independent trajectory checks:',checked)
    print('example:',example)
    print('incompatible example:',join('11','10'))
if __name__=='__main__':test()
