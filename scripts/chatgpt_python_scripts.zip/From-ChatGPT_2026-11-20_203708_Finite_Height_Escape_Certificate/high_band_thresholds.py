from fractions import Fraction
P=Fraction(1197634424202209201486330161312590462976,1194027704281321183001939677510824745641)
Q=Fraction(2305843009213693952,1840049047529878113)
H=1000001
# for u>H, u is odd so min 1000003, C(u)<1+1/u <= 1000004/1000003
R=Fraction(1000004,1000003)
for j in [0,1,5,10,20,40,50]:
 base=Q*P**j
 if base>=Fraction(3,2):print(j,'already above');continue
 lo=0;hi=300000
 while lo+1<hi:
  mid=(lo+hi)//2
  if base*R**mid<Fraction(3,2):lo=mid
  else:hi=mid
 print(j,'max_safe_A',lo,'first_not_excluded',hi,'verify',base*R**lo<Fraction(3,2)<=base*R**hi)
