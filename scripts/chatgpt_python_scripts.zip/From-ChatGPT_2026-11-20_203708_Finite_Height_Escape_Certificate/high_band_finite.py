from functools import lru_cache
from fractions import Fraction
H=1000001

def nxt(u):
 s=(u+1 & -(u+1)).bit_length()-1
 w=3**s*((u+1)//2**s)-1
 e=(w & -w).bit_length()-1
 return w>>e,s,e

@lru_cache(None)
def solve(u):
 v,s,e=nxt(u)
 if v<=1023 or v>H: return (1,v, u, (1,s,e))
 if v==u: raise Exception(('cycle',u))
 n,term,maxu,_=solve(v)
 return n+1,term,max(maxu,u),(1,s,e)

mx=(0,None); exitlow=exithi=0
for u in range(1025,H+1,2):
 n,t,ma,_=solve(u)
 if n>mx[0]: mx=(n,u,t,ma)
 if t<=1023: exitlow+=1
 else: exithi+=1
print('H',H,'starts',(H-1025)//2+1,'max',mx,'exit low',exitlow,'exit high',exithi,'cache',solve.cache_info())
