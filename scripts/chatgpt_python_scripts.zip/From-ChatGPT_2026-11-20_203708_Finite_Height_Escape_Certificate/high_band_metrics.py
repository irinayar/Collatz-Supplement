from functools import lru_cache
from fractions import Fraction
H=1000001

def nxt(u):
 s=((u+1)&-(u+1)).bit_length()-1
 w=3**s*((u+1)//2**s)-1
 e=(w&-w).bit_length()-1
 return w>>e,s
@lru_cache(None)
def metrics(u):
 v,s=nxt(u)
 c=Fraction(3**s*(u+1)-2**s,3**s*u)
 j=(u//1024).bit_length()-1
 wt=Fraction(1,2**j)
 if v<=1023 or v>H: return (1,c,wt,u,v)
 n,p,w,_,end=metrics(v)
 return (n+1,c*p,wt+w,u,end)
maxp=(Fraction(0),None); maxw=(Fraction(0),None); maxn=(0,None)
for u in range(1025,H+1,2):
 n,p,w,_,end=metrics(u)
 if p>maxp[0]:maxp=(p,u,end,n)
 if w>maxw[0]:maxw=(w,u,end,n)
 if n>maxn[0]:maxn=(n,u,end)
print('maxp',maxp, 'float',float(maxp[0]))
print('maxw',maxw,'float',float(maxw[0]))
print('maxn',maxn)
