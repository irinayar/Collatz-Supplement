from fractions import Fraction
from random import Random
from high_band_metrics import nxt,metrics,H

def direct(u):
    n=0;prod=Fraction(1);occ=Fraction(0); seen=set()
    while 1025<=u<=H:
        assert u not in seen, ('cycle',u)
        seen.add(u)
        original=u
        s=0
        while u%2:
            u=(3*u+1)//2
            s+=1
        assert s>=1
        while u%2==0:
            u//=2
        n+=1
        prod*=Fraction(3**s*(original+1)-2**s,3**s*original)
        j=(original//1024).bit_length()-1
        occ+=Fraction(1,2**j)
    return n,prod,occ,u

starts=[1025,1000001,53001,251265,926649]
starts += [2*i+1025 for i in Random(20261120).sample(range((H-1025)//2+1),1000)]
for u in starts:
    n,p,w,t=direct(u)
    n2,p2,w2,_,t2=metrics(u)
    assert (n,p,w,t)==(n2,p2,w2,t2),(u,(n,p,w,t),(n2,p2,w2,t2))
print('PASS: 1009 independent direct odd-step replays; exact products, occupancy, terminal, lengths')
