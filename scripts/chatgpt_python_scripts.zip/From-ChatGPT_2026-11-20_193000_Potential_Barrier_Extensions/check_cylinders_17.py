import json
rows=[]
for L in range(18):
    tests=0; outside=0; cycle=0
    for a in range(1,(1<<(L+1))+1):
        n=a;k=r=0
        for _ in range(L):
            if n&1: n=(3*n+1)//2;r+=1
            else: n//=2;k+=1
        if n%2==0 or k==0:continue
        tests+=1
        D=3**(r+1)*(a+1)-2**(r+1)*((1<<k)*n+1)
        U=(2**(r+1)*((1<<k)-1))//3
        if 0<D<=U:
            if n>=3:outside+=1;print('OUTSIDE',L,a,n,k,r)
            else:cycle+=1
    rows.append(dict(length=L,odd_next_candidates=tests,cycle_crossings=cycle,outside_crossings=outside))
    print(L,tests,cycle,outside,flush=True)
with open('/mnt/data/cylinder_depth17.json','w') as f:json.dump(rows,f,indent=2)
