from functools import lru_cache
from fractions import Fraction

@lru_cache(None)
def H(x,k,r):
    if x<1 or k<0 or r<0: return None
    if k+r==0: return x
    vals=[]
    if k:
        z=H(2*x,k-1,r)
        if z is not None: vals.append(z)
    if r and x%3==2:
        y=(2*x-1)//3
        if y%2:
            z=H(y,k,r-1)
            if z is not None: vals.append(z)
    return min(vals) if vals else None

checks=0
for t in range(1001):
    x=9*t+5; y=6*t+3; w=32*t+17
    a=w; counts=[0,0]
    for j in range(5):
        if a%2:
            counts[1]+=1; a=(3*a+1)//2
        else:
            counts[0]+=1; a//=2
    assert a==x and counts==[3,2]
    for k in range(3,9):
        candidate=(2**(k-3))*w
        odd_branch=(2**k)*y
        assert candidate<odd_branch
        assert H(x,k,2) is not None and H(x,k,2)<=candidate
        assert H(y,k,0)==odd_branch and H(y,k,1) is None
        checks+=1
print('Verified',checks,'exact cross-branch inequalities for 0<=t<=1000, 3<=k<=8')
print('Example x=5,k=3:',H(5,3,1),H(5,3,2),'odd predecessor branch',H(3,3,0))
