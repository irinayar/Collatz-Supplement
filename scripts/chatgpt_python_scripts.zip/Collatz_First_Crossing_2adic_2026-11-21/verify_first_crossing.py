from fractions import Fraction
from math import ceil,log

def test(N=200000,cap=10000):
    maxratio=(0,1,0,0); checked=0; cross=[]; longest=(0,0)
    for n in range(3,N+1,2):
        x=n; odds=0; num=1;den=1
        for L in range(1,cap+1):
            if x&1:
                num*=3*x+1;den*=3*x;odds+=1
                x=(3*x+1)//2
            else:x//=2
            if x<n:break
            if 2*num>=3*den:
                cross.append((n,L,odds));break
        checked+=1
        if L>longest[0]:longest=(L,n)
        if num*maxratio[1]>maxratio[0]*den:maxratio=(num,den,n,L)
    print('odd starts',checked,'first crossings',cross[:5], 'longest prefix',longest,'max product',float(Fraction(maxratio[0],maxratio[1])),'at',maxratio[2:])

# exact residue and affine prefix checks, all length <= 15

def cylinder(L):
    total=0;bad=0;bad_survivors=[];max_survivors=0
    # construct word from each positive residue 1..2^L
    for a in range(1,(1<<L)+1):
        x=a;U=0;r=0;B=None; word=0
        for j in range(L):
            b=x&1;word|=b<<j
            U=3**b*U+b*(1<<j);r+=b
            x=(3*x+1)//2 if b else x//2
            D=(1<<(j+1))-3**r
            if D>0:
                t=U//D
                B=t if B is None else min(B,t)
        H=(2*U)//(3**r)
        if a<=H:bad+=1
        if a<=H and (B is None or a<=B):bad_survivors.append((a,word))
    print('L',L,'bad cylinders',bad,'survivors',bad_survivors[:10])

if __name__=='__main__':
    test()
    for L in (10,12,14,15,16):cylinder(L)
