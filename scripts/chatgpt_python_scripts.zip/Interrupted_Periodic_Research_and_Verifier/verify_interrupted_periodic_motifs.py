#!/usr/bin/env python3
"""Exact odd-Collatz valuation cylinder and periodic interruption checks."""
from math import ceil

def affine(word):
    a,b,d=1,0,1
    for e in word:
        b=3*b+d
        a*=3
        d*=2**e
    return a,b,d

def next_odd(x):
    y=3*x+1
    e=(y & -y).bit_length()-1
    return y>>e,e

def least_realizer(word):
    a,b,d=affine(word)
    return ((d-b)*pow(a,-1,2*d))%(2*d) or 2*d

def test(word, repeats):
    a,b,d=affine(word)
    q=a-d
    assert q>0 and b%2 and q%2
    for n in range(1,repeats+1):
        full=word*n
        x=least_realizer(full)
        y=x
        for e in full:
            y,got=next_odd(y)
            assert got==e,(word,n,x,e,got)
        assert (q*x+b)%(2*d**n)==0
        assert q*x+b>=2*d**n
        assert x>=ceil((2*d**n-b)/q)
    return (word, q, b, repeats, x)

if __name__=='__main__':
    motifs=[[2,1],[2,1,1],[2,1,2,1,1],[2,1,1,2,1],[1,2,1,1,2,1],[2,1,2,1,2,1,1,1]]
    for word in motifs: print(test(word,8))
    print('PASS: exact valuation replay, congruence, and exponential bound')
