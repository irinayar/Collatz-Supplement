from math import log2
# Thue-Morse finite cube-free controls, plus exact Collatz block-defect checks.
t=[i.bit_count()%2 for i in range(2048)]
for L in range(1, 2048//3+1):
    for s in range(2048-3*L+1):
        assert not (t[s:s+L]==t[s+L:s+2*L]==t[s+2*L:s+3*L]),(s,L)

def T(x):return (3*x+1)//2 if x%2 else x//2

def affine(word):
    a=0;u=0
    for j,b in enumerate(word):
        if b:a+=1;u=3*u+(1<<j)
    return a,u
checked=0
for n in range(1,301):
    seq=[n]
    for i in range(50):seq.append(T(seq[-1]))
    for s in range(15):
        for L in range(1,9):
            w=[seq[s+i]%2 for i in range(L)]
            a,u=affine(w)
            d=((1<<L)-3**a)*seq[s]-u
            for k in range(1,5):
                if s+k*L>50:break
                if all(seq[s+i]%2==w[i%L] for i in range(k*L)):
                    assert d%(1<<(k*L))==0
                    if d:assert (1<<(k*L))<=abs(d)
                    checked+=1
print('2048-bit Thue-Morse prefix: no cubes; repeated-block divisibility checks:',checked)
