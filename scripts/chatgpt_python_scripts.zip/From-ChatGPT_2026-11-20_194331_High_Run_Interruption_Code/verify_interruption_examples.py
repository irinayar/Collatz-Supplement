from fractions import Fraction
from math import gcd
H=255
Q=Fraction(8192,6561)
def run(m):
    n=m; starts=[]; transitions=[]; odd=0; seen=set()
    while n>1:
        if n%2==0:
            n//=2;continue
        if n<=H:break
        if n in seen:raise AssertionError('cycle')
        seen.add(n);odd+=1
        starts.append(n) if not transitions or transitions[-1][1]>=2 else None
        z=3*n+1;a=(z&-z).bit_length()-1
        transitions.append((n,a));n=z>>a
    ints=sum(1 for (u,a) in transitions[:-1] if a>=2)
    # do not count last high-to-low boundary
    assert len(starts)==ints+1
    recip=sum((Fraction(1,u) for u in starts),Fraction(0))
    prod=Fraction(1)
    for u,a in transitions:prod*=Fraction(3*u+1,3*u)
    # exact rational exp majorant, 0 <= t < 3
    t=recip
    major=1+t+t*t/(2*(1-t/3))
    assert prod<=major
    assert Q*major<Fraction(3,2)
    return len(starts),ints,odd,recip,prod,Q*major
for m in [3732423,3542887,626331,187401,993,438699]:
    r,i,o,s,p,b=run(m)
    print(m,'runs',r,'interruptions',i,'odd',o,'sum',float(s),'highprod',float(p),'Qmajor',float(b))
