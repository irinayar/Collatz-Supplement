from functools import lru_cache
@lru_cache(None)
def H(x,k,r):
    if k<0 or r<0 or x<1:return None
    if k==0:
        y=x+1
        for _ in range(r):
            if y%3:return None
            y=(y//3)*2
        return y-1 if y>1 else None
    a=H(2*x,k-1,r)
    b=H((2*x-1)//3,k,r-1) if r>0 and x%3==2 else None
    return min((v for v in (a,b) if v is not None),default=None)
checks=0
for k in range(6):
 for r in range(6):
  P=3**(r+1); A=2**(k+r)
  for x in range(1,101):
   a,b=H(x,k,r),H(x,k,r+1)
   for t in (1,2):
    aa,bb=H(x+t*P,k,r),H(x+t*P,k,r+1)
    assert (a is None)==(aa is None) and (b is None)==(bb is None)
    if a is not None:assert aa==a+3*t*A
    if b is not None:assert bb==b+2*t*A
    if a is not None and b is not None:assert bb-aa==(b-a)-t*A
    checks+=1
print('PASS:',checks,'exact translation checks')
print('Trivial-cycle x=2 example:',H(2,20,21),H(2,20,22),'translated:',H(2+3**22,20,21),H(2+3**22,20,22))
