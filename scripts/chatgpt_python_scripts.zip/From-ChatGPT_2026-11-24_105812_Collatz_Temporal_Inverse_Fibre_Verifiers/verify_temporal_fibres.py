#!/usr/bin/env python3
"""Exact finite checks supporting a symbolic all-depth Collatz inverse-fibre theorem.
No external modules, no random sampling; proof is in the separate Markdown audit.
"""
import json
from pathlib import Path

def T(n):
    assert isinstance(n, int) and n > 0
    return (3*n+1)//2 if n&1 else n//2

def pred(y):
    assert y > 0
    out={2*y}
    if y%3 == 2:
        out.add((2*y-1)//3)
    return out

def fibre(y,h):
    a={y}
    for _ in range(h):
        a={x for z in a for x in pred(z)}
    return a

def compute():
    counts={'inverse_three_exact':0,'two_step_00':0,'allodd_source_cases':0,'allodd_bruteforce_origins':0,'allodd_00_cases':0,'allodd_01_cases':0,'symbolic_five_residue_classes':0,'symbolic_five_words_checked':0}
    for t in range(2000):
        for r in (2,14):
            N=24*t+r
            y=N
            for _ in range(3):y=T(y)
            if r==2:
                expected={N,3*N+2}
            else:
                expected={N,3*N+2,3*N+3,9*N+10}
            got=fibre(y,3)
            assert got==expected,(N,got,expected)
            assert min(got)==N
            counts['inverse_three_exact']+=1
    for N in range(8,10000,12):
        assert N%3==2 and N%4==0
        z=N//4
        x=(N-2)//3
        assert x>0 and x<N and T(T(x))==z
        counts['two_step_00']+=1
    for j in range(1,13):
        for q in range(1,81,2):
            n=(1<<j)*q-1
            N=n
            for k in range(j):
                assert N&1,(n,j,k,N)
                N=T(N)
            assert N==pow(3,j)*q-1
            assert N%3==2 and N%2==0
            counts['allodd_source_cases']+=1
            if N%4==0:
                counts['allodd_00_cases']+=1
                assert n>1
                m=n-1
                a,b=m,n
                for _ in range(j+2):a,b=T(a),T(b)
                assert a==b
                assert T(T((N-2)//3))==T(T(N))
            else:
                counts['allodd_01_cases']+=1
                assert min(fibre(T(T(T(N))),3))==N
                y5=N
                for _ in range(5):y5=T(y5)
                assert all(x>=N-2 for x in fibre(y5,5))
    # Brute-force smaller origins, deliberately small and complete in this range.
    for n in range(3,1200,2):
        j=0; z=n
        while z%2:
            j+=1;z=T(z)
        N=z
        cap=j+(2 if N%4==0 else 5)
        origin_end=n
        for m in range(1,origin_end):
            a,b=m,n
            for k in range(1,cap+1):
                a,b=T(a),T(b)
                if N%4==0 and k==j+2:
                    # At least n-1 meets here; other smaller origins may as well.
                    pass
                else:
                    assert a!=b,(n,m,j,N,k)
            counts['allodd_bruteforce_origins']+=1
    # Symbolic residue certificate for *every* N==2 mod12, all N>=2.
    # M is divisible by 2**5 and 3**6, so parity and all five
    # reverse-branch divisibility tests are constant within N=M*t+r.
    M=2**5*3**6
    observed={}
    for r in range(2,M,12):
        A,B=M,r
        for _ in range(5):
            assert A%2==0
            if B%2:
                A,B=3*A//2,(3*B+1)//2
            else:
                A,B=A//2,B//2
        pairs={(A,B)}
        for _ in range(5):
            nxt=set()
            for a,b in pairs:
                nxt.add((2*a,2*b))
                if b%3==2:
                    assert (2*a)%3==0
                    nxt.add((2*a//3,(2*b-1)//3))
            pairs=nxt
        near=set()
        for a,b in pairs:
            # For t >= 0 all ancestors are >= N-2.
            assert a>=M and b>=r-2,(r,a,b)
            if b<r:
                assert a==M,(r,a,b)
                near.add(b-r)
        expected={26:{-2},38:{-2,-1},74:{-2}}.get(r%96,set())
        assert near==expected,(r,near,expected)
        counts['symbolic_five_residue_classes']+=1
        counts['symbolic_five_words_checked']+=len(pairs)
    return counts

if __name__=='__main__':
    data=compute()
    here=Path(__file__).resolve().parent
    (here/'verification_results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data,indent=2))
