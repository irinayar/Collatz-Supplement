#!/usr/bin/env python3
"""Independent affine-word certificate for inverse fibre at depth five.
Instead of backward branching, enumerates all 32 words and solves each affine equation.
"""
from pathlib import Path
import json
from collections import Counter

M=(2**5)*(3**6)

def T(x): return (3*x+1)//2 if x%2 else x//2

def forward_symbolic(r):
    a,b=M,r
    for _ in range(5):
        assert a%2==0
        if b%2:
            a,b=3*a//2,(3*b+1)//2
        else:
            a,b=a//2,b//2
    return a,b

def word_data(bits):
    a=sum(bits)
    running=0
    c=0
    for t,v in enumerate(bits):
        running+=v
        if v:c+=2**t*3**(a-running)
    return a,c

def get_origin_pairs(r):
    A,B=forward_symbolic(r)
    out=set()
    for mask in range(2**5):
        bits=[(mask>>t)&1 for t in range(5)]
        a,c=word_data(bits)
        den=3**a
        numer=32*B-c
        assert (32*A)%den == 0
        if numer%den:continue
        slope=(32*A)//den
        intercept=numer//den
        if intercept<=0:continue
        # independent forward parity replay at two parameter lifts
        for t in (0,1):
            x=slope*t+intercept
            y=A*t+B
            for bit in bits:
                assert x%2==bit
                x=T(x)
            assert x==y
        out.add((slope,intercept))
    return out

def run():
    counts=Counter(); tail_by_r={}
    for r in range(2,M,12):
        origins=get_origin_pairs(r)
        near=set()
        for a,b in origins:
            assert a>=M and b>=r-2,(r,a,b)
            if b<r:
                assert a==M
                near.add(b-r)
        expected={26:{-2},38:{-2,-1},74:{-2}}.get(r%96,set())
        assert near==expected,(r,near,expected)
        counts['symbolic_residue_classes']+=1
        counts['affine_word_ancestors']+=len(origins)
        counts['all_words_screened']+=32
        counts[f'ancestors_{len(origins)}']+=1
        tail_by_r.setdefault(str(r%96),set()).update(near)
    counts['near_mod96_class_count']=sum(bool(s) for s in tail_by_r.values())
    summary={'counts':dict(counts),'near_shifts_mod96':{k:sorted(s) for k,s in sorted(tail_by_r.items(),key=lambda z:int(z[0]))}}
    Path(__file__).with_name('independent_word_results.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':run()
