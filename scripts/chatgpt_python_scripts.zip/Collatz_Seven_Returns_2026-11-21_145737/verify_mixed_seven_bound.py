#!/usr/bin/env python3
"""Exact residue envelope for low-band chains with return gaps at most seven.

This certifies a restricted-family theorem under distinct positive-charge
departure states. It does not prove convergence or exclude nontrivial cycles.
The classification of proper seven-return suffixes is an input theorem; the
56-word/30-word combinatorics and all rational arithmetic are rechecked here.
Standard library only. No floating-point comparison is used as a certificate.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json


def compositions(total, length):
    if length == 1:
        if total >= 1:
            yield (total,)
        return
    for first in range(1, total - length + 2):
        for tail in compositions(total - first, length - 1):
            yield (first,) + tail


def affine(word):
    exponent = numerator = 0
    for e in word:
        numerator = 3 * numerator + (1 << exponent)
        exponent += e
    return exponent, numerator


def odd_step(u):
    z = 3 * u + 1
    e = (z & -z).bit_length() - 1
    return z >> e, e


def prefix_valuations(u, count):
    result = []
    for _ in range(count):
        u, e = odd_step(u)
        result.append(e)
    return tuple(result)


def make_family(word, gap):
    exponent, numerator = affine(word)
    multiplier = 3 ** gap
    modulus = 1 << (exponent + 1)
    residue = (((1 << exponent) - numerator)
               * pow(multiplier, -1, modulus)) % modulus
    assert residue > 0 and residue % 2 == 1
    assert prefix_valuations(residue, gap) == word
    charge_num = numerator + 5 * ((1 << exponent) - multiplier)
    assert charge_num > 0
    return dict(gap=gap, word=word, numerator=numerator,
                modulus=modulus, residue=residue,
                charge_num=charge_num, charge_den=multiplier)


def families():
    words3 = [(1, 1, 3), (1, 2, 2)]
    words5 = [(1, 1, 1, 1, 4), (1, 1, 1, 2, 3),
              (1, 1, 1, 3, 2), (1, 1, 2, 1, 3),
              (1, 1, 2, 2, 2), (1, 2, 1, 1, 3),
              (1, 2, 1, 2, 2)]
    candidates = [(1,) + tail for tail in compositions(10, 6)
                  if tail[-1] >= 2]
    assert len(candidates) == 56
    words7 = []
    for word in candidates:
        prefix_e = 0
        valid = True
        for j, e in enumerate(word[:-1], 1):
            prefix_e += e
            # Every nonempty proper suffix of a genuine first return must
            # have coefficient 3^(7-j)/2^(11-prefix_e) strictly below 1.
            valid = valid and (3 ** (7 - j) < (1 << (11 - prefix_e)))
        if valid:
            words7.append(word)
    assert len(words7) == 30
    output = [make_family(word, gap)
              for gap, words in ((3, words3), (5, words5), (7, words7))
              for word in words]
    seven = [f for f in output if f['gap'] == 7]
    assert sum(f['charge_num'] for f in seven) == 64148
    assert min(f['residue'] for f in seven) == 155
    assert max(f['charge_num'] for f in seven) == 3072
    return output


def sum_by_progressions(n, profile_rows):
    high = (4 * n - 2) // 3
    sums = {3: Q(0), 5: Q(0), 7: Q(0)}
    counts = {3: 0, 5: 0, 7: 0}
    for f in profile_rows:
        first = n + (f['residue'] - n) % f['modulus']
        for u in range(first, high + 1, f['modulus']):
            sums[f['gap']] += Q(f['charge_num'], f['charge_den'] * (u + 5))
            counts[f['gap']] += 1
    return sums, counts


def sum_by_actual_word_replay(n, profile_rows):
    high = (4 * n - 2) // 3
    table = {(f['gap'], f['word']): f for f in profile_rows}
    sums = {3: Q(0), 5: Q(0), 7: Q(0)}
    counts = {3: 0, 5: 0, 7: 0}
    for u in range(n, high + 1, 2):
        word = prefix_valuations(u, 7)
        for gap in (3, 5, 7):
            f = table.get((gap, word[:gap]))
            if f is not None:
                sums[gap] += Q(f['charge_num'], f['charge_den'] * (u + 5))
                counts[gap] += 1
    return sums, counts


def rational(q):
    return dict(numerator=q.numerator, denominator=q.denominator)


def certify():
    profile_rows = families()
    weights = {gap: sum((Q(f['charge_num'], f['charge_den'])
                         for f in profile_rows if f['gap'] == gap), Q(0))
               for gap in (3, 5, 7)}
    assert weights == {3: Q(92, 27), 5: Q(764, 81), 7: Q(64148, 2187)}
    linear = (weights[3] / (3 * 64) + weights[5] / (3 * 512)
              + weights[7] / (3 * 4096))
    additive = sum(weights.values(), Q(0))
    assert linear == Q(176525, 6718464)
    assert additive == Q(92228, 2187)
    # S(n) <= (linear*n+additive)/(n+5), decreasing since additive>5*linear.
    assert additive > 5 * linear
    threshold = 1023
    large_s = (linear * threshold + additive) / (threshold + 5)
    large_r = Q(4 * (threshold + 5), 4 * threshold + 15)
    large_bound = large_r / (1 - large_s)
    assert large_bound == Q(350615568384, 326667306847)
    assert large_s < 1
    expected_max = Q(1088640, 994117)
    assert large_bound < expected_max < Q(11, 10)
    small_rows = []
    maximum = Q(0)
    max_n = None
    for n in range(3, threshold, 2):
        sums, counts = sum_by_progressions(n, profile_rows)
        alternate_sums, alternate_counts = sum_by_actual_word_replay(n, profile_rows)
        assert sums == alternate_sums and counts == alternate_counts
        total = sum(sums.values(), Q(0))
        assert total < 1
        high = (4 * n - 2) // 3
        endpoint = Q((n + 5) * high, n * (high + 5))
        envelope = endpoint / (1 - total)
        assert envelope <= expected_max
        if envelope > maximum:
            maximum, max_n = envelope, n
        small_rows.append(dict(n=n, H=high, counts=counts,
                               S_by_gap={gap: rational(q) for gap, q in sums.items()},
                               S=rational(total), endpoint_ratio=rational(endpoint),
                               product_envelope=rational(envelope)))
    assert len(small_rows) == 510
    assert (maximum, max_n) == (expected_max, 43)
    assert Q(11, 10) * Q(10, 9) ** 2 == Q(110, 81) < Q(3, 2)
    return dict(scope='Gaps 2..7; distinct positive-charge departure states; '
                      'completed low-band returns. Gap6 absent by K138.',
                classification_profiles=profile_rows,
                total_weight_by_gap={gap: rational(q) for gap, q in weights.items()},
                analytic_bound=dict(threshold=threshold, linear=rational(linear),
                                    additive=rational(additive),
                                    S_at_threshold=rational(large_s),
                                    endpoint_upper_at_threshold=rational(large_r),
                                    product_upper=rational(large_bound)),
                finite_certificate=dict(rows=small_rows, count=len(small_rows),
                                        maximum=rational(maximum), maximizing_n=max_n,
                                        independent_methods_agree=True),
                conclusion=dict(completed_upper=rational(maximum),
                                clean_strict_upper=rational(Q(11, 10)),
                                two_tail_strict_upper=rational(Q(110, 81))))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('mixed_seven_bound_certificate.json'))
    args = parser.parse_args()
    certificate = certify()
    args.output.write_text(json.dumps(certificate, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(status='PASS', exact_small_n_rows=510,
                          threshold=1023, small_maximum='1088640/994117',
                          maximizing_n=43,
                          analytic_large_n_upper='350615568384/326667306847',
                          completed_strict_bound='11/10',
                          two_tail_strict_bound='110/81',
                          certificate=str(args.output)), indent=2))


if __name__ == '__main__':
    main()
