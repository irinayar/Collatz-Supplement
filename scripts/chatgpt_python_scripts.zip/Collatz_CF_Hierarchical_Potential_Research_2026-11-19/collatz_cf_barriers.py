#!/usr/bin/env python3
"""Exact Collatz affine-numerator barrier and high precision CF record scan."""
import argparse, json, sys
sys.set_int_max_str_digits(0)
from fractions import Fraction
import mpmath as mp

def numerator(word):
    u=0
    for i,b in enumerate(word):
        if b=='1': u=3*u+(1<<i)
    return u

def brute_check(limit=12):
    checks=0
    for L in range(1,limit+1):
        for mask in range(1<<L):
            w=''.join(str((mask>>i)&1) for i in range(L))
            A=w.count('1')
            assert numerator(w)>=3**A-2**A, (w,numerator(w))
            checks+=1
    return checks

def record_scan(max_a=100000, precision=100):
    mp.mp.dps=precision
    beta=mp.log(3)/mp.log(2)
    best=mp.inf
    rows=[]
    for a in range(1,max_a+1):
        L=int(mp.floor(a*beta))+1
        eps=mp.mpf(L)-a*beta
        if eps<best:
            best=eps
            # exact integer comparison; numerator and denominator potentially huge
            D=(1<<L)-pow(3,a)
            numerator_min=pow(3,a)-(1<<a)
            threshold=numerator_min//D
            rows.append({'A':a,'L':L,'epsilon_bits':mp.nstr(eps,17),
                         'D_digits':len(str(D)), 'floor_barrier':str(threshold),
                         'barrier_approx':mp.nstr(mp.mpf(numerator_min)/mp.mpf(D),12)})
    return rows

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-a',type=int,default=10000)
    p.add_argument('--check-l',type=int,default=12)
    p.add_argument('--output',default='collatz_cf_barriers_results.json')
    args=p.parse_args()
    count=brute_check(args.check_l)
    records=record_scan(args.max_a)
    out={'checked_words':count,'max_a':args.max_a,'record_count':len(records),'records':records}
    with open(args.output,'w') as f:json.dump(out,f,indent=2)
    print('checked words',count,'record count',len(records))
    for row in records[:15]:print(row['A'],row['L'],row['epsilon_bits'],row['barrier_approx'])
