from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def word_data(j):
    out=[]
    for r in range(1,2**j+1):
        x=r;a=0
        for _ in range(j):
            a+=x%2;x=T(x)
        U=2**j*x-3**a*r
        out.append((r,a,U))
    return out

def has_smaller_meeting(n,j):
    x=n
    for _ in range(j):x=T(x)
    for m in range(1,n):
        y=m
        for _ in range(j):y=T(y)
        if y==x:return True
    return False

def eventual_status(n,j,data):
    mod2=2**j
    r=(n-1)%mod2+1
    _,a,Uw=data[r-1]
    for v,b,Uv in data:
        numerator=3**a*n+Uw-Uv
        if numerator%3**b:continue
        m=numerator//3**b
        if 1<=m<n:return True
    return False

if __name__=='__main__':
    total=0
    for j in range(1,6):
        data=word_data(j)
        C=2**(j+1)*3**j
        # Uniform sufficient threshold n>2C+1 makes positivity and sign of m-n stable.
        threshold=2*C+2
        modulus=2**j*3**j
        # Test congruence invariance above threshold for every residue, two shifts.
        statuses=[]
        for r in range(1,modulus+1):
            n=r+modulus*((threshold-r+modulus-1)//modulus) if r<threshold else r
            s=eventual_status(n,j,data)
            assert s==eventual_status(n+modulus,j,data)
            statuses.append(s)
            total+=1
        print(f'j={j}, modulus={modulus}, eventual meeting residues={sum(statuses)}/{modulus}')
    # Direct brute check, independent of affine candidate computation.
    for j in range(1,5):
        data=word_data(j)
        for n in range(1,201):
            assert eventual_status(n,j,data)==has_smaller_meeting(n,j),(n,j)
    print('PASS: residue invariance and 800 direct brute-force comparisons; residue checks:',total)
