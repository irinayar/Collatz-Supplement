#!/usr/bin/env python3
"""Exact local audit for K188/K190 and the mixed reciprocal-cost lemma.

No trajectory census. Replays only the supplied 256-transition checkpoint,
then stops. The reciprocal packing theorem is an identified prior input.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions must remain enabled.")


def v2(x):
    assert x > 0
    return (x & -x).bit_length()-1


def ceil_grid(x, D):
    return F(-((-x.numerator*D)//x.denominator), D)


def exp_upper_12(z):
    assert 0 <= z < 1
    term = total = F(1)
    for j in range(1, 13):
        term *= z/j
        total += term
    return total + (term*z/13)/(1-z/14)


def high_reciprocal_bound(L, S):
    return (F(3**S-1, 2**L)
            + F(200, 7)*F(193, 200)**(S+1)
            + F(L+1, 2**(L-1)))


def checkpoint():
    u, n = 2**256-1, 3*2**254+1
    H = (4*n-2)//3
    assert H == 2**256 and n <= u <= H
    L, Dgrid = (H+1).bit_length()-1, 2**256
    assert L == 256
    odd, shortcut, word = [u], [u], []
    q, U, E, low = F(0), 0, 0, n
    first_singleton = None
    rows = []
    for g in range(1, 257):
        a = odd[-1]
        e = v2(3*a+1)
        word.append(e)
        x = (3*a+1)//2
        shortcut.append(x)
        for _ in range(e-1):
            assert x % 2 == 0
            x //= 2
            shortcut.append(x)
        odd.append(x)
        assert x & 1 and x > H
        U = 3*U+2**E
        E += e
        q = F(U, 3**g)
        assert 2**E*x == 3**g*u+U
        modulus = 2**(E+1)
        residue = ((2**E-U)*pow(3**g, -1, modulus)) % modulus
        assert residue == u % modulus
        low = max(low, (2**E*H-U)//3**g+1)
        active_low = max(low, (32*q.numerator)//(15*q.denominator)+1)
        least = active_low+(residue-active_low) % modulus
        count = 0 if least > H else 1+(H-least)//modulus
        assert count >= 1 and least <= u <= H
        if count == 1 and first_singleton is None:
            first_singleton = g
        if g in (252, 253, 255, 256):
            rows.append(dict(depth=g, exponent=e, E=E,
                             active_count=str(count), least_source=str(least)))
    assert word == [1]*255+[11]
    assert E == 266 and len(shortcut)-1 == E
    assert len(set(shortcut[:-1])) == E
    assert first_singleton == 253
    assert q == 1-F(2, 3)**256
    for i in range(256):
        assert odd[i] == 3**i*2**(256-i)-1
    assert odd[-1] == (3**256-1)//2**10
    assert v2(3**256-1) == 10

    # Only past inputs are spent. The last output is the future current state.
    past_all = sum(Dgrid//x for x in odd[:-1])
    past_high = sum(Dgrid//x for x in odd[:-1] if x >= 2**L)
    assert past_all == 1 and past_high == 0
    bounds = [high_reciprocal_bound(L, S) for S in range(2*L+1)]
    S = min(range(len(bounds)), key=lambda j: bounds[j])
    assert S == 156
    b = min(F(144, 125)-F(past_all, Dgrid),
            bounds[S]-F(past_high, Dgrid))
    assert b == bounds[S] > 0
    z = ceil_grid(b/3, Dgrid)
    assert z >= b/3 and z < 1
    exponential_cap = (1+q/u)*exp_upper_12(z)-1
    linear_cap = q/u+F(47, 96)*b
    cap = ceil_grid(min(F(15, 32), linear_cap, exponential_cap), Dgrid)
    ratio = cap/F(15, 32)
    assert F(78, 1000) < ratio < F(79, 1000)
    assert F(36, 1000) < cap < F(37, 1000)
    return dict(source=str(u), threshold=str(n), H=str(H), stopped_depth=256,
                E=E, first_singleton=first_singleton, checkpoints=rows,
                exact_phase=str(q), exact_phase_short="1-(2/3)^256",
                supplied_word="255 copies of 1, followed by 11",
                S_minimum_over_0_to_512=S, reciprocal_bound=str(b),
                rounded_cap_over_source=str(cap),
                ratio_to_baseline=str(ratio),
                decimal_ratio_informational=float(ratio),
                future_steps_computed=0,
                scope="Conditional cap; no eventual completion asserted.")


def run_cost(s, a):
    return sum((1/(F(3, 2)**j*(a+1)-1) for j in range(s)), F(0))


def coefficient(s, e):
    beta = 1-F(2, 3)**s
    lam = F(2**(s+e-1), 3**s)
    chi = max(F(0), 1+beta-lam)
    return beta, lam, chi, chi/(3*beta)


def mixed_lemma():
    checks = positive = zero = 0
    for s in range(1, 13):
        for e in range(2, 19):
            beta, lam, chi, gamma = coefficient(s, e)
            assert 0 <= gamma < F(2, 3)
            for a in (F(1), F(3, 2), F(2), F(3), F(10),
                      F(100), F(2**71+1)):
                ta = ((a-1)/(a+1))*beta/a+1/a-lam/(a+beta)
                c = run_cost(s, a)
                clow = (3*a*beta+1)/(a*(a+1))
                assert c >= clow
                assert max(F(0), ta) <= gamma*c
                if chi > 0:
                    numerator = (3*beta**2*(1-beta)*(a-1)
                                 + chi*(a*(1-3*beta+3*beta**2)+beta))
                    gap = gamma*clow-ta
                    assert gap == numerator/(3*beta*a*(a+1)*(a+beta))
                    assert gap > 0
                    positive += 1
                else:
                    cutoff_charge = -beta*(1-beta)*(a-1)/(a*(a+1)*(a+beta))
                    assert ta <= cutoff_charge <= 0
                    zero += 1
                checks += 1
    assert checks == 1428
    assert coefficient(2, 2)[3] == F(2, 5)
    assert coefficient(5, 4)[3] == F(66, 211)
    assert F(2, 5)-F(66, 211) == F(92, 1055)
    return dict(scalar_identity_controls=checks, positive_cases=positive,
                zero_cases=zero, R_factor="2/5", C_5_4_factor="66/211",
                mixed_cost_credit="92/1055",
                universal_factor_ceiling="2/3",
                proof_assumptions="a >= n > 1; output a_out >= n not needed for local lemma",
                scope="Fixed scalar algebra controls, not a trajectory census.")


def R_cost(a):
    return F(1, a)+F(2, 3*a+1)


def residual_height():
    n, m = 2**71+1, 72
    H = (4*n-2)//3
    a0 = H+1+(11-(H+1)) % 16
    old_exponent, new_exponent = 64*m, 29*(m+15)
    assert (old_exponent, new_exponent) == (4608, 2523)
    Aold, Anew = 2**old_exponent-5, 2**new_exponent-5
    assert Aold % 16 == Anew % 16 == a0 % 16 == 11
    assert a0 > H
    assert Anew > a0+16*4
    kappa = F(n-1, n+1)
    C = kappa+F(9*(a0+5), 5*(9*a0+5))
    gamma = C*F(5*(3*a0+1), 9*(5*a0+1))
    assert gamma < F(2, 5)
    t0 = kappa*F(5, 9*a0)+F(a0+5, a0*(9*a0+5))
    assert gamma == t0/R_cost(a0)
    old = new = F(0)
    rows = []
    for k in range(1, 5):
        old += R_cost(Aold-16*(k-1))
        new += R_cost(Anew-16*(k-1))
        assert 2**2084*old < new < 2**2086*old
        rows.append(dict(k=k, residual_cost_numerator_bits=new.numerator.bit_length(),
                         residual_cost_denominator_bits=new.denominator.bit_length(),
                         improvement_ratio_between_powers_of_two=[2084, 2086]))
    return dict(m=m, old_height_exponent=old_exponent,
                residual_height_exponent=new_exponent,
                exponent_gain=old_exponent-new_exponent,
                R_exact_source_factor=str(gamma), cost_comparisons=rows,
                scope="Height restriction only after assigning the already-paid core tail.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path("reciprocal_cost_audit_certificate.json"))
    args = parser.parse_args()
    result = dict(status="exact audit passed",
                  checkpoint=checkpoint(), mixed_lemma=mixed_lemma(),
                  residual_height=residual_height(),
                  imported_theorems=["Original reciprocal packing budgets",
                                     "Previously paid height/long-run tail"],
                  unresolved="Uniform sum of remaining reciprocal budgets over all actual sources.")
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print("Verified supplied depth256 checkpoint and first singleton depth253.")
    print("Verified cap parameter S=156 and exact rounded conditional-cap ratio.")
    print("Verified 1428 scalar controls of mixed reciprocal-cost identity.")
    print("No source census or additional trajectory continuation performed.")
    print("Certificate:", args.output)


if __name__ == "__main__":
    main()
