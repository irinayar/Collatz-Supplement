#!/usr/bin/env python3
"""Verify packet hashes and replay both exact certificate generators."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

if not __debug__:
    raise SystemExit("Run without -O or -OO: assertions must remain enabled.")


def verify() -> dict:
    root = Path(__file__).resolve().parent
    checked = 0
    for line in (root / "MANIFEST.sha256").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file():
            raise RuntimeError(f"Invalid manifest path: {name}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f"Hash mismatch: {name}")
        checked += 1
    jobs = [
        ("inverse_parity.py", ["--verify"], "inverse_parity_certificate.json"),
        ("continuation/verify_reciprocal_cost_audit.py", [],
         "continuation/reciprocal_cost_audit_certificate.json"),
    ]
    replayed = []
    with tempfile.TemporaryDirectory(prefix="parity-replay-") as tmp:
        for script, options, expected_file in jobs:
            target = Path(tmp) / Path(expected_file).name
            result = subprocess.run(
                [sys.executable, str(root / script), *options, "--output", str(target)],
                cwd=root, text=True, capture_output=True, check=True,
            )
            expected = json.loads((root / expected_file).read_text())
            actual = json.loads(target.read_text())
            if actual != expected:
                raise RuntimeError(f"Certificate mismatch: {script}")
            replayed.append({"script": script, "certificate_matches": True})
    return {"status": "PASS", "hashed_files": checked, "replays": replayed,
            "scope": "Exact formula and supplied-checkpoint controls; no unrestricted aggregate theorem."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify()
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
