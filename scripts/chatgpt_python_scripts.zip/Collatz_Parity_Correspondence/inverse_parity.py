#!/usr/bin/env python3
"""Exact Collatz inverse-parity demonstrations and bounded verification.

Bits are chronological: the LEFTMOST supplied bit is the least significant
bit of the parity integer and describes the starting state's parity.
Uses T(x)=(3*x+1)//2 for odd x and x//2 for even x.

Examples:
    python inverse_parity.py --bits 11101
    python inverse_parity.py --bits 1101 --band 10 40
    python inverse_parity.py --verify --output inverse_parity_certificate.json

All calculations use integers or fractions.Fraction. Finite checks are
controls for the proved identities, not a Collatz convergence verification.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Run without -O or -OO: exact checks require assertions.")


def shortcut(n: int) -> int:
    return (3*n+1)//2 if n & 1 else n//2


def bits_from_source(n: int, length: int) -> list[int]:
    assert length >= 0
    bits = []
    for _ in range(length):
        bits.append(n & 1)
        n = shortcut(n)
    return bits


def affine(bits: list[int]) -> tuple[int, int]:
    """Return r,U with 2^L*T^L(n)=3^r*n+U on this cylinder."""
    r = U = 0
    for i, bit in enumerate(bits):
        assert bit in (0, 1)
        if bit:
            U = 3*U + (1 << i)
            r += 1
    return r, U


def inverse_rational(bits: list[int]) -> F:
    """Phi of this finite parity integer, whose later bits are all zero."""
    r = 0
    result = F(0)
    for i, bit in enumerate(bits):
        assert bit in (0, 1)
        if bit:
            r += 1
            result -= F(1 << i, 3**r)
    return result


def least_residue(bits: list[int]) -> int:
    if not bits:
        return 0
    r, U = affine(bits)
    M = 1 << len(bits)
    return (-U * pow(3**r, -1, M)) % M


def lifted_residues(bits: list[int]) -> list[int]:
    """Decode the ordinary binary source digits one at a time."""
    a = r = U = 0
    out = [a]
    for L, bit in enumerate(bits):
        numerator = 3**r*a + U
        assert numerator % (1 << L) == 0
        predicted = (numerator >> L) & 1
        new_source_bit = bit ^ predicted
        a += new_source_bit << L
        if bit:
            U = 3*U + (1 << L)
            r += 1
        out.append(a)
    return out


def first_in_band(a: int, M: int, low: int, high: int):
    assert 0 <= a < M and 0 <= low <= high
    candidate = low + (a-low) % M
    return candidate if candidate <= high else None


def describe(bits: list[int], band=None) -> dict:
    L = len(bits)
    r, U = affine(bits)
    M = 1 << L
    a = least_residue(bits)
    data = {
        "bits_earliest_first": "".join(map(str, bits)),
        "length": L,
        "parity_integer_prefix": sum(bit << i for i, bit in enumerate(bits)),
        "odd_count": r,
        "affine_numerator_U": U,
        "finite_parity_inverse_rational": str(inverse_rational(bits)),
        "source_modulus": M,
        "least_nonnegative_source_residue": a,
        "least_positive_source": a if a else M,
        "source_residue_lifts": lifted_residues(bits),
        "meaning": "Finite parity fixes a source residue, not the unspecified infinite continuation.",
    }
    if band:
        data["band"] = list(band)
        data["first_source_in_band"] = first_in_band(a, M, *band)
    return data


def verify() -> dict:
    words = source_checks = lift_checks = 0
    rows = []
    for L in range(1, 13):
        residues = set()
        for Q in range(1 << L):
            bits = [(Q >> i) & 1 for i in range(L)]
            a = least_residue(bits)
            r, U = affine(bits)
            assert inverse_rational(bits) == -F(U, 3**r)
            assert bits_from_source(a, L) == bits
            assert lifted_residues(bits)[-1] == a
            residues.add(a)
            n = a + (1 << L)
            x = n
            for _ in range(L):
                x = shortcut(x)
            assert (1 << L)*x == 3**r*n+U
            assert bits_from_source(n, L) == bits
            for nxt in (0, 1):
                extended = least_residue(bits+[nxt])
                assert extended in (a, a+(1 << L))
                assert lifted_residues(bits+[nxt])[-1] == extended
                lift_checks += 1
            words += 1
            source_checks += 2
        assert residues == set(range(1 << L))
        rows.append({"length": L, "words": 1 << L, "permutation": True})

    concatenations = 0
    for L in range(1, 5):
        for bits in product((0, 1), repeat=L):
            p = list(bits)
            r, _ = affine(p)
            for tail in ([0], [1], [1, 0, 1], [1, 1, 0, 1]):
                assert inverse_rational(p+tail) == (
                    inverse_rational(p) + F(1 << L, 3**r)*inverse_rational(tail))
                concatenations += 1

    examples = []
    for n in (1, 2, 3, 7, 27, 2**71+1):
        bits = bits_from_source(n, 96)
        a = lifted_residues(bits)
        assert all(a[L] == n % (1 << L) for L in range(97))
        assert all(a[L] == n for L in range(n.bit_length(), 97))
        examples.append({"source": str(n), "residues_stabilize_from": n.bit_length()})
    seven = [describe(bits_from_source(7, L)) for L in (1, 2, 3, 4, 5, 8, 12)]
    assert describe([1, 1, 0, 1])["least_nonnegative_source_residue"] == 11
    assert first_in_band(11, 16, 10, 40) == 11
    assert first_in_band(11, 16, 12, 40) == 27
    assert first_in_band(11, 16, 12, 20) is None

    # Exact periodic words, evaluated by their affine fixed-point identity.
    periodic = []
    for block, expected in [([1], F(-1)), ([1, 0], F(1)), ([1, 0, 0], F(1, 5))]:
        r, U = affine(block)
        x = F(U, 2**len(block)-3**r)
        assert x == expected
        Q = F(sum(b << j for j, b in enumerate(block)), 1-2**len(block))
        for count in (1, 2, 4, 8, 16):
            p = block*count; M = 1 << len(p)
            assert least_residue(p) == (x.numerator*pow(x.denominator, -1, M)) % M
        periodic.append({"block_earliest_first": "".join(map(str, block)),
                         "full_parity_2adic_rational": str(Q),
                         "initial_2adic_rational": str(x)})

    # Every exact odd-exponent word carries one extra final odd parity bit.
    odd_arrival_words = 0
    for g in range(1, 4):
        for word in product(range(1, 5), repeat=g):
            E = U = 0
            bits = []
            for e in word:
                U = 3*U + (1 << E)
                E += e
                bits += [1] + [0]*(e-1)
            bits += [1]
            M = 1 << (E+1)
            expected = (((1 << E)-U)*pow(3**g, -1, M)) % M
            assert least_residue(bits) == expected
            x = expected
            for e in word:
                v = 3*x+1
                assert (v & -v).bit_length()-1 == e
                x = v >> e
            odd_arrival_words += 1

    return {"status": "PASS", "finite_prefix_words": words,
            "source_replays": source_checks, "one_bit_lift_checks": lift_checks,
            "permutation_rows": rows, "concatenation_checks": concatenations,
            "odd_arrival_words": odd_arrival_words, "source_examples": examples,
            "seven_prefix_table": seven, "periodic_controls": periodic,
            "Q_of_seven": str(F(151)-F(2**11, 3)),
            "scope": "Exact finite controls of classical inverse parity and derived residue identities; no new convergence or aggregate theorem."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bits", help="Chronological 0/1 string, earliest parity first.")
    parser.add_argument("--band", nargs=2, type=int, metavar=("LOW", "HIGH"))
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.verify:
        data = verify()
    else:
        word = args.bits or "11101"
        if not word or set(word)-{"0", "1"}:
            parser.error("--bits must contain only 0 and 1.")
        if args.band and not (0 <= args.band[0] <= args.band[1]):
            parser.error("--band requires 0 <= LOW <= HIGH.")
        data = describe(list(map(int, word)), args.band)
    text = json.dumps(data, indent=2)
    if args.output:
        args.output.write_text(text+"\n")
    if args.verify:
        print(json.dumps({k: data[k] for k in ["status", "finite_prefix_words", "source_replays", "one_bit_lift_checks", "concatenation_checks", "odd_arrival_words"]}, indent=2))
    else:
        print(text)


if __name__ == "__main__":
    main()
