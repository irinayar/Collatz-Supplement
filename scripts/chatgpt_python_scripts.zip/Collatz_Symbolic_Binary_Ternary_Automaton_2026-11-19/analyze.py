from fractions import Fraction
from collections import Counter
import json, math

def T(x):return x//2 if x%2==0 else (3*x+1)//2

def affine_word(bits):
    a=0;u=0
    for b in bits:
        if b:u=3*u+(1<<len_done[0]);a+=1
        len_done[0]+=1
    return a,u

def targets(ell):
    out=[]
    for L in range(ell+1):
        for mask in range(1<<L):
            a=u=0
            for i in range(L):
                if mask>>i&1:u=3*u+(1<<i);a+=1
            out.append((L,a,u,mask))
    return out

def build(j,H=8,E=4):
    # D tests for source at times j through j+H. Exact parity for every k mod 2^H;
    # affine T^(j+h)(n) = (3^j*k-1) continued by h bits.
    d_table=[]
    for r in range(1<<H):
        y=3**j*r-1
        # representative may be -1 for r=0; parity still valid in 2-adics
        bits=[];a=u=0;D=[]
        for h in range(H+1):
            # T^(j+h)(n) = (3^a*(3^j*k-1)+u)/2^h
            # inequality vs n=2^j*k-1
            slope=3**(j+a)-2**(j+h)
            intercept=2**(j+h)-3**a+u
            # endpoint - n = (slope*k+intercept)/2^h
            if slope<0:
                # k > intercept/(-slope)
                D.append((h,slope,intercept))
            if h<H:
                bit=y&1;bits.append(bit)
                if bit:u=3*u+(1<<h);a+=1
                y=T(y)
        d_table.append(D)
    # I endpoint candidate exact affine word and k-congruence
    I=[]
    for L,b,u,mask in targets(E):
        # m=(2^L*(3^j*k-1)-u)/3^b ; n=2^j*k-1
        den=3**b
        slope=2**L*3**j-den*2**j
        intercept=den-2**L-u
        # m<n iff slope*k+intercept<0; positive eventually requires slope_m>0 (always)
        # integrality: 2^L*(3^j*k-1)-u == 0 mod 3^b
        mod=den
        residues=[r for r in range(mod) if (2**L*(3**j*r-1)-u)%mod==0]
        if residues:
            I.append((L,b,u,mask,mod,residues,slope,intercept))
    Q=(1<<H)*3**E
    # Beyond this K, all affine inequalities have stabilized (also positive origins).
    thresholds=[1]
    for Ds in d_table:
        for h,s,c in Ds:thresholds.append(max(1,c//(-s)+2))
    for L,b,u,mask,mod,res,s,c in I:
        if s!=0:thresholds.append(abs(c)//abs(s)+3)
        thresholds.append((2**L+u)//(2**L*3**j)+3)
    K=max(thresholds)
    # D eventual residues (for k>=K)
    d_ok=[bool(Ds) for Ds in d_table]
    # I eventual residues, with slope negative, or equal and intercept negative
    good_I=[(mod,set(res)) for L,b,u,mask,mod,res,s,c in I if s<0 or (s==0 and c<0)]
    counts=Counter(); uncovered=[]; example={}
    for r in range(Q):
        D=d_ok[r%(1<<H)]
        I0=r%3==0
        Iy=any(r%mod in rs for mod,rs in good_I)
        ok=D or I0 or Iy
        counts['D']+=D;counts['I0']+=I0;counts['Iy']+=Iy;counts['union']+=ok
        if not ok:
            uncovered.append(r)
            key=f'{r%3},{r%8}'
            example.setdefault(key,r)
    # Check all guards with exact integer iterates for representatives K+residue, plus second period.
    samples=0
    for r in range(Q):
        k=K+((r-K)%Q)
        for offset in (0,Q):
            kk=k+offset;n=(1<<j)*kk-1;y=3**j*kk-1
            x=y;actualD=x<n
            for h in range(1,H+1):
                x=T(x);actualD |= x<n
            assert actualD==d_ok[kk%(1<<H)],('D',j,kk)
            # exact I test via candidate words
            actualI=False
            for L,b,u,mask,mod,res,s,c in I:
                numer=2**L*y-u
                if numer%3**b:continue
                m=numer//3**b
                if 0<m<n:
                    z=m
                    for t in range(L):
                        assert z%2==((mask>>t)&1)
                        z=T(z)
                    assert z==y
                    actualI=True;break
            assert actualI==any(kk%mod in rs for mod,rs in good_I),('I',j,kk)
            samples+=1
    # construct explicit noncontracting symbolic 2-adic infinite path: all ones
    return {'j':j,'H':H,'E':E,'period':Q,'stabilization_k':K,'counts':dict(counts),'uncovered_count':len(uncovered),'uncovered_residues':uncovered,'uncovered_mod3_mod8':dict(Counter(f'{r%3},{r%8}' for r in uncovered)),'first_residues':uncovered[:30],'validation':samples,'target_words':len(I),'eventual_I_words':len(good_I)}

if __name__=='__main__':
    a=[build(j) for j in (3,4,5)]
    with open('/mnt/data/collatz_symbolic_automaton/results.json','w') as f:json.dump(a,f,indent=2)
    for z in a:print({k:v for k,v in z.items() if k not in ('uncovered_residues',)})
