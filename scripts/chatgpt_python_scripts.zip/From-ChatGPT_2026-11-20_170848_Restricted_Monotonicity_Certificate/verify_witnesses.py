from functools import lru_cache

def T(n): return (3*n+1)//2 if n&1 else n//2

def reachable(origin,endpoint,k,r):
    n=origin;e=o=0
    while e<=k and o<=r:
        if (n,e,o)==(endpoint,k,r):return True
        if n&1:o+=1
        else:e+=1
        n=T(n)
    return False
for k,x,r,a,b in [(20,2,21,1,251),(21,1,21,1,251),(22,2,23,1,251),(23,2,27,111,175),(24,1,27,111,175)]:
    assert reachable(a,x,k,r)
    assert reachable(b,x,k,r+1)
    print(k,x,r,a,b,'replay OK')
