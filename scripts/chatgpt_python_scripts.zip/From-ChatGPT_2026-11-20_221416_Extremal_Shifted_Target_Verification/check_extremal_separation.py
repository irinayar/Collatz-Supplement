from functools import lru_cache
from collections import Counter
@lru_cache(None)
def ext(x,k,r):
    if k<0 or r<0:return None
    if k==r==0:return (x,x)
    a=[]
    if k: 
        t=ext(2*x,k-1,r)
        if t:a.append(t)
    if r and x%3==2:
        y=(2*x-1)//3
        if y%2:
            t=ext(y,k,r-1)
            if t:a.append(t)
    if not a:return None
    return (min(t[0] for t in a),max(t[1] for t in a))
checks=0; fail=[]; tight=(10**100,None); cross=0; examples=[]
for k in range(10):
 for r in range(9):
  for x in range(3,151):
   a,b=ext(x,k,r),ext(x,k,r+1)
   if a and b:
    checks+=1
    gap=a[0]-b[1]
    if gap<=0:fail.append((x,k,r,a,b))
    if gap<tight[0]:tight=(gap,(x,k,r,a,b))
    if b[1]>b[0] and a[1]>a[0]:cross+=1
    if len(examples)<5 and b[1]>b[0] and a[1]>a[0]:examples.append((x,k,r,a,b,gap))
print({'checks':checks,'failures':len(fail),'smallest_gap':tight,'both_multi':cross,'examples':examples,'cache':ext.cache_info()})
