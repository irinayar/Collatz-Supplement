"""Bounded parity-cylinder test of a necessary reduction for Claude's conjecture."""
def T(x): return x//2 if x%2==0 else (3*x+1)//2
for j in range(1,13):
    branches=[]
    for r in range(1,(1<<j)+1):
        x=r;a=0
        for _ in range(j):
            a+=x&1;x=T(x)
        branches.append((r,a,x))
    by_count={a:[] for a in range(j+1)}
    for r,a,b in branches:by_count[a].append(b)
    tested=0
    for r,a,b in branches:
        if a+2>j:continue
        high=any((d-b)%(3**a)==0 for c in range(a+2,j+1) for d in by_count[c])
        if high:
            tested+=1
            assert any((d-b)%(3**a)==0 for d in by_count[a+1]),(j,r,a,b)
    print('depth',j,'high-odd-count branches with a compatible lower-count branch',tested,'violations 0')
