from fractions import Fraction
from itertools import product
from collections import Counter

def F(u):
 z=3*u+1; e=(z&-z).bit_length()-1
 return z>>e,e

def params(word):
 U=E=0
 for e in word:
  U=3*U+(1<<E); E+=e
 return E,U

allowed={(1,1,1,1,4),(1,1,1,2,3),(1,1,1,3,2),(1,1,2,1,3),(1,1,2,2,2),(1,2,1,1,3),(1,2,1,2,2)}
for word in sorted(allowed):
 E,U=params(word)
 assert E==8
 residue=next(u for u in range(1,513,2) if tuple(iter_word(u,5))==word) if False else None
 def replay(u):
  out=[]
  for _ in range(5):
   u,e=F(u);out.append(e)
  return tuple(out)
 residue=next(u for u in range(1,513,2) if replay(u)==word)
 print(word,'U=',U,'u mod 512=',residue,'rho=1+',Fraction(U+65,243),'/(u+5)')

counts=Counter()
for n in range(3,3002,2):
 H=(4*n-2)//3
 for u in range(n,H+1,2):
  x=u; word=[]; good=True
  for j in range(5):
   x,e=F(x);word.append(e)
   if j<4 and x<=H:good=False;break
  if good and n<=x<=H:
   assert tuple(word) in allowed
   E,U=params(word)
   assert (1<<E)*x==243*u+U
   rho=Fraction((1<<E)*(x+5),243*(u+5))
   assert rho==1+Fraction(U+65,243*(u+5))
   counts[tuple(word)]+=1
print('exact five-return controls',sum(counts.values()),'by word',dict(counts))
