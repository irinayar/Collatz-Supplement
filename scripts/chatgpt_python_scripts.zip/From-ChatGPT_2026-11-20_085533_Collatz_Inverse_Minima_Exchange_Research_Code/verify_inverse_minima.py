"""Exact finite experiment: inverse Collatz minima by odd-edge count."""
from fractions import Fraction

def check(max_y=300, max_depth=17):
    comparisons=0
    worst=(Fraction(0), None)
    largest=0
    for y in range(1,max_y+1):
        states={(y,0)}
        for j in range(1,max_depth+1):
            nxt={(2*x,b) for x,b in states}
            nxt.update(((2*x-1)//3,b+1) for x,b in states if x%3==2)
            states=nxt
            largest=max(largest,len(states))
            minima={}
            for x,b in states:
                minima[b]=min(minima.get(b,x),x)
            levels=sorted(minima)
            assert levels==list(range(levels[-1]+1)),(y,j,levels)
            for b in levels[:-1]:
                comparisons+=1
                if not minima[b+1]<minima[b]:
                    raise AssertionError((y,j,b,minima[b],minima[b+1]))
                ratio=Fraction(minima[b+1],minima[b])
                if ratio>worst[0]:worst=(ratio,(y,j,b,minima[b],minima[b+1]))
    print('endpoints',max_y,'depths',max_depth,'comparisons',comparisons)
    print('largest inverse fibre',largest)
    print('largest adjacent-minimum ratio',worst)
    print('PASS: no violations; finite evidence only')

if __name__=='__main__':check()
