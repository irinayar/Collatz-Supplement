from fractions import Fraction
q=Fraction(124659,131200)
assert q<1
assert q/(1-q)==Fraction(124659,6541)

def next_run(u):
 s=0;t=u
 while t%2:
  t=(3*t+1)//2;s+=1
 e=0
 while t%2==0:
  t//=2;e+=1
 return t,s,e

checked=0;eligible=0;maxratio=Fraction(0)
for u in range(4097,100002,2):
 v,s,e=next_run(u)
 if v<u and s<=5 and v>=4097:
  eligible+=1
  assert Fraction(v,u)<q,(u,v,s,e)
  maxratio=max(maxratio,Fraction(v,u))
 checked+=1
print('odd starts',checked,'eligible descending high edges',eligible,'largest ratio',str(maxratio),'q',str(q))
# exact rational majorant exp(t) <= 1/(1-t), t<1
z=Fraction(124659,6541*4097)
assert z<1
print('exponent',str(z),'elementary rational upper bound',str(1/(1-z)))
assert 1/(1-z)<Fraction(1005,1000)
