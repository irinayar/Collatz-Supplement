#!/usr/bin/env python3
"""Exact audit of K176--K179 and a sharper aggregate count tail.

Standard library only. The finite pair tree has a fixed depth of 15.
No trajectory census or external source files are required.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Assertions must remain enabled.")

HERE = Path(__file__).resolve().parent
R = (1, 2)
SINGLE = (2,)
A2 = R * 2 + SINGLE
A3 = R * 3 + SINGLE
PAIRS = (A2 + A3, A3 + A2)
A = 3**12
D = 2**19
OFFSETS = (1662005, 1568693)
KMAX = F(1669158, 7153)
B0 = F(3000, 2797)
A0 = F(8850, 170617)
TARGET = F(327, 3904)
SIGNED_TARGET = F(116073, 3904000)
NEGATIVE_COUNT_COEFFICIENT = F(1837125, 1364936)


def affine(word):
    p, q, d = 1, 0, 1
    for exponent in word:
        p, q, d = 3*p, 3*q+d, d*(1 << exponent)
    return p, q, d


def odd_source(word):
    p, q, d = affine(word)
    return (d-q)*pow(p, -1, 2*d) % (2*d)


def replay(start, word):
    x = start
    assert x > 0 and x % 2
    for exponent in word:
        y = 3*x+1
        assert (y & -y).bit_length()-1 == exponent
        x = y >> exponent
        assert x > 0 and x % 2
    p, q, d = affine(word)
    assert d*x == p*start+q
    return x


def recovery_checks():
    controls = []
    cases = (
        (3, F(3,4), F(3906,139)),
        (4, F(3,4), F(44370,3299)),
        (9, F(3,8), F(4557649698,88519643)),
        (5, F(9,16), F(1419174,7153)),
        (6, F(9,16), F(14542038,588665)),
    )
    for length, rho, expected in cases:
        t0 = F(9,8)**length
        assert rho*t0 > 1
        coefficient = 6*(t0-1)/(t0-1/rho)
        assert coefficient == expected
        controls.append({"recovery_runs":length, "rho":str(rho),
                         "coefficient":str(coefficient), "fits_56":coefficient<=56})
    assert 4*cases[1][2] < 56
    return controls


def reverse_checks():
    controls = []
    for length, coefficient, cutoff, expected_map, expected_residue, expected_poly in (
        (1, 4, 107, (27,23,32), 43, (18,-1676,-1150)),
        (2, 24, 1915, (243,319,256), 379, (486,-750084,-813450)),
    ):
        aa, dd = 9**length, 8**length
        bb = 5*(aa-dd)
        p, q, denominator = affine(R*length+SINGLE)
        assert (p,q,denominator) == expected_map
        residue = odd_source(R*length+SINGLE)
        assert residue == expected_residue
        poly = (
            coefficient*(denominator-p)*aa-6*(aa-dd)*p,
            coefficient*((denominator-p)*bb-q*aa)-6*((aa-dd)*q+bb*p),
            -(coefficient+6)*q*bb,
        )
        assert poly == expected_poly
        shifted = (poly[0], 2*poly[0]*cutoff+poly[1],
                   poly[0]*cutoff**2+poly[1]*cutoff+poly[2])
        assert all(x > 0 for x in shifted)
        assert cutoff % (2*denominator) == residue
        previous = cutoff-2*denominator
        assert poly[0]*previous**2+poly[1]*previous+poly[2] < 0
        for source in (residue, cutoff, cutoff+2*denominator):
            replay(source, R*length+SINGLE)
        controls.append({"recovery_runs":length, "map":[p,q,denominator],
                         "residue":residue, "modulus":2*denominator,
                         "cutoff":cutoff, "polynomial":list(poly),
                         "shifted_polynomial":list(shifted)})
    return controls


def mixed_pair_checks():
    rows = []
    for pair, expected_offset, expected_c in zip(
        PAIRS, OFFSETS, (F(185462,59049), F(175094,59049))
    ):
        assert affine(pair) == (A,expected_offset,D)
        p, d, start, c0, positive_runs = 1, 1, 0, F(0), 0
        for end, exponent in enumerate(pair, 1):
            if exponent < 2:
                continue
            run = pair[start:end]
            if len(run) == 2:
                assert run == R
                c0 += F(2,3)*d/p
                positive_runs += 1
            else:
                assert run == SINGLE
            p *= 3**len(run)
            d *= 1 << sum(run)
            start = end
        assert positive_runs == 5 and c0 == expected_c
        coefficient = c0*A/(A-D)
        assert coefficient <= KMAX
        repeats = []
        for copies in range(1,13):
            word = pair*copies
            residue = odd_source(word)
            defect_residue = -expected_offset*pow(A-D,-1,2*D**copies) % (2*D**copies)
            assert residue == defect_residue
            final = replay(residue,word)
            defect = (A-D)*residue+expected_offset
            assert defect > 0 and defect % (2*D**copies) == 0
            assert (A-D)*residue >= 2*D**copies-expected_offset
            assert final > residue
            repeats.append({"copies":copies,"source":str(residue)})
        rows.append({"offset":expected_offset,"C0":str(c0),
                     "flux_coefficient":str(coefficient),"repetition_controls":repeats})
    return rows


def pair_tree():
    states = [(0,0)]
    minima = []
    nonroot_nodes = 0
    inverses = {depth:pow(A,-1,2*D**depth) for depth in range(1,16)}
    final_rows = None
    for depth in range(1,16):
        states = [(A*u+D**(depth-1)*offset,mask | (bit << (depth-1)))
                  for u,mask in states for bit,offset in enumerate(OFFSETS)]
        modulus = 2*D**depth
        inverse_power = pow(A**depth,-1,modulus)
        rows = [((D**depth-u)*inverse_power % modulus,mask) for u,mask in states]
        assert all(residue > 0 and residue%2 for residue,_ in rows)
        assert len({residue for residue,_ in rows}) == len(rows)
        residue,mask = min(rows)
        word = tuple(e for index in range(depth) for e in PAIRS[(mask >> index)&1])
        assert odd_source(word) == residue
        replay(residue,word)
        minima.append({"depth":depth,"nodes":len(rows),"minimum_source":str(residue),"mask":mask})
        nonroot_nodes += len(rows)
        final_rows = rows
    assert nonroot_nodes == 65534
    assert len(final_rows) == 32768
    for residue,mask in final_rows:
        x = 1
        for step,index in enumerate(range(14,-1,-1),1):
            offset = OFFSETS[(mask >> index)&1]
            x = (D*x-offset)*inverses[step] % (2*D**step)
        assert x == residue
    last = minima[-1]
    m15 = int(last["minimum_source"])
    assert m15 == 7631510170755948127862786147500572769390316906790491185139757695856112765430029307
    assert last["mask"] == 25847
    assert 3*56*m15 >= KMAX*(4*((1 << 256)-1)+1)
    assert F(10,3)*14 < 56
    sorted_residues = b"\n".join(str(r).encode() for r,_ in sorted(final_rows))
    return {"nonroot_nodes":nonroot_nodes,"leaves":len(final_rows),
            "all_leaf_backward_compositions_checked":True,"depth_minima":minima,
            "sorted_leaf_residues_sha256":sha256(sorted_residues).hexdigest(),
            "finite_range_affordability_verified":True}


def tail_checks():
    assert 3000**22 < 1 << 256
    old_tail = F(2,16125)
    new_tail = F(1,10749)
    n0 = 1 << 256
    # 96/(258*3000) * 3n/(4n-1) < 1/10749
    # is equivalent to 2n>5375 and holds for every n>=n0.
    assert 2*n0 > 5375
    assert old_tail*F(3*n0,4*n0-1) < new_tail < old_tail
    old_cost = B0*KMAX*old_tail+A0
    assert old_cost == F(4351172358,52478206243)
    assert TARGET-old_cost == F(2842566489,3358605199552)
    new_cost = B0*KMAX*new_tail+A0
    assert new_cost < old_cost < TARGET
    assert B0*SIGNED_TARGET+A0 == TARGET
    ordinary_mean_budget = SIGNED_TARGET/new_tail
    credited_mean_budget = ordinary_mean_budget+NEGATIVE_COUNT_COEFFICIENT/B0
    assert ordinary_mean_budget > 319 and credited_mean_budget > 320
    # A larger restricted chronological cover paid throughout the analytic tail:
    # one arbitrary-order pair group and two K176 three-recovery groups.
    three_group_fee = KMAX+2*F(3906,139)
    assert B0*three_group_fee*new_tail+A0 < TARGET
    return {"old_count_ratio":str(old_tail),"improved_count_ratio":str(new_tail),
            "old_Kmax_sector_cost":str(old_cost),"new_Kmax_sector_cost":str(new_cost),
            "new_Kmax_sector_slack":str(TARGET-new_cost),
            "ordinary_normalized_mean_sufficient_budget":str(ordinary_mean_budget),
            "credited_normalized_mean_sufficient_budget":str(credited_mean_budget),
            "one_pair_group_plus_two_recovery_groups_fee":str(three_group_fee),
            "three_group_tail_sector_cost":str(B0*three_group_fee*new_tail+A0),
            "aggregate_mean_inequality_itself_proved":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=HERE/"ten_note_pair_audit_certificate.json")
    args = parser.parse_args()
    result = {"status":"PASS","recovery_controls":recovery_checks(),
              "reverse_polynomials":reverse_checks(),"mixed_pair_controls":mixed_pair_checks(),
              "aperiodic_tree":pair_tree(),"count_tail":tail_checks(),
              "scope":{"K176_through_K179_restricted_algebra_checked":True,
                       "finite_15_pair_certificate_reproduced":True,
                       "large_reported_censuses_or_phase_DP_rerun":False,
                       "global_source_count_and_complement_theorems_imported":True,
                       "actual_unrestricted_aggregate_bound_proved":False}}
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":"PASS","pair_tree_nodes":65534,"pair_tree_leaves":32768,
                      "improved_count_tail":"1/10749",
                      "credited_mean_sufficient_budget":result["count_tail"]["credited_normalized_mean_sufficient_budget"],
                      "unrestricted_aggregate_bound_proved":False}))


if __name__ == "__main__":
    main()
