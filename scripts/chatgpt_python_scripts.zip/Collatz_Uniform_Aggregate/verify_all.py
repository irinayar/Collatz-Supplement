#!/usr/bin/env python3
"""Reproduce the three new exact aggregate-research certificates.

Python 3.10+, standard library only. All checks work from an extracted archive.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

if not __debug__:
    raise RuntimeError("Assertions must remain enabled; do not use -O or -OO.")

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "aggregate_uniform_work"
TASKS = (
    ("verify_uniform_long_run_tail.py", "uniform_long_run_tail_certificate.json"),
    ("verify_ten_note_pair_audit.py", "ten_note_pair_audit_certificate.json"),
    ("verify_endpoint_potential_obstruction.py", "endpoint_potential_obstruction_certificate.json"),
)


def check_payload():
    manifest = json.loads((ROOT / "release_manifest.json").read_text())
    for name, expected in manifest["files"].items():
        path = ROOT / name
        assert path.is_file(), f"Missing payload: {name}"
        data = path.read_bytes()
        assert len(data) == expected["bytes"], name
        assert sha256(data).hexdigest() == expected["sha256"], name
    return len(manifest["files"])


def check_provenance():
    archive = ROOT / "previous_release" / "Collatz_Aggregate_Compensation.zip"
    expected_hash = "e9188fe9584e498aa51d5bdb9c5388d83b678962eb52f39940c5e0855d65169c"
    assert sha256(archive.read_bytes()).hexdigest() == expected_hash
    audit = json.loads((WORK / "ten_note_pair_audit_provenance.json").read_text())
    for entry in audit["inputs"]:
        data = (ROOT / "incoming_notes" / Path(entry["file"]).name).read_bytes()
        assert sha256(data).hexdigest() == entry["sha256"]
    assert len(audit["inputs"]) == 10
    for name, expected in audit["artifacts"].items():
        assert sha256((WORK / name).read_bytes()).hexdigest() == expected
    with ZipFile(archive) as outer:
        assert outer.testzip() is None
        context = outer.read("aggregate_compensation_work/Global_Signed_Compensation.md")
        assert sha256(context).hexdigest() == audit["context"]["sha256"]
        with ZipFile(BytesIO(outer.read("previous_release/Collatz_Research.zip"))) as older:
            count_import = older.read("span_residue_work/Audit_Count_and_Reset_Support.md")
    review = json.loads((WORK / "long_run_tail_proof_review.json").read_text())
    assert review["status"] == "ACCEPTED_PROOF_REVIEW"
    for entry in review["files"]:
        if entry["file"].startswith("aggregate_uniform_work/"):
            data = (WORK / Path(entry["file"]).name).read_bytes()
        else:
            assert entry["file"] == "span_residue_work/Audit_Count_and_Reset_Support.md"
            data = count_import
        assert sha256(data).hexdigest() == entry["sha256"]
    return {
        "previous_archive_sha256": expected_hash,
        "ten_incoming_notes_unchanged": True,
        "signed_framework_and_count_import_hashes_verified": True,
        "independent_long_tail_review_hashes_verified": True,
        "previous_release_verifiers_rerun": False,
    }


def run_one(task, temporary):
    script, certificate = task
    destination = temporary / certificate
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, str(WORK / script), "--output", str(destination)],
        cwd=ROOT, env=environment, capture_output=True, text=True, timeout=600,
    )
    if result.returncode:
        raise RuntimeError(f"{script} failed:\n{result.stdout}\n{result.stderr}")
    data = destination.read_bytes()
    assert data == (WORK / certificate).read_bytes(), certificate
    summary = json.loads(result.stdout)
    assert summary["status"] == "PASS"
    print(f"PASS {script}: certificate reproduced byte for byte", flush=True)
    return {"script": script, "certificate": certificate,
            "certificate_sha256": sha256(data).hexdigest(),
            "byte_identical": True, "summary": summary}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "uniform_aggregate_verification.json")
    arguments = parser.parse_args()
    count = check_payload()
    provenance = check_provenance()
    epsilon = F(17,327680)
    increment = F(488,375)*F(3000,2797)*epsilon
    assert increment == F(1037,14320640) < F(1,10000)
    residual = F(116073,3904000)-epsilon
    assert residual > 0
    with tempfile.TemporaryDirectory(prefix="collatz-uniform-") as directory:
        temporary = Path(directory)
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(run_one, task, temporary) for task in TASKS]
            checks = [future.result() for future in futures]
    report = {
        "status": "PASS", "payload_files_checked": count,
        "checks": checks, "provenance": provenance,
        "exact_budgets": {"K16_signed_tail": str(epsilon),
                          "K16_original_charge_increment": str(increment),
                          "remaining_sufficient_Z_threshold_before_P_over_n_credit": str(residual)},
        "scope": {"uniform_actual_long_run_aggregate_tail_proved": True,
                  "all_original_source_multiplicities_retained": True,
                  "all_existing_negative_credits_retained": True,
                  "imported_global_theorems_newly_formalized": False,
                  "large_external_censuses_or_phase_DP_rerun": False,
                  "full_unweighted_aggregate_bound_proved": False,
                  "unrestricted_21_over_125_bound_proved": False},
    }
    arguments.output.write_text(json.dumps(report, indent=2)+"\n")
    print("PASS all three checks; full unweighted aggregate remains unproved.")


if __name__ == "__main__":
    main()
