from functools import lru_cache
from collections import Counter

def T(n): return n//2 if n%2==0 else (3*n+1)//2
@lru_cache(None)
def H(j,y):
    if j==0: return 0
    a=H(j-1,2*y)
    if y%3==2:
        a=max(a,1+H(j-1,(2*y-1)//3))
    return a

for j in range(1,9):
    p=3**j
    vals=[H(j,y) for y in range(1,p+1)]
    assert all(H(j,y)==H(j,y+p) for y in range(1,min(p,1000)+1))
    assert [y for y in range(1,p+1) if H(j,y)==j]==[p-1]
    print('depth',j,'period',p,'counts',sorted(Counter(vals).items()))

for n in range(1,251):
    y=n;a=0;last=0
    for j in range(1,18):
        a+=y%2;y=T(y)
        d=H(j,y)-a
        assert d>=last,(n,j,d,last)
        last=d
print('surplus monotonic checked 250 starts 17 depths')
