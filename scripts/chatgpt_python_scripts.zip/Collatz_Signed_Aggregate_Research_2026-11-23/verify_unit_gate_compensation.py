#!/usr/bin/env python3
"""Exact unit-phase entry and retained-credit checks, Python standard library.

The proof is in Unit_Phase_Entry_and_Retained_Credits.md. These checks certify
the arithmetic entry capacity and exact controls, not a global signed bound.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def encode(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {str(k): encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [encode(v) for v in x]
    return x


def full_run(a):
    s = v2(a + 1)
    odd_part = (a + 1) >> s
    even_output = 3**s * odd_part - 1
    e = v2(even_output) + 1
    b = even_output >> (e - 1)
    beta = 1 - F(2, 3)**s
    lam = F(2**(s + e - 1), 3**s)
    assert b == (a + beta) / lam
    return s, e, b, beta, lam


def inspect_prefix(n, u):
    H = (4*n - 2)//3
    assert n % 2 and u % 2 and n <= u <= H
    a = u
    q, lam = F(0), F(1)
    g = E = 0
    runs = []
    for k in range(1, 4):
        s, e, b, beta, lr = full_run(a)
        delta = beta/a
        credit = max(F(0), F(1, b)-F(1, a)-delta/15)
        runs.append({"a": a, "b": b, "s": s, "e": e,
                     "delta": delta, "beta": beta, "credit": credit})
        q += lam*beta
        lam *= lr
        g += s
        E += s+e-1
        assert lam*b == u+q
        if b <= H:
            return {"kind": "returned_before_proper_unit_gate", "k": k}
        if q > 1:
            assert k in (2, 3) and 1 < q < 2
            assert g >= 4
            assert n+1 < F(2**E*b, 3**g) < H+2
            assert 3*(H+2) <= 4*(n+1)
            if k == 3:
                assert runs[0]["e"] == 2 and runs[1]["s"] == 1
                a2 = runs[1]["b"]
                gamma = F(14*a2-15, 15*(4*a2-1))
                c2 = runs[1]["credit"]
                assert c2 >= gamma/a2
                sigma = F(14*n-15, 16*(4*n-1))
                assert sum((r["credit"] for r in runs), F(0)) > sigma/b
                if n >= 11:
                    assert sigma > F(1, 5)
            D = sum((r["delta"] for r in runs), F(0))
            beta_sum = sum((r["beta"] for r in runs), F(0))
            C = sum((r["credit"] for r in runs), F(0))
            assert D < 2/F(u)
            lower = max(F(0), F(1,b)-D*(F(1,15)+1/beta_sum))
            assert C >= lower
            # Wholly integer, slightly coarser height/depth controls.
            ceil_log = H.bit_length()
            assert (1 << ceil_log) >= H+1
            assert g <= (13*ceil_log+4)//5
            assert b+1 < (H+1)**3
            if H+1 >= 16:
                assert E < 5*ceil_log
            return {"kind": "proper_unit_gate", "k": k, "g": g, "E": E,
                    "source": u, "gate": b, "q": q,
                    "credit": C, "beta_sum": beta_sum,
                    "prefix_delta": D, "generic_credit_lower": lower}
        a = b
    raise AssertionError("Three complete runs survived without a unit gate.")


def circle_certificate(N=702):
    p3 = [3**j for j in range(N)]
    p2 = [1 << (x.bit_length()-1) for x in p3]
    points = sorted((F(p3[j], p2[j]), j) for j in range(N))
    ext = points + [(2*x, j) for x, j in points]
    counts, exclusions = [], []
    right = 0
    for left in range(N):
        right = max(right, left)
        while right < left+N and 3*ext[right][0] < 4*ext[left][0]:
            right += 1
        counts.append(right-left)
        assert right-left <= 292
        if left+292 < left+N:
            ratio = ext[left+292][0]/ext[left][0]
            assert ratio >= F(4, 3)
            exclusions.append([ext[left][1], ext[left+292][1], str(ratio)])
    # An independent exact integer count, without using the circular order.
    independent = []
    for i in range(N):
        number = 0
        for j in range(N):
            num, den = p3[j]*p2[i], p3[i]*p2[j]
            if num < den:
                num *= 2
            if 3*num < 4*den:
                number += 1
        independent.append(number)
    assert [independent[j] for _, j in points] == counts
    assert max(counts) == 292
    return {"depth_count": N, "open_capacity": 292,
            "sorted_depth_offsets": [j for _, j in points],
            "counts_by_sorted_start": counts,
            "independent_counts_by_depth_offset": independent,
            "exclusion_of_293_points": exclusions,
            "scope": "arithmetic arc relaxation; simultaneous actual attainment not asserted"}


def reset_shell_certificate():
    """Exact arithmetic controls for the analytic phase-delay/shell proof."""
    n0 = 2**71+1
    H0 = (4*n0-2)//3
    d = F(1,H0+1)
    bound = F(2)
    for _ in range(3):
        bound += F(H0+bound,H0+1)
    assert bound == 5+6*d+4*d*d+d*d*d < 5+7*d
    # Uniform analytic step: n>700000 and Pstar<=H imply 7/(H+1)<B-5.
    assert n0 > 700000 and H0+1 >= 5
    assert 700000*H0 < n0*(H0+1)

    def threshold(v):
        return F(2**v,(v+1)*(v+2))

    assert [threshold(v) for v in range(5)] == [F(1,2),F(1,3),F(1,3),F(2,5),F(8,15)]
    for v in range(2,65):
        assert threshold(v+1)/threshold(v) == F(2*(v+1),v+3) > 1

    def closed_series(x):
        if x <= F(1,3): return 2*x
        if x <= F(2,5): return F(5,4)*x
        if x <= F(1,2): return F(9,8)*x
        v0 = 4
        while threshold(v0) < x:
            v0 += 1
        return x*F(1,2**(v0-1))

    breakpoints = sorted({threshold(v) for v in range(41)})
    samples = {F(1,10),*breakpoints}
    samples.update((a+b)/2 for a,b in zip(breakpoints,breakpoints[1:]))
    rows = []
    for x in sorted(samples):
        # Independent direct shell sum plus its exact infinite tail.
        assert x < threshold(64)
        shell_sum = sum((F(1,2**v) for v in range(64) if x <= threshold(v)),F(0))
        shell_sum += F(1,2**63)
        direct = x*shell_sum
        assert direct == closed_series(x) <= F(2,3)
        rows.append({"x":x,"F":direct})
    assert closed_series(F(1,3)) == F(2,3)
    reset = F(2,3)/6000
    total = reset+F(879,2000000)
    assert reset == F(1,9000)
    assert total == F(9911,18000000)
    return {"n0":n0,"six_run_phase_upper":bound,
            "imported_prescribed_source_property":"Pstar<=H, current manuscript II immediately before K184",
            "minimum_lost_mark_J":6,
            "eligible_shell_scale":12000,
            "shell_series_supremum":F(2,3),
            "reset_error_strict_upper":reset,
            "four_bin_total_error_strict_upper":total,
            "direct_series_controls":rows,
            "scope":"Exact controls supplement the all-x piecewise proof; not an aggregate residual bound"}


def saved_core_controls():
    path = HERE/"fixture/verify_nonempty_core_coalescence.py"
    spec = importlib.util.spec_from_file_location("source_fixture", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    data = json.loads((HERE/"fixture/original_core_profile.json").read_text())
    n = int(data["n"])
    P = 8780738570161207464047659560356896525
    assert module.sc.source_count(n)[0] == P
    assert P <= (4*n-2)//3
    second = 473569587534005792343618380642931659580735
    controls = []
    for u, word in ((int(data["u"]), data["word"]),
                    (second, [1,1,1,1,1,3,1,3]+data["word"][1:])):
        profile = module.replay(n, u, word, P)
        runs = profile["runs"]
        crossing = next(i for i,r in enumerate(runs) if r["phase"] <= 1 < r["phase_end"])
        k = crossing+1
        gate_depth = runs[crossing]["end_odd"]
        E_gate = sum(word[:gate_depth])
        y = runs[crossing]["b"]
        q_gate = runs[crossing]["phase_end"]
        lam = F(2**E_gate, 3**gate_depth)
        assert k in (2,3) and y>profile["H"] and 1<q_gate<2
        assert all(not r["core"] for r in runs[:k])
        pre_credit = sum((r["c"] for r in runs[:k]), F(0))
        original_suffix = aligned_suffix = F(0)
        changes = []
        L = n.bit_length()-1
        for j,r in enumerate(runs[k:]):
            a = r["a"];ell = a.bit_length()-1;v = ell-L
            J = 2**ell//(2000*P*(v+1)*(v+2))
            # Source-independent tests read from the exact original replay.
            # Isolate only the early-reset predicate, keeping all others.
            incoming = r["phase"] > profile["B"]
            remaining = profile["Q"]-r["phase"] > profile["B"]
            assert r["phase"] == q_gate+lam*((r["phase"]-q_gate)/lam)
            # Reconstruct the original canonical endpoint directly.
            start_time=sum(word[:r["start_odd"]])
            shortcut=[u];x=u
            for e in word:
                x=(3*x+1)//2;shortcut.append(x)
                for _ in range(e-1):
                    x//=2;shortcut.append(x)
            at=start_time+ell
            base=(r["start_odd"]>0 and profile["H"]<a<2**(64*n.bit_length())
                  and at<profile["E"] and 64*shortcut[at]>a
                  and len(runs)-k-j>J)
            mark=base and incoming and remaining and k+j>J
            aligned=base and incoming and remaining and 2+j>J
            assert mark==r["core"]
            h=r["t"]+r["c"]
            assert h>0
            original_suffix += -r["c"]+h*mark
            aligned_suffix += -r["c"]+h*aligned
            if mark and not aligned:
                assert k==3 and j==J-2 and J>=6
                assert 2**ell>=12000*P*(v+1)*(v+2)
                changes.append((ell,j,h))
        assert len({ell for ell,j,h in changes})==len(changes)
        reset_error=original_suffix-aligned_suffix
        assert reset_error==sum((h for ell,j,h in changes), F(0))
        assert 0<=reset_error<F(1,9000*P)
        exact_score=-pre_credit+original_suffix
        assert exact_score==profile["signed_score"]
        controls.append({"source":u,"unit_gate_k":k,"unit_gate_odd_depth":gate_depth,
                         "unit_gate":y,"unit_gate_phase":q_gate,
                         "original_core_count":profile["core_count"],
                         "n_scaled_original_signed_score":n*exact_score,
                         "unit_prefix_credit":pre_credit,
                         "reset_alignment_error":reset_error})
    return controls


def main():
    if not __debug__:
        raise SystemExit("Run without -O or -OO; exact assertions must be active.")
    assert 3**5<2**8
    assert 3**63<2**100
    c=F(100,63)
    entry_bound=275+273*c-c*c
    assert entry_bound==F(2801375,3969)<706
    assert 7/F(32)-F(23,32*(4*11-1))==F(14*11-15,16*(4*11-1))>F(1,5)
    populations=Counter();examples={}
    for n in range(3,502,2):
        H=(4*n-2)//3
        for u in range(n,H+1,2):
            p=inspect_prefix(n,u)
            populations[(p["kind"],p["k"])]+=1
            if p["kind"]=="proper_unit_gate":
                examples.setdefault(p["k"],{"n":n,**p})
    # A high-floor actual three-run prefix. No future completion is assumed.
    word=[1,1,2,2,1,2]
    E=g=C=0
    for e in word:
        C=3*C+2**E;E+=e;g+=1
    M=2**(E+1)
    residue=((2**E-C)*pow(3**g,-1,M))%M
    u=2**80+residue
    n=(9*u//10)|1
    high=inspect_prefix(n,u)
    assert high["kind"]=="proper_unit_gate" and high["k"]==3
    assert high["credit"]>F(1,5*high["gate"])
    result={"status":"PASS","scope":"bounded unit-phase entry, mandatory prefix credit and retained masks; not unrestricted suffix summability",
            "entry_bound_for_n_below_2pow272":str(entry_bound),
            "actual_odd_depth_range":[4,705],
            "finite_prefix_controls":{str(k):v for k,v in populations.items()},
            "small_actual_examples":examples,"high_floor_three_run_prefix":high,
            "arc_certificate":circle_certificate(),
            "reset_shell_certificate":reset_shell_certificate(),
            "original_nonempty_core_controls":saved_core_controls(),
            "global_signed_bound_proved":False,
            "source_files":[{"path":str(p.relative_to(HERE)),
                             "sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
                            for p in sorted((HERE/"fixture").glob("*")) if p.is_file()]}
    (HERE/"unit_gate_compensation_certificate.json").write_text(json.dumps(encode(result),indent=2)+"\n")
    print("PASS: first proper unit gate has two or three complete runs.")
    print("PASS: all fixed gate multiplicities <=292 in the stated threshold range.")
    print("PASS: high-floor three-run gate earns >1/(5y) original prefix credit.")
    print("PASS: retained dyadic shells give reset error <1/9000 and four-bin total <9911/18000000.")
    print("PASS: both nonempty-core fixtures retain their original scores and masks.")
    print("The all-gate, all-future signed aggregate remains unbounded by this proof.")


if __name__=="__main__":
    main()
