#!/usr/bin/env python3
"""Exact source-preserving reciprocal phase-bin checks.

The uniform error theorem is proved in Reciprocal_Phase_Bins.md.
This script checks constants and actual unchanged-core profile controls.
It does not prove the remaining common-cut aggregate or global convergence.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("original_replay",HERE/"original_replay.py")
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)


def enc(value):
    if isinstance(value,F):return str(value)
    if isinstance(value,dict):return {str(k):enc(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [enc(v) for v in value]
    return value


def exact_bin(profile, bins):
    n,H,B=profile['n'],profile['H'],profile['B']
    omega=(H+B)/(H+1)
    gate=profile['gate_odd_depth'];y=profile['gate_state']
    crossing=next(r for r in profile['runs'] if r['end_odd']==gate)
    q=crossing['phase_end'];sigma=profile['u']+q
    E=sum(profile['word'][:gate])
    assert sigma==F(2**E*y,3**gate)
    assert n+B<sigma<H+B+omega
    top=1/(n+B);delta=top-1/(H+B+omega)
    rank=(top-1/sigma)*bins/delta
    j=rank.numerator//rank.denominator
    assert 0<=j<bins
    low=1/(top-F(j,bins)*delta)
    high=1/(top-F(j+1,bins)*delta)
    assert low<=sigma<high
    suffix=[r for r in profile['runs'] if r['start_odd']>=gate]
    phase_intervals=[]
    for r in suffix:
        D=F(y,1)*(profile['Q']-r['phase'])/sigma
        if F(B*y,sigma)<D<=F(B*y,low):
            phase_intervals.append(r['ordinal'])
    last=phase_intervals[-1] if phase_intervals else None
    selected=last if last is not None and profile['runs'][last]['core'] else None
    comparison=F(0);boundary=F(0);error=F(0)
    core=0;retained_credits=0;comparison_core=0
    for r in profile['runs']:
        actual=r['core'];core+=actual
        if r['start_odd']<gate:
            I0=False
        else:
            D=F(y,1)*(profile['Q']-r['phase'])/sigma
            common_phase=low*D>B*y
            # Since the common test implies the original remaining-phase
            # test, intersecting with original core is exactly equivalent
            # to keeping every original other predicate.
            I0=actual and common_phase
            assert not I0 or actual
        if r['ordinal']==selected:
            assert actual and not I0
            boundary+=r['t']
        else:
            comparison+=r['t'] if I0 else -r['c']
            if not I0:retained_credits+=1
            comparison_core+=I0
            error+=(r['t']+r['c'])*(int(actual)-int(I0))
        assert 0<r['t']+r['c']<2*r['delta']
    assert profile['signed_score']==comparison+boundary+error
    exact_error_cap=2*B*(1/low-1/sigma)
    bin_error_cap=2*B*delta/bins
    assert 0<=error<=exact_error_cap<=bin_error_cap
    return {
        'source':str(profile['u']),'gate_state':str(y),
        'incoming_odd_depth':gate,'incoming_exponent':E,'sigma':sigma,
        'bin':j,'bins':bins,'lower_sigma':low,'upper_sigma':high,
        'core_count':core,'comparison_core_count':comparison_core,
        'selected_boundary_ordinal':selected,
        'selected_boundary_type':None if selected is None else
           [profile['runs'][selected]['s'],profile['runs'][selected]['e']],
        'comparison_score':comparison,'boundary_score':boundary,
        'error':error,'exact_error_cap':exact_error_cap,
        'bin_error_cap':bin_error_cap,'n_scaled_error':n*error,
        'credits_or_zero_baselines_retained':retained_credits}


def constant_check():
    c=F(620751769493359576,1180591620717411303425)
    n0=2**71+1
    C=(5*c*(F(4,3)+F(1,3*n0))+F(1,100000))*(F(1,2)+F(4,n0))
    assert c<F(1,1500)
    assert C<F(1758,10**6)
    assert C/2<F(879,10**6)
    assert C/4<F(879,2*10**6)
    assert C/8<F(879,4*10**6)
    # R-only h<=6 delta/5, hence 3/5 of the all-type error cap.
    r_error_two=F(3,5)*C/2
    boundary_R=F(2,3)*c
    assert r_error_two+boundary_R<F(878,10**6)
    # A crude all-type boundary bound alone exceeds the target.
    assert 2*c>F(1003,10**6)
    return {'imported_core_count_ratio':c,'n0':n0,
            'uniform_all_type_constant_exact_upper':C,
            'simple_constant':'1758/1000000',
            'error_two_bins':C/2,'error_four_bins':C/4,
            'R_only_error_and_crude_boundary_two_bins':r_error_two+boundary_R,
            'all_type_crude_boundary':2*c,
            'scope':'Uniform bin-error constant; not a bound on the common-cut score.'}


def main():
    if not __debug__:raise SystemExit("Run without -O or -OO")
    data=json.loads((HERE/'original_core_profile.json').read_text())
    n=int(data['n']);u=int(data['u'])
    P,_,_=old.sc.source_count(n)
    assert P==8780738570161207464047659560356896525
    first=old.replay(n,u,data['word'],P)
    second=old.replay(n,473569587534005792343618380642931659580735,
                     [1,1,1,1,1,3,1,3]+data['word'][1:],P)
    assert first['core_count']==31 and second['core_count']==33
    assert first['gate_state']!=second['gate_state']
    original_core={(r['a'],r['b']):r for r in first['runs'] if r['core']}
    second_core={(r['a'],r['b']):r for r in second['runs'] if r['core']}
    shared=original_core.keys()&second_core.keys()
    assert len(shared)==31
    assert sum(original_core[k]['t']>0 for k in shared)==23
    assert sum(original_core[k]['t']<0 for k in shared)==8
    assert all(original_core[k]['t']==second_core[k]['t'] and
               original_core[k]['c']==second_core[k]['c'] for k in shared)
    rows=[]
    for bins in [1,2,4,8,16,64,256]:
        actual=[exact_bin(p,bins) for p in [first,second]]
        z=sum((p['signed_score'] for p in [first,second]),F(0))
        comp=sum((r['comparison_score'] for r in actual),F(0))
        boundary=sum((r['boundary_score'] for r in actual),F(0))
        error=sum((r['error'] for r in actual),F(0))
        assert z==comp+boundary+error
        assert len([r for r in actual if r['selected_boundary_ordinal'] is not None])<=2
        rows.append({'bins':bins,'profiles':actual,'aggregate_score':z,
            'comparison_score':comp,'boundary_score':boundary,'error':error,
            'all_occurrences_retained':True})
    assert any(r['error']>0 for r in rows)
    result={'status':'PASS','constants':constant_check(),'actual_controls':rows,
        'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in [HERE/'original_replay.py',HERE/'original_source_count.py',
                                 HERE/'original_core_profile.json']},
        'new_uniform_result':'The phase-discretization error is <(1758/10^6)/J.',
        'not_proved':['The retained common-cut aggregate',
                      'An all-type boundary payment below the residual budget',
                      'Global Collatz convergence']}
    (HERE/'phase_bin_certificate.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    print(json.dumps({'status':'PASS','bin_counts':[r['bins'] for r in rows],
        'n_scaled_errors':[float(n*r['error']) for r in rows],
        'uniform_error_constant':float(result['constants']['uniform_all_type_constant_exact_upper']),
        'R_only_error_plus_boundary_two_bins':float(result['constants']['R_only_error_and_crude_boundary_two_bins']),
        'global_proof':False},indent=2))


if __name__=='__main__':main()
