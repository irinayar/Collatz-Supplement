#!/usr/bin/env python3
"""Exact controls for the aggregate-to-return-product conditional bridge.

These checks do not prove the assumed signed aggregate estimate, its original
large imported certificates, or global Collatz convergence.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent


def exp_upper(x, degree=24):
    assert 0 <= x < 1
    term = total = F(1)
    for j in range(1, degree + 1):
        term *= x / j
        total += term
    next_term = term * x / (degree + 1)
    return total + next_term / (1 - x / (degree + 2))


def word_data(word):
    exponent = numerator = 0
    for e in word:
        numerator = 3 * numerator + 2**exponent
        exponent += e
    a = 3**len(word)
    modulus = 2**(exponent + 1)
    residue = (2**exponent - numerator) * pow(a, -1, modulus) % modulus
    return a, 2**exponent, numerator, modulus, residue


def replay(source, word, threshold):
    height = (4 * threshold - 2) // 3
    x = source
    states = [x]
    product = F(1)
    for e in word:
        assert x % 2 == 1
        product *= 1 + F(1, 3*x)
        value = 3*x + 1
        assert value % (2**e) == 0 and value % (2**(e+1)) != 0
        x = value // (2**e)
        states.append(x)
    assert threshold <= source <= height
    assert threshold <= x <= height
    assert all(y > height for y in states[1:-1])
    a, d, b, modulus, residue = word_data(word)
    assert source % modulus == residue
    assert d*x == a*source+b
    rho = product * (1 + F(5, x)) / (1 + F(5, source))
    c = F(b+5*(d-a), a)
    assert rho == 1 + c / (source+5)
    assert F(x+5, source+5) == F(a,d)*rho
    return {"source": source, "endpoint": x, "states": states,
            "rho": rho, "raw_product": product, "coefficient": F(a,d),
            "word_charge_coefficient": c, "modulus": modulus,
            "residue": residue}


def encode(value):
    if isinstance(value,F): return str(value)
    if isinstance(value,dict): return {str(k):encode(v) for k,v in value.items()}
    if isinstance(value,list): return [encode(v) for v in value]
    return value


def main():
    if not __debug__:
        raise SystemExit("Run without -O or -OO; exact assertions are required.")
    y_star=F(116073,3904000)
    b0=F(3000,2797)
    a0=F(8850,170617)
    count_coefficient=F(4899,3904)
    debit=F(1837125,1364936)
    assert b0*count_coefficient==debit
    core_cap=b0*y_star+a0
    assert core_cap==F(327,3904)
    assert F(488,375)*core_cap+F(59,1000)==F(21,125)
    least_source_total=F(21,125)+F(9,125)
    assert least_source_total==F(6,25)
    occurrence_allowance=least_source_total+F(111,2500)
    assert occurrence_allowance==F(711,2500)
    exponential=exp_upper(occurrence_allowance)
    assert exponential < F(4,3)
    assert 2/exponential > F(3,2)
    assert F(3,4)*exponential < 1
    assert F(8,9)*(1+F(5,2**71)) < F(9,10)

    # Existing actual two-copy family: repeated word, distinct departure
    # integers, every input above the high floor. It is a bridge control,
    # not a new nonempty-central-core witness.
    lift=2**71
    threshold=54523+118098*lift
    source1=60511+131072*lift
    source2=57439+124416*lift
    word=[1,1,1,1,4]
    first=replay(source1,word,threshold)
    second=replay(source2,word,threshold)
    assert first["endpoint"]==source2 and second["endpoint"]==threshold
    inputs=first["states"][:-1]+second["states"][:-1]
    assert len(inputs)==len(set(inputs))
    assert first["rho"]>1 and second["rho"]>1
    positive_sum=(first["rho"]-1)+(second["rho"]-1)
    assert positive_sum>second["rho"]-1
    normalized=first["rho"]*second["rho"]
    assert normalized <= exp_upper(positive_sum)
    assert F(threshold+5,source1+5)==first["coefficient"]*second["coefficient"]*normalized
    assert word_data(word)[2]==211
    assert first["word_charge_coefficient"]==F(92,81)

    # A genuine high-floor return with a negative normalized whole-word
    # charge tests the positive-part step without deleting its actual factor.
    negative_word=[1,1,2,2]
    aa,dd,bb,modulus,residue=word_data(negative_word)
    negative_source=residue+modulus*2**71
    negative=replay(negative_source,negative_word,negative_source)
    assert 0<negative["rho"]<1
    assert negative["word_charge_coefficient"]==F(-4,27)

    result={
        "status":"PASS",
        "scope":"Exact arithmetic and actual finite controls for a conditional bridge; aggregate assumption unproved.",
        "signed_target":y_star,"count_coefficient":count_coefficient,
        "central_mass_threshold":core_cap,"complementary_positive_budget":F(21,125),
        "least_source_total_budget":least_source_total,
        "distinct_actual_source_budget":occurrence_allowance,
        "exp_budget_rational_upper":exponential,
        "exp_budget_upper_decimal_informational":float(exponential),
        "cycle_spread_conditional_lower":2/exponential,
        "cycle_spread_lower_decimal_informational":float(2/exponential),
        "completed_return_feasible_successor_fraction_upper":F(9,10),
        "two_copy_actual_family":{"threshold":threshold,"first":first,"second":second,
                                  "positive_sum":positive_sum,"normalized_product":normalized},
        "negative_whole_return_control":negative,
        "not_proved":["The full signed aggregate assumption",
                      "A forcing theorem for homogeneous coefficient deficit",
                      "An all-occurrence bound with repeated departure integers",
                      "Exclusion of nonrepeating escape",
                      "Global Collatz convergence"]}
    (HERE/"Closing_Bridge_Checks.json").write_text(json.dumps(encode(result),indent=2)+"\n")
    print(json.dumps({"status":"PASS","signed_to_positive_constants":"exact",
                     "distinct_source_budget":str(occurrence_allowance),
                     "exp_upper_below":"4/3",
                     "conditional_cycle_spread_above":"3/2",
                     "actual_controls":"two distinct departures of same positive word and one negative-charge return",
                     "global_proof":False},indent=2))


if __name__=="__main__":
    main()
