from functools import lru_cache
from collections import Counter
@lru_cache(None)
def origins(x,k,r):
 if k<0 or r<0 or x<1:return ()
 if k==r==0:return (x,)
 a=set()
 if k:a.update(origins(2*x,k-1,r))
 if r and x%3==2:a.update(origins((2*x-1)//3,k,r-1))
 return tuple(sorted(a))
def branch(x,k,r):
 y=(2*x-1)//3
 A=origins(4*x,k-2,r) if k>=2 else ()
 B=origins(y,k,r-1) if r>=1 else ()
 return A,B
c=Counter(); examples={}; min_gaps={}
for k in range(2,11):
 for r in range(1,11):
  for x in range(5,400,3):
   A,B=branch(x,k,r); C,D=branch(x,k,r+1)
   if not (A or B) or not (C or D):continue
   for label,left,right in [('AA',C,A),('AB',C,B),('BA',D,A),('BB',D,B)]:
    if not(left and right):continue
    gap=min(right)-max(left)
    c[label]+=1
    if label not in min_gaps or gap<min_gaps[label][0]:min_gaps[label]=(gap,x,k,r,min(left),max(left),min(right),max(right))
    if gap<=0 and label not in examples:examples[label]=(x,k,r,left[:5],right[:5],gap)
print('counts',c)
print('minimum gaps',min_gaps)
print('failures',examples)
