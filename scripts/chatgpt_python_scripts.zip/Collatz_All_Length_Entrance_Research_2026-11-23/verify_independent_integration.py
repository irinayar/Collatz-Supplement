#!/usr/bin/env python3
"""Independent exact audit of the integrated entrance theorems.

The source-residue exclusion uses backward complete-run congruences and
cross-checks them against the composed affine numerator. All arithmetic is
integer or rational. No finite sample is promoted to a global Collatz proof.
"""
from __future__ import annotations

import json
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise SystemExit("Run without -O or -OO.")
    floor = 2**71
    source_cap = (2**274 - 6) // 3
    assert 3**273 < 2**433
    assert 3**272 < 2**432

    coefficient_rows = []
    for s in range(1, 433):
        e = 2
        numerator = 16 * 3**s - 2**s
        while 15 * 2**(s + e - 1) <= numerator:
            e += 1
        gap = 1 - F(numerator, 15 * 2**(s + e - 1))
        coefficient_rows.append((gap, s, e))
    error = F(16, 15 * floor)
    bad = [(s, e) for gap, s, e in coefficient_rows
           if gap - error <= F(1, 120)]
    assert bad == [(193, 114), (246, 145), (299, 176), (352, 207)]
    remaining = sorted(row for row in coefficient_rows if row[1:] not in bad)
    assert remaining[0][1:] == (140, 83)
    assert remaining[0][0] - error > F(1, 120)
    # At a larger terminal exponent, the homogeneous gap exceeds one half.
    for gap, s, e in coefficient_rows:
        assert (1 + gap) / 2 - error > F(1, 120)

    first = []
    for s in range(2, 273):
        e = 2
        while 2**(s + e - 1) < 3**s:
            first.append((s, e))
            e += 1
    assert len(first) == 21583
    max_bits = max(s + e - 1 + t + f for s, e in first for t, f in bad)
    master_mod = 2**max_bits
    powers3 = {s: 3**s for s in set(range(2, 273)) | {t for t, _ in bad}}
    inverses3 = {s: pow(powers3[s], -1, master_mod) for s in powers3}
    exclusions = []
    for t, f in bad:
        # Exact odd output of the second complete run, inverted first.
        second_odd_quotient = ((1 + 2**(f - 1)) * pow(3**t, -1, 2**f)) % 2**f
        a_residue = 2**t * second_odd_quotient - 1
        minimum = None
        hits = 0
        for s, e in first:
            E1 = s + e - 1
            E2 = t + f - 1
            total_E = E1 + E2
            modulus = 2**(total_E + 1)
            backward = (2**s * inverses3[s] *
                        (1 + 2**(e - 1) * a_residue) - 1) % modulus
            U = powers3[t] * (powers3[s] - 2**s) + \
                (powers3[t] - 2**t) * 2**E1
            affine = ((2**total_E - U) * inverses3[s] * inverses3[t]) % modulus
            assert backward == affine
            assert backward & 1
            hits += backward <= source_cap
            row = (backward, s, e)
            if minimum is None or row < minimum:
                minimum = row
        assert hits == 0 and minimum[0] > source_cap
        exclusions.append({"second_type": [t, f], "first_types": len(first),
                           "minimum_source_residue": str(minimum[0]),
                           "minimum_first_type": list(minimum[1:]),
                           "minimum_bit_length": minimum[0].bit_length(),
                           "admissible_source_hits": hits})
    assert [row['minimum_bit_length'] for row in exclusions] == [310, 392, 478, 562]

    # Independent density and all-threshold error computations.
    expansion_min = {2: 2, 3: 4, 4: 6, 5: 7, 6: 9, 7: 11}
    for e, s in expansion_min.items():
        assert 2**(s + e - 1) < 3**s
        assert 2**(s - 1 + e - 1) >= 3**(s - 1)
    density = F(1, 2**18) * (
        1 + sum((F(1, 2**(s + e - 2)) for e, s in expansion_min.items()), F(0)))
    assert density == F(84297, 2**34)
    k = 71
    boundary = F(1 + 39 * (k + 2)**2, 4 * 2**k - 1)
    shortage_bound = (density / 4 + boundary) / 26
    assert shortage_bound < F(1, 21_000_000)
    # For k>=1, 2(k+2)^2-(k+3)^2=k^2+2k-1>0;
    # this is the symbolic reason the boundary sequence decreases.
    assert 2 * (k + 2)**2 - (k + 3)**2 == k*k + 2*k - 1 > 0
    new_target = F(8143, 18_000_000) - F(1, 21_000_000)
    assert new_target == F(11399, 25_200_000)
    result = {
        "status": "PASS",
        "coefficient_lengths": 432,
        "bad_types": bad,
        "independently_cross_checked_full_cylinders": 4 * len(first),
        "exclusions": exclusions,
        "positive_credit_toll": "1/(120*y), in 2^71 <= n < 2^272",
        "sparse_cover_density": str(density),
        "all_threshold_shortage_upper_fraction": str(shortage_bound),
        "all_threshold_shortage_simple_bound": "1/21000000",
        "remaining_residual_target": str(new_target),
        "full_signed_residual_proved": False,
        "global_collatz_closing_proved": False,
    }
    (HERE / "independent_integration_certificate.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "full_cylinders": 4 * len(first),
                      "positive_toll": "1/120", "shortage": "<1/21000000",
                      "remaining_target": str(new_target),
                      "global_bound_proved": False}, indent=2))


if __name__ == "__main__":
    main()
