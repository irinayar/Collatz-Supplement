#!/usr/bin/env python3
"""Exact controls for the all-length entrance-shortage theorem.

See All_Length_Entrance_Compensation.md for the uniform proofs.
Finite controls do not establish the open signed residual or global closure.
"""
from __future__ import annotations

import hashlib
import json
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent
S = 12


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def complete_run(a):
    s = v2(a + 1)
    intermediate = 3**s * ((a + 1) >> s) - 1
    e = v2(intermediate) + 1
    b = intermediate >> (e - 1)
    beta = 1 - F(2, 3)**s
    lam = F(2**(s + e - 1), 3**s)
    assert F(a + beta, 1) / lam == b
    c = max(F(0), F(1, b) - (1 + beta / 15) / a)
    return {'a': a, 'b': b, 's': s, 'e': e,
            'beta': beta, 'lambda': lam, 'credit': c}


def cylinders():
    rows = [{'kind': 'long_first', 'modulus': 2**S, 'residue': 2**S - 1}]
    for s in range(2, S):
        e = 2
        while 2**(s + e - 1) < 3**s:
            modulus = 2**(s + e + S - 1)
            residue = (2**s * (1 - 2**(e - 1))
                       * pow(3**s, -1, modulus) - 1) % modulus
            rows.append({'kind': 'long_second', 's': s, 'e': e,
                         'modulus': modulus, 'residue': residue})
            e += 1
    assert len(rows) == 34
    for i, x in enumerate(rows):
        for y in rows[i + 1:]:
            common = min(x['modulus'], y['modulus'])
            assert (x['residue'] - y['residue']) % common != 0
    assert max(r['modulus'] for r in rows) == 2**29
    density = sum((F(1, r['modulus']) for r in rows), F(0))
    assert density == F(168531, 2**29)
    return rows, density


def in_cover(u, rows):
    return sum(u % r['modulus'] == r['residue'] for r in rows)


def exact_count(lo, hi, rows):
    return sum((hi - r['residue']) // r['modulus']
               - (lo - 1 - r['residue']) // r['modulus'] for r in rows)


def actual_prefix(row):
    for lift in range(128):
        u = row['residue'] + row['modulus'] * (2**80 + lift)
        r1 = complete_run(u)
        r2 = complete_run(r1['b'])
        n = (3*u + 5) // 4
        if n % 2 == 0:
            n += 1
        H = (4*n - 2) // 3
        q = r1['beta'] + r1['lambda'] * r2['beta']
        if r1['b'] > H and r2['b'] > H and q > 1:
            assert n >= 2**71 and n <= u <= H
            assert r1['credit'] == 0 and r1['lambda'] < 1
            assert 1 < q < 2
            assert max(r1['s'], r2['s']) >= S
            assert in_cover(u, ROWS) == 1
            if row['kind'] == 'long_second':
                assert (r1['s'], r1['e']) == (row['s'], row['e'])
                assert r2['s'] >= S
            else:
                assert r1['s'] >= S
            # All internal unit-exponent steps increase from their run input;
            # checking both terminal states proves properness through the gate.
            return {'source': u, 'n': n, 'H': H, 'gate': r2['b'],
                    'types': [[r1['s'], r1['e']], [r2['s'], r2['e']]],
                    'phase': q, 'entrance_credit': r2['credit'],
                    'future_completion_asserted': False}
    raise AssertionError(('No proper prefix control found', row))


def encode(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {str(k): encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [encode(v) for v in x]
    return x


def main():
    if not __debug__:
        raise SystemExit('Run without -O or -OO.')
    global ROWS
    ROWS, D = cylinders()
    n0 = 2**71
    gate_upper = (D*(n0 + 1) + 102) / (4*n0 - 1)
    assert gate_upper < F(1, 12742)
    assert F(1, 12742) - D/4 == F(30823, 13681618321408)
    assert D/3 + (D/3 + 34)/n0 < F(1, 9556)
    assert F(1, 26*12742) == F(1, 331292)
    residual = F(8143, 18000000) - F(1, 331292)
    assert residual == F(669927689, 1490814000000)

    finite = 0
    covered = 0
    for u in range(1, 200002, 2):
        r1 = complete_run(u)
        r2 = complete_run(r1['b'])
        predicate = (r1['s'] >= S or
                     (2 <= r1['s'] < S and r1['lambda'] < 1
                      and r2['s'] >= S))
        count = in_cover(u, ROWS)
        assert count in (0, 1)
        assert bool(count) == predicate
        covered += count
        finite += 1
    assert covered == exact_count(1, 200001, ROWS)

    intervals = []
    for lo, hi in [(1, 200001), (1001, 199999), (2**71 + 1, (4*(2**71 + 1)-2)//3),
                   (2**272 + 1, (4*(2**272 + 1)-2)//3),
                   (2**600 + 1, (4*(2**600 + 1)-2)//3)]:
        count = exact_count(lo, hi, ROWS)
        assert count <= D*(hi-lo+1)+34
        intervals.append({'lo': lo, 'hi': hi, 'exact_cover_count': count})

    algebra_controls = 0
    for m in range(101):
        for long_count in range(m+1):
            controlled = m-long_count
            for extra_numerator in (0, 1, 37):
                y = 123457
                credit = F(max(0, controlled-2), 26*y) + F(extra_numerator, 100*y)
                debit = F(max(0, m-2), 26*y)
                shortage = max(F(0), debit-credit)
                excess = max(F(0), credit-debit)
                assert credit == debit+excess-shortage
                assert shortage <= F(long_count, 26*y)
                algebra_controls += 1

    controls = [actual_prefix(row) for row in ROWS]
    output = {'status': 'PASS', 'cylinder_count': len(ROWS), 'cylinders': ROWS,
              'exact_density': D, 'finite_odd_sources_checked': finite,
              'covered_finite_sources': covered, 'interval_counts': intervals,
              'actual_proper_high_floor_prefixes': controls,
              'shortage_algebra_controls': algebra_controls,
              'all_n_gate_reciprocal_cap': F(1, 12742),
              'all_n_shortage_cap': F(1, 331292),
              'new_sufficient_comparison_target': residual,
              'upper_n_cutoff_needed_for_shortage_bound': False,
              'full_signed_residual_proved': False, 'global_closing_proved': False,
              'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'all_length_entrance_compensation_certificate.json').write_text(
        json.dumps(encode(output), indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'cylinders': len(ROWS),
                      'density': str(D), 'finite_sources': finite,
                      'actual_high_prefixes': len(controls),
                      'shortage_cap': '1/331292',
                      'full_signed_residual_proved': False}, indent=2))


if __name__ == '__main__':
    main()
