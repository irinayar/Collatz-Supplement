#!/usr/bin/env python3
"""Exact controls for the unrestricted zero-entrance cap and triple family.

The universal proofs are in Unrestricted_Zero_Entrance_Valuations_and_Cap13.md.
The cap uses the inherited unit-gate depth theorem in n<2**272. The CRT
family is actual and least completed, but its original cores are empty.
"""
from __future__ import annotations

from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent


def v2(a):
    assert a > 0
    return (a & -a).bit_length() - 1


def v3(a):
    assert a > 0
    k = 0
    while a % 3 == 0:
        a //= 3
        k += 1
    return k


def encode(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {str(k): encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [encode(v) for v in x]
    return x


def finite_cap_comparisons():
    assert 2**432 > 3**272
    assert 45 * 2**1119 > 64 * 3**705
    assert 2 * 3**5 == 486 > 414 - 2
    assert 2 * 3**4 == 162 > 160 - 1
    assert max(1 + v3(d) for d in range(2, 413, 2)) == 5
    assert max(1 + v3(k) for k in range(2, 160, 2)) == 4

    expanding = []
    for s in range(1, 6):
        for e in range(2, 8):
            if F(2**(s + e - 1), 3**s) < 1:
                expanding.append((s, e))
    assert expanding == [(2, 2), (3, 2), (4, 2), (4, 3), (5, 2), (5, 3)]
    maxima = [0, 2, 2, 3, 4]
    for s, maximum in enumerate(maxima, 1):
        beta = 1 - F(2, 3)**s
        for e in range(2, maximum + 1):
            assert F(2**(s + e - 1), 3**s) < 1 + beta / 15
        e_next = max(2, maximum + 1)
        assert F(2**(s + e_next - 1), 3**s) > (
            (1 + beta / max(3, 2**s - 1)) * (1 + beta / 15)
        )
    assert len({pow(2, e - 1, 9) for e in [2, 3, 4]}) == 3
    capacities = [2, 2, 1, 1, 1]
    assert sum(capacities) == 7
    assert sum(capacities[:4]) == 6
    assert sum(capacities) + sum(capacities[:4]) == 13
    assert 2**6 * F(2, 3)**10 > 1
    assert 2**4 * F(2, 3)**6 > 1
    assert 2**2 * F(2, 3)**3 > 1
    return {
        'first_length_cap': 272, 'first_exponent_cap': 160,
        'inherited_total_entry_depth_cap': 705, 'last_exponent_cap': 414,
        'two_high_branch_minimum_exponent_difference': 486,
        'intermediate_valuation_capacities': capacities,
        'last_low_branch_capacity': 6, 'unrestricted_zero_entrance_cap': 13,
        'scope': 'Distinct sources, fixed proper unit gate, two zero-credit runs; 2**71<=n<2**272.',
    }


def crt_base():
    mod3 = 3**95
    mod2 = 2**84
    ry = (2**49 * (1 + 2**30) * pow(3**49, -1, 2**80) - 1) % 2**80
    rx = ((16 * ry - 19) * pow(27, -1, mod2)) % mod2
    r3 = (-pow(2**55, -1, mod3)) % mod3
    x0 = r3 + mod3 * (((rx - r3) * pow(mod3, -1, mod2)) % mod2)
    assert 0 < x0 < mod2 * mod3
    assert x0 % mod2 == rx and x0 % mod3 == r3
    assert rx % 32 == 7
    return x0, mod2 * mod3


def replay(source, word):
    x = source
    states = [x]
    q, lam = F(0), F(1)
    run_a, run_q = x, q
    run_s = 0
    runs = []
    for e in word:
        assert v2(3 * x + 1) == e
        q += lam / 3
        lam *= F(2**e, 3)
        x = (3 * x + 1) // 2**e
        states.append(x)
        run_s += 1
        assert lam * x == source + q
        if e >= 2:
            beta = 1 - F(2, 3)**run_s
            credit = max(F(0), F(1, x) - (1 + beta / 15) / run_a)
            runs.append({'input': run_a, 'output': x, 's': run_s, 'e': e,
                         'credit': credit, 'q_in': run_q, 'q_out': q})
            run_a, run_q, run_s = x, q, 0
    assert run_s == 0
    g, E = len(word), sum(word)
    affine = q * 3**g
    assert affine.denominator == 1
    modulus = 2**(E + 1)
    residue = ((2**E - affine.numerator) * pow(3**g, -1, modulus)) % modulus
    assert source % modulus == residue
    return {'source': source, 'word': word, 'states': states, 'g': g, 'E': E,
            'q': q, 'lambda': lam, 'endpoint': x, 'runs': runs,
            'full_modulus': modulus, 'full_residue': residue}


def uniform_affine_family_checks(x0):
    # All relevant band inequalities are affine in x, with positive slope.
    A = F(2**150, 3**95)
    R = F(3**52, 2**83)
    zsmall = F(2, 3)**95
    D = F(35 * 3**49 - 2**53, 2**83)
    assert 3**53 > 2**84
    assert 2**233 > 3**147
    assert 2**152 < 3**96
    assert F(2, 3) < R < A < F(3, 4)
    # Represent L(x)=slope*x+constant.
    u = (F(8, 9), F(-5, 9))
    v = (F(64, 81), F(-49, 81))
    w = (A, zsmall - 1)
    z = (R, D)
    n = (R, D - 4)
    add = lambda p, q: (p[0] + q[0], p[1] + q[1])
    scale = lambda k, p: (k * p[0], k * p[1])
    sub = lambda p, q: add(p, scale(-1, q))
    checks = {
        'u_minus_v': sub(u, v),
        'v_minus_w': sub(v, w),
        'w_minus_n': sub(w, n),
        'four_n_minus_two_minus_three_u': sub(add(scale(4, n), (F(0), F(-2))), scale(3, u)),
        'three_x_minus_four_n_plus_two': sub((F(3), F(2)), scale(4, n)),
        'three_u_plus_one_minus_two_x': sub(add(scale(3, u), (F(0), F(1))), (F(2), F(0))),
        'three_v_plus_one_minus_two_x': sub(add(scale(3, v), (F(0), F(1))), (F(2), F(0))),
        'three_w_plus_one_minus_two_x': sub(add(scale(3, w), (F(0), F(1))), (F(2), F(0))),
        'endpoint_minus_eighteen': add(z, (F(0), F(-18))),
    }
    for slope, intercept in checks.values():
        assert slope > 0 and slope * x0 + intercept > 0
    return {'A': A, 'R': R, 'positive_slope_and_initial_value_certificates': checks}


def completed_control(t, x0, step):
    x = x0 + step * t
    assert x % 32 == 7 and (2**55 * x + 1) % 3**95 == 0
    assert v3(2*x+1) == 4
    assert (2*x+1) % 81 == 0
    y = (27*x+19) // 16
    endpoint_num = 3**49 * (y+1) - 2**49
    assert endpoint_num % 2**79 == 0
    endpoint = endpoint_num // 2**79
    assert endpoint % 2 == 1
    n = endpoint - 4
    H = (4*n-2)//3
    sources = [4*(2*x+1)//9 - 1, 32*(2*x+1)//81 - 1,
               2**95 * (2**55*x+1)//3**95 - 1]
    prefixes = [[1,2,1,1,2], [1]*4+[3,1,2], [1]*94+[56,1,1,2]]
    continuation = [1]*48+[31]
    profiles = []
    for u, pre in zip(sources, prefixes):
        p = replay(u, pre+continuation)
        assert n <= u <= H
        assert p['endpoint'] == endpoint and n <= endpoint <= H
        assert min(p['states'][1:-1]) > H
        assert len(p['runs']) == 3
        assert p['runs'][1]['output'] == y
        assert all(r['credit'] == 0 and r['output'] > r['input'] for r in p['runs'][:2])
        assert p['runs'][0]['q_out'] < 1
        assert 1 < p['runs'][1]['q_out'] < 2
        assert p['q'] < 2 < 5
        assert endpoint - 2*3**p['g'] < n
        assert p['runs'][-1]['credit'] > 0
        profiles.append(p)
    assert [(p['g'],p['E']) for p in profiles] == [(54,86),(56,89),(147,233)]
    assert profiles[0]['runs'][1]['q_out'] == F(287,243)
    assert profiles[1]['runs'][1]['q_out'] == F(2539,2187)
    common_credit = profiles[0]['runs'][-1]['credit']
    assert all(p['runs'][-1]['credit'] == common_credit for p in profiles)
    scores = [-sum((r['credit'] for r in p['runs']), F(0)) for p in profiles]
    assert sum(scores) == -3 * common_credit < 0
    return {'t': t, 'intermediate_x': x, 'n': n, 'H': H, 'gate': y,
            'endpoint': endpoint, 'sources': sources,
            'n_in_inherited_cap_range': 2**71 <= n < 2**272,
            'all_three_least_genuine_completed': True,
            'all_entrance_credits_zero': True, 'all_original_core_counts': [0,0,0],
            'full_signed_scores': scores, 'all_source_copies_retained': True,
            'profiles': profiles}


def unrestricted_low_exponent_pair(p, ell):
    assert p >= 2 and ell >= 3
    m3, m2 = 3**(p+2), 2**(ell+2)
    r3 = (-pow(2, -1, m3)) % m3
    r2 = (2**ell * pow(3, 1-ell, 4) - 1) % m2
    x = r3 + m3 * (((r2-r3) * pow(m3, -1, m2)) % m2)
    C = 2*x+1
    u = 2**p * C // 3**p - 1
    v = 2**(p+3) * C // 3**(p+2) - 1
    n = 3*(u+1)//4
    if n % 2 == 0:
        n += 1
    H = (4*n-2)//3
    high = replay(u, [1]*(p-1)+[2]+[1]*(ell-1)+[2])
    low = replay(v, [1]*(p+2)+[3]+[1]*(ell-2)+[2])
    assert n <= v < u <= H
    assert min(high['states'][1:]+low['states'][1:]) > H
    assert high['endpoint'] == low['endpoint']
    assert len(high['runs']) == len(low['runs']) == 2
    assert all(r['credit'] == 0 for r in high['runs']+low['runs'])
    assert all(r['e'] <= 3 for r in high['runs']+low['runs'])
    assert v+1 == F(8,9)*(u+1)
    assert low['q']-1 == F(8,9)*(high['q']-1)
    assert 1 < low['q'] < high['q'] < 2
    return {'first_length_high':p,'last_length_high':ell,'n':n,'H':H,
            'sources':[u,v],'gate':high['endpoint'],'phases':[high['q'],low['q']],
            'all_entrance_credits_zero':True,'largest_terminal_exponent':3,
            'future_completion_asserted':False}


def main():
    if not __debug__:
        raise SystemExit('Run without -O or -OO.')
    cap = finite_cap_comparisons()
    x0, step = crt_base()
    affine = uniform_affine_family_checks(x0)
    controls = [completed_control(t, x0, step) for t in [0,1,2**40]]
    low_pairs = [unrestricted_low_exponent_pair(p,ell)
                 for p,ell in [(2,3),(12,3),(2,15),(40,20),(100,50)]]
    assert controls[0]['n_in_inherited_cap_range']
    result = {'status':'PASS', 'cap_certificate': cap, 'crt_base':x0, 'crt_step':step,
              'uniform_affine_family_certificate':affine, 'completed_controls':controls,
              'unrestricted_length_low_exponent_pair_controls':low_pairs,
              'unrestricted_cap_two_refuted_on_full_completed_family':True,
              'core_bearing_cap_two_refuted':False,
              'all_gate_signed_residual_proved':False,'global_closing_proved':False,
              'finite_controls_do_not_replace_written_uniform_proof':True}
    (HERE/'unrestricted_zero_entrances_certificate.json').write_text(
        json.dumps(encode(result),indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','unrestricted_zero_entrance_cap':13,
                      'least_completed_triple_controls':len(controls),
                      'unrestricted_length_low_exponent_pair_controls':len(low_pairs),
                      'base_threshold_bits':controls[0]['n'].bit_length(),
                      'base_threshold_in_inherited_range':True,
                      'original_cores_empty':True,'full_signed_residual_proved':False},indent=2))


if __name__=='__main__':
    main()
