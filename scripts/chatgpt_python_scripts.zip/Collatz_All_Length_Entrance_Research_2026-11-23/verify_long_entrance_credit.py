#!/usr/bin/env python3
"""Exact finite type certificate and actual proper-prefix controls.

The written proof supplies the unrestricted quantifier in the vanishing-toll
construction. This verifier does not prove the signed residual or Collatz.
"""
from __future__ import annotations

from fractions import Fraction as F
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def v2(value):
    assert value > 0
    return (value & -value).bit_length() - 1


def coefficient_certificate():
    rows = []
    gaps = []
    error = F(16, 15 * 2**71)
    for s in range(1, 706):
        numerator = 16 * 3**s - 2**s
        e = 2
        while 15 * 2**(s + e - 1) <= numerator:
            e += 1
        denominator = 15 * 2**(s + e - 1)
        assert denominator > numerator
        if e > 2:
            assert denominator // 2 <= numerator
        mu = 1 - F(numerator, denominator)
        assert mu - error > F(1, 15970)
        gaps.append((mu, s, e))
        rows.append({'s': s, 'first_positive_homogeneous_e': e,
                     'full_floor_corrected_toll_verified': '1/15970'})
    mu, s, e = min(gaps)
    assert (s, e) == (352, 207)
    # Independent fixed-coefficient inequality: all other e only improve it.
    assert mu == 1 - F(16 * 3**352 - 2**352, 15 * 2**558)
    for mu_short, ss, ee in gaps[:11]:
        assert mu_short - F(1, 960) > F(1, 26)
    return {'lengths_checked': 705, 'rows': rows,
            'minimum_type': [s, e], 'exact_minimum_gap': mu,
            'finite_input_error': error,
            'positive_margin_above_1_over_15970': mu - error - F(1, 15970),
            'short_input_floor': 1024, 'short_toll': F(1, 26)}

def inverse_residue_exclusions():
    Hmax = (2**274 - 6) // 3
    assert Hmax + 1 < 2**273 and 3**273 < 2**433
    error = F(16, 15 * 2**71)
    bad = []
    for s in range(1, 433):
        numerator = 16 * 3**s - 2**s
        e = 2
        while 15 * 2**(s + e - 1) <= numerator:
            e += 1
        mu = 1 - F(numerator, 15 * 2**(s + e - 1))
        assert 1 - (1 - mu) / 2 - error > F(1, 120)
        if mu - error <= F(1, 120):
            bad.append((s, e))
    assert bad == [(193, 114), (246, 145), (299, 176), (352, 207)]
    first_types = []
    for s in range(2, 273):
        exponents = []
        e = 2
        while 2**(s + e - 1) < 3**s:
            exponents.append(e)
            e += 1
        assert 2**(s + e - 1) >= 3**s
        if exponents:
            first_types.append((s, exponents))
    count_first = sum(len(es) for s, es in first_types)
    assert count_first == 21583
    exclusions = []
    for s2, e2 in bad:
        least = None
        checked = 0
        three2 = 3**s2
        for s1, exponents in first_types:
            g = s1 + s2
            threeg = 3**g
            # Reducing an inverse modulo a smaller power of two preserves it.
            inverse = pow(threeg, -1, 2**(g + exponents[-1] + e2 - 1))
            for e1 in exponents:
                E = g + e1 + e2 - 2
                U = threeg + 2**s1 * three2 * (2**(e1 - 1) - 1) - 2**(g + e1 - 1)
                residue = ((2**E - U) * inverse) % 2**(E + 1)
                assert residue > Hmax
                assert (threeg * residue + U) % 2**(E + 1) == 2**E
                checked += 1
                if least is None or residue < least[0]:
                    least = (residue, s1, e1)
        assert checked == count_first
        # Replay the minimizing cylinder as a direct valuation control.
        r, s1, e1 = least
        x = r
        for exponent in [1] * (s1 - 1) + [e1] + [1] * (s2 - 1) + [e2]:
            assert v2(3 * x + 1) == exponent
            x = (3 * x + 1) // 2**exponent
        exclusions.append({'second_type': [s2, e2],
                           'first_types_checked': checked,
                           'minimum_source_residue': r,
                           'minimum_first_type': [s1, e1],
                           'minimum_source_bits': r.bit_length(),
                           'all_residues_above_Hmax': True,
                           'minimum_direct_valuation_replay_passed': True})
    assert [x['minimum_source_bits'] for x in exclusions] == [310, 392, 478, 562]
    return {'Hmax': Hmax, 'first_length_max': 272, 'second_length_max': 432,
            'first_types_per_exclusion': count_first,
            'total_two_run_cylinders_checked': count_first * len(bad),
            'bad_terminal_types': bad, 'exclusions': exclusions,
            'actual_inverse_residue_toll': F(1, 120)}


def actual_prefix(s, e, floor=2**71):
    k = e - 1
    lam = F(2**(s + k), 3**s)
    assert F(16, 15) < lam < F(9, 8)
    beta = 1 - F(2, 3)**s
    A = 1 + beta / 15
    mu = 1 - A / lam
    modulus2 = 2**(k + 1)
    residue2 = (1 + 2**k) * pow(3**s, -1, modulus2) % modulus2
    residue9 = 5 * pow(2**s, -1, 9) % 9
    d = residue2 + modulus2 * ((residue9 - residue2) * pow(modulus2, -1, 9) % 9)
    period = 9 * modulus2
    # Pick a large enough actual CRT lift for positive credit and the floor.
    target_a = max(2 * floor + 100, (2 * A * beta / (lam * mu)).numerator //
                   (2 * A * beta / (lam * mu)).denominator + 1)
    if 2**s * d - 1 <= target_a:
        needed_d = (target_a + 1) // 2**s + 1
        d += max(0, (needed_d - d + period - 1) // period) * period
    a = 2**s * d - 1
    assert d % 2 == 1 and v2(a + 1) == s
    assert (3**s * d - 1) % 2**k == 0
    y = (3**s * d - 1) // 2**k
    assert y % 2 and v2(3**s * d - 1) == k
    assert a % 9 == 4 and (8 * a - 5) % 9 == 0
    u = (8 * a - 5) // 9
    assert u % 8 == 3
    n = 3 * (u + 1) // 4
    H = (4 * n - 2) // 3
    assert H == u and n % 2 and n >= floor and n <= u <= H
    word = [1, 2] + [1] * (s - 1) + [e]
    x = u
    q = F(0)
    scale = F(1)
    minimum_proper = None
    for exponent in word:
        assert v2(3 * x + 1) == exponent
        q += scale / 3
        scale *= F(2**exponent, 3)
        x = (3 * x + 1) // 2**exponent
        minimum_proper = x if minimum_proper is None else min(minimum_proper, x)
        assert x > H
        assert scale * x == u + q
    assert x == y
    q_expected = F(13, 9) - F(8, 9) * F(2, 3)**s
    assert q == q_expected and 1 < q < 2
    c1 = max(F(0), F(1, a) - (1 + F(5, 9) / 15) / u)
    c2 = max(F(0), F(1, y) - A / a)
    assert c1 == 0 and 0 < y * c2 < mu
    assert y * c2 == mu - A * beta / (lam * a)
    assert c2 > 0
    E = sum(word)
    U = q * 3**len(word)
    assert U.denominator == 1
    modulus = 2**(E + 1)
    residue = ((2**E - int(U)) * pow(3**len(word), -1, modulus)) % modulus
    assert u % modulus == residue
    return {'type_s_e': [s, e], 'n': n, 'H': H, 'source': u,
            'intermediate': a, 'gate': y, 'source_bits': u.bit_length(),
            'exact_gate_phase': q, 'first_credit': c1,
            'positive_normalized_entrance_credit': y * c2,
            'homogeneous_upper_gap': mu,
            'all_proper_states_above_H': True,
            'full_cylinder_final_odd_bit_checked': True,
            'completion_or_core_membership_asserted': False,
            'inside_original_payment_range': n < 2**272}


def main():
    if not __debug__:
        raise SystemExit('Run without -O or -OO.')
    coefficient = coefficient_certificate()
    exclusions = inverse_residue_exclusions()
    prefixes = [actual_prefix(s, e) for s, e in [(10, 7), (140, 83), (352, 207), (1017, 596)]]
    assert all(prefixes[i]['homogeneous_upper_gap'] > prefixes[i + 1]['homogeneous_upper_gap']
               for i in range(len(prefixes) - 1))
    assert prefixes[1]['inside_original_payment_range']
    assert 0 < prefixes[1]['positive_normalized_entrance_credit'] < F(1, 119)
    assert prefixes[1]['positive_normalized_entrance_credit'] > F(1, 120)
    result = {'status': 'PASS', 'coefficient_certificate': coefficient,
              'inverse_parity_residue_exclusions': exclusions,
              'actual_CRT_prefix_controls': prefixes,
              'coarse_type_only_toll': '1/(15970*y)',
              'finite_range_positive_entrance_toll': '1/(120*y)',
              'all_threshold_uniform_positive_toll': 'Disproved for proper prefixes by the written construction.',
              'full_signed_aggregate_proved': False,
              'global_collatz_closing_proved': False}
    (HERE / 'long_entrance_credit_certificate.json').write_text(
        json.dumps(encode(result), indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'exact_length_types_checked': 705,
                      'minimum_homogeneous_gap_type': coefficient['minimum_type'],
                      'exact_cylinders_excluded': exclusions['total_two_run_cylinders_checked'],
                      'finite_range_toll': '1/(120*y)',
                      'actual_proper_prefix_controls': len(prefixes),
                      'full_signed_bound_proved': False}, indent=2))


if __name__ == '__main__':
    main()
