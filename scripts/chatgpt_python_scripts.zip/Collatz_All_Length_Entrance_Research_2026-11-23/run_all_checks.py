#!/usr/bin/env python3
"""Replay all new exact checks in this self-contained research package.

The analytic proofs provide their universal quantifiers. The finite inverse
exclusion is exhaustive within analytically proved bounds. No global Collatz
proof or full signed suffix bound is certified by this runner.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHECKS = (
    "unrestricted/verify_unrestricted_zero_entrances.py",
    "long_credit/verify_long_entrance_credit.py",
    "transport/verify_all_length_entrance_compensation.py",
    "transport/verify_sharp_entrance_compensation.py",
    "verify_independent_integration.py",
)


def main() -> None:
    if not __debug__:
        raise SystemExit("Run without -O or -OO; assertions are required.")
    results = []
    for relative in CHECKS:
        script = ROOT / relative
        run = subprocess.run(
            [sys.executable, "-B", str(script)], cwd=ROOT,
            capture_output=True, text=True, check=False,
        )
        if run.returncode:
            sys.stderr.write(run.stdout + run.stderr)
            raise SystemExit(f"FAILED: {relative} (exit {run.returncode})")
        result = json.loads(run.stdout)
        if result.get("status") != "PASS":
            raise SystemExit(f"Missing PASS result: {relative}")
        results.append({"checker": relative,
                        "sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
                        "result": result})
        print(f"PASS: {relative}", flush=True)
    summary = {
        "status": "PASS", "checkers": results,
        "entrance_shortage_bound": "< 1/21000000 for every odd n >= 2^71",
        "positive_two_run_credit": "> 1/(120*y), if positive, in 2^71 <= n < 2^272",
        "zero_two_run_capacity": "<= 13 in 2^71 <= n < 2^272",
        "finite_full_inverse_exclusion": "86332 full cylinders, independently reproduced",
        "full_signed_suffix_residual_proved": False,
        "global_forcing_proved": False,
        "collatz_convergence_proved": False,
        "historical_large_canonical_certificates_replayed": False,
    }
    (ROOT / "Verification_Summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print("All five exact checkers passed; the full residual and global forcing remain open.")


if __name__ == "__main__":
    main()
