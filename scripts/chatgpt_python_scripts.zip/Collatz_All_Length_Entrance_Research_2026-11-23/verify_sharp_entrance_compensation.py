#!/usr/bin/env python3
"""Exact controls for the all-height entrance shortage below 1/21,000,000.

The uniform proof is in Sharp_All_Length_Entrance_Compensation.md.
The full signed residual and global forcing remain open.
"""
from __future__ import annotations

from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
MIN_S = {2: 2, 3: 4, 4: 6, 5: 7, 6: 9, 7: 11}


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def run(a):
    s = v2(a + 1)
    numerator = 3**s * ((a+1) >> s) - 1
    e = v2(numerator) + 1
    return s, e, numerator >> (e-1)


def cylinder_a(s):
    assert s >= 12
    bits = s+7
    modulus = 2**bits
    residue = (2**s*pow(3**s, -1, modulus)-1) % modulus
    return {'kind': 'A', 's': s, 'bits': bits,
            'modulus': modulus, 'residue': residue}


def cylinder_b(s, e, t):
    assert 2 <= e <= 7 and s >= MIN_S[e] and t >= 12
    E = s+e-1
    bits = E+t+7
    modulus = 2**bits
    r = ((2**s + 2**E*(2**t*pow(3**t, -1, modulus)-1))
         * pow(3**s, -1, modulus)-1) % modulus
    return {'kind': 'B', 's': s, 'e': e, 't': t,
            'bits': bits, 'modulus': modulus, 'residue': r}


def family(smax, tmax):
    result = [cylinder_a(s) for s in range(12, smax+1)]
    for e, smin in MIN_S.items():
        for s in range(smin, smax+1):
            for t in range(12, tmax+1):
                result.append(cylinder_b(s, e, t))
    return result


def check_disjoint(rows):
    # Reverse the prescribed binary digits: a 2-adic cylinder becomes a
    # dyadic subinterval of [0,1]. Its length is exactly 1/modulus.
    intervals = []
    for r in rows:
        numerator = int(format(r['residue'], f"0{r['bits']}b")[::-1], 2)
        intervals.append((F(numerator, r['modulus']),
                          F(numerator+1, r['modulus'])))
    intervals.sort()
    assert all(a[1] <= b[0] for a, b in zip(intervals, intervals[1:]))


def count_interval(lo, hi, rows):
    return sum((hi-r['residue'])//r['modulus']
               -(lo-1-r['residue'])//r['modulus'] for r in rows)


def prefix_control(row):
    for lift in range(128):
        u = row['residue'] + row['modulus']*(2**80+lift)
        s, e, a = run(u)
        t, f, y = run(a)
        if row['kind'] == 'A':
            assert s == row['s'] and e >= 8
        else:
            assert (s, e, t) == (row['s'], row['e'], row['t']) and f >= 8
        n = (3*u+5)//4
        if n % 2 == 0:
            n += 1
        H = (4*n-2)//3
        q = 1-F(2, 3)**s + F(2**(s+e-1), 3**s)*(1-F(2, 3)**t)
        if a > H and y > H and q > 1:
            assert n >= 2**71 and n <= u <= H and 1 < q < 2
            assert 2**(s+e-1) < 3**s
            return {'source': u, 'n': n, 'H': H, 'gate': y,
                    'first_type': [s, e], 'second_type': [t, f],
                    'phase': q, 'future_completion_asserted': False}
    raise AssertionError(('No actual proper control found', row))


def encode(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {str(k): encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [encode(v) for v in x]
    return x


def main():
    if not __debug__:
        raise SystemExit('Run without -O or -OO.')
    for e, s in MIN_S.items():
        assert 2**(s+e-1) < 3**s
        assert 2**(s+e-2) > 3**(s-1)
    assert 2**(11+7) > 3**11 and 2**(12+7) < 3**12
    assert 64*F(2, 3)**12 < 1
    DA = F(1, 2**18)
    coefficient = sum((F(1, 2**(s+e-2)) for e, s in MIN_S.items()), F(0))
    assert coefficient == F(18761, 65536)
    D = DA*(1+coefficient)
    assert D == F(84297, 2**34)

    bounds = []
    for k in [71, 72, 100, 272, 600, 4096]:
        K = max(0, k-10) + sum(max(0, k+2-s) for s in MIN_S.values())*max(0, 2*k-8)
        assert K <= 13*(k+2)**2
        numerator = 1+39*(k+2)**2
        next_numerator = 1+39*(k+3)**2
        denominator = 4*2**k-1
        next_denominator = 4*2**(k+1)-1
        assert next_numerator < 2*numerator
        assert next_denominator > 2*denominator
        g = F(numerator, denominator)
        assert (D/4+g)/26 < F(1, 21000000)
        bounds.append({'k': k, 'eligible_cylinder_count': K,
                       'safe_count_bound': 13*(k+2)**2,
                       'gate_mass_bound': D/4+g,
                       'shortage_bound': (D/4+g)/26})
    residual = F(8143, 18000000)-F(1, 21000000)
    assert residual == F(11399, 25200000)

    finite_rows = family(17, 36)
    check_disjoint(finite_rows)
    covered = 0
    sources_checked = 0
    for u in range(1, 200002, 2):
        s, e, a = run(u)
        t, f, y = run(a)
        predicate_a = e >= 8 and s >= 12
        predicate_b = e in MIN_S and s >= MIN_S[e] and t >= 12 and f >= 8
        assert not (predicate_a and predicate_b)
        if predicate_a or predicate_b:
            row = cylinder_a(s) if predicate_a else cylinder_b(s, e, t)
            assert u % row['modulus'] == row['residue']
            assert s <= 17 and t <= 36
            covered += 1
        sources_checked += 1
    assert covered == count_interval(1, 200001, finite_rows)
    assert covered <= D*200001 + len(finite_rows)

    selected = [cylinder_a(s) for s in (12, 13, 20, 100)]
    selected += [cylinder_b(s+d, e, t) for e, s in MIN_S.items()
                 for d in (0, 3, 70) for t in (12, 13, 80)]
    actual = [prefix_control(row) for row in selected]
    result = {'status': 'PASS', 'exact_density': D, 'density_A': DA,
              'density_B': DA*coefficient, 'first_expansion_minima': MIN_S,
              'finite_disjoint_cylinders': len(finite_rows),
              'finite_odd_sources_checked': sources_checked,
              'covered_finite_sources': covered,
              'dyadic_bounds': bounds,
              'actual_high_floor_proper_prefixes': actual,
              'final_shortage_cap': F(1, 21000000),
              'sufficient_R_dagger_target': residual,
              'upper_n_cutoff_required_for_shortage': False,
              'full_signed_residual_proved': False,
              'global_closing_proved': False,
              'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'sharp_entrance_compensation_certificate.json').write_text(
        json.dumps(encode(result), indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'density': str(D),
                      'finite_disjoint_cylinders': len(finite_rows),
                      'finite_sources': sources_checked,
                      'actual_high_prefixes': len(actual),
                      'shortage_cap': '1/21000000',
                      'full_signed_residual_proved': False}, indent=2))


if __name__ == '__main__':
    main()
