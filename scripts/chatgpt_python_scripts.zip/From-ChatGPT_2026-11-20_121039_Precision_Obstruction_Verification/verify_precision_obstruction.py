from math import prod

def num(word):
 a=0; u=0
 for i,c in enumerate(word):
  if c=='1':u=3*u+2**i;a+=1
 return a,u

def control(h,a):
 j=2*a;b=a-1
 w='0'*(j-b-h)+'1'*(b-h)+'10'*h
 assert len(w)==j
 bc,V=num(w)
 assert bc==b
 assert (V-2**j)%3**h==0
 threshold=2**j-3**b
 return V>threshold,V,threshold,w
for h in range(1,7):
 first=next((a for a in range(h+1,100) if control(h,a)[0]),None)
 print('h',h,'first a',first,'j',2*first,'V/threshold',round(control(h,first)[1]/control(h,first)[2],3))
 for a in range(max(first,h+1),first+10):assert control(h,a)[0]
print('All symbolic congruences and sampled inequalities passed')
