"""Exact finite three-way Collatz audit; standard library only."""
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

OUT=Path(__file__).parent

def T(n): return (3*n+1)//2 if n&1 else n//2

def envelope(N,M,R):
    B=[0]*M
    for s in range(M):
        z=(N-1)-((N-1-s)%M)
        B[s]=z if z>=1 else 0
    rows=[B]
    for _ in range(R):
        nxt=[0]*M
        for s,h in enumerate(B):
            if not h: continue
            for b in (0,1):
                z=h-M*((h-b)&1)
                if z<1: continue
                y=T(z)
                nxt[y%M]=max(nxt[y%M],y)
        B=nxt
        rows.append(B)
    return rows

def inverse_step(y):
    yield 2*y,0
    if (2*y-1)%3==0:
        z=(2*y-1)//3
        if z>0 and z&1: yield z,1

def inverse_meet(y,n,R):
    layers=[{y}]
    for _ in range(R):
        layers.append({z for x in layers[-1] for z,_ in inverse_step(x)})
    return [sorted(x for x in layer if x<n) for layer in layers]

def exact_forward_sets(n,R):
    layers=[set(range(1,n))]
    for _ in range(R): layers.append({T(x) for x in layers[-1]})
    return layers

def pack_check(n,Lmax=12,steps=120):
    z=n; states=[]; bits=[]; seen=set()
    while z not in seen and len(states)<steps+Lmax+1:
        seen.add(z);states.append(z);bits.append(z&1);z=T(z)
    H=[0]; h=0
    for x in states: h=max(h,x);H.append(h)
    checks=0; fails=[]; bounds=[]
    for L in range(1,Lmax+1):
        if len(bits)<L: continue
        fac=set()
        for k in range(len(bits)-L+1):
            fac.add(tuple(bits[k:k+L]))
        p=len(fac)
        if p+L<=len(bits) and p<len(states):
            checks+=1
            if H[p+1]<2**L: fails.append((L,p,H[p+1]))
        bounds.append((L,p))
    return checks,fails,bounds,len(states)

def main():
    NMAX=160; R=8; MLIST=(3,9,27)
    comparisons=0; envelope_valid=0; exclusion=defaultdict(int); witness_counts=defaultdict(int)
    examples=[]; pack_checks=0; pack_fails=[]; separation_checks=0
    for n in range(2,NMAX+1):
        fwd=exact_forward_sets(n,R)
        envs={M:envelope(n,M,R) for M in MLIST}
        for M,rows in envs.items():
            for d,states in enumerate(fwd):
                for x in states:
                    envelope_valid+=1
                    assert x<=rows[d][x%M],(n,M,d,x)
        z=n; history=[]; seen=set()
        for j in range(9):
            if z in seen: break
            seen.add(z);history.append(z)
            if j>=2 and z>=n:
                meetings=inverse_meet(z,n,R)
                for d,origins in enumerate(meetings):
                    oracle=z in fwd[d]
                    assert oracle==bool(origins),(n,j,d,z)
                    comparisons+=1
                    for M,rows in envs.items():
                        reject=z>rows[d][z%M]
                        assert not (reject and oracle)
                        if reject: exclusion[(M,'depth')]+=1
                        if not oracle: exclusion[(M,'nonmeet')]+=1
                        if oracle: witness_counts[M]+=1
                if len(examples)<8:
                    examples.append({'n':n,'j':j,'endpoint':z,'meeting_depths':[d for d,v in enumerate(meetings) if v], 'envelope_excluded_depths_M27':[d for d in range(R+1) if z>envs[27][d][z%27]]})
            z=T(z)
        c,f,b,s=pack_check(n)
        pack_checks+=c
        pack_fails.extend([(n,*item) for item in f])
        # reciprocal separation for distinct states with identical length-L future word
        states=[];bits=[];z=n; seen=set()
        while z not in seen and len(states)<65:
            seen.add(z);states.append(z);bits.append(z&1);z=T(z)
        for L in (2,4,6):
            for i in range(max(0,len(states)-L+1)):
                for k in range(i+1,max(0,len(states)-L+1)):
                    if bits[i:i+L]==bits[k:k+L]:
                        assert abs(Fraction(1,states[i])-Fraction(1,states[k]))>=Fraction(2**L,states[i]*states[k])
                        separation_checks+=1
    result={'range_n':[2,NMAX], 'max_inverse_depth':R,'moduli':list(MLIST), 'envelope_containment_checks':envelope_valid,'inverse_forward_witness_equivalence_checks':comparisons,'depth_envelope_exclusions':{str(k[0]):v for k,v in exclusion.items() if k[1]=='depth'},'nonmeeting_cases':{str(k[0]):v for k,v in exclusion.items() if k[1]=='nonmeet'},'meeting_cases':witness_counts.get(3,0),'height_packing_checks':pack_checks,'height_packing_violations':pack_fails,'reciprocal_separation_checks':separation_checks,'examples':examples}
    (OUT/'results.json').write_text(json.dumps(result,indent=2,default=dict))
    print(json.dumps({k:v for k,v in result.items() if k!='examples'},indent=2,default=dict))

if __name__=='__main__':main()
