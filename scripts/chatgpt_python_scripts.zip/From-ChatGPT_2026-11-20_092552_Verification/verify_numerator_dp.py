from itertools import combinations
from collections import defaultdict

def direct(j,a):
    d={}
    for I in combinations(range(j),a):
        u=sum((1<<i)*3**(a-h-1) for h,i in enumerate(I))
        r=u%3**a
        d[r]=max(d.get(r,-1),u)
    return d

def build(J):
    dp={(0,0):{0:0}}
    for j in range(J):
        for a in range(j+2):
            d={}
            if a<=j:
                for r,u in dp[(j,a)].items():
                    d[r]=max(d.get(r,-1),u)
            if a>0:
                for r,u in dp[(j,a-1)].items():
                    v=3*u+(1<<j)
                    R=v%(3**a)
                    d[R]=max(d.get(R,-1),v)
            dp[(j+1,a)]=d
    return dp

J=13
DP=build(J)
comparisons=0
for j in range(J+1):
    for a in range(j+1):
        assert DP[(j,a)]==direct(j,a),(j,a)
        comparisons+=1
print('Exact DP-versus-enumeration tables checked:',comparisons)

# Check same-count witness iff direct forward fibre for small n and j.
def step(x): return x//2 if x%2==0 else (3*x+1)//2
for j in range(1,11):
    fib={}
    vals=[]
    for n in range(1,2001):
        x=n; a=0
        for _ in range(j):
            a+=x%2;x=step(x)
        u=(1<<j)*x-3**a*n
        vals.append((n,x,a,u))
        fib.setdefault((x,a),[]).append(n)
    for n,y,a,u in vals:
        maxu=DP[(j,a)].get(((1<<j)*y)%(3**a))
        assert maxu is not None
        witness=maxu>u
        # A same-count witness may be >2000, but if smaller than n it must be in this range.
        actual=any(m<n for m in fib[(y,a)])
        assert witness==actual,(j,n,y,a,u,maxu)
print('Exact source same-count witness tests:',10*2000)
for n in [15,79,143,207,271]:
    x=n;a=0
    for _ in range(6):a+=x%2;x=step(x)
    u=64*x-3**a*n
    print('family',n,'y',x,'a',a,'U',u,'M',DP[(6,a)][(64*x)%(3**a)])
