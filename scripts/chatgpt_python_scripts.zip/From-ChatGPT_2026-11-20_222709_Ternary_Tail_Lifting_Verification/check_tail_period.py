from itertools import combinations
from math import comb

def numerator(ps):
 b=len(ps)
 return sum(3**(b-i-1)*2**p for i,p in enumerate(ps))

def residue_position(L,x,j,prefix):
 q=3**j; period=2*3**(j-1)
 target=(pow(2,L,q)*x-sum(3**(j-i-1)*pow(2,p,q) for i,p in enumerate(prefix)))%q
 if target%3==0:return None
 return next(t for t in range(period) if pow(2,t,q)==target)

checks=0; classes=0; admiss=0; max_candidates=0
for L in range(3,15):
 for j in range(1,min(L,5)+1):
  for x in range(1,10):
   if x%3==0:continue
   for pre in combinations(range(L),j-1):
    t=residue_position(L,x,j,pre)
    assert t is not None
    lo=(pre[-1]+1 if pre else 0)
    options=[z for z in range(lo,L) if z%(2*3**(j-1))==t]
    max_candidates=max(max_candidates,len(options))
    classes+=1
    for z in range(lo,L):
     ps=pre+(z,)
     expected=(numerator(ps)-pow(2,L,3**j)*x)%(3**j)==0
     assert expected==(z in options),(L,j,x,ps)
     checks+=1
     admiss+=expected
print({'tested_tail_configs':checks,'fixed_prefix_classes':classes,'admissible':admiss,'max_allowed_final_positions':max_candidates})
checked=0; possible=0; blocked=0
for L in range(4,15):
 for j in range(1,min(L-1,5)+1):
  for x in range(1,10):
   if x%3==0:continue
   for tail in combinations(range(L),j):
    T=numerator(tail)
    delta=pow(2,L)*x-T
    if delta%(3**j):continue
    d=(delta//(3**j))%3
    for p in range(tail[0]):
     actual=(3**j*2**p+T-pow(2,L)*x)%(3**(j+1))==0
     expected=d!=0 and (2**p%3)==d
     assert actual==expected
     checked+=1
     possible+=actual
     blocked+=not actual
print({'older_position_tests':checked,'admissible':possible,'excluded':blocked})
