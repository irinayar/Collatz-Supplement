from functools import lru_cache
from itertools import combinations

def v3(n):
 a=0
 while n%3==0:
  n//=3;a+=1
 return a
@lru_cache(None)
def R(x,k):
 a=v3(x+1)
 if k==0:return a
 return max(l+R(2*((2**l*(x+1))//3**l-1),k-1) for l in range(a+1))
@lru_cache(None)
def H(x,k,r):
 if r<0:return None
 a=v3(x+1)
 if k==0:
  return 2**r*((x+1)//3**r)-1 if r<=a else None
 vals=[H(2*((2**l*(x+1))//3**l-1),k-1,r-l) for l in range(min(a,r)+1)]
 return min((v for v in vals if v is not None),default=None)
def brute(x,k,r):
 n=k+r; out=[]
 for odds in combinations(range(n),r):
  V=sum((2**pos)*3**(r-1-i) for i,pos in enumerate(odds))
  numer=2**n*x-V
  if numer>0 and numer%3**r==0:
   m=numer//3**r
   y=m
   for j in range(n):
    assert (y%2)==(j in odds)
    y=(3*y+1)//2 if y%2 else y//2
   assert y==x
   out.append(m)
 return min(out,default=None)
series=0;adjacent=0;thresholds=0; brutechecks=0
for x in range(1,301):
 for k in range(6):
  top=R(x,k)
  seq=[H(x,k,r) for r in range(top+1)]
  assert all(isinstance(v,int) and v>0 for v in seq)
  assert all(seq[i]>seq[i+1] for i in range(top))
  assert seq[0]==(2**k)*x
  series+=1;adjacent+=top
  for N in [2,10,100,1000,100000]:
   actual=[r for r in range(top+1) if seq[r]<N]
   if actual:assert actual==list(range(actual[0],top+1))
   thresholds+=1
  if x<=40 and k<=4:
   for r in range(min(top+2,8)):
    if k+r<=12:
     assert H(x,k,r)==brute(x,k,r)
     brutechecks+=1
print({'series':series,'adjacent':adjacent,'thresholds':thresholds,'independent_brute_cells':brutechecks,'failures':0})
