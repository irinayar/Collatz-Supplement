#!/usr/bin/env python3
from fractions import Fraction

def check(N,h,threshold=4095):
    assert N>=1 and h>=1
    u=1+2*h*4**N
    start=u
    G=Fraction(1)
    starts=[]
    for i in range(N):
        expected=1+2*h*3**i*4**(N-i)
        assert u==expected and u%8==1
        assert (3*u+1)%4==0 and (3*u+1)%8!=0
        starts.append(u)
        G*=Fraction(3*u+1,3*u)
        u=(3*u+1)//4
    assert u==1+2*h*3**N
    closed=1+Fraction(Fraction(4,3)**N-1,1+2*h*4**N)
    assert G==closed and G<Fraction(3,2)
    assert all(v>threshold for v in starts+[u]) if 2*h*3**N>threshold else True
    return {'N':N,'h':h,'start':start,'end':u,'G':str(G),'G_float':float(G),'min_state':u}

if __name__=='__main__':
    for n,h in [(1,1),(3,1),(8,1),(20,2),(50,1),(100,1)]:
        print(check(n,h))
