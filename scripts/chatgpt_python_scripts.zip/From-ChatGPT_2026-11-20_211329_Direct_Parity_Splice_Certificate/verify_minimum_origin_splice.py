from functools import lru_cache
import json
@lru_cache(None)
def H(x,k,r):
    if k==r==0:return x
    z=[]
    if k:
        v=H(2*x,k-1,r)
        if v is not None:z.append(v)
    if r and x%3==2:
        v=H((2*x-1)//3,k,r-1)
        if v is not None:z.append(v)
    return min(z) if z else None
@lru_cache(None)
def minwords(x,k,r):
    if k==r==0:return [('',x)]
    out=[]
    if k:
        out.extend((w+'E',v) for w,v in minwords(2*x,k-1,r) if v==H(x,k,r))
    if r and x%3==2:
        out.extend((w+'O',v) for w,v in minwords((2*x-1)//3,k,r-1) if v==H(x,k,r))
    return out

def path(m,w):
    z=m;seq=[m]
    for c in w:
        if c=='E':
            if z%2:return None
            z//=2
        else:
            if z%2!=1:return None
            z=(3*z+1)//2
        seq.append(z)
    return seq

def insertion(m,w,x):
    seq=path(m,w);assert seq[-1]==x
    hits=[]
    for j,y in enumerate(seq):
        if y%3!=2:continue
        z=(2*y-1)//3
        for c in reversed(w[:j]):
            if c=='E':z*=2
            else:
                if z%3!=2:break
                z=(2*z-1)//3
        else:
            nw=w[:j]+'O'+w[j:]
            if 0<z<m and path(z,nw) is not None and path(z,nw)[-1]==x:
                hits.append([j,z,nw])
    return hits

cases=[]
for k in range(9):
 for r in range(7):
  for x in range(3,3**(r+1)+3):
   m=H(x,k,r);n=H(x,k,r+1)
   if m is None or n is None or m%3==2 or (k>=1 and m>=2**(k+1)-3):continue
   ww=[w for w,v in minwords(x,k,r)]
   assert ww and all(path(m,w)[-1]==x for w in ww)
   insert=[(w,h) for w in ww for h in insertion(m,w,x)]
   proper=[]
   for w in ww:
    seq=path(m,w);a=b=0
    for j,y in enumerate(seq[:-1]):
     z=H(y,a,b+1)
     if z is not None and z<m:
      proper.append([j,y,a,b,z])
     a+=w[j]=='E';b+=w[j]=='O'
   assert n<m,(x,k,r,m,n)
   cases.append({'x':x,'k':k,'r':r,'m':m,'successor':n,'words':ww,'insertions':insert,'proper_splices':proper})
assert len(cases)==56,len(cases)
assert sum(bool(c['insertions']) for c in cases)==29
assert sum(bool(c['proper_splices']) for c in cases)==54
print('56 exceptional comparisons; 29 insertion witnesses; 54 proper splice witnesses; 2 only endpoint-level witnesses')
print('No proper splice:',[(c['x'],c['k'],c['r'],c['m']) for c in cases if not c['proper_splices']])
with open('/mnt/data/minimum_origin_splice_certificates.json','w') as f:json.dump(cases,f,indent=2)
