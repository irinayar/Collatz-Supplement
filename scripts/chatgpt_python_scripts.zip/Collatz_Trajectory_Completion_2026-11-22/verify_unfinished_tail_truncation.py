#!/usr/bin/env python3
"""Exact controls for odd-input truncation and arbitrary unfinished tails.

The previously independently audited canonical packing certificate is imported,
not rerun.  All new controls use exact rational arithmetic and 23 saved paths.
No high cycle exclusion is asserted.
"""

from __future__ import annotations

import argparse
from fractions import Fraction as Q
import hashlib
import json
from math import factorial
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
M0 = 1 << 71
R_BAR = Q(575597, 500000)
GAMMA = Q(367, 250)
SCALE = 1 << 80


def T(x: int) -> int:
    return (3*x+1)//2 if x & 1 else x//2


def phi(x: int) -> Q:
    return 1 + Q(5, x)


def exp10(x: Q) -> Q:
    assert 0 <= x < 1
    return sum((x**j / factorial(j) for j in range(11)), Q(0)) + x**11 / factorial(11) / (1-x/12)


def enc(q: Q) -> dict:
    p = q.numerator*SCALE
    lo, hi = p//q.denominator, -((-p)//q.denominator)
    assert Q(lo, SCALE) <= q <= Q(hi, SCALE)
    return {"lower_units": str(lo), "upper_units": str(hi),
            "denominator": str(SCALE), "display_only": float(q)}


def product(path: list[int]) -> Q:
    result = Q(1)
    for x in path[:-1]:
        if x & 1:
            result *= Q(3*x+1, 3*x)
    return result


def reciprocal(path: list[int]) -> Q:
    return sum((Q(1, x) for x in path[:-1] if x & 1), Q(0))


def normalized(path: list[int]) -> Q:
    return product(path)*phi(path[-1])/phi(path[0])


def check_truncation(path: list[int]) -> dict:
    assert all(x > 0 for x in path)
    assert all(T(x) == y for x, y in zip(path, path[1:]))
    odd_positions = [i for i, x in enumerate(path[:-1]) if x & 1]
    charged = [path[i] for i in odd_positions]
    assert len(charged) == len(set(charged))
    cut = odd_positions[-1]+1 if odd_positions else 0
    short = path[:cut+1]
    assert len(short[:-1]) == len(set(short[:-1]))
    assert product(short) == product(path)
    assert reciprocal(short) == reciprocal(path)
    if charged:
        minimum = min(charged)
        assert min(short[:-1]) >= minimum
    else:
        minimum = None
        assert product(path) == 1 and reciprocal(path) == 0
    U = r = 0
    for i, x in enumerate(path[:-1]):
        if x & 1:
            U = 3*U + (1 << i)
            r += 1
    assert (1 << (len(path)-1))*path[-1] == 3**r*path[0]+U
    assert product(path) == 1+Q(U, 3**r*path[0])
    high = bool(charged and minimum >= M0)
    if high:
        assert reciprocal(path) < R_BAR
        assert product(path) < exp10(R_BAR/3) < GAMMA
        assert 250*U < 117*3**r*path[0]
        if 2*path[-1] >= minimum:
            assert normalized(path) < GAMMA
    return {"cut": cut, "odd_inputs": len(charged), "high_floor": high,
            "full_shortcut_inputs_distinct": len(set(path[:-1])) == len(path)-1}


def constant_checks(certificate: Path, audit: Path) -> dict:
    raw = certificate.read_bytes()
    data = json.loads(raw)
    independent = json.loads(audit.read_bytes())
    assert data["status"] == independent["status"] == "PASS"
    assert independent["producer_sha256"] == hashlib.sha256(raw).hexdigest()
    def fraction(entry: dict) -> Q:
        return Q(int(entry["numerator"]), int(entry["denominator"]))
    aggregate = sum((fraction(data[key]) for key in
                     ("finite_endpoint_weight", "uninspected_length_tail",
                      "large_odd_count_tail", "terminal_boundary")), Q(0))
    assert aggregate == fraction(data["reciprocal_upper"]) < R_BAR
    assert int(data["finite_endpoint_weight"]["numerator"]) == 90967979218314767609676800115
    assert data["upward_rounding_terms"] == independent["upward_rounding_terms"] == 7912935
    envelope = exp10(R_BAR/3)
    normalized_envelope = envelope*(1+Q(10, M0))
    assert envelope < normalized_envelope < GAMMA < Q(47, 32) < Q(3, 2)
    # K159 with fixed S=116 gives an all-larger-floor bound, since its first
    # and boundary terms decrease with L.  This is one path, not a profile sum.
    L, S = 190, 116
    high_budget = Q(3**S-1, 1 << L) + Q(200, 7)*Q(193, 200)**(S+1) + Q(L+1, 1 << (L-1))
    high_charge = exp10(high_budget/3)*(1+Q(10, 1 << L))-1
    assert 0 < high_budget/3 < 1
    assert high_charge < Q(164294642, 10**9) < Q(21, 125)
    return {"canonical_certificate_sha256": hashlib.sha256(raw).hexdigest(),
            "canonical_independent_audit_sha256": hashlib.sha256(audit.read_bytes()).hexdigest(),
            "scope": "Imported previously audited packing theorem; its large DP is not rerun here.",
            "reciprocal_upper": str(R_BAR), "raw_product_rational_envelope": enc(envelope),
            "half_floor_endpoint_rho_envelope": enc(normalized_envelope),
            "strict_cap": str(GAMMA), "margin": enc(GAMMA-normalized_envelope),
            "single_path_large_floor": {"floor": "2^190", "S": S,
                "K159_reciprocal_budget": enc(high_budget),
                "half_floor_endpoint_positive_charge_upper": enc(high_charge),
                "margin_below_21_over_125": enc(Q(21, 125)-high_charge)}}


def saved_path_checks(seeds: Path) -> dict:
    raw = seeds.read_bytes()
    groups = json.loads(raw)["groups"]
    paths = prefixes = high_prefixes = chain_checks = multi_return_checks = remaining_checks = 0
    for group in groups:
        for source in group["sources"]:
            u = source["u"]
            path = [u]
            for e in source["word"]:
                num = 3*path[-1]+1
                assert path[-1] & 1
                assert (num & -num).bit_length()-1 == e
                for _ in range(e):
                    path.append(T(path[-1]))
                assert path[-1] & 1
            assert len(path[:-1]) == len(set(path[:-1]))
            paths += 1
            for end in range(1, len(path)):
                prefix = path[:end+1]
                result = check_truncation(prefix)
                prefixes += 1
                high_prefixes += result["high_floor"]

                # Interpret the existing trajectory at band floor u, up to
                # its first shortcut descent below u.  No new orbit is searched.
                if min(prefix[:-1]) < u:
                    continue
                H = (4*u-2)//3
                visits = [i for i, x in enumerate(prefix) if x & 1 and u <= x <= H]
                assert visits and visits[0] == 0
                assert len({prefix[i] for i in visits}) == len(visits)
                factors = Q(1)
                for start, stop in zip(visits, visits[1:]):
                    part = prefix[start:stop+1]
                    assert all(x > H for x in part[1:-1])
                    factors *= normalized(part)
                tail = prefix[visits[-1]:]
                factors *= normalized(tail)
                assert factors == normalized(prefix)
                chain_checks += 1
                multi_return_checks += len(visits) >= 3 and visits[-1] < end
            if min(x for x in path[:-1] if x & 1) >= M0:
                mid = (len(path)-1)//2
                left, right = path[:mid+1], path[mid:]
                remaining = R_BAR-reciprocal(left)
                assert remaining > 0
                assert reciprocal(right) < remaining
                assert product(right) < exp10(remaining/3)
                assert product(right) < GAMMA/product(left)
                remaining_checks += 1
    return {"seed_sha256": hashlib.sha256(raw).hexdigest(), "saved_paths": paths,
            "shortcut_prefix_controls": prefixes, "high_floor_prefixes": high_prefixes,
            "chain_plus_tail_telescoping_controls": chain_checks,
            "multiple_completed_returns_with_tail": multi_return_checks,
            "remaining_budget_controls": remaining_checks}


def explicit_controls() -> dict:
    # Distinct charged odds need not imply distinct full shortcut inputs.
    path = [3, 5, 8, 4, 2, 1, 2, 1]
    r = check_truncation(path)
    assert not r["full_shortcut_inputs_distinct"] and r["cut"] == 6
    assert product(path) == Q(128, 81)
    assert check_truncation([8, 4, 2, 1])["odd_inputs"] == 0
    examples = []
    for h in (37, 80, 160):
        u = (4**h-1)//3
        assert u >= M0 and u & 1 and 3*u+1 == 4**h
        path = [u]
        for _ in range(2*h):
            path.append(T(path[-1]))
        assert path[-1] == 1
        result = check_truncation(path)
        assert result["cut"] == 1
        assert product(path) == Q(4**h, 4**h-1)
        rho = normalized(path)
        assert rho == Q(6*4**h, 4**h+14)
        assert Q(3, 2) < rho < 6
        # Stopping at the first shortcut output below u does retain the cap.
        crossing = next(i for i, x in enumerate(path) if x < u)
        first_exit = path[:crossing+1]
        assert 2*first_exit[-1] >= u
        assert normalized(first_exit) < GAMMA
        if u >= 1 << 190:
            assert product(path)-1 < Q(21, 125)
            assert normalized(first_exit)-1 < Q(21, 125)
        examples.append({"h": h, "source": str(u),
                         "raw_G": enc(product(path)), "rho_to_one": enc(rho),
                         "first_shortcut_exit_rho": enc(normalized(first_exit))})
    return {"small_structural_control": "3,5,8,4,2,1,2,1; the high-floor theorem is not invoked on this control.",
            "arbitrarily_high_terminal_descent_family": "u=(4^h-1)/3 -> 1",
            "examples": examples}


def saved_chain_controls(path: Path) -> dict:
    raw = path.read_bytes()
    data = json.loads(raw)
    prefixes = multi = 0
    for group in data["groups"]:
        n, current = group["n"], group["initial_source"]
        H = (4*n-2)//3
        full = [current]
        for record in group["records"]:
            assert current == record["u"]
            for e in record["word"]:
                num = 3*current+1
                assert (num & -num).bit_length()-1 == e
                for _ in range(e):
                    full.append(T(full[-1]))
                current = full[-1]
            assert current == record["output"]
        for end in range(1, len(full)):
            prefix = full[:end+1]
            check_truncation(prefix)
            assert min(prefix[:-1]) >= n
            visits = [i for i, x in enumerate(prefix) if x & 1 and n <= x <= H]
            assert visits[0] == 0
            assert len({prefix[i] for i in visits}) == len(visits)
            factors = Q(1)
            for a, b in zip(visits, visits[1:]):
                assert all(x > H for x in prefix[a+1:b])
                factors *= normalized(prefix[a:b+1])
            factors *= normalized(prefix[visits[-1]:])
            assert factors == normalized(prefix)
            prefixes += 1
            multi += len(visits) >= 3 and visits[-1] < end
    assert multi > 0
    return {"file_sha256": hashlib.sha256(raw).hexdigest(),
            "original_saved_seed_sha256": data["source_sha256"],
            "chains": len(data["groups"]), "shortcut_prefixes": prefixes,
            "at_least_two_completed_returns_plus_nonempty_tail": multi}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=Path,
                        default=ROOT/"central_bound_work"/"incoming_eleven_saved_groups.json")
    parser.add_argument("--canonical", type=Path,
                        default=ROOT/"overlap_continuation_work"/"residue_canonical_certificate.json")
    parser.add_argument("--canonical-audit", type=Path,
                        default=ROOT/"overlap_continuation_work"/"residue_canonical_independent_audit.json")
    parser.add_argument("--chains", type=Path,
                        default=HERE/"saved_completed_chains.json")
    parser.add_argument("--output", type=Path,
                        default=HERE/"unfinished_tail_truncation_certificate.json")
    args = parser.parse_args()
    constants = constant_checks(args.canonical, args.canonical_audit)
    saved = saved_path_checks(args.seeds)
    explicit = explicit_controls()
    chains = saved_chain_controls(args.chains)
    result = {"scope": "Arbitrary-length finite tails with distinct high charged odd inputs; exact chain telescoping and endpoint normalization. No cycle exclusion or unrestricted profile-sum bound.",
              "constants": constants, "saved_path_checks": saved,
              "saved_chain_checks": chains, "explicit_controls": explicit,
              "checks_passed": True}
    args.output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(f"PASS: {saved['saved_paths']} saved paths, {saved['shortcut_prefix_controls']} shortcut-prefix controls.")
    print(f"PASS: {saved['high_floor_prefixes']} high-floor prefix controls and {saved['chain_plus_tail_telescoping_controls']} chain/tail identities.")
    print(f"PASS: {chains['chains']} saved completed chains, including {chains['at_least_two_completed_returns_plus_nonempty_tail']} multi-return tail controls.")
    print("PASS: exact 367/250 endpoint cap and the high-source terminal-descent counterfamily.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
