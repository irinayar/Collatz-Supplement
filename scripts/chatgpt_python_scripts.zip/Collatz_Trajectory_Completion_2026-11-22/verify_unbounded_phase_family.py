#!/usr/bin/env python3
"""Exact mechanical-word first returns with unbounded phase.

All comparisons and trajectory checks use integers or Fraction.  The analytic
proof of infinitely many qualifying lengths is in Unbounded_Phase_First_Returns.md;
the finite examples here are reproducible witnesses, not that infinite proof.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")


def ceildiv(a: int, b: int) -> int:
    assert b > 0
    return -((-a) // b)


def rational(x: Fraction) -> dict[str, int]:
    return {"numerator": x.numerator, "denominator": x.denominator}


def valuation2(x: int) -> int:
    assert x > 0
    return (x & -x).bit_length() - 1


def word_data(g: int) -> dict:
    assert g >= 3
    powers3 = [3**i for i in range(g + 1)]
    cumulative = [p.bit_length() - 1 for p in powers3[:-1]]
    cumulative.append(powers3[-1].bit_length())
    E = cumulative[-1]
    assert 3 * (1 << E) < 4 * powers3[-1] < 4 * (1 << E)
    exponents = [cumulative[i + 1] - cumulative[i] for i in range(g)]
    assert exponents[:2] == [1, 2]
    assert min(exponents) >= 1 and exponents[-1] >= 2
    numerators = [0]
    for i in range(g):
        numerators.append(3 * numerators[-1] + (1 << cumulative[i]))
    B = numerators[-1]
    Q = Fraction(B, powers3[-1])
    assert Q == sum((Fraction(1 << cumulative[i], powers3[i + 1])
                     for i in range(g)), Fraction(0))
    assert Fraction(g + 1, 6) < Q <= Fraction(g, 3)
    assert all(powers3[i] > 1 << cumulative[i] for i in range(1, g))
    modulus = 1 << (E + 1)
    residue = (((1 << E) - B) * pow(powers3[-1], -1, modulus)) % modulus
    assert residue % 16 == 11
    return dict(g=g, powers3=powers3, cumulative=cumulative,
                exponents=exponents, numerators=numerators, E=E, B=B,
                Q=Q, modulus=modulus, residue=residue)


def construct(g: int, floor: int = 1 << 71) -> dict:
    d = word_data(g)
    P, M, a, E, B = d["powers3"][-1], d["modulus"], d["residue"], d["E"], d["B"]
    twoE = 1 << E
    lower = max(3, ceildiv(4 * floor, 3) - 1,
                ceildiv(B, twoE - P),
                ceildiv(3 * twoE - 4 * B, 4 * P - 3 * twoE))
    lift = max(0, ceildiv(lower - a, M))
    u = a + M * lift
    assert u % 8 == 3
    n = 3 * (u + 1) // 4
    H = (4 * n - 2) // 3
    assert n % 2 == 1 and n >= floor and H == u

    # Independently recover the exact complete-word feasible interval, then
    # choose its least cylinder member.  This allows arbitrarily large lifts.
    L = n
    for i in range(1, g):
        L = max(L, ((1 << d["cumulative"][i]) * H - d["numerators"][i])
                // d["powers3"][i] + 1)
    L = max(L, ceildiv(twoE * n - B, P))
    U = min(H, (twoE * H - B) // P)
    least = a + ceildiv(L - a, M) * M
    assert L <= least <= U and least <= u

    def replay(start: int) -> list[int]:
        states = [start]
        for e in d["exponents"]:
            value = 3 * states[-1] + 1
            assert valuation2(value) == e
            states.append(value >> e)
        assert all(x > H for x in states[1:-1])
        assert n <= states[0] <= H and n <= states[-1] <= H
        assert len(set(states[:-1])) == g
        assert twoE * states[-1] == P * start + B
        correction = Fraction(1)
        for x in states[:-1]:
            correction *= Fraction(3 * x + 1, 3 * x)
        assert correction == 1 + d["Q"] / start
        rho = correction * Fraction(states[-1] + 5, states[-1]) * Fraction(start, start + 5)
        assert rho - 1 == (d["Q"] + 5 * (Fraction(twoE, P) - 1)) / (start + 5)
        assert rho > 1
        assert correction < Fraction(47, 32)
        return states

    lifted_states = replay(u)
    least_states = replay(least)
    assert least - M < L
    return {
        "g": g, "E": E, "reset_count": sum(e >= 2 for e in d["exponents"]),
        "exponents": d["exponents"], "cumulative_exponents": d["cumulative"],
        "numerator_B": B, "phase_Q": rational(d["Q"]),
        "lambda": rational(Fraction(P, twoE)),
        "phase_exceeds_g_over_6": True,
        "modulus": M, "residue": a, "lift_parameter": lift,
        "threshold_n": n, "H": H, "constructed_source": u,
        "feasible_interval": [L, U], "least_source": least,
        "least_endpoint": least_states[-1], "least_states": least_states,
        "constructed_states": lifted_states, "positive_charge": True,
        "charge": rational((d["Q"] + 5 * (Fraction(twoE, P) - 1)) / (least + 5)),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("unbounded_phase_family_certificate.json"))
    args = parser.parse_args()
    # Seven separate lengths exercise both lifted and least-representative cases.
    lengths = [20, 37, 46, 70, 80, 150, 200]
    examples = [construct(g) for g in lengths]
    witness = next(x for x in examples if x["g"] == 46)
    assert witness["constructed_source"] == witness["least_source"] == 9420305793941977848827
    assert witness["threshold_n"] == 7065229345456483386621
    assert witness["least_endpoint"] == 8840015659815569560675
    assert Fraction(witness["phase_Q"]["numerator"], witness["phase_Q"]["denominator"]) > 11
    report = {
        "status": "PASS",
        "arithmetic": "integer and fractions.Fraction only",
        "claim": "explicit genuine positive least-source first returns with arbitrarily large phase",
        "infinite_part": "proved analytically in companion note; finite witnesses do not replace it",
        "not_claimed": ["counterexample to the central bound", "nontrivial Collatz cycle", "divergent orbit"],
        "examples": examples,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "examples": len(examples),
                      "odd_transitions_checked": 2 * sum(lengths), "witness_g": 46,
                      "witness_Q": witness["phase_Q"]}))


if __name__ == "__main__":
    main()
