#!/usr/bin/env python3
"""Reproduce the four new trajectory-completion certificates independently.

Run from any working directory.  Prior canonical packing certificates are
inputs; their large dynamic program is deliberately not rerun by this script.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SPECS = [
    ("verify_unfinished_tail_truncation.py", "unfinished_tail_truncation_certificate.json"),
    ("verify_exact_repetition_and_cycles.py", "exact_repetition_cycle_certificate.json"),
    ("verify_unbounded_phase_family.py", "unbounded_phase_family_certificate.json"),
    ("verify_nineteen_note_audit.py", "nineteen_note_audit_certificate.json"),
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reproduce(spec: tuple[str, str], destination: Path) -> dict:
    script_name, certificate_name = spec
    script = HERE / script_name
    expected = HERE / certificate_name
    fresh = destination / certificate_name
    run = subprocess.run([sys.executable, "-B", str(script), "--output", str(fresh)],
                         cwd=ROOT, text=True, encoding="utf-8",
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if run.returncode != 0:
        raise RuntimeError(f"{script_name} failed:\n{run.stdout}\n{run.stderr}")
    if fresh.read_bytes() != expected.read_bytes():
        raise AssertionError(f"Fresh output differs from saved {certificate_name}")
    return {"verifier": script_name, "verifier_sha256": digest(script),
            "certificate": certificate_name, "certificate_sha256": digest(expected),
            "fresh_output_byte_identical": True, "return_code": run.returncode}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=HERE / "trajectory_completion_reproduction.json")
    parser.add_argument("--jobs", type=int, choices=range(1, 5), default=4)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="collatz_completion_verify_") as temporary:
        destination = Path(temporary)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            records = list(pool.map(lambda spec: reproduce(spec, destination), SPECS))
    report = {"status": "PASS", "fresh_certificates": len(records), "results": records,
              "scope": "Four new exact verifiers; no prior large packing DP or external census rerun.",
              "unrestricted_cycle_exclusion_proved": False,
              "unrestricted_central_budget_proved": False}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("PASS: four freshly generated certificates match the saved outputs byte for byte.")
    for record in records:
        print(f"PASS: {record['verifier']}")


if __name__ == "__main__":
    main()
