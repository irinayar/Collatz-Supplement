#!/usr/bin/env python3
"""Focused independent controls of nineteen incoming Collatz notes.

Uses 23 cached paths, a nine-source n=55 control, and a few explicit examples.
Does not import external verifiers or repeat any large source/fibre census.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from math import factorial
from pathlib import Path

HERE=Path(__file__).resolve().parent
A=F(47,32)


def ceil_div(a,b):return -((-a)//b)
def step(x):
    z=3*x+1;e=(z&-z).bit_length()-1
    return z>>e,e
def shortcut(x):return (3*x+1)//2 if x%2 else x//2
def affine(word):
    E=D=0;rows=[(0,0)]
    for e in word:
        D=3*D+(1<<E);E+=e;rows.append((E,D))
    return rows
def least_source(n,word):
    H=(4*n-2)//3;g=len(word);rows=affine(word);E,D=rows[-1]
    lo=n
    for i,(Ei,Di) in enumerate(rows[1:-1],1):lo=max(lo,((1<<Ei)*H-Di)//3**i+1)
    lo=max(lo,ceil_div((1<<E)*n-D,3**g))
    hi=min(H,((1<<E)*H-D)//3**g)
    modulus=1<<(E+1);a=(((1<<E)-D)*pow(3**g,-1,modulus))%modulus
    candidate=lo+(a-lo)%modulus
    return candidate if candidate<=hi else None


def decode_phase(n,Q):
    denominator=Q.denominator;g=0
    while denominator%3==0:denominator//=3;g+=1
    assert denominator==1 and g>=2
    numerator=Q.numerator;current=numerator;prefix=[]
    for r in range(g,1,-1):
        remainder=current-3**(r-1)
        assert remainder>0 and remainder%2==0
        e=(remainder&-remainder).bit_length()-1
        prefix.append(e);current=remainder>>e
    assert current==1 and prefix[0]==1
    H=(4*n-2)//3
    lower=F(3**g*n+numerator,H);upper=F(3**g*H+numerator,n)
    assert upper/lower<2
    E=0
    while (1<<E)<lower:E+=1
    assert (1<<E)<=upper
    final=E-sum(prefix);assert final>=2
    return tuple(prefix+[final])


def replay(n,u,word):
    H=(4*n-2)//3;states=[u]
    for e in word:
        x,actual=step(states[-1]);assert actual==e;states.append(x)
    assert n<=u<=H and n<=states[-1]<=H and all(x>H for x in states[1:-1])
    rows=affine(word);g=len(word);E,D=rows[-1]
    assert (1<<E)*states[-1]==3**g*u+D
    Q=F(D,3**g);G=1+Q/u
    assert G<A and D%3 and D%4==(5*3**(g-2))%4
    assert decode_phase(n,Q)==tuple(word)
    assert least_source(n,word)==u
    phases=[F(Di,3**i) for i,(Ei,Di) in enumerate(rows)]
    for i in range(g):assert phases[i+1]-phases[i]==(u+phases[i])/(3*states[i])
    proper=[i for i in range(1,g) if word[i-1]>=2]
    tests=nonempty=0
    for B in (F(0),F(1,10),F(1),F(5)):
        chosen=[i for i in proper if phases[i]>B and Q-phases[i]>B]
        mass=sum((F(1,states[i]) for i in chosen),F(0))
        Z=max(F(0),Q-2*B)
        bound=3*Z/(u+B)+(A/(H+1) if Q>2*B else 0)
        assert mass<=bound
        tests+=1;nonempty+=bool(chosen)
    return {'g':g,'Q':Q,'tests':tests,'nonempty':nonempty,'states':states}


def progression_controls():
    answer=[];coefficient=A-1
    for a,m,c,t in [(55,4,5,F(0)),(55,8,3,F(2)),(11,16,0,F(5)),
                    (3,4,7,F(45,32)),(7,32,4,F(200)),(9,2,8,F(10))]:
        cut=(t/coefficient-a)/m
        j=max(0,min(c,cut.numerator//cut.denominator+1));k=c-j
        formula=coefficient*(k*a+F(m*k*(j+c-1),2))-k*t
        direct=sum((max(F(0),coefficient*(a+i*m)-t) for i in range(c)),F(0))
        assert formula==direct
        answer.append(str(direct))
    return answer


def tiny_frontier():
    n=55;H=72;records=[]
    for u in range(n,H+1,2):
        x=u;word=[];D=E=0
        for g in range(1,129):
            x,e=step(x);word.append(e);D=3*D+(1<<E);E+=e
            if x<=H:break
        else:raise AssertionError('The deliberately tiny control did not finish.')
        records.append({'u':u,'g':g,'w':x,'Q':F(D,3**g),'genuine':x>=n})
    genuine=[r for r in records if r['genuine']]
    assert [(r['u'],r['g']) for r in genuine]==[(59,2),(63,34),(71,32)]
    previous=None;weights={}
    for d in range(65):
        active=[r for r in records if r['g']>d]
        capacity=sum((max(F(0),(A-1)*r['u']-2) for r in active),F(0))
        remaining=sum((max(F(0),r['Q']-2) for r in genuine if r['g']>d),F(0))
        completed=sum((max(F(0),r['Q']-2) for r in genuine if r['g']<=d),F(0))
        assert remaining<=capacity
        total=completed+capacity
        if previous is not None:assert total<=previous
        previous=total
        if d in (8,16,32,64):weights[d]=str(capacity)
    assert weights=={8:'941/16',16:'941/16',32:'881/32',64:'0'}
    return {'odd_sources':9,'genuine_sources':3,'depth_capacities_t2':weights}


def high_tail(L,S):
    return F(3**S-1,1<<L)+F(200,7)*F(193,200)**(S+1)+F(L+1,1<<(L-1))
def optimal_split(L):
    S=0
    # Difference B(L,S+1)-B(L,S) has one sign change, since its
    # positive/negative term ratio grows by 3/(193/200)>1.
    while F(2*3**S,1<<L)<F(193,200)**(S+1):S+=1
    return S
def exp_upper(z):
    assert 0<=z<1
    return sum((z**j/factorial(j) for j in range(13)),F(0))+z**13/factorial(13)/(1-z/14)
def tail_controls():
    first={}
    for L in range(71,205):
        S=optimal_split(L);budget=high_tail(L,S)
        assert high_tail(L,S+1)>=budget
        if S:assert high_tail(L,S-1)>=budget
        linear=A*(budget/3+F(5,4*(1<<L)))
        for name,target in [('linear_117_250',F(117,250)),('linear_21_125',F(21,125))]:
            if linear<target and name not in first:first[name]={'L':L,'S':S,'upper':str(linear),'display_only':float(linear)}
        if budget<3:
            bound=exp_upper(budget/3)-1
            if bound<F(21,125) and 'unfinished_21_125' not in first:
                first['unfinished_21_125']={'L':L,'S':S,'upper':str(bound),'display_only':float(bound)}
    assert (first['linear_117_250']['L'],first['linear_117_250']['S'])==(157,96)
    assert (first['linear_21_125']['L'],first['linear_21_125']['S'])==(204,125)
    assert (first['unfinished_21_125']['L'],first['unfinished_21_125']['S'])==(190,116)
    z=high_tail(190,116)/3
    exp10=sum((z**j/factorial(j) for j in range(11)),F(0))+z**11/factorial(11)/(1-z/12)
    half_floor=exp10*(1+F(10,1<<190))-1
    assert half_floor<F(164294642,10**9)<F(21,125)
    first['half_floor_endpoint_21_125']={
        'L':190,'S':116,'upper':str(half_floor),'display_only':float(half_floor),
        'scope':'Distinct charged odd inputs at least 2^190; normalized endpoint at least half that floor. Raw G needs no endpoint restriction.'}
    return first


def finite_example_controls():
    checks=0
    for h in (0,1,31):
        for source,target,word,steps,expected in [
            (31+32768*h,91+93312*h,'11111010',8,91+93312*h),
            (127+2048*h,273+4374*h,'11111110',8,4*(273+4374*h)+1),
            (95+128*h,121+162*h,'1111100',7,(3*(121+162*h)+1)//2)]:
            assert source<target;x=source;bits=''
            for i in range(steps):bits+=str(x%2);x=shortcut(x)
            assert bits==word and x==expected;checks+=1
    lifts=[]
    for source,endpoint in [(23207,22331),(68711,66113)]:
        for t in (0,1,1<<80):
            u=source+(1<<27)*3**10*t;target=endpoint+3**27*t
            x=u;a=0;path=[x]
            for j in range(27):a+=x%2;x=shortcut(x);path.append(x)
            assert x==target and a==17 and all(v>=u for v in path[:-1]) and x<u
            assert len(set(path[:-1]))==27
            assert 3**17<1<<27 and 32*(1<<27)<47*3**17
            lifts.append({'seed':source,'t':str(t),'first_descent':27})
    n=10697;u=13503;H=(4*n-2)//3;x=u;word=[];states=[x]
    for i in range(100):
        x,e=step(x);word.append(e);states.append(x)
        if x<=H:break
    assert len(word)==48 and x==14261 and max(states[:-1])==350837
    E,D=affine(word)[-1];Q=F(D,3**48)
    assert F(557,100)<Q<F(558,100)
    assert sum(v<2*H for v in states[:-1])==11
    # A numerator without its depth does not identify an arbitrary word.
    assert affine([1,8,2])[-1][1]==affine([1,2,3,1,2])[-1][1]==527
    return {'affine_meeting_checks':checks,'lift_controls':lifts,
            'reported_record_replayed':{'n':n,'u':u,'g':48,'endpoint':x,'Q':str(Q),'display_only':float(Q)},
            'relaxed_numerator_collision_D527':'The first word is not a genuine band return; this illustrates only why the rational-phase decoder uses g.'}


def unbounded_phase_witness():
    g=46;u=9420305793941977848827;n=7065229345456483386621
    P=3**g;E=P.bit_length()
    cumulative=[(3**i).bit_length()-1 for i in range(g)]+[E]
    word=tuple(cumulative[i+1]-cumulative[i] for i in range(g))
    assert 3*(1<<E)<4*P<4*(1<<E)
    assert n==3*(u+1)//4 and (4*n-2)//3==u and n>=1<<71
    record=replay(n,u,word)
    assert record['states'][-1]==8840015659815569560675
    expected=F(98878719971867038884317,8862938119652501095929)
    assert record['Q']==expected>11
    assert F(g+1,6)<record['Q']<=F(g,3)
    for i in range(1,g):assert 3**i>1<<cumulative[i]
    charge=(record['Q']+5*(F(1<<E,P)-1))/(u+5)
    assert charge>0
    proper=[i for i in range(1,g) if word[i-1]>=2]
    interior=[i for i in proper if cumulative[i]+record['states'][i].bit_length()-1<E]
    assert not interior
    return {'g':g,'n':n,'u':u,'endpoint':record['states'][-1],'Q':str(expected),
            'Q_display_only':float(expected),'positive_charge':str(charge),
            'least_source_verified':True,'proper_reset_arrivals':len(proper),
            'interior_canonical_proper_reset_arrivals':0,
            'scope':'Refutes constant phase cap six; all proper reset starts of this witness are canonical-terminal, so its current central core is empty.'}


def repetition_controls():
    controls=0
    for word,u in [((1,),3),((1,),7),((1,2),123),((1,2),139),
                   ((1,1,1,1,4),60511),((1,1,1,1,4),57439)]:
        E,B=affine(word)[-1];Aword=3**len(word);Dword=1<<E
        defect=(Dword-Aword)*u-B
        assert defect!=0 and defect%2==0
        valuation=(abs(defect)&-abs(defect)).bit_length()-1
        maximum=(valuation-1)//E
        for copies in range(maximum+2):
            x=u;realized=True
            for e in word*copies:
                x,actual=step(x)
                if actual!=e:realized=False;break
            assert realized==(valuation>=copies*E+1)
            if copies and realized:
                S=sum(Dword**(copies-1-j)*Aword**j for j in range(copies))
                assert S%2 and (Dword-Aword)*S==Dword**copies-Aword**copies
                t=defect//(2*Dword**copies)
                assert defect==2*Dword**copies*t and x==u-2*t*S
            controls+=1
    word=(1,1,1,1,4);E,B=affine(word)[-1];Aword=3**5;Dword=1<<E
    assert (Aword,Dword,B)==(243,256,211)
    high_t=1<<80
    u0=60511+131072*high_t;u1=57439+124416*high_t
    n=54523+118098*high_t;H=(4*n-2)//3
    assert n>=1<<71 and H==72696+157464*high_t
    assert least_source(n,word)==u1
    charges=[]
    for u,v in [(u0,u1),(u1,n)]:
        states=[u]
        for e in word:
            x,actual=step(states[-1]);assert actual==e;states.append(x)
        assert states[-1]==v and n<=u<=H and n<=v<=H
        assert all(x>H for x in states[1:-1])
        charge=F(Dword*(v+5),Aword*(u+5))-1
        assert charge==F(92,81*(u+5))>0
        charges.append(charge)
    assert u0-n==2*(Aword+Dword)*(6+13*high_t)
    return {'exact_copy_count_controls':controls,'positive_family_high_t':str(high_t),
            'threshold':str(n),'first_source':str(u0),'least_source':str(u1),
            'charges':[str(c) for c in charges],
            'scope':'Independent compact replay of the exact repetition converse/lattice and one high positive two-return family; no cycle census.'}


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seeds',type=Path,default=HERE/'incoming_nineteen_saved_groups.json')
    parser.add_argument('--output',type=Path,default=HERE/'nineteen_note_audit_certificate.json')
    args=parser.parse_args();raw=args.seeds.read_bytes();data=json.loads(raw)
    paths=tests=nonempty=0
    for group in data['groups']:
        for source in group['sources']:
            record=replay(group['n'],source['u'],tuple(source['word']))
            paths+=1;tests+=record['tests'];nonempty+=record['nonempty']
    assert paths==23
    result={'status':'PASS','seed_sha256':sha256(raw).hexdigest(),'saved_paths':paths,
            'phase_decoder_least_source_checks':paths,'phase_excess_controls':tests,'nonempty_phase_excess_controls':nonempty,
            'progression_moments':progression_controls(),'tiny_source_frontier':tiny_frontier(),
            'canonical_tail_conversion':tail_controls(),'explicit_examples':finite_example_controls(),
            'unbounded_phase_witness':unbounded_phase_witness(),
            'exact_repetition_and_positive_occurrences':repetition_controls(),
            'scope':['No broad source census or large external executable suite was rerun.',
                     'K166 global minimum fibre counts remain source-reported; the stated trajectories/lift identities were checked independently.',
                     'Finite empirical phase maxima are not adopted as uniform bounds.',
                     'Distinct-input estimates do not apply to repeated cycle traversals.']}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','saved_paths':paths,'phase_excess_controls':tests,
                      'nonempty_controls':nonempty,'output':str(args.output)},indent=2))


if __name__=='__main__':main()
