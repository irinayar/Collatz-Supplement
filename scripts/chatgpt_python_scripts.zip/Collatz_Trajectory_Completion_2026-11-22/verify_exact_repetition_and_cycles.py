#!/usr/bin/env python3
"""Exact checks for repetition costs and cycle/occurrence identities.

This is not a search for high positive cycles and does not re-prove the imported
canonical packing bound. All arithmetic is integer or Fraction arithmetic.
The positive fixed point 1 is used only as an explicitly ineligible control.
"""
from __future__ import annotations

from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json


def v2(x: int) -> int:
    assert x != 0
    a = abs(x)
    return (a & -a).bit_length() - 1


def compositions(total: int):
    if total == 0:
        yield ()
        return
    for first in range(1, total + 1):
        for tail in compositions(total - first):
            yield (first,) + tail


def affine(word):
    b = e_total = 0
    for e in word:
        assert e >= 1
        b = 3*b + (1 << e_total)
        e_total += e
    return 3**len(word), 1 << e_total, b, e_total


def odd_step(x: int):
    assert x > 0 and x % 2 == 1
    numerator = 3*x + 1
    e = v2(numerator)
    return numerator >> e, e


def follow_word(source: int, word):
    states = [source]
    for e in word:
        arrival, actual_e = odd_step(states[-1])
        if actual_e != e:
            return None
        states.append(arrival)
    return states


def phi(x):
    return 1 + Q(5, x)


def sum_polynomial(a, d, k):
    assert k >= 1
    # No logarithmic rounding is used for the band-width bound.
    result = 0
    for j in range(k):
        result += d**(k-1-j)*a**j
    assert (d-a)*result == d**k-a**k
    assert result % 2 == 1
    assert result >= max(a, d)**(k-1)
    return result


def exact_word_checks():
    words = source_checks = cylinder_lifts = maximal_failures = 0
    periodic_controls = 0
    longest_finite_count = 0
    for total_e in range(1, 11):
        for word in compositions(total_e):
            words += 1
            a, d, b, e = affine(word)
            defect_coefficient = d-a
            assert b % 2 == 1 and defect_coefficient % 2 == 1

            # Every formal word has an exact odd 2-adic periodic realization.
            periodic_point = Q(b, defect_coefficient)
            x = periodic_point
            assert x.numerator % 2 and x.denominator % 2
            for exponent in word:
                z = 3*x+1
                assert v2(z.numerator)-v2(z.denominator) == exponent
                x = z / (1 << exponent)
                assert x.numerator % 2 and x.denominator % 2
            assert x == periodic_point

            for copies in (1, 2, 3):
                s = sum_polynomial(a, d, copies)
                ar, dr, br, er = affine(word*copies)
                assert (ar, dr, br, er) == (a**copies, d**copies,
                                             b*s, e*copies)
                modulus = 2*dr
                residue = (b*pow(defect_coefficient, -1, modulus)) % modulus
                cylinder = ((dr-br)*pow(ar, -1, modulus)) % modulus
                assert residue == cylinder and residue % 2
                replay = follow_word(residue, word*copies)
                assert replay is not None
                # Dropping the final odd-arrival bit gives the ordinary
                # inverse length-er shortcut-parity residue.
                parity_residue = (-br*pow(ar, -1, dr)) % dr
                assert residue % dr == parity_residue
                cylinder_lifts += 1

            for source in range(1, 64, 2):
                source_checks += 1
                z = defect_coefficient*source-b
                assert z % 2 == 0
                one_word = follow_word(source, word)
                assert (one_word is not None) == ((a*source+b-d) % (2*d) == 0)
                if z == 0:
                    # Diagnostic only; never a high/nontrivial candidate.
                    assert source == 1 and all(exponent == 2 for exponent in word)
                    assert source < (1 << 71)
                    replay = follow_word(source, word*5)
                    assert replay is not None and replay[-1] == source
                    periodic_controls += 1
                    continue
                maximum = (v2(z)-1)//e
                assert maximum >= 0
                longest_finite_count = max(longest_finite_count, maximum)
                for copies in range(maximum+2):
                    replay = follow_word(source, word*copies)
                    predicted = v2(z) >= copies*e+1
                    assert (replay is not None) == predicted
                    if copies == maximum+1:
                        assert replay is None
                        maximal_failures += 1
                    if copies and replay is not None:
                        s = sum_polynomial(a, d, copies)
                        assert z % (2*d**copies) == 0
                        integer_t = z // (2*d**copies)
                        assert integer_t != 0
                        assert replay[-1] == source-2*integer_t*s
                        assert abs(source-replay[-1]) >= 2*s
                        assert 2*d**copies <= abs(z) <= abs(defect_coefficient)*source+b
                        assert maximum <= ((abs(z).bit_length()-1)-1)//e
                if one_word is not None:
                    difference = source-one_word[-1]
                    assert difference != 0
                    assert z == d*difference
                    assert maximum == 1+(v2(difference)-1)//e
    assert words == 1023 and source_checks == 32736
    return dict(words=words, odd_sources_per_word=32, source_word_cases=source_checks,
                periodic_cylinder_lifts=cylinder_lifts,
                next_copy_failures=maximal_failures,
                ineligible_fixed_point_controls=periodic_controls,
                maximum_finite_copy_count_in_diagnostic=longest_finite_count)


def genuine(word, source, n):
    h = (4*n-2)//3
    states = follow_word(source, word)
    assert states is not None
    assert n <= states[0] <= h and n <= states[-1] <= h
    assert all(x > h for x in states[1:-1])
    return states


def band_examples():
    word = (1, 2)
    first = genuine(word, 123, 119)
    second = genuine(word, first[-1], 119)
    assert first == [123, 185, 139]
    assert second == [139, 209, 157]
    a, d, b, e = affine(word)
    assert second[-1]-first[0] == 2*sum_polynomial(a, d, 2) == 34

    positive_word = (1, 1, 1, 1, 4)
    a, d, b, e = affine(positive_word)
    assert (a, d, b, e) == (243, 256, 211, 8)
    assert Q(b+5*(d-a), a) == Q(92, 81)
    # Coefficient identities for the entire affine t-family.
    pairs = ((60511, 131072), (57439, 124416), (54523, 118098))
    for source_pair, arrival_pair in zip(pairs, pairs[1:]):
        assert a*source_pair[0]+b == d*arrival_pair[0]
        assert a*source_pair[1] == d*arrival_pair[1]
    assert 4*54523-2 == 3*72696+2
    assert 4*118098 == 3*157464
    assert 90767 > 72696 and 196608 > 157464
    assert 86159 > 72696 and 186624 > 157464
    assert 72696 > 60511 > 57439 > 54523
    assert 157464 > 131072 > 124416 > 118098
    assert ((d-a)*60511-b, (d-a)*131072) == (2*d*d*6, 2*d*d*13)

    examples = []
    for t in (0, 1, 2, 98, 1 << 80):
        u0 = 60511+131072*t
        u1 = 57439+124416*t
        n = 54523+118098*t
        h = (4*n-2)//3
        assert h == 72696+157464*t
        path1 = genuine(positive_word, u0, n)
        path2 = genuine(positive_word, u1, n)
        assert path1[-1] == u1 and path2[-1] == n
        all_odd_states = path1[:-1]+path2
        assert len(all_odd_states) == len(set(all_odd_states))
        delta0 = Q(d*(u1+5), a*(u0+5))-1
        delta1 = Q(d*(n+5), a*(u1+5))-1
        assert delta0 == Q(92, 81*(u0+5)) > 0
        assert delta1 == Q(92, 81*(u1+5)) > 0
        assert delta0+delta1 > delta1
        assert u0-n == 2*(a+d)*(6+13*t)
        if t == 1 << 80:
            assert n >= 1 << 71
        examples.append(dict(t=str(t), source0=str(u0), least_word_source=str(u1),
                             threshold=str(n), band_upper=str(h),
                             high_floor=n >= 1 << 71,
                             first_charge=str(delta0), least_source_charge=str(delta1),
                             occurrence_sum=str(delta0+delta1)))
    return dict(sharp_displacement_example=dict(word=[1, 2], n=119, H=158,
                                               path=first[:-1]+second,
                                               displacement=34),
                positive_word=list(positive_word), positive_family_examples=examples,
                scope="Two genuine positive g=5 returns at distinct sources; not a residual-core counterexample.")


def shortcut(x):
    return (3*x+1)//2 if x % 2 else x//2


def path_data(inputs):
    reciprocal = Q(0)
    correction = Q(1)
    for x in inputs:
        if x % 2:
            reciprocal += Q(1, x)
            correction *= 1+Q(1, 3*x)
    return reciprocal, correction


def lasso_checks():
    rows = []
    tests = 0
    for start in (1, 2, 3, 5, 7, 11, 27, 31, 97, 871):
        states = [start]
        positions = {start: 0}
        while True:
            nxt = shortcut(states[-1])
            if nxt in positions:
                mu = positions[nxt]
                tau = len(states)
                states.append(nxt)
                break
            positions[nxt] = len(states)
            states.append(nxt)
            assert len(states) < 10000
        assert len(set(states[:-1])) == tau
        period = states[mu:tau]
        p = len(period)
        g = sum(x % 2 for x in period)
        r_a, g_a = path_data(states[:mu])
        r_c, g_c = path_data(period)
        assert g >= 1 and g_c == Q(1 << p, 3**g) > 1
        assert min(period) < (1 << 71)  # Ineligible diagnostic, never a high cycle.
        for copies in range(5):
            for remainder in range(p):
                length = mu+copies*p+remainder
                actual = [start]
                for _ in range(length):
                    actual.append(shortcut(actual[-1]))
                r_r, g_r = path_data(period[:remainder])
                reciprocal, correction = path_data(actual[:-1])
                assert reciprocal == r_a+copies*r_c+r_r
                assert correction == g_a*g_c**copies*g_r
                rho = correction*phi(actual[-1])/phi(start)
                rho_a = g_a*phi(states[mu])/phi(start)
                rho_r = g_r*phi(period[remainder])/phi(period[0])
                assert rho == rho_a*g_c**copies*rho_r
                tests += 1
        rows.append(dict(source=start, transient_shortcut_steps=mu,
                         period_shortcut_steps=p, period_odd_inputs=g,
                         period_multiplier=str(g_c),
                         eligible_high_floor_cycle=False))

    # Mixed-sign potential identity on a positive rational 2-adic period.
    # It is explicitly not an ordinary-integer cycle candidate.
    word = (1, 2, 2)
    a, d, b, e = affine(word)
    x0 = Q(b, d-a)
    assert x0 == Q(23, 5) and x0.denominator != 1
    x = x0
    product_rho = Q(1)
    signed_charge = Q(0)
    positive_charge = Q(0)
    charges = []
    for exponent in word:
        y = (3*x+1)/(1 << exponent)
        rho = Q(1 << exponent, 3)*(y+5)/(x+5)
        delta = rho-1
        product_rho *= rho
        signed_charge += delta
        positive_charge += max(delta, 0)
        charges.append(delta)
        x = y
    assert x == x0 and product_rho == Q(d, a) > 1
    assert charges[0] < 0 < charges[1] and charges[2] > 0
    assert signed_charge > 0 and positive_charge > 0
    return dict(actual_small_lasso_controls=rows, exact_lasso_prefix_checks=tests,
                formal_mixed_sign_control=dict(word=list(word), point=str(x0),
                                              integer_cycle=False,
                                              charges=[str(c) for c in charges],
                                              product=str(product_rho),
                                              signed_sum=str(signed_charge),
                                              positive_sum=str(positive_charge)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('exact_repetition_cycle_certificate.json'))
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Do not run this verifier with -O or -OO.')
    certificate = dict(status='PASS', arithmetic='integer and Fraction only',
                       word_checks=exact_word_checks(),
                       band_examples=band_examples(), lasso_checks=lasso_checks(),
                       imported_canonical_theorem_rerun=False,
                       high_nontrivial_positive_cycle_found=False,
                       universal_cycle_exclusion_claimed=False)
    certificate['verifier_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.write_text(json.dumps(certificate, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status='PASS', word_checks=certificate['word_checks'],
                          high_positive_word_example=certificate['band_examples']['positive_family_examples'][-1],
                          lasso_checks=certificate['lasso_checks']['exact_lasso_prefix_checks'],
                          certificate=str(args.output)), indent=2))


if __name__ == '__main__':
    main()
