from fractions import Fraction

def affine(word):
    u=0;a=0
    for i,bit in enumerate(word):
        if bit=='1':
            u=3*u+2**i;a+=1
    return a,u

for a in range(4,101):
    j=2*a;b=a-1
    w='00010110'+'10'*(a-4)
    odd,V=affine(w)
    By=2**j
    d=By-V
    assert len(w)==j and odd==b
    assert V==By-8*3**(a-3)
    assert 0<d<3**b
    assert Fraction(d,3**b)==Fraction(8,9)
    assert d%(3**(a-3))==0
    assert d%(3**(a-2))!=0
    # The numerator is greater than the strict smaller-origin threshold for n=1.
    assert V>By-3**b
print('PASS: 97 exact cases (a=4..100), numerator, positive rational origin, and precision bounds')
for a in range(4,101):
    w='0'+'00010110'+'10'*(a-4)
    j=len(w); b,V=affine(w); By=2**j
    assert b==a-1
    assert Fraction(By-V,3**b)==Fraction(16,9)
    assert 1<Fraction(16,9)<2
    assert (By-V)%(3**(a-3))==0
    assert V>By-2*3**b
    assert V<By-3**b
print('PASS: 97 exact n=2 extensions with 1 < rational origin 16/9 < 2')
