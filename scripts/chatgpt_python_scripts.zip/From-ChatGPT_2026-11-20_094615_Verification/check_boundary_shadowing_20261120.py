from fractions import Fraction

def T(n):
    return n//2 if n%2==0 else (3*n+1)//2

for L in range(1,81):
    n=(1<<L)-1
    z=n
    for j in range(L+1):
        assert z==3**j*2**(L-j)-1
        assert z>=n
        if j<L:
            assert z%2==1
            assert T(z)>z
            z=T(z)
    # Exact maximal-growth barrier, independent of enumeration of smaller origins
    for j in range(L+1):
        endpoint=3**j*2**(L-j)-1
        for m in range(1,min(n,100)):
            q=m
            for _ in range(j):q=T(q)
            assert q<endpoint
print('PASS: 80 exact shadowing formulas, 80 growth checks, bounded smaller-origin controls')
