from fractions import Fraction
from itertools import product

def affine(word):
    a=u=0
    for i,b in enumerate(word):
        if b:
            u=3*u+2**i
            a+=1
    return len(word),a,u

def step(x): return (3*x+1)//2 if x%2 else x//2

def parity(x,L):
    out=[]
    for _ in range(L):
        out.append(x%2);x=step(x)
    return tuple(out)

def test():
    checks=0;positive_fixed=[]
    for L in range(1,11):
        for w in product((0,1),repeat=L):
            l,a,u=affine(w); D=2**l-3**a
            if a and D>0 and u%D==0:
                x=u//D
                if x>0 and parity(x,L)==w and step_orbit(x,L)==x:
                    positive_fixed.append((w,x))
            for n in range(1,45):
                if parity(n,L)!=w:continue
                z=n
                for _ in range(L):z=step(z)
                assert Fraction(1,z)==Fraction(2**L,3**a*n+u)
                assert (z<n)==(D*n>u)
                checks+=1
    assert positive_fixed
    print('exact reciprocal/affine/descent comparisons:',checks)
    print('positive integer periodic words through length 10:',len(positive_fixed))
    print('sample:',positive_fixed[:8])

def step_orbit(x,L):
    for _ in range(L):x=step(x)
    return x

if __name__=='__main__':test()
