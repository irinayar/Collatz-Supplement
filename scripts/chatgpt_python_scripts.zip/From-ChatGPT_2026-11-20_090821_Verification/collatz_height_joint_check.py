from collections import Counter

def step(x): return x//2 if x%2==0 else (3*x+1)//2

def check(limit=5000, depth=50):
    c=Counter(); examples=[]
    for n in range(3,limit+1):
        x=n; a=0; U=0; ell=-1
        for j in range(1,depth+1):
            i=j-1
            if x%2:
                U=3*U+(1<<i); a+=1; ell=i
            x=step(x)
            assert (1<<j)*x==pow(3,a)*n+U
            if a==0: continue
            maxU=(1<<(ell-a+1))*(pow(3,a)-(1<<a))
            coarseU=(1<<(j-a))*(pow(3,a)-(1<<a))
            assert U<=maxU<=coarseU
            D=(1<<j)-pow(3,a)
            if D<=0:continue
            c['crossing']+=1
            if D*n>U:c['exact_descent']+=1
            if D*n>maxU:
                c['refined']+=1
                assert x<n
            if D*n>coarseU:c['coarse']+=1
            if D*n>maxU and D*n<=coarseU:
                c['gain']+=1
                if len(examples)<10: examples.append((n,j,a,ell,x))
    return c,examples

if __name__=='__main__':
    c,ex=check()
    print(dict(c));print('newly certified examples',ex)
