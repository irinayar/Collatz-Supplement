#!/usr/bin/env python3
"""Exact normalized unequal-time meeting and finite inverse enumeration."""
from collections import deque
S=lambda x:(3*x+1)//2 if x&1 else x//2
P='11101'; Q='11110111100'; W='111011101100111'

def run(n,L):
 out=[n]
 for _ in range(L):out.append(S(out[-1]))
 return out

def affine(w):
 a,b,d=1,0,1
 for c in w:
  if c=='1':a,b=3*a,3*b+d
  d*=2
 return a,b,d

def check(h):
 n=585447+5308416*h;m=462575+4194304*h
 sn=run(n,15);tm=run(m,11)
 assert ''.join(str(v%2) for v in sn[:-1])==W
 assert ''.join(str(v%2) for v in tm[:-1])==Q
 assert sn[5]==tm[11]
 assert all(v>=n for v in sn[:])
 assert m<n and n not in tm[:-1]
 assert (64*n-33)==81*m
 assert (n-61159)%65536==0
 assert sn[15]==3164993+28697814*h
 return n,m,sn[5],sn[15]

def inverse_count(n,maxdepth=24):
 z=run(n,15)[-1]
 layer=[(z,'')]; visits=0; hits=[]
 for depth in range(maxdepth+1):
  nxt=[]
  for x,rev in layer:
   visits+=1
   if 0<x<n and depth>0:
    word=rev[::-1]
    c=0
    while c<min(len(word),len(W)) and word[-1-c]==W[-1-c]:c+=1
    if c<len(W) and n not in run(x,depth)[:-1]:
     hits.append((depth,x,word,c))
   if depth<maxdepth:
    nxt.append((2*x,rev+'0'))
    if x%3==2:nxt.append(((2*x-1)//3,rev+'1'))
  layer=nxt
 return visits,hits

if __name__=='__main__':
 assert affine(P)==(81,73,32)
 assert affine(Q)==(6561,7345,2048)
 for h in range(100):check(h)
 for t in range(9):
  n=61159+65536*t
  visits,hits=inverse_count(n)
  print('t=',t,'n=',n,'visited=',visits,'normalized_hits=',len(hits),'first=',hits[:1])
 assert check(0)==(585447,462575,1481915,3164993)
 print('PASS: 100 exact infinite-family lifts, all nine initial cylinder representatives, depth<=24')
