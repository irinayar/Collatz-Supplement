"""Exact finite-depth ternary collision density by scaled target-height bands."""
from fractions import Fraction
from collections import defaultdict

def T(x): return x//2 if x%2==0 else (3*x+1)//2

def branches(j):
    out=[]
    for r in range(1,2**j+1):
        x=r;a=0
        for _ in range(j):
            a+=x&1;x=T(x)
        out.append((a,x%(3**a),Fraction(3**a,2**j)))
    return out

def profile(j):
    br=branches(j)
    cuts=sorted({Fraction(0)} | {c/2 for _,_,c in br} | {3*c/2 for _,_,c in br})
    M=3**(j+1)
    out=[]
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2
        even=[(a,r) for a,r,c in br if c>2*mid]
        odd=[(a,r) for a,r,c in br if c>2*mid/3]
        # A_j contains 2y if its residue matches an active even branch;
        # A_j contains (2y-1)/3 if it matches an active odd branch.
        # Check only y=2 (mod 3), which makes (2y-1)/3 integral and odd.
        hit=0;ehit=0;ohit=0
        for y in range(2,M+1,3):
            E=any((2*y-r)%3**a==0 for a,r in even)
            O=any((((2*y-1)//3)-r)%3**a==0 for a,r in odd)
            ehit+=E;ohit+=O;hit+=E and O
        frac=Fraction(hit,M)
        if hit:out.append((lo,hi,frac,Fraction(ehit,M),Fraction(ohit,M)))
    return out

def d(j):
    # exact image density for T^j, by active output-residue sets
    br=branches(j); M=3**j
    cuts=sorted({Fraction(0)}|{c for _,_,c in br})
    s=Fraction(0)
    for lo,hi in zip(cuts,cuts[1:]):
        active=[(a,r) for a,r,c in br if c>(lo+hi)/2]
        hit=sum(any((z-r)%3**a==0 for a,r in active) for z in range(M))
        s+=(hi-lo)*Fraction(hit,M)
    return s

if __name__=='__main__':
    for j in range(0,8):
        p=profile(j)
        c=sum(((hi-lo)*f for lo,hi,f,_,_ in p),Fraction(0))
        delta=d(j)-d(j+1)
        assert c==delta,(j,c,delta)
        print('j',j,'C_j/N',c,'bands',len(p),'d_j-d_j+1',delta)
        if j in (2,4):
            for lo,hi,f,e,o in p:
                print('  ',str(lo),str(hi),'joint',str(f),'even',str(e),'odd',str(o),'independence',str(3*e*o))
