from fractions import Fraction

def odd_step(u):
    x=3*u+1;e=0
    while x%2==0:x//=2;e+=1
    return x,e

checked=0; maximum=(Fraction(0),None); grouped={}
for start in range(3,200001,2):
    u=start; resets=0; prod=Fraction(1)
    while resets<100:
        v,e=odd_step(u)
        if e<2:break
        prod*=Fraction(3*u+1,3*u);resets+=1;u=v
    if resets==0 or u<3:continue
    valley=u;s=0;rise=Fraction(1)
    while s<100:
        v,e=odd_step(u)
        if e!=1:break
        rise*=Fraction(3*u+1,3*u);s+=1;u=v
    if s==0:continue
    total=prod*rise
    assert (valley+1)%(2**(s+1))==0
    assert valley%3!=0
    assert total < Fraction(4,3), (start,valley,s,total)
    if s==1:assert total < Fraction(11,9)
    else:assert total < 1+Fraction(1,2**s-1)
    assert total < Fraction(valley+1, valley-1)
    checked+=1
    if total>maximum[0]:maximum=(total,(start,valley,resets,s,u))
    grouped[s]=grouped.get(s,0)+1
print('checked',checked,'max',maximum,'by_s',sorted(grouped.items())[:15])

from fractions import Fraction
Q=Fraction(2**61,3**32*993)
assert 7*Q<9
print("certified_tail_product_with_charge",Q*Fraction(7,6))
