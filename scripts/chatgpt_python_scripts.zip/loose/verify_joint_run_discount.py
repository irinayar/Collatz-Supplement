from fractions import Fraction

def nextodd(u):
    z=3*u+1; e=(z&-z).bit_length()-1
    return z>>e,e

def runs(start,limit=200):
    u=start; out=[]
    for _ in range(limit):
        a=u;s=1;P=Fraction(1,1)
        while True:
            P*=Fraction(3*u+1,3*u)
            v,e=nextodd(u)
            if e>=2:
                out.append((a,s,u,v,e,P));u=v;break
            u=v;s+=1
        if u==1:break
    return out

checks=0;discounts=0;examples=[]
for start in range(3,2000,2):
    rr=runs(start,60)
    for a,s,w,b,e,P in rr:
        assert b*2**(s+e-1)==3**s*(a+1)-2**s
        assert P == (1+ (1-Fraction(2,3)**(s-1))/a)*Fraction(3*w+1,3*w)
        assert Fraction(1,b)<Fraction(2**(e-1),1)*Fraction(2,3)**s/Fraction(a,1)
        checks+=1
        if Fraction(2**(e-1),1)*Fraction(2,3)**s<1:
            discounts+=1
            if len(examples)<8:examples.append((a,s,e,b))
print('exact_run_checks',checks,'strict_discount_cases',discounts,'examples',examples)
assert Fraction(27,11*9)<Fraction(1,3)
print('uniform certificate exp(27/(11*9)) <= 1/(1-3/11)=11/8 <3/2')
