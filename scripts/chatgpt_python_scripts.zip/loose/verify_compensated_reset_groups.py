from fractions import Fraction

def odd_next(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def run(u):
 a=u;s=0;P=Fraction(1)
 while True:
  P*=Fraction(3*u+1,3*u)
  v,e=odd_next(u);s+=1
  if e>=2:return v,s,e,P
  u=v

def group(pattern):
 D=Fraction(1);A=Fraction(0)
 for s,e in pattern:
  d=Fraction(2**(s+e-1),3**s)
  A+=D*(1-Fraction(2,3)**s)
  D*=d
 return D,A

pat=[(1,2),(3,2)]
D,A=group(pat);C=A/(1-D)
assert (D,A,C)==(Fraction(64,81),Fraction(103,81),Fraction(103,17))
checked=0;actual=[]
for a in range(3,200001,2):
 b,s,e,p1=run(a)
 if (s,e)!=(1,2):continue
 c,s2,e2,p2=run(b)
 if (s2,e2)!=(3,2):continue
 assert c==Fraction(a+A,D)
 assert p1*p2==1+A/Fraction(a)
 assert (p1*p2)*(1+C/Fraction(c))==1+C/Fraction(a)
 checked+=1
 if len(actual)<10:actual.append((a,b,c))
assert checked>0
print('D,A,C',D,A,C)
print('verified_actual_two_run_groups',checked,'examples',actual)
# Every consecutive group with D<1 and A/(1-D)<=C telescopes, including reset runs.
for a in range(3,2000,2):
 u=a; P=Fraction(1);D=Fraction(1);A=Fraction(0);ng=0
 for i in range(80):
  if u==1:break
  v,s,e,p=run(u)
  d=Fraction(2**(s+e-1),3**s)
  A+=D*(1-Fraction(2,3)**s);D*=d;P*=p;u=v
  if D<1:
   assert P==1+A/Fraction(a)
   assert u==Fraction(a+A,D)
   ng+=1
   break
print('first_net_discount_group_identity_checks_done')
# At C=103/17, any completed group with A/(1-D)<=C is absorbed.
assert Fraction(1)+C/13 < Fraction(3,2)
print('exact barrier for a>=13',1+C/Fraction(13))
