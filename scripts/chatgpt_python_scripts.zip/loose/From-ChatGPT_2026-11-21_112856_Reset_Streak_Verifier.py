from fractions import Fraction

def F(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def reset_streak(u):
 a=u; p=Fraction(1);n=0
 while u>1:
  v,e=F(u)
  if e<2:break
  p*=Fraction(3*u+1,3*u)
  u=v;n+=1
 return u,n,p

best=(0,0,0)
checks=0
for a in range(3,100000,2):
 b,n,p=reset_streak(a)
 if n and b>=3:
  assert p < Fraction(b,b-1), (a,b,n,p)
  checks+=1
  if n>best[0]:best=(n,a,b)
print('verified',checks,'longest',best)
for a in [5,7,13,27,85,341,1365,5461]:
 b,n,p=reset_streak(a)
 print(a,b,n,str(p), 'bound',str(Fraction(b,b-1)) if b>1 else 'endpoint1')
