from fractions import Fraction
from math import log
Q = Fraction(2**61, 3**32 * 993)
t = Fraction(1,1001)+Fraction(7,45)
assert 0<t<1
assert 2*Q.numerator*(1-t.denominator*0) > 0
assert Q/(1-t) < Fraction(3,2)
print('Q =',Q)
print('rational universal upper bound =',float(Q/(1-t)))
print('strictly less than 3/2:',Q/(1-t)<Fraction(3,2))
for h in (1001,1025,4097,262143):
    eligible=[u for u in range(h,4*h+1,2) if u%3]
    # Include the maximum possible single divisible-by-3 input separately, conservatively.
    lg=sum(log(1+1/(3*u)) for u in eligible)
    if h<=4*h:
        div3=next((u for u in range(h,4*h+1,2) if u%3==0),None)
        if div3: lg+=log(1+1/(3*div3))
    assert lg < float(t)
    print('h',h,'maximal distinct-band envelope',round(float(Q)*__import__('math').exp(lg),10))
