from fractions import Fraction
from math import gcd

H=1023
SEARCH_LIMIT=200001

def next_odd(u):
    z=3*u+1
    while z%2==0:
        z//=2
    return z

def full_product(u):
    p=Fraction(1)
    seen=set()
    while u!=1:
        if u in seen: raise RuntimeError('cycle in finite checked orbit')
        seen.add(u)
        p*=Fraction(3*u+1,3*u)
        u=next_odd(u)
    return p

Q=max((full_product(u),u) for u in range(3,H+1,2))
assert Q==(Fraction(2**61,3**32*993),993),Q

B={0:Fraction(1)}
args={}
for b in range(1,7):
    best=Fraction(0); arg=None
    for start in range(H+2,SEARCH_LIMIT,2):
        u=start; product=Fraction(1)
        for _ in range(b):
            if u<=H: break
            product*=Fraction(3*u+1,3*u)
            u=next_odd(u)
        else:
            if product>best:
                best=product;arg=start
    # For any start >= SEARCH_LIMIT, the FIRST factor is at most
    # f(SEARCH_LIMIT). The remaining b-1 outside inputs, if any,
    # are bounded by the already certified B[b-1], irrespective
    # of their sizes. Induction makes the finite search GLOBAL.
    assert Fraction(3*SEARCH_LIMIT+1,3*SEARCH_LIMIT)*B[b-1] <= best
    B[b]=best;args[b]=arg
    print('GLOBAL',b,arg,best)
print('Q verified',Q)

Qvalue=Q[0]
for b in range(1,7):
    r=0
    while Qvalue*B[b]**(r//b)*B[r%b] < Fraction(3,2):
        r+=1
    print('BLOCK',b,'last proven old r',r-1,'next fails',r)
assert Qvalue*B[6]**(792//6)*B[792%6] < Fraction(3,2)
assert Qvalue*B[6]**(793//6)*B[793%6] >= Fraction(3,2)
