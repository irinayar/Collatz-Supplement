from fractions import Fraction

def example(t):
    es=[2]*t+[1]*t
    U=0; power=1
    for e in es:
        U=3*U+power
        power*=2**e
    E=3*t; r=2*t
    base=(-U*pow(3**r,-1,2**E))%(2**E)
    for a in (base,base+2**E):
        if a<3 or a%2==0: continue
        u=a; odd=[]
        for e in es:
            odd.append(u)
            if (3*u+1)%(2**e): break
            u=(3*u+1)//2**e
            if u%2==0:break
        else:
            D=Fraction(2**E,3**r)
            A=Fraction(U,3**r)
            G=Fraction(1)
            for v in odd:G*=Fraction(3*v+1,3*v)
            assert G==1+A/a and Fraction(u)==(a+A)/D
            return a,u,D,A,A/(1-D),G
    raise AssertionError('no realization')

if __name__=='__main__':
    for t in range(1,13):
        a,b,D,A,C,G=example(t)
        assert D==Fraction(8,9)**t
        assert A>=Fraction(4,3)**t-1
        print(t,a,b,'D=',str(D),'C=',float(C),'G=',float(G))
