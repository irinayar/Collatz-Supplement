#!/usr/bin/env python3
"""Reproduce every new exact certificate in a fresh temporary directory.

Uses only bundled Python and JSON inputs.  No network or third-party packages
are used.  Saved certificates are not overwritten.  This verifies the stated
finite certificates; the companion analytic proofs supply universal coverage.
The unresolved central mass bound is not asserted or tested as a theorem.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

if not __debug__:
    raise RuntimeError("Run without -O; certificate assertions must be enabled.")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

JOBS = [
    ("verify_canonical_forest_absorption.py", "canonical_forest_absorption_certificate.json",
     ["--seeds", "../all_depth_work/incoming_inverse_saved_first_hits.json"]),
    ("verify_incoming_eleven_notes.py", "incoming_eleven_notes_certificate.json",
     ["--seeds", "incoming_eleven_saved_groups.json"]),
    ("verify_sharp_short_depth_collision.py", "sharp_short_depth_collision_certificate.json", []),
    ("verify_unbounded_asynchronous_overlap.py", "unbounded_asynchronous_overlap_certificate.json", []),
    ("verify_overlap_independent_audit.py", "overlap_independent_audit_certificate.json",
     ["--witness", "unbounded_asynchronous_overlap_certificate.json"]),
    ("verify_bandwidth_uniform_complement.py", "bandwidth_uniform_complement_certificate.json",
     ["--seeds", "incoming_eleven_saved_groups.json"]),
    ("verify_uniform_complement_independent.py", "uniform_complement_independent_certificate.json",
     ["--producer-certificate", "bandwidth_uniform_complement_certificate.json",
      "--seeds", "incoming_eleven_saved_groups.json"]),
]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "central_bound_reproduction.json")
    args = parser.parse_args()
    controls = []
    with tempfile.TemporaryDirectory(prefix="collatz_central_reproduction_") as temp:
        stage_root = Path(temp)
        stage = stage_root / "central_bound_work"
        stage.mkdir()
        seed_relative = Path("all_depth_work/incoming_inverse_saved_first_hits.json")
        (stage_root / seed_relative.parent).mkdir()
        shutil.copy2(ROOT / seed_relative, stage_root / seed_relative)
        shutil.copy2(HERE / "incoming_eleven_saved_groups.json", stage / "incoming_eleven_saved_groups.json")
        for script, _, _ in JOBS:
            shutil.copy2(HERE / script, stage / script)
        for script, certificate, inputs in JOBS:
            cmd = [sys.executable, "-I", str(stage / script)]
            for i in range(0, len(inputs), 2):
                cmd.extend([inputs[i], str((stage / inputs[i + 1]).resolve())])
            cmd.extend(["--output", str(stage / certificate)])
            result = subprocess.run(cmd, cwd=stage, capture_output=True, text=True, timeout=180)
            if result.returncode:
                raise RuntimeError(f"{script} failed ({result.returncode})\n{result.stdout}\n{result.stderr}")
            generated = (stage / certificate).read_bytes()
            expected = (HERE / certificate).read_bytes()
            if generated != expected:
                raise RuntimeError(f"Certificate differs from saved bytes: {certificate}")
            controls.append({"script": script, "certificate": certificate,
                             "status": "PASS", "byte_identical": True,
                             "certificate_sha256": digest(generated),
                             "script_sha256": digest((HERE / script).read_bytes())})
            print(f"PASS: {script}; regenerated certificate is byte-identical.", flush=True)
    output = {"status": "PASS", "fresh_directory": True,
              "standard_library_only": True, "network_used": False,
              "checkers_run": len(controls), "checks": controls,
              "scope": "Finite exact certificates and independent reconstructions pass. The analytic notes prove all-threshold coverage of the complement. R_core<=51/4700 and the full21/125 residual budget remain unproved."}
    args.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: all {len(controls)} checkers. The central mass bound remains open.", flush=True)


if __name__ == "__main__":
    main()
