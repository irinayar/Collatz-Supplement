from fractions import Fraction

def nextodd(x):
 z=3*x+1;e=(z&-z).bit_length()-1
 return z>>e,e

def cylinder(word):
 x=1;mod=2
 for i,e in enumerate(word):
  found=[]
  for k in range(1<<e):
   z=x+k*mod;u=z;ok=True
   for v in word[:i+1]:
    u,actual=nextodd(u)
    if actual!=v:ok=False;break
   if ok:found.append(z)
  assert len(found)==1,(i,found)
  x=found[0];mod*=1<<e
 return x,mod

def test(N):
 word=[1,1,1]+[v for _ in range(N) for v in (2,1)]
 r,m=cylinder(word)
 # choose the positive representative itself (if necessary add multiples of modulus)
 x=r if r>1 else r+m
 vals=[x];es=[]
 for e in word:
  y,actual=nextodd(vals[-1]);assert actual==e
  vals.append(y);es.append(e)
 assert all(v>x for v in vals[1:]),(N,x,vals)
 return x,m,vals[-1],min(vals[1:]),len(word)
if __name__=='__main__':
 for N in range(1,11):print(N,*test(N))
