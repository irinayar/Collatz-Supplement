#!/usr/bin/env python3
"""Rebuild the exact certificates for the all-length Collatz continuation.

Use Python3.8 or later; only the standard library is required. Keep the sources/
directory with the scripts for the supplied-note table audit. The mathematical
scope and unproved remaining conditions are stated in the companion report.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json
import time
import audit_k140
import sharp_density_certificate as density
import verify_infinite_terminal_reset as single
import two_reset_extension as double
import audit_two_reset_extension as independent
import verify_ordered_eight_n_tail as tail
import integration_corollaries as integration


def main():
    if not __debug__:
        raise SystemExit('Run verification without -O or PYTHONOPTIMIZE; its exact checks use assertions.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_name('certificates'))
    args=parser.parse_args();out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    results={}
    results['supplied_note_audit']=audit_k140.run()
    results['sharp_all_length_density']=density.run()
    short=sum((Q(r['upper_contribution'])for r in results['sharp_all_length_density']['length_rows']if r['g']<=8),Q(0))
    assert short==Q(34627,1119744)
    results['single_reset_family']=single.certify()
    results['two_reset_extension']=double.certify()
    results['two_reset_independent_audit']=independent.certify(results['two_reset_extension'])
    results['successor_compatible_tail']=tail.certify()
    results['integration_corollaries']=integration.run()
    for name,result in results.items():
        (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    summary=dict(status='PASS',
                 all_length_density_strict_upper=results['sharp_all_length_density']['readable_combined_upper_bound'],
                 all_length_progression_bulk_strict_upper='111/2500',
                 boundary_functional_uniform_bound_proved=False,
                 one_reset_boundary_order='Theta(log(n)/n)',
                 completed_family='Every return has length<=8 OR at most two valuation exponents>=2; positive departures distinct.',
                 completed_upper=results['two_reset_extension']['completed_upper'],
                 completed_clean_strict_upper='11/10',
                 tail_without_distinctness=dict(input_allowance='n',upper=results['two_reset_extension']['tail_upper']),
                 tail_with_distinct_internal_inputs=dict(input_allowance='8*n',strict_upper='299/200',
                                                        distinct_inputs='y_2,...,y_(t-2); final output unrestricted'),
                 small_complete_graphs=results['two_reset_independent_audit']['small_graph_counts'],
                 additional_long_profiles_in_finite_certificate=results['two_reset_extension']['number_of_long_positive_source_profiles'],
                 finite_two_reset_thresholds=results['two_reset_extension']['small_threshold_count'],
                 all_length_DP_cutoff=512,
                 source_audit=dict(K140_retained=85,K140_real_excluded=111,K140_residue_excluded=14,
                                   K140_E14_candidates=462,K140_E14_minimum_margin=1093632))
    (out/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('Certificates:',out)
    print('Elapsed seconds (informational):',round(time.perf_counter()-start,3))


if __name__=='__main__':
    main()
