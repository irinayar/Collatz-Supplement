#!/usr/bin/env python3
"""Independent exact audit of the uniform complement, without producer imports.

Reconstructs every finite necessary-code count, proves contiguous interval
coverage arithmetically, and checks the analytic tail constants. Replays only
the existing 23 saved paths for the new structural lemmas. This does not bound
the central reset mass.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
N0=(1<<71)+1
A=F(47,32)
C=F(47,30)
RHO=F(1,1000)
BETA=F(1,100000)
LIMIT=F(151,1000)
SCALE=1<<80


def interval(x):
    v=x*SCALE
    lo=v.numerator//v.denominator
    hi=-((-v.numerator)//v.denominator)
    return {'lower_units':str(lo),'upper_units':str(hi),'denominator':str(SCALE),
            'display_only':float(x)}


def threshold_s(n,cap=A):
    s=0
    while 2*cap*3**s<=n:s+=1
    return s


def old_tail(L):
    return F(6*L+3+(-1)**L,6*(1<<L))


def terminal_tail(L,s):
    # Exact finite piece followed by the already explicit floor(j/2) tail.
    # Unlike the producer, use this sum rather than its new closed form.
    cut=max(L,2*s+1)
    value=sum((F(min(j//2,j-s),1<<j) for j in range(L,cut)),F(0))+old_tail(cut)
    if L<=2*s:
        closed=F(2*(L-s+1),1<<L)-F(4,3*(1<<(2*s)))
    else:closed=old_tail(L)
    assert value==closed and 0<=value<=old_tail(L)
    return value


def complement(n,P):
    L=n.bit_length()-1;s=threshold_s(n)
    tau=terminal_tail(L,s)
    value=C*(P*tau+F(31*P,n)+F(P,256*n)+F(214*P,7*n*n)+RHO+6*BETA)+A*F(5*P,4*n)
    return value,L,s,tau


def necessary_code_counts():
    power3=[3**r for r in range(257)]
    table={2:[0,0,1]}
    short_by_length={}
    for j in range(3,256):
        previous=table[j-1]
        short_by_length[j]=sum(number for r,number in enumerate(previous)
            if 3*(1<<j)<4*power3[r] and 3*power3[r]<4*(1<<j))
        current=[0]*(j+1)
        for r in range(j+1):
            if power3[r]>1<<j:
                current[r]=(previous[r] if r<len(previous) else 0)+(previous[r-1] if r else 0)
        table[j]=current
    # Direct word enumeration controls the recurrence and terminal-bit rule.
    words=[(3,2)]
    direct_lengths=0
    for j in range(3,18):
        direct_short=sum(1 for word,r in words if 3*(1<<j)<4*power3[r] and 3*power3[r]<4*(1<<j))
        assert direct_short==short_by_length[j]
        words=[((word<<1)|bit,r+bit) for word,r in words for bit in (0,1)
               if power3[r+bit]>1<<j]
        histogram=Counter(r for word,r in words)
        assert all(histogram[r]==number for r,number in enumerate(table[j]))
        direct_lengths+=1
    return table,short_by_length,direct_lengths


def barrier_controls():
    for j in range(1,256):
        candidates=[r for r in range(j+1) if 3**r<=1<<j]
        r=max(candidates)
        assert (1<<j)*(3*N0-r)>=3*N0*3**r
    for E in range(3,256):
        g=max(r for r in range(E+1) if 4*3**r<=3*(1<<E))
        assert 4*3**g*3*N0<=3*(1<<E)*(3*N0-255)


def saved_path_controls(seed_path):
    seed_raw=seed_path.read_bytes();groups=json.loads(seed_raw)['groups']
    paths=proper_prefixes=terminal_shells=proper_budgets=0
    for group in groups:
        n=group['n'];H=(4*n-2)//3;proper=[]
        for source in group['sources']:
            u=source['u'];word=source['word'];odd=[u];trace=[u];times=[0]
            for e in word:
                numerator=3*odd[-1]+1
                actual=(numerator&-numerator).bit_length()-1
                assert e==actual
                odd.append(numerator>>e)
                for step in range(e):
                    v=trace[-1];trace.append((3*v+1)//2 if v%2 else v//2)
                assert trace[-1]==odd[-1]
                times.append(len(trace)-1)
            assert n<=u<=H and n<=odd[-1]<=H
            assert all(v>H for v in trace[1:-1])
            E=len(trace)-1;g=len(word);r=0
            for j in range(1,E):
                r+=trace[j-1]%2
                assert (1<<j)*n**r<(3*n+1)**r
                proper_prefixes+=1
            cap=F((1<<E)*odd[-1],3**g*u);s0=threshold_s(n,cap)
            starts=[0]+[i+1 for i,e in enumerate(word[:-1]) if e>=2]
            terminal=Counter()
            for before,i in enumerate(starts):
                a=odd[i];after=len(starts)-before
                if i:proper.append((a,before,after))
                j=a.bit_length()-1;d=E-times[i];s=g-i
                if d>j:continue
                assert after<=d-s<=j-s0
                terminal[j]+=1
            for j,number in terminal.items():
                assert number<=min(j//2,j-s0)
                terminal_shells+=1
            paths+=1
        P=len(group['sources']);Pstar=2*P+1;L=n.bit_length()-1
        for rho in (RHO,F(1,10),F(3)):
            mass=F(0);counts=Counter();cutoffs={}
            for a,before,after in proper:
                assert before>=1 and after>=1
                ell=a.bit_length()-1;t=ell-L
                allowed=rho*(1<<ell)/(2*Pstar*(t+1)*(t+2))
                J=allowed.numerator//allowed.denominator
                cutoffs[ell]=J
                if before<=J or after<=J:
                    counts[ell]+=1;mass+=F(1,a)
            for ell,number in counts.items():assert number<=2*P*cutoffs[ell]
            assert mass<=rho*P/Pstar
            proper_budgets+=1
    assert paths==23
    return {'seed_sha256':sha256(seed_raw).hexdigest(),'paths':paths,'proper_prefixes':proper_prefixes,
            'refined_terminal_shells':terminal_shells,'proper_reset_budget_controls':proper_budgets,
            'budget_test_Pstar':'2*P+1, preserving the P/Pstar factor'}


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--producer-certificate',type=Path,default=HERE/'bandwidth_uniform_complement_certificate.json')
    parser.add_argument('--seeds',type=Path,default=HERE/'incoming_eleven_saved_groups.json')
    parser.add_argument('--output',type=Path,default=HERE/'uniform_complement_independent_certificate.json')
    args=parser.parse_args();raw=args.producer_certificate.read_bytes();producer=json.loads(raw)
    producer_rows=producer['finite_source_code_bounds']['rows']
    assert len(producer_rows)==186
    barrier_controls()
    table,short_by_length,direct_lengths=necessary_code_counts()
    rows=[];short_total=0;next_odd=N0;best=F(0);best_k=None;event_checks=0
    for k in range(3,256):
        short_total+=short_by_length[k]
        if k<70:continue
        lo=max(N0,3*(1<<(k-1))+3)
        hi=min((1<<256)-1,3*(1<<k)+1)
        assert lo==next_odd and lo%2==hi%2==1
        assert (((lo-2)//3).bit_length(),((hi-2)//3).bit_length())==(k,k)
        next_odd=hi+2
        P=sum(table[k])+short_total
        value,L,s,tau=complement(lo,P)
        assert value<LIMIT
        supplied=producer_rows[k-70]
        assert supplied['width_exponent']==k
        assert int(supplied['smallest_odd_threshold'])==lo
        assert int(supplied['long_codes'])==sum(table[k])
        assert int(supplied['short_codes'])==short_total
        assert int(supplied['P_upper'])==P
        assert F(supplied['tau'])==tau and supplied['s0']==s
        enclosure=supplied['complement_bound']
        assert F(int(enclosure['lower_units']),int(enclosure['denominator']))<=value<=F(int(enclosure['upper_units']),int(enclosure['denominator']))
        # Check every possible L or s0 jump in this interval, plus both ends.
        events={lo,hi}
        for power in range(L,hi.bit_length()+1):
            v=(1<<power)+1
            if lo<=v<=hi:events.add(v)
        for power in range(threshold_s(lo)-1,threshold_s(hi)+1):
            q=2*A*3**power
            v=-((-q.numerator)//q.denominator)
            if v%2==0:v+=1
            if lo<=v<=hi:events.add(v)
        previous=value
        for n in sorted(events):
            test=complement(n,P)[0]
            assert test<=previous<=value
            previous=test;event_checks+=1
        if value>best:best,best_k=value,k
        rows.append({'k':k,'first_odd_n':str(lo),'last_odd_n':str(hi),'U_k':str(P),
                     'complement_upper':interval(value)})
    assert next_odd==(1<<256)+1 and best_k==71
    assert int(rows[0]['U_k'])==1425333934605606057
    assert int(rows[1]['U_k'])==2982193714729830477
    assert 2**180<3**33*5**55
    assert 3000**22<2**256
    base=C*(192+31+F(1,256)+1)+A*F(5,4)
    assert base<400
    tail=F(400,3000)+C*(RHO+6*BETA)
    assert tail==F(67497,500000)<LIMIT
    assert 3**39<2**62 and 4*193**39<200**39
    assert C*F(51,4700)+LIMIT==F(21,125)
    actual=saved_path_controls(args.seeds)
    result={'status':'PASS','producer_code_imported':False,'producer_certificate_sha256':sha256(raw).hexdigest(),
            'finite_width_cases':len(rows),'all_odd_threshold_intervals_contiguous':True,
            'coverage':'2^71+1 through 2^256-1, followed by the analytic tail for odd n>=2^256+1',
            'direct_code_enumeration_lengths':direct_lengths,'height_coefficient_event_checks':event_checks,
            'worst_width':best_k,'worst_complement_exact':str(best),'worst_complement_interval':interval(best),
            'slack_below_151_over_1000':interval(LIMIT-best),'analytic_tail_bound':str(tail),
            'saved_path_controls':actual,'rows':rows,
            'scope':'Uniform complement proved; the required central reciprocal reset mass <=51/4700 remains unproved.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','width_cases':len(rows),'worst_width':best_k,
                      'worst_complement_display_only':float(best),'slack_display_only':float(LIMIT-best),
                      'actual_paths':actual['paths'],'output':str(args.output)},indent=2))


if __name__=='__main__':main()
