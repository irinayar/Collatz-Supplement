from fractions import Fraction

def check(N,a=1):
    u=(2**(N+2))*a-1
    start=u
    product=Fraction(1)
    for i in range(N):
        assert u==3**i*2**(N+2-i)*a-1
        assert (3*u+1)%4==2
        product*=Fraction(3*u+1,3*u)
        v=(3*u+1)//2
        assert v>u
        u=v
    assert product==1+Fraction(1,start)*(1-Fraction(2,3)**N)
    return (N,start,u,str(product))

if __name__=='__main__':
    for N in (1,2,5,10,20,40):
        print(check(N))
    for N in range(1,20):
        for a in range(1,10):
            check(N,a)
    print('171 parameterized exact checks passed')
