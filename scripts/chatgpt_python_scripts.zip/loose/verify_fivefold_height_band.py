#!/usr/bin/env python3
"""Exact rational proof of the fivefold height-band product certificate."""
from fractions import Fraction as F
from math import factorial
H=524285
h=H+2
Q=F(2**61,3**32*993)
z=F(2,3)
N=16
ln5_upper=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))+2*z**(2*N+1)/((2*N+1)*(1-z*z))
assert ln5_upper < F(161,100)
t=F(1,h)+ln5_upper/F(9)
K=8
exp_upper=sum((t**j/F(factorial(j)) for j in range(K+1)),F(0)) + (t**(K+1)/factorial(K+1))/(1-t/F(K+2))
assert t < 1
assert Q*exp_upper < F(1498527,1000000) < F(3,2)
print('ln(5) rigorous upper:',float(ln5_upper))
print('Q:',Q, float(Q))
print('t:',float(t))
print('rigorous upper for Q*exp(1/h+ln(5)/9):',float(Q*exp_upper))
print('exact gap to 3/2:',F(3,2)-Q*exp_upper)
print('SUCCESS: all comparisons use Fraction, no floating-point proof steps')
