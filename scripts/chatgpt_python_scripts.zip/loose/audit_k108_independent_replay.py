from collections import defaultdict

def run(u):
 s=0; w=u
 while w%2:
  w=(3*w+1)//2;s+=1
 e=0
 while w%2==0:
  w//=2;e+=1
 return w,s,e
S={1};
for a in range(3,1024,2):
 u=a;seen=set()
 while u not in S and u not in seen:
  seen.add(u);u,_,_=run(u)
 S.update(seen)
print('S',len(S),max(S))
def shell(u):
 if 1024<=u<8192:return u.bit_length()-11
 return None
surv=defaultdict(list); triples=[]; pairs=[]
for u in range(1025,8192,2):
 if u in S:continue
 x=u; states=[x]; profiles=[]
 for j in range(6):
  if x in S or shell(x) is None:break
  v,s,e=run(x)
  if s>4 or e>4:break
  profiles.append((s,e));states.append(v);x=v
  if j==1 and shell(states[0])==shell(states[2]) and all(shell(t) is not None and t not in S for t in states):
   pairs.append((u,tuple(profiles),tuple(map(shell,states))))
  if j==3 and profiles[:2]==profiles[2:4] and [shell(t) for t in states[:3]]==[shell(t) for t in states[2:5]] and all(t not in S for t in states):
   surv[(tuple(profiles[:2]),tuple(map(shell,states[:3])))].append(u)
  if j==5 and profiles[:2]==profiles[2:4]==profiles[4:6] and all(shell(states[k])==shell(states[k+2]) for k in range(5)):
   triples.append(u)
print('pairs',len(pairs),'repeat2',surv,'repeat3',triples)
for u in (1643,6969):
 x=u; a=[]
 for _ in range(4):
  v,s,e=run(x);a.append((x,s,e,v));x=v
 print(u,a)
