#!/usr/bin/env python3
"""Rebuild the Collatz first-source continuation and its exact certificates.

Python 3.8+, standard library only. Keep sources/ alongside these modules.
The analytic theorems and their limitations are in the companion report.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json
import time
import verify_k141
import verify_three_reset_extension as three
import audit_three_reset as independent
import verify_fixed_reset_boundary as layers
import verify_growing_reset_boundary as growing
import verify_unrestricted_finite_boundary as finite
import audit_unrestricted_boundary as finite_audit
import sharp_density_certificate as density
import verify_ordered_eight_n_tail as tail


def main():
    if not __debug__:
        raise SystemExit('Run without -O or PYTHONOPTIMIZE; exact checks use assertions.')
    here=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=here/'certificates')
    args=parser.parse_args()
    out=args.output_dir
    out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()

    results={}
    results['k141_audit']=verify_k141.certify(here/'sources'/'From-Codex_2026-11-21_163643.md')
    nine=[r for r in results['k141_audit']['classification']['E14_profiles']
          if r['disposition']=='genuine']
    nine_path=out/'nine_return_profiles.json'
    nine_path.write_text(json.dumps(nine,indent=2)+'\n',encoding='utf-8')
    results['three_reset_extension']=three.certify()
    results['three_reset_independent_audit']=independent.audit(results['three_reset_extension'],nine_path)
    results['fixed_reset_boundary']=layers.certify()
    results['growing_reset_boundary']=growing.certify()
    results['unrestricted_finite_boundary']=finite.certify()
    results['unrestricted_boundary_independent_audit']=finite_audit.audit(results['unrestricted_finite_boundary'])
    results['prior_all_length_density']=density.run()
    results['prior_successor_compatible_tail']=tail.certify()

    # Compare the restricted source producer against the unrestricted,
    # first-strict-descent enumeration, with matching threshold endpoints.
    all_sources=results['unrestricted_finite_boundary']['positive_source_records']
    exact={(r['u'],tuple(r['word'])):(r['w'],r['E'],r['B'],r['n_lo'],min(r['n_hi'],65533))
           for r in all_sources
           if len(r['word'])>=10 and r['resets']<=3 and r['n_lo']<=65533}
    restricted={(r['u'],tuple(r['word'])):(r['w'],r['E'],r['B'],r['lo'],r['hi'])
                for r in results['three_reset_extension']['long_positive_source_profiles']}
    assert exact==restricted and len(exact)==131

    T=Q(results['prior_all_length_density']['readable_combined_upper_bound'])
    _,log_upper=tail.log_bounds(Q(4,3))
    assert 3*T*log_upper<Q(111,2500)
    graph=results['three_reset_extension']['graph_summary']
    assert (graph['small_tail_transport_pairs'],graph['small_tail_transport_edges'],
            graph['small_tail_transport_maxgap'])==(325,44,5)
    assert Q(11,10)*Q(806,801)*Q(27,20)<Q(299,200)
    assert Q(17,250)+Q(43,250)==Q(6,25)
    rejected=[p for p in results['three_reset_extension']['prefix_records']if not p['accepted']]
    assert len(rejected)==24
    assert min(w['margin']for p in rejected for w in p['rejection_witnesses'])==1024
    for name,data in results.items():
        (out/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

    finite_data=results['unrestricted_finite_boundary']
    summary=dict(
        status='PASS',
        uniform_first_source_theorem=dict(
            family='gap<=9 OR at most3 reset exponents, with unbounded completed lengths',
            strict_boundary_upper='17/250',
            trajectory_distinctness_required_for_boundary_statement=False),
        sharp_reset_layers='For every fixed k>=1: B_=k and B_<=k are Theta_k(log(n)^(2k-1)/n).',
        growing_reset_layers=dict(
            asymptotic='B_<=floor(c sqrt(log n))->0 for c<(2 log(log_2 3))^(-1/2).',
            explicit_scope='log(n)>=1000000; k<=floor(sqrt(log n))',
            strict_boundary_upper='n^(-1/25)'),
        unrestricted_finite_check=dict(
            maximum_threshold=65535,thresholds=32767,
            strict_boundary_upper='121/1000',
            exact_maximum=finite_data['exact_boundary_maximum'],
            maximizing_thresholds=finite_data['exact_boundary_maximum_thresholds'],
            positive_profiles=finite_data['distinct_positive_profiles'],
            maximum_observed_profile_resets=finite_data['maximum_positive_profile_resets'],
            all_sources_strictly_descend=True,
            all_boundary_rows_independently_checked_by_heaps=True,
            independent_literal_path_and_interval_arrangement_audit=True),
        independent_three_reset_source_crosscheck=131,
        completed_product_upper='1088640/994117',
        n_input_tail_upper='24325110/16899989',
        eight_n_tail_strict_upper='299/200',
        product_hypotheses='C3 completed returns, distinct positive departures; 8n tail also requires distinct y_2,...,y_(t-2).',
        remaining_sufficient_condition=dict(
            complement='gap>=10 AND at least4 reset exponents',
            boundary_budget='43/250',proved=False),
        unrestricted_boundary_target_proved=False,
        all_collatz_convergence_proved=False,
        no_manuscript_or_frontier_update=True)
    (out/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('Certificates:',out)
    print('Elapsed seconds (informational):',round(time.perf_counter()-started,3))


if __name__=='__main__':
    main()
