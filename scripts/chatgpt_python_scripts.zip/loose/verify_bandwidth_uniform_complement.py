#!/usr/bin/env python3
"""Exact source-code and all-n numerical controls for the central reduction.

This counts necessary parity codes, not Collatz trajectories.  The bounded
trajectory checks replay the 23 previously saved paths only.  The remaining
central reset mass is NOT bounded by this certificate.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")

HERE = Path(__file__).resolve().parent
N0 = (1 << 71) + 1
A = Q(47, 32)
C = Q(47, 30)
RHO = Q(1, 1000)
BETA = Q(1, 100000)
LIMIT = Q(151, 1000)
MAX_K = 255
SCALE = 1 << 80


def interval(q: Q) -> dict:
    p = q.numerator * SCALE
    lo = p // q.denominator
    hi = -((-p) // q.denominator)
    assert Q(lo, SCALE) <= q <= Q(hi, SCALE)
    return {"lower_units": str(lo), "upper_units": str(hi),
            "denominator": str(SCALE), "display_only": float(q)}


def threshold_s(n: int, correction: Q = A) -> int:
    s = 0
    while 2 * correction * 3**s <= n:
        s += 1
    return s


def old_tau(L: int) -> Q:
    return Q(6 * L + 3 + (-1)**L, 6 * (1 << L))


def refined_tau(L: int, s: int) -> Q:
    assert 0 <= s <= L
    if L <= 2 * s:
        return Q(2 * (L - s + 1), 1 << L) - Q(4, 3 * (1 << (2 * s)))
    return old_tau(L)


def exact_profile_upper(n: int) -> dict:
    """The integer P_*(n) in the theorem, for any odd n>=2^71+1."""
    assert n >= N0 and n & 1
    H = (4*n-2)//3
    k = max(2, (H-n).bit_length())
    assert k < 3*n
    powers3 = [3**r for r in range(k+1)]
    powers_n = [n**r for r in range(k+1)]
    powers_3n1 = [(3*n+1)**r for r in range(k+1)]
    row = {2: 1}
    short = 0
    for j in range(3, k+1):
        short += sum(count for r, count in row.items()
                     if (3*n-k)*(1 << j) < 3*H*powers3[r]
                     and n*powers3[r] < H*(1 << j))
        nxt = {}
        for r, count in row.items():
            for bit in (0, 1):
                rr = r+bit
                if (1 << j)*powers_n[rr] < powers_3n1[rr]:
                    nxt[rr] = nxt.get(rr, 0)+count
        row = nxt
    long = sum(row.values())
    m = H.bit_length()
    old = {2: 1}
    for j in range(3, m+1):
        nxt = {}
        for r, count in old.items():
            for bit in (0, 1):
                rr = r+bit
                if 3**rr > 1 << (j-1):
                    nxt[rr] = nxt.get(rr, 0)+count
        old = nxt
    old_upper = 2*sum(old.values())
    return {"n": str(n), "H": str(H), "k": k,
            "long_codes": str(long), "short_codes": str(short),
            "new_code_upper": str(long+short), "old_code_upper": str(old_upper),
            "P_upper": str(min(long+short, old_upper))}


def certificate_constants() -> dict:
    # Every proper prefix has the exact n-dependent barrier.  At the stated
    # floor and j<=255, the geometric correction bound cannot cross 3^r=2^j.
    proper_checks = 0
    for j in range(1, MAX_K + 1):
        r = 0
        while 3 ** (r + 1) <= 1 << j:
            r += 1
        assert 3**r <= 1 << j < 3 ** (r + 1)
        assert (1 << j) * (3 * N0 - r) >= 3**r * 3 * N0
        proper_checks += 1

    # This certifies that the slight correction in the short lower endpoint
    # condition cannot admit an exponent below the pure 3/4 threshold.
    endpoint_checks = 0
    for E in range(3, MAX_K + 1):
        g = 0
        while 4 * 3 ** (g + 1) <= 3 * (1 << E):
            g += 1
        assert 4 * 3**g <= 3 * (1 << E) < 4 * 3 ** (g + 1)
        assert 4 * 3**g * 3 * N0 <= 3 * (1 << E) * (3 * N0 - MAX_K)
        endpoint_checks += 1

    # Imported explicit profile-bound exponent and the all-n analytic tail.
    assert 2**180 < 3**33 * 5**55
    assert 3000**22 < 2**256
    base_constant = C * (192 + 31 + Q(1, 256) + 1) + A * Q(5, 4)
    assert base_constant < 400
    analytic_tail = Q(400, 3000) + C * (RHO + 6 * BETA)
    assert analytic_tail < LIMIT

    # A doubled high cutoff gives an inverse-square height envelope.
    q = Q(193, 200)
    assert 3**39 < 2**62
    assert q**39 < Q(1, 4)
    assert 2 * (64 + 1) <= 2**62
    # This ratio check propagates 2(64m+1)<=2^(62m) from m to m+1.
    assert 2 * (64 * 2 + 1) <= 2**62 * 2 * (64 + 1)
    for m in (1, 2, 3, 36, 72, 128, 256):
        L, S = 64 * m, 39 * m
        first = Q(3**S - 1, 1 << L)
        second = Q(200, 7) * q ** (S + 1)
        third = Q(L + 1, 1 << (L - 1))
        assert first < Q(1, 1 << (2 * m))
        assert second < Q(200, 7 * (1 << (2 * m)))
        assert third <= Q(1, 1 << (2 * m))
        assert first + second + third < Q(214, 7 * (1 << (2 * m)))

    # Closed terminal-sum recurrence, including both branch boundaries.
    terminal_checks = 0
    for L in range(1, 160):
        for s in range(L + 1):
            tau = refined_tau(L, s)
            assert tau >= 0 and tau <= old_tau(L)
            assert tau == Q(min(L // 2, L - s), 1 << L) + refined_tau(L + 1, s)
            if s < L:
                assert refined_tau(L, s + 1) <= tau
            terminal_checks += 1
    assert C * Q(51, 4700) == Q(17, 1000)
    assert LIMIT + Q(17, 1000) == Q(21, 125)
    return {"proper_barrier_comparisons": proper_checks,
            "short_endpoint_comparisons": endpoint_checks,
            "terminal_closed_form_recurrences": terminal_checks,
            "analytic_tail_base_constant": str(base_constant),
            "analytic_tail_complement_bound": str(analytic_tail),
            "old_explicit_profile_bound": "96*n^(21/22)/(ceil(log2(H+1))+1)",
            "large_n_threshold": "2^256", "analytic_comparisons_passed": True}


def source_count_and_budget() -> dict:
    # D[j,r] counts words starting 11 and obeying 3^r_i>2^i at all prefixes.
    row = {2: 1}
    short_total = 0
    rows = []
    best = Q(0)
    best_k = None
    for k in range(3, MAX_K + 1):
        short_k = sum(count for r, count in row.items()
                      if 4 * 3**r > 3 * (1 << k)
                      and 3 * 3**r < 4 * (1 << k))
        short_total += short_k
        next_row = {}
        for r, count in row.items():
            for bit in (0, 1):
                rr = r + bit
                if 3**rr > 1 << k:
                    next_row[rr] = next_row.get(rr, 0) + count
        row = next_row
        if k < 70:
            continue
        n = max(N0, 3 * (1 << (k - 1)) + 3)
        H = (4 * n - 2) // 3
        assert (H - n).bit_length() == k
        assert k <= MAX_K and n < 1 << 256
        Pstar = sum(row.values()) + short_total
        L = n.bit_length() - 1
        s = threshold_s(n)
        tau = refined_tau(L, s)
        complement = C * (Pstar * tau + Q(31 * Pstar, n)
                          + Q(Pstar, 256 * n) + Q(214 * Pstar, 7 * n * n)
                          + RHO + 6 * BETA) + A * Q(5 * Pstar, 4 * n)
        assert complement < LIMIT
        if complement > best:
            best, best_k = complement, k
        rows.append({"width_exponent": k, "smallest_odd_threshold": str(n),
                     "long_codes": str(sum(row.values())),
                     "short_codes": str(short_total), "P_upper": str(Pstar),
                     "floor_log2_threshold": L, "s0": s,
                     "tau": str(tau), "complement_bound": interval(complement)})
    assert best_k == 71
    assert rows[0]["long_codes"] == "1241503538986719152"
    assert rows[0]["short_codes"] == "183830395618886905"
    assert rows[0]["P_upper"] == "1425333934605606057"
    exact_examples = [exact_profile_upper(N0),
                      exact_profile_upper(3*(1 << 70)+3)]
    assert exact_examples[0]["new_code_upper"] == rows[0]["P_upper"]
    assert exact_examples[1]["new_code_upper"] == rows[1]["P_upper"]
    return {"finite_width_cases": len(rows), "worst_width_exponent": best_k,
            "worst_complement_bound": interval(best),
            "gap_to_151_over_1000": interval(LIMIT - best),
            "exact_n_dependent_examples": exact_examples, "rows": rows}


def bounded_saved_path_checks(path: Path) -> dict:
    raw = path.read_bytes()
    groups = json.loads(raw)["groups"]
    count = terminal_shell_checks = proper_code_checks = proper_window_checks = 0
    for group in groups:
        n = group["n"]
        H = (4 * n - 2) // 3
        P = len(group["sources"])
        group_run_rows = []
        for source in group["sources"]:
            u, word = source["u"], tuple(source["word"])
            odd = [u]
            shortcut = [u]
            times = [0]
            for e in word:
                num = 3 * odd[-1] + 1
                assert (num & -num).bit_length() - 1 == e
                odd.append(num >> e)
                for _ in range(e):
                    x = shortcut[-1]
                    shortcut.append((3*x+1)//2 if x & 1 else x//2)
                assert shortcut[-1] == odd[-1]
                times.append(len(shortcut) - 1)
            E, g = sum(word), len(word)
            assert n <= u <= H and n <= odd[-1] <= H
            assert all(v > H for v in odd[1:-1])
            assert all(v > H for v in shortcut[1:-1])
            assert len(set(shortcut[:-1])) == len(shortcut) - 1
            assert word[0] == 1 and word[-1] >= 2
            r = 0
            for j, v in enumerate(shortcut[:-2], 1):
                r += v & 1
                assert (1 << j) * n**r < (3*n+1)**r
                proper_code_checks += 1
            # The structural terminal lemma works with any suffix upper bound.
            # These saved small-floor controls use the exact full correction;
            # the analytic high-floor theorem imports the fixed A=47/32.
            G = Q((1 << E) * odd[-1], 3**g * u)
            s0 = threshold_s(n, G)
            starts = [0] + [i+1 for i, e in enumerate(word[:-1]) if e >= 2]
            shells = Counter()
            for rminus, i in enumerate(starts):
                a, at = odd[i], times[i]
                j = a.bit_length() - 1
                rplus = len(starts) - rminus
                if i:
                    group_run_rows.append((a, rminus, rplus))
                if at + j < E:
                    continue
                shells[j] += 1
                d, s = E - at, g - i
                assert d <= j
                assert 3**(s + j - d) > n / (2 * G)
                assert s + j - d >= s0
            for j, amount in shells.items():
                assert amount <= min(j // 2, j - s0)
                terminal_shell_checks += 1
            count += 1
        L = n.bit_length() - 1
        for rho in (RHO, Q(1, 10), Q(3)):
            counts = Counter()
            mass = Q(0)
            Js = {}
            for a, before, after in group_run_rows:
                ell = a.bit_length() - 1
                t = ell - L
                q = rho * (1 << ell) / (2 * P * (t+1) * (t+2))
                J = q.numerator // q.denominator
                Js[ell] = J
                if before <= J or after <= J:
                    counts[ell] += 1
                    mass += Q(1, a)
            for ell, amount in counts.items():
                assert amount <= 2 * P * Js[ell]
            assert mass <= rho
            proper_window_checks += 1
    return {"saved_seed_file": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
            "actual_paths_replayed": count, "proper_prefix_checks": proper_code_checks,
            "refined_terminal_shell_checks": terminal_shell_checks,
            "proper_reset_budget_controls": proper_window_checks,
            "scope": "23 saved actual paths only; no new trajectory census."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=Path,
                        default=HERE / "incoming_eleven_saved_groups.json")
    parser.add_argument("--output", type=Path,
                        default=HERE / "bandwidth_uniform_complement_certificate.json")
    args = parser.parse_args()
    constants = certificate_constants()
    finite = source_count_and_budget()
    actual = bounded_saved_path_checks(args.seeds)
    result = {"scope": "Exact verification of the proved uniform complement below 151/1000. The central reset mass itself is not bounded.",
              "constants": constants, "finite_source_code_bounds": finite,
              "saved_path_controls": actual, "checks_passed": True}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {finite['finite_width_cases']} exact source-code width cases, k=70..255.")
    print(f"PASS: worst complement at k={finite['worst_width_exponent']}, below 151/1000.")
    print("PASS: exact all-n analytic tail above 2^256; central mass remains open.")
    print(f"PASS: {actual['actual_paths_replayed']} saved paths, {actual['refined_terminal_shell_checks']} refined terminal controls.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
