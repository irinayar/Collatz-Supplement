from fractions import Fraction as F

def nextodd(u):
 v=3*u+1;e=0
 while v%2==0:v//=2;e+=1
 return v,e

def epoch(u,s,e):
 a=u;G=F(1)
 for j in range(s):
  G*=F(3*u+1,3*u)
  v,ev=nextodd(u)
  assert ev==(1 if j<s-1 else e),(a,s,e,j,u,ev)
  u=v
 D=F(2**(s+e-1),3**s)
 A=D*u-a
 assert A>0 and G==1+A/F(a) and u==(a+A)/D
 return u,D,A,G

def verify_pair():
 b,D1,A1,G1=epoch(137,1,2)
 c,D2,A2,G2=epoch(b,3,2)
 D=D1*D2;A=A1+D1*A2;C=A/(1-D)
 assert (b,c,D,A,C)==(103,175,F(64,81),F(103,81),F(103,17))
 delta1=A1+C*(D1-1);delta2=A2+C*(D2-1)
 assert delta1+D1*delta2==0
 assert G1*G2*(1+C/F(c))==1+C/F(137)
 print('example:',b,c,'D=',D,'A=',A,'C=',C,'defects=',delta1,delta2)

def test():
 tested=0
 for start in range(3,2000,2):
  u=start; epochs=[]
  for j in range(70):
   a=u;s=0;g=F(1)
   while True:
    v,e=nextodd(u);s+=1;g*=F(3*u+1,3*u);u=v
    if e>=2:break
    if s>50:break
   if e==1:break
   D=F(2**(s+e-1),3**s);A=D*u-a
   assert A>0 and g==1+A/F(a)
   epochs.append((a,u,D,A,g));tested+=1
   if u==1:break
  for C in [F(1),F(103,17),F(20)]:
   prod=F(1);debt=F(0)
   for a,b,D,A,g in epochs:
    debt+=prod*(A+C*(D-1))/a
    prod*=g
    assert prod*(1+C/F(b))==1+C/F(start)+debt
 print('exact epoch/defect tests:',tested)
verify_pair();test()
