#!/usr/bin/env python3
"""Rebuild the ordered-parity and four-reset Collatz continuation.

Python 3.8+, standard library only. Run without -O. Analytic proofs are in the
report and companion notes; finite checks are explicitly scoped certificates.
The master reconstructs every included certificate and required profile table.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
import subprocess
import sys
import time

from continuation_audit import verify_k142
from continuation_audit import audit_four_reset_extension
from continuation_four_reset import verify_four_reset_extension
from continuation_analytic import verify_parity_profile_count
from continuation_order import verify_ordered_profile_count


def write_json(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    if not __debug__:
        raise SystemExit('Run without -O or PYTHONOPTIMIZE; assertions verify exact certificates.')
    started=time.perf_counter()
    here=Path(__file__).resolve().parent
    prior=here/'first_source_work'
    run=subprocess.run([sys.executable,str(prior/'verify_first_source_research.py')],
                       cwd=here,capture_output=True,text=True)
    if run.returncode:
        raise RuntimeError('Prior reconstruction failed:\n'+run.stdout+'\n'+run.stderr)
    print('Prior dependencies: PASS',flush=True)
    old_path=prior/'certificates'/'unrestricted_finite_boundary.json'

    audit_dir=here/'continuation_audit'
    k142=verify_k142.certify(audit_dir/'sources')
    baseline_path=audit_dir/'k142_certificate.json'
    write_json(baseline_path,k142)
    ten=[r for r in k142['classification']['E16_records']if r['disposition']=='genuine']
    assert len(ten)==476
    write_json(audit_dir/'ten_return_profiles.json',ten)
    classes=k142['short_positive_classes']
    assert len(classes)==713
    four_dir=here/'continuation_four_reset'
    profile_path=four_dir/'short_positive_profiles.json'
    write_json(profile_path,classes)
    print('K142 and short-profile reconstruction: PASS',flush=True)

    four_path=four_dir/'four_reset_certificate.json'
    four=verify_four_reset_extension.certify(profiles_path=profile_path,
              reference_census=old_path,output=four_path)
    four_audit=audit_four_reset_extension.certify(producer_path=four_path,
              baseline_path=baseline_path,output=audit_dir/'four_reset_independent_audit.json')
    print('Four-reset theorem and independent audit: PASS',flush=True)

    parity=verify_parity_profile_count.certify()
    write_json(here/'continuation_analytic'/'parity_profile_count_certificate.json',parity)
    ordered=verify_ordered_profile_count.certify(old_path)
    write_json(here/'continuation_order'/'ordered_profile_certificate.json',ordered)
    print('Parity injections, ordered counts, and integer constants: PASS',flush=True)

    assert Q(four['uniform_source_strict_upper'])==Q(9,125)
    assert Q(four['completed_product_strict_upper'])==Q(14,13)
    assert Q(four['tail_up_to_n_strict_upper'])==Q(23,16)
    assert Q(four['finite']['exact_maximum_source_sum'])==Q(17741,439425)
    assert four['analytic']['selected_prefixes']==244
    assert four['independent_old_census_comparison']
    assert len(four_audit['finite']['small_eight_n_transfer_rows'])==39
    assert Q(k142['eight_n_tail']['strict_global_upper'])==Q(299,200)
    assert Q(9,125)+Q(21,125)==Q(6,25)
    assert Q(121,1000)<Q(21,125)
    assert ordered['profile_threshold_injections_checked']==5103711
    assert ordered['distinct_all_sign_profiles']==1770

    summary=dict(status='PASS',
       source_notes=['From-Claude_2026-11-21_173852.md','From-Codex_2026-11-21_174113.md'],
       supplied_note_audit=dict(K142_genuine_gap10_profiles=476,K142_complete_positive_baseline=713,
              Claude_scope='Explicitly partial; witness searches do not prove exclusions.',
              decimal_correction='24325110/16899989 rounds to1.43936, not1.43939.'),
       ordered_profile_theorem='P_all(n)=O(n^gamma/(log n)^(3/2)), gamma=H_2(log(2)/log(3)).',
       uniform_charge_theorem='B_<=k(n)=O(k*n^(-eta)/(log n)^(3/2)) for positive integer k and n>=9k; eta=1-gamma.',
       growing_reset_scope='K=o(n^eta*(log n)^(3/2)) implies B_<=K->0. In particular floor(n^eta log n).',
       explicit_charge_bound='B_<=k<16*k*n^(-1/22), n>=33 and1<=k<=n/9.',
       explicit_order_bound='B_<=k<384*k*n^(-1/22)/(m+1), m=ceil(log2(H+1)), n>=33 and1<=k<=n/9.',
       explicit_power_scope='n>=2^352 and1<=k<=floor(n^(1/44)) imply B_<=k<n^(-1/88).',
       C4=dict(family='gap<=10 OR at most4 resets, arbitrary completed length',
               boundary_strict_upper='9/125',set_sum_requires_trajectory_distinctness=False,
               completed_product_strict_upper='14/13',n_input_tail_strict_upper='23/16',
               inherited_eight_n_tail_strict_upper='299/200',
               trajectory_conditions='Distinct positive completed departures; 8n also requires pairwise-distinct y_2,...,y_(t-2).',
               selected_prefix_cylinders=244,
               finite_maximum='17741/439425',finite_maximum_n=91,
               finite_maximum_scope='All odd thresholds3..65535; genuine source and first-source sums.'),
       remaining_sufficient_condition=dict(family='gap>=11 AND at least5 resets',
               boundary_budget='21/125',unproved_odd_thresholds_from=65537,proved=False),
       new_finite_controls=dict(ordered_profile_threshold_pairs=5103711,
               distinct_all_sign_profiles=1770,code_count_lengths=512),
       analytic_proofs_separate_from_finite_checks=True,
       unrestricted_all_reset_boundary_proved=False,
       universal_convergence_proved=False,
       no_manuscript_or_frontier_update=True)
    write_json(here/'verification_summary.json',summary)
    print(json.dumps(summary,indent=2))
    print('Elapsed seconds (informational):',round(time.perf_counter()-started,3))


if __name__=='__main__':main()
