#!/usr/bin/env python3
"""Exact finite symbolic certificate for inverse Collatz greedy-depth theorem.
No libraries beyond Python standard library; checks all residue classes and slopes.
"""
import json, hashlib

def inverse_children(x):
    out = [(2*x,0)]
    if x%3==2: out.append(((2*x-1)//3,1))
    return out

def paths(y,depth):
    layer={():y}
    for _ in range(depth):
        nxt={}
        for word,x in layer.items():
            for z,bit in inverse_children(x):
                assert z>0 and z%2==bit
                nxt[word+(bit,)]=z
        layer=nxt
    return layer

def greedy(y,depth):
    word=()
    x=y
    for _ in range(depth):
        z,b=min(inverse_children(x),key=lambda pair:pair[0])
        x=z;word=word+(b,)
    return word,x

def T(x): return (3*x+1)//2 if x%2 else x//2

def check():
    rows=[]
    exhaustive=0
    for j in range(1,6):
        M=3**j
        exceptions=[]
        for y0 in range(1,M+1):
            p0,p1=paths(y0,j),paths(y0+M,j)
            assert p0.keys()==p1.keys(), (j,y0)
            gw,g0=greedy(y0,j)
            gw1,g1=greedy(y0+M,j)
            assert gw==gw1 and p0[gw]==g0 and p1[gw]==g1
            # For y=y0+M*t, all branches are affine. Compare both intercept and slopes.
            for p,v0 in p0.items():
                slope=p1[p]-v0
                assert slope>0
                assert slope*3**sum(p)==2**j*M
                for t in (0,1,2):
                    if t==0: val=v0
                    else: val=paths(y0+M*t,j)[p]
                    assert val==v0+slope*t
                # Actual Collatz path back to target for concrete lift t=0.
                x=v0
                for _ in range(j): x=T(x)
                assert x==y0
                exhaustive+=1
            # Find whether greedy wins for *all* t>=0 (intercept AND slope).
            bad=any(g0>v0 or (g1-g0)>(p1[p]-v0) for p,v0 in p0.items())
            if bad: exceptions.append(y0)
            if j==5 and y0%9==5:
                assert set(p0.values())=={17+32*((y0-5)//9),48+96*((y0-5)//9),52+96*((y0-5)//9),53+96*((y0-5)//9),160+288*((y0-5)//9)}
        assert (not exceptions) if j<=4 else (exceptions==[i for i in range(1,M+1) if i%9==5])
        rows.append({'depth':j,'residue_modulus':M,'residue_cases':M,'greedy_failure_residues':len(exceptions),'exceptions':exceptions if j==5 else []})
    for t in range(100):
        y=5+9*t
        p0=paths(y,5)
        expect={'00101':17+32*t,'10000':48+96*t,'00100':52+96*t,'00001':53+96*t,'00000':160+288*t}
        assert {''.join(map(str,w)):v for w,v in p0.items()}==expect
        assert min(p0.values())==17+32*t
        for j in range(5,21):
            g=greedy(y,j)[1]
            assert g==2**(j-5)*(48+96*t)
            q=2**(j-5)*(17+32*t)
            x=q
            for _ in range(j):x=T(x)
            assert x==y and q<g
    return {'symbolic_residue_certificates':rows,'word_residue_pair_checks':exhaustive,'all_depth_greedy_gap_samples':100*16,'family_formula':{'endpoint':'5+9t','depth5_minimum':'17+32t','greedy_depth5':'48+96t'}}

if __name__=='__main__':
    result=check()
    print(json.dumps(result,indent=2))
