from fractions import Fraction
from collections import Counter
import json, zipfile

def T(x):return (3*x+1)//2 if x&1 else x//2

def word_data(word):
    a=u=0
    for ch in word:
        if ch=='1':u=3*u+2**a*0 # placeholder overridden below
    # numerator update from (3^a n+U)/2^j
    a=u=0
    for j,ch in enumerate(word):
        if ch=='1': u=3*u+2**j; a+=1
    return a,u

def inverse_target(y,word):
    z=y
    for ch in reversed(word):
        if ch=='0':z*=2
        else:
            if (2*z-1)%3:return None
            z=(2*z-1)//3
            if z<=0 or z%2==0:return None
    return z if z>0 else None

def test(prefix, K=13, R=8, nmax=10000):
    j=len(prefix);r=next(n for n in range(2**j) if ''.join(str((lambda x: x)(0)) for _ in [])=='') if False else None
    r=next(n for n in range(2**j) if parity(n,j)==prefix)
    a,u=word_data(prefix)
    assert (3**a*r+u)%2**j==0
    y0=(3**a*r+u)//2**j
    words=[''.join('1' if (mask>>i)&1 else '0' for i in range(ell)) for ell in range(R+1) for mask in range(2**ell)]
    symbolic=[]
    for v in words:
        b,uv=word_data(v);ell=len(v)
        # require 3^b | 2^ell*(y0+3^a*t)-uv
        modulus=3**max(0,b-a)
        residues=[]
        for t in range(modulus):
            num=2**ell*(y0+3**a*t)-uv
            if num%3**b==0:
                residues.append(t)
        for residue in residues:
            # exact integer affine m(t) along t=residue+modulus*k
            numerator=2**ell*(y0+3**a*residue)-uv
            m0=numerator//3**b
            slope=2**ell*3**a*modulus//3**b
            symbolic.append((v,modulus,residue,m0,slope))
    counts=Counter();checks=0
    for n in range(max(1,r),nmax+1,2**j):
        if parity(n,j)!=prefix:continue
        y=iterate(n,j)
        assert y==(3**a*n+u)//2**j
        t=(n-r)//2**j
        d=next((k for k in range(1,K+1) if iterate(n,k)<n),None)
        actual=set()
        for v in words:
            m=inverse_target(y,v)
            if m is not None and m<n:actual.add(v)
        predicted=set()
        for v,mod,res,m0,slope in symbolic:
            if t%mod!=res:continue
            m=m0+slope*((t-res)//mod)
            if 0<m<n:predicted.add(v)
        assert actual==predicted,(n,actual^predicted)
        checks+=1
        if d is not None:counts['D']+=1
        if actual:counts['I']+=1
        if d is not None or actual:counts['D_or_I']+=1
        else:counts['unresolved']+=1
    return {'prefix':prefix,'r':r,'j':j,'a':a,'u':u,'target_words':len(words),'symbolic_target_progressions':len(symbolic),'nmax':nmax,'checked':checks,'counts':dict(counts)}

def iterate(n,j):
    for _ in range(j):n=T(n)
    return n

def parity(n,j):
    out=[]
    for _ in range(j):out.append(str(n&1));n=T(n)
    return ''.join(out)

if __name__=='__main__':
    out={'results':[test(w) for w in ('11011','11101','1101101','111011')], 'scope':'finite n<=10000; target lengths<=8; D depth<=13'}
    with open('/mnt/data/shifted_guard_results.json','w') as f:json.dump(out,f,indent=2)
    print(json.dumps(out,indent=2))
