from functools import lru_cache

def v3(n):
    assert n > 0
    c = 0
    while n % 3 == 0:
        n //= 3
        c += 1
    return c

@lru_cache(None)
def exact_min(x, e, r):
    if r < 0:
        return None
    a = v3(x + 1)
    if e == 0:
        return (2**r * (x+1)//3**r - 1) if r <= a else None
    vals = []
    for ell in range(min(a, r)+1):
        y = 2*(2**ell*(x+1)//3**ell-1)
        m = exact_min(y,e-1,r-ell)
        if m is not None:
            vals.append(m)
    return min(vals) if vals else None

def closed_form(x,r):
    a=v3(x+1);u=(x+1)//3**a
    D=2**(a+1)*u-1;d=v3(D)
    E=2**(d+1)*(D//3**d)-1;f=v3(E)
    if r<=a:return 2**(r+2)*3**(a-r)*u-4
    if r<=a+d:return 2**(r-a+1)*(D//3**(r-a))-2
    if r<=a+d+f:return 2**(r-a-d)*(E//3**(r-a-d))-1
    return None

if __name__=='__main__':
    n=0
    for x in range(1,3001):
        vals=[]
        for r in range(40):
            lhs=closed_form(x,r)
            rhs=exact_min(x,2,r)
            assert lhs==rhs,(x,r,lhs,rhs)
            if lhs is not None: vals.append(lhs)
            n+=1
        assert all(a>b for a,b in zip(vals,vals[1:])),(x,vals)
    print(f'PASS: {n} formula/recursion comparisons; strict decrease on all 3000 finite sequences')
