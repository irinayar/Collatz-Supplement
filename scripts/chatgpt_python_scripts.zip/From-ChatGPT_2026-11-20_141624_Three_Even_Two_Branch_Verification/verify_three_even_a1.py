from functools import lru_cache
from itertools import combinations

def v3(n):
 a=0
 while n%3==0:
  a+=1;n//=3
 return a
@lru_cache(None)
def H(k,x,r):
 if r<0:return None
 if k==0:
  return (2**r*((x+1)//3**r)-1) if r<=v3(x+1) else None
 vals=[]
 for l in range(min(v3(x+1),r)+1):
  y=2*(2**l*((x+1)//3**l)-1)
  h=H(k-1,y,r-l)
  if h is not None:vals.append(h)
 return min(vals) if vals else None

def closed_H2(x,r):
 a=v3(x+1);u=(x+1)//3**a
 D=2**(a+1)*u-1;d=v3(D)
 E=2**(d+1)*(D//3**d)-1;f=v3(E)
 if r<0 or r>a+d+f:return None
 if r<a:return 2**(r+2)*3**(a-r)*u-4
 if r<=a+d:return 2**(r-a+1)*(D//3**(r-a))-2
 return 2**(r-a-d)*(E//3**(r-a-d))-1

count=0;adj=0;branches=0;cross=0
for x in range(1,30001):
 if v3(x+1)!=1:continue
 u=(x+1)//3;C=4*u-1;c=v3(C);v=C//3**c
 A=2*x;B=4*u-2;G=2**(c+1)*v-1
 for r in range(0,32):
  h=H(3,x,r)
  aa=closed_H2(A,r)
  bb=closed_H2(B,r-1) if r>=1 else None
  expected=min([z for z in (aa,bb) if z is not None],default=None)
  assert h==expected,(x,r,h,aa,bb)
  if h is None:break
  if r:
   assert h<prev,(x,r,h,prev)
   adj+=1
  if 1<=r<=c+1:
   assert aa==bb+2,(x,r,aa,bb)
   branches+=1
  if r==c+2 and G%3==1:
   assert bb is None and aa is not None and aa<prev,(x,r,G,aa,prev)
   cross+=1
  prev=h;count+=1
 else:raise AssertionError(('depth cap',x))
print({'endpoint_count':sum(v3(x+1)==1 for x in range(1,30001)),'finite_minimum_comparisons':count,'adjacent_strict_checks':adj,'branch_offset_checks':branches,'A_takeover_checks':cross,'cache':H.cache_info()._asdict()})
# Independent direct parity-word enumeration for small cases
cells=0
for x in range(1,101):
 if v3(x+1)!=1:continue
 for r in range(0,9):
  n=r+3; origins=[]
  for evens in combinations(range(n),3):
   evens=set(evens);odd=[p for p in range(n) if p not in evens]
   V=sum((2**p)*3**(r-1-j) for j,p in enumerate(odd))
   q,rem=divmod(2**n*x-V,3**r)
   if rem==0 and q>=1:
    z=q
    for p in range(n):
     assert (z&1)==(0 if p in evens else 1)
     z=(z//2 if z%2==0 else (3*z+1)//2)
    assert z==x
    origins.append(q)
  actual=min(origins,default=None)
  assert actual==H(3,x,r),(x,r,actual,H(3,x,r))
  cells+=1
print('independent word enumeration cells:',cells)
