from itertools import combinations
from math import log

def numerator(bits):
    v=0
    for i,bit in enumerate(bits):
        if bit:v=3*v+(1<<i)
    return v

def suffixes(h,e,z):
    out=[]
    for d in range(e+1):
        for zero_indices in combinations(range(h+d-1),d):
            v=(1,)+tuple(0 if i in zero_indices else 1 for i in range(h+d-1))
            B=(1<<len(v))*z
            V=numerator(v)
            if (B-V)%(3**h)==0:
                c=(B-V)//(3**h)
                assert c>0
                out.append((v,d,c))
    return out

def direct_words(b,e,z):
    out=[]
    for odd in combinations(range(b+e),b):
        word=tuple(int(i in odd) for i in range(b+e))
        B=(1<<(b+e))*z
        V=numerator(word)
        if (B-V)%(3**b)==0:
            m=(B-V)//(3**b)
            if m>0:out.append((m,word))
    return sorted(out)

def decomposed_words(b,e,z,h):
    out=[]
    for v,d,c in suffixes(h,e,z):
        k=b-h;f=e-d
        for odd in combinations(range(k+f),k):
            u=tuple(int(i in odd) for i in range(k+f))
            B=(1<<(k+f))*c
            V=numerator(u)
            if (B-V)%(3**k)==0:
                m=(B-V)//(3**k)
                if m>0:
                    w=u+v
                    assert numerator(w)==3**h*numerator(u)+(1<<len(u))*numerator(v)
                    out.append((m,w))
    return sorted(out)

checks=0
for h,e,z in [(2,2,2),(3,2,17),(2,3,5),(3,3,20)]:
    ss=suffixes(h,e,z)
    print('CASE',h,e,z,'suffixes', [(''.join(map(str,v)),d,c) for v,d,c in ss])
    for b in range(h,13):
        a=direct_words(b,e,z)
        d=decomposed_words(b,e,z,h)
        assert a==d,(h,e,z,b,a,d)
        checks+=1
        if h==2 and e==2 and z==2:
            expected={2:[(2,'0101'),(3,'1100')],3:[(1,'10101')]}.get(b,[])
            assert [(m,''.join(map(str,w))) for m,w in a]==expected
print('PASS',checks,'complete word/fibre decompositions')
