#!/usr/bin/env python3
"""Independent exact full-word enumeration of changed-count inverse layers."""
from itertools import combinations
from functools import lru_cache

def S(n):return (3*n+1)//2 if n&1 else n//2

def replay(n,word):
    out=[n]
    for bit in word:
        assert n%2==int(bit),(n,bit)
        n=S(n);out.append(n)
    return out

def affine(word):
    a,b,d=1,0,1
    for bit in word:
        if bit=='1': b=3*b+d; a*=3
        d*=2
    return a,b,d

W='111011101100111' # valuations (1,1,2,1,1,2,1,3,1,1,1)
A,B,D=affine(W)
assert (A,B,D)==(177147,310915,32768)
assert W.count('1')==11 and len(W)==15

@lru_cache(None)
def inverse_min(z,k,r):
    if k<0 or r<0:return None
    if k==r==0:return z
    vals=[]
    if k:
        q=inverse_min(2*z,k-1,r)
        if q is not None:vals.append(q)
    if r and z%3==2:
        q=inverse_min((2*z-1)//3,k,r-1)
        if q is not None:vals.append(q)
    return min(vals) if vals else None

# Independent complete enumeration of all C(18,5)=8568 target words.
words=[]
for zero_positions in combinations(range(18),5):
    zeros=set(zero_positions)
    word=''.join('0' if i in zeros else '1' for i in range(18))
    a,b,d=affine(word)
    assert a==3**13 and d==2**18
    words.append((word,b))
assert len(words)==8568

results=[]
for t in range(9):
    n=61159+65536*t
    source=replay(n,W)
    z=source[-1]
    assert z==330641+354294*t
    y=source[9]
    assert y*512==2187*n+2707
    assert y>2*n+1
    assert (3*y+9)%(2**7)==0
    assert min(source)==n
    candidates=[]
    for word,b in words:
        numerator=(2**18)*z-b
        if numerator%3**13==0:
            m=numerator//3**13
            if m>0:
                candidates.append((m,word))
    best=min(candidates) if candidates else None
    recursive=inverse_min(z,5,13)
    assert (best[0] if best else None)==recursive
    if n%9 in (2,4,8):
        expected=(8*n-{2:7,4:5,8:10}[n%9])//9
        assert best is not None and best[0]==expected and best[0]<n
        # Prefix ancestor, not a genuinely new meeting class.
        prefix={2:'101',4:'110',8:'011'}[n%9]
        assert replay(expected,prefix)[-1]==n
    else:
        assert best is None
    results.append((t,n%9,n,z,best[0] if best else None,len(candidates)))

for r in results:print('t=%d nmod9=%d n=%d endpoint=%d min=%s origins=%d'%r)
print('PASS: 9 residues, 8568 exact target words each, independent recursion, complete 3-adic lift, no descent and local C08 failure')
