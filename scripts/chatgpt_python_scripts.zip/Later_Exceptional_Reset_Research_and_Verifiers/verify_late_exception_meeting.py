#!/usr/bin/env python3
"""Exact integer certificate: later exceptional reset, local C08 failure, alternative unequal-time meeting."""
from functools import lru_cache

def S(n):return (3*n+1)//2 if n&1 else n//2

def replay(n,word):
    states=[n]
    for bit in word:
        assert n%2==int(bit), (n,bit)
        n=S(n);states.append(n)
    return states

def affine(word):
    a,b,d=1,0,1
    for bit in word:
        if bit=='1':b=3*b+d;a*=3
        d*=2
    return a,b,d

source_valuations=(1,1,2,1,1,2,1,3,1,1,1)
source_word=''.join('1'+'0'*(e-1) for e in source_valuations)
target_word='110111011101100111'
assert len(source_word)==15 and source_word.count('1')==11
assert len(target_word)==18 and target_word.count('1')==13
assert affine(source_word)==(177147,310915,32768)
assert affine(target_word)[0]==3**13
for t in range(12):
    n=61159+589824*t
    m=54363+524288*t
    a=replay(n,source_word)
    b=replay(m,target_word)
    assert a[-1]==b[-1]==330641+3188646*t
    assert 0<m<n
    assert min(a[:-1])==n  # no descent before meeting
    y=a[9] # 7th odd-to-odd input boundary: 1+1+2+1+1+2+1 = 9
    assert y==(2187*n+2707)//512
    assert y>2*n+1
    assert (3*y+9)%(2**7)==0 # exceptional e=3 followed by three e=1
    assert a[12]>n # state immediately after e=3 reset: total 9+3
    assert (3*y+1)//8==a[12]
    assert all(v>=n for v in a)
    # Independently verify target's convergence, not needed for the infinite-class induction rule
    p=m
    for i in range(2000):
        if p==1:break
        p=S(p)
    assert p==1
print('PASS 12 exact lifts; binary cylinder, failed local height, no descent, smaller unequal-time meeting, convergence')
print('source:',source_word,'target:',target_word)
print('source affine',affine(source_word),'target affine',affine(target_word))
