#!/usr/bin/env python3
"""Independent focused audit of K149/K150 and four incoming research notes.

Uses only a compact extraction of cached first-hit words, not a new trajectory
census. Slow membership uses its prescribed finite shortcut lookahead.
All theorem decisions and weight comparisons use integers or rational intervals.
Python 3.10+, standard library. Assertions must remain enabled.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from functools import lru_cache
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SCALE = 1 << 64
BANDS = (55, 91, 255, 1023, 4095, 65535)
EXPECTED_PROFILE_COUNTS = (2, 0, 0, 0, 7, 132)
RESIDUES = (1, 2, 4, 5, 7, 8)


def odd_step(x):
    numerator = 3*x + 1
    e = (numerator & -numerator).bit_length()-1
    return numerator >> e, e


@lru_cache(None)
def slow(x):
    assert x > 1 and x & 1
    state = x
    for _ in range((x-1).bit_length()):
        state = (3*state+1)//2 if state & 1 else state//2
        if 2*state < x:
            return False
    return True


def selected_slow(path):
    selected = []
    at = 0
    while at < len(path)-1:
        source = path[at]
        if slow(source):
            selected.append(source)
            at += 1
        else:
            at += 1
            while at < len(path)-1 and 2*path[at] >= source:
                at += 1
    return selected


def replay(source, word):
    path = [source]
    E = B = 0
    for e in word:
        actual, actual_e = odd_step(path[-1])
        assert e == actual_e
        B = 3*B + (1 << E)
        E += e
        path.append(actual)
    assert (1 << E)*path[-1] == 3**len(word)*source+B
    return path, E, B


def atanh_log_interval(value, terms=24):
    """Natural logarithm interval for positive rational value with |t|<1."""
    value = Q(value)
    t = (value-1)/(value+1)
    assert 0 <= t < 1
    term = t
    partial = Q(0)
    for j in range(terms):
        partial += 2*term/(2*j+1)
        term *= t*t
    remainder = 2*term/((2*terms+1)*(1-t*t))
    return partial, partial+remainder


LOG2_LOW, LOG2_HIGH = atanh_log_interval(Q(2))


@lru_cache(None)
def w_units(y):
    """Directed 2^-64 interval for W(y)=(2log2(y)+7)/(3y)."""
    level = y.bit_length()-1
    zlo, zhi = atanh_log_interval(Q(y, 1 << level))
    loglo = level + zlo/LOG2_HIGH
    loghi = level + zhi/LOG2_LOW
    lower = (2*loglo+7)/(3*y)
    upper = (2*loghi+7)/(3*y)
    lo = lower.numerator*SCALE//lower.denominator
    hi = (upper.numerator*SCALE+upper.denominator-1)//upper.denominator
    assert lo <= hi
    return lo, hi


def weight_summary(anchors):
    sums = {name: [0, 0] for name in ("single", "shared_with_multiplicity", "overlap_excess", "total")}
    for y, sources in anchors.items():
        m = len(sources)
        lo, hi = w_units(y)
        sums["total"][0] += m*lo
        sums["total"][1] += m*hi
        if m == 1:
            sums["single"][0] += lo
            sums["single"][1] += hi
        else:
            sums["shared_with_multiplicity"][0] += m*lo
            sums["shared_with_multiplicity"][1] += m*hi
            sums["overlap_excess"][0] += (m-1)*lo
            sums["overlap_excess"][1] += (m-1)*hi
    return {
        name: {
            "lower_units": str(lo), "upper_units": str(hi),
            "denominator": str(SCALE),
            "display_midpoint_only": (lo+hi)/(2*SCALE),
        } for name, (lo, hi) in sums.items()
    }


def exact_inverse_sources(n, y, depth_limit):
    H = (4*n-2)//3
    assert y > H and y & 1 and depth_limit >= 1
    ceiling = [(3**r*(H+1))//(1 << r)-1 for r in range(depth_limit)]
    stack = [(y, 0, ())]
    found = {}
    nodes = rejected_internal = 0
    while stack:
        v, depth, backward = stack.pop()
        nodes += 1
        assert nodes < 100000, "Inverse-node cap hit; no completeness claim."
        remaining_before_predecessor = depth_limit-depth-1
        assert remaining_before_predecessor >= 0
        vmax = ceiling[remaining_before_predecessor]
        doubled = 2*v
        exponent = 1
        while doubled <= 3*vmax+1:
            if (doubled-1) % 3 == 0:
                x = (doubled-1)//3
                if x >= n:
                    backward_word = backward+(exponent,)
                    if x <= H:
                        word = tuple(reversed(backward_word))
                        assert x not in found, "Duplicate source would contradict first return."
                        path, _, _ = replay(x, word)
                        assert path[-1] == y and all(z > H for z in path[1:])
                        found[x] = word
                    elif x % 3 == 0:
                        rejected_internal += 1
                    elif depth+1 < depth_limit:
                        stack.append((x, depth+1, backward_word))
            doubled *= 2
            exponent += 1
    return found, {"visited_nodes": nodes, "internal_multiple_of_3_rejections": rejected_internal}


def inverse_weight_controls():
    expected = (Q(10,21), Q(20,21), Q(17,42), Q(5,21), Q(5,42), Q(17,21))
    expected_potential = (Q(4,7),Q(4,7),Q(11,14),Q(1,7),Q(1,7),Q(11,14))
    rows = []
    for residue, target, target_potential in zip(RESIDUES, expected, expected_potential):
        v = residue if residue & 1 else residue+9
        integral = [e for e in range(1,7) if ((1 << e)*v-1) % 3 == 0]
        internal = [e for e in integral if ((1 << e)*v-1) % 9 != 0]
        forbidden = list(set(integral)-set(internal))
        assert len(integral) == 3 and len(internal) == 2 and len(forbidden) == 1
        total = sum((Q(3, 1 << (e+1)) for e in internal), Q(0))/(1-Q(1,64))
        all_integral = sum((Q(3, 1 << (e+1)) for e in integral), Q(0))/(1-Q(1,64))
        assert total == target <= Q(20,21)
        assert all_integral == (Q(1,2) if v % 3 == 1 else Q(1))
        h_v = 1 if v % 3 == 1 else 2
        potential_total = sum((Q(3,1 << (e+1)) * (1 if (((1 << e)*v-1)//3) % 3 == 1 else 2)
                               for e in internal),Q(0))/(1-Q(1,64))/h_v
        assert potential_total == target_potential <= Q(11,14)
        for e in range(1,19):
            value = (1 << e)*v-1
            if value % 3 == 0:
                x = value//3
                assert x & 1 and odd_step(x) == (v,e)
                assert (x % 3 != 0) == (value % 9 != 0)
        rows.append({"endpoint_residue_mod9":residue,
                     "integral_exponent_classes_mod6":[e % 6 for e in integral],
                     "internal_classes_mod6":[e % 6 for e in internal],
                     "excluded_internal_class_mod6":forbidden[0] % 6,
                     "internal_weight_sum":str(total),
                     "normalized_internal_potential_sum":str(potential_total),
                     "all_integral_weight_sum":str(all_integral)})
    return {"rows":rows,"uniform_internal_weight_cap":"20/21",
            "uniform_internal_potential_cap":"11/14",
            "potential":"h(v)=1 when v=1 mod3; h(v)=2 when v=2 mod3",
            "discounted_depth_tail":"sum_{g>D} sum_p 3^g/2^(E+g) <= min((20/21)^D, h(y)*(11/14)^D)",
            "tail_argument":"Internal mass contracts by 20/21 per generation; source leaves below each depth-D node form an antichain of total continuation mass at most 1.",
            "scope":"The discount 2^-g remains. Translating this estimate to unweighted counts introduces 2^g."}


def adaptive_floor_controls():
    dp = {1:1}
    counts = {1:1}
    for length in range(2,513):
        nxt = {}
        for r in range(1,length+1):
            if 3**(r+1) > 2**length:
                value = dp.get(r,0)+dp.get(r-1,0)
                if value:
                    nxt[r] = value
        dp = nxt
        counts[length] = sum(dp.values())
    for ell in range(6,512):
        assert (counts[ell+1]*(ell+3))**22 < 48**22*(1 << (21*ell))
    tail = Q(1089, 1 << 23)
    values = {}
    for level in range(511,2,-1):
        tail += Q(counts[level+1]*(2*level+7),3*(1 << level))
        values[level] = tail+Q(4*(level+2),3*(1 << level))
    assert all(values[j]>values[j+1] for j in range(3,511))
    ln15_lo, ln15_hi = atanh_log_interval(Q(3,2),32)
    assert values[160] > ln15_hi and values[161] < ln15_lo
    assert values[166] > Q(1,3) and values[167] < Q(1,3)
    assert values[172] > Q(13,50) and values[173] < Q(13,50)
    assert sum(slow(x) for x in range(9,2048,2)) == 315
    return {
        "exact_recurrence_lengths":512,
        "dyadic_count_inequalities":506,
        "first_floor_for_exp_bound_below_3_over_2":161,
        "first_floor_for_upper_below_1_over_3":167,
        "first_floor_for_upper_below_13_over_50":173,
        "U_160":str(values[160]),"U_161":str(values[161]),
        "U_172":str(values[172]),"U_173":str(values[173]),
        "log_3_over_2_interval":[str(ln15_lo),str(ln15_hi)],
        "literal_slow_sources_9_through_2047":315,
        "scope":"Certifies this particular adaptive envelope, under selected-slow distinctness. It is not a minimal possible cutoff for actual trajectories."}


def certify(seed_path=None, output=None):
    if not __debug__:
        raise RuntimeError("Assertions required; do not use -O or -OO.")
    seed_path = Path(seed_path) if seed_path else HERE/"incoming_inverse_saved_first_hits.json"
    raw = seed_path.read_bytes()
    data = json.loads(raw)
    assert tuple(data["thresholds"]) == BANDS
    grouped = defaultdict(list)
    for n, source, word in data["records"]:
        grouped[n].append((source,tuple(word)))
    bands = {}
    all_genuine = {}
    for n, expected in zip(BANDS,EXPECTED_PROFILE_COUNTS):
        H = (4*n-2)//3
        rows = sorted(grouped[n])
        assert [u for u,_ in rows] == [u for u in range(n,H+1,2) if u % 4 == 3]
        # All other odd sources immediately fall below n.
        assert (3*H+1)//4 < n
        genuine = {}
        least = {}
        for u, word in rows:
            path, E, B = replay(u,word)
            assert n <= u <= H
            assert all(x>H for x in path[1:-1]) and path[-1] <= H
            assert len(set(path[:-1])) == len(path)-1
            if path[-1] < n:
                continue
            genuine[u] = (word,path)
            cnum = B+5*((1 << E)-3**len(word))
            if len(word)>=11 and sum(e>=2 for e in word)>=5 and cnum>0:
                least.setdefault(word,(u,path,E,B,cnum))
        assert len(least) == expected
        anchors = defaultdict(list)
        charges = []
        for word,(u,path,E,B,cnum) in least.items():
            selected = selected_slow(path)
            assert len(set(selected)) == len(selected)
            for y in selected:
                anchors[y].append(u)
            charges.append(Q(cnum,3**len(word)*(u+5)))
        hist = Counter(len(us) for us in anchors.values())
        weights = weight_summary(anchors)
        if n == 65535:
            assert dict(hist) == {1:741,2:29,3:4}
            assert anchors[109031] == [72687,76575,80671]
            assert anchors[173927] == [68711,81435,85791]
            assert int(weights["single"]["lower_units"]) > int(weights["shared_with_multiplicity"]["upper_units"])
        if n == 4095:
            assert dict(hist) == {1:52,2:5}
            assert anchors[8687] == [4575,5147]
            assert int(weights["single"]["lower_units"]) > int(weights["shared_with_multiplicity"]["upper_units"])
        if n == 55:
            assert dict(hist) == {1:7,2:16}
            assert anchors[91] == [63,71]
            assert int(weights["shared_with_multiplicity"]["lower_units"]) > int(weights["single"]["upper_units"])
            assert sorted(charges) == sorted([Q(4575162170707021,94504029631443891),Q(649104445873871,11735794529394993)])
        bands[n] = {
            "n":n,"H":H,"cached_candidate_sources":len(rows),
            "positive_residual_least_profiles":len(least),
            "selected_anchor_count":len(anchors),
            "multiplicity_histogram":{str(k):v for k,v in sorted(hist.items())},
            "exact_positive_charge_sum":str(sum(charges,Q(0))),
            "weight_intervals":weights,
            "shared_anchors":[{"y":y,"sources":us} for y,us in sorted(anchors.items()) if len(us)>=2],
        }
        all_genuine[n]=genuine
    inverse_checks=[]
    for n,y,limits in ((55,91,(6,12)),(4095,8687,(6,12)),(65535,109031,(6,12,24)),(65535,173927,(6,12,24))):
        direct={}
        common_suffix=None
        for u,(word,path) in all_genuine[n].items():
            if y in path[1:-1]:
                depth=path.index(y)
                direct[u]=(depth,word[:depth])
                suffix=path[depth:]
                if common_suffix is None:common_suffix=suffix
                else:assert suffix==common_suffix
        assert common_suffix is not None
        H=(4*n-2)//3
        assert common_suffix[0]==y and n<=common_suffix[-1]<=H and all(x>H for x in common_suffix[:-1])
        discounted_tails=[]
        for cut in (0,1,3,6,12,24):
            mass=sum((Q(3**depth,1 << (sum(word)+depth))
                      for depth,word in direct.values() if depth>cut),Q(0))
            ceiling=min(Q(20,21)**cut,(1 if y%3==1 else 2)*Q(11,14)**cut)
            assert mass<=ceiling
            discounted_tails.append({"D":cut,"exact_mass":str(mass),"ceiling":str(ceiling)})
        for D in limits:
            found,statistics=exact_inverse_sources(n,y,D)
            expected={u:w for u,(d,w) in direct.items() if d<=D}
            assert found==expected
            inverse_checks.append({"n":n,"anchor":y,"D":D,"sources":sorted(found),
                                   "all_depth_sources_from_complete_cached_band":[{"source":u,"depth":depth} for u,(depth,word) in sorted(direct.items())],
                                   "verified_returning_suffix":common_suffix,
                                   "discounted_tail_checks":discounted_tails,**statistics})
    # The first seven checks are exactly the K150 cases, before our second-anchor extension.
    assert sum(row["visited_nodes"] for row in inverse_checks[:7])==393
    assert inverse_checks[5]["internal_multiple_of_3_rejections"]==10
    assert inverse_checks[6]["internal_multiple_of_3_rejections"]==142
    result={
        "status":"PASS",
        "scope":"Independent finite inverse search and cached first-hit replay; no new large trajectory census and no unrestricted-depth claim.",
        "seed_sha256":hashlib.sha256(raw).hexdigest(),
        "cached_candidate_records":len(data["records"]),
        "band_results":list(bands.values()),
        "inverse_checks":inverse_checks,
        "inverse_weight_controls":inverse_weight_controls(),
        "adaptive_floor_controls":adaptive_floor_controls(),
        "limitations":[
            "The finite multiplicity examples do not prove monotone or slow growth with n.",
            "Singleton W domination is certified for n4095 and n65535; shared weights dominate at n55.",
            "No external C# script or reported random sample was supplied or executed.",
            "The all-depth internal-weight tail is discounted and does not bound the unweighted first-source sum.",
        ],
    }
    output = Path(output) if output else HERE/"incoming_inverse_audit_certificate.json"
    output.write_text(json.dumps(result,indent=2)+"\n")
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds",type=Path,default=HERE/"incoming_inverse_saved_first_hits.json")
    parser.add_argument("--output",type=Path,default=HERE/"incoming_inverse_audit_certificate.json")
    args=parser.parse_args()
    result=certify(args.seeds,args.output)
    print(json.dumps({"status":result["status"],"cached_candidate_records":result["cached_candidate_records"],
                      "inverse_checks":len(result["inverse_checks"]),
                      "adaptive_first_floor":result["adaptive_floor_controls"]["first_floor_for_exp_bound_below_3_over_2"],
                      "output":str(args.output)},indent=2))

