#!/usr/bin/env python3
"""Independent exact audit of inverse-transfer weights and their limitation.

All infinite valuation sums are evaluated by a proved finite residue period
and a geometric tail.  This is not a Collatz convergence verifier.

Run:
    python verify_finite_residue_barrier.py
    python verify_finite_residue_barrier.py --output certificate.json
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction as Q
from pathlib import Path


def transfer(potential: dict[int, Q], modulus: int, v: int) -> Q:
    """Sum (3/2**e) h((2**e*v-1)/3) over integral unit predecessors.

    The potential is indexed modulo m=3**k.  Predecessor classes are
    determined by 2**e*v modulo 3*m, whose period divides 2*m.  Successive
    copies of one period have weight ratio 2**(-2*m).
    """
    assert modulus >= 3
    n = modulus
    while n % 3 == 0:
        n //= 3
    assert n == 1
    period = 2 * modulus
    assert pow(2, period, 3 * modulus) == 1
    answer = Q(0)
    for e in range(1, period + 1):
        numerator = (pow(2, e, 3 * modulus) * v - 1) % (3 * modulus)
        if numerator % 3:
            continue
        predecessor = numerator // 3
        if predecessor % 3:
            answer += Q(3, 2**e) * potential[predecessor]
    return answer / (1 - Q(1, 2**period))


def potential_extension(potential: dict[int, Q], modulus: int) -> dict[int, Q]:
    return {
        v: transfer(potential, modulus, v)
        for v in range(3 * modulus)
        if v % 3
    }


def exact_boundary_cap(potential: dict[int, Q], modulus: int, z: Q, u: int) -> Q:
    """Maximum terminal b(u) allowed by its unique e=1 parent row."""
    v = ((3 * u + 1) * pow(2, -1, 3 * modulus)) % (3 * modulus)
    available = potential[v % modulus] - z * transfer(potential, modulus, v)
    if u % 3:
        # This unit e=1 branch is terminal, so delete its internal allocation.
        available += z * Q(3, 2) * potential[u]
    return Q(2, 3) * available


def odd_step(x: int) -> tuple[int, int]:
    value = 3 * x + 1
    exponent = (value & -value).bit_length() - 1
    return value >> exponent, exponent


def incoming_prefix(u: int, y: int, height: int) -> tuple[list[int], list[int]]:
    states = [u]
    exponents = []
    assert u <= height < y
    while states[-1] != y:
        assert len(states) < 100  # Only guards this fixed finite regression.
        v, e = odd_step(states[-1])
        assert v > height
        assert v not in states
        exponents.append(e)
        states.append(v)
    return states, exponents


def stringify(value):
    if isinstance(value, Q):
        return str(value)
    if isinstance(value, dict):
        return {str(k): stringify(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [stringify(v) for v in value]
    return value


def certificate() -> dict:
    h = {1: Q(1), 2: Q(2)}
    lh = potential_extension(h, 3)
    expected_lh = {1: Q(8, 7), 2: Q(16, 7), 4: Q(11, 7),
                   5: Q(4, 7), 7: Q(2, 7), 8: Q(22, 7)}
    assert lh == expected_lh

    lam_old = Q(11, 7)
    z_old = 1 / lam_old
    assert all(lh[v] <= lam_old * h[v % 3] for v in lh)
    b_old = {0: Q(12, 11), 1: Q(1), 2: Q(14, 11)}
    assert {u: exact_boundary_cap(h, 3, z_old, u) for u in range(3)} == b_old

    l2h = potential_extension(lh, 9)
    ratios = {v: l2h[v] / h[v % 3] for v in l2h}
    constant = max(ratios.values())
    assert constant == Q(23285, 9709)
    assert [v for v in ratios if ratios[v] == constant] == [13, 26]

    lam = Q(31, 20)
    z = 1 / lam
    assert constant < lam**2
    H = {v: h[v % 3] + lh[v] / lam for v in lh}
    assert H == {v: Q(a, 217) for v, a in
                 zip((1, 2, 4, 5, 7, 8), (377, 754, 437, 514, 257, 874))}
    LH = potential_extension(H, 9)
    row_slack = {v: lam * H[v % 9] - LH[v] for v in LH}
    assert min(row_slack.values()) > 0
    assert sum(lh.values()) / len(lh) == sum(h.values()) / len(h)
    assert sum(LH.values()) / len(LH) == sum(H.values()) / len(H)

    b9 = {u: exact_boundary_cap(H, 9, z, u) for u in range(9)}
    expected_b9 = [Q(4781228, 3998721), Q(53284136, 27991047),
                   Q(10353668, 3998721), Q(30415796, 27991047),
                   Q(46066136, 27991047), Q(71712476, 27991047),
                   Q(34764596, 27991047), Q(48481736, 27991047),
                   Q(72799676, 27991047)]
    assert [b9[u] for u in range(9)] == expected_b9
    assert min(b9.values()) > 1
    boundary_rows = []
    for u in range(9):
        v = ((3 * u + 1) * pow(2, -1, 27)) % 27
        internal = LH[v] - (Q(3, 2) * H[u] if u % 3 else 0)
        allocation = z * internal + Q(3, 2) * b9[u]
        assert allocation == H[v % 9]
        boundary_rows.append({"source_mod9": u, "parent_mod27": v,
                              "terminal_b": b9[u], "allocation": allocation})

    # Symbolic proof in the companion note is universal. These exact integer
    # controls exercise the residue computation and proper-height condition.
    fixed_point_controls = []
    height = 1024
    for k in range(1, 7):
        modulus = 3**k
        t = 1 + (3 * height + 3) // (2 * modulus)
        v = -1 + 3 * modulus * t
        x1 = (2 * v - 1) // 3
        x5 = (32 * v - 1) // 3
        # Make v and both predecessors odd, preserving all residue identities.
        if v % 2 == 0:
            t += 1
            v = -1 + 3 * modulus * t
            x1 = (2 * v - 1) // 3
            x5 = (32 * v - 1) // 3
        assert v % 2 == x1 % 2 == x5 % 2 == 1
        assert min(v, x1, x5) > height
        assert x1 % modulus == v % modulus == (modulus - 1)
        assert x5 % modulus == (-11) % modulus
        assert x5 % 3 != 0
        assert odd_step(x1) == (v, 1)
        assert odd_step(x5) == (v, 5)
        fixed_point_controls.append({"k": k, "v": v, "e1_predecessor": x1,
                                     "e5_predecessor": x5})

    mixed_modulus_controls = []
    for modulus in (1, 2, 6, 8, 24, 72, 864):
        t = height + 1
        v = -1 + 18 * modulus * t
        x1 = -1 + 12 * modulus * t
        x5 = -11 + 192 * modulus * t
        assert min(v, x1, x5) > height
        assert v % 2 == x1 % 2 == x5 % 2 == 1
        assert v % 3 and x1 % 3 and x5 % 3
        assert v % modulus == x1 % modulus == (-1) % modulus
        assert x5 % modulus == (-11) % modulus
        assert odd_step(x1) == (v, 1)
        assert odd_step(x5) == (v, 5)
        mixed_modulus_controls.append({"modulus": modulus, "v": v,
                                       "e1_predecessor": x1,
                                       "e5_predecessor": x5})

    # Real incoming source paths, with all proper odd states above H=80.
    # These are the earlier common-anchor sources 63 and 71 for n=61.
    paths = []
    new_mass = Q(0)
    old_mass = Q(0)
    y = 91
    for u in (63, 71):
        states, exponents = incoming_prefix(u, y, 80)
        g, E = len(exponents), sum(exponents)
        natural = Q(3**g, 2**E)
        new_mass += z**(g - 1) * natural * b9[u % 9]
        old_mass += z_old**(g - 1) * natural * b_old[u % 3]
        paths.append({"source": u, "states": states, "exponents": exponents,
                      "g": g, "E": E})
    assert new_mass <= H[y % 9]
    assert old_mass <= h[y % 3]

    return stringify({
        "status": "PASS",
        "scope": "Exact finite-residue certificates for infinite valuation sums; not a convergence proof",
        "Lh_mod9": lh,
        "old_lambda": lam_old,
        "old_terminal_weights": b_old,
        "L2h_over_h_mod27": ratios,
        "two_step_constant": constant,
        "lambda": lam,
        "discount": z,
        "H_mod9": H,
        "LH_row_slack_mod27": row_slack,
        "terminal_weights_mod9": b9,
        "boundary_rows": boundary_rows,
        "fixed_point_controls": fixed_point_controls,
        "mixed_modulus_controls": mixed_modulus_controls,
        "source_paths": paths,
        "new_source_mass": new_mass,
        "new_parent_budget": H[y % 9],
        "old_source_mass": old_mass,
        "old_parent_budget": h[y % 3],
    })


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without -O: exact certificate checks use assertions.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = certificate()
    output = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(output)
        print(f"PASS: exact audit saved to {args.output}")
    else:
        print(output, end="")


if __name__ == "__main__":
    main()
