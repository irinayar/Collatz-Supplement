#!/usr/bin/env python3
"""Reproduce every new exact certificate in clean isolated directories.

This driver does not rerun the earlier large canonical-packing calculation.
Each new verifier is copied with only its required compact input. Expected
certificates are compared as parsed JSON. Python 3.10+, standard library.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


HERE = Path(__file__).resolve().parent
SEED = "incoming_inverse_saved_first_hits.json"
JOBS = (
    ("verify_inverse_boundary_mass.py", "inverse_boundary_mass_certificate.json", False, True),
    ("verify_finite_residue_barrier.py", "finite_residue_barrier_certificate.json", False, True),
    ("verify_incoming_inverse_notes.py", "incoming_inverse_audit_certificate.json", True, True),
    ("verify_first_source_occupation.py", "first_source_occupation_certificate.json", True, True),
    ("verify_aggregate_sandwich.py", "aggregate_sandwich_audit_certificate.json", True, True),
    ("verify_residue_stabilization.py", "residue_stabilization_certificate.json", False, False),
)


def run_job(job: tuple, parent: Path) -> dict:
    script, output, needs_seed, output_option = job
    work = parent / Path(script).stem
    work.mkdir()
    shutil.copyfile(HERE / script, work / script)
    if needs_seed:
        shutil.copyfile(HERE / SEED, work / SEED)
    command = [sys.executable, str(work / script)]
    if output_option:
        command += ["--output", str(work / output)]
    start = time.perf_counter()
    proc = subprocess.run(command, cwd=work, capture_output=True, text=True, timeout=60)
    if proc.returncode:
        raise RuntimeError(f"{script} failed ({proc.returncode}):\n{proc.stdout}\n{proc.stderr}")
    actual_path = work / output
    if not actual_path.is_file():
        raise RuntimeError(f"{script} did not produce {output}")
    actual = json.loads(actual_path.read_text())
    expected_path = HERE / output
    expected = json.loads(expected_path.read_text())
    if actual != expected:
        raise RuntimeError(f"Regenerated {output} differs from the delivered certificate")
    return {"script": script, "certificate": output, "status": "PASS",
            "regenerated_json_matches": True,
            "script_sha256": hashlib.sha256((HERE / script).read_bytes()).hexdigest(),
            "delivered_certificate_sha256": hashlib.sha256(expected_path.read_bytes()).hexdigest(),
            "elapsed_seconds_display_only": round(time.perf_counter() - start, 3)}


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without Python optimization; the exact checks use assertions.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "all_depth_verification_summary.json")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="collatz_all_depth_verify_") as directory:
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(run_job, job, Path(directory)) for job in JOBS]
            results = [future.result() for future in futures]
    result = {"status": "PASS", "verification_jobs": len(results),
              "all_expected_certificates_reproduced": True,
              "seed_sha256": hashlib.sha256((HERE / SEED).read_bytes()).hexdigest(),
              "results": results,
              "scope": [
                  "Fresh isolated runs of every new finite arithmetic certificate.",
                  "Universal statements are proved in the accompanying notes; sample tests are not extrapolated.",
                  "The earlier canonical-packing theorem is an imported previously audited result, not rerun by this driver.",
                  "No unrestricted residual budget or convergence proof is certified."]}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "verification_jobs": len(results),
                      "all_expected_certificates_reproduced": True,
                      "summary": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
