#!/usr/bin/env python3
"""Check the exact finite-prefix identities in the residue stabilization lemma.

These finite checks accompany an algebraic proof; they do not verify any
unrestricted first-return survival claim.
"""

from __future__ import annotations

import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: this verifier uses assertions.")


def step(x: int) -> int:
    return (3 * x + 1) // 2 if x & 1 else x // 2


def inverse_residue(bits: list[int]) -> int:
    B = 0
    r = 0
    for j, bit in enumerate(bits):
        if bit:
            B = 3 * B + (1 << j)
            r += 1
    modulus = 1 << len(bits)
    return (-B * pow(3**r, -1, modulus)) % modulus


def main() -> None:
    checks = 0
    examples = []
    for u in range(1, 258):
        m = u.bit_length()
        x = u
        bits = []
        for L in range(m + 17):
            if L >= m:
                assert inverse_residue(bits) == u
                residues = [inverse_residue(bits + [bit]) for bit in (0, 1)]
                assert sorted(residues) == [u, u + (1 << L)]
                assert residues[x & 1] == u
                checks += 1
                if u in (27, 63, 71) and L == m + 3:
                    examples.append({
                        "source": u,
                        "shortcut_depth": L,
                        "residue": u,
                        "next_actual_bit": x & 1,
                        "two_lift_residues": residues,
                    })
            bits.append(x & 1)
            x = step(x)

    odd_cylinder_checks = 0
    for u in range(1, 258, 2):
        x = u
        E = 0
        B = 0
        for g in range(1, 21):
            v = 3 * x + 1
            e = (v & -v).bit_length() - 1
            B = 3 * B + (1 << E)
            E += e
            x = v >> e
            modulus = 1 << (E + 1)
            a = (((1 << E) - B) * pow(3**g, -1, modulus)) % modulus
            assert (1 << E) * x == 3**g * u + B
            assert a == u % modulus
            if modulus > u:
                assert a == u
            odd_cylinder_checks += 1

    result = {
        "scope": "Finite exact checks of the proved inverse-residue identities; no survival theorem is inferred.",
        "shortcut_stabilization_and_two_lift_checks": checks,
        "odd_word_with_arrival_bit_checks": odd_cylinder_checks,
        "examples": examples,
        "checks_passed": True,
    }
    output = Path(__file__).with_name("residue_stabilization_certificate.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {checks} shortcut stabilization/lift checks and {odd_cylinder_checks} odd-word cylinder checks.")
    print(f"Certificate: {output.resolve()}")


if __name__ == "__main__":
    main()
