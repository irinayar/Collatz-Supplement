#!/usr/bin/env python3
"""Exact finite controls for the first-source occupation reduction.

Replays only the supplied compact first-hit words.  All decisions use
integers or Fraction; aggregate values use rigorous directed 2^-128
intervals.  The general statements are proved in the companion Markdown
note, not inferred from this finite sample.  No third-party dependencies.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SCALE = 1 << 128


def enclose(value: Q) -> tuple[int, int]:
    scaled = value.numerator * SCALE
    lo = scaled // value.denominator
    hi = -((-scaled) // value.denominator)
    return lo, hi


def interval_record(bounds: tuple[int, int] | list[int]) -> dict:
    lo, hi = bounds
    return {"lower_units": str(lo), "upper_units": str(hi),
            "denominator": str(SCALE),
            "display_midpoint_only": (lo + hi) / (2 * SCALE)}


def replay(n: int, source: int, word: tuple[int, ...]) -> dict:
    H = (4 * n - 2) // 3
    assert n <= source <= H and source % 2
    path = [source]
    E = B = 0
    product = Q(1)
    telescoping = Q(0)
    signed_transport = Q(0)
    occupation = [0, 0]
    for i, exponent in enumerate(word):
        x = path[-1]
        assert x >= n
        numerator = 3 * x + 1
        actual_e = (numerator & -numerator).bit_length() - 1
        assert exponent == actual_e
        signed_transport += Q((5 * (1 << exponent) - 14) * (1 << E),
                              3**(i + 1) * (source + 5))
        prefix_product = Q((1 << E) * x, 3**i * source)
        assert product == prefix_product >= 1
        term = Q(1 << E, 3**(i + 1) * source)
        assert term == product / (3 * x)
        telescoping += term
        lo, hi = enclose(Q(1, 3 * x))
        occupation[0] += lo
        occupation[1] += hi
        product *= Q(numerator, 3 * x)
        B = 3 * B + (1 << E)
        E += exponent
        path.append(numerator >> exponent)
    g = len(word)
    assert g >= 1 and all(x > H for x in path[1:-1])
    assert path[-1] <= H
    assert len(set(path[:-1])) == g
    assert (1 << E) * path[-1] == 3**g * source + B
    assert product == Q((1 << E) * path[-1], 3**g * source)
    assert product - 1 == telescoping
    rho = Q((1 << E) * (path[-1] + 5), 3**g * (source + 5))
    assert rho == product * Q(path[-1] + 5, path[-1]) / Q(source + 5, source)
    assert signed_transport == rho - 1
    return {"n": n, "H": H, "source": source, "word": word,
            "path": path, "E": E, "B_affine": B, "G": product,
            "rho": rho, "S_interval": occupation,
            "genuine": path[-1] >= n,
            "residual": g >= 11 and sum(e >= 2 for e in word) >= 5}


def family_controls(n: int, family: list[dict], label: str) -> dict:
    H = (4 * n - 2) // 3
    eps = Q(5 * (H - n), n * (H + 5))
    assert eps == Q(n + 5, n) / Q(H + 5, H) - 1
    assert 0 <= eps < Q(5, 4 * n)
    cap = max((p["G"] for p in family), default=Q(1))
    P = len(family)
    assert len({p["word"] for p in family}) == P
    assert len({p["source"] for p in family}) == P
    error = cap * eps * P
    sums = {key: [0, 0] for key in ("B", "T", "S")}
    for p in family:
        u, w = p["source"], p["path"][-1]
        ratio = Q(w + 5, w) / Q(u + 5, u)
        assert 1 / (1 + eps) <= ratio <= 1 + eps
        assert abs(ratio - 1) <= eps
        correction = p["G"] - 1
        charge = max(Q(0), p["rho"] - 1)
        assert abs(charge - correction) <= cap * eps
        for key, value in (("B", charge), ("T", correction)):
            lo, hi = enclose(value)
            sums[key][0] += lo
            sums[key][1] += hi
        for side in (0, 1):
            sums["S"][side] += p["S_interval"][side]
    B_lo, B_hi = (Q(v, SCALE) for v in sums["B"])
    T_lo, T_hi = (Q(v, SCALE) for v in sums["T"])
    S_lo, S_hi = (Q(v, SCALE) for v in sums["S"])
    # Directed intervals strictly verify the finite aggregate inequalities;
    # the empty family is also admitted, without a positive error allowance.
    assert max(B_hi - T_lo, T_hi - B_lo) <= error
    assert S_hi <= T_lo
    assert T_hi <= cap * S_lo
    assert B_lo >= S_hi - error
    assert B_hi <= cap * S_lo + error
    return {"label": label, "profiles": P,
            "positive_profiles": sum(p["rho"] > 1 for p in family),
            "max_odd_depth": max((len(p["word"]) for p in family), default=0),
            "actual_finite_G_cap": str(cap),
            "endpoint_epsilon": str(eps), "endpoint_error_cap": str(error),
            "B_interval": interval_record(sums["B"]),
            "T_interval": interval_record(sums["T"]),
            "S_interval": interval_record(sums["S"]),
            "note": "The finite G cap is computed from these paths; the high-floor theorem is not assumed at these smaller thresholds."}


def cutoff_controls() -> dict:
    A = Q(47, 32)
    exact_accumulated = Q(0)
    for g in range(1, 257):
        q_lo = 1 - Q(2, 3)**g
        q_hi = (1 + (g - 1) * A) / 3
        exact_phase_cap = 1 + ((q_hi - q_lo) / 2).__floor__()
        assert exact_phase_cap <= 1 + A * g / 6
        exact_accumulated += 1 + A * g / 6
        assert exact_accumulated == g + A * g * (g + 1) / 12
    # The critical logarithmic tail uses p=2a+1/2>1.  Its integral
    # upper bound from shell ell=L onward is (L-1)^(1-p)/(p-1).
    critical_examples = []
    for a in (Q(1, 2), Q(3, 4), Q(1), Q(2)):
        exponent = 2 * a + Q(1, 2)
        assert exponent > 1
        critical_examples.append({"a": str(a), "shell_power": str(exponent),
                                  "tail_log_power": str(1 - exponent)})
    return {"fixed_depth_checked_through": 256,
            "A": str(A),
            "cumulative_phase_bound": "D + 47*D*(D+1)/384",
            "critical_cutoff": "floor(y^(eta/2)/(log_2 y)^a), a>1/4",
            "critical_examples": critical_examples,
            "scope": "Finite rational algebra controls; convergence of the all-shell series is proved symbolically in the companion note."}


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without -O or -OO; assertions certify exact controls.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=Path, default=HERE / "incoming_inverse_saved_first_hits.json")
    parser.add_argument("--output", type=Path, default=HERE / "first_source_occupation_certificate.json")
    args = parser.parse_args()
    raw = args.seeds.read_bytes()
    seeds = json.loads(raw)
    by_band = defaultdict(list)
    for n, u, w in seeds["records"]:
        by_band[n].append((u, tuple(w)))
    results = []
    replay_count = genuine_count = 0
    for n in seeds["thresholds"]:
        H = (4 * n - 2) // 3
        rows = sorted(by_band[n])
        assert [u for u, _ in rows] == [u for u in range(n, H + 1, 2) if u % 4 == 3]
        assert (3 * H + 1) // 4 < n
        least = {}
        for source, word in rows:
            p = replay(n, source, word)
            replay_count += 1
            if p["genuine"]:
                genuine_count += 1
                least.setdefault(word, p)
        all_profiles = list(least.values())
        residual = [p for p in all_profiles if p["residual"]]
        positive_residual = [p for p in residual if p["rho"] > 1]
        families = [family_controls(n, all_profiles, "all_active_least_profiles"),
                    family_controls(n, residual, "residual_all_signs"),
                    family_controls(n, positive_residual, "residual_positive")]
        results.append({"n": n, "H": H, "families": families})
    assert replay_count == len(seeds["records"]) == 5925
    output = {"status": "PASS", "seed_sha256": hashlib.sha256(raw).hexdigest(),
              "replayed_first_hits": replay_count, "genuine_source_returns": genuine_count,
              "bands": results, "cutoff_controls": cutoff_controls(),
              "limitations": [
                  "No unrestricted first-source budget is claimed.",
                  "The infinite growing-depth estimates use the previously proved slow-source shell bound.",
                  "All-word and occupation sums count one least source per active complete word; repeated trajectory laps are not silently removed.",
                  "The fixed high-floor cap 47/32 is not applied to the finite small-band controls."]}
    args.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "replayed_first_hits": replay_count,
                      "genuine_source_returns": genuine_count,
                      "profile_families_checked": sum(len(r["families"]) for r in results),
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
