#!/usr/bin/env python3
"""Exact rational certificates for the inverse-boundary mass inequalities.

The infinite exponent sums are evaluated by exact geometric periods, not by
truncating a trajectory or exponent search.  Python standard library only.
This script certifies the finite arithmetic in the accompanying proof; it
does not certify the unrestricted Collatz first-source budget.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction as F
from pathlib import Path


if not __debug__:
    raise RuntimeError("Run without -O: the exact certificate uses assertions.")


UNITS_9 = (1, 2, 4, 5, 7, 8)
UNITS_27 = tuple(v for v in range(1, 27) if v % 3)


def h(v: int) -> F:
    if v % 3 == 0:
        raise ValueError("h is defined only on units modulo 3")
    return F(1 if v % 3 == 1 else 2)


def predecessor(v: int, e: int) -> int | None:
    numerator = (1 << e) * v - 1
    if numerator % 3:
        return None
    return numerator // 3


def geometric_operator(v: int, period: int, child_weight) -> F:
    """Sum 3/2^e times a periodic weight of unit integral predecessors."""
    numerator = F(0)
    for e in range(1, period + 1):
        x = predecessor(v, e)
        if x is not None and x % 3:
            numerator += F(3, 1 << e) * child_weight(x)
    return numerator / (1 - F(1, 1 << period))


def fraction_string(value: F) -> str:
    return str(value)


def build_certificate() -> dict:
    assert pow(2, 6, 9) == 1
    assert all(pow(2, e, 9) != 1 for e in range(1, 6))
    assert pow(2, 18, 27) == 1
    assert all(pow(2, e, 27) != 1 for e in range(1, 18))

    Lh = {v: geometric_operator(v, 6, h) for v in UNITS_9}
    expected_Lh = dict(zip(UNITS_9, map(F, ("8/7", "16/7", "11/7", "4/7", "2/7", "22/7"))))
    assert Lh == expected_Lh

    z0 = F(7, 11)
    b0 = {0: F(12, 11), 1: F(1), 2: F(14, 11)}
    base_rows = []
    for v in UNITS_9:
        assert z0 * Lh[v] <= h(v)
        base_rows.append({
            "v_mod_9": v,
            "h": fraction_string(h(v)),
            "Lh": fraction_string(Lh[v]),
            "normalized_internal_mass": fraction_string(z0 * Lh[v] / h(v)),
        })
    base_boundary_rows = []
    for v in (2, 5, 8):
        u = predecessor(v, 1)
        assert u is not None
        removed = F(3, 2) * h(u) if u % 3 else F(0)
        internal = z0 * (Lh[v] - removed)
        terminal = F(3, 2) * b0[u % 3]
        assert internal + terminal == h(v)
        base_boundary_rows.append({
            "v_mod_9": v,
            "source_mod_3": u % 3,
            "internal_mass": fraction_string(internal),
            "terminal_mass": fraction_string(terminal),
            "total": fraction_string(internal + terminal),
        })

    L2h = {
        v: geometric_operator(v, 18, lambda x: Lh[x % 9])
        for v in UNITS_27
    }
    C = max(L2h[v] / h(v) for v in UNITS_27)
    maximizers = [v for v in UNITS_27 if L2h[v] / h(v) == C]
    assert C == F(23285, 9709)
    assert maximizers == [13, 26]

    lam = F(31, 20)
    z = 1 / lam
    assert C < lam**2
    H9 = {v: h(v) + z * Lh[v] for v in UNITS_9}
    assert H9 == {v: F(a, 217) for v, a in zip(UNITS_9, (377, 754, 437, 514, 257, 874))}
    LH9 = {v: Lh[v % 9] + z * L2h[v] for v in UNITS_27}
    refined_rows = []
    for v in UNITS_27:
        direct = geometric_operator(v, 18, lambda x: H9[x % 9])
        assert direct == LH9[v]
        assert z * LH9[v] <= H9[v % 9]
        refined_rows.append({
            "v_mod_27": v,
            "L2h_over_h": fraction_string(L2h[v] / h(v)),
            "H9": fraction_string(H9[v % 9]),
            "LH9": fraction_string(LH9[v]),
            "slack": fraction_string(H9[v % 9] - z * LH9[v]),
        })

    b9 = {}
    refined_boundary_rows = []
    for u in range(9):
        v = ((3 * u + 1) * pow(2, -1, 27)) % 27
        slack = H9[v % 9] - z * LH9[v]
        unit_replacement = z * H9[u] if u % 3 else F(0)
        b9[u] = F(2, 3) * slack + unit_replacement
        assert b9[u] > 1
        removed = F(3, 2) * H9[u] if u % 3 else F(0)
        internal = z * (LH9[v] - removed)
        terminal = F(3, 2) * b9[u]
        assert internal + terminal == H9[v % 9]
        refined_boundary_rows.append({
            "source_mod_9": u,
            "v_mod_27": v,
            "b9": fraction_string(b9[u]),
            "internal_mass": fraction_string(internal),
            "terminal_mass": fraction_string(terminal),
            "total": fraction_string(internal + terminal),
        })

    return {
        "scope": "Exact finite residue and geometric-series certificate; unrestricted first-source bound remains open.",
        "base": {
            "lambda": "11/7",
            "depth_factor": "7/11",
            "source_weights_mod_3": {str(k): fraction_string(v) for k, v in b0.items()},
            "internal_rows": base_rows,
            "boundary_rows": base_boundary_rows,
        },
        "refined": {
            "two_step_C": fraction_string(C),
            "two_step_maximizers_mod_27": maximizers,
            "lambda": fraction_string(lam),
            "depth_factor": fraction_string(z),
            "H9_mod_9": {str(k): fraction_string(v) for k, v in H9.items()},
            "source_weights_mod_9": {str(k): fraction_string(v) for k, v in b9.items()},
            "internal_rows": refined_rows,
            "boundary_rows": refined_boundary_rows,
        },
        "checks_passed": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("inverse_boundary_mass_certificate.json"))
    args = parser.parse_args()
    result = build_certificate()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("PASS: exact mod-9 base rows, all 18 mod-27 refined rows, and all terminal replacements.")
    print("All exponent tails included by exact periods 6 and 18.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
