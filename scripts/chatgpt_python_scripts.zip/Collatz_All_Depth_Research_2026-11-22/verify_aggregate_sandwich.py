#!/usr/bin/env python3
"""Independent finite controls for the all-sign aggregate sandwich.

Uses only compact saved first-hit words. No new trajectory census, producer
imports, or claim of a global collision injection. Python standard library.
The large-threshold analytic theorem is audited in the companion note; these
small-band controls verify their actual product cap directly from integers.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path


HERE=Path(__file__).resolve().parent
A=Q(47,32)
SCALE=1 << 80


def bounds(value):
    lo=value.numerator*SCALE//value.denominator
    hi=(value.numerator*SCALE+value.denominator-1)//value.denominator
    return lo,hi


def add_bounds(total,value):
    lo,hi=bounds(value)
    total[0]+=lo
    total[1]+=hi


def formatted_bounds(total):
    return {"lower_units":str(total[0]),"upper_units":str(total[1]),
            "denominator":str(SCALE),"display_midpoint_only":sum(total)/(2*SCALE)}


def certify(seed=None,output=None):
    if not __debug__:raise RuntimeError('Assertions required; do not use -O or -OO.')
    seed=Path(seed) if seed else HERE/'incoming_inverse_saved_first_hits.json'
    raw=seed.read_bytes()
    data=json.loads(raw)
    grouped=defaultdict(list)
    for n,u,word in data['records']:grouped[n].append((u,tuple(word)))
    band_results=[]
    total_prefixes=0
    all_collision_classes=[]
    for n in data['thresholds']:
        H=(4*n-2)//3
        eps=Q(5*(H-n),n*(H+5))
        assert 0<=eps<Q(5,4*n)
        assert Q(n+5,n)/Q(H+5,H)==1+eps
        candidates=sorted(grouped[n])
        assert [u for u,w in candidates]==[u for u in range(n,H+1,2) if u%4==3]
        assert (3*H+1)//4<n
        least={}
        prefix_groups=defaultdict(list)
        depth_groups=defaultdict(list)
        prefix_count=0
        maximum_G=Q(1)
        for u,word in candidates:
            x=u
            path=[u]
            E=0
            for g,e in enumerate(word,1):
                t=3*x+1
                actual=(t&-t).bit_length()-1
                assert e==actual
                x=t >> e
                E+=e
                path.append(x)
                G=Q((1 << E)*x,3**g*u)
                maximum_G=max(maximum_G,G)
                # This is an exact finite observation, not an appeal to a
                # theorem whose n>=2^71 hypothesis these seed bands lack.
                assert 1<G<A
                if g<len(word):
                    assert x>H
                    prefix_groups[(g,E,x)].append(u)
                    depth_groups[(g,x)].append((u,E))
                    prefix_count+=1
            assert x<=H and n<=u<=H
            assert len(set(path[:-1]))==len(path)-1
            if x>=n:
                least.setdefault(word,(u,path,E))
        # Inspect all cached candidate prefixes, including nonleast sources
        # and source paths whose first hit lies below n.
        collisions=[]
        for (g,E,y),sources in sorted(prefix_groups.items()):
            assert len(sources)==len(set(sources))
            if len(sources)>1:
                collisions.append({'g':g,'E':E,'y':y,'sources':sources})
        for (g,y),sources_and_E in depth_groups.items():
            assert len({E for u,E in sources_and_E})==1
            assert len(sources_and_E)<=1+A*g/6
        P=len(least)
        aggregates={key:[0,0] for key in ('B','T','S','B_minus_T','B_minus_S')}
        nonpositive=0
        K=defaultdict(Q)
        edge_exponents={}
        injections=defaultdict(Q)
        sinks=defaultdict(Q)
        exact_positive_charge=Q(0)
        for word,(u,path,E) in least.items():
            w=path[-1]
            g=len(word)
            G=Q((1 << E)*w,3**g*u)
            r=Q(w+5,w)/Q(u+5,u)
            rho=G*r
            b=max(Q(0),rho-1)
            t=G-1
            s=sum((Q(1,3*x) for x in path[:-1]),Q(0))
            assert 1/(1+eps)<=r<=1+eps
            assert abs(b-t)<=A*eps
            assert s<=t<=G*s<=A*s
            assert s-A*eps<=b<=A*s+A*eps
            if rho<=1:nonpositive+=1
            else:
                exact_positive_charge+=b
                mass=Q(1,u+5)
                injections[u]+=mass
                for x,e in zip(path[:-1],word):
                    if x in edge_exponents:assert edge_exponents[x]==e
                    edge_exponents[x]=e
                    K[x]+=mass
                    mass*=Q(1 << e,3)
                sinks[w]+=mass
            for key,value in (('B',b),('T',t),('S',s),('B_minus_T',b-t),('B_minus_S',b-s)):
                add_bounds(aggregates[key],value)
        # Independently aggregate all positive whole-charge paths into a
        # signed transport forest. Low arrivals are sinks, even if that same
        # integer is also another profile's source.
        incoming=defaultdict(Q)
        sink_transport=defaultdict(Q)
        high_parents=defaultdict(set)
        for x,mass in K.items():
            e=edge_exponents[x]
            y=(3*x+1) >> e
            transported=mass*Q(1 << e,3)
            if y>H:
                incoming[y]+=transported
                high_parents[y].add(x)
            else:
                assert n<=y<=H
                sink_transport[y]+=transported
        assert dict(sink_transport)==dict(sinks)
        assert set(incoming)=={x for x in K if x>H}
        for x,mass in K.items():
            assert mass==(incoming[x] if x>H else injections[x])
        signed=sum((Q(5*(1 << edge_exponents[x])-14,3)*mass for x,mass in K.items()),Q(0))
        terminal=sum(((w+5)*mass for w,mass in sinks.items()),Q(0))
        initial=sum(((u+5)*mass for u,mass in injections.items()),Q(0))
        assert signed==terminal-initial==exact_positive_charge
        assert initial==P-nonpositive
        delta=A*eps*P
        if P:
            bt=aggregates['B_minus_T']
            assert Q(bt[0],SCALE)>=-delta and Q(bt[1],SCALE)<=delta
            # Enclosures leave ample slack in these finite examples.
            assert Q(aggregates['S'][1],SCALE)-delta<=Q(aggregates['B'][0],SCALE)
            assert Q(aggregates['B'][1],SCALE)<=A*Q(aggregates['S'][0],SCALE)+delta
        # Exact polynomial summation identity for the safe depth envelope.
        for D in (0,1,2,7,24,1000):
            assert sum((1+A*g/6 for g in range(1,D+1)),Q(0))==D+A*D*(D+1)/12
        result={'n':n,'H':H,'cached_candidates':len(candidates),'proper_prefixes':prefix_count,
                'active_all_sign_least_profiles':P,'nonpositive_profiles':nonpositive,
                'maximum_observed_prefix_G':str(maximum_G),
                'endpoint_epsilon':str(eps),'aggregate_error_delta':str(delta),
                'aggregate_intervals':{k:formatted_bounds(v) for k,v in aggregates.items()},
                'signed_forest':{'positive_profiles':P-nonpositive,'charged_states':len(K),
                                 'high_merge_states':sum(len(parents)>1 for parents in high_parents.values()),
                                 'low_arrivals_also_used_as_sources':sorted(set(sinks)&set(injections)),
                                 'exact_signed_identity_verified':True,
                                 'internal_transport_verified':True,
                                 'arrival_sink_transport_verified':True},
                'same_g_E_y_collision_classes':collisions,
                'same_g_E_y_maximum_multiplicity':max((len(v) for v in prefix_groups.values()),default=0),
                'same_g_y_single_E':True}
        band_results.append(result)
        total_prefixes+=prefix_count
        all_collision_classes.extend({'n':n,**v} for v in collisions)
    result={'status':'PASS','seed_sha256':hashlib.sha256(raw).hexdigest(),
            'cached_records':len(data['records']),'proper_prefix_records':total_prefixes,
            'bands':band_results,'same_g_E_y_collision_classes':all_collision_classes,
            'scope':['All-sign least profiles are used for B,T,S, not only positive residual profiles.',
                     'Collision diagnostics include every cached candidate source, including nonleast and nonreturning-to-band candidates.',
                     'The fixed cap 47/32 is verified directly in these small finite samples.',
                     'Finite absence of a collision is not proof of a same-depth injection.',
                     'No new trajectory census and no unrestricted first-source conclusion.']}
    output=Path(output) if output else HERE/'aggregate_sandwich_audit_certificate.json'
    output.write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seeds',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=certify(args.seeds,args.output)
    print(json.dumps({'status':result['status'],'cached_records':result['cached_records'],
                      'proper_prefix_records':result['proper_prefix_records'],
                      'same_g_E_y_collision_classes':len(result['same_g_E_y_collision_classes'])},indent=2))
