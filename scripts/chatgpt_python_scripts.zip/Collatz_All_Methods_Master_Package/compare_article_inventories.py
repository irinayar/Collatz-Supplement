#!/usr/bin/env python3
"""Compare the substantive inventory rows in the two supplied TEX articles.

References are replaced with <REF>; hyperlink targets and rendered link labels
are deliberately outside this equality test. Everything else is retained,
apart from whitespace normalization. This is not a theorem-proof verifier.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path


def extract_rows(path):
    result = {}
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        match = (
            re.search(r"\\hypertarget\{cond:(K\d{3})\}", line)
            or re.match(r"(M\d{2}|C\d{2,3})\s*&", line)
            or re.match(r"\\item\[(M\d{2}|C\d{2,3})\]", line)
        )
        if match:
            key = match.group(1)
            if key in result:
                raise ValueError("Duplicate inventory ID: " + key)
            result[key] = {"line": line_number, "text": line}
    for prefix, count, width in [("M", 91, 2), ("C", 121, 2), ("K", 190, 3)]:
        actual = {key for key in result if key.startswith(prefix)}
        expected = {prefix + str(i).zfill(width) for i in range(1, count + 1)}
        if actual != expected:
            raise ValueError("Incomplete or excess inventory IDs: " + prefix)
    return result


def balanced_end(text, start, opening="{", closing="}"):
    if start >= len(text) or text[start] != opening:
        raise ValueError("Malformed reference macro at position " + str(start))
    depth = 0
    for i in range(start, len(text)):
        if text[i] == opening:
            depth += 1
        elif text[i] == closing:
            depth -= 1
            if depth == 0:
                return i + 1
    raise ValueError("Unbalanced reference macro")


def normalize_references(text):
    pattern = re.compile(
        r"\\(VOnePageLink|VTwoPageLink|hyperref|hyperlink|href|hypertarget|ref|pageref)\b"
    )
    pieces = []
    position = 0
    while True:
        match = pattern.search(text, position)
        if match is None:
            pieces.append(text[position:])
            break
        pieces.append(text[position:match.start()])
        name = match.group(1)
        end = match.end()
        if end < len(text) and text[end] == "*":
            end += 1
        if name == "hyperref":
            end = balanced_end(text, end, "[", "]")
            end = balanced_end(text, end)
        else:
            arguments = 1 if name in {"ref", "pageref"} else 2
            for _ in range(arguments):
                end = balanced_end(text, end)
        pieces.append("" if name == "hypertarget" else "<REF>")
        position = end
    return re.sub(r"\s+", " ", "".join(pieces)).strip()


def fingerprint(path):
    data = path.read_bytes()
    return {"file": path.name, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--two", type=Path, required=True)
    parser.add_argument("--three", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    two, three = extract_rows(args.two), extract_rows(args.three)
    differences = []
    for key in two:
        a = normalize_references(two[key]["text"])
        b = normalize_references(three[key]["text"])
        if a != b:
            differences.append({"id": key, "II_line": two[key]["line"],
                                "III_line": three[key]["line"], "II": a, "III": b})
    result = {
        "status": "PASS" if not differences else "DIFFERENCES",
        "inputs": [fingerprint(args.two), fingerprint(args.three)],
        "counts_each": {"methods": 91, "classes": 121, "conditions": 190},
        "total_rows_each": len(two),
        "equal_after_reference_normalization": len(two) - len(differences),
        "differences": differences,
        "scope": "All non-reference row text and formulas, with whitespace normalized; not link-target or theorem-proof validation.",
    }
    encoded = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
