#!/usr/bin/env python3
"""Verify or restore exact content from the available Collatz source archive.

Python standard library only. Reads bytes; never imports or executes an archive
member. Nested ZIP readers are cached. Extracted files have flat, hash-prefixed
names and are written only after the complete content hash and size match.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import zipfile

INDEX_NAME = "AVAILABLE_SOURCE_INDEX.json"
CHUNK = 1024 * 1024
MAX_MEMBER_BYTES = 100_000_000
MAX_INDEX_BYTES = 20_000_000
MAX_LOCATOR_DEPTH = 64


class ArchiveError(Exception):
    """A source/index integrity or safe-restoration failure."""


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def same_file(a: Path, b: Path) -> bool:
    if a.resolve() == b.resolve():
        return True
    return a.exists() and b.exists() and a.samefile(b)


def normalize_alias(value: str) -> str:
    value = value.replace("\\", "/")
    while value.startswith("./"):
        value = value[2:]
    return value


def workspace_aliases(record: dict) -> list[str]:
    return [a["path"] for a in record.get("aliases", [])
            if isinstance(a, dict) and a.get("kind") == "workspace_snapshot"
            and isinstance(a.get("path"), str)]


def safe_output_name(record: dict) -> str:
    # Treat both slash conventions as separators; no archive directory is used.
    source = record.get("canonical_name") or record["locator"][-1]
    base = str(source).replace("\\", "/").split("/")[-1]
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._-") or "source"
    if len(base) > 140:
        suffix = Path(base).suffix[:16]
        base = base[:140-len(suffix)] + suffix
    return record["sha256"][:16] + "_" + base


class SourceArchive:
    def __init__(self, path: Path):
        self.path = path.resolve()
        self._stack = ExitStack()
        self._containers: dict[tuple[str, ...], zipfile.ZipFile] = {}
        self._archive_blobs: dict[tuple[str, ...], bytes] = {}
        self._members: dict[int, dict[str, list[zipfile.ZipInfo]]] = {}
        self._by_locator: dict[tuple[str, ...], dict] = {}
        self.nested_open_count = 0
        try:
            root = self._stack.enter_context(zipfile.ZipFile(self.path, "r"))
            self._containers[()] = root
            info = self._member(root, INDEX_NAME)
            if info.file_size > MAX_INDEX_BYTES:
                raise ArchiveError("index_exceeds_size_limit")
            index_data = self._read_limited(root, info, MAX_INDEX_BYTES)
            self.index_sha256 = hashlib.sha256(index_data).hexdigest()
            self.index = json.loads(index_data.decode("utf-8"))
            self.records = self._validate_index(self.index)
            self._by_locator = {tuple(r["locator"]): r for r in self.records}
        except Exception:
            self._stack.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self._stack.close()

    @staticmethod
    def _validate_index(index: dict) -> list[dict]:
        if not isinstance(index, dict) or index.get("schema") != 1:
            raise ArchiveError("unsupported_index_schema")
        rows = index.get("files")
        if not isinstance(rows, list) or not rows:
            raise ArchiveError("missing_source_records")
        seen_hashes: set[str] = set()
        seen_locators: set[tuple[str, ...]] = set()
        for row in rows:
            if not isinstance(row, dict):
                raise ArchiveError("invalid_source_record")
            sha, size, locator = (row.get(k) for k in ("sha256", "size_bytes", "locator"))
            if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{64}", sha):
                raise ArchiveError("invalid_content_sha256")
            if type(size) is not int or not 0 <= size <= MAX_MEMBER_BYTES:
                raise ArchiveError("invalid_source_size")
            if (not isinstance(locator, list) or not 1 <= len(locator) <= MAX_LOCATOR_DEPTH
                    or any(not isinstance(s, str) or not s or "\x00" in s for s in locator)):
                raise ArchiveError("invalid_nested_locator")
            if sha in seen_hashes or tuple(locator) in seen_locators:
                raise ArchiveError("duplicate_content_or_locator_record")
            seen_hashes.add(sha)
            seen_locators.add(tuple(locator))
        if index.get("unique_contents") != len(rows):
            raise ArchiveError("source_record_count_mismatch")
        return rows

    def _member(self, container: zipfile.ZipFile, name: str) -> zipfile.ZipInfo:
        key = id(container)
        if key not in self._members:
            groups: dict[str, list[zipfile.ZipInfo]] = {}
            for info in container.infolist():
                groups.setdefault(info.filename, []).append(info)
            self._members[key] = groups
        choices = self._members[key].get(name, [])
        if len(choices) != 1:
            raise ArchiveError("missing_or_ambiguous_zip_member")
        info = choices[0]
        if info.is_dir():
            raise ArchiveError("locator_resolves_to_directory")
        if info.flag_bits & 1:
            raise ArchiveError("encrypted_member_not_supported")
        return info

    @staticmethod
    def _read_limited(container: zipfile.ZipFile, info: zipfile.ZipInfo, limit: int) -> bytes:
        if info.file_size > limit:
            raise ArchiveError("member_exceeds_size_limit")
        blocks = []
        total = 0
        with container.open(info, "r") as stream:
            for block in iter(lambda: stream.read(CHUNK), b""):
                total += len(block)
                if total > limit:
                    raise ArchiveError("decompressed_member_exceeds_size_limit")
                blocks.append(block)
        if total != info.file_size:
            raise ArchiveError("zip_member_size_mismatch")
        return b"".join(blocks)

    @staticmethod
    def _check_bytes(data: bytes, record: dict) -> None:
        if len(data) != record["size_bytes"]:
            raise ArchiveError("source_size_mismatch")
        if hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise ArchiveError("source_sha256_mismatch")

    def _container(self, locator: tuple[str, ...]) -> zipfile.ZipFile:
        if locator in self._containers:
            return self._containers[locator]
        parent = self._container(locator[:-1])
        info = self._member(parent, locator[-1])
        data = self._read_limited(parent, info, MAX_MEMBER_BYTES)
        indexed = self._by_locator.get(locator)
        if indexed is not None:
            self._check_bytes(data, indexed)
        buffer = self._stack.enter_context(io.BytesIO(data))
        container = self._stack.enter_context(zipfile.ZipFile(buffer, "r"))
        self._containers[locator] = container
        self._archive_blobs[locator] = data
        self.nested_open_count += 1
        return container

    def verified_content(self, record: dict, keep: bool = False) -> bytes | None:
        locator = tuple(record["locator"])
        if locator in self._archive_blobs:
            data = self._archive_blobs[locator]
            self._check_bytes(data, record)
            return data if keep else None
        container = self._container(locator[:-1])
        info = self._member(container, locator[-1])
        if info.file_size != record["size_bytes"]:
            raise ArchiveError("source_declared_size_mismatch")
        h, total, chunks = hashlib.sha256(), 0, []
        with container.open(info, "r") as stream:
            for block in iter(lambda: stream.read(CHUNK), b""):
                total += len(block)
                if total > record["size_bytes"]:
                    raise ArchiveError("source_decompressed_size_mismatch")
                h.update(block)
                if keep:
                    chunks.append(block)
        if total != record["size_bytes"] or h.hexdigest() != record["sha256"]:
            raise ArchiveError("source_content_integrity_failure")
        return b"".join(chunks) if keep else None

    def select_sha(self, value: str) -> dict:
        value = value.lower()
        if not re.fullmatch(r"[0-9a-f]{8,64}", value):
            raise ArchiveError("sha_selector_requires_8_to_64_hex_digits")
        rows = [r for r in self.records if r["sha256"].startswith(value)]
        if len(rows) != 1:
            raise ArchiveError("sha_selector_missing_or_ambiguous")
        return rows[0]

    def select_path(self, value: str) -> dict:
        value = normalize_alias(value)
        rows = [r for r in self.records if value in
                {normalize_alias(p) for p in workspace_aliases(r)}]
        if len(rows) != 1:
            raise ArchiveError("workspace_path_missing_or_ambiguous_use_list_or_sha")
        return rows[0]

    def list_records(self, phrase: str | None) -> list[dict]:
        output = []
        for r in self.records:
            name = str(r.get("canonical_name", ""))
            aliases = workspace_aliases(r)
            haystack = "\n".join([r["sha256"], name, *aliases, *r["locator"]])
            if phrase is not None and phrase.casefold() not in haystack.casefold():
                continue
            output.append({"sha256": r["sha256"], "size_bytes": r["size_bytes"],
                           "name": name, "workspace_paths": aliases,
                           "locator_depth": len(r["locator"])})
        return output


def restore_record(source: SourceArchive, record: dict, output: Path) -> dict:
    content = source.verified_content(record, keep=True)
    if content is None:
        raise ArchiveError("restoration_content_unavailable")
    output.mkdir(parents=True, exist_ok=True)
    directory = output.resolve()
    target = directory / safe_output_name(record)
    if target.parent != directory or same_file(target, source.path):
        raise ArchiveError("unsafe_restore_destination")
    if target.is_symlink():
        raise ArchiveError("refusing_symlink_destination")
    if target.exists():
        if (not target.is_file() or target.stat().st_size != record["size_bytes"]
                or file_sha256(target) != record["sha256"]):
            raise ArchiveError("existing_destination_has_different_content")
        disposition = "already_present_and_verified"
    else:
        # Exclusive creation also rejects a symlink/file inserted after the check.
        with target.open("xb") as stream:
            stream.write(content)
        if target.stat().st_size != record["size_bytes"] or file_sha256(target) != record["sha256"]:
            raise ArchiveError("written_content_verification_failed")
        disposition = "restored_and_verified"
    return {"sha256": record["sha256"], "size_bytes": record["size_bytes"],
            "output_filename": target.name, "disposition": disposition,
            "locator_depth": len(record["locator"])}


def error_code(exc: Exception) -> str:
    # No source bytes, arbitrary filenames, credentials or tracebacks in reports.
    return str(exc) if isinstance(exc, ArchiveError) else type(exc).__name__


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Source ZIP containing AVAILABLE_SOURCE_INDEX.json")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--verify-all", action="store_true", help="Verify SHA256 and size of every indexed unique source")
    mode.add_argument("--sha", help="Restore one unique full content SHA256 or prefix of at least8 hex digits")
    mode.add_argument("--path", help="Restore one exact original workspace path alias shown by --list")
    mode.add_argument("--list", action="store_true", help="List indexed source identities without restoring")
    parser.add_argument("--filter", help="Case-insensitive substring for --list")
    parser.add_argument("--output", type=Path, help="Directory for --sha/--path restoration")
    parser.add_argument("--report", type=Path, help="Write the sanitized JSON result to this file")
    parser.add_argument("--expected-archive-sha256", help="Optional expected SHA256 of the whole input ZIP")
    args = parser.parse_args(argv)
    if bool(args.sha or args.path) != bool(args.output):
        parser.error("--output is required only for --sha or --path")
    if args.filter is not None and not args.list:
        parser.error("--filter applies only to --list")
    if args.expected_archive_sha256 is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", args.expected_archive_sha256):
        parser.error("--expected-archive-sha256 requires exactly64 hex digits")
    mode_name = "verify_all" if args.verify_all else "list" if args.list else "restore"
    result = {"schema": 1, "mode": mode_name, "status": "FAIL",
              "checked_at_utc": datetime.now(timezone.utc).isoformat(),
              "archive_name": args.archive.name,
              "verifier_sha256": file_sha256(Path(__file__)),
              "scope": "Exact preserved-byte integrity only; no source code execution or mathematical proof verification."}
    try:
        if args.report and same_file(args.report, args.archive):
            raise ArchiveError("report_must_not_overwrite_input_archive")
        result["archive_size_bytes"] = args.archive.stat().st_size
        result["archive_sha256"] = file_sha256(args.archive)
        if args.expected_archive_sha256 is not None:
            if result["archive_sha256"] != args.expected_archive_sha256.lower():
                raise ArchiveError("outer_archive_sha256_mismatch")
            result["expected_archive_sha256_matched"] = True
        with SourceArchive(args.archive) as source:
            result.update(index_sha256=source.index_sha256, indexed_unique_sources=len(source.records))
            if args.verify_all:
                checks = []
                for r in source.records:
                    check = {"sha256": r["sha256"], "size_bytes": r["size_bytes"],
                             "locator_depth": len(r["locator"]), "status": "PASS"}
                    try:
                        source.verified_content(r)
                    except Exception as exc:
                        check.update(status="FAIL", error_code=error_code(exc))
                    checks.append(check)
                failures = sum(c["status"] != "PASS" for c in checks)
                result.update(status="FAIL" if failures else "PASS", checked_sources=len(checks),
                              failed_sources=failures,
                              indexed_unique_bytes=sum(r["size_bytes"] for r in source.records),
                              checks=checks)
            elif args.list:
                matches = source.list_records(args.filter)
                result.update(status="PASS", matched_sources=len(matches), sources=matches)
            else:
                r = source.select_sha(args.sha) if args.sha else source.select_path(args.path)
                result.update(status="PASS", restored=restore_record(source, r, args.output))
            result["nested_zip_readers_opened"] = source.nested_open_count
    except Exception as exc:
        result.update(status="FAIL", error_code=error_code(exc))
    text = json.dumps(result, indent=2, ensure_ascii=True) + "\n"
    if args.report:
        try:
            if same_file(args.report, args.archive):
                raise ArchiveError("report_must_not_overwrite_input_archive")
            if args.report.is_symlink():
                raise ArchiveError("refusing_symlink_report_destination")
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(text, encoding="utf-8")
        except Exception as exc:
            print(json.dumps({"status": "FAIL", "error_code": error_code(exc)}))
            return 1
        summary = {k: v for k, v in result.items() if k not in ("checks", "sources")}
        summary["report_filename"] = args.report.name
        print(json.dumps(summary, indent=2, ensure_ascii=True))
    else:
        print(text, end="")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
