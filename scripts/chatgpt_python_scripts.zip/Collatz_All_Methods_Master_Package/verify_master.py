#!/usr/bin/env python3
"""Verify this research-memory package, not the Collatz conjecture.

Standard library only. Do not run Python with -O. --source-archive additionally
replays all content hashes of the companion historical archive (no code exec).
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import subprocess
import sys
import tempfile

def read_csv(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-archive',type=Path)
    args=parser.parse_args()
    if not __debug__:raise SystemExit('Run without -O')
    root=Path(__file__).resolve().parent
    checked=0
    for line in (root/'MANIFEST.sha256').read_text().splitlines():
        expected,rel=line.split('  ',1)
        p=root/rel
        assert p.is_file(),rel
        assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,rel
        checked+=1
    methods=read_csv(root/'catalogue/All_91_Methods.csv')
    assert len(methods)==91
    assert {r['id'] for r in methods}=={f'M{i:02}' for i in range(1,92)}
    classes=read_csv(root/'cases/Canonical_Classes_C01_C121_Coverage.csv')
    assert len(classes)==121
    assert {r['class_id'] for r in classes}=={f'C{i:02}' for i in range(1,122)}
    data=json.loads((root/'catalogue/All_402_Inventory_Entries.json').read_text())
    assert len(data['inventory'])==402
    history=json.loads((root/'catalogue/Historical_Method_Updates.json').read_text())
    assert len(history['sections'])==201
    matrix=read_csv(root/'combination/Method_Compatibility.csv')
    assert len(matrix)==28
    status=json.loads((root/'Master_Status.json').read_text())
    assert not status['all_positive_integers_covered']
    assert not status['central_aggregate_uniform_bound_proved']
    assert status['source_archive']['unique_contents']==919
    # Only the new finite exact algebra/precision controls are executed here.
    result=subprocess.run([sys.executable,'-B',str(root/'combination/verify_resource_combination.py')],
                          cwd=root,capture_output=True,text=True,check=True)
    control=json.loads(result.stdout)
    assert control['status']=='PASS'
    archive_check=None
    if args.source_archive:
        expected=status['source_archive']['archive_sha256']
        assert hashlib.sha256(args.source_archive.read_bytes()).hexdigest()==expected
        with tempfile.TemporaryDirectory(prefix='collatz_archive_verify_') as td:
            report=Path(td)/'result.json'
            subprocess.run([sys.executable,'-B',str(root/'archive_tools/restore_source.py'),
                            str(args.source_archive.resolve()),'--verify-all','--report',str(report)],
                           cwd=root,capture_output=True,text=True,check=True)
            full=json.loads(report.read_text())
            assert full['status']=='PASS'
            archive_check={k:full[k] for k in ['status','checked_sources','failed_sources','archive_sha256']}
    print(json.dumps({'status':'PASS','scope':'package integrity, complete ID coverage and finite rational accounting; no unrestricted theorem is verified',
                      'hashed_payloads':checked,'methods':91,'classes':121,'conditions_results':190,
                      'canonical_entries':402,'historical_sections':201,'operational_families':28,
                      'resource_controls':control['counts'],'source_archive_check':archive_check},indent=2))

if __name__=='__main__':main()
