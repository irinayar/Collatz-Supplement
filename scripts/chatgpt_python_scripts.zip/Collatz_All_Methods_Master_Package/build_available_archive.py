#!/usr/bin/env python3
"""Preserve available Collatz sources and all original archive bytes, deduplicated.

This inventories bytes and provenance; it does not certify their mathematics.
Nested archive locators preserve all original ZIPs without storing each twice.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import hashlib
import io
import json
import os
import re
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'collatz_master_work'
DEST=ROOT/'Collatz_Available_Research_Archive.zip'
ALLOWED={'.md','.tex','.py','.json','.csv','.txt','.npz','.sha256','.cpp','.h','.c','.cs','.ps1','.sh','.yaml','.yml','.toml','.ipynb','.pdf'}

def digest(data):return hashlib.sha256(data).hexdigest()

def identity(path):
    out={}
    for attr,key in [('user.library-file-id','library_file_id'),('user.library-file-version','version')]:
        try:out[key]=os.getxattr(path,attr).decode()
        except OSError:pass
    return out

def main():
    raw=json.loads((WORK/'workspace_candidate_paths.json').read_text())
    # Add manifest, compressed-array and text artifacts not in the initial list.
    scan=subprocess.run(['rg','--files'],cwd=ROOT,capture_output=True,text=True,check=True)
    raw=sorted(set(raw+scan.stdout.splitlines()))
    candidates=[]
    for rel in raw:
        p=ROOT/rel
        if rel.startswith('collatz_master_work/') or rel.startswith('collatz_master_release/'):
            continue
        if p.name.endswith(('_receipt.json','_receipts.json')) or not p.is_file():continue
        if re.search(r'library.*(?:stdout|stderr|receipt|helper_path)',p.name,re.I):continue
        if p.suffix not in ALLOWED|{'.zip'} and p.name!='MANIFEST.sha256':continue
        if p.name.startswith('Collatz_Master_') or p.name==DEST.name:continue
        candidates.append(p)
    candidates += list((WORK/'library_sources').rglob('*.md'))
    candidates += [WORK/'recorded_C85_update.txt']
    candidate_hash={p:digest(p.read_bytes()) for p in candidates}
    raw_zips={candidate_hash[p]:p for p in candidates if p.suffix=='.zip'}
    children=set();edge_rows=[];seen=set()
    def edges(data,h):
        if h in seen:return
        seen.add(h)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if not info.is_dir() and info.filename.lower().endswith('.zip'):
                    b=z.read(info);ch=digest(b);children.add(ch)
                    edge_rows.append({'parent':h,'child':ch,'member':info.filename})
                    edges(b,ch)
    for h,p in raw_zips.items():edges(p.read_bytes(),h)
    roots=sorted([(h,p) for h,p in raw_zips.items() if h not in children],key=lambda x:x[1].name)
    records={};walked=set()
    def register(data,locator,name,alias=None):
        h=digest(data)
        row=records.setdefault(h,{'sha256':h,'size_bytes':len(data),'suffix':Path(name).suffix,
                                 'canonical_name':name,'locator':locator,'aliases':[],
                                 'library_identities':[],'mathematical_status':'Preserved source bytes; not a new proof verification.'})
        if alias is not None and alias not in row['aliases']:row['aliases'].append(alias)
        return h
    def inventory_zip(data,h,locator):
        register(data,locator,Path(locator[-1]).name)
        if h in walked:return
        walked.add(h)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if info.is_dir():continue
                if info.file_size>100_000_000:raise ValueError('Oversized source member')
                b=z.read(info);loc=locator+[info.filename]
                ch=register(b,loc,info.filename,{'kind':'archive_member','archive_sha256':h,'member':info.filename})
                if info.filename.lower().endswith('.zip'):inventory_zip(b,ch,loc)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
        for h,p in roots:
            member='original_archives/'+p.name
            out.write(p,member)
            inventory_zip(p.read_bytes(),h,[member])
        extras=0
        for p in candidates:
            data=p.read_bytes();h=candidate_hash[p]
            alias={'kind':'workspace_snapshot','path':p.relative_to(ROOT).as_posix()}
            if h not in records:
                name=re.sub(r'[^A-Za-z0-9._-]+','_',p.name)
                member='additional_sources/'+h[:16]+'_'+name
                out.writestr(member,data)
                register(data,[member],p.name,alias);extras+=1
            elif alias not in records[h]['aliases']:records[h]['aliases'].append(alias)
            ident=identity(p)
            if ident and ident not in records[h]['library_identities']:records[h]['library_identities'].append(ident)
        rows=sorted(records.values(),key=lambda x:x['sha256'])
        summary={'schema':1,'scope':'All identified source files in this Collatz workspace snapshot, six resolved historical inventory files, and the recorded latest C85 task result. Not a claim that every historical chat or unavailable later manuscript was retrieved.',
                 'source_path_count':len(candidates),'unique_contents':len(rows),
                 'original_archive_count':len(seen),'root_archives_stored':len(roots),
                 'root_archive_bytes':sum(p.stat().st_size for _,p in roots),
                 'additional_contents_stored':extras,
                 'unique_content_bytes':sum(r['size_bytes'] for r in rows),
                 'suffix_counts':dict(sorted(Counter(r['suffix'] for r in rows).items())),
                 'archive_edges':edge_rows,'files':rows}
        encoded=json.dumps(summary,indent=2,ensure_ascii=False)+'\n'
        out.writestr('AVAILABLE_SOURCE_INDEX.json',encoded)
        out.writestr('README.txt','Available Collatz research source snapshot.\n\nEvery original ZIP is retained byte-for-byte, either at original_archives/ or inside another retained archive. AVAILABLE_SOURCE_INDEX.json maps every unique content hash and original path to a locator. Each subsequent locator element is a member within the preceding ZIP. Additional files are under additional_sources/. The companion master package provides restore_source.py.\n\nPreservation is not mathematical certification. Missing later manuscript versions, original external ledger bytes, and the latest C85 full proof/certificate package remain explicitly marked unavailable in the master memory.\n')
    (WORK/'AVAILABLE_SOURCE_INDEX.json').write_text(encoded)
    # CRC validation and exact original-container inventory are sufficient here;
    # the separate verifier checks every locator and SHA without executing code.
    with zipfile.ZipFile(DEST) as z:assert z.testzip() is None
    result={k:v for k,v in summary.items() if k not in ['files','archive_edges']}
    result.update(archive=str(DEST),archive_size_bytes=DEST.stat().st_size,archive_sha256=digest(DEST.read_bytes()))
    (WORK/'available_archive_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
