#!/usr/bin/env python3
"""Exact resource accounting for combining signed Collatz estimates.

This checks a finite algebraic certificate. It does not prove the hypotheses
or uniformity of an imported Collatz estimate. Each resource coordinate must
refer to an original occurrence, including its source and visit copy.

Run without arguments for deterministic rational controls. Pass --certificate
FILE to check a finite certificate with the same JSON schema as --example.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction as F
from pathlib import Path
from random import Random


def frac(value):
    if isinstance(value, float):
        raise ValueError("Use integer or rational-string data, never floats")
    return F(value)


def dot(a, b):
    return sum((x * y for x, y in zip(a, b, strict=True)), F(0))


def check_certificate(data):
    pos = [frac(x) for x in data["positive_values"]]
    neg = [frac(x) for x in data["credit_values"]]
    if any(x < 0 for x in pos + neg):
        raise ValueError("Positive resources and credits must be nonnegative")
    plabel = data.get("positive_labels", [f"p{i}" for i in range(len(pos))])
    nlabel = data.get("credit_labels", [f"n{i}" for i in range(len(neg))])
    if len(plabel) != len(pos) or len(nlabel) != len(neg):
        raise ValueError("Labels must identify every occurrence")
    if len(set(plabel)) != len(plabel) or len(set(nlabel)) != len(nlabel):
        raise ValueError("Repeated physical values require distinct occurrence labels")
    ap, bn = [F(0)] * len(pos), [F(0)] * len(neg)
    weighted_actual = F(0)
    weighted_upper = F(0)
    rows = []
    for row in data["rows"]:
        weight = frac(row["weight"])
        a = [frac(x) for x in row["positive_coefficients"]]
        b = [frac(x) for x in row["credit_coefficients"]]
        upper = frac(row["upper_bound"])
        if len(a) != len(pos) or len(b) != len(neg):
            raise ValueError("Every certificate row must use the same resource universe")
        if any(x < 0 for x in [weight] + a + b):
            raise ValueError("Incidence coefficients and weights must be nonnegative")
        actual = dot(a, pos) - dot(b, neg)
        if actual > upper:
            raise ValueError(f"Row {row['name']} fails its stated finite inequality")
        ap = [x + weight * y for x, y in zip(ap, a, strict=True)]
        bn = [x + weight * y for x, y in zip(bn, b, strict=True)]
        weighted_actual += weight * actual
        weighted_upper += weight * upper
        rows.append({"name": row["name"], "actual": str(actual), "upper": str(upper)})
    if any(x > 1 for x in ap):
        raise ValueError("A positive occurrence is allocated more than once")
    if any(x > 1 for x in bn):
        raise ValueError("A negative credit is spent more than once")
    exact = sum(pos, F(0)) - sum(neg, F(0))
    residual = dot([1 - x for x in ap], pos) - dot([1 - x for x in bn], neg)
    if exact != weighted_actual + residual:
        raise AssertionError("Resource decomposition identity failed")
    upper_exact_residual = weighted_upper + residual
    assert exact <= upper_exact_residual
    cap_channels = data.get("positive_cap_channels", [])
    if cap_channels:
        channels = [[frac(x) for x in channel] for channel in cap_channels]
        if any(len(c) != len(pos) for c in channels):
            raise ValueError("Each cap channel must cover the same positive occurrences")
        if any(x < value for c in channels for x, value in zip(c, pos, strict=True)):
            raise ValueError("A finite positive cap does not dominate its occurrence")
        caps = [min(c[i] for c in channels) for i in range(len(pos))]
        upper_capped = weighted_upper + dot([1 - x for x in ap], caps) - dot([1 - x for x in bn], neg)
        assert exact <= upper_exact_residual <= upper_capped
    else:
        caps = None
        upper_capped = upper_exact_residual
    return {
        "scope": "finite rational resource accounting; imported theorem hypotheses are not verified",
        "exact_ledger": str(exact),
        "positive_loads": list(map(str, ap)),
        "credit_loads": list(map(str, bn)),
        "weighted_actual": str(weighted_actual),
        "weighted_upper": str(weighted_upper),
        "exact_residual": str(residual),
        "upper_with_exact_residual": str(upper_exact_residual),
        "minimum_positive_caps": None if caps is None else list(map(str, caps)),
        "upper_with_caps": str(upper_capped),
        "rows": rows,
    }


def example():
    return {
        "description": "Two covers share one credit; half allocation retains the unused positives",
        "positive_labels": ["source_A:run_1:visit_1", "source_B:run_1:visit_1"],
        "credit_labels": ["source_A:run_2:visit_1"],
        "positive_values": [6, 5],
        "credit_values": [5],
        "positive_cap_channels": [[8, 7], [7, 8]],
        "rows": [
            {"name": "cover_A", "weight": "1/2", "positive_coefficients": [1, 0], "credit_coefficients": [1], "upper_bound": 1},
            {"name": "cover_B", "weight": "1/2", "positive_coefficients": [0, 1], "credit_coefficients": [1], "upper_bound": 0},
        ],
    }


def exact_controls():
    counts = {"resource_certificates": 0, "invalid_double_credit_rejected": 0,
              "invalid_duplicate_label_rejected": 0, "overlap_identities": 0,
              "multiplicity_controls": 0, "cap_minimum_controls": 0,
              "valuation_cylinder_checks": 0, "method_catalogue_coverage_checks": 0,
              "signed_suffix_counting_checks": 0, "subclass_cap_controls": 0,
              "boundary_off_credit_controls": 0}
    valid = example()
    first = check_certificate(valid)
    assert F(first["exact_ledger"]) == 6
    assert F(first["weighted_upper"]) == F(1, 2)
    assert F(first["exact_residual"]) == F(11, 2)
    counts["resource_certificates"] += 1
    bad = json.loads(json.dumps(valid))
    for row in bad["rows"]:
        row["weight"] = 1
    try:
        check_certificate(bad)
        raise AssertionError("Double spending was accepted")
    except ValueError as exc:
        assert "spent more than once" in str(exc)
        counts["invalid_double_credit_rejected"] += 1
    bad = json.loads(json.dumps(valid))
    bad["positive_labels"] = ["same occurrence", "same occurrence"]
    try:
        check_certificate(bad)
        raise AssertionError("Duplicate occurrence label was accepted")
    except ValueError as exc:
        assert "distinct occurrence labels" in str(exc)
        counts["invalid_duplicate_label_rejected"] += 1
    # Shared positive atom of size 3 occurs in two envelopes, but once in the union.
    envelope_sum, union_value, credit = F(5 + 8), F(2 + 3 + 5), F(4)
    surplus = envelope_sum - union_value
    assert union_value - credit == envelope_sum - surplus - credit == 6
    counts["overlap_identities"] += 1
    # Two profiles sharing a physical suffix still incur two copies of its cost.
    actual_suffix, cap, mass = F(3), F(4), 2
    assert mass * actual_suffix <= mass * cap and mass * actual_suffix > cap
    counts["multiplicity_controls"] += 1
    assert F(3) <= min(F(5), F(4)) == 4
    counts["cap_minimum_controls"] += 1
    # A cap on one subclass is not a cap on the full multiset.
    part_a, part_b = F(3), F(4)
    assert part_a + part_b > min(part_a, part_b)
    assert part_a + part_b <= min(F(8), part_a + part_b)
    counts["subclass_cap_controls"] += 1
    # Actual complete-run arithmetic, with deliberately specified arbitrary masks.
    # These controls verify the algebra, not eligibility as original core masks.
    masks = [[1, 1, 0, 1, 0], [0, 1, 1, 0, 1], [1, 0, 1, 1, 0]]
    omitted = {(0, 1), (0, 2)}
    a, kappa = 27, F(26, 28)
    for j in range(5):
        s = ((a + 1) & -(a + 1)).bit_length() - 1
        even = (3 ** s * (a + 1)) // (2 ** s) - 1
        extra = (even & -even).bit_length() - 1
        b = even // (2 ** extra)
        delta = (1 - F(2, 3) ** s) / a
        flux = F(1, a) - F(1, b)
        t = kappa * delta + flux
        c = max(-flux - delta / 15, F(0))
        h = t + c
        assert h == (kappa - F(1, 15)) * delta + max(flux + delta / 15, F(0)) > 0
        active = [p for p in range(3) if (p, j) not in omitted]
        m = len(active)
        n_core = sum(masks[p][j] for p in active)
        direct = sum((t if masks[p][j] else -c for p in active), F(0))
        assert direct == n_core * h - m * c
        if j == 2:
            assert c > 0 and masks[0][j] == 0 and (0, j) in omitted
            assert direct > n_core * h - 3 * c
            counts["boundary_off_credit_controls"] += 1
        full_count_cap = min(m, n_core + 1)
        assert direct <= full_count_cap * h - m * c
        counts["signed_suffix_counting_checks"] += 1
        a = b
    rng = Random(20261123)
    for _ in range(250):
        p, n, m = rng.randrange(1, 7), rng.randrange(1, 5), rng.randrange(1, 7)
        pos = [F(rng.randrange(1, 30), rng.randrange(1, 9)) for _ in range(p)]
        neg = [F(rng.randrange(1, 25), rng.randrange(1, 9)) for _ in range(n)]
        aa = [[F(rng.randrange(0, 4), 3) for _ in range(p)] for _ in range(m)]
        bb = [[F(rng.randrange(0, 4), 3) for _ in range(n)] for _ in range(m)]
        ww = [F(rng.randrange(1, 5), 4) for _ in range(m)]
        loads = [sum((ww[j] * aa[j][i] for j in range(m)), F(0)) for i in range(p)]
        loads += [sum((ww[j] * bb[j][i] for j in range(m)), F(0)) for i in range(n)]
        scale = max([F(1)] + loads)
        ww = [w / scale for w in ww]
        rows = [{"name": f"row_{j}", "weight": str(ww[j]),
                 "positive_coefficients": list(map(str, aa[j])),
                 "credit_coefficients": list(map(str, bb[j])),
                 "upper_bound": str(dot(aa[j], pos) - dot(bb[j], neg) + F(rng.randrange(0, 6), 7))}
                for j in range(m)]
        data = {"positive_values": list(map(str, pos)), "credit_values": list(map(str, neg)),
                "rows": rows,
                "positive_cap_channels": [list(map(str, [x + F(1, 3) for x in pos])),
                                          list(map(str, [x + F(1, 5) for x in pos]))]}
        checked = check_certificate(data)
        assert all(F(v) == x + F(1, 5) for v, x in zip(checked["minimum_positive_caps"], pos, strict=True))
        counts["resource_certificates"] += 1
        counts["cap_minimum_controls"] += 1
    # Exact odd-valuation residue includes the final odd bit (modulus 2^(E+1)).
    for word in [(1,), (2,), (1, 1, 3), (1, 2, 2), (1, 1, 1, 1, 4), (2, 3, 1, 2)]:
        E, C = 0, 0
        for e in word:
            C = 3 * C + 2 ** E
            E += e
        modulus = 2 ** (E + 1)
        a = ((2 ** E - C) * pow(3 ** len(word), -1, modulus)) % modulus
        for lift in range(3):
            u = a + lift * modulus
            x = u
            for e in word:
                z = 3 * x + 1
                assert z % (2 ** e) == 0 and (z // (2 ** e)) % 2 == 1
                x = z // (2 ** e)
            assert x == (3 ** len(word) * u + C) // (2 ** E)
            counts["valuation_cylinder_checks"] += 1
    compat = Path(__file__).with_name("Method_Compatibility.csv")
    if compat.exists():
        import csv
        rows = list(csv.DictReader(compat.open()))
        ids = {s for row in rows for s in row["historical_method_ids"].split(";") if s}
        assert ids == {f"M{i:02}" for i in range(1, 92)}
        assert {row["family_id"] for row in rows} == {f"F{i:02}" for i in range(1, 29)}
        counts["method_catalogue_coverage_checks"] += 2
    return {"status": "PASS", "scope": "algebraic controls and small exact residue examples; no new aggregate or convergence bound", "counts": counts, "example_result": first}


def main():
    if not __debug__:
        raise SystemExit("Run without -O: exact certificate assertions must remain enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--example", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.example:
        args.example.write_text(json.dumps(example(), indent=2) + "\n")
    result = check_certificate(json.loads(args.certificate.read_text())) if args.certificate else exact_controls()
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(rendered, end="")


if __name__ == "__main__":
    main()
