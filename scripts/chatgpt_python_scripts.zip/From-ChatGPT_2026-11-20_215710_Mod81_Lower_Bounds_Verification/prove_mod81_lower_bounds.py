from fractions import Fraction

def normalized(x, e):
    a,b,c=e
    return Fraction(8*x,27)-Fraction(4,27*2**a)-Fraction(2,9*2**b)-Fraction(1,3*2**c)

def inverse_word(x,k,positions):
    n=x; prev=0
    for e in positions:
        for _ in range(e-prev): n*=2
        if (2*n-1)%3: return None
        n=(2*n-1)//3
        if n<=0 or n%2==0:return None
        prev=e
    return n*2**(k-prev)

for x,k0,c in [(4,4,Fraction(17,16)),(5,3,Fraction(11,8))]:
    for k in range(k0,31):
        best=None; arg=None
        for a in range(k+1):
            for b in range(a,k+1):
                for d in range(b,k+1):
                    m=inverse_word(x,k,(a,b,d))
                    if m is not None and (best is None or m<best):best,arg=m,(a,b,d)
        assert best==c*2**k,(x,k,best,arg,c*2**k)
    print('PASS',x,'k',k0,'..30','ratio',c)
assert normalized(4,(1,3,4))==Fraction(17,16)
assert normalized(5,(2,3,3))==Fraction(11,8)
print('All checks passed')
