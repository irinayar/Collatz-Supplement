from fractions import Fraction
from math import comb,exp

def b(j):
    return Fraction(sum(min(comb(j,a),3**a) for a in range(j+1)),2**j)

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def image_count(N,j):
    s=set(range(1,N+1))
    for _ in range(j): s={T(x) for x in s}
    return len(s)

for j in range(0,12):
    B=b(j)
    N=6000
    count=image_count(N,j)
    assert Fraction(count,N)<=B+Fraction(2**j,N)*sum(min(comb(j,a),3**a) for a in range(j+1)) # loose finite correction
    print(j, B, round(float(B),8), count)
for j in [50,100,200,400]:
    print('bound',j, float(b(j)), 'exp bound',2.5*exp(-.02*j))
