import json
from min_origin_exact import H

def brute(x,k,r):
    stack=[(x,k,r)]
    best=None
    while stack:
        y,a,b=stack.pop()
        if a==0 and b==0:
            if best is None or y<best:best=y
            continue
        if a:stack.append((2*y,a-1,b))
        if b and y%3==2:stack.append(((2*y-1)//3,a,b-1))
    return best
checks=0
for k in range(7):
 for r in range(5):
  for x in range(3,3**(r+1)+3):
   for rr in (r,r+1):
    a=H(x,k,rr);b=brute(x,k,rr)
    assert a==b,(x,k,rr,a,b)
    checks+=1
print('Independent DFS matches:',checks)
# independently verify translation over available small representatives
checks2=0
for k in range(6):
 for r in range(5):
  for x in range(3,3**(r+1)+3):
   for rr in (r,r+1):
    a=H(x,k,rr);b=H(x+3**(r+1),k,rr)
    if a is not None:
     assert b-a==2**(k+rr)*3**(r+1-rr)
    else:assert b is None
    checks2+=1
print('Translation checks:',checks2)
