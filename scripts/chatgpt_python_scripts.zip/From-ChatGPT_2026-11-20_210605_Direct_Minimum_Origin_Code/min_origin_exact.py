from functools import lru_cache
from collections import Counter
import json
@lru_cache(None)
def H(x,k,r):
    if k==r==0:return x
    z=[]
    if k:z.append(H(2*x,k-1,r))
    if r and x%3==2:z.append(H((2*x-1)//3,k,r-1))
    z=[a for a in z if a is not None]
    return min(z) if z else None

def run(K=8,R=6):
    rows=[]; bad=[]; close=[]; total=0; pruned=Counter(); residue=Counter(); maxgap=(-10**100,None)
    for k in range(K+1):
      for r in range(R+1):
       mod=3**(r+1)
       count=0; tested=0; admissible=0; no_both=0; min_gap=None
       for x in range(3,mod+3):
        a=H(x,k,r);b=H(x,k,r+1)
        if a is None or b is None:
         no_both+=1;continue
        count+=1;d=b-a
        if d>=0:bad.append([x,k,r,a,b,d])
        if d>maxgap[0]:maxgap=(d,[x,k,r,a,b])
        if a%3==2:pruned['mod3_2']+=1
        elif k>=1 and a>=2**(k+1)-3:pruned['envelope']+=1
        else:
         tested+=1
         residue[a%3]+=1
         if len(close)<30:close.append([x,k,r,a,b,d])
       rows.append({'k':k,'r':r,'representatives':mod,'both_feasible':count,'not_both':no_both,'unresolved_after_sufficient_filters':tested})
       total+=count
    return {'range':{'k_max':K,'r_max':R},'total_feasible_pairs':total,'bad':bad,'pruned':dict(pruned),'remaining_residues':dict(residue),'max_difference':maxgap,'rows':rows,'examples_unfiltered':close,'cache':H.cache_info()._asdict()}
if __name__=='__main__':
 out=run();print(json.dumps({k:v for k,v in out.items() if k not in ('rows','examples_unfiltered')},indent=2));open('/mnt/data/min_origin_results.json','w').write(json.dumps(out,indent=2))
