#!/usr/bin/env python3
"""Verify this self-contained research packet, not the Collatz conjecture."""
from pathlib import Path
import csv
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent

def main():
    if not __debug__:
        raise SystemExit('Run without -O: exact assertion checks must remain enabled.')
    manifest = json.loads((HERE/'Package_Manifest.json').read_text())
    for row in manifest['files']:
        path = HERE/row['path']
        data = path.read_bytes()
        assert len(data) == row['bytes'], row['path']
        assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    methods = list(csv.DictReader((HERE/'All_Methods_Applicability_This_Attempt.csv').open()))
    assert len(methods) == 91
    assert {r['method_id'] for r in methods} == {f'M{i:02}' for i in range(1,92)}
    scripts = [
        'cycle/verify_cycle_bridge.py',
        'escape/verify_escape_bounds.py',
        'escape/verify_endpoint_bootstrap.py',
        'signed/verify_short_merge.py',
        'transport/verify_nonempty_core_coalescence.py',
    ]
    records = []
    for name in scripts:
        run = subprocess.run([sys.executable,'-B',str(HERE/name)],
                             cwd=HERE, text=True, capture_output=True)
        if run.returncode:
            print(run.stdout)
            print(run.stderr, file=sys.stderr)
            raise SystemExit(f'FAILED: {name}')
        records.append({'script':name,'returncode':0,'stdout':run.stdout.strip()})
        print(f'PASS: {name}', flush=True)
    result = {'status':'PASS','manifest_files':len(manifest['files']),
              'method_rows':91,'scripts':records,
              'scope':'Packet integrity, exact finite controls and actual witnesses; universal statements require the supplied proofs.',
              'not_replayed':['Historical large canonical certificate','External certified base','Every historical manuscript proof'],
              'global_proof_obtained':False,
              'original_central_budget_proved':False}
    (HERE/'Verification_Results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='scripts'},indent=2))

if __name__ == '__main__':
    main()
