#!/usr/bin/env python3
"""Bounded actual inverse search into an existing nonempty-core fixture."""
from pathlib import Path
import json
import time
from verify_nonempty_core_coalescence import replay, sc

HERE=Path(__file__).resolve().parent

def main():
    data=json.loads((HERE/'original_core_profile.json').read_text())
    n=int(data['n']);H=(4*n-2)//3;P,_,_=sc.source_count(n)
    orig=replay(n,int(data['u']),data['word'],P)
    core=[r for r in orig['runs'] if r['core']]
    odd=orig['odd'];word=data['word'];known_u=int(data['u'])
    maxdepth=18;maxnodes=2_000_000;nodes=0;found=[];started=time.monotonic()
    targets=list(range(1,100))
    for pos in targets:
        if pos>=len(word):break
        y=odd[pos]
        stack=[(y,())]
        while stack:
            x,rev=stack.pop();d=len(rev)
            if d>=maxdepth:continue
            if x%3==0:continue
            remaining=maxdepth-d-1
            e=1 if x%3==2 else 2
            while True:
                parent=((1<<e)*x-1)//3
                if (1<<remaining)*(parent+1)>3**remaining*(H+1):break
                nodes+=1
                if nodes>maxnodes:break
                nr=rev+(e,)
                if n<=parent<=H:
                    if parent==known_u: e+=2;continue
                    w=list(reversed(nr))+word[pos:]
                    try:
                        p=replay(n,parent,w,P)
                    except AssertionError:
                        e+=2;continue
                    c=[r for r in p['runs'] if r['core']]
                    if c:
                        found.append({'n':str(n),'u':str(parent),'word':w,
                                      'join_original_odd_index':pos,'incoming_odd_steps':len(nr),
                                      'join_state':str(y),'core_count':len(c),
                                      'odd_count':len(w),'shortcut_length':sum(w)})
                        print(json.dumps({'found':len(found),'join':pos,'u':str(parent),'core_count':len(c)}),flush=True)
                elif parent>H and d+1<maxdepth:
                    stack.append((parent,nr))
                e+=2
            if nodes>maxnodes or len(found)>=1:break
        if nodes>maxnodes or len(found)>=1:break
    result={'scope':'bounded exact inverse search, not exhaustive over all words',
            'max_incoming_odd_steps':maxdepth,'node_budget':maxnodes,'nodes':nodes,
            'last_target':pos,'max_target_requested':max(targets),'original_core_count':len(core),
            'results':found,'elapsed_seconds':time.monotonic()-started}
    (Path(__file__).parent/'core_coalescence_search.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))

if __name__=='__main__':main()
