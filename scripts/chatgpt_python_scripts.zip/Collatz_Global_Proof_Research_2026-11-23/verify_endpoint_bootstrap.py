#!/usr/bin/env python3
"""Exact finite controls for the endpoint entropy occupation proof.

Run alongside verify_escape_bounds.py; both use only Python's standard library.
The all-length proof is symbolic in Endpoint_Entropy_Occupation_Bootstrap.md.
"""

from collections import defaultdict
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import json

from verify_escape_bounds import certified_constants, LN2, LN3


def shortcut(x):
    return (3*x + 1)//2 if x & 1 else x//2


def constant_certificate():
    # alpha in (1/2,2/3), gamma=h2(alpha)>h2(2/3)>9/10.
    assert 2**2 > 3
    assert 2**3 < 3**2
    assert 3**30 > 2**47
    # 3^(-9/10)<3/8 and (4/27)^(9/10)<1/5.
    assert 3**19 > 8**10
    assert 4**9 * 5**10 < 3**27
    coefficient = Q(1, 5) / Q(5, 8)
    assert coefficient == Q(8, 25)
    assert 12*coefficient + 8 == Q(296, 25) < 12
    assert 14*coefficient + 9 == Q(337, 25) < 14
    # gamma>2/3, and L<=2^(2L/3), checked directly for L=1,2;
    # thereafter (L+1)/L<=3/2<2^(2/3).
    assert 1**3 <= 2**2
    assert 2**3 <= 2**4
    assert Q(3, 2)**3 < 4
    assert Q(35, 96) < Q(2, 5) < LN3[0]-LN2[1]
    return {
        'alpha_interval': '(1/2,2/3)',
        'gamma_lower_bound': '9/10',
        'contraction_coefficient_upper_bound': '8/25',
        'infinite_dyadic_constant': 12,
        'infinite_arbitrary_window_constant': 24,
        'finite_path_dyadic_constant': 14,
        'finite_path_arbitrary_window_constant': 28,
        'infinite_induction_upper': '296/25 < 12',
        'finite_induction_upper': '337/25 < 14',
        'all_integer_constant_assertions': 'passed',
        'simple_raw_G_cutoff': 'N>=2^180 implies log(G_raw)<35/96<2/5<log(3/2)',
    }


def arbitrary_interval_controls():
    source_checks = 0
    interval_checks = 0
    for length in range(1, 11):
        size = 1 << length
        shifts = sorted(set([0, 1, 2, 3, 17, 49, 1001, size-1, size+3]))
        for start in shifts:
            groups = defaultdict(list)
            parity_words = set()
            for source in range(start+1, start+size+1):
                x, r, word, additive = source, 0, 0, 0
                for j in range(length):
                    if x & 1:
                        r += 1
                        word += 1 << j
                        additive = 3*additive + (1 << j)
                    x = shortcut(x)
                assert size*x == 3**r*source + additive
                assert additive <= 2**(length-r)*(3**r - 2**r)
                groups[r].append(x)
                parity_words.add(word)
                source_checks += 1
            assert len(parity_words) == size
            for r in range(length+1):
                images = groups[r]
                assert len(images) == comb(length, r)
                assert max(images)-min(images)+1 <= 2*3**r
            interval_checks += 1
    return {'arbitrary_source_interval_checks': interval_checks,
            'source_affine_and_parity_checks': source_checks,
            'maximum_source_interval_exponent': 10}


def distinct_path(start, cap=700):
    values, seen = [], set()
    x = start
    while x not in seen and len(values) < cap:
        seen.add(x)
        values.append(x)
        x = shortcut(x)
    return values


def occupancy(sorted_values, width):
    left, best, best_start = 0, 0, 1
    for right, value in enumerate(sorted_values):
        while value-sorted_values[left] >= width:
            left += 1
        if right-left+1 > best:
            best = right-left+1
            best_start = sorted_values[left]
    return best, best_start


def finite_path_controls():
    rows = []
    recurrence_checks = 0
    retained_source_checks = 0
    for start in [1, 2, 3, 7, 9, 27, 97, 6171, 77031, 837799]:
        values = distinct_path(start)
        values_set = set(values)
        ordered = sorted(values)
        prefix_odds = [0]
        for value in values:
            prefix_odds.append(prefix_odds[-1] + (value & 1))
        widths = {1 << L for L in range(11)} | {2*3**r for r in range(11)}
        occupancies = {width: occupancy(ordered, width) for width in widths}
        for length in range(11):
            width = 1 << length
            lhs, interval_start = occupancies[width]
            rhs = length + sum(min(comb(length, r), occupancies[2*3**r][0])
                               for r in range(length+1))
            assert lhs <= rhs
            # A finite weaker rational-exponent control, not the proof of gamma.
            assert lhs**20 < 14**20 * 2**(19*length)
            boundary = 0
            groups = defaultdict(list)
            for j, value in enumerate(values):
                if not interval_start <= value < interval_start+width:
                    continue
                if j+length >= len(values):
                    boundary += 1
                else:
                    r = prefix_odds[j+length] - prefix_odds[j]
                    image = values[j+length]
                    assert image in values_set
                    groups[r].append(image)
                    retained_source_checks += 1
            assert boundary <= length
            assert boundary + sum(map(len, groups.values())) == lhs
            for r, images in groups.items():
                assert len(images) == len(set(images))
                assert len(images) <= comb(length, r)
                assert max(images)-min(images)+1 <= 2*3**r
                assert len(images) <= occupancies[2*3**r][0]
            recurrence_checks += 1
        rows.append({'start': start, 'distinct_states': len(values)})
    return {'finite_path_recurrence_checks': recurrence_checks,
            'retained_source_checks': retained_source_checks,
            'paths': rows}


def dyadic_index_controls():
    checks = 0
    # r <= alpha*L-3 is equivalent to 3^(r+3)<=2^L, so no logs.
    for length in range(1, 513):
        for r in range(length+1):
            if 3**(r+3) <= 2**length:
                image_width = 2*3**r
                index = (image_width-1).bit_length()
                assert (1 << index) >= image_width
                assert index < length
                checks += 1
    return {'strictly_smaller_dyadic_image_controls': checks,
            'maximum_L': 512}


def main():
    logarithm_intervals = certified_constants()
    assert Q(logarithm_intervals['gamma_h2_alpha'][1]) < Q(19, 20)
    result = {
        'status': 'All exact assertions passed; no global Collatz proof claimed.',
        'constants': constant_certificate(),
        'certified_logarithm_intervals': logarithm_intervals,
        'arbitrary_interval_controls': arbitrary_interval_controls(),
        'finite_path_controls': finite_path_controls(),
        'dyadic_index_controls': dyadic_index_controls(),
        'raw_tail_corollary': 'sum_{x in S, x>=N} 1/x <= 28/(1-gamma) * N^(gamma-1)',
        'scope': 'S is an actual finite path with pairwise distinct states; no repeated occurrences or profile multiplicities are silently collapsed.',
    }
    target = Path(__file__).with_name('endpoint_bootstrap_verification.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
