#!/usr/bin/env python3
"""Exact controls for the escape-side Collatz research note.

Standard library only.  All assertions use integers or Fraction; reported
decimal intervals are outward rounded.  Finite controls supplement, and do
not replace, the symbolic proofs in Escape_Constraints_and_Real_Shadow.md.
This program does not prove the Collatz conjecture.
"""

from fractions import Fraction as Q
from itertools import product
from math import comb
from pathlib import Path
import json


def plus(x, y):
    return x[0] + y[0], x[1] + y[1]


def neg(x):
    return -x[1], -x[0]


def scale(x, q):
    assert q >= 0
    return q * x[0], q * x[1]


def times(x, y):
    values = [a * b for a in x for b in y]
    return min(values), max(values)


def reciprocal(x):
    assert x[0] > 0
    return 1 / x[1], 1 / x[0]


def divide(x, y):
    return times(x, reciprocal(y))


def log_bounds(q, terms=96):
    """Certified ln(q) via the atanh series and its geometric remainder."""
    q = Q(q)
    assert q > 0
    if q < 1:
        return neg(log_bounds(1 / q, terms))
    z = (q - 1) / (q + 1)
    z2 = z * z
    power = z
    partial = Q(0)
    for k in range(terms):
        partial += 2 * power / (2 * k + 1)
        power *= z2
    error = 2 * power / ((2 * terms + 1) * (1 - z2))
    return partial, partial + error


LN2 = log_bounds(Q(2))
LN3 = log_bounds(Q(3))


def entropy(q):
    assert 0 < q < 1
    numerator = neg(plus(scale(log_bounds(q), q),
                         scale(log_bounds(1 - q), 1 - q)))
    return divide(numerator, LN2)


def root_numerator(q):
    """ln(2) * (h_2(q) - q log_2(3))."""
    return plus(neg(plus(scale(log_bounds(q), q),
                         scale(log_bounds(1 - q), 1 - q))),
                neg(scale(LN3, q)))


def rounded(q, digits, upper=False):
    scaled = q * 10 ** digits
    k = -((-scaled.numerator) // scaled.denominator) if upper else scaled.numerator // scaled.denominator
    sign = '-' if k < 0 else ''
    k = abs(k)
    return f'{sign}{k // 10**digits}.{k % 10**digits:0{digits}d}'


def show_interval(interval, digits=28):
    return [rounded(interval[0], digits), rounded(interval[1], digits, True)]


def certified_constants():
    blo = Q('0.609089767923818676517278146865')
    bhi = Q('0.609089767923818676517278146867')
    assert root_numerator(blo)[0] > 0
    assert root_numerator(bhi)[1] < 0
    assert Q(1, 2) < blo < bhi < Q(2, 3)
    alpha = divide(LN2, LN3)
    alo = Q('0.630929753571457437099527114342')
    ahi = Q('0.630929753571457437099527114344')
    assert alo < alpha[0] <= alpha[1] < ahi
    dstar = times((blo, bhi), divide(LN3, LN2))
    gamma = entropy(ahi)[0], entropy(alo)[1]  # h_2 decreases on (1/2,1).
    assert 0 < dstar[0] < dstar[1] < 1
    assert 0 < gamma[0] < gamma[1] < 1
    # Completely logarithm-free proof of the rational choice b=39/64.
    assert 3**1170 < 2**1856
    assert 39**1170 * 25**750 > 2**9664
    return {
        'root_bstar': show_interval((blo, bhi)),
        'image_exponent_dstar': show_interval(dstar),
        'prefix_threshold_inverse_dstar': show_interval(reciprocal(dstar)),
        'alpha_log3_2': show_interval(alpha),
        'gamma_h2_alpha': show_interval(gamma),
        'two_sided_interval_threshold_inverse_gamma': show_interval(reciprocal(gamma)),
        'old_C107_interval_threshold': show_interval(plus(reciprocal(gamma), (-Q(1, 6), -Q(1, 6)))),
        'rational_exponent_29_over_30': True,
        'log_series_terms': 96,
    }


def image_capacity(length):
    return sum(min(comb(length, r), 3**r + 3**r // 2**r - 1)
               for r in range(length + 1))


def finite_image_controls():
    source_checks = 0
    rows = []
    for length in range(1, 13):
        modulus = 1 << length
        input_counts = [0] * (length + 1)
        outputs = [set() for _ in range(length + 1)]
        parity_words = set()
        for start in range(1, modulus + 1):
            x, r, additive, word = start, 0, 0, 0
            for j in range(length):
                if x & 1:
                    x = (3*x + 1) // 2
                    additive = 3*additive + (1 << j)
                    word += 1 << j
                    r += 1
                else:
                    x //= 2
            assert modulus*x == 3**r * start + additive
            assert additive <= 2**(length-r) * (3**r - 2**r)
            assert x <= 3**r + 3**r // 2**r - 1
            inverse_residue = (-additive * pow(3**r, -1, modulus)) % modulus
            assert inverse_residue == start % modulus
            parity_words.add(word)
            input_counts[r] += 1
            outputs[r].add(x)
            source_checks += 1
        assert len(parity_words) == modulus
        assert input_counts == [comb(length, r) for r in range(length+1)]
        for r in range(length + 1):
            assert len(outputs[r]) <= min(comb(length, r), 3**r + 3**r // 2**r - 1)
        image_size = len(set().union(*outputs))
        cap = image_capacity(length)
        assert image_size <= cap
        rows.append({'L': length, 'actual_full_block_image_size': image_size, 'capacity_I_L': cap})
    # These are finite exact controls, not the proof for arbitrary L.
    for length in range(0, 513):
        assert image_capacity(length)**30 < 4**30 * 2**(29*length)
    return {'source_checks': source_checks, 'max_enumerated_L': 12,
            'power_bound_checks_L_0_through': 512, 'image_rows': rows}


def odd_affine_controls():
    checks = 0
    for start in range(1, 502, 2):
        x = start
        h, additive, correction = Q(1), Q(0), Q(1)
        for _ in range(20):
            assert Q(x) == h * (start + additive)
            assert Q(x) == start * h * correction
            additive += 1 / (3*h)
            correction *= 1 + Q(1, 3*x)
            y = 3*x + 1
            e = (y & -y).bit_length() - 1
            h *= Q(3, 2**e)
            x = y // 2**e
            assert Q(x) == h * (start + additive)
            assert Q(x) == start * h * correction
            checks += 1
    return {'odd_step_affine_and_product_checks': checks}


def finite_shadow_controls():
    checks = 0
    for length in range(0, 7):
        for exponents in product(range(1, 5), repeat=length):
            # Includes t=0, followed by all supplied exponents.
            tail, e_sum = Q(1, 3), 0
            for t, e in enumerate(exponents, 1):
                e_sum += e
                tail += Q(2**e_sum, 3**(t+1))
            lower = 1 - Q(2, 3)**(length+1)
            assert tail >= lower
            if all(e == 1 for e in exponents):
                assert tail == lower
            checks += 1
    return {'finite_shadow_geometric_lower_bound_checks': checks,
            'note': 'The infinite >=1 lower bound follows by monotone limiting in the proof.'}


def main():
    result = {
        'status': 'All exact assertions passed; no global Collatz proof claimed.',
        'constants': certified_constants(),
        'image_controls': finite_image_controls(),
        'affine_controls': odd_affine_controls(),
        'shadow_controls': finite_shadow_controls(),
    }
    target = Path(__file__).with_name('escape_verification.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
