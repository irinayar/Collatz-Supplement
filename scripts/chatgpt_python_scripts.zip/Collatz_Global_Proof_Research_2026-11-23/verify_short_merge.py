#!/usr/bin/env python3
"""Exact controls for inverse-run separation and a short uncredited merge.

No Collatz convergence or uniform core-aggregate claim is tested here.
Every assertion is integral/rational. Run without -O.
"""
from fractions import Fraction as F
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
PREFIX_A=(1,2,1,1,1,3,1,2)
PREFIX_B=(1,1,2)
SUFFIX=(1,2,1,2,3)

def v2(x):return (x&-x).bit_length()-1

def affine(word):
    b=e=0
    for v in word:
        b=3*b+(1<<e);e+=v
    return 3**len(word),1<<e,b,e

def orbit(start,word):
    xs=[start]
    for e in word:
        assert v2(3*xs[-1]+1)==e
        xs.append((3*xs[-1]+1)//(1<<e))
    return xs

def runs(xs,word,kappa):
    out=[];left=0
    for j,e in enumerate(word,1):
        if e<2:continue
        s=j-left;a=xs[left];b=xs[j]
        beta=1-F(2,3)**s;delta=beta/a
        flux=F(1,a)-F(1,b);c=max(F(0),-flux-delta/15)
        out.append({'s':s,'e':e,'a':a,'b':b,'delta':delta,'flux':flux,
                    't':kappa*delta+flux,'credit':c})
        left=j
    assert left==len(word)
    return out

def family(t):
    assert isinstance(t,int) and t>=0
    k=19+512*t
    u=411+8192*k;v=391+7776*k;y=661+13122*k
    w=(243*y+319)//512;n=w-4;H=(4*n-2)//3
    assert n==118639+3188646*t and H==158184+4251528*t
    assert u==156059+4194304*t and v==148135+3981312*t
    assert y==249979+6718464*t and w==118643+3188646*t
    kappa=F(n-1,n+1)
    paths=[]
    for name,start,prefix in [('A',u,PREFIX_A),('B',v,PREFIX_B)]:
        word=prefix+SUFFIX;xs=orbit(start,word)
        assert xs[len(prefix)]==y and xs[-1]==w
        assert n<=start<=H and n<=w<=H
        assert min(xs[1:-1])>H
        assert len(set(xs))==len(xs)
        aa,dd,bb,E=affine(word)
        assert dd*w==aa*start+bb
        modulus=2*dd
        residue=((dd-bb)*pow(aa,-1,modulus))%modulus
        assert start%modulus==residue
        # Every lower member of this exact full cylinder has endpoint below n.
        assert w-2*aa<n
        assert (aa*(start-modulus)+bb)//dd==w-2*aa
        Q=F(bb,aa)
        assert Q<5
        rr=runs(xs,word,kappa)
        entry=rr[:3] if name=='A' else rr[:1]
        assert all(r['s']<=4 and r['flux']>0 and r['credit']==0 for r in entry)
        assert all(r['s']<=4 for r in rr)
        # B=5+n/(100000P*)>5 for every positive P*: all original cores empty.
        # Their exact signed score is consequently minus all actual credits.
        Z=-sum((r['credit'] for r in rr),F(0))
        assert Z<0
        paths.append({'name':name,'source':start,'odd_inputs':len(word),'E':E,
                      'phase':str(Q),'original_core_count':0,
                      'entry_run_types':[(r['s'],r['e']) for r in entry],
                      'entry_credit':'0','score_Z':str(Z),'word':list(word),
                      'odd_states':xs,'full_residue':residue,'modulus':modulus})
    # First merger is interior to B's complete run and at a reset output of A.
    merge=587+11664*k
    pa=orbit(u,PREFIX_A);pb=orbit(v,PREFIX_B)
    assert merge==pa[6]==pb[1]
    assert pa[5]!=pb[0]
    assert v2(3*pa[5]+1)==3 and v2(3*pb[0]+1)==1
    return {'parameter':t,'n':n,'H':H,'common_run_boundary':y,
            'first_odd_merge':merge,'terminal':w,'paths':paths,
            'total_entry_credit':'0',
            'aggregate_original_Z':str(sum((F(p['score_Z']) for p in paths),F(0)))}

def separation_controls():
    n=(1<<71)+1;H=(4*n-2)//3;rows=[]
    for s in range(1,9):
        reset_gap=2*3**(s-1)
        ell=1
        while n*(1<<(reset_gap+ell))>=(H+1)*3**ell:ell+=1
        if ell>1:assert n*(1<<(reset_gap+ell-1))>=(H+1)*3**(ell-1)
        rows.append({'shorter_s':s,'minimum_reset_difference':reset_gap,
                     'minimum_odd_length_difference':ell,'next_s_at_least':s+ell})
    assert [r['next_s_at_least'] for r in rows]==[4,12,34,96,282,837,2499,7485]
    assert F(1<<18,3**11)>F(64,45)
    # Exhaustive finite type-level check: output compatibility for s<=11,
    # zero-credit types at high inputs, and a 4/3 homogeneous height band.
    types=[]
    for s in range(2,12):
        beta=1-F(2,3)**s
        for e in range(2,18):
            lam=F(1<<(s+e-1),3**s)
            if lam<=(1+beta/n)*(1+beta/15):types.append((s,e,lam))
    compatible_pairs=0
    for i,(s,e,lam) in enumerate(types):
        assert e<=7
        for ss,ee,ll in types[i+1:]:
            modulus=3**min(s,ss)
            if pow(2,abs(ee-e),modulus)!=1:continue
            compatible_pairs+=1
            assert e==ee
            assert max(lam,ll)/min(lam,ll)>=F(3,2)
    return {'separation_table':rows,'zero_credit_short_types':len(types),
            'compatible_distinct_short_pairs':compatible_pairs,
            'all_compatible_pairs_share_reset_exponent':True}

def main():
    assert __debug__
    small=[family(t) for t in [0,1,2,16,31]]
    # Check all-time first-return height inequalities as affine functions of t.
    zero,one=small[0],small[1]
    slopes=[]
    for p0,p1 in zip(zero['paths'],one['paths'],strict=True):
        for j,(x0,x1) in enumerate(zip(p0['odd_states'][1:-1],p1['odd_states'][1:-1],strict=True),1):
            c=x0-zero['H'];s=(x1-x0)-(one['H']-zero['H'])
            assert c>0 and s>0
            slopes.append({'path':p0['name'],'odd_index':j,'constant':c,'slope':s})
    # Choose a high-floor control also retaining n=15 mod32.
    working_floor=2075*(1<<60)
    tmin=max(0,(working_floor-118639+3188645)//3188646)
    thigh=((tmin+15)//16)*16
    high=family(thigh);assert high['n']>=working_floor and high['n']%32==15
    result={'status':'PASS','scope':'Exact inverse arithmetic, finite replay and affine proof certificates; no central aggregate or convergence claim.',
            'separation':separation_controls(),'first_return_height_affine_certificates':slopes,
            'small_parameter_checks':[p['parameter'] for p in small],
            'base_control':zero,'high_floor_control':high,
            'new_obstruction':'Whole-prefix coalescence can occur through interior odd states using only short expanding zero-credit complete runs; long-run/credit charging at run boundaries does not cover it.'}
    (HERE/'short_merge_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','short_types':result['separation']['zero_credit_short_types'],
                      'height_affine_checks':len(slopes),'high_n':high['n'],
                      'high_sources':[p['source'] for p in high['paths']],
                      'actual_core_counts':[p['original_core_count'] for p in high['paths']],
                      'entry_credit':high['total_entry_credit'],'canonical_aggregate_sign':'negative'},indent=2))

if __name__=='__main__':main()
