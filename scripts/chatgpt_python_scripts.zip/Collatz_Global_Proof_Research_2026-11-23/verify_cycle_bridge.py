#!/usr/bin/env python3
"""Exact finite controls for cycle closure, mechanical words and rational shadows.

No positive integer nontrivial cycle is asserted. The large examples are
compactly specified nonintegral rational cycles; their huge words are not
expanded. All large comparisons use rigorous rational logarithm enclosures.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import gcd
from pathlib import Path
import json


def numerator(word):
    u = 0
    for j, bit in enumerate(word):
        if bit:
            u = 3 * u + (1 << j)
    return u


def rotate(word, k):
    return word[k:] + word[:k]


def mechanical(length, ones, intercept=0):
    # Intercept is an integer multiple of 1/length.
    return tuple(((j + 1) * ones + intercept) // length
                 - (j * ones + intercept) // length for j in range(length))


def is_cyclically_balanced(word):
    n = len(word)
    doubled = word + word
    for width in range(1, n):
        counts = [sum(doubled[j:j+width]) for j in range(n)]
        if max(counts) - min(counts) > 1:
            return False
    return True


def strip_2_3(value):
    value = abs(value)
    if value == 0:
        return 0
    for p in [2, 3]:
        while value % p == 0:
            value //= p
    return value


def log_enclosure(integer, terms=160):
    """Rigorous ln(integer) enclosure by 2 atanh((a-1)/(a+1))."""
    z = F(integer-1, integer+1)
    lo = sum((2*z**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    error = 2*z**(2*terms+1)/F(2*terms+1)/(1-z*z)
    return lo, lo+error


def gamma_enclosure(length, ones):
    l2, u2 = log_enclosure(2)
    l3, u3 = log_enclosure(3)
    return length*l2-ones*u3, length*u2-ones*l3


def join_stats(first, second, modulus):
    # (A,D,U) for first+second, where f(x)=(Ax+U)/D.
    a, d, u = first
    b, e, v = second
    return a*b % modulus, d*e % modulus, (b*u+d*v) % modulus


@dataclass(eq=False)
class Node:
    kind: str
    args: tuple
    length: int
    ones: int

    @staticmethod
    def bit(value):
        return Node('bit', (value,), 1, value)

    @staticmethod
    def concat(left, right):
        return Node('concat', (left, right), left.length+right.length, left.ones+right.ones)

    @staticmethod
    def power(word, copies):
        return Node('power', (word, copies), word.length*copies, word.ones*copies)

    def get_bit(self, index):
        if not 0 <= index < self.length:
            raise IndexError(index)
        if self.kind == 'bit':
            return self.args[0]
        if self.kind == 'concat':
            left, right = self.args
            return left.get_bit(index) if index < left.length else right.get_bit(index-left.length)
        word, _ = self.args
        return word.get_bit(index % word.length)

    def modular_stats(self, modulus, cache=None):
        if cache is None:
            cache = {}
        if id(self) in cache:
            return cache[id(self)]
        if self.kind == 'bit':
            value = self.args[0]
            result = ((3 if value else 1) % modulus, 2 % modulus, value)
        elif self.kind == 'concat':
            left, right = self.args
            result = join_stats(left.modular_stats(modulus, cache), right.modular_stats(modulus, cache), modulus)
        else:
            word, copies = self.args
            base = word.modular_stats(modulus, cache)
            result = (1, 1, 0)
            while copies:
                if copies & 1:
                    result = join_stats(result, base, modulus)
                base = join_stats(base, base, modulus)
                copies >>= 1
        cache[id(self)] = result
        return result


def christoffel_slp(length, ones):
    """Stern-Brocot concatenation for the lower mechanical word, coprime data."""
    assert 0 < ones < length and gcd(length, ones) == 1
    num, den = ones, length-ones
    lp, lq, rp, rq = 0, 1, 1, 0
    left, right = Node.bit(0), Node.bit(1)
    trace = []
    while True:
        delta = num*(lq+rq)-den*(lp+rp)
        if delta == 0:
            word = Node.concat(left, right)
            assert word.length == length and word.ones == ones
            return word, trace
        x, y = num*lq-den*lp, den*rp-num*rq
        assert x > 0 and y > 0
        if delta > 0:
            k = (x-1)//y
            assert k > 0
            lp, lq = lp+k*rp, lq+k*rq
            left = Node.concat(left, Node.power(right, k))
            trace.append(['left', k])
        else:
            k = (y-1)//x
            assert k > 0
            rp, rq = rp+k*lp, rq+k*lq
            right = Node.concat(Node.power(left, k), right)
            trace.append(['right', k])


def controls():
    counts = {'rotation_gcd_checks': 0, 'adjacent_swap_checks': 0,
              'mechanical_coprimality_checks': 0, 'local_window_range_checks': 0,
              'spread_implication_checks': 0, 'coprime_spread_implication_checks': 0,
              'slp_small_word_checks': 0}
    for length in range(2, 13):
        for word in product([0, 1], repeat=length):
            ones = sum(word)
            if not ones:
                continue
            d = (1 << length)-3**ones
            u = numerator(word)
            all_u = [numerator(rotate(word, j)) for j in range(length)]
            assert all(gcd(v, abs(d)) == gcd(u, abs(d)) for v in all_u)
            common = 0
            for v in all_u:
                common = gcd(common, v)
            assert common == gcd(u, abs(d))
            counts['rotation_gcd_checks'] += 1
            if d > 0:
                odd_values = [F(all_u[j], d) for j in range(length) if word[j]]
                ratio = max(odd_values)/min(odd_values)
                correction = F(1 << length, 3**ones)
                # Exact sufficient bound for mechanical parity, no logarithms.
                if ratio**ones * correction**(ones-1) <= 2**ones:
                    assert is_cyclically_balanced(word)
                    counts['spread_implication_checks'] += 1
                if (ones >= 2 and gcd(length, ones) == 1
                        and ratio**ones * correction**(ones-1) <= 2**(ones+1)):
                    assert is_cyclically_balanced(word)
                    counts['coprime_spread_implication_checks'] += 1
    for length in range(2, 61):
        for ones in range(1, length):
            if gcd(length, ones) != 1:
                continue
            w = mechanical(length, ones)
            v = mechanical(length, ones, 1)
            assert v in [rotate(w, j) for j in range(length)]
            changed = [j for j in range(length) if w[j] != v[j]]
            assert len(changed) == 2 and changed[1] == changed[0]+1
            delta = numerator(v)-numerator(w)
            assert strip_2_3(delta) == 1
            counts['adjacent_swap_checks'] += 1
            d = (1 << length)-3**ones
            assert gcd(numerator(w), abs(d)) == 1
            counts['mechanical_coprimality_checks'] += 1
            node, _ = christoffel_slp(length, ones)
            assert tuple(node.get_bit(i) for i in range(length)) == w
            for mod in [5, 7, 97]:
                assert node.modular_stats(mod) == (pow(3, ones, mod), pow(2, length, mod), numerator(w) % mod)
            counts['slp_small_word_checks'] += 1
    for length in range(2, 10):
        for ones in range(1, length):
            values = [numerator(w) for w in product([0, 1], repeat=length) if sum(w) == ones]
            lo, hi = 3**ones-2**ones, 2**(length-ones)*(3**ones-2**ones)
            assert min(values) == lo and max(values) == hi
            counts['local_window_range_checks'] += 1
    return counts


def large_examples():
    base = 2075 * 2**60
    rows = []
    specifications = [
        ('balanced', 217976794617, 137528045312, F(8, 10**13), F(9, 10**13), 6),
        ('nonbalanced_prefix_swap', 9009497464537, 5684360015103, F(18, 10**13), F(19, 10**13), 12),
    ]
    for label, length, ones, coarse_lo, coarse_hi, divisor in specifications:
        assert gcd(length, ones) == 1
        gamma_lo, gamma_hi = gamma_enclosure(length, ones)
        assert coarse_lo < gamma_lo < gamma_hi < coarse_hi < 1
        # exp(t)-1 < t/(1-t), for 0<t<1, follows from its positive series.
        correction_excess_cap = gamma_hi/(1-gamma_hi)
        min_floor = (F(ones, divisor)/correction_excess_cap).__floor__()
        assert min_floor > base
        word, trace = christoffel_slp(length, ones)
        prefix = ''.join(str(word.get_bit(i)) for i in range(30))
        record = {
            'kind': label, 'shortcut_length': length, 'odd_count': ones,
            'gcd_length_odd_count': 1,
            'gamma_coarse_open_interval': [str(coarse_lo), str(coarse_hi)],
            'gamma_lower_exact': str(gamma_lo), 'gamma_upper_exact': str(gamma_hi),
            'raw_correction_excess_cap': str(correction_excess_cap),
            'minimum_odd_state_strictly_exceeds_integer': min_floor,
            'adopted_certified_integer_base': base,
            'lower_mechanical_prefix': prefix, 'straight_line_construction': trace,
            'word_expanded': False, 'integer_cycle': False,
        }
        if label == 'balanced':
            assert correction_excess_cap < F(1, 10**12)
            record['nonintegrality_proof'] = 'Coprime mechanical numerator and closing denominator; denominator greater than one.'
            record['raw_G_less_than'] = '1 + 1/10^12'
        else:
            assert prefix[:3] == '010' and '11' in prefix[3:]
            # Swap only initial 01 to 10. The resulting word contains both00 and11.
            a, d, u = word.modular_stats(5)
            modified_u = (u-pow(3, ones-1, 5)) % 5
            assert (d-a) % 5 == 0 and modified_u == 4
            assert correction_excess_cap < F(2, 10**12)
            record['modified_prefix'] = '10'+prefix[2:]
            record['mod5_certificate'] = {'closing_denominator': (d-a) % 5, 'balanced_numerator': u, 'modified_numerator': modified_u}
            record['nonintegrality_proof'] = '5 divides closing denominator but does not divide modified numerator.'
            record['raw_G_less_than'] = '1 + 2/10^12'
        rows.append(record)
    return rows


def main():
    if not __debug__:
        raise SystemExit('Run without -O')
    result = {'status':'PASS',
              'scope':'finite exact controls and compact nonintegral rational-cycle certificates; no global integer-cycle exclusion claimed',
              'controls': controls(), 'large_rational_examples': large_examples(),
              'inherited_cycle_product_cap':'367/250; imported, not reverified here',
              'derived_global_high_cycle_constraints':[
                  'E = ceil(g log_2 3)',
                  '2^E / 3^g < 367/250',
                  'R^g (2^E/3^g)^(g-1) > 2^g for nontrivial integer cycles',
                  'R^g (2^E/3^g)^(g-1) > 2^(g+1) if also gcd(E,g)=1 and g>=2',
                  'closing denominator divides every stripped local rotation defect'],
              'global_proof_obtained':False}
    path = Path(__file__).resolve().parent/'cycle_bridge_certificate.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    concise = dict(result)
    concise['large_rational_examples'] = [{k:v for k,v in row.items() if k not in ['gamma_lower_exact','gamma_upper_exact','raw_correction_excess_cap','straight_line_construction']} for row in result['large_rational_examples']]
    print(json.dumps(concise,indent=2))


if __name__ == '__main__':
    main()
