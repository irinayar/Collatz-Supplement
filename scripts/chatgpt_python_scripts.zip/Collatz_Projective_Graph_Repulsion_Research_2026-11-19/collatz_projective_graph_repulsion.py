#!/usr/bin/env python3
"""Exact rational tests of a conditional projective graph-repulsion certificate."""
from fractions import Fraction as F
from itertools import product

def affine(word):
    p=F(1); c=F(0)
    for bit in word:
        if bit=='1': p=F(3,2)*p; c=F(3,2)*c+F(1,2)
        else: p=p/2; c=c/2
    return p,c

# A->B: '11', B->A: '000'; self-loops: '10'.
edges=[('A','B','11'),('B','A','000'),('A','A','10'),('B','B','10')]
H={'A':F(1),'B':F(3)}
rho=F(3,4); C=F(5,12)
for a,b,w in edges:
    q,c=affine(w)
    assert q*H[a]/H[b] <= rho,(a,b,w,q)
    assert c/H[b] <= C,(a,b,w,c)
    print(f'{a}->{b} {w}: q={q} c={c}, weighted q={q*H[a]/H[b]}, weighted c={c/H[b]}')

# Test all graph paths up to 8 blocks with exact rational affine algebra.
checks=0
for k in range(1,9):
    for choices in product(range(4),repeat=k):
        state='A'; x=F(7); z0=x/H[state]; bound=max(z0,C/(1-rho))
        valid=True
        for idx in choices:
            a,b,w=edges[idx]
            if a!=state:valid=False;break
            q,c=affine(w); x=q*x+c;state=b
            assert x/H[state]<=bound
            checks+=1
print('Exact rational weighted-height checks:',checks)

# Actual integer trajectories: only accept graph edges if all parity steps match.
def T(x):return (3*x+1)//2 if x%2 else x//2
accepted=0; steps=0
for n in range(1,5001):
    x=n; state='A'; zbound=max(F(n),C/(1-rho))
    for _ in range(15):
        choices=[]
        for a,b,w in edges:
            if a!=state:continue
            y=x;ok=True
            for bit in w:
                if str(y%2)!=bit:ok=False;break
                y=T(y)
            if ok:choices.append((b,w,y))
        if not choices:break
        assert len(choices)==1
        state,w,x=choices[0]
        assert F(x,H[state])<=zbound
        accepted+=1;steps+=len(w)
print('Actual admissible integer block transitions:',accepted,'steps:',steps)
