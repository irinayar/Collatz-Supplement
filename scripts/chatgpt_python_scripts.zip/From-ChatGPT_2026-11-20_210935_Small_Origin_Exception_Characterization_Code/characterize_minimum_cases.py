from min_origin_exact import H
from collections import Counter
from fractions import Fraction
import json
rows=[]; per=Counter(); res=Counter(); checks=0
for k in range(9):
 for r in range(7):
  for x in range(3,3**(r+1)+3):
   m=H(x,k,r); n=H(x,k,r+1)
   if m is None or n is None:continue
   if m%3==2 or (k>=1 and m>=2**(k+1)-3):continue
   assert k>=1
   assert m < 2**(k+1)-3
   assert 2**r*(x+1) < 3**(r+1)*(1-Fraction(1,2**k)),(x,k,r,m)
   rows.append(dict(x=x,k=k,r=r,m=m,next=n,delta=n-m,origin_residue=m%3,origin_fraction=str(Fraction(m,2**k)),endpoint_bound=str(3**(r+1)*(1-Fraction(1,2**k))/2**r-1)))
   per[(k,r)]+=1;res[m%3]+=1;checks+=1
print('cases',len(rows),'residue',res,'per',sorted(per.items()))
print('minmax',min(t['delta'] for t in rows),max(t['delta'] for t in rows))
print('first',rows[:12]);print('max m',max(t['m'] for t in rows))
json.dump({'scope':'0<=k<=8,0<=r<=6, representative endpoints','count':len(rows),'cases':rows,'per_budget':{str(k):v for k,v in per.items()},'residue_counts':dict(res)},open('/mnt/data/min_origin_hard_cases.json','w'),indent=2)
