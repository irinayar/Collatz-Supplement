import json
from min_origin_exact import H
cases=json.load(open('/mnt/data/min_origin_hard_cases.json'))['cases']
# Independent forward parity enumeration of origins, bounded by the proved origin cutoff.
found={}
for k in range(1,9):
 limit=2**(k+1)-4
 for m in range(1,limit+1):
  frontier={(m,0,0)}
  for step in range(k+7):
   for n,ke,ro in frontier:
    if ke==k and ro<=6:
     key=(n,k,ro)
     if key not in found or m<found[key]:found[key]=m
   nxt=set()
   for n,ke,ro in frontier:
    if n%2==0 and ke<k:nxt.add((n//2,ke+1,ro))
    if n%2==1 and ro<6:nxt.add(((3*n+1)//2,ke,ro+1))
   frontier=nxt
   if not frontier:break
for row in cases:
 key=(row['x'],row['k'],row['r'])
 assert found.get(key)==row['m'],(key,found.get(key),row['m'])
 assert H(row['x'],row['k'],row['r']+1)==row['next']
print('All',len(cases),'hard minima independently attained and minimal among origins under cutoff; successors checked')
