from collections import Counter
from fractions import Fraction
import json
L,U=1025,4095

def step(u):
    assert u%2==1 and u>1
    s=((u+1)&-(u+1)).bit_length()-1
    w=3**s*((u+1)//2**s)-1
    e=(w&-w).bit_length()-1
    v=w>>e
    return v,s,e

def return_excursion(start, cap=10000):
    u=start; E=R=0; V=0; visited=[]; escaped=False
    for t in range(cap):
        v,s,e=step(u)
        # 2^(s+e) v = 3^s u + (3^s-2^s)
        V=3**s*V + (3**s-2**s)*2**E
        E+=s+e; R+=s
        assert (1<<E)*v==3**R*start+V
        visited.append((u,v,s,e))
        u=v
        if u>U: escaped=True
        if escaped and u<=U:
            return {'start':start,'end':u,'steps':t+1,'E':E,'R':R,'V':V,'escaped':True,'returned':u>=L,'low':u<L,'max':max(z[1] for z in visited),'residue':start%(1<<E),'check':((3**R*start+V)%(1<<E))==0}
        if not escaped and u<L:
            return {'start':start,'end':u,'steps':t+1,'E':E,'R':R,'V':V,'escaped':False,'returned':False,'low':True,'max':max(z[1] for z in visited),'residue':start%(1<<E),'check':True}
    return {'start':start,'capped':True}

out=[return_excursion(u,1000) for u in range(L,U+1,2)]
counts=Counter('returned' if z.get('returned') else 'low' if z.get('low') else 'capped' for z in out)
ret=[z for z in out if z.get('returned')]
print(counts, 'returns',len(ret),'max E',max((z['E'] for z in ret),default=0),'max steps',max((z['steps'] for z in ret),default=0))
print('sample',ret[:4]);
with open('/mnt/data/return_research/results.json','w') as f:json.dump({'counts':counts,'returned':ret,'examples':out[:10]},f,indent=2)
by={z['start']:z for z in out}
cache={}; visiting=set()
def depth(u):
 if u in cache:return cache[u]
 if u in visiting:raise RuntimeError('cycle '+str(u))
 visiting.add(u); z=by[u]
 if z.get('returned'):
  d=1+depth(z['end'])
 else:d=0
 visiting.remove(u);cache[u]=d;return d
for u in by:depth(u)
print('max returns',max(cache.values()),'argmax',[u for u in cache if cache[u]==max(cache.values())][:10]);
print('returned starts with 2+ returns',sum(v>=2 for v in cache.values()))
from functools import lru_cache
@lru_cache(None)
def full(u):
 z=by[u]
 seg=Fraction((1<<z['E'])*z['end'],3**z['R']*u)
 if z.get('returned'):
  nxt=full(z['end']);return (seg*nxt[0],z['steps']+nxt[1],max(z['max'],nxt[2]),nxt[3])
 return (seg,z['steps'],z['max'],z['end'])
vals={u:full(u) for u in by}
a=max(vals,key=lambda u:vals[u][0]);b=max(vals,key=lambda u:vals[u][1]);c=max(vals,key=lambda u:vals[u][2]);
print('max product',a,vals[a][0],float(vals[a][0]));print('max steps',b,vals[b][1]);print('max peak',c,vals[c][2]);
with open('/mnt/data/return_research/summary.json','w') as f:json.dump({'counts':counts,'max_returns':max(cache.values()),'max_return_starts':[u for u in cache if cache[u]==max(cache.values())], 'max_product_start':a,'max_product_num':vals[a][0].numerator,'max_product_den':vals[a][0].denominator,'max_steps_start':b,'max_steps':vals[b][1],'max_peak_start':c,'max_peak':vals[c][2]},f,indent=2)
