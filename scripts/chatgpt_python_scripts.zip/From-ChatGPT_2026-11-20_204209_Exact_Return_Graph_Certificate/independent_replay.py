from fractions import Fraction
L,U=1025,4095

def nxt(u):
    x=u
    while x%2:
        x=(3*x+1)//2
    while x%2==0:x//=2
    return x

def check(start):
    u=start; had_exit=False; returns=0; peak=u; seen=set(); count=0
    while u>1023:
        if u in seen:raise AssertionError(('cycle',start,u))
        seen.add(u)
        v=nxt(u);count+=1;peak=max(peak,v)
        if v>U:had_exit=True
        if had_exit and L<=v<=U:
            returns+=1;had_exit=False
        u=v
        assert count<10000
    return returns,count,peak
vals={u:check(u) for u in range(L,U+1,2)}
print('independent max returns',max(v[0] for v in vals.values()),'max steps',max(v[1] for v in vals.values()),'max peak',max(v[2] for v in vals.values()))
assert max(v[0] for v in vals.values())==3
assert max(v[1] for v in vals.values())==22
assert max(v[2] for v in vals.values())==189175
