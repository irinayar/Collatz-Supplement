from fractions import Fraction
from itertools import product

def params(e,s):
 a=3**(s+1); d=2**(s+e); B=3**s*(1+2**e)-d
 return a,d,B,Fraction(B,a-d) if a>d else None

def next_odd(x):
 t=3*x+1;e=(t&-t).bit_length()-1
 return t>>e,e

def realizer(word):
 a,b,d=1,0,1
 for e in word:
  b=3*b+d;a*=3;d*=2**e
 return ((d-b)*pow(a,-1,2*d))%(2*d)

C=Fraction(3619,217)
assert params(2,1)[3]==7
assert params(3,3)[3]==Fraction(179,17)
assert params(4,5)[3]==C
assert Fraction(1)+(19+8*C)/405 < Fraction(3,2)
checked=0
for length in range(1,5):
 for pairs in product([(2,1),(2,2),(3,3),(3,4),(4,5),(4,6)],repeat=length):
  word=[1,1,1]+[v for e,s in pairs for v in [e]+[1]*s]
  x=realizer(word); assert x>0 and x%2==1
  y=x; G=Fraction(1)
  for e in word:
   G*=Fraction(3*y+1,3*y)
   y,got=next_odd(y)
   assert got==e
   assert G < Fraction(3,2)
  assert G*(1+C/y)<=Fraction(1)+(19+8*C)/(27*x)
  checked+=1
print('PASS',checked,'exact mixed block cylinders; C=',C,'global at x=15:',Fraction(1)+(19+8*C)/405)
