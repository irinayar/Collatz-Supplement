from functools import lru_cache
from itertools import combinations
@lru_cache(None)
def origins(x,k,r):
 if k<0 or r<0:return ()
 if k==r==0:return (x,)
 a=origins(2*x,k-1,r) if k else ()
 b=origins((2*x-1)//3,k,r-1) if r and x%3==2 and (2*x-1)//3%2==1 else ()
 return tuple(sorted(set(a+b)))
# Old parity numerator with odd positions p ascending (0-indexed): sum 3^(r-i-1)*2^p
# fixed last j positions; P from remaining n positions <t, bounds Pmin=3^n-2^n, Pmax=2^(t-n)*Pmin.
# Note numerator T is last j contributions (coefficients 3^0 ..3^(j-1)).
def tail_test(x,k,r,M,tail):
 L=k+r;j=len(tail);n=r-j;t=tail[0] if j else L
 T=sum(3**(j-i-1)*2**p for i,p in enumerate(tail))
 if t<n:return False
 if n==0:
  return (2**L*x-T)%3**r==0 and (2**L*x-T)//3**r<=M
 lo=3**n-2**n;hi=(3**n-2**n)*2**(t-n)
 if (2**L*x-T)%3**j:return False
 residue=((2**L*x-T)//3**j)%3**n
 lo=max(lo,(2**L*x-3**r*M-T+3**j-1)//3**j)
 first=lo+(residue-lo)%3**n
 return first<=hi
survivors=[]; tested=0; falsepositive=0; fullpass=0; counts={};depths={}
for k in range(0,9):
 for r in range(0,7):
  for x in range(3,3**(r+1)+3):
   old=origins(x,k,r);new=origins(x,k,r+1)
   if not old or not new:continue
   m=old[0]
   if m%3==2 or (k>=1 and m>=2**(k+1)-3):continue
   survivors.append((x,k,r,m,new[0]))
   M=new[0]
   L=k+r
   for j in range(0,r+1):
    if j==0:tails=[()]
    else:tails=list(combinations(range(L),j))
    cnt=sum(tail_test(x,k,r,M,t) for t in tails)
    counts[j]=counts.get(j,0)+cnt
    if cnt==0:
     tested+=1
     depths[j]=depths.get(j,0)+1
     break
   else:fullpass+=1
print('survivors',len(survivors),'certified before full',tested,'full-needed',fullpass,'remaining tails by depth',counts)
print('depths',depths)
print('first',survivors[:5])
