#!/usr/bin/env python3
"""Exact adaptive parity-prefix certificates, using arbitrary precision integers."""
from collections import deque

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def state(w):
    L=A=U=0
    for b in w:
        if b=='1': U=3*U+(1<<L); A+=1
        L+=1
    D=(1<<L)-3**A
    # unique parity cylinder representative via affine endpoint integrality
    r=0
    for j,b in enumerate(w):
        # lift by 2^j: previous j parities invariant, new parity flips
        candidate=r
        for _ in range(j): candidate=T(candidate)
        if candidate%2!=int(b): r+=1<<j
    return L,A,U,D,r

def exact_exception_count(w, lower=2):
    L,A,U,D,r=state(w)
    if D<=0: return None
    modulus=1<<L
    # n=r+t*modulus, n>=lower and D*n<=U
    t0=max(0,(lower-r+modulus-1)//modulus)
    t1=(U//D-r)//modulus
    return max(0,t1-t0+1)

def verify(max_len=11):
    checked=0; exceptions=0; max_exceptions=0
    for L in range(1,max_len+1):
        for bits in range(1<<L):
            w=format(bits,f'0{L}b')
            l,a,u,d,r=state(w)
            assert l==L and 0<=r<1<<L
            for t in range(3):
                n=r+(t+1)*(1<<L)
                x=n
                for b in w:
                    assert x%2==int(b)
                    x=T(x)
                assert x*(1<<L)==3**a*n+u
                assert (x<n)==(d*n>u)
                checked+=1
            if d>0:
                cnt=exact_exception_count(w)
                brute=sum(1 for n in range(2,u//d+1) if n%(1<<L)==r)
                assert cnt==brute
                exceptions+=cnt
                max_exceptions=max(max_exceptions,cnt)
    return checked,exceptions,max_exceptions

if __name__=='__main__':
    print('verified',verify(10))
    for w in ('1100','11100','11011111','1'*12):
        print(w,state(w),'exceptions >=2:',exact_exception_count(w))
