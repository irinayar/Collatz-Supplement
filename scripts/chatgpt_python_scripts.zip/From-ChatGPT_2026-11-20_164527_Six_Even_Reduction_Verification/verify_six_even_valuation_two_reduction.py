from itertools import combinations
from functools import lru_cache
from collections import Counter

def v3(n):
 a=0
 while n%3==0:n//=3;a+=1
 return a
@lru_cache(None)
def H(e,x,r):
 if r<0:return None
 a=v3(x+1)
 if e==0:return 2**r*((x+1)//3**r)-1 if r<=a else None
 z=[]
 for l in range(min(a,r)+1):
  v=H(e-1,2*(2**l*((x+1)//3**l)-1),r-l)
  if v is not None:z.append(v)
 return min(z,default=None)

# Exact universal mod-27 obstruction at 5 evens, 3 odds.
residues=Counter((9*2**i+3*2**j+2**k)%27 for i,j,k in combinations(range(8),3))
assert sum(residues.values())==56 and 1 not in residues
assert 256*25%27==1
# Actual positive 2-odd word exists for any y=25 mod27.
# odds positions (0,1), V=5: m=(128*y-5)/9, integer only if y=25 mod27? y=25 gives 3195/9=355 yes.
# (0,1) V=5 and 2^7 y=128*25 =3200, modulo9 = 5.
checks=0
for a in range(3,8):
 for u in range(1,101):
  if u%3==0:continue
  x=3**a*u-1; xx=9*2**(a-2)*u-1
  for r in range(a,a+13):
   assert H(6,x,r)==H(6,xx,r-a+2),(a,u,r)
   checks+=1
  for l in range(a-2):
   y=2*(2**l*3**(a-l)*u-1)
   assert y%27==25
   assert H(5,y,2) is not None and H(5,y,3) is None
print({'mod27_residue_counts':dict(sorted(residues.items())),'reduction_checks':checks,'failures':0})
