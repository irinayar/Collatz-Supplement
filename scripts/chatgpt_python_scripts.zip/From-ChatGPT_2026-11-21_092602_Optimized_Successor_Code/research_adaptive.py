from itertools import combinations
from functools import lru_cache

def nums(k,b,x):
 L=k+b; B=(1<<L)*x; arr=[]
 for ps in combinations(range(L),b):
  V=sum(3**(b-1-i)*(1<<p) for i,p in enumerate(ps))
  if (B-V)%(3**b)==0:
   m=(B-V)//(3**b)
   if m>0: arr.append((m,ps))
 return arr

def cert(k,b,x,M,j):
 L=k+b; B=(1<<L)*x; n=b-j; Q=3**n; alltail=0; live=0; candidate=0; singleton=0; witness=[]
 if j==0: tails=[()]
 else: tails=combinations(range(L),j)
 for tail in tails:
  if j:
   t=tail[0]; T=sum(3**(j-1-i)*(1<<p) for i,p in enumerate(tail))
   if t<n or (B-T)%(3**j):continue
  else:t=L;T=0
  alltail+=1
  lo=3**n-2**n if n else 0
  hi=(1<<(t-n))*lo if n else 0
  # m in [1,M] imposes P >= (B-T-3**b*M)/3**j and P <= (B-T-3**b)/3**j
  lo=max(lo,(B-T-3**b*M +3**j-1)//3**j)
  hi=min(hi,(B-T-3**b)//3**j)
  if lo>hi:continue
  D=((B-T)//3**j)%Q
  pl=lo+(D-lo)%Q
  ph=hi-(hi-D)%Q
  if pl>ph:continue
  live+=1
  c=(ph-pl)//Q+1;candidate+=c
  singleton+=(c==1)
  witness.append((tail,pl,ph,c))
 return dict(j=j,tail_compatible=alltail, surviving_tails=live, lattice_candidates=candidate,singleton_tails=singleton,examples=witness[:3])

if __name__=='__main__':
 k,b,x=9,5,11
 old=nums(k,b,x)
 print('old',len(old),min(m for m,_ in old),max(m for m,_ in old))
 for M in [507,687,688]:
  print('M',M)
  for j in range(b+1):
   print({a:v for a,v in cert(k,b,x,M,j).items() if a!='examples'})
