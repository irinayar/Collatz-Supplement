from fractions import Fraction
from collections import Counter
H=1024
maxruns=(0,None); maxweighted=(0,None); maxprod=(Fraction(1),None); cross=0
for m in range(3,100001,2):
 u=m; seen=set(); shell=Counter(); p=Fraction(1); runs=0
 while u>=1025 and runs<10000:
  if u in seen: break
  seen.add(u); j=(u//H).bit_length()-1
  shell[j]+=1; runs+=1
  s=0; z=u+1
  while z%2==0: s+=1;z//=2
  w=(3**s*(u+1))//(2**s)-1
  p*=Fraction((2**s)*w,(3**s)*u)
  while w%2==0:w//=2
  u=w
 weighted=sum(Fraction(c,2**j) for j,c in shell.items())
 if runs>maxruns[0]:maxruns=(runs,m)
 if weighted>maxweighted[0]:maxweighted=(weighted,m)
 if p>maxprod[0]:maxprod=(p,m)
 if p>=Fraction(3,2):cross+=1
print('odd starts 3..100000:',49999,'max runs',maxruns,'max weighted',float(maxweighted[0]),maxweighted[1], 'max product',float(maxprod[0]),maxprod[1], 'cross',cross)
