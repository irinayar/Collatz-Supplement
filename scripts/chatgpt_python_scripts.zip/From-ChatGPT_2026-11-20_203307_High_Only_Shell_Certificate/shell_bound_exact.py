from fractions import Fraction
from math import factorial
best=(Fraction(1),None)
for m in range(3,1024,2):
 u=m;p=Fraction(1);seen=set()
 while u>1:
  if u in seen:raise ValueError(('cycle',m,u))
  seen.add(u)
  p*=Fraction(3*u+1,3*u)
  z=3*u+1
  while z%2==0:z//=2
  u=z
 if p>best[0]:best=(p,m)
print('Q',best, float(best[0]))
for w in [183,184,185]:
 x=Fraction(w,1024)
 upper=sum((x**i)/factorial(i) for i in range(6))+(x**6)/factorial(6)/(1-x/7)
 print(w, float(best[0]*upper),best[0]*upper<Fraction(3,2))
