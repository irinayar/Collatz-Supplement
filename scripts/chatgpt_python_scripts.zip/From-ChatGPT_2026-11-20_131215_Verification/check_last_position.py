from itertools import combinations

def calc(j,b):
 out=[]
 for pos in combinations(range(j),b):
  v=sum((1<<p)*3**(b-1-i) for i,p in enumerate(pos))
  out.append((v,pos))
 return out

def upper(j,b,B):
 if b==0:return 0
 if b>j:return None
 return max((1<<(l-b+1))*(3**b-2**b) for l in range(b-1,j) if (pow(2,l,3)==B%3)) if any(pow(2,l,3)==B%3 for l in range(b-1,j)) else None
checks=0; improvements=0; examples=[]
for j in range(2,12):
 for b in range(1,j):
  vals=calc(j,b); top=max(v for v,p in vals); second=sorted((v for v,p in vals),reverse=True)[1]
  for y in range(1,61):
   B=(1<<j)*y; actual=max((v for v,p in vals if v%3==B%3),default=None)
   bound=upper(j,b,B)
   assert actual is None or bound>=actual
   old=top if top%3==B%3 else second
   if bound is not None and bound<old:
    improvements+=1
    if len(examples)<6:examples.append((j,b,y,bound,old,actual))
   checks+=1
print('checks',checks,'strict improvements',improvements,'examples',examples)
