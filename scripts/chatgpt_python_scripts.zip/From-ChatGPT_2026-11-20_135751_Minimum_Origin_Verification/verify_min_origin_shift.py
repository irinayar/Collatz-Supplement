from functools import lru_cache
from itertools import combinations
from math import inf

def v3(n):
 a=0
 while n%3==0:
  a+=1;n//=3
 return a
@lru_cache(None)
def L(x,r,e):
 if r<0 or e<0:return None
 a=v3(x+1)
 if e==0:
  return 2**r*(x+1)//3**r-1 if r<=a else None
 ans=[]
 for ell in range(min(r,a)+1):
  Y=2*(2**ell*(x+1)//3**ell-1)
  v=L(Y,r-ell,e-1)
  if v is not None:ans.append(v)
 return min(ans) if ans else None

def brute(x,r,e):
 j=r+e; B=2**j*x; den=3**r
 vals=[]
 for inds in combinations(range(j),r):
  V=sum(2**p*3**(r-1-i) for i,p in enumerate(inds))
  if (B-V)%den==0:
   m=(B-V)//den
   if m>0:vals.append(m)
 return min(vals) if vals else None

cnt=0
for x in range(1,81):
 for r in range(0,7):
  for e in range(0,5):
   a=L(x,r,e); b=brute(x,r,e)
   assert a==b,(x,r,e,a,b)
   shifted=L(x+3**r,r,e)
   assert (a is None and shifted is None) or (a is not None and shifted==a+2**(r+e)),(x,r,e,a,shifted)
   cnt+=1
print('PASS',cnt,'recurrence vs exhaustive comparisons and exact shift comparisons')
