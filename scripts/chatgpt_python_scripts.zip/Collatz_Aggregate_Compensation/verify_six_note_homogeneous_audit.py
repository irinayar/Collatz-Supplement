#!/usr/bin/env python3
"""Exact bounded audit of K174/K175 and homogeneous compensation constants.

Standalone standard library. No uploaded census code is assumed or rerun.
The count recurrence is reconstructed; its source-profile injection and the
global complementary theorem remain explicit imports.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError('Assertions must remain enabled.')

C=F(620751769493359576,1180591620717411303425)
CW=F(488,375);CE=F(235,128)
B0=F(3000,2797);A0=F(8850,170617);ALPHA0=F(2797,200)
TARGET=F(327,3904)


def v2(x):
    assert x>0
    return (x&-x).bit_length()-1


def complement_rows():
    row={2:1};short=0;saved=[]
    for j in range(3,256):
        short+=sum(count for r,count in row.items()
                   if 4*3**r>3*(1<<j) and 3*3**r<4*(1<<j))
        new={}
        for r,count in row.items():
            for bit in (0,1):
                rr=r+bit
                if 3**rr>1<<j:new[rr]=new.get(rr,0)+count
        row=new
        if j<70:continue
        n=max((1<<71)+1,3*(1<<(j-1))+3)
        H=(4*n-2)//3;L=n.bit_length()-1
        long=sum(row.values());U=long+short
        tau=F(5*(L+1),27*(1<<(L-1)))
        f_unit=tau+F(11,n)+F(9,1024*n)+F(214,7*n*n)+F(51,50000*U)
        eps=CW*f_unit+CE/n
        envelope=eps*U
        assert envelope<F(59,1000) and F(long,H+1)<=C
        # Retaining P/P_* gives the exact homogeneous linear extension.
        for p in (0,1,7,U//3,U):
            f_direct=p*tau+F(11*p,n)+F(9*p,1024*n)+F(214*p,7*n*n)+F(51*p,50000*U)
            assert f_direct==p*f_unit
            assert CW*f_direct+CE*p/n==p*eps
        saved.append({'width':j,'n':str(n),'long_count':str(long),'upper_count':str(U),
                      'homogeneous_envelope_at_U':str(envelope)})
    assert len(saved)==186
    worst=max(saved,key=lambda r:F(r['homogeneous_envelope_at_U']))
    assert worst['width']==71
    assert 3000**22<1<<256
    tail=F(120,3000)+CW*F(51,50000)
    assert tail==F(32287,781250)<F(59,1000)
    return saved,worst


def run_bound_controls():
    n=(1<<71)+1;H=(4*n-2)//3;kappa=1-F(4,3*n+1)
    controls=[];rounding=None
    for s in range(1,9):
        z=F(2,3)**s;beta=1-z;weight=max(F(0),2-3*z)
        for e in range(2,7):
            h=((1+(1<<(e-1)))*pow(3**s,-1,1<<e))%(1<<e)
            residue=(1<<s)*h-1;modulus=1<<(s+e)
            lower=max(H+1,n*(1<<e))
            a=lower+(residue-lower)%modulus;x=a
            for expected in [1]*(s-1)+[e]:
                assert v2(3*x+1)==expected;x=(3*x+1)//(1<<expected)
            b=x;delta=beta/a;flux=F(1,a)-F(1,b)
            psi=max(F(0),kappa*delta+flux)
            shifted=F(n-1,n+1)*delta+flux
            off_credit=max(F(0),-flux-delta/15)
            assert off_credit>=max(F(0),-shifted)
            lam=F(1<<(s+e-1),3**s)
            assert (off_credit>0)==(lam>(1+beta/a)*(1+beta/15))
            assert b>=n and b<=F(a+beta,2*z)
            assert a*psi<=weight
            if s==1:assert psi==0
            else:
                assert 2*z/(a+beta)-F(4,3*n+1)<0
                assert a*psi<weight
            if s==2 and e==2:
                assert psi>0
                ratio=a*psi/weight
                rounding={'n':str(n),'a':str(a),'b':str(b),
                          'exact_ratio':str(ratio),'exact_positive_gap':str(weight-a*psi),
                          'rounded_display_only':float(ratio)}
                assert ratio<1 and float(ratio)==1.0
            controls.append({'s':s,'e':e,'positive_signed':psi>0,
                             'positive_shifted_with_off_credit':shifted>0 and off_credit>0})
    # Actual source differs from the least local odd-arrival residue.
    a,b,g,E,N=43,49,2,3,5;M=1<<(E+1)
    residue=((1<<E)-N)*pow(3**g,-1,M)%M
    assert (1<<E)*b==3**g*a+N and a%M==residue==11 and a!=residue
    return controls,rounding


def actual_profile():
    """One small genuine return, a control only; no large census."""
    n=u=47;H=(4*n-2)//3;x=u;word=[]
    for _ in range(200):
        e=v2(3*x+1);word.append(e);x=(3*x+1)//(1<<e)
        if x<=H:break
    assert n<=x<=H and len(word)<200
    return replay(n,u,word,'genuine small return, not a high-floor core')


def replay(n,u,word,scope):
    x=u;Q=F(0);runs=[];a=x;incoming=Q;start=0
    kappa=1-F(4,3*n+1)
    for index,e in enumerate(word,1):
        assert v2(3*x+1)==e
        Q+=(u+Q)/(3*x)
        x=(3*x+1)//(1<<e)
        if e>=2:
            s=index-start;z=F(2,3)**s;delta=(1-z)/a
            flux=F(1,a)-F(1,x);psi=max(F(0),kappa*delta+flux)
            weight=max(F(0),2-3*z)
            assert a*psi<=weight
            assert Q-incoming==(u+incoming)*delta
            runs.append({'a':a,'b':x,'s':s,'e':e,'delta':delta,'psi':psi,
                         'weight':weight,'q':incoming,'qend':Q,'flux':flux})
            start=index;a=x;incoming=Q
    assert start==len(word)
    return {'n':n,'u':u,'runs':runs,'scope':scope}


def group_data(p,selected):
    r=[p['runs'][i] for i in selected];groups={};u=p['u']
    for i in range(len(r)):
        height=F(0)
        for j in range(i,len(r)):
            height=max(height,r[j]['psi']/r[j]['delta'])
            cost=height*(r[j]['q']-r[i]['q'])/(u+r[i]['q'])
            true=sum((t['psi'] for t in r[i:j+1]),F(0))
            assert true<=cost+r[j]['psi']
            groups[i,j]=(cost,r[j]['weight'],height)
    return r,groups


def pareto(r,groups,budget):
    dp=[[] for _ in range(len(r)+1)];dp[0]=[(F(0),F(0))]
    for end in range(1,len(r)+1):
        candidates=[]
        for begin in range(end):
            c,w,_=groups[begin,end-1]
            candidates.extend((b+w,v+c) for b,v in dp[begin] if b+w<=budget)
        best=None
        for b,v in sorted(set(candidates)):
            if best is None or v<best:
                dp[end].append((b,v));best=v
    return min((v for _,v in dp[-1]),default=None)


def exhaustive(r,groups,budget):
    best=None;count=0
    for bits in product((0,1),repeat=max(0,len(r)-1)):
        starts=0;cost=F(0);weight=F(0)
        for end in [i for i,bit in enumerate(bits) if bit]+[len(r)-1]:
            c,w,_=groups[starts,end];cost+=c;weight+=w;starts=end+1
        if weight<=budget:best=cost if best is None else min(best,cost)
        count+=1
    return best,count


def fixed_group_count(r,groups,maximum):
    N=len(r);dp=[[None]*(N+1) for _ in range(maximum+1)];dp[0][0]=F(0)
    for b in range(1,maximum+1):
        for end in range(1,N+1):
            candidates=[dp[b-1][start]+groups[start,end-1][0]
                        for start in range(end) if dp[b-1][start] is not None]
            if candidates:dp[b][end]=min(candidates)
    return min(row[N] for row in dp if row[N] is not None)


def partition_controls():
    small=actual_profile();selected=[i for i,r in enumerate(small['runs']) if r['psi']>0]
    small_selected=selected[:8];r,g=group_data(small,small_selected)
    checks=0
    for budget in (F(2),F(4),F(6),F(56)):
        oracle,count=exhaustive(r,g,budget)
        assert pareto(r,g,budget)==oracle;checks+=count
    # Verify exact-endpoint split monotonicity, including skipped positive runs.
    splits=0
    for i in range(len(r)):
        for j in range(i+1,len(r)):
            parent=g[i,j][0]+r[j]['psi']
            for k in range(i,j):
                child=g[i,k][0]+r[k]['psi']+g[k+1,j][0]+r[j]['psi']
                assert child<=parent;splits+=1
    n=(1<<71)+1
    u=(1<<(3*32+1))-5
    local=replay(n,u,[1,2]*32,'local exact word, not a completed first-return core')
    r,g=group_data(local,list(range(32)))
    phi=pareto(r,g,F(56));omega=fixed_group_count(r,g,28)
    assert phi==0<omega
    # Long chain with J>56 but a uniformly paid chronological signed sum.
    chain=replay(n,(1<<(3*96+1))-5,[1,2]*96,'local exact word, not a completed first-return core')
    rows=chain['runs'];total=sum((t['psi'] for t in rows),F(0))
    J=sum((t['a']*t['psi'] for t in rows),F(0))
    assert J>56 and total<F(6,chain['u'])
    for t in rows:
        assert t['s']==2 and t['e']==2 and t['flux']>0
        assert t['delta']<5*t['flux'] and t['psi']<6*t['flux']
    return {'small_genuine_return_odd_transitions':sum(t['s'] for t in small['runs']),
            'small_positive_runs_selected':len(small_selected),
            'exhaustive_partition_comparisons':checks,'split_controls':splits,
            'local_32_run_weighted_cost':str(phi),'local_32_run_Omega28_positive':omega>0,
            'local_96_run_J_above_56':J>56,'local_96_run_resource_below_6_over_u':total<F(6,chain['u'])}


def signed_augmentation_controls():
    p=actual_profile();runs=p['runs'];N=len(runs)
    khat=F(p['n']-1,p['n']+1);alpha=15*khat-1
    t=[khat*r['delta']+r['flux'] for r in runs]
    W=sum((r['delta'] for r in runs),F(0))
    endpoint=F(1,runs[-1]['b'])-F(1,p['u'])
    controls=0;exhaustive_choices=0
    for C0 in ([],list(range(1,N)),list(range(1,N,2)),list(range(6,N))):
        C=set(C0);off=[i for i in range(N) if i not in C]
        WC=sum((runs[i]['delta'] for i in C),F(0))
        RC=sum((t[i] for i in C),F(0))
        Rstar=sum((max(F(0),t[i]) for i in C),F(0))-sum((max(F(0),-x) for x in t),F(0))
        Z=RC-sum((max(F(0),-runs[i]['flux']-runs[i]['delta']/15) for i in off),F(0))
        assert Z<=Rstar
        # The least nonnegative algebraic allowance for this selected set.
        # This is not asserted to be the high-floor canonical allowance.
        F0=max(F(0),W-WC-W/16)
        U=C|{i for i,x in enumerate(t) if x<0}
        WU=sum((runs[i]['delta'] for i in U),F(0))
        assert sum((t[i] for i in U),F(0))==Rstar
        assert alpha*WU<=15*Rstar+16*F0+15*endpoint
        rhs=15*Z+16*F0+15*endpoint
        assert 0<=alpha*WC<=rhs
        if len(off)<=6:
            choices=[]
            for mask in product((0,1),repeat=len(off)):
                objective=15*RC+sum((runs[i]['delta']+15*runs[i]['flux']
                    for i,chosen in zip(off,mask) if chosen),F(0))
                choices.append(objective)
            assert min(choices)==15*Z
            exhaustive_choices+=len(choices)
        controls+=1
    return {'selected_set_controls':controls,'exhaustive_augmentation_choices':exhaustive_choices,
            'minimal_allowance_is_algebra_control_not_canonical_theorem':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('six_note_homogeneous_audit_certificate.json'))
    args=parser.parse_args()
    assert F(1,1000)+F(2,100000)==F(51,50000)
    assert B0==15/ALPHA0 and A0==F(750,61)*F(59,1000)/ALPHA0
    assert F(15,4)-F(750,61)*CE==-F(73485,3904)
    neg=F(73485,3904)/ALPHA0
    assert neg==F(1837125,1364936)
    assert 56*B0*C+A0<159*C<TARGET<57*B0*C+A0
    gamma=(TARGET-159*C)/B0
    assert gamma==F(681059791019519908784361,4609029687280773728571200000)
    assert 84*F(2,3)==56 and 9*6+2==56
    rows,worst=complement_rows()
    runs,rounding=run_bound_controls()
    partitions=partition_controls()
    signed=signed_augmentation_controls()
    result={'status':'PASS','arithmetic':'Exact integers and Fraction; one explicitly labelled rounding display',
            'finite_complement_rows':len(rows),'worst_complement_row':worst,'complement_rows':rows,
            'constants':{'c':str(C),'b0':str(B0),'a0':str(A0),
                         'mixed_sector_slack':str(159*C-(56*B0*C+A0)),
                         'gamma':str(gamma),'retained_negative_endpoint_coefficient':str(neg)},
            'run_controls':len(runs),'finite_attainment_counterexample':rounding,
            'partition_controls':partitions,
            'signed_augmentation_controls':signed,
            'local_t_positive_runs_with_new_off_credit':sum(r['positive_shifted_with_off_credit'] for r in runs),
            'scope':{'all_six_attachments_read':True,'large_reported_censuses_rerun':False,
                     'source_profile_injection_and_global_complement_imported':True,
                     'homogeneous_accounting_rederived_from_phase_and_reset_factors':True,
                     'local_controls_claimed_as_central_profiles':False,
                     'unrestricted_aggregate_bound_proved':False}}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','finite_rows':len(rows),'run_controls':len(runs),
                      'partitions':partitions,'signed_augmentations':signed,
                      'unrestricted_aggregate_bound_proved':False}))


if __name__=='__main__':main()
