#!/usr/bin/env python3
"""Reproduce this release's three exact checks and verify frozen provenance.

Python 3.10+, standard library only. Run from any working directory.
Previous-release checks are included for context but are not rerun here.
"""
from __future__ import annotations

import argparse
import ast
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

if not __debug__:
    raise RuntimeError("Exact assertions must remain enabled; do not use -O.")

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "aggregate_compensation_work"
TASKS = (
    ("verify_six_note_homogeneous_audit.py", "six_note_homogeneous_audit_certificate.json"),
    ("verify_exact_signed_compensation.py", "exact_signed_compensation_certificate.json"),
    ("verify_source_cylinder_carleson.py", "source_cylinder_carleson_certificate.json"),
)


def check_payload():
    manifest = json.loads((ROOT / "release_manifest.json").read_text())
    for name, expected in manifest["files"].items():
        path = ROOT / name
        assert path.is_file(), f"Missing payload: {name}"
        assert path.stat().st_size == expected["bytes"], f"Size mismatch: {name}"
        assert sha256(path.read_bytes()).hexdigest() == expected["sha256"], name
    return len(manifest["files"])


def check_provenance():
    original = ROOT / "previous_release" / "Collatz_Research.zip"
    original_hash = sha256(original.read_bytes()).hexdigest()
    assert original_hash == "f71297e999e96b6a4fbe4b3ee85f01d2537f25a1e87fb2d7dbf2616070ecfdfd"
    with ZipFile(original) as z:
        assert z.testzip() is None
        for current, prior in (
            ("exact_compensation_seeds.json", "span_residue_work/ordered_span_seeds.json"),
            ("source_cylinder_controls.json", "previous/aggregate_central_work/central_collision_seeds.json"),
        ):
            assert (WORK / current).read_bytes() == z.read(prior), current
        old_code = z.read("span_residue_work/ordered_span_verify.py")
    source_hash = sha256(old_code).hexdigest()
    assert source_hash == "3bc4cc696496b2b3170a14e6f7cb84bcc75e20045626e276488493cc6b980c8b"
    old_functions = {
        node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(old_code).body if isinstance(node, ast.FunctionDef)
    }
    copied = []
    for node in ast.parse((WORK / "exact_compensation_profile_support.py").read_text()).body:
        if isinstance(node, ast.FunctionDef):
            assert old_functions[node.name] == ast.dump(node, include_attributes=False)
            copied.append(node.name)
    assert len(copied) == 6
    audit = json.loads((WORK / "six_note_homogeneous_audit_provenance.json").read_text())
    for item in audit["inputs"]:
        name = Path(item["file"]).name
        assert sha256((ROOT / "incoming_notes" / name).read_bytes()).hexdigest() == item["sha256"]
    for name, expected in audit["artifacts"].items():
        assert sha256((WORK / name).read_bytes()).hexdigest() == expected
    return {
        "previous_archive_sha256": original_hash,
        "copied_function_ASTs_identical": copied,
        "fixtures_identical_to_previous_release": True,
        "six_incoming_notes_unchanged": True,
        "previous_release_verifiers_rerun": False,
    }


def run_one(task, temporary):
    script, certificate = task
    destination = temporary / certificate
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, str(WORK / script), "--output", str(destination)],
        cwd=ROOT, env=environment, text=True, capture_output=True, timeout=600,
    )
    if result.returncode:
        raise RuntimeError(f"{script} failed:\n{result.stdout}\n{result.stderr}")
    generated = destination.read_bytes()
    expected = (WORK / certificate).read_bytes()
    assert generated == expected, f"Nonidentical certificate: {certificate}"
    summary = json.loads(result.stdout)
    assert summary["status"] == "PASS"
    print(f"PASS {script}: certificate reproduced byte for byte", flush=True)
    return {
        "script": script,
        "certificate": certificate,
        "certificate_sha256": sha256(generated).hexdigest(),
        "byte_identical": True,
        "summary": summary,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "aggregate_compensation_verification.json")
    arguments = parser.parse_args()
    count = check_payload()
    provenance = check_provenance()
    b0, a0 = F(3000,2797), F(8850,170617)
    target, signed_target = F(327,3904), F(116073,3904000)
    retained_credit = F(1837125,1364936)
    assert b0 * signed_target + a0 == target
    assert retained_credit / b0 == F(4899,3904)
    with tempfile.TemporaryDirectory(prefix="collatz-compensation-") as temp:
        temporary = Path(temp)
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(run_one, task, temporary) for task in TASKS]
            results = [future.result() for future in futures]
    certificate = {
        "status": "PASS",
        "payload_files_checked": count,
        "checks": results,
        "provenance": provenance,
        "numerical_targets": {
            "central_target": str(target),
            "signed_target": str(signed_target),
            "retained_profile_count_credit": str(retained_credit / b0),
            "identities_checked_exactly": True,
        },
        "scope": {
            "exact_arithmetic_controls_reproduced": True,
            "original_core_and_all_source_occurrences_retained": True,
            "broad_censuses_rerun": False,
            "imported_global_theorems_newly_formalized": False,
            "unrestricted_aggregate_numerical_bound_proved": False,
            "residual_21_over_125_proved": False,
        },
    }
    arguments.output.write_text(json.dumps(certificate, indent=2) + "\n")
    print("PASS all three checks; unrestricted numerical target remains unproved.")


if __name__ == "__main__":
    main()
