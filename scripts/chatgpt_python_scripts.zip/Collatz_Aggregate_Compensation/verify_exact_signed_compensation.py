#!/usr/bin/env python3
"""Exact chronological signed covers and global compensation controls.

Requires only adjacent exact_compensation_profile_support.py and
exact_compensation_seeds.json. No search or external packages are used.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
import exact_compensation_profile_support as support

if hasattr(sys,"set_int_max_str_digits"):sys.set_int_max_str_digits(0)
if not __debug__:raise RuntimeError("Assertions must remain enabled.")
HERE=Path(__file__).resolve().parent


def exact_cover(p,selected):
    """Shortest path plus an independently checked feasible dual potential."""
    runs=p["runs"];N=len(runs);C=set(selected);k=p["kappa"]
    assert all(1<=i<N for i in C)
    t=[k*r["delta"]+r["flux"] for r in runs]
    S=[F(0)]*(N+1)
    for i in range(1,N):S[i+1]=S[i]+t[i]
    D=[F(0)]*(N+1);number=[0]*(N+1);choice={}
    for i in range(N-1,0,-1):
        options=[]
        if i not in C:options.append((D[i+1],number[i+1],0,i+1))
        for j in range(i+1,N+1):
            options.append((max(F(0),S[j]-S[i])+D[j],number[j]+1,1,j))
        D[i],number[i],kind,j=min(options);choice[i]=(kind,j)
    dual=0
    for i in range(1,N):
        if i not in C:assert D[i]<=D[i+1]
        for j in range(i+1,N+1):
            assert D[i]-D[j]<=max(F(0),S[j]-S[i])
            dual+=1
    assert D[N]==0
    covered=set();intervals=[];i=1;primal=F(0);negative_blocks=F(0)
    while i<N:
        kind,j=choice[i]
        if kind:
            assert covered.isdisjoint(range(i,j))
            covered.update(range(i,j));intervals.append((i,j))
            signed=S[j]-S[i];primal+=max(F(0),signed)
            negative_blocks+=max(F(0),-signed)
        else:assert i not in C
        i=j
    assert C<=covered and primal==D[1]
    WC=sum((runs[i]["delta"] for i in C),F(0))
    extra=sum((runs[i]["delta"] for i in covered-C),F(0))
    off_flux=sum((r["flux"] for i,r in enumerate(runs) if i not in covered),F(0))
    endpoint=F(1,p["w"])-F(1,p["u"])
    assert primal==k*WC+k*extra-endpoint-off_flux+negative_blocks
    Y=sum((max(F(0),t[i]) for i in C),F(0))
    assert 0<=primal<=Y
    if C:
        first,last=min(C),max(C)
        hull=set(range(first,last+1));holes=hull-C
        closed=max(F(0),min(S[last+1:])-max(S[1:first+1]))
        hole_positive=sum((max(F(0),t[i]) for i in holes),F(0))
        hole_weight=sum((runs[i]["delta"] for i in holes),F(0))
        assert primal<=closed<=primal+hole_positive
        assert hole_positive<=(k+1)*hole_weight
        contiguous=(hull==C)
        if contiguous:assert primal==closed
    else:
        closed=F(0);contiguous=True;hole_positive=F(0);assert primal==0
    dual_payload=json.dumps({"S":[str(x) for x in S[1:]],"pi":[str(x) for x in D[1:]]},
                            separators=(",",":")).encode()
    return {"required_runs":len(C),"contiguous":contiguous,"cost":str(primal),
            "normalized_cost":str((p["H"]+1)*primal),"individual_positive_cost":str(Y),
            "hull_closed_form":str(closed),"hole_positive_allowance":str(hole_positive),
            "blocks":len(intervals),"intervals":[[runs[i]["i"],runs[j-1]["j"]] for i,j in intervals],
            "dual_constraints_checked":dual,"dual_payload_sha256":sha256(dual_payload).hexdigest(),
            "strictly_positive_dual_lower_bound":primal>0},primal


def global_controls(p,C):
    """All negative terms and the stronger optimal complement mask."""
    runs=p["runs"];C=set(C);k=p["kappa"];alpha=15*k-1
    t=[k*r["delta"]+r["flux"] for r in runs]
    Y=sum((max(F(0),t[i]) for i in C),F(0))
    NC=sum((max(F(0),-t[i]) for i in C),F(0))
    Nall=sum((max(F(0),-x) for x in t),F(0))
    RC=Y-NC
    Ustar=C|{i for i,x in enumerate(t) if x<0}
    Rstar=Y-Nall
    assert Rstar==sum((t[i] for i in Ustar),F(0))
    off=[i for i in range(len(runs)) if i not in C]
    A={i for i in off if runs[i]["flux"]<-runs[i]["delta"]/15}
    credit=sum((-runs[i]["flux"]-runs[i]["delta"]/15 for i in A),F(0))
    Z=RC-credit;U=C|A
    WA=sum((runs[i]["delta"] for i in A),F(0))
    RU=sum((t[i] for i in U),F(0))
    assert 15*RU-alpha*WA==15*Z
    assert Z<=Rstar<=Y
    W=sum((r["delta"] for r in runs),F(0))
    WC=sum((runs[i]["delta"] for i in C),F(0))
    endpoint=F(1,p["w"])-F(1,p["u"])
    hplus=sum((max(F(0),runs[i]["flux"]+runs[i]["delta"]/15) for i in off),F(0))
    assert 15*Z+15*endpoint-alpha*WC==W-15*hplus
    WoffC=W-WC
    assert 15*hplus<=16*WoffC
    for chosen,resource in ((Ustar,Rstar),(U,RU)):
        WU=sum((runs[i]["delta"] for i in chosen),F(0))
        Woff=W-WU
        assert k*WU<=resource+Woff+endpoint
    subset_checks=0
    if len(runs)<=8:
        bestR=bestZ=None
        for mask in range(1<<len(off)):
            added={off[j] for j in range(len(off)) if mask>>j&1}
            R=RC+sum((t[i] for i in added),F(0))
            z=RC+sum((runs[i]["flux"]+runs[i]["delta"]/15 for i in added),F(0))
            bestR=R if bestR is None else min(bestR,R)
            bestZ=z if bestZ is None else min(bestZ,z)
            subset_checks+=1
        assert bestR==Rstar and bestZ==Z
    result={"Y_core":str(Y),"negative_core":str(NC),"negative_all":str(Nall),
            "R_star":str(Rstar),"Z":str(Z),"normalized_Y":str((p["H"]+1)*Y),
            "normalized_negative_all":str((p["H"]+1)*Nall),
            "normalized_R_star":str((p["H"]+1)*Rstar),"normalized_Z":str((p["H"]+1)*Z),
            "optimal_mask_runs":len(A),"mask_positive_t_runs":sum(t[i]>0 for i in A),
            "mask_odd_indices":[runs[i]["i"] for i in sorted(A)],
            "exhaustive_subset_checks":subset_checks}
    return result,Rstar,Z


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output",type=Path,default=HERE/"exact_signed_compensation_certificate.json")
    args=ap.parse_args()
    seed=HERE/"exact_compensation_seeds.json";data=json.loads(seed.read_bytes())
    counts=defaultdict(int);rows=[];actual=[];groups={}
    for group in data["groups"]:
        n=int(group["n"]);high=n>=1<<71;P=support.source_count(n) if high else None
        for item in group["sources"]:
            p=support.replay(n,item);counts["profiles"]+=1
            whole_charge=(1+p["Q"]/p["u"])*(1+F(5,p["w"]))/(1+F(5,p["u"]))-1
            counts["high_floor_profiles" if high else "low_floor_algebra_profiles"]+=1
            C=support.actual_core(p,P) if high else []
            counts["actual_nonempty_cores" if high and C else "actual_empty_cores" if high else "algebra_empty_selections"]+=1
            global_row,Rstar,Z=global_controls(p,C)
            if high and not C:assert Z<=Rstar<0
            counts["exhaustive_global_subset_checks"]+=global_row["exhaustive_subset_checks"]
            counts["positive_t_contractions_in_optimal_mask"]+=global_row["mask_positive_t_runs"]
            proper=list(range(1,len(p["runs"])))
            selections=[("all_proper_algebra",proper),("alternating_proper_algebra",proper[::2])]
            if high:selections.append(("actual_core",C))
            checks={}
            for label,selected in selections:
                result,cost=exact_cover(p,selected);checks[label]=result
                counts["signed_cover_controls"]+=1
                counts["dual_interval_constraints"]+=result["dual_constraints_checked"]
                if label=="actual_core":
                    assert Rstar<=cost
                    if C:
                        assert cost>0
                        counts["positive_genuine_core_duals"]+=1
                        assert result["contiguous"]
            row={"n":str(n),"u":str(p["u"]),"H":str(p["H"]),
                 "whole_normalized_phi5_charge":str(whole_charge),
                 "whole_normalized_phi5_charge_sign":(whole_charge>0)-(whole_charge<0),
                 "scope":"actual_high_floor_core" if high else "low_floor_algebra_only",
                 "core_odd_indices":[p["runs"][i]["i"] for i in C] if high else None,
                 "global_compensation":global_row,"cover_controls":checks}
            rows.append(row)
            if high and C:actual.append(row)
            if high:
                key=str(n)
                if key not in groups:groups[key]={"H":p["H"],"sources":[],"R":F(0),"Z":F(0),"charge_signs":[]}
                groups[key]["sources"].append(str(p["u"]));groups[key]["R"]+=Rstar;groups[key]["Z"]+=Z
                groups[key]["charge_signs"].append((whole_charge>0)-(whole_charge<0))
    assert counts["profiles"]==32 and counts["high_floor_profiles"]==18
    assert counts["actual_nonempty_cores"]==6 and counts["actual_empty_cores"]==12
    same_n=str(26645514422485486121914504906678081)
    pair=groups[same_n]
    assert set(pair["sources"])=={"35527352563313981495886006542237435","35527352563313981495886006542237439"}
    assert pair["Z"]<0
    assert pair["charge_signs"]==[1,1]
    assert sum(F(x["global_compensation"]["Z"])>0 for x in actual)==3
    grouped=[{"n":n,"sources":x["sources"],"R_star_sum":str(x["R"]),"Z_sum":str(x["Z"]),
              "whole_phi5_charge_signs":x["charge_signs"],
              "normalized_Z_sum":str((x["H"]+1)*x["Z"]),
              "scope":"Saved subfamily only; not the complete original family."} for n,x in groups.items()]
    result={"status":"PASS","counts":dict(counts),
            "dependencies":{name:sha256((HERE/name).read_bytes()).hexdigest()
                            for name in ("exact_compensation_profile_support.py","exact_compensation_seeds.json")},
            "actual_nonempty_core_controls":actual,"profile_controls":rows,"saved_same_n_subfamilies":grouped,
            "scope":{"exact_signed_cover_optima_and_duals_verified":True,
                     "global_R_star_and_optimal_Z_mask_identities_verified":True,
                     "all_profile_occurrences_retained":True,
                     "uniform_aggregate_numerical_target_proved":False,
                     "old_source_and_complement_theorems_imported":True}}
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    summary=[{"core":len(x["core_odd_indices"]),
              "exact_cover":float(F(x["cover_controls"]["actual_core"]["normalized_cost"])),
              "R_star":float(F(x["global_compensation"]["normalized_R_star"])),
              "Z":float(F(x["global_compensation"]["normalized_Z"]))} for x in actual]
    print(json.dumps({"status":"PASS","counts":dict(counts),"actual_core_summary":summary,
                      "same_n_11_plus_1_core_Z_sum_normalized":float((pair["H"]+1)*pair["Z"])}))


if __name__=="__main__":main()
