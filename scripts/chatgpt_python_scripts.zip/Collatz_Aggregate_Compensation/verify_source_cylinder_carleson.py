#!/usr/bin/env python3
"""Exact source-cylinder packing and atomic-measure controls.

Four frozen genuine core profiles are replayed. No census or depth search is run.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Exact assertions are required; do not use -O or -OO.")

HERE = Path(__file__).resolve().parent


def prescribed_count(n: int) -> int:
    H = (4*n-2)//3
    k = max(2, (H-n).bit_length())
    row, short = {2: 1}, 0
    for t in range(3, k+1):
        short += sum(c for g,c in row.items()
                     if (3*n-k)*(1 << t) < 3*H*3**g
                     and n*3**g < H*(1 << t))
        nxt = defaultdict(int)
        for g,c in row.items():
            for bit in (0,1):
                gg = g+bit
                if (1 << t)*n**gg < (3*n+1)**gg:
                    nxt[gg] += c
        row = dict(nxt)
    newer = short+sum(row.values())
    row = {2: 1}
    for t in range(3, H.bit_length()+1):
        nxt = defaultdict(int)
        for g,c in row.items():
            for bit in (0,1):
                gg = g+bit
                if 3**gg > 1 << (t-1):
                    nxt[gg] += c
        row = dict(nxt)
    return min(newer,2*sum(row.values()))


def replay(n: int, Pstar: int, item: dict) -> dict:
    H = (4*n-2)//3
    B = 5+F(n,100000*Pstar)
    u, word = int(item['u']), item['word']
    assert n >= 1 << 71 and n%2 and u%4 == 3
    odd, times, phases = [u], [0], [F(0)]
    shortcut, affines = [u], [(0,0)]
    r = U = E = odd_U = 0
    for i,e in enumerate(word):
        y = 3*odd[-1]+1
        assert (y & -y).bit_length()-1 == e
        odd.append(y >> e)
        odd_U = 3*odd_U+(1 << E)
        E += e
        times.append(E)
        phases.append(F(odd_U,3**(i+1)))
        for _ in range(e):
            x = shortcut[-1]
            j = len(shortcut)-1
            if x%2:
                U = 3*U+(1 << j)
                r += 1
                y = (3*x+1)//2
            else:
                y = x//2
            shortcut.append(y)
            affines.append((r,U))
            assert (1 << (j+1))*y == 3**r*u+U
        assert shortcut[-1] == odd[-1]
    assert n <= u <= H and n <= odd[-1] <= H
    assert min(odd[1:-1]) > H
    assert len(set(shortcut[:-1])) == E
    modulus = 1 << (E+1)
    assert (((1 << E)-odd_U)*pow(3**len(word),-1,modulus))%modulus == u
    assert 1+phases[-1]/u < F(47,32)
    assert F((1 << E)*(odd[-1]+5),3**len(word)*(u+5)) > 1
    core, start, ordinal = [], 0, 0
    khat = 1-F(4,3*n+1)
    for end,e in enumerate(word,1):
        if e < 2:
            continue
        a, b, s = odd[start], odd[end], end-start
        z = F(2,3)**s
        delta = (1-z)/a
        psi = max(F(0),khat*delta+F(1,a)-F(1,b))
        assert phases[end]-phases[start] == (u+phases[start])*delta
        assert a*psi <= max(F(0),2-3*z) < 2
        assert s != 1 or psi == 0
        ell, incoming = a.bit_length()-1,times[start]
        d = incoming+ell
        t = ell-(n.bit_length()-1)
        if t >= 0:
            J = (1 << ell)//(2000*Pstar*(t+1)*(t+2))
        else:
            J = 0
        # The ordinal after this run is independent of the retained core.
        total_runs = sum(v >= 2 for v in word)
        retained = (start > 0 and H < a < 1 << (64*n.bit_length())
                    and d < E and 64*shortcut[d] > a
                    and phases[start] > B and phases[-1]-phases[start] > B
                    and ordinal > J and total_runs-ordinal > J)
        if retained:
            rr,UU = affines[d]
            inverse = (-UU*pow(3**rr,-1,1 << d))%(1 << d)
            assert inverse == u and d >= H.bit_length()
            assert d == ((1 << incoming)*a).bit_length()-1
            core.append({'ordinal':ordinal,'g':start,'a':a,'b':b,
                         'd':d,'u':u,'delta':delta,'psi':psi,'s':s})
        start,ordinal = end,ordinal+1
    assert start == len(word)
    assert [c['g'] for c in core] == item['expected_core']
    for x,y in zip(core,core[1:]):
        assert y['d'] >= x['d']+1
        assert (1 << times[y['g']])*y['a'] > 3**(y['g']-x['g'])*(1 << times[x['g']])*x['a']
    positives = [c for c in core if c['psi'] > 0]
    for x,y in zip(positives,positives[1:]):
        assert x['s'] >= 2 and y['g']-x['g'] >= 2
        assert y['d'] >= x['d']+3
    return {'u':u,'core':core,'positives':positives,'B':B,'E':E}


def contains(parent: tuple[int,int], child: dict) -> bool:
    L,residue = parent
    return child['d'] >= L and child['u']%(1 << L) == residue


def audit_family(family: dict) -> dict:
    n = int(family['n'])
    H,h = (4*n-2)//3,((4*n-2)//3).bit_length()
    Pstar = prescribed_count(n)
    paths = [replay(n,Pstar,item) for item in family['sources']]
    sources = [p['u'] for p in paths]
    assert len(sources) == len(set(sources))
    core = [c for p in paths for c in p['core']]
    positive = [c for p in paths for c in p['positives']]
    assert len({(c['d'],c['u']) for c in core}) == len(core)
    max_depth = max(c['d'] for c in core)
    ancestors = {(L,u%(1 << L)) for u in sources for L in range(max_depth+1)}
    atomic_norm = F(0)
    max_haar = max_positive_haar = F(0)
    martingale_checks = 0
    for parent in ancestors:
        L,residue = parent
        mass = F(1,1 << L)
        descendants = [c for c in core if contains(parent,c)]
        pos = [c for c in positive if contains(parent,c)]
        packed = sum((F(1,1 << c['d']) for c in descendants),F(0))
        packed_pos = sum((F(1,1 << c['d']) for c in pos),F(0))
        assert packed <= 2*mass
        assert packed_pos <= F(8,7)*mass
        assert sum((c['a']*c['psi']/2**c['d'] for c in pos),F(0)) <= F(16,7)*mass
        assert sum((c['psi']/2**c['d'] for c in pos),F(0)) <= F(16,7*(H+1))*mass
        max_haar = max(max_haar,packed/mass)
        max_positive_haar = max(max_positive_haar,packed_pos/mass)
        nu = sum(u%(1 << L) == residue for u in sources)
        assert nu > 0
        atomic_norm = max(atomic_norm,sum((c['psi'] for c in pos),F(0))/nu)
        if L >= h:
            assert nu == 1
        if L < max_depth:
            child_counts = [sum(u%(1 << (L+1)) == residue+b*(1 << L)
                                for u in sources) for b in (0,1)]
            assert nu*(1 << L) == sum(v*(1 << (L+1)) for v in child_counts)//2
            martingale_checks += 1
    per_source = [sum((c['psi'] for c in p['positives']),F(0)) for p in paths]
    assert atomic_norm == max(per_source)
    total = sum(per_source,F(0))
    normalized_occupations = [(H+1)*v for v in per_source]
    levels = sorted(set([F(0)]+normalized_occupations))
    tail_area = sum(((upper-lower)*sum(v >= upper for v in normalized_occupations)
                     for lower,upper in zip(levels,levels[1:])),F(0))
    assert tail_area/(H+1) == total
    weighted_haar = sum((c['psi']*2**c['d']*F(1,1 << c['d']) for c in positive),F(0))
    assert weighted_haar == total
    for L in [h,h+1,max_depth]:
        cells = {u%(1 << L) for u in sources}
        assert len(cells) == len(sources)
        assert len(cells)*F(2**(2*L),2**L) == len(sources)*2**L
    maximal_checks = []
    for M in [h,h+1,h+17,max_depth]:
        exact_shell_integral = len(sources)*(F(M-h,2)+1)
        independently_summed = len(sources)*(sum((F(2**k,2**(k+1))
                                                  for k in range(h,M)),F(0))+1)
        assert exact_shell_integral == independently_summed
        maximal_checks.append({'M':M,'integral':str(exact_shell_integral)})
    stop = [p['core'][0] for p in paths if p['core']]
    for i,c in enumerate(stop):
        for other in stop[:i]:
            assert not contains((c['d'],c['u']),other)
            assert not contains((other['d'],other['u']),c)
    stop_haar = sum((F(1,1 << c['d']) for c in stop),F(0))
    assert sum(2**c['d']*F(1,1 << c['d']) for c in stop) == len(stop)
    by_state = defaultdict(list)
    for pid,p in enumerate(paths):
        for c in p['core']:
            by_state[c['a']].append((pid,c['g']))
    shared = [v for v in by_state.values() if len(v)>1]
    if family['name'] == 'asynchronous':
        assert len(shared) == 6 and all(len({g for _,g in row}) == 2 for row in shared)
    else:
        assert family['name'] == 'synchronized'
        assert len(shared) == 1 and len({g for _,g in shared[0]}) == 1
    return {'family':family['name'],'n':str(n),'Pstar':str(Pstar),'h':h,
            'Bstar':str(paths[0]['B']),'profiles':len(paths),
            'actual_core_occurrences':len(core),'positive_occurrences':len(positive),
            'shared_physical_core_states':len(shared),
            'distinct_canonical_nodes':len({(c['d'],c['u']) for c in core}),
            'ancestor_cylinders_checked':len(ancestors),
            'martingale_checks':martingale_checks,
            'maximum_Haar_packing_ratio':str(max_haar),
            'maximum_positive_Haar_packing_ratio':str(max_positive_haar),
            'exact_atomic_Carleson_norm':str(atomic_norm),
            'actual_total_signed_charge':str(total),
            'exact_normalized_occupation_tail_integral':str(tail_area),
            'one_cut_per_source_Haar_mass':str(stop_haar),
            'one_cut_per_source_atomic_mass':len(stop),
            'maximal_density_controls':maximal_checks}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixtures',type=Path,default=HERE/'source_cylinder_controls.json')
    parser.add_argument('--output',type=Path,default=HERE/'source_cylinder_carleson_certificate.json')
    args = parser.parse_args()
    raw = args.fixtures.read_bytes()
    data = json.loads(raw)
    families = [audit_family(f) for f in data['families']]
    abstract_controls = []
    for m in [1,2,8,32,128]:
        H = 100
        haar = sum((F(1,8**j*(H+1)) for j in range(m)),F(0))
        atomic = F(m,H+1)
        assert haar <= F(8,7*(H+1))
        assert atomic == m*F(1,H+1)
        if m >= 2:
            assert atomic > F(8,7*(H+1))
        abstract_controls.append({'nodes':m,'Haar_ratio':str(haar),
                                  'atomic_cost':str(atomic),
                                  'scope':'abstract measure counterexample, not a Collatz profile'})
    result = {'status':'PASS','arithmetic':'integers and Fraction',
              'families':families,'abstract_controls':abstract_controls,
              'fixture_sha256':sha256(raw).hexdigest(),
              'verifier_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope':{'actual_core_predicates_retained':True,
                       'all_source_occurrences_retained':True,
                       'Haar_to_atomic_conversion_proved':True,
                       'uniform_aggregate_charge_bound_proved':False,
                       'broad_census_or_constructor_search_performed':False}}
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','profiles':sum(x['profiles'] for x in families),
                      'actual_core_occurrences':sum(x['actual_core_occurrences'] for x in families),
                      'positive_occurrences':sum(x['positive_occurrences'] for x in families),
                      'ancestor_cylinders_checked':sum(x['ancestor_cylinders_checked'] for x in families)}))


if __name__ == '__main__':
    main()
