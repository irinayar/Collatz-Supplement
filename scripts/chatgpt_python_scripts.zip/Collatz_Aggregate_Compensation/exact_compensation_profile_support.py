"""Immutable replay/core helper copied from the audited prior verifier.
Source: span_residue_work/ordered_span_verify.py
SHA256: 3bc4cc696496b2b3170a14e6f7cb84bcc75e20045626e276488493cc6b980c8b
Only exact profile replay and fixed core/source-count functions are included.
The uniform source-count theorem is imported, not newly proved here.
"""
from collections import defaultdict
from fractions import Fraction as F
def v2(x):
    return (x & -x).bit_length()-1

def product(xs):
    result=F(1)
    for x in xs: result*=x
    return result

def ceil_div(a,b):
    return -((-a)//b)

def source_count(n):
    H=(4*n-2)//3;k=(H-n).bit_length()
    powers3=[3**r for r in range(k+1)]
    powersn=[n**r for r in range(k+1)]
    perturbed=[(3*n+1)**r for r in range(k+1)]
    row={2:1};short=0
    for j in range(3,k+1):
        short+=sum(c for r,c in row.items()
                   if (3*n-k)*(1<<j)<3*H*powers3[r]
                   and n*powers3[r]<H*(1<<j))
        nxt=defaultdict(int)
        for r,c in row.items():
            for bit in (0,1):
                rr=r+bit
                if (1<<j)*powersn[rr]<perturbed[rr]:nxt[rr]+=c
        row=dict(nxt)
    newer=sum(row.values())+short
    row={2:1}
    for j in range(3,H.bit_length()+1):
        nxt=defaultdict(int)
        for r,c in row.items():
            for bit in (0,1):
                rr=r+bit
                if 3**rr>1<<(j-1):nxt[rr]+=c
        row=dict(nxt)
    return min(newer,2*sum(row.values()))

def replay(n,item):
    u=int(item['u']);word=item['word'];H=(4*n-2)//3
    odd=[u];shortcut=[u];times=[0];phases=[F(0)];nums=[0]
    E=N=0
    for g,e in enumerate(word,1):
        x=odd[-1];assert v2(3*x+1)==e
        y=(3*x+1)//2;shortcut.append(y)
        for _ in range(e-1):
            assert y%2==0;y//=2;shortcut.append(y)
        assert y%2;odd.append(y)
        N=3*N+(1<<E);E+=e
        times.append(E);nums.append(N);phases.append(F(N,3**g))
        assert (1<<E)*y==3**g*u+N
    g=len(word);w=odd[-1]
    assert n<=u<=H and n<=w<=H
    assert all(x>H for x in odd[1:-1])
    modulus=1<<(E+1)
    residue=(((1<<E)-N)*pow(3**g,-1,modulus))%modulus
    low=max(n,ceil_div((1<<E)*n-N,3**g))
    high=min(H,((1<<E)*H-N)//3**g)
    for i in range(1,g):low=max(low,((1<<times[i])*H-nums[i])//3**i+1)
    assert low+(residue-low)%modulus==u<=high
    kappa=F(n-1,n+1);assert 0<kappa<=1-F(4,3*n+1)
    runs=[];start=0
    for end,e in enumerate(word,1):
        if e<2:continue
        s=end-start;a=odd[start];b=odd[end]
        z=F(2,3)**s;beta=1-z;q=(1<<(e-1))*z;delta=beta/a
        flux=F(1,a)-F(1,b);psi=max(F(0),kappa*delta+flux)
        theta=max(F(0),2-z-q)
        assert psi<=theta/a
        rho=(1+delta)*(1+F(5,b))/(1+F(5,a))
        assert b==(a+beta)/q
        assert rho==1+(5*q-4-z)/(a+5)
        good=(rho<=1)
        assert good==(5*(1<<(s+e-1))<=4*3**s+(1<<s))
        if good:
            assert a<b and delta*(1+F(5,b))<=5*flux
            assert delta<5*flux and psi==kappa*delta+flux<6*flux
        elif psi>0:
            assert psi<F(6,5)*delta<F(6,5*a)
        if s==1:assert psi==0
        assert phases[end]-phases[start]==(u+phases[start])*delta
        runs.append({'i':start,'j':end,'a':a,'b':b,'s':s,'e':e,'q':phases[start],
                     'qend':phases[end],'delta':delta,'flux':flux,'psi':psi,'good':good,
                     'rho':rho,'theta':theta,'ordinal':len(runs),'time':times[start]})
        start=end
    assert start==g
    assert sum((r['flux'] for r in runs),F(0))==F(1,u)-F(1,w)
    assert product(1+r['delta'] for r in runs)==1+phases[-1]/u<F(47,32)
    return {'n':n,'H':H,'u':u,'w':w,'word':word,'odd':odd,'shortcut':shortcut,
            'times':times,'phases':phases,'E':E,'Q':phases[-1],'runs':runs,'kappa':kappa}

def actual_core(p,P):
    n=p['n'];H=p['H'];L=n.bit_length()-1;m=n.bit_length()
    B=5+F(n,100000*P);selected=[]
    for k,r in enumerate(p['runs']):
        a=r['a'];ell=a.bit_length()-1;t=ell-L
        J=(1<<ell)//(2000*P*(t+1)*(t+2))
        position=r['time']+ell
        if (r['i']>0 and H<a<1<<(64*m) and position<p['E']
            and 64*p['shortcut'][position]>a and r['q']>B and p['Q']-r['q']>B
            and k>J and len(p['runs'])-k>J):selected.append(k)
    return selected
