"""Exact rational potential and parity-word tests. Python 3.10+."""
from fractions import Fraction
from collections import Counter

def accelerated(n):
    return (3*n+1)//2 if n&1 else n//2

def run(limit=5000,even_limit=25):
    counts=Counter();examples=[]
    for m in range(1,limit+1):
        n=m;k=r=0
        P=Fraction(m+1,1)
        while k<=even_limit:
            assert P==Fraction(2**r,3**r)*(2**k*n+1)
            if n>=3:
                counts['outside_cycle']+=1
                if not 2*P<3*(m+1):
                    counts['outside_failures']+=1
                    if len(examples)<20: examples.append((m,n,k,r,str(P)))
            else:
                counts['cycle_states']+=1
            if n%2:
                Pnew=P+Fraction(2**r,3**r)*Fraction(2**k-1,3)
                n=accelerated(n);r+=1
            else:
                Pnew=P;n=accelerated(n);k+=1
            assert Pnew==Fraction(2**r,3**r)*(2**k*n+1)
            P=Pnew
    return dict(counts),examples
if __name__=='__main__':
    a,b=run();print(a);print('exceptions',b)
