from itertools import product
from collections import Counter,defaultdict
import json
from _prior_joint import data,residue,join,exceptional

def upper_envelope(n,M,R):
    # exact sound upper bound by residue and depth for all 1<=m<n
    B=[0]*M
    for s in range(M):
        h=n-1-((n-1-s)%M)
        B[s]=max(0,h)
    U=B[:]
    for j in range(R):
        C=[0]*M
        for s,h in enumerate(B):
            if not h:continue
            for parity in (0,1):
                z=h-M*((h-parity)%2)
                if z<1:continue
                y=(3*z+1)//2 if parity else z//2
                C[y%M]=max(C[y%M],y)
        B=C
        U=[max(x,y) for x,y in zip(U,B)]
    return U

def affine(w,n):
    L,a,u=data(w)
    return (3**a*n+u)//2**L

def run(w, K=13, target_max=8, envelope_mod=27, test_classes=160):
    j,a,u=data(w);r=residue(w)
    assert exceptional(w) and K>j
    catalog=[]
    for ell in range(1,target_max+1):
        for v in product((0,1),repeat=ell):
            z=join(w,v)
            if z and z['positive_slope']:
                catalog.append((v,z))
    B=max([0]+[max(0,data(v)[1]-a) for v,z in catalog]);q=3**B
    binary=2**(K-j);P=q*binary
    meet_t=set()
    for v,z in catalog:
        meet_t.update(range(z['t0'],P,z['q']))
    # source t modulo 2^(K-j) determines exact next K-j parity bits
    desc_bin=set();blocks={};first_exit={}
    for bits in product((0,1),repeat=K-j):
        ext=w+bits;rr=residue(ext)
        tbin=((rr-r)//2**j)%binary
        blocks[tbin]=''.join(map(str,bits[:min(3,len(bits))]))
        ds=[]
        for i in range(j+1,K+1):
            ii,aa,uu=data(ext[:i]);D=2**ii-3**aa
            if D>0:
                # eventual descent for this residue class
                ds.append(i)
        if ds:desc_bin.add(tbin);first_exit[tbin]=min(ds)
    uncovered=[t for t in range(P) if t not in meet_t and t%binary not in desc_bin]
    # Original K=10 baseline, compare which old uncovered classes acquire descent by 13
    old_binary=2**(10-j)
    old_desc=set()
    for bits in product((0,1),repeat=10-j):
        ext=w+bits;tbin=((residue(ext)-r)//2**j)%old_binary
        if any((2**i-3**data(ext[:i])[1])>0 for i in range(j+1,11)):
            old_desc.add(tbin)
    oldP=q*old_binary
    olduncovered=[t for t in range(oldP) if t not in meet_t and t%old_binary not in old_desc]
    oldlift=set(t for t in range(P) if t%oldP in olduncovered)
    rescued=len(oldlift-set(uncovered))
    # Exact envelope pilot on finitely many n in still-uncovered cylinders, using actual y.
    # Test all time depths <= target_max; envelope is a necessary reachability bound, not sufficient.
    probes=[]; pruned=0; attempted=0; false_rejects=0; genuine_reachable=0
    for tclass in uncovered[:test_classes]:
        t=tclass+P*2
        n=r+2**j*t
        y=affine(w,n)
        U=upper_envelope(n,envelope_mod,target_max)
        reject=y>U[y%envelope_mod]
        # independently search whether some m<n reaches y in <=target_max steps
        # using exact inverse recursion (without parity catalogue)
        frontier={y}; reachable=False
        for d in range(target_max+1):
            if any(1<=m<n for m in frontier):reachable=True
            nxt=set()
            for x in frontier:
                nxt.add(2*x)
                z=2*x-1
                if z%3==0 and (z//3)%2==1 and z//3>0:
                    nxt.add(z//3)
            frontier=nxt
        attempted+=1;pruned+=reject;genuine_reachable+=reachable
        if reject and reachable:false_rejects+=1
        probes.append({'t_class':tclass,'n':n,'target':y,'envelope_reject':reject,'actual_reachable':reachable})
    assert false_rejects==0
    return {'prefix':''.join(map(str,w)),'K':K,'target_max':target_max,'ternary_mod':q,'binary_mod':binary,'combined_mod':P,'catalogue_words':len(catalog),'meeting_classes':len(meet_t),'descent_classes':len(desc_bin)*q,'union_classes':P-len(uncovered),'uncovered_classes':len(uncovered),'old_uncovered_classes':len(olduncovered),'old_uncovered_lifted':len(oldlift),'newly_resolved_by_longer_binary_prefix':rescued,'uncovered_next3':dict(Counter(blocks[t%binary] for t in uncovered)),'envelope_mod':envelope_mod,'envelope_probes':attempted,'envelope_rejects':pruned,'actual_reachable_in_probes':genuine_reachable,'false_rejects':false_rejects,'sample_probes':probes[:12]}

if __name__=='__main__':
    words=['11011','11101','1101101','111011']
    out=[run(tuple(map(int,w))) for w in words]
    path='/mnt/data/Collatz_Joint_Envelope_Adaptive_Results_2026-11-19.json'
    with open(path,'w') as f:json.dump(out,f,indent=2)
    for d in out:print({k:v for k,v in d.items() if k!='sample_probes'},flush=True)
