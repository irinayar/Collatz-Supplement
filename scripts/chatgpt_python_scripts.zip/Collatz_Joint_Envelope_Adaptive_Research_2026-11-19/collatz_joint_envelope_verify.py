import json
from itertools import product
from _prior_joint import data,residue,join
from collatz_joint_envelope_extension import run

def forward(n,steps):
    vals=[];x=n
    for _ in range(steps):
        x=(3*x+1)//2 if x%2 else x//2
        vals.append(x)
    return vals

out=json.load(open('/mnt/data/Collatz_Joint_Envelope_Adaptive_Results_2026-11-19.json'))
checks=0
for row in out:
    w=tuple(map(int,row['prefix']));j,a,u=data(w);r=residue(w)
    q=row['ternary_mod'];B=row['binary_mod'];P=q*B;K=row['K']
    catalogue=[]
    for ell in range(1,row['target_max']+1):
        for v in product((0,1),repeat=ell):
            z=join(w,v)
            if z and z['positive_slope']:catalogue.append((v,z))
    # independent trajectory check of all classes at a large positive representative
    # use the actual source orbit and the exact join origin, rather than using the descent test for the oracle
    for tc in range(P):
        t=tc+P*10000;n=r+2**j*t
        vals=forward(n,K)
        descent=any(vals[i-1]<n for i in range(j+1,K+1))
        meeting=False
        for v,z in catalogue:
            if t%z['q']==z['t0']:
                zz=(t-z['t0'])//z['q'];m=z['m0']+z['sm']*zz
                if 1<=m<n:
                    x=m
                    for b in v:
                        assert x%2==b
                        x=(3*x+1)//2 if b else x//2
                    assert x==vals[j-1]
                    meeting=True
                    break
        # Determine eventual direct-descent prediction from the actual K-bit parity cylinder.
        bits=tuple(vals[i-1]%2 for i in [])  # parity recovered directly below
        x=n; actualbits=[]
        for _ in range(K):
            actualbits.append(x%2);x=(3*x+1)//2 if x%2 else x//2
        predicted_descent=any(2**i>3**sum(actualbits[:i]) for i in range(j+1,K+1))
        assert predicted_descent==descent, (row['prefix'],tc,descent,predicted_descent)
        predicted_meeting=any(t%z['q']==z['t0'] for v,z in catalogue)
        assert meeting==predicted_meeting
        checks+=1
    print(row['prefix'],'verified',P,'combined classes')
print('TOTAL VERIFIED',checks)
