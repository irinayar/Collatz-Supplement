"""Exact finite residue check for the six-return exclusion theorem."""
from itertools import product

def F(u):
    a=3*u+1
    e=(a & -a).bit_length()-1
    return a>>e,e

def numerator(es):
    B=0; E=0; p=1
    for e in es:
        B=3*B+p
        E+=e
        p<<=e
    return B

for E in range(7,18):
    maximum=0
    for middle in product(range(1,E),repeat=4):
        last=E-1-sum(middle)
        if last<2: continue
        maximum=max(maximum,numerator((1,*middle,last)))
    assert maximum==1040*2**(E-9)+405, (E,maximum)
print('Numerator envelope checked exactly for E=7..17.')

possible=[]
for u in range(3,51,2):
    z=u; states=[u]; es=[]
    for _ in range(6):
        z,e=F(z);states.append(z);es.append(e)
    if sum(es)==10:
        possible.append((u,tuple(es),tuple(states)))
        # Every admissible n must satisfy n>=ceil((3u+2)/4), n<=u and n<=w.
        for n in range(3,u+1,2):
            H=(4*n-2)//3
            assert not (n<=u<=H and n<=z<=H and all(v>H for v in states[1:6]))
print('E=10 possible starts:',possible)
assert possible==[(39,(1,1,2,1,4,1),(39,59,89,67,101,19,29))]
for u in (3,5):
    z=u
    seq=[]
    for _ in range(6):
        z,e=F(z);seq.append((z,e))
    print('Small start',u,seq)
print('All six-transition first returns excluded by exact envelope plus finite check.')
