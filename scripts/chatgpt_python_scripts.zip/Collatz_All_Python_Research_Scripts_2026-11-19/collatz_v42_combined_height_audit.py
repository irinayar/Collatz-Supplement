"""Exact suffix-constrained height audit; no proof of universal Collatz convergence."""
from itertools import combinations
M = 2075 * 2**60
LIMIT = 1500

def numerator(bits):
    u=0
    for j,e in enumerate(bits):
        if e: u=3*u+(1<<j)
    return u

def suffix_admissible(bits):
    b=0
    for t,e in enumerate(reversed(bits),1):
        b+=e
        if (1<<t)<=3**b:return False
    return True

# Exact maxima/minima over suffix-contraction admissible words.
maxima={(0,0):0}; minima={(0,0):0}
pow3=[1]
for k in range(LIMIT):pow3.append(pow3[-1]*3)
first_survivor=None
eligible_pairs=0
for t in range(1,LIMIT+1):
    two_t=1<<t
    for b in range(min(t, (t*63093)//100000+3)+1):
        if two_t<=pow3[b]:continue
        mx=[];mn=[]
        if (t-1,b) in maxima:
            mx.append(2*maxima[t-1,b]);mn.append(2*minima[t-1,b])
        if b and (t-1,b-1) in maxima:
            mx.append(pow3[b-1]+2*maxima[t-1,b-1]);mn.append(pow3[b-1]+2*minima[t-1,b-1])
        if not mx:continue
        maxima[t,b]=max(mx);minima[t,b]=min(mn)
        if b*2>t:
            eligible_pairs+=1
            D=two_t-pow3[b]
            if maxima[t,b]>=M*D and first_survivor is None:
                first_survivor=(t,b)
    if t<=12:
        for b in range(t+1):
            nums=[]
            for ones in combinations(range(t),b):
                bits=[int(i in ones) for i in range(t)]
                if suffix_admissible(bits):nums.append(numerator(bits))
            if nums:
                assert (min(nums),max(nums))==(minima[t,b],maxima[t,b]),(t,b)
            else:assert (t,b) not in maxima,(t,b)
print('M=',M)
print('L_max=',LIMIT,'eligible (L,A) pairs=',eligible_pairs)
print('first pair surviving necessary global height test=',first_survivor)
for t,b in [(8,4),(10,5),(12,6),(15,8),(20,10)]:
    print((t,b),'min=',minima[t,b],'max=',maxima[t,b])
