from fractions import Fraction
from math import gcd,lcm
from itertools import combinations
families=[('r15',32767,2**47),('r21',2097151,2**53)]
rules=[('C61',2,3),('C83',4,9),('C84',10,81)]
def crt_pair(a,m,b,n):
 g=gcd(m,n)
 if (b-a)%g:return None
 mod=lcm(m,n); u=n//g
 k=((b-a)//g*pow(m//g,-1,u))%u if u>1 else 0
 return ((a+m*k)%mod,mod)
def density_intersect(f,subset):
 a,m=f
 for _,b,n in subset:
  z=crt_pair(a,m,b,n)
  if z is None:return Fraction(0)
  a,m=z
 return Fraction(1,m)
for name,a,m in families:
 f=(a,m);covered=Fraction(0)
 for k in range(1,len(rules)+1):
  for sub in combinations(rules,k):
   covered+=(-1)**(k+1)*density_intersect(f,sub)
 print(name,'density',Fraction(1,m),'overlap',covered,'remaining',Fraction(1,m)-covered,'relative remaining',1-covered*m)
 for rule in rules:print(' ',rule[0],density_intersect(f,[rule]))
