#!/usr/bin/env python3
"""Exact arithmetic verification of a shifted-target progression."""
def T(n):
    assert n > 0
    return n//2 if n%2==0 else (3*n+1)//2

def parity_and_endpoint(n,steps):
    bits=[]
    for _ in range(steps):
        bits.append(str(n%2)); n=T(n)
    return ''.join(bits),n

def verify(k):
    n=273+4374*k
    m=127+2048*k
    word,z=parity_and_endpoint(m,8)
    assert word=='11111110'
    assert z==4*n+1
    word2,meeting=parity_and_endpoint(z,3)
    assert word2=='100'
    assert meeting==T(n)
    assert 0<m<n
    assert 256*z==2187*m+2059
    return n,m,z,meeting

if __name__=='__main__':
    for k in range(10000): verify(k)
    print('10,000 exact progression checks passed')
    print('k=0:',verify(0))
