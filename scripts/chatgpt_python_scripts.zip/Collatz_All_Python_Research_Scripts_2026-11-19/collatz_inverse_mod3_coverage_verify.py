from fractions import Fraction
from math import gcd
S=lambda n:n//2 if n%2==0 else (3*n+1)//2

def binary_covered(n):
    if n%2==0 or n%4==1 or n%16==3 or n%32 in (11,23):return True
    q=n
    while q%2: q=S(q)
    if q%2==0:
        q//=2
        return q%2==0 # parity prefix 1^k 00, k>=1
    return False

# Independent definition of 1^k00 membership by parity iteration.
def binary_union(n):
    if n%2==0 or n%4==1 or n%16==3 or n%32 in (11,23):return True
    x=n
    while x%2==1: x=S(x)
    return S(x)%2==0

oldclasses=((91,93312),(1275,1296),(273,4374),(121,162))
def old_union(n):return binary_union(n) or any(n%mod==res for res,mod in oldclasses)

N=279936*8
new=old=extra=c53extra=0
for n in range(1,N+1):
    o=old_union(n)
    old+=o
    add=(n%3==2)
    new+=o or add
    extra+=add and not o
    if n%354294==94109 and not (o or add): c53extra+=1
    if n%3==2 and n>1:
        m=(2*n-1)//3
        assert 0<m<n and S(m)==n
assert c53extra==0
old_density=Fraction(84713,93312)
new_density=old_density+Fraction(1,32)
print('N',N,'old count',old,'new count',new,'marginal count',extra)
print('reported old exact density',old_density)
print('new exact density',new_density,'=',float(new_density)*100,'%')
print('marginal exact',Fraction(1,32),'empirical',extra/N)
print('C53 extra after mod3 rule',c53extra)
