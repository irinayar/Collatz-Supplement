"""Verify an exact obstruction to uniform finite-horizon descent/even-entry meeting.
Python 3 standard library. Not a proof of Collatz convergence.
"""
def S(x):
    return x//2 if x%2==0 else (3*x+1)//2

def verify(r):
    n=(1<<r)-1
    x=n
    for j in range(r+1):
        assert x==3**j * 2**(r-j)-1
        if j:
            assert x>n
        if j<r:
            assert x&1==1
            x=S(x)
    e=(x & -x).bit_length()-1
    assert e == (1 if r%2 else 2+((r & -r).bit_length()-1))
    z=x
    for _ in range(e):
        assert z%2==0
        z=S(z)
    assert z==(3**r-1)//(2**e)
    return n,x

if __name__=='__main__':
    for r in range(2,101):
        verify(r)
    for H in (8,14,27,100,1000):
        r=H+1
        n,x=verify(r)
        print('H=',H,'r=',r,'bit_length(n)=',n.bit_length(),
              'no descent or even-entry event through H')
    print('PASS: exact symbolic identity plus integer verification')
