"""Exact checks of 3-adic suffix reduction for Collatz target words."""
from itertools import product

def affine(word):
    u=0; b=0
    for i,c in enumerate(word):
        if c=='1':
            u=3*u+2**i
            b+=1
    return u,b

def suffix_numerator(word,a):
    pos=[i for i,c in enumerate(word) if c=='1']
    return sum(2**i*3**(len(pos)-j-1) for j,i in enumerate(pos[-a:],start=len(pos)-a))

total=0
for ell in range(8,17):
    for bits in product('01',repeat=ell-1):
        w='1'+''.join(bits)
        u,b=affine(w)
        if b<=7:continue
        mod=3**7
        assert (u-suffix_numerator(w,7))%mod==0
        # For last odd at i, trailing zeros q=ell-1-i, endpoint modulo 3 is 2^(i-ell).
        q=ell-1-w.rindex('1')
        assert (u*pow(2,-ell,3))%3 == (2 if q%2==0 else 1)
        total+=1
print('Verified suffix and terminal mod-3 identities for',total,'target words')

# Demonstrate exact 3-adic obstruction for y=577 and all odd-count >=8 words.
y=577; a=7
for ell in range(8,17):
    for bits in product('01',repeat=ell-1):
        w='1'+''.join(bits);u,b=affine(w)
        if b<=a:continue
        compatible=(2**ell*y-u)%(3**a)==0
        compatible_suffix=(2**ell*y-suffix_numerator(w,a))%(3**a)==0
        assert compatible==compatible_suffix
print('Verified compatibility decisions for y=577, a=7')
