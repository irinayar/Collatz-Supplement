from fractions import Fraction
from collections import Counter

def S(x): return x//2 if x%2==0 else (3*x+1)//2

def analyze(n,T=14):
 x=n; run=0; seen=[]; first=None
 for j in range(1,T+1):
  parity=x%2; run=run+1 if parity else 0
  x=S(x); h=Fraction(x,n)
  kind=('descent' if x<n else 'good' if (not parity and x%3==2 and 2*x<=3*n) else 'four' if run>=4 else 'high' if (not parity and x%3==2) else 'other')
  seen.append((j,x,parity,run,kind))
  if kind in ('descent','good','four'):
   first=(j,kind,x);break
 return first,seen

N=200000
counts=Counter(); examples={}; unresolved=[]
for n in range(32,N+1):
 first,seen=analyze(n)
 label=first[1] if first else 'unresolved'
 counts[label]+=1
 examples.setdefault(label,(n,first,seen))
 if not first: unresolved.append(n)
print('counts',counts,'examples',[(k,v[0],v[1]) for k,v in examples.items()]);print('unresolved first',unresolved[:20]);
for n in [4064460795,18839651253368551,411,103,539]:
 first,seen=analyze(n,70)
 print('start',n,'first',first,'high-even-visits',[(j,x,float(Fraction(x,n))) for j,x,p,r,k in seen if k=='high'][:10])
