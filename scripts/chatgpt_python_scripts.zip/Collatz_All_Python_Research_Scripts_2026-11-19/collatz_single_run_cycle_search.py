"""Exact single-run positive Collatz cycle search; no universal claim."""
from fractions import Fraction
MAX_R=5000
eligible=[]
smallest=[]
for r in range(1,MAX_R+1):
    p=pow(3,r)
    s=max(1,p.bit_length()-r)
    if (1 << (r+s))<=p: s+=1
    # Larger s only increase D and cannot improve positive k.
    D=(1 << (r+s))-p
    numer=(1 << s)-1
    if D<=numer:
        eligible.append((r,s,D,numer,numer%D))
    if r>1:
        smallest.append((Fraction(D,numer),r,s))
print('r range:',1,MAX_R)
print('possible positive integer k for any s:',len(eligible))
print('eligible cases (r,s,D,2^s-1,remainder):',eligible)
print('five smallest D/(2^s-1), r>=2:',[(r,s,str(frac),float(frac)) for frac,r,s in sorted(smallest)[:5]])
# Check the known cycle r=s=1.
assert eligible == [(1,1,1,1,0)]
print('PASS: no nontrivial single-run cycles for r <=',MAX_R)
