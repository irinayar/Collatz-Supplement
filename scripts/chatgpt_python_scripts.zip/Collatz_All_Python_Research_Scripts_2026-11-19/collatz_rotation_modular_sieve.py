"""Exact modular sieve for fixed (L,A,k,h) accelerated Collatz parity words.
No statistical or Collatz-convergence assumptions.
"""
from collections import Counter, defaultdict
from math import comb

def signature(bits):
    L=len(bits); A=sum(bits)
    if A in (0,L): return None
    runs=[]
    for i in range(L):
        if bits[i] and not bits[(i-1)%L]:
            r=0
            while bits[(i+r)%L]:r+=1
            runs.append(r)
    return A,len(runs),sum(r>=2 for r in runs)

def numerator(bits):
    U=0
    for i,b in enumerate(bits):
        if b: U=3*U+(1<<i)
    return U

def count(L,A,k,h):
    if not (1<=k<=min(A,L-A) and 0<=h<=k):return 0
    odd=(int(A==k) if h==0 else comb(k,h)*comb(A-k-1,h-1) if A>=k+h else 0)
    return L*odd*comb(L-A-1,k-1)//k

def sieve(L,A,k,h,q):
    D=(1<<L)-3**A
    assert D>0 and D%q==0 and q>1
    residue_counts=Counter()
    words=[]
    for mask in range(1,(1<<L)-1):
        bits=[(mask>>i)&1 for i in range(L)]
        if signature(bits)!=(A,k,h):continue
        u=numerator(bits)
        residue_counts[u%q]+=1
        words.append((''.join(map(str,bits)),u))
    assert len(words)==count(L,A,k,h)
    return residue_counts,words

def rotations(s):return [s[i:]+s[:i] for i in range(len(s))]

if __name__=='__main__':
    L,A,k,h,q=8,4,2,1,5
    counts,words=sieve(L,A,k,h,q)
    reps={min(rotations(s)) for s,_ in words}
    assert len(words)==24 and 0 not in counts and len(reps)==3
    assert sorted(reps)==['00010111','00011101','00100111']
    print('Class', (L,A,k,h),'D=',2**L-3**A,'q=',q)
    print('Indexed words:',len(words),'residues:',dict(sorted(counts.items())))
    for s in sorted(reps):print('Representative:',s,'U=',numerator(list(map(int,s))))
    # For any left rotation b0,... -> b1,...,b0:
    # 2 U(rotated) = 3^b0 U(original) + b0 D,
    # so U==0 mod q is invariant under rotation for odd q|D.
    for s,u in words:
        b0=int(s[0]);rot=s[1:]+s[0]
        ur=numerator(list(map(int,rot)))
        assert 2*ur==3**b0*u+b0*(2**L-3**A)
    print('All exact checks passed.')
