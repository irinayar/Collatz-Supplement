from fractions import Fraction
from math import log

def first_run(x):
    assert x>0 and x%2
    c=x; r=s=0
    while x%2:
        x=(3*x+1)//2; r+=1
    while x%2==0:
        x//=2; s+=1
    return r,s,x

checked=0
for c in range(1,100000,2):
    r,s,z=first_run(c)
    g=z-c
    E=3**r-2**(r+s)
    assert 2**(r+s)*(z+Fraction(1,2**s))==3**r*(c+1)
    assert 2**s*g==E*((c+1)//2**r)+2**s-1
    if g>0:
        assert E>0
        assert Fraction(g-1,1)+Fraction(1,2**s)==Fraction(E*(c+1),2**(r+s))
        assert 0 < log(Fraction(3**r,2**(r+s))) < g/(c+1)
    checked+=1
print('Checked',checked,'odd starting values; all exact identities and growth bounds passed')
print('Example c=7:',first_run(7))
