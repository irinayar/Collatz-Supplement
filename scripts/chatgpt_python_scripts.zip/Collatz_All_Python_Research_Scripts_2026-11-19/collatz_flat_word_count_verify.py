from fractions import Fraction
from math import comb

def composition_count(L):
    # sequences of k pairs (r>=2,d>=1), total length L
    return sum(comb(L-k-1,2*k-1) for k in range(1,L//3+1))

def brute_cyclic_no_single_ones(L):
    count=0
    for w in range(1<<L):
        if w==0 or w==(1<<L)-1: continue
        if all(not ((w>>i)&1 and not ((w>>((i-1)%L))&1) and not ((w>>((i+1)%L))&1)) for i in range(L)):
            count+=1
    return count

for L in range(3,19):
    n=brute_cyclic_no_single_ones(L)
    marked=L*composition_count(L)
    assert n<=marked, (L,n,marked)
    # F(9/16) = 729/784; 1/(1-F) = 784/55
    assert Fraction(marked,1) <= Fraction(784*L,55)*Fraction(16,9)**L
    print(L,n,marked)
print('All checks passed')
