#!/usr/bin/env python3
"""Exact seam-aware block DP for accelerated Collatz parity-word numerators.
Run-boundary anchored words: start with 1, end with 0; no cyclic seam ambiguity.
No approximate pruning; supports a composite modulus for correlated prime-power tests.
"""
from collections import defaultdict
from math import comb

def dp(L,A,k,h,q):
    # states: (length,odd_count,run_count,long_run_count,numerator_mod_q) -> multiplicity
    states={(0,0,0,0,0):1}
    for _ in range(k):
        nxt=defaultdict(int)
        for (ell,a,runs,long,u),mult in states.items():
            remaining=k-runs-1
            for r in range(1,A-a-remaining+1):
                if long+(r>=2)>h: continue
                for d in range(1,L-ell-r-remaining*2+1):
                    ee=ell+r+d; aa=a+r
                    if ee>L or aa>A:continue
                    # append r odd steps, then d even steps
                    v=u
                    for j in range(ell,ell+r): v=(3*v+pow(2,j,q))%q
                    nxt[(ee,aa,runs+1,long+(r>=2),v)]+=mult
        states=nxt
    out=defaultdict(int)
    for (ell,a,runs,long,u),mult in states.items():
        if (ell,a,runs,long)==(L,A,k,h):out[u]+=mult
    return dict(out)

def brute(L,A,k,h,q):
    out=defaultdict(int)
    def rec(word,a,runs,long):
        if runs==k:
            if len(word)==L and a==A and long==h:
                u=0
                for i,b in enumerate(word):
                    if b:u=3*u+(1<<i)
                out[u%q]+=1
            return
        for r in range(1,A-a+1):
            for d in range(1,L-len(word)-r+1):
                if len(word)+r+d+2*(k-runs-1)>L:continue
                rec(word+[1]*r+[0]*d,a+r,runs+1,long+(r>=2))
    rec([],0,0,0)
    return dict(out)

def count_formula_anchored(L,A,k,h):
    if not (1<=k<=min(A,L-A) and 0<=h<=k):return 0
    if h==0:return comb(L-A-1,k-1) if A==k else 0
    if A<k+h:return 0
    return comb(k,h)*comb(A-k-1,h-1)*comb(L-A-1,k-1)

def run_tests():
    checks=0
    for L in range(3,15):
      for A in range(1,L):
       for k in range(1,min(A,L-A)+1):
        for h in range(k+1):
         q=25
         v=dp(L,A,k,h,q)
         assert sum(v.values())==count_formula_anchored(L,A,k,h),(L,A,k,h,v)
         assert v==brute(L,A,k,h,q),(L,A,k,h,v,brute(L,A,k,h,q))
         checks+=1
    print('PASS exact DP / independent composition enumeration / closed count:',checks,'signatures through L=14')
    for sig in [(8,4,2,1),(8,4,2,2),(12,7,3,2),(16,9,3,3),(20,12,4,4)]:
        L,A,k,h=sig;D=(1<<L)-3**A
        if D<=0:continue
        from sympy import factorint
        factors=factorint(D)
        mod=1
        for p,e in factors.items():mod*=p**e
        # Avoid large D-state explosion; calculate selected small prime powers, correlated in one modulus
        q=1
        for p,e in factors.items():
            if p<=13:q*=p**e
        if q==1:q=min(D,101)
        residues=dp(*sig,q)
        print('signature',sig,'D=',D,'small-prime-power modulus',q,'anchored words',sum(residues.values()),'passing',residues.get(0,0))
if __name__=='__main__':run_tests()
