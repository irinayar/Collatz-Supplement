#!/usr/bin/env python3
"""Exact verification of n=539+2048k, m=455+1728k."""
def S(n):
    return (3*n+1)//2 if n&1 else n//2

def path(n,steps):
    a=[n]
    for _ in range(steps):a.append(S(a[-1]))
    return a

n0,m0=539,455
pn=path(n0,11);pm=path(m0,6)
wn=''.join(str(x&1) for x in pn[:-1]);wm=''.join(str(x&1) for x in pm[:-1])
assert wn=='11011111000' and wm=='111010'
assert pn[-1]==pm[-1]==577
assert min(pn)>=n0
for j in range(12):
    a=wn[:j].count('1')
    assert 3**a>=2**j, (j,a)
assert 3**7==2187
assert 2**6*3**(7-4)==1728
assert 1728<2048 and 0<m0<n0
for k in range(10000):
    n=539+2048*k;m=455+1728*k
    x=path(n,11);y=path(m,6)
    assert x[-1]==y[-1]==577+2187*k
    assert ''.join(str(z&1) for z in x[:-1])==wn
    assert ''.join(str(z&1) for z in y[:-1])==wm
    assert min(x)>=n and 0<m<n
print('PASS: 10,000 exact trajectory replays; infinite family follows from affine identities')
print('candidate:',wn,'target:',wm)
print('base candidate states:',pn)
print('base target states:',pm)
