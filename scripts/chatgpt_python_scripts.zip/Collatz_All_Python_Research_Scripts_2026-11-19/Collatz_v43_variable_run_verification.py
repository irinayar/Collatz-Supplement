#!/usr/bin/env python3
"""Exact variable expanding-run parity cylinders (standard accelerated Collatz)."""
from fractions import Fraction

def affine(word):
    a=u=0
    for j,bit in enumerate(word):
        if bit=='1':
            u=3*u+(1<<j)
            a+=1
    return a,u

def cylinder(word):
    L=len(word); a,u=affine(word); modulus=1<<L
    r=(-u*pow(pow(3,a,modulus),-1,modulus))%modulus
    x=r if r else modulus
    y=(3**a*x+u)//modulus
    assert (3**a*x+u)%modulus==0
    z=x
    for bit in word:
        assert z%2==int(bit)
        z=(3*z+1)//2 if z%2 else z//2
    assert z==y
    return x,y,a,u

def thue_morse(k): return (k.bit_count()&1)

if __name__=='__main__':
    blocks=('110','1110')
    for n in (1,2,3,4,5,6,8,10,12,16,20,24,32):
        word=''.join(blocks[thue_morse(i)] for i in range(n))
        x,y,a,u=cylinder(word)
        z=x
        for i in range(n):
            previous=z
            block=blocks[thue_morse(i)]
            for bit in block:
                z=(3*z+1)//2 if bit=='1' else z//2
            assert z>previous
        print(f'{n:2d} blocks, {len(word):3d} steps, {a:3d} odd, min_start={x}, end={y}, growth={Fraction(y,x)}')
    # Each fixed positive integer cannot realize a fixed repeated expanding block forever.
    for k in range(1,12):
        w='110'*k
        x,y,_,_=cylinder(w)
        assert x==(8**k-5)
        assert y==(9**k-5)
    print('All exact parity and affine checks passed.')
