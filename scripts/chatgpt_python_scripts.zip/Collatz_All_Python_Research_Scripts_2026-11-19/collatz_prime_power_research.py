from collections import defaultdict
from math import gcd

def calc(bits):
 L=len(bits); A=sum(bits); U=0
 for i,b in enumerate(bits):
  if b: U=3*U+(1<<i)
 return (1<<L)-3**A,U

def signature(bits):
 L=len(bits); A=sum(bits); runs=[]
 for i in range(L):
  if bits[i] and not bits[i-1]:
   j=i; r=0
   while bits[j%L]:r+=1;j+=1
   runs.append(r)
 return (L,A,len(runs),sum(r>=2 for r in runs))

def primitive(bits):
 L=len(bits)
 return all(bits != bits[:d]*(L//d) for d in range(1,L) if L%d==0)

examples=[]; summary=defaultdict(lambda:[0,0,0]); checked=0
for L in range(4,17):
 for mask in range(1,(1<<L)-1):
  bits=tuple((mask>>i)&1 for i in range(L));A=sum(bits)
  if 3**A >= 2**L or not primitive(bits):continue
  D,U=calc(bits); sig=signature(bits); checked+=1
  if D%25==0:
   summary[sig][0]+=1
   if U%5==0:
    summary[sig][1]+=1
    if U%25==0:summary[sig][2]+=1
    elif len(examples)<8: examples.append((sig,''.join(map(str,bits)),D,U,U%25))
print('checked',checked,'examples',examples)
print('classes 5 survivors but no25',[(k,v) for k,v in summary.items() if v[1] and not v[2]][:12])

# Exact assertions for the new prime-power obstruction.
for word, expected in [('11110000',65),('11011000',85)]:
 bits=tuple(map(int,word));D,U=calc(bits)
 assert D==175 and U==expected and U%5==0 and U%25!=0
 for i in range(8):
  rot=bits[i:]+bits[:i]
  Dr,Ur=calc(rot)
  assert Dr==D and (Ur%25!=0) and (Ur%5==0)
# Every primitive cyclic word with (8,4,1,1) or (8,4,2,2) fails 25|U.
for mask in range(256):
 bits=tuple((mask>>i)&1 for i in range(8))
 if sum(bits)==4 and primitive(bits) and signature(bits) in [(8,4,1,1),(8,4,2,2)]:
  D,U=calc(bits)
  assert D==175 and U%25!=0
print('All prime-power class assertions passed.')
