from math import comb
from collections import Counter

def C(n,r): return comb(n,r) if 0<=r<=n else 0

def count(L,A,k,h):
    if not (1<=k<=min(A,L-A) and 0<=h<=k): return 0
    odd = (1 if A==k else 0) if h==0 else C(k,h)*C(A-k-1,h-1)
    return L*odd*C(L-A-1,k-1)//k

def signature(bits):
    L=len(bits); A=sum(bits)
    if A==0 or A==L:return None
    runs=[]
    for i in range(L):
        if bits[i] and not bits[(i-1)%L]:
            r=0
            while bits[(i+r)%L]:r+=1
            runs.append(r)
    return A,len(runs),sum(r>=2 for r in runs)

def U_of(bits):
    U=0
    for i,b in enumerate(bits):
        if b: U=3*U+(1<<i)
    return U

if __name__=='__main__':
    for L in range(3,17):
        got=Counter(); eligible=0; integer=0
        for mask in range(1,(1<<L)-1):
            bits=[(mask>>i)&1 for i in range(L)]
            A,k,h=signature(bits);got[A,k,h]+=1
            D=(1<<L)-3**A
            if D>0:
                eligible+=1
                if U_of(bits)%D==0:integer+=1
        for A in range(1,L):
            for k in range(1,min(A,L-A)+1):
                for h in range(k+1):
                    assert got[A,k,h]==count(L,A,k,h),(L,A,k,h,got[A,k,h],count(L,A,k,h))
        print(f'L={L}: {sum(got.values())} mixed words, {eligible} growth-eligible, {integer} integer fixed-point words')
    print('All exact combinatorial comparisons passed.')
