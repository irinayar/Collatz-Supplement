"""Exact reproduction of the height-sensitive 14-step exception continuation.
Python 3, standard library only. Does not prove universal convergence.
"""
from collections import Counter

def S(x):
    return x // 2 if x % 2 == 0 else (3*x+1)//2

def first_event_14(n):
    x=n; run=0
    for j in range(1,15):
        p=x&1
        run=run+1 if p else 0
        x=S(x)
        if x<n: return ('descent',j)
        if not p and x%3==2 and 2*x<=3*n: return ('good',j)
        if run>=4: return ('four',j)
    return ('none',14)

def first_strong_certificate(n,limit=200):
    x=n
    for j in range(1,limit+1):
        p=x&1
        x=S(x)
        if x<n: return ('descent',j,x,None)
        if not p and x%3==2 and 2*x<=3*n:
            m=(2*x-1)//3
            assert 0<m<n and m%2==1 and S(m)==x
            return ('good',j,x,m)
    return ('none',limit,x,None)

def main():
    early=Counter(); continued=Counter(); all_strong=Counter()
    latest=(-1,None,None)
    for n in range(32,200001):
        label,j=first_event_14(n)
        early[label]+=1
        kind,step,x,m=first_strong_certificate(n)
        all_strong[kind]+=1
        assert kind!='none',n
        if label=='none':
            continued[kind]+=1
            if step>latest[0]:latest=(step,n,kind)
    print('14-step event counts:',dict(early))
    print('726 previously unresolved, extended:',dict(continued))
    print('All starts strong certificate by 200:',dict(all_strong))
    print('Latest certificate among 726:',latest)
    assert early==Counter({'descent':182586,'four':15634,'good':1023,'none':726})
    assert continued==Counter({'descent':538,'good':188})
    assert all_strong==Counter({'descent':191336,'good':8633})
    assert latest==(135,35655,'descent')
    print('PASS')
if __name__=='__main__':main()
