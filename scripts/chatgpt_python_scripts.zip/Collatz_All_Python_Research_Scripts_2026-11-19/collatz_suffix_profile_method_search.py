from collections import defaultdict
from math import gcd
L,r,a,y0=11,539,7,577
stats=defaultdict(int); profiles=defaultdict(set); examples={}
def S(n):return (3*n+1)//2 if n&1 else n//2
def check(word,m):
 x=m
 for z in word:
  if str(x&1)!=z:return False
  x=S(x)
 return True
for ell in range(9,19):
 for z in range(1<<(ell-1)):
  word='1'+format(z,'0'+str(ell-1)+'b')
  b=word.count('1');d=b-a
  if not 1<=d<=4:continue
  stats['total']+=1
  if word[-1]!='0' or (len(word)-len(word.rstrip('0')))%2==0:continue
  stats['terminal']+=1
  if 2**ell>=2**L*3**d:continue
  stats['slope']+=1
  U=0;odd=0
  for i,ch in enumerate(word):
   if ch=='1':U=3*U+2**i;odd+=1
  C=2**ell*y0-U
  if C%3**a:continue
  stats['compatible']+=1
  k0=(-pow(2**ell,-1,3**d)*(C//3**a))%(3**d)
  m0=(2**ell*(y0+3**a*k0)-U)//3**b
  n0=r+2**L*k0
  if m0<=0 or m0>=n0 or not check(word,m0):continue
  stats['valid']+=1
  profiles[d].add(k0)
  examples.setdefault(d,(word,k0,n0,m0,ell,b))
print(dict(stats));print('residue counts', {d:len(v) for d,v in profiles.items()});print('examples',examples)
covered=set()
for d,vals in profiles.items():
 for k in vals:
  covered.update(range(k,81,3**d))
print('union mod81',len(covered),'missing',81-len(covered))
