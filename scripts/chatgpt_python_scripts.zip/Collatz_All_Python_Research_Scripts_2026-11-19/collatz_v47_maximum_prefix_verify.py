#!/usr/bin/env python3
"""Exact verification of maximum-prefix coefficient necessity; no Collatz proof."""
from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def prefix(n, depth):
    a=0; U=0; x=n
    for j in range(1,depth+1):
        odd=x&1
        if odd: U=3*U+2**(j-1); a+=1
        x=T(x)
        assert x*2**j==3**a*n+U
        yield j,a,U,x

# The trivial accelerated cycle provides a full-cycle regression check.
for j,a,U,x in prefix(2,12):
    assert 2**j>3**a
    assert x<=2

# For arbitrary candidate maxima, every observed failure of the coefficient
# restriction must coincide with an actual excursion above the candidate.
tested=0
for H in range(2,10002,2):
    for j,a,U,x in prefix(H,24):
        if 2**j<=3**a: assert x>H
        tested+=1
print('Checked exact affine identities and maximum-prefix implications:',tested)
print('Trivial cycle 2 -> 1 -> 2 passes all 12 prefix tests.')
