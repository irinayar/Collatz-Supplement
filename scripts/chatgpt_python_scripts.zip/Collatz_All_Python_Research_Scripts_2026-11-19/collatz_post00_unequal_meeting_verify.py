"""Exact replay of post-00 unequal-word meeting family, no external packages."""
from fractions import Fraction
S=lambda n:(3*n+1)//2 if n%2 else n//2
N0=18265851; M0=13003717
DN=2048*3**14; DM=1458*3**14
word='11011011100'
for t in list(range(1000))+[10**6,10**12]:
 n=N0+DN*t; m=M0+DM*t
 assert n% (3**9)==27
 assert (n-3149307)%5038848==0
 assert 0<m<n
 x=n
 for i,bit in enumerate(word):
  assert x%2==int(bit),(t,i,x)
  assert x>=n,(t,i,x)
  x=S(x)
 assert x==S(m),(t,x,S(m))
 assert m%2==1
 assert x>=n
 if t==0:
  assert x==19505576
  assert S(x)<n
print('PASS: 1002 parameters, full candidate parity, no descent through meeting, exact meeting, smaller origin')
print('candidate increment',DN,'target increment',DM)
# Stronger whole-binary-cylinder identity, which contains the residual-27 subfamily.
for k in list(range(10000))+[10**8,10**15]:
 n=1787+2048*k; m=1273+1458*k
 assert 0<m<n and m%2
 x=n
 for j,bit in enumerate(word):
  assert x%2==int(bit)
  assert x>=n
  x=S(x)
 assert x==S(m)
print('PASS: 10002 whole-binary-cylinder parameters, all eleven parities and pre-descent meeting')
