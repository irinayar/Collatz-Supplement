"""Exact verification of canonical odd-run shifted-target certificates."""
def T(n):
    assert n > 0
    return (3*n+1)//2 if n&1 else n//2

def check(b,q):
    assert b >= 4 and q > 0 and q%2 == 1
    assert (pow(3,b,4)*q)%4 == 3
    n=(3**b*q-1)//2
    m=2**(b+1)*q-1
    assert 0<m<n and n%2 == 1
    x=m
    for _ in range(b):
        assert x%2 == 1
        x=T(x)
    assert x==4*n+1
    assert x%2 == 1
    x=T(x)
    assert x%4 == 0
    x=T(T(x))
    assert x==T(n)
    return n,m

if __name__ == '__main__':
    count=0
    for b in range(4,61):
        for q in range(1,200,2):
            if (pow(3,b,4)*q)%4==3:
                check(b,q)
                count+=1
    print('verified',count,'parameter pairs')
    for b,q in [(4,3),(5,1),(6,3),(7,1)]:
        print(b,q,check(b,q))
