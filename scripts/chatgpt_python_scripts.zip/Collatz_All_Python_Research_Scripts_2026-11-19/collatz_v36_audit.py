"""Exact arithmetic audit for Collatz manuscript v36."""
M=2075*2**60
power3=1
H=0
survivors=[]
for a in range(1,20001):
    H=3*H+(1<<(power3.bit_length()-1))
    power3*=3
    j=power3.bit_length()
    D=(1<<j)-power3
    if H>=D*M:
        survivors.append((a,j))
assert j==31700
assert not survivors, survivors[:5]

def numerator(word):
    a=0; A=0
    for i,b in enumerate(word):
        if b=='1':
            A=3*A+(1<<i);a+=1
    return A,a
w='11001010'
assert len(w)==8 and numerator(w)[1]==4
assert all(w!=w[:d]*(len(w)//d) for d in [1,2,4])
assert numerator(w[:4])[1]==2
assert 4*4-8*2==0
print('PASS: 20,000 first-crossing tests, last j=31,700; primitive zero-determinant example')
