import json,sys
from fractions import Fraction as F
from math import gcd
from functools import lru_cache
from pathlib import Path
root=Path('/mnt/data/crt_inputs')
data=json.loads((root/'data/counting_inventory.json').read_text())
classes=[(x['residue'],x['modulus']) for x in data['finite_ledger']]
families=json.loads((root/'data/requested_lifted_families.json').read_text())['families']
certs=json.loads((root/'tmp/higher_entry_resume/parent27_certificates.json').read_text())['certificates']
def crt(z,w):
 a,m=z;b,n=w;g=gcd(m,n)
 if (a-b)%g:return None
 v=n//g;t=((b-a)//g*pow(m//g,-1,v))%v if v>1 else 0
 return ((a+m*t)%(m*v),m*v)
terms={}
for z in classes:
 z=(z[0]%z[1],z[1]); delta={z:1}
 for p,c in list(terms.items()):
  w=crt(z,p)
  if w:delta[w]=delta.get(w,0)-c
 for p,c in delta.items():terms[p]=terms.get(p,0)+c
 terms={p:c for p,c in terms.items() if c}
@lru_cache(None)
def suffix(j,a,T):
 if j==T:return 1
 return sum(suffix(j+1,a+b,T) for b in (0,1) if 3**(a+b)>=2**(j+1))
@lru_cache(None)
def survivor(z,T):
 r,m=z;L=(m&-m).bit_length()-1;x=r;a=0
 for j in range(1,min(L,T)+1):
  b=x&1;a+=b;x=(3*x+1)//2 if b else x//2
  if 3**a<2**j:return F(0)
 return F(1,m) if L>=T else F(suffix(L,a,T),m*2**(T-L))
def measure(z):return F(1,z[1])
def residual(z,f):
 v=f(z)
 for p,c in terms.items():
  w=crt(z,p)
  if w:v-=c*f(w)
 return v
def cylinder(k):
 m=2**(k+2)
 return ((-(3**k-2**k)*pow(3**k,-1,m))%m,m)
def outside_C08(z,f,J):
 v=residual(z,f)
 for k in range(1,J):
  w=crt(z,cylinder(k))
  if w:v-=residual(w,f)
 w=crt(z,(2**J-1,2**J))
 if w:v-=residual(w,f)/2
 return v
def result(z,T):
 f=measure if T is None else lambda w:survivor(w,T)
 J=max(17,(z[1]&-z[1]).bit_length()-1, T or 0)
 out=outside_C08(z,f,J)
 if T is not None:
  sub=F()
  for c in certs:
   if c['meeting'] is None:continue
   w=crt(z,(c['n'],2**27))
   if w:sub+=residual(w,f)
  out-=sub
 return out
rows=[]
for fam in families:
 z=(fam['n0'],fam['P']);v=[result(z,T) for T in (None,32,100)]
 rows.append((fam['label'],z,v))
 print(fam['label'], 'base',F(1,z[1]), 'marginals',*[str(x) for x in v],flush=True)
for T in (None,32,100):
 a=rows[0][1];b=rows[1][1];w=crt(a,b)
 overlap=result(w,T) if w else F(0)
 union=rows[0][2][(None,32,100).index(T)]+rows[1][2][(None,32,100).index(T)]-overlap
 print('T',T,'intersection',w,'overlap',overlap,'union',union,flush=True)
