from collections import defaultdict
S=lambda n:(3*n+1)//2 if n%2 else n//2
r,L=539,11
y=r; w=''; pref=[]
for j in range(L):
 w+=str(y%2);y=S(y);pref.append(y)
a=w.count('1');print('candidate',r,w,a,y,'no descent',min(pref)>=r)
# enumerate all parity words length ell by inverse affine numerators (for every word U)
# U_{w0}=U_w; U_{w1}=3 U_w + 2^ell
hits=defaultdict(dict); stats=defaultdict(lambda:[0,0,0])
for ell in range(1,23):
 words=[('',0,0)]
 for j in range(ell):
  words=[(w+'0',u,b) for w,u,b in words]+[(w+'1',3*u+2**j,b+1) for w,u,b in words]
  if j==0:words=[z for z in words if z[0]=='1']
 for v,U,b in words:
  if b<=a:continue
  d=b-a
  if d>4 or 2**ell>=2**L*3**d:continue
  stats[d][0]+=1
  C=2**ell*y-U
  if C%3**a:continue
  stats[d][1]+=1
  mod=3**d
  k0=(-C//3**a * pow(2**ell,-1,mod))%mod
  n0=r+2**L*k0
  m0=(2**ell*(y+3**a*k0)-U)//3**b
  # existence of sufficiently large positive m with m<n, target word automatically if integer and positive
  t=max(0,(-m0)//2**ell+1)
  n=n0+2**L*mod*t;m=m0+2**ell*t
  if m<=0 or m>=n:continue
  # verify target word, candidate and endpoint
  z=m;vv=''
  for j in range(ell):vv+=str(z%2);z=S(z)
  if vv!=v or z!=y+3**a*(k0+mod*t):raise Exception('mismatch')
  stats[d][2]+=1
  hits[d].setdefault(k0,(v,ell,b,n,m,t))
 if ell in (12,14,16,18,20,22):print('ell',ell,'hits',[(d,len(h)) for d,h in hits.items()])
print('stats',dict(stats))
for d in sorted(hits):
 print('d',d,'covered',len(hits[d]),'/',3**d,'missing',sorted(set(range(3**d))-set(hits[d]))[:50]);print('samples',list(hits[d].items())[:8])
