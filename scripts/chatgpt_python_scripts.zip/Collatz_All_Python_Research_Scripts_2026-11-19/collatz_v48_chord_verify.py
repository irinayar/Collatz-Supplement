"""Exact chord-crossing tests for accelerated Collatz transitions."""
def T(n): return n//2 if n%2==0 else (3*n+1)//2
def crosses(a,b,c,d):
    if len({a,b,c,d})<4: return False
    l,r=sorted((a,b)); u,v=sorted((c,d))
    return (l<u<r<v) or (u<l<v<r)

def same_odd(a,b):
    assert a<b and a%2==b%2==1
    return b<T(a) and len({a,T(a),b,T(b)})==4

def same_even(a,b):
    assert a<b and a%2==b%2==0
    return b<2*a and len({a,T(a),b,T(b)})==4

odd_count=even_count=0
for a in range(1,301):
    for b in range(a+1,301):
        if a%2 and b%2:
            assert crosses(a,T(a),b,T(b))==same_odd(a,b)
            odd_count+=1
        if not a%2 and not b%2:
            assert crosses(a,T(a),b,T(b))==same_even(a,b)
            even_count+=1
print('Verified odd pairs:',odd_count,'even pairs:',even_count)
print('Example odd crossing: 7->11 and 9->14:',crosses(7,11,9,14))
print('Example even crossing: 10->5 and 14->7:',crosses(10,5,14,7))
