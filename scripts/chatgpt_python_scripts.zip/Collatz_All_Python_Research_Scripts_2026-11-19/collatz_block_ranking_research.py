from fractions import Fraction

def S(x): return x//2 if x%2==0 else (3*x+1)//2

def v2(x):
 e=0
 while x%2==0: x//=2;e+=1
 return e

# Test exact complete first block for n=2^r-1.
for r in range(2,301):
 n=(1<<r)-1;x=n
 for j in range(r):
  assert x%2==1
  x=S(x)
 assert x==3**r-1
 e=v2(x)
 assert e==(1 if r%2 else 2+v2(r))
 for j in range(e):
  assert x%2==0
  x=S(x)
 assert x==(3**r-1)//2**e
 if r>=10:
  assert x>3*n//2 and 2*x>3*n
  assert x>n
 print(r,e, 'D' if x<n else 'high',x) if r<=16 else None
print('Verified 2<=r<=300; all r>=10 exit above 3n/2.')
