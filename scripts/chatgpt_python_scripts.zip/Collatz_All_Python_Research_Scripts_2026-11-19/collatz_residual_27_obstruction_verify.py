"""Exact checks supporting a finite-shift, whole-cylinder all-odd-target obstruction."""
from fractions import Fraction
W='1101101'
def S(x): return (3*x+1)//2 if x&1 else x//2

def residue_crt():
    return next(n for n in range(128*19683) if n%19683==27 and ''.join(str((lambda y:y)(0)) for _ in [])=='')

def parity(n,L=7):
    bits=[]
    for _ in range(L): bits.append(str(n&1)); n=S(n)
    return ''.join(bits)

r=next(n for n in range(128) if parity(n)==W)
n0=next(n for n in range(27,128*19683,19683) if n%128==r)
assert n0%19683==27 and parity(n0)==W
assert (243*n0+319)%128==0
print('binary residue',r,'CRT representative',n0,'modulus',128*19683)
for s in range(1,9):
    bs=set(); candidates=[]
    for t in range(100):
        n=n0+128*19683*t; x=(243*n+319)//128
        H=4**s*x+(4**s+2)//3; B=0; z=H
        while z%3==0:B+=1;z//=3
        bs.add(B)
        if B:
            m=(2**B)*z-1
            assert m>=n
            candidates.append(m)
    assert len(bs)==1
    print('shift',s,'B',next(iter(bs)),'candidate_count',len(candidates))
print('PASS: first 100 lifts per shift; universal result follows from 3-adic precision and inequalities in note.')
