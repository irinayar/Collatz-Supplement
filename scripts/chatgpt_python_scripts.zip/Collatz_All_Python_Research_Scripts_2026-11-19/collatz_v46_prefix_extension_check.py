from math import gcd, isqrt
from fractions import Fraction

# Exhaustive first-crossing words through length 18, testing the strengthened
# theorem whenever the word begins with 110^k and a<=3k and gcd(a,j)>1.

def test(maxlen=18):
    tested=0
    examples=[]
    for j in range(1,maxlen+1):
        for mask in range(1<<j):
            bits=[(mask>>i)&1 for i in range(j)]
            a=0; U=0; crossed=False
            for i,b in enumerate(bits,1):
                U=3*U+2**(i-1) if b else U
                a+=b
                if 2**i>3**a:
                    if i!=j: crossed=True
                    break
            if crossed or 2**j<=3**a: continue
            k=0
            while bits[3*k:3*k+3]==[1,1,0]: k+=1
            if k==0 or a>3*k or gcd(a,j)==1: continue
            D=2**j-3**a
            # least positive cylinder residue n modulo 2^j, using the
            # exact condition 3^a n + U = 0 mod 2^j.
            n=(-U*pow(3**a,-1,2**j))%(2**j)
            if n==0:n=2**j
            assert n>=8**k-5
            assert n*D>U
            tested+=1
            if len(examples)<6: examples.append((j,a,k,''.join(map(str,bits)),n))
    return tested,examples

if __name__=='__main__':
    print('checked',test())
    # Check elementary growth inequality without floating point:
    # 8^k-5 > (k/2) 3^(3k/2)
    for k in range(1,2001):
        assert 4*(8**k-5)**2 > k*k*3**(3*k)
    print('exact growth inequality verified for k=1..2000')
