from fractions import Fraction
from math import gcd
import csv,json
from pathlib import Path
P=Path('/mnt/data')
base=[('E_even',0,2,'D'),('E_1mod4',1,4,'D'),('E_3mod16',3,16,'D'),('E_11mod32',11,32,'D'),('E_23mod32',23,32,'D')]
new=[('I_91',91,93312,'I'),('I_1275',1275,1296,'I'),('I_273',273,4374,'I'),('I_121',121,162,'I')]
# A residue class intersection via generalized CRT; return (r,m) or None.
def crt(a,b):
 r,m=a;s,n=b;g=gcd(m,n)
 if (s-r)%g:return None
 N=n//g; t=((s-r)//g*pow(m//g,-1,N))%N if N>1 else 0
 M=m*N
 return ((r+m*t)%M,M)
def intersect(classes):
 x=(0,1)
 for c in classes:
  x=crt(x,(c[1],c[2]))
  if x is None:return None
 return x
# inclusion-exclusion of finite union of classes
from itertools import combinations
def density_union(classes):
 out=Fraction(0)
 for k in range(1,len(classes)+1):
  for subset in combinations(classes,k):
   v=intersect(subset)
   if v:out+=(-1)**(k+1)*Fraction(1,v[1])
 return out
allc=base+new
b=density_union(base)
print('base',b,float(b))
print('all',density_union(allc),float(density_union(allc)))
rows=[]
prior=base.copy()
for name,r,m,status in new:
 before=density_union(prior); after=density_union(prior+[(name,r,m,status)])
 rows.append({'id':name,'residue':r,'modulus':m,'status':status,'raw_density':str(Fraction(1,m)),'incremental_density':str(after-before),'incremental_pct':float((after-before)*100),'cumulative_density':str(after),'cumulative_pct':float(after*100)})
 prior.append((name,r,m,status))
 print(name, 'raw',Fraction(1,m),'new',after-before,'cum',after)
# check progression n=91 mod93312 is subset of 3 mod16? 91 mod16=11; n 91 mod32=27 (uncovered), 93312 mod32=0
# Others same.
with (P/'collatz_v51_coverage_ledger.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(P/'collatz_v51_coverage_results.json').write_text(json.dumps({'base':str(b),'combined':str(density_union(allc)),'rows':rows},indent=2))
period=279936
assert all(period%c[2]==0 for c in allc)
actual=sum(any(n%c[2]==c[1]%c[2] for c in allc) for n in range(1,period+1))
assert actual==245503,(actual,period)
print('independent one-period enumeration:',actual,'/',period)
