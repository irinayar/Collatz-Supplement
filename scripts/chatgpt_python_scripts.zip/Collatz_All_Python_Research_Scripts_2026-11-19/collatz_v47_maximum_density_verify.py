from fractions import Fraction
from math import isqrt

def threshold(t):
    # Smallest r>=1 for which 3**r >= 2**(r+t), exact integers.
    lo,hi=1,2*t+4
    while 3**hi < 2**(hi+t): hi*=2
    while lo<hi:
        mid=(lo+hi)//2
        if 3**mid >= 2**(mid+t): hi=mid
        else: lo=mid+1
    return lo

def excluded(h):
    t=(h & -h).bit_length()-1
    u=h>>t
    r=((u+1)&-(u+1)).bit_length()-1
    return 3**r >= 2**(r+t)

if __name__=='__main__':
    N=200000
    cnt=sum(excluded(h) for h in range(2,N+1,2))
    partial=sum((Fraction(1,2**(t+threshold(t)-1)) for t in range(1,81)),Fraction(0))
    print('even tested:',N//2,'excluded:',cnt,'fraction:',cnt/(N//2))
    print('density partial t<=80:',float(partial))
    print('rigorous absolute tail bound <',2**(-80))
    print('thresholds:',[threshold(t) for t in range(1,11)])
