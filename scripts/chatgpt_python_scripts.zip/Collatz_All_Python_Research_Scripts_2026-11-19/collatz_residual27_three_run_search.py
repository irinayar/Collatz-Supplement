from math import gcd
n0=629883+2519424; dn=2*2519424
x0=(243*n0+319)//128; dx=243*dn//128
assert (243*n0+319)%128==0
print(n0,dn,x0,dx)
def coeff(w):
 p=1;u=0;q=1
 for bit in w:
  if bit=='1': p*=3;u=3*u+q
  q*=2
 return p,u,q
hits=[]
for h in range(1,22):
 for g in range(1,7):
  for k in range(1,9):
   for e in range(1,7):
    for l in range(1,9):
     V='1'*h+'0'*g+'1'*k+'0'*e+'1'*l
     b=h+k+l; Q=3**b
     p,u,q=coeff(V)
     for s in range(1,4):
      g_s=(4**s-1)//3
      A=q*(4**s*x0+g_s)-u
      D=q*4**s*dx
      d=gcd(D,Q)
      if A%d: continue
      period=Q//d
      t0=(-(A//d)*pow(D//d,-1,period))%period if period>1 else 0
      # m(t)=(A+D*t)/Q; n=n0+dn*t; slope must less
      dm=D//d # not actual increment
      slope_num=D*period//Q
      dn_new=dn*period
      if slope_num>=dn_new: continue
      m0=(A+D*t0)//Q
      nbase=n0+dn*t0
      # find t=t0+period*z for nonneg m<n
      diff=nbase-m0
      if diff<=0:
       z=(1-diff+(dn_new-slope_num)-1)//(dn_new-slope_num)
      else:z=0
      if m0+slope_num*z<=0: z=max(z,(-m0)//slope_num+1) if slope_num else 10**50
      # no cap
      t=t0+period*z; n=n0+dn*t;m=(A+D*t)//Q
      if not 0<m<n:continue
      # candidate n still hard? starts with W, x odd yes
      hits.append((n,len(V)+2*s+1,h,g,k,e,l,s,m,period, V))
 if hits:
  print('h',h,'hits',len(hits),'best',sorted(hits)[:2],flush=True)
  break
print('total',len(hits));print(*sorted(hits)[:15],sep='\n')
