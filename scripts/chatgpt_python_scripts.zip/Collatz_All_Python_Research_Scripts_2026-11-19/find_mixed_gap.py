from collections import defaultdict

def S(x):return (3*x+1)//2 if x&1 else x//2

def words(maxlen):
 out=[]
 for ell in range(1,maxlen+1):
  for mask in range(1<<(ell-1)):
   w='1'+''.join(str(mask>>j&1) for j in range(ell-1))
   b=w.count('1');U=0
   for j,c in enumerate(w):
    if c=='1':U=3*U+2**j
   out.append((ell,b,U,w))
 return out
W=words(8)
def witness(y,n,limit=8):
 for ell,b,U,w in W:
  z=(1<<ell)*y-U
  if z>0 and z%(3**b)==0:
   m=z//(3**b)
   if m<n:
    x=m;bits=''
    for _ in range(ell):bits+=str(x&1);x=S(x)
    if x==y and bits==w:return m,ell,w
 return None
candidates=[]
L=9;Q=1<<L
for r in range(1,Q,2):
 if r%3==2:continue
 x=r;bits='';states=[r];a=0;ok=True
 for j in range(1,L+1):
  bit=x&1;bits+=str(bit);a+=bit;x=S(x);states.append(x)
  if x<r or 3**a<2**j:ok=False;break
 if not ok or '00' not in bits or not(bits.startswith('110') or bits.startswith('1110')):continue
 if any(witness(y,r) for y in states[1:]):continue
 candidates.append((r,bits,x))
print('candidates',len(candidates),candidates[:20])
for r,bits,x in candidates[:50]:
 y=r;first=None;found=None
 for j in range(1,120):
  y=S(y)
  if y<r: first=j;break
  w=witness(y,r)
  if w:found=(j,y,w);break
 if found:
  print('LATER',r,bits,'found',found);break
 else:print('NONE',r,bits,'first descent',first)
