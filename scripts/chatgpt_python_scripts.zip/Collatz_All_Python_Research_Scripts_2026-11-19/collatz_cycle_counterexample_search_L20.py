from collections import Counter
counts=Counter(); examples=[]; total=0
for L in range(2,21):
  found=[]
  for bits in range(1,1<<L):
    A=bits.bit_count()
    D=(1<<L)-3**A
    if D<=0: continue
    U=0;a=0
    for i in range(L):
      if bits>>i&1: U=3*U+(1<<i);a+=1
    if U%D==0:
      c=U//D
      if c>0: found.append((c,bits,A))
  counts[L]=len(found)
  if found: examples.append((L,found[:4]))
print('counts',dict(counts));print('examples',examples)
# Validate run examples in previous responses
for r,s,k in [(2,2,5),(3,2,7),(5,3,3),(6,4,25)]:
 x=2**r*k-1;y=(3**r*k-1)//2**s
 print('run',r,s,k,x,y,'congruence?',(3**r*k-1)%(2**s)==0)
