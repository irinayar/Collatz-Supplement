"""Exact finite test of zero-determinant first-crossing words.
Not a proof of universal Collatz convergence.
"""
from itertools import combinations
from math import gcd

def numerator(word):
    u = 0
    for i, bit in enumerate(word):
        if bit:
            u = 3*u + (1 << i)
    return u

def count_family(L, A, crossing):
    assert 2**L > 3**A and gcd(L,A)>1
    D = 2**L - 3**A
    g = gcd(L,A)
    B = 2**(L//g)-3**(A//g)
    assert B>0 and D%B==0
    Q = D//B
    counts = dict(first_crossing=0, suffix_admissible=0,
                  quotient_divisible=0, cycle_integral=0)
    for positions in combinations(range(2,L-1), A-2):
        w = [1,1]+[0]*(L-2)
        for k in positions:
            w[k]=1
        a=0
        first=None
        for j,bit in enumerate(w,1):
            a+=bit
            if 2**j > 3**a:
                first=j
                break
        if first != crossing:
            continue
        counts['first_crossing']+=1
        if any(2**s <= 3**sum(w[-s:]) for s in range(1,L)):
            continue
        counts['suffix_admissible']+=1
        u=numerator(w)
        if u%Q==0:
            counts['quotient_divisible']+=1
        if u%D==0:
            counts['cycle_integral']+=1
    return B,Q,counts

if __name__=='__main__':
    for case in [(15,9,10),(20,12,10),(25,15,10),(25,15,20)]:
        print(case, count_family(*case))
