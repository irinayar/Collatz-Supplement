#!/usr/bin/env python3
"""Exact CRT gap sieve for hypothetical two-run Collatz cycles; no universal proof."""
from math import gcd

def crt_gap(r1,s1,r2,s2):
    q=min(r1,r2)
    mod3=3**q
    # 2^s1*g = 2^(s1-s2)-1 mod 3^q
    t=((pow(2,s1-s2,mod3)-1)*pow(2,-s1,mod3))%mod3
    a=min(r1,r2) if r1!=r2 else r1+1
    # If r1 != r2, v2(g)=a; otherwise 2^a divides g.
    mod2=2**(a+1) if r1!=r2 else 2**a
    rem2=2**a if r1!=r2 else 0
    # g = rem2 + mod2*j, j determined modulo mod3
    j=((t-rem2)*pow(mod2,-1,mod3))%mod3
    g0=(rem2+mod2*j)%(mod2*mod3)
    if g0==0: g0=mod2*mod3
    return g0,mod2*mod3,t,a,q

def verify():
    checked=0
    for r1 in range(1,7):
      for r2 in range(1,7):
       for s1 in range(1,7):
        for s2 in range(1,7):
         g0,period,t,a,q=crt_gap(r1,s1,r2,s2)
         assert g0>0
         assert g0%3**q==t
         if r1!=r2: assert g0%(2**(a+1))==2**a
         else: assert g0%2**a==0
         checked+=1
    print('Checked CRT residue tuples:',checked)
    print('Example (r1,s1,r2,s2)=(3,1,2,2):',crt_gap(3,1,2,2))
    # Exhaustively verify gap condition on actual pairs of odd run-start values.
    n=0
    for c in range(1,1000,2):
      for z in range(c+2,1000,2):
       r1=((c+1)&-(c+1)).bit_length()-1
       r2=((z+1)&-(z+1)).bit_length()-1
       # endpoint ternary congruences only when a complete run exists
       for s1 in range(1,5):
        if (2**s1*z+1)%3**r1: continue
        for s2 in range(1,5):
         if (2**s2*c+1)%3**r2: continue
         g0,period,_,_,_=crt_gap(r1,s1,r2,s2)
         assert (z-c-g0)%period==0
         n+=1
    print('Verified admissible endpoint pairs:',n)
if __name__=='__main__': verify()
