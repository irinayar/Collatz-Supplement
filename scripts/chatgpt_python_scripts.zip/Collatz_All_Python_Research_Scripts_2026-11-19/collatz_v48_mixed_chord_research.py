"""Exact crossing classification for accelerated Collatz chords, no cycle assumed."""
def T(x): return x//2 if x%2==0 else (3*x+1)//2
def cross(a,b,d,e):
    if len({a,b,d,e})!=4: return False
    l,r=sorted((a,b)); u,v=sorted((d,e))
    return l<u<r<v or u<l<v<r

def mixed(a,d):
    assert a>0 and a%2 and d>0 and d%2==0
    b=T(a)
    return len({a,b,d,d//2})==4 and ((a<d<b) or (2*a<d<3*a+1))

pairs=hits=0
for a in range(1,1000,2):
    for d in range(2,1001,2):
        pairs+=1
        actual=cross(a,T(a),d,T(d))
        predicted=mixed(a,d)
        assert actual==predicted,(a,d,actual,predicted)
        hits+=actual
print('Mixed pairs verified:',pairs,'crossing pairs:',hits)
for a,d in [(7,8),(7,16),(7,12),(7,22)]:
    print(a,T(a),d,T(d),mixed(a,d))
