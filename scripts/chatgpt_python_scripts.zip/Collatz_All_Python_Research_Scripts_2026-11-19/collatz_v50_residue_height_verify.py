"""Exact checks of one-step shifted-target residue-height certificate."""
def T(n): return n//2 if n%2==0 else (3*n+1)//2
checked=0; witnesses=[]; violations=0
for n in range(3,20001):
    x=n
    for j in range(1,101):
        x=T(x)
        if x<n: break
        if x%3==2 and 2*x-1<3*n:
            m=(2*x-1)//3
            assert (2*x-1)%3==0 and m%2==1 and 0<m<n and T(m)==x
            checked+=1
            if len(witnesses)<12: witnesses.append((n,j,x,m))
        if x%6==4 and x<3*n+1:
            m=(x-1)//3
            assert m%2==1 and m<n and T(m)==x//2
            violations+=1
print('one-step witness events before descent',checked,'even-state shortcuts',violations)
print('examples',witnesses)
