#!/usr/bin/env python3
"""Exact checks of maximum-centered odd-run theorem; not a cycle search."""
from collections import Counter

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def v2(n):
    k=0
    while n%2==0:
        k+=1; n//=2
    return k

def test(limit=200000):
    counts=Counter()
    for H in range(2,limit+1,2):
        t=v2(H); u=H>>t; r=v2(u+1); k=(u+1)>>r
        x=H
        for _ in range(t):
            x=T(x)
        assert x==u
        for _ in range(r):
            assert x%2==1
            x=T(x)
        assert x==3**r*k-1
        if 3**r>=2**(t+r):
            assert x>H
            counts['excluded']+=1
        else:
            assert r*1>=1
            counts['not_excluded']+=1
    print('even H tested:',limit//2)
    print('excluded by theorem:',counts['excluded'])
    print('not excluded:',counts['not_excluded'])
    for t in range(1,7):
        allowed=[r for r in range(1,30) if 3**r<2**(t+r)]
        print('t=',t,'allowed odd-run lengths r <=',max(allowed))

if __name__=='__main__': test()
