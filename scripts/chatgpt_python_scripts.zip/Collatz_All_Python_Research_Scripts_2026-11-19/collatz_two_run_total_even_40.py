"""Exact exhaustive two-run Collatz cycle search for total even steps <= 40.

Accelerated Collatz T(n) = (3n+1)//2 for odd n, n//2 for even n.
No heuristic floating-point bounds are used.
"""

def accelerated(n):
    return (3*n+1)//2 if n & 1 else n//2

def search(max_even=40):
    checked=0
    solutions=[]
    counts={}
    for even_total in range(2,max_even+1):
        local=0
        odd_total=2
        # For fixed even_total, D decreases relative to 3**odd_total
        # as odd_total grows. Once D <= 0, no larger odd_total qualifies.
        while (1 << (odd_total+even_total)) > 3**odd_total:
            D=(1 << (odd_total+even_total))-3**odd_total
            for s1 in range(1,even_total):
                s2=even_total-s1
                for r2 in range(1,odd_total):
                    r1=odd_total-r2
                    local+=1
                    N1=3**r2*((1<<s1)-1)+(1<<(r2+s1))*((1<<s2)-1)
                    if N1%D: continue
                    k1=N1//D
                    x=(1<<r1)*k1-1
                    y=x
                    word=[1]*r1+[0]*s1+[1]*r2+[0]*s2
                    for b in word:
                        assert (y&1)==b, (r1,s1,r2,s2,x)
                        y=accelerated(y)
                    assert y==x
                    solutions.append((r1,s1,r2,s2,x))
            odd_total+=1
        counts[even_total]=local
        checked+=local
    return checked, solutions, counts

if __name__=='__main__':
    checked,solutions,counts=search(40)
    print('Maximum total even steps: 40')
    print('Exact tuples checked:',checked)
    print('Solutions:',solutions)
    assert solutions==[(1,1,1,1,1)]
