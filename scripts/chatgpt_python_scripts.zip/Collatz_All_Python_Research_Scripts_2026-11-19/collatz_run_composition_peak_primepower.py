from itertools import combinations
from math import gcd
from collections import Counter
import json

def compositions(n,k,minimum):
    if k==1:
        if n>=minimum: yield (n,)
        return
    for a in range(minimum,n-minimum*(k-1)+1):
        for tail in compositions(n-a,k-1,minimum):yield (a,)+tail

def calc(bits):
    L=len(bits);A=sum(bits);D=(1<<L)-3**A
    if D<=0:return None
    U=0
    for i,b in enumerate(bits):
        if b:U=3*U+(1<<i)
    X=U;xs=[]
    for b in bits:
        xs.append(X)
        if b:
            if (3*X+D)%2:return None
            X=(3*X+D)//2
        else:
            if X%2:return None
            X//=2
    assert X==U
    return D,U,xs

def prime_power_pass(U,D):
    z=D;p=2; factors=[]
    while p*p<=z:
        if z%p==0:
            q=1
            while z%p==0:q*=p;z//=p
            factors.append((p,q))
        p+=1 if p==2 else 2
    if z>1:factors.append((z,z))
    return all(U%p==0 for p,q in factors),all(U%q==0 for p,q in factors)

def flat(bits,xs):
    S=min(xs)+max(xs);L=len(bits)
    for i in range(L):
        b=bits[i]; nxt=bits[(i+1)%L]
        if b==1 and nxt==0:
            if xs[i]+xs[(i+1)%L]<S:return False
        if b==0 and nxt==1:
            if 3*xs[i]>=2*S:return False
    return True

def primitive(bits):
    L=len(bits)
    return all(bits!=bits[:d]*(L//d) for d in range(1,L) if L%d==0)

counts=Counter(); byL={}; examples=[]
for L in range(3,23):
    c=Counter()
    for A in range(2,L):
        if 3**A >= 2**L:continue
        for k in range(1,min(A//2,L-A)+1):
            for rs in compositions(A,k,2):
                for ds in compositions(L-A,k,1):
                    bits=tuple(z for r,d in zip(rs,ds) for z in ([1]*r+[0]*d))
                    if not primitive(bits):continue
                    c['primitive_run_compositions']+=1
                    v=calc(bits)
                    if v is None:continue
                    D,U,xs=v
                    if min(xs)<D:continue
                    c['positive_ge1']+=1
                    p,pp=prime_power_pass(U,D)
                    if p:c['positive_prime_pass']+=1
                    if pp:c['positive_primepower_pass']+=1
                    if p and not pp:c['positive_primepower_extra']+=1
                    if not flat(bits,xs):continue
                    c['flat']+=1
                    if U%D==0:c['integer']+=1
                    p,pp=prime_power_pass(U,D)
                    if p:c['prime_pass']+=1
                    if pp:c['primepower_pass']+=1
                    if p and not pp:
                        c['primepower_extra']+=1
                        if len(examples)<8:examples.append({'L':L,'A':A,'k':k,'word':''.join(map(str,bits)),'D':D,'U':U,'gcd':gcd(D,U)})
    byL[L]=dict(c);counts.update(c)
    print(L,dict(c),flush=True)
print('TOTAL',dict(counts));print('EXAMPLES',examples)
with open('/mnt/data/collatz_run_composition_results.json','w') as f:json.dump({'by_length':byL,'totals':dict(counts),'examples':examples},f,indent=2)
