from fractions import Fraction
from math import gcd
pairs=[(1023,13,767,11),(2047,12,1819,15),(4095,16,3071,14),(16383,17,12287,15),(32767,47,31959,1),(2097151,53,1725759,2),(268435455,72,223910979,2)]
def run(n,k):
 w=''; v=n; low=n
 for _ in range(k):
  bit=v%2;w+=str(bit);v=(3*v+1)//2 if bit else v//2;low=min(low,v)
 return v,w,low
def lift(n,j,m,l):
 y,w,lo=run(n,j);z,v,_=run(m,l);assert y==z and m<n
 a=w.count('1');b=v.count('1');P=(2**j)*(3**max(b-a,0));Q=(2**l)*(3**max(a-b,0));g=gcd(P,Q);P//=g;Q//=g
 # reduced increments preserve parity only if n shift multiple 2^j, m shift multiple 2^l
 # scaling down by gcd may destroy parity. verify using 2-adic divisibility
 if P%(2**j) or Q%(2**l):
  P*=g;Q*=g
 assert 3**a*P//2**j==3**b*Q//2**l
 # for all t, each prefix >= initial iff at t=0 and slope(prefix)>=1
 pref=True
 for h in range(j+1):
  x,ww,_=run(n,h); aa=ww.count('1');
  if x<n or 3**aa*P < 2**h*P:pref=False
 return w,v,a,b,P,Q,P-Q,pref,lo
for p in pairs:
 w,v,a,b,P,Q,D,pref,lo=lift(*p)
 print('n',p[0],'j',p[1],'m',p[2],'l',p[3], 'words',w,v,'odd',a,b,'periods',P,Q,'difference',D,'prefix_non_descent',pref,'min',lo)
