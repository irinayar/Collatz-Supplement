from fractions import Fraction
def S(x): return (3*x+1)//2 if x&1 else x//2
def walk(n,L):
    bits=[]; states=[n]
    for _ in range(L):
        bits.append(str(n&1)); n=S(n); states.append(n)
    return ''.join(bits),states
L,ell,a,b=11,14,7,9
r,y0=539, None
w,base=walk(r,L)
y0=base[-1]
v,tar=walk(2299,ell)
assert w=="11011111000" and v=="11011011111000"
assert walk(2587,L)[1][-1]==tar[-1]
assert y0%3!=2
assert min(base)>=r
assert all(3**w[:j].count('1')>=2**j for j in range(1,L+1))
for t in range(1000):
    n=2587+18432*t
    m=2299+16384*t
    wb,ns=walk(n,L);vb,ms=walk(m,ell)
    assert wb==w and vb==v and ns[-1]==ms[-1] and 0<m<n
    assert min(ns)>=n
print('verified',w,v,'base endpoint',y0,'1000 lifts')
