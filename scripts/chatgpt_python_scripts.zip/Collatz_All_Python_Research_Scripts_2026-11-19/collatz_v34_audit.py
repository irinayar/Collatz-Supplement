from fractions import Fraction
from math import gcd

def S(n): return n//2 if n%2==0 else (3*n+1)//2

def reaches_one(n):
    seen=set()
    while n!=1 and n not in seen:
        seen.add(n);n=S(n)
    return n==1

N=1000
P=[3+4*j for j in range(N)]
assert all(reaches_one(n) for n in P)
H=max(P)
z=2
K=[]
for k in range(40):
    numerator=(2**(k+1))*z-1
    if numerator%3: continue
    m=numerator//3
    if m>H:break
    assert m%4==1
    x=m
    for _ in range(k+1):x=S(x)
    assert x==z
    K.append((k,m))
assert set(P).isdisjoint(m for _,m in K)
print('P count:',len(P),'H:',H,'ancestors:',K,'intersection:',0)
# actual Fourier remainder for q=H+1: identity forces -|A||P| exactly
print('exact nonzero Fourier correlation:',-len(K)*len(P),'zero-frequency:',len(K)*len(P))
