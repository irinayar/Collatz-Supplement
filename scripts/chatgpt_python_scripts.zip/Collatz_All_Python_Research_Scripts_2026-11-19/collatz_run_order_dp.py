#!/usr/bin/env python3
"""Exact seam-aware run-formula Collatz numerator DP, including prime-power orders.
Counts run-boundary-anchored words 1^r1 0^d1 ... 1^rk 0^dk.
No geometric flatness is assumed by this modular-only program.
"""
from collections import defaultdict
from math import gcd, comb, lcm

def factor(n):
    ans={}; d=2
    while d*d<=n:
        while n%d==0: ans[d]=ans.get(d,0)+1;n//=d
        d+=1 if d==2 else 2
    if n>1:ans[n]=ans.get(n,0)+1
    return ans

def order(a,q):
    assert gcd(a,q)==1
    t=1;v=a%q
    while v!=1:
        v=v*a%q;t+=1
    return t

def orders_for_D(L,A):
    D=2**L-3**A
    if D<=0:return {}
    out={}
    for p,e in factor(D).items():
        q=p**e
        out[q]=order(3*pow(2,-1,q)%q,q)
    return out

def dp(L,A,k,h,q,track_orders=True):
    """Residue histogram. All moduli q must be coprime to 6.
    Exact position and ones totals retain seam and exponents; run length residue
    modulo ord_q(3/2) is used to compute run defect 3^r-2^r mod q.
    """
    assert q>1 and gcd(q,6)==1
    o=order(3*pow(2,-1,q)%q,q) if track_orders else None
    pow2=[pow(2,i,q) for i in range(L+1)]
    pow3=[pow(3,i,q) for i in range(A+1)]
    defect=[(pow3[r]-pow2[r])%q for r in range(A+1)]
    if track_orders:
        # r mod o controls whether a run contribution vanishes; exact r remains
        # necessary to enforce (L,A,k,h), so no unsafe quotient of lengths.
        for r in range(1,A+1):
            assert (defect[r]==0)==(r%o==0)
    states={(0,0,0,0,0):1}
    for block in range(k):
        nxt=defaultdict(int)
        for (ell,a,used,long,u),count in states.items():
            remaining=k-used-1
            for r in range(1,A-a-remaining+1):
                hh=long+(r>=2)
                if hh>h:continue
                # Compute odd run in one step: U' = 3^r U + 2^ell(3^r-2^r).
                v=(pow3[r]*u+pow2[ell]*defect[r])%q
                for d in range(1,L-ell-r-2*remaining+1):
                    ee=ell+r+d
                    if ee>L or a+r>A:continue
                    nxt[(ee,a+r,used+1,hh,v)]+=count
        states=nxt
    out=defaultdict(int)
    for (ell,a,used,long,u),count in states.items():
        if (ell,a,used,long)==(L,A,k,h):out[u]+=count
    return dict(out)

def brute(L,A,k,h,q):
    out=defaultdict(int)
    def rec(word,a,used,long):
        if used==k:
            if len(word)==L and a==A and long==h:
                u=0
                for i,b in enumerate(word):
                    if b:u=3*u+(1<<i)
                out[u%q]+=1
            return
        for r in range(1,A-a+1):
            for d in range(1,L-len(word)-r+1):
                if len(word)+r+d+2*(k-used-1)>L:continue
                rec(word+[1]*r+[0]*d,a+r,used+1,long+(r>=2))
    rec([],0,0,0)
    return dict(out)

def formula(L,A,k,h):
    if not(1<=k<=min(A,L-A) and 0<=h<=k):return 0
    if h==0:return comb(L-A-1,k-1) if A==k else 0
    if A<k+h:return 0
    return comb(k,h)*comb(A-k-1,h-1)*comb(L-A-1,k-1)

def verify():
    checks=0
    for L in range(3,15):
        for A in range(1,L):
            for k in range(1,min(A,L-A)+1):
                for h in range(k+1):
                    for q in (5,25,7,49,13):
                        v=dp(L,A,k,h,q)
                        assert v==brute(L,A,k,h,q),(L,A,k,h,q)
                        assert sum(v.values())==formula(L,A,k,h)
                        checks+=1
    print('PASS:',checks,'exact signature/modulus comparisons through L=14')
    for sig in ((8,4,2,1),(8,4,2,2),(12,7,3,2),(16,9,3,3),(20,12,4,4)):
        L,A,k,h=sig; D=2**L-3**A
        if D<=0:continue
        ords=orders_for_D(L,A)
        hist=dp(L,A,k,h,D)
        print('SIG',sig,'D',D,'prime_power_orders',ords,'anchored',sum(hist.values()),'D_divides_U',hist.get(0,0))
if __name__=='__main__':verify()
