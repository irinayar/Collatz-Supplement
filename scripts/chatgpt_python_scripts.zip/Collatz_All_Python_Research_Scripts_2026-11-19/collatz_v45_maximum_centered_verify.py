"""Verify maximum-centered local restriction by exhaustive residues and integer paths."""
def T(n):
    return n // 2 if n % 2 == 0 else (3*n + 1)//2

allowed = {2, 8, 20}
for H in range(2, 100000, 2):
    if H % 6 != 2:
        continue
    if H % 24 == 14:
        u = T(H)
        assert u % 2 == 1
        assert T(u) % 2 == 1
        assert T(T(u)) > H
    if H % 24 not in allowed:
        assert H % 24 == 14
print('Verified: all H ≡ 14 (mod 24) below 100000 overshoot within three steps.')
print('Permitted maximum residue classes modulo 24:', sorted(allowed))
