from fractions import Fraction as F
from math import log2

def orbit(word):
 a=0;b=0;L=len(word)
 for c in word:
  if c=='1': a=3*a+2**b;b+=1
  else:b+=1
 # instead direct affine numerator U
 U=0;A=0
 for c in word:
  if c=='1': U=3*U+2**A; A+=1
  else: A+=1
 # above incorrect; use fraction affine
 slope=F(1);inter=F(0)
 for c in word:
  if c=='1': slope*=F(3,2);inter=(3*inter+1)/2
  else:slope/=2;inter/=2
 x=inter/(1-slope)
 vals=[x]
 for c in word:
  x=(3*x+1)/2 if c=='1' else x/2
  vals.append(x)
 assert vals[-1]==vals[0]
 return vals

def analyze(word):
 v=orbit(word);c=min(v[:-1]);H=max(v[:-1]); S=c+H
 starts=[];i=0
 while i<len(word):
  assert word[i]=='1'
  r=0
  while i<len(word) and word[i]=='1':i+=1;r+=1
  d=0
  while i<len(word) and word[i]=='0':i+=1;d+=1
  starts.append((r,d))
 peaks=[];valleys=[];j=0
 for r,d in starts:
  a=v[j+r-1];p=v[j+r];b=v[j+r+d-1];m=v[(j+r+d)%len(word)]
  peaks.append(a+p>=S);valleys.append(F(3,2)*b<S)
  j+=r+d
 return c,H,peaks,valleys,starts

word=''.join('1'*r+'0'*d for r,d in [(2,2),(3,1),(2,2),(3,2),(4,2),(3,2),(3,1)])
c,H,p,v,st=analyze(word)
print('Claude k7:',len(word),sum(map(lambda x:x[0],st)),c,H,all(p),all(v),min(orbit(word)[:-1])>=1)
assert len(word)==32 and all(p) and all(v) and c>=1
q=F(27,64);h=F(19,37)
for k in range(1,101):
 word='111000'*(k-1)+'1110000'
 c,H,p,v,st=analyze(word)
 ck=h*(1-q**k)/(2-q**k)
 assert c==ck and H==16*c and all(p) and all(v) and c+H>=3
print('Codex C90: exact rational k=1..100 passed')
for n,y,j,a in [(4064460795,7821397930,26,17),(18839651253368551,27937390841126308,66,42)]:
 pairs=0;bad=[]
 for ell in range(109):
  for b in range(ell+1):
   if 2**ell*3**a<2**j*3**b:
    pairs+=1
    if 2**ell*y>=3**b*n:bad.append((ell,b))
 print('Codex affine',n,pairs,'exceptions',len(bad))
 assert not bad
 # peak and necessary lengths
 H=1034822155734146 if j==26 else 5544449589606178143824
 A=0
 while n*3**A<(H+1)*2**A:A+=1
 B=0
 while 2**B*y<H:B+=1
 print('height barrier A B',A,B)
