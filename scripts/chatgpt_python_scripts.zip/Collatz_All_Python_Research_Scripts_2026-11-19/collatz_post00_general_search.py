from fractions import Fraction
from collections import Counter

def S(n):return (3*n+1)//2 if n%2 else n//2

def scan(L):
  out=[]
  for r in range(1,2**L,2):
    x=r; states=[x]; w=[]
    for j in range(L):
      w.append(str(x%2));x=S(x);states.append(x)
    word=''.join(w)
    if '00' not in word or word.index('00')+2>L:continue
    if min(states)>=r and x%3==2 and x>1 and (2*x-1)%3==0:
      m=(2*x-1)//3
      if 0<m<r:
        # full-lift: affine slope endpoint / start, target inverse slope < 1
        a=word.count('1'); slope=Fraction(2*3**a,3*2**L)
        if slope<1 and all(Fraction(3**word[:j].count('1'),2**j)>=1 for j in range(1,L+1)):
          out.append((r,word,m,x))
  return out
for L in (9,10,11,12,13,14):
  a=scan(L)
  print('L',L,'count',len(a),'examples',a[:6])
