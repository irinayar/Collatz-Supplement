from math import gcd

def numerator(w):
    n=0
    for i, bit in enumerate(w):
        if bit=='1': n=3*n+(1<<i)
    return n

def first_crossing(w):
    a=0
    for j,b in enumerate(w,1):
        a+=b=='1'
        if (1<<j)>3**a: return j,a
    return None

w='1101011111111111000100000'
L=len(w); A=w.count('1'); g=gcd(L,A); q=L//g; p=A//g
B=2**q-3**p; D=2**L-3**A; N=numerator(w)
assert (L,A,g,q,p,B,D,N,N%25)==(25,15,5,5,3,5,19205525,29556935,10)
assert first_crossing(w)==(5,3)
assert (first_crossing(w)[0]*A-L*first_crossing(w)[1])==0
print('Example: verified',L,A,B,D,N,N%25)
for g in range(2,21):
    for q,p in [(5,3),(8,5),(19,12),(27,17)]:
        X,Y=2**q,3**p
        if X<=Y: continue
        B=X-Y; Q=(X**g-Y**g)//B
        assert B*Q==X**g-Y**g
        for ell in range(5,300):
            if any(ell%d==0 for d in range(2,int(ell**.5)+1)):continue
            if Q%ell==0 and B%ell:
                z=X*pow(Y,-1,ell)%ell
                assert z!=1 and pow(z,g,ell)==1
print('Order checks: verified')
