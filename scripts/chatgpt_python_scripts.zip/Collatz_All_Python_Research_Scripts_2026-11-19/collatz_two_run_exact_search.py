"""Exact two-run positive Collatz cycle search; accelerated map."""
from math import gcd

def S(n):
    return (3*n+1)//2 if n&1 else n//2

def check(limit=20):
    tested=0; solutions=[]; best=[]
    for r1 in range(1,limit+1):
      for s1 in range(1,limit+1):
       for r2 in range(1,limit+1):
        for s2 in range(1,limit+1):
         L=r1+s1+r2+s2; A=r1+r2
         D=(1<<L)-3**A
         if D<=0: continue
         tested+=1
         N=3**r2*((1<<s1)-1)+(1<<(r2+s1))*((1<<s2)-1)
         if N%D: continue
         k1=N//D
         # Second run parameter is integral automatically, but check independently.
         N2=3**r1*((1<<s2)-1)+(1<<(r1+s2))*((1<<s1)-1)
         assert N2%D==0
         k2=N2//D
         assert k1>0 and k2>0 and k1%2==1 and k2%2==1
         x=(1<<r1)*k1-1; y=x
         word=[1]*r1+[0]*s1+[1]*r2+[0]*s2
         for bit in word:
          assert (y&1)==bit
          y=S(y)
         assert y==x
         solutions.append((r1,s1,r2,s2,x,k1,k2))
    return tested,solutions
if __name__=='__main__':
    tested,solutions=check()
    print('Contracting run tuples checked:',tested)
    print('Integer cycles:',solutions)
