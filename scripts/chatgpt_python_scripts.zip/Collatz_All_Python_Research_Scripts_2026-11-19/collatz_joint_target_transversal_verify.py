from fractions import Fraction
Q=3**11
N0=94109
M0=69631

def S(x): return x//2 if x%2==0 else (3*x+1)//2

def iterate(x,k):
 for _ in range(k): x=S(x)
 return x

checks=0
for J in range(1,15):
 mod=2**(J-1)
 inv=pow(Q,-1,mod) if mod>1 else 0
 for r in range(1,2**J,2):
  t=(((r-N0)//2)*inv)%mod if mod>1 else 0
  n=N0+2*Q*t
  m=M0+262144*t
  assert n%2**J==r and 0<m<n and iterate(m,18)==S(n)
  checks+=1
print('verified cylinder intersections',checks)
print('C53 relative density within any odd binary cylinder',Fraction(1,Q))
print('C53 unconditional density',Fraction(1,2*Q))
