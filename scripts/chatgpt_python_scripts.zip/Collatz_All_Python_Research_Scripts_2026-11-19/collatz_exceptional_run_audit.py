"""Exact audit of multiplicatively contracting but value-increasing maximal runs.
For each r, the only possible exceptional s is the least s with 2^(r+s)>3^r:
D/(2^s-1) increases with s. An odd positive k can yield increase only if
D*k < 2^s-1. The script checks the strongest k=1 case.
"""
import argparse

def audit(R):
    p3 = 1
    closest = None
    exceptions = []
    for r in range(1, R+1):
        p3 *= 3
        s = max(1, p3.bit_length()-r)
        if (1 << (r+s)) <= p3:
            s += 1
        d = (1 << (r+s)) - p3
        upper = (1 << s) - 1
        if d < upper:
            exceptions.append((r,s,d,upper))
        # Track smallest difference (ties allowed), exact integers.
        gap = d - upper
        if closest is None or gap < closest[0]:
            closest = (gap,r,s,d,upper)
    print('r tested:',R)
    print('exceptional (r,s) candidates:',len(exceptions))
    print('first exceptions:',exceptions[:10])
    print('smallest absolute gap (gap,r,s,D,2^s-1):',closest)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--max-r',type=int,default=2000)
    audit(p.parse_args().max_r)
