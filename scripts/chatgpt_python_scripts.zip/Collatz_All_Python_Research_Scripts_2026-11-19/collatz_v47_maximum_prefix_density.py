"""Exact asymptotic density of even integers failing a maximum-prefix test.
For length d, parity words bijectively represent residues mod 2**d.
Only words beginning in 0 are counted; the coefficient condition is 3**a < 2**j.
"""
from collections import defaultdict
from fractions import Fraction

def counts(max_depth=100):
    states = {0: 1}
    for j in range(1, max_depth + 1):
        new = defaultdict(int)
        for a, count in states.items():
            for bit in (0, 1):
                if j == 1 and bit == 1:
                    continue
                b = a + bit
                if pow(3, b) < (1 << j):
                    new[b] += count
        states = dict(new)
        if j in (3, 8, 12, 20, 32, 50, 64, 80, 100):
            surviving = sum(states.values())
            excluded = Fraction((1 << (j-1)) - surviving, 1 << (j-1))
            print(f'depth={j:3d} surviving={surviving} excluded={float(excluded):.12%}')

if __name__ == '__main__':
    counts()
