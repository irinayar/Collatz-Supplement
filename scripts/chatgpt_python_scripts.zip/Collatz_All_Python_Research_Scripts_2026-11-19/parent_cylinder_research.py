from collections import Counter
from fractions import Fraction

def S(x):return (3*x+1)//2 if x%2 else x//2

def analyze(L):
 out=[]
 for q in range(1<<(L-13)):
  r=103+8192*q; n=r; a=0; states=[n];counts=[0];hits=[]
  for j in range(1,L+1):
   if n%2:a+=1
   n=S(n);states.append(n);counts.append(a)
   # candidate's prefix all above initial for entire cylinder iff base>=r and coefficient>=1
   prefixok=all(states[i]>=r and 3**counts[i]>=2**i for i in range(j+1))
   if n%3==2 and prefixok:
    m=(2*n-1)//3
    if 0<m<r and 2*3**(a-1)<2**j:
     hits.append((j,m,a))
  # descent certified by prefix at some time with base below r and multiplier<1 OR bound for all t: base<r and slope<=1
  desc=[j for j in range(1,L+1) if states[j]<r and 3**counts[j]<=2**j]
  out.append((r,hits,desc,states,counts))
 return out
for L in [17,19,21,23,25,27]:
    o=analyze(L)
    h=sum(bool(x[1]) for x in o)
    d=sum(bool(x[2]) for x in o)
    both=sum(bool(x[1]) and bool(x[2]) for x in o)
    print(L,len(o),h,d,both,h+d-both,len(o)-h-d+both)
