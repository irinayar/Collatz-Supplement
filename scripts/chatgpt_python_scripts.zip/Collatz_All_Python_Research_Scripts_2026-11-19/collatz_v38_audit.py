from itertools import combinations
from math import gcd
w='11100'
A=0
for i,b in enumerate(w):
    if b=='1': A=3*A+(1<<i)
assert A==19
assert (1<<5)-3**3==5
for j in range(1,5):
    assert 3**w[:j].count('1')>2**j
assert 3**w.count('1')<2**len(w)
for k in range(5):
    rot=w[k:]+w[:k]
    assert all(not (3**rot[:i].count('1')<2**i and 3**rot[i:].count('1')<2**(5-i)) for i in range(1,5))
print('PASS: primitive negative-drift word 11100, zero determinant, no two contracting segments in any rotation')
# Test mixed-block bounds on all positive integer boundary pairs from a formal two-block cycle.
for q in range(2,8):
    for p0 in range(q+1):
      for p1 in range(q+1):
        X=2**q; Y0=3**p0;Y1=3**p1
        if Y0*Y1>=X*X: continue
        T=2*X-Y0-Y1
        for U0 in range(max(0,3**p0-2**p0),2**(q-p0)*(3**p0-2**p0)+1):
          for U1 in range(max(0,3**p1-2**p1),2**(q-p1)*(3**p1-2**p1)+1):
            den=X*X-Y0*Y1
            num=Y1*U0+X*U1
            if num%den:continue
            x0=num//den
            if x0<=0 or (Y0*x0+U0)%X:continue
            x1=(Y0*x0+U0)//X
            if x1<=0:continue
            c=min(x0,x1);R=abs(x0-x1);U=U0+U1
            Cp=sum(max(0,X-y) for y in (Y0,Y1));Ep=sum(max(0,y-X) for y in (Y0,Y1))
            assert T*c-Ep*R<=U<=T*c+Cp*R
print('PASS: mixed-block drift spread inequalities in enumerated integer boundary cases')
