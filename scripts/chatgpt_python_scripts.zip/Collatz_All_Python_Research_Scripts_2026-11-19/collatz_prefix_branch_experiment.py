"""Exact finite parity-word search; not a proof of Collatz convergence.
Minimum-start accelerated map. Searches all binary words at selected lengths.
Uses safe prefix upper bounds and optional certified minimum lower bound.
"""
from collections import Counter
from math import gcd

def primitive(bits):
    L=len(bits)
    return all(bits != bits[:d]*(L//d) for d in range(1,L) if L%d==0)

def suffix_contract(bits):
    a=0
    for k,b in enumerate(reversed(bits[1:]),1):
        a+=b
        if 2**k <= 3**a:return False
    return True

def exact_cycle(bits):
    L=len(bits); A=sum(bits); D=(1<<L)-3**A
    if D<=0:return False
    U=0
    for j,b in enumerate(bits):
        if b:U=3*U+(1<<j)
    if U%D:return False
    c=U//D
    if c<=1:return False
    x=c
    for b in bits:
        if x%2!=b:return False
        x=(3*x+1)//2 if b else x//2
        if x<c:return False
    return x==c

def scan(maxL=18,minc=2):
    stats=Counter(); examples={}
    for L in range(3,maxL+1):
        # Initial 11; final 0. Prefix state (word, a, U, min-upper bound)
        stack=[((1,1),2,5,None)] # numerator '11' = 5
        while stack:
            bits,a,U,upper=stack.pop(); j=len(bits)
            if j==L:
                if bits[-1]!=0 or not primitive(bits):continue
                if not (2*a>L and 3**a < 2**L):continue
                stats['preliminary']+=1
                if not suffix_contract(bits):
                    stats['suffix_reject']+=1;continue
                stats['suffix_pass']+=1
                if upper is not None and upper<minc:
                    stats['prefix_reject_after_suffix']+=1;continue
                stats['both_pass']+=1
                if exact_cycle(bits):
                    stats['actual_cycle']+=1
                    examples.setdefault('cycle',''.join(map(str,bits)))
                continue
            for b in (0,1):
                if j==L-1 and b:continue
                na=a+b
                nu=3*U+(1<<j) if b else U
                nj=j+1
                if 3**na >= 2**L:continue # can't lower odd count
                nupper=upper
                # Every proper contracting prefix requires x_j-c >=1.
                if nj<L and 2**nj>3**na:
                    bound=(nu-(1<<nj))//(2**nj-3**na)
                    nupper=bound if upper is None else min(upper,bound)
                    if nupper<minc:
                        stats['early_pruned_nodes']+=1
                        continue
                stack.append((bits+(b,),na,nu,nupper))
    return stats,examples

if __name__=='__main__':
    for minc in (2,2075*(1<<60)):
        s,e=scan(18,minc)
        print('minimum',minc,dict(s),e)

def baseline(maxL=18,minc=2):
    s=Counter(); witness={}
    for L in range(3,maxL+1):
        for middle in range(1<<(L-3)):
            bits=(1,1)+tuple((middle>>k)&1 for k in range(L-4,-1,-1))+(0,) if L>3 else (1,1,0)
            if not primitive(bits):continue
            A=sum(bits)
            if not (2*A>L and 3**A<2**L):continue
            s['preliminary']+=1
            suffix=suffix_contract(bits)
            if suffix:s['suffix_pass']+=1
            a=0; U=0; upper=None
            for j,b in enumerate(bits,1):
                if b:U=3*U+(1<<(j-1))
                a+=b
                if j<L and 2**j>3**a:
                    bound=(U-(1<<j))//(2**j-3**a)
                    upper=bound if upper is None else min(upper,bound)
            prefix=(upper is None or upper>=minc)
            if prefix:s['prefix_pass']+=1
            if prefix and suffix:
                s['both_pass']+=1
                if exact_cycle(bits):s['cycles']+=1
            if suffix and not prefix and 'prefix' not in witness:witness['prefix']=''.join(map(str,bits))
            if prefix and not suffix and 'suffix' not in witness:witness['suffix']=''.join(map(str,bits))
    return s,witness
if __name__=='__main__':
    for minc in (2,2075*(1<<60)):
        s,e=baseline(18,minc)
        print('baseline minimum',minc,dict(s),e)

def integrality_counts(maxL=18):
 s=Counter()
 for L in range(3,maxL+1):
  for m in range(1<<(L-3)):
   bits=(1,1)+tuple((m>>k)&1 for k in range(L-4,-1,-1))+(0,) if L>3 else (1,1,0)
   if not primitive(bits):continue
   a=sum(bits)
   if not (2*a>L and 3**a<2**L):continue
   s['prelim']+=1
   U=0
   for j,b in enumerate(bits):
    if b:U=3*U+(1<<j)
   D=(1<<L)-3**a
   if U%D==0:
    s['integral']+=1
    c=U//D
    if c>1:s['integral_c_gt1']+=1
 print('integrality',dict(s))
if __name__=='__main__':integrality_counts(18)
