"""Exact search for primitive minimum-start two-run cycles, S<=MAX_S.
All tests are integer arithmetic. This is a finite exclusion only.
"""
import sys

def run(max_s=50):
    checked=0; feasible=0; solutions=[]; per_s=[]
    for S in range(2,max_s+1):
        count=0; survivors=0
        A=2
        while (1 << (A+S))>3**A:
            D=(1 << (A+S))-3**A
            for r1 in range(2,A):
                r2=A-r1
                for s1 in range(1,S):
                    s2=S-s1
                    count+=1
                    # Minimum-start first run expands, second run contracts.
                    if 3**r1 <= (1 << (r1+s1)): continue
                    if 3**r2 >= (1 << (r2+s2)): continue
                    survivors+=1
                    N1=3**r2*((1<<s1)-1)+(1<<(r2+s1))*((1<<s2)-1)
                    if N1%D: continue
                    k1=N1//D
                    c=(1<<r1)*k1-1
                    if c<=1: continue
                    x=c; seen=[]
                    word=[1]*r1+[0]*s1+[1]*r2+[0]*s2
                    for b in word:
                        assert x%2==b
                        seen.append(x)
                        x=(3*x+1)//2 if b else x//2
                    assert x==c
                    if c==min(seen) and len(set(seen))==len(seen):
                        solutions.append((r1,s1,r2,s2,c))
            A+=1
        checked+=count; feasible+=survivors; per_s.append((S,count,survivors))
    print('S max',max_s,'total tuples',checked,'run-pruned',feasible,'primitive solutions',solutions)
    print('last five S:',per_s[-5:]); return checked,feasible,solutions
if __name__=='__main__': run(int(sys.argv[1]) if len(sys.argv)>1 else 50)
