from collections import Counter

def S(x): return (3*x+1)//2 if x%2 else x//2

def target_words(maxlen=6):
 for ell in range(2,maxlen+1):
  for bits in range(1<<(ell-1)):
   w='1'+format(bits,'0'+str(ell-1)+'b')
   if w=='1'*ell: continue
   b=w.count('1'); U=0; a=0
   for j,c in enumerate(w):
    if c=='1': U=3*U+2**j; a+=1
   yield w,ell,b,U

# S^ell(m)=(3^b m+U)/2^ell. for b<=a, integer m(k) all k
results=[]; counts=Counter()
for L in range(7,15):
 Q=1<<L
 for r in range(1,Q,2):
  x=r; states=[x]; word=''; a=0; valid=True
  for j in range(1,L+1):
   bit=x&1; word+=str(bit); a+=bit; x=S(x); states.append(x)
   if x<r or 3**a < 2**j: valid=False
  if not valid or '00' not in word: continue
  y=x
  for w,ell,b,U in target_words(6):
   if b>a: continue
   numerator=(1<<ell)*y-U
   if numerator<=0 or numerator%(3**b): continue
   m0=numerator//(3**b)
   dm=(1<<ell)*3**(a-b)
   if not(0<m0<r and dm<Q): continue
   z=m0; bits=''
   for j in range(ell): bits+=str(z&1); z=S(z)
   if bits!=w or z!=y: continue
   results.append((L,r,word,y,a,w,m0,dm)); counts[(L,w)]+=1
print('total',len(results),'counts',counts)
for row in results[:35]: print(row)
