from fractions import Fraction
best=[]
for L in range(5,19):
 for mid in range(1<<(L-3)):
  bits=[1,1]+[(mid>>k)&1 for k in range(L-3)]+[0]
  A=sum(bits); D=(1<<L)-3**A
  if D<=0:continue
  U=0;a=0; prefixes=[]
  for j,e in enumerate(bits):
   if e:U=3*U+(1<<j);a+=1
   if j<L-1:prefixes.append((j+1,a,U))
  c=Fraction(U,D)
  if c<=2:continue
  if any((1<<(L-j))<=3**(A-aa) for j,aa,_ in prefixes):continue
  if any(Fraction(3**aa*c+uu,1<<j)<=c for j,aa,uu in prefixes):continue
  rem=U%D
  if rem==0:print('CYCLE',L,''.join(map(str,bits)),c)
  else:
   dist=min(rem,D-rem)/D
   best.append((dist,L,''.join(map(str,bits)),str(c),D,rem))
best.sort()
for x in best[:12]:print(x)
print('candidates',len(best))
