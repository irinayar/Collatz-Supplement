from itertools import combinations
from collections import defaultdict

def numerator(bits):
    u=0
    for i,e in enumerate(bits):
        if e:u=3*u+(1<<i)
    return u

def admissible(bits):
    return all((1<<len(bits[k:]))>3**sum(bits[k:]) for k in range(len(bits)))

for t in range(1,13):
    for b in range(t+1):
        vals=[]
        for positions in combinations(range(t),b):
            s=set(positions)
            bits=tuple(int(i in s) for i in range(t))
            vals.append(numerator(bits))
        assert len({v%(1<<t) for v in vals})==len(vals)
print('Verified numerator injectivity modulo 2^t for every (t,b), 1<=t<=12.')

# Full parity cylinders: each word of length t has a unique starting residue.
for t in range(1,12):
    residues=set()
    for n in range(1<<t):
        x=n; bits=[]
        for _ in range(t):
            e=x%2;bits.append(e)
            x=(3*x+1)//2 if e else x//2
        residues.add(tuple(bits))
    assert len(residues)==(1<<t)
print('Verified parity-cylinder bijection for 1<=t<=11.')

# Example collisions mod odd D (unlike mod 2^t).
for t,b,D in [(8,4,5),(8,4,7),(8,4,295)]:
    vals=[]
    for positions in combinations(range(t),b):
        bits=tuple(int(i in positions) for i in range(t))
        if admissible(bits):vals.append(numerator(bits))
    print('t,b,D=',t,b,D,'exact numerators=',len(vals),'distinct residues=',len({v%D for v in vals}))
