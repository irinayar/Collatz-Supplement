#!/usr/bin/env python3
"""Exact bounded reverse search for smaller-origin pre-descent meetings."""
from collections import deque

def S(x): return x//2 if x%2==0 else (3*x+1)//2

def first_block(n):
 x=n;r=0;e=0
 while x%2: x=S(x);r+=1
 while x%2==0: x=S(x);e+=1
 return r,e,x

def inverse_search(y,n,maxdepth=16):
 # breadth-first; exclude trivial y itself and origins on candidate's forward prefix later
 q=deque([(y,0,'')]); seen={(y,0)}
 while q:
  x,d,w=q.popleft()
  if d and 0<x<n: return x,d,w
  if d==maxdepth: continue
  for z,b in ((2*x,'0'),((2*x-1)//3,'1')):
   if b=='1' and ((2*x-1)%3 or z<=0 or z%2==0):continue
   if z<=0:continue
   key=(z,d+1)
   if key not in seen:seen.add(key);q.append((z,d+1,b+w))
 return None

def run():
 print('r,n,block_steps,block_height_ratio,first_certificate_step,target_length,target,word,status')
 for r in range(10,31):
  n=2**r-1; a,e,z=first_block(n);x=n; result=None; descent=None
  for j in range(1,min(a+e+40,120)+1):
   x=S(x)
   if x<n: descent=j;break
   if j>=a+e:
    res=inverse_search(x,n,16)
    if res:
     m,d,w=res
     # independent replay and ensure no false self-meeting
     assert m<n and m>0
     z2=m
     for b in w:
      assert (z2%2)==int(b)
      z2=S(z2)
     assert z2==x
     result=(j,m,d,w);break
  print(f'{r},{n},{a+e},{z/n:.6f},'+ (f'{result[0]},{result[2]},{result[1]},{result[3]},meeting' if result else f'{descent or ""},,,, '+('descent' if descent else 'unresolved')))
if __name__=='__main__':run()
