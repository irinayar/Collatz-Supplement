from math import gcd
pairs=[(32767,47,31959,1),(2097151,53,1725759,2)]
def walk(x,k):
 w='';arr=[x]
 for _ in range(k):
  b=x&1;w+=str(b);x=(3*x+1)//2 if b else x//2;arr.append(x)
 return w,arr
for n,j,m,l in pairs:
 w,A=walk(n,j);v,B=walk(m,l);assert A[-1]==B[-1]
 old=(w,v); c=0
 while w and v and w[-1]==v[-1]:w=w[:-1];v=v[:-1];c+=1
 j1,l1=len(w),len(v);a=w.count('1');b=v.count('1'); P=2**j1*3**max(b-a,0);Q=2**l1*3**max(a-b,0)
 assert A[j1]==B[l1]
 print('n',n,'m',m,'suffix',c,'reduced lengths',j1,l1,'word',w,v,'periods',P,Q,'n mod9',n%9,'n mod81',n%81,'n mod3',n%3,'n mod32',n%32,'slope difference',P-Q)
 for k in [0,1,2]:
  aa=walk(n+P*k,j1)[1];bb=walk(m+Q*k,l1)[1]
  assert aa[-1]==bb[-1] and 0<m+Q*k<n+P*k
 print('pre-descent?',all(A[i]>=n for i in range(j1+1)))
