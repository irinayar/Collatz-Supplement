"""Exact arithmetic necessary run-multiplier inequalities for primitive two-run cycles."""
from collections import Counter

def counts(max_even=40):
    total=0; filtered=0; candidates=[]
    for S in range(2,max_even+1):
        A=2
        while 2**(A+S)>3**A:
            for s1 in range(1,S):
                s2=S-s1
                for r1 in range(1,A):
                    r2=A-r1
                    total+=1
                    # Minimum-start first run expands; second run contracts.
                    if 3**r1 <= 2**(r1+s1) and (2**(r1+s1)-3**r1) >= 2**s1-1: continue
                    if 3**r2 >= 2**(r2+s2): continue
                    filtered+=1
                    D=2**(A+S)-3**A
                    N=3**r2*(2**s1-1)+2**(r2+s1)*(2**s2-1)
                    if N%D==0:
                        candidates.append((r1,s1,r2,s2,N//D))
            A+=1
    return total,filtered,candidates
if __name__=='__main__':
    a,b,c=counts()
    print('All tuples:',a,'minimum-run-compatible:',b,'fraction:',b/a)
    print('Solutions:',c)
