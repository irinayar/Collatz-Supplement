"""Exact finite verification of the v35 reversal-defect identity."""
from itertools import product

def A(word):
    # affine recurrence on successive appended symbols
    value=0; length=0
    for bit in word:
        value=(3 if bit else 1)*value + (2**length if bit else 0)
        length+=1
    return value

def rotations(w):
    return {w[i:]+w[:i] for i in range(len(w))}

count=0; conj=0; survivors=[]
for n in range(11):
    for u in product((0,1),repeat=n):
        w=(1,)+u+(0,)
        rev=w[::-1]
        D=2**len(w)-3**sum(w)
        if D<=0: continue
        defect=A(u)-A(u[::-1])
        assert 3*A(w)-A(rev)+D==2**(len(w)-1)+6*defect
        count+=1
        if rev in rotations(w):
            conj+=1
            if (2**(len(w)-1)+6*defect)%D==0:
                survivors.append((''.join(map(str,w)),D))
print('Exact identity checked:',count)
print('Reversal-conjugate candidates:',conj)
print('Divisibility survivors:',len(survivors))
print('First survivors:',survivors[:30])
