import sys
sys.path.insert(0,'/mnt/data')
from collatz_prefix_branch_experiment import primitive,suffix_contract
from collections import Counter
M=2075*2**60
for minc in (2,M):
 s=Counter(); witness=None
 for L in range(3,19):
  for z in range(1<<(L-3)):
   bits=(1,1)+tuple((z>>k)&1 for k in range(L-4,-1,-1))+(0,) if L>3 else (1,1,0)
   A=sum(bits)
   if not primitive(bits) or 2*A<=L or 3**A>=2**L:continue
   if not suffix_contract(bits):continue
   s['baseline']+=1
   a=0;U=0;lo=minc;hi=None;res=0;ok_old=True;ok_new=True
   for j,b in enumerate(bits[:-1],1):
    if b:U=3*U+(1<<(j-1))
    a+=b
    t=(1<<j)-3**a
    if t>0:
     upper=(U-(1<<j))//t
     hi=upper if hi is None else min(hi,upper)
     if hi<minc:ok_old=False
    elif t<0:
     lower=((1<<j)-U + (-t)-1)//(-t)
     lo=max(lo,lower)
    modulus=1<<j
    res=(-U*pow(3**a,-1,modulus))%modulus
    if hi is not None:
     first=lo+(res-lo)%modulus
     if first>hi:ok_new=False
   if ok_old:s['old']+=1
   if ok_old and ok_new:s['new']+=1
   if ok_old and not ok_new and witness is None:witness=''.join(map(str,bits))
 print(minc,s,witness)
