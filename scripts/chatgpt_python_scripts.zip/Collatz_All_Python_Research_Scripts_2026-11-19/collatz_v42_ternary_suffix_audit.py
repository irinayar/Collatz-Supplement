"""Exact audit of ternary residue determined by trailing even steps."""
from itertools import product

def numerator(w):
    u=0
    for j,e in enumerate(w):
        if e: u=3*u+(1<<j)
    return u

checks=0
for L in range(2,17):
    for w in product((0,1),repeat=L):
        A=sum(w)
        if not A or w[-1]!=0: continue
        z=next(i for i,e in enumerate(reversed(w)) if e)
        U=numerator(w)
        D=(1<<L)-3**A
        if D<=0: continue
        assert U%3 == pow(2,L-z-1,3)
        if U%D==0:
            c=U//D
            assert c%3 == (1 if z%2 else 2)
        checks+=1
print('Verified',checks,'contracting parity words ending even, lengths 2..16')
