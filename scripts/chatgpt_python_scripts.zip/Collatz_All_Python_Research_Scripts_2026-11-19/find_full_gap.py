exec(open('/mnt/data/find_mixed_gap.py').read().split('candidates=[]')[0])
W=words(6)
for L in [9,11,13,14]:
 Q=1<<L; gaps=[]; eligible=0
 for r in range(1,Q,2):
  if r%3==2:continue
  x=r;bits='';a=0;good=True;states=[r]
  for j in range(1,L+1):
   bit=x&1;bits+=str(bit);a+=bit;x=S(x);states.append(x)
   if x<r or 3**a<2**j:good=False;break
  if not good or '00' not in bits or not(bits.startswith('110') or bits.startswith('1110')):continue
  eligible+=1;full=False
  for ell,b,U,w in W:
   if b>a:continue
   z=(1<<ell)*x-U
   if z<=0 or z%(3**b):continue
   m=z//3**b
   if 0<m<r and (1<<ell)*3**(a-b)<Q:
    q=m;ws=''
    for _ in range(ell):ws+=str(q&1);q=S(q)
    if q==x and ws==w:full=True;break
  if not full:gaps.append((r,bits,x,a))
 print(L,'eligible',eligible,'gaps',len(gaps),gaps[:8])
 if gaps:
  for r,bits,x,a in gaps[:10]:
   found=[]
   for k in range(0,100):
    n=r+(1<<L)*k;y=n;first=0
    for j in range(1,80):
     y=S(y)
     if y<n:first=j;break
     if j>L:
      z=witness(y,n)
      if z:found.append((k,j,z));break
   if found:
    print('later',r,bits,found[:4]);quit()
