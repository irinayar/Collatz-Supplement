from math import comb
from fractions import Fraction
from collections import defaultdict

def count(L,A):
    if not (0<A<L): return 0
    return sum(L*comb(A-k-1,k-1)*comb(L-A-1,k-1)//k for k in range(1,min(A//2,L-A)+1))

def S(x): return (3*x+1)//2 if x&1 else x//2

def U_for_word(bits):
    U=0; a=0
    for i,b in enumerate(bits):
        if b: U=3*U+2**i; a+=1
    return U

def fixed_integer(bits):
    L=len(bits); A=sum(bits); D=(1<<L)-3**A
    if D<=0: return None
    U=U_for_word(bits)
    if U%D: return None
    n=U//D
    if n<1:return None
    x=n
    for b in bits:
        if x%2!=b:return None
        x=S(x)
    return n if x==n else None

def admissible(bits):
    L=len(bits)
    return 0<sum(bits)<L and all(not(bits[i]==1 and bits[(i-1)%L]==0 and bits[(i+1)%L]==0) for i in range(L))

def main():
    for L in range(3,17):
        observed=defaultdict(int); valid=[]
        for mask in range(1<<L):
            bits=[(mask>>i)&1 for i in range(L)]
            if admissible(bits):
                observed[sum(bits)]+=1
                n=fixed_integer(bits)
                if n is not None: valid.append((mask,n))
        for A in range(L+1): assert observed[A]==count(L,A),(L,A,observed[A],count(L,A))
        print(f'L={L:2d} candidates={sum(observed.values()):6d} integer-fixed={len(valid):3d} integer-starts={sorted(set(n for _,n in valid))}')
    for L in [20,30,40,60,100]:
        items=[(A,count(L,A)) for A in range(1,L) if 3**A<2**L]
        print('L',L,'eligible count',sum(c for _,c in items),'max A',max(A for A,_ in items))
if __name__=='__main__':main()
