#!/usr/bin/env python3
"""Exact mixed-cylinder later-endpoint certificate; no universal coverage claim."""
def S(x): return (3*x+1)//2 if x&1 else x//2

def trajectory(n,L):
 a=[n]
 for _ in range(L):a.append(S(a[-1]))
 return a
r=103; L=13
p=trajectory(r,L)
assert ''.join(str(x&1) for x in p[:-1])=='1110111101001'
assert p[-1]==251 and min(p)>=r
# Fixed-endpoint exhaustive short-word scan, b<=a, integer slope for entire parent cylinder.
a=sum(x&1 for x in p[:-1]); Q=1<<L
hits=[]
for ell in range(1,7):
 for mask in range(1<<(ell-1)):
  w='1'+''.join(str(mask>>j&1) for j in range(ell-1))
  b=w.count('1');U=0
  for j,c in enumerate(w):
   if c=='1':U=3*U+(1<<j)
  if b>a:continue
  z=(1<<ell)*p[-1]-U
  if z>0 and z%(3**b)==0:
   m=z//(3**b);dm=(1<<ell)*3**(a-b)
   if 0<m<r and dm<Q and ''.join(str(x&1) for x in trajectory(m,ell)[:-1])==w:
    hits.append((ell,w,m,dm))
assert not hits
n0=65639;m0=59143;J=17
p=trajectory(n0,J)
assert ''.join(str(x&1) for x in p[:-1])=='11101111010011100'
assert p[-1]==S(m0)==88715
assert min(p)>=n0
A=sum(x&1 for x in p[:-1]);assert A==11
assert all(3**sum(x&1 for x in p[:j])>=2**j for j in range(1,J+1))
assert 2*3**(A-1)==118098<(1<<J)
assert (n0-r)%Q==0
for t in range(10000):
 n=n0+(1<<J)*t;m=m0+118098*t
 pn=trajectory(n,J)
 assert min(pn)>=n and pn[-1]==S(m) and 0<m<n
 assert ''.join(str(x&1) for x in pn[:-1])=='11101111010011100'
print('PASS: parent 13-step fixed-endpoint short-target scan; refined 17-step identity and 10000 lifts')
