"""Exact verification of Version 42 finite suffix statements (Python 3)."""
from functools import lru_cache

@lru_cache(None)
def numerators(t,b):
    if t == 0:
        return frozenset({0}) if b == 0 else frozenset()
    if b < 0 or b > t or (1 << t) <= 3**b:
        return frozenset()
    out = {2*v for v in numerators(t-1,b)}
    if b:
        out.update(3**(b-1)+2*v for v in numerators(t-1,b-1))
    return frozenset(out)

@lru_cache(None)
def count(t,b):
    if t == 0:
        return int(b == 0)
    if b < 0 or b > t or (1 << t) <= 3**b:
        return 0
    return count(t-1,b) + (count(t-1,b-1) if b else 0)

def decode(t,b,v):
    word=[]
    while t:
        if v%2:
            assert b > 0
            word.append('1');v=(v-3**(b-1))//2;b-=1
        else:
            word.append('0');v//=2
        t-=1
    assert b==0 and v==0
    return ''.join(word)

for t in range(1,16):
    for b in range(t+1):
        vals=numerators(t,b)
        assert len(vals)==count(t,b), (t,b)
        for v in vals:
            w=decode(t,b,v)
            assert len(w)==t and w.count('1')==b
            for k in range(1,t+1):
                assert 2**k > 3**w[-k:].count('1')
for t,b in [(8,4),(10,5),(12,6),(15,8),(20,10)]:
    vals=numerators(t,b)
    print(f'(t,b)=({t},{b}): count={count(t,b)}, min={min(vals)}, max={max(vals)}')
assert 120 not in numerators(8,4)
assert len(numerators(8,4))==23
print('All exact checks passed.')
