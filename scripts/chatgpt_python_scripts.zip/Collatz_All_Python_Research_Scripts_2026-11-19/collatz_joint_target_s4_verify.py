from fractions import Fraction
Q=3**14
r=2503585

def S(n):return n//2 if n%2==0 else (3*n+1)//2

def check(t):
 n=r+2*Q*t
 m=(2**14*(256*n+86))//Q-1
 assert (256*n+86)%Q==0
 assert n>m>0
 x=m
 for i in range(14):
  assert x%2==1,(t,i,x)
  x=S(x)
 assert x==256*n+85,(t,x,n)
 assert x%2==1
 x=S(x)
 for i in range(8):
  assert x%2==0,(t,i,x)
  x=S(x)
 assert x==S(n),(t,x,S(n))
 return n,m
for t in range(10000):
 check(t)
n,m=check(5)
assert n%32==27 and n%3==1 and n%162==37
assert n%93312!=91 and n%1296!=1275 and n%4374!=273
print('verified 10000; example',n,m,'S^23(m)=S(n)')
