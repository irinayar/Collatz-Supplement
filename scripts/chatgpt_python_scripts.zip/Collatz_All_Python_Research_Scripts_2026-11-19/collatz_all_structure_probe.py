from math import comb
n0=3149307; dn=5038848; x0=5978765;dx=9565938
summary={};hits=[]
for s in (1,2,3):
 G=4**s*x0+(4**s-1)//3
 for ell in range(1,23):
  q=1<<ell
  for B in range(1,min(14,ell)+1):
   Q=3**B
   if q*4**s*3**5>=128*Q:continue
   # enumerate exact binary strings, first and last odd; include single-letter case
   for mask in range(1<<(ell-1)):
    if mask.bit_count()!=B-1:continue
    # word bit positions: first 1, remaining from mask in temporal order
    p=1;u=0;power=1
    for i in range(ell):
     bit=1 if i==0 else ((mask>>(i-1))&1)
     if bit:p*=3;u=3*u+power
     power*=2
    key=(s,B)
    summary[key]=summary.get(key,0)+1
    A=q*G-u
    if A%Q==0:
     slope=q*4**s*dx//Q
     m0=A//Q
     t=max(0,(-m0)//slope+1,(m0-n0)//(dn-slope)+1)
     n=n0+dn*t;m=m0+slope*t
     if 0<m<n:hits.append((s,B,ell,mask,t,n,m))
 print('s',s,'count',sum(v for (ss,b),v in summary.items() if ss==s),'hits',len(hits),flush=True)
print('HITS',hits[:20]);print('total',sum(summary.values()))
assert sum(summary.values())==17238
assert not hits
