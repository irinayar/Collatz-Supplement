"""Exact crossing classification for the outgoing chord of a proposed maximum H."""
def T(x):
    return x//2 if x%2==0 else (3*x+1)//2

def crosses(a,b,d,e):
    if len({a,b,d,e})<4:
        return False
    l,r=sorted((a,b)); u,v=sorted((d,e))
    return (l<u<r<v) or (u<l<v<r)

def predicted(H,x):
    if x%2==0:
        return H//2 < x < H
    return (H-1)<3*x and 2*x<H and T(x)<H

count=0
for H in range(4,2002,2):
    for x in range(1,H):
        if T(x)>H: continue
        actual=crosses(H,H//2,x,T(x))
        expected=predicted(H,x)
        assert actual==expected,(H,x,actual,expected)
        count+=1
print('Verified',count,'valid local transitions against proposed maxima')
