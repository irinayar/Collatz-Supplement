#!/usr/bin/env python3
"""Exact finite experiment for height-sensitive residue-20 modulo 27 visits."""
from collections import Counter

def S(x): return (3*x+1)//2 if x&1 else x//2

def examine(n,cap=300):
    x=n; events=[]; descent=None
    for j in range(1,cap+1):
        old=x;x=S(x)
        if x<n:
            descent=j;break
        if x%27==20:
            m=(2*x-1)//3
            event=(j,old%2==0,3*x<3*n*1.5 if False else 2*x<3*n+1,m<n,m==old,x)
            events.append(event)
    return descent,events

def main():
    cnt=Counter();examples=[]
    for n in range(3,200003,2):
        if n%32 not in (7,27) or n%3==2:continue
        cnt['tested']+=1
        descent,events=examine(n)
        if descent is None:cnt['no_descent_cap']+=1
        if events:cnt['any_res20']+=1
        if any(e[1] for e in events):cnt['even_entry']+=1
        valid=[e for e in events if e[1] and e[3]]
        if valid:
            cnt['valid_even_small']+=1
            if len(examples)<12:examples.append((n,descent,valid[0]))
        if any(e[3] and not e[1] for e in events):cnt['odd_entry_small']+=1
    print(dict(cnt));print('examples (n, descent, (j, even_entry, height_band, smaller, m_is_previous, x))')
    for x in examples:print(x)
    for n in (4064460795,18839651253368551):
        d,events=examine(n)
        print('hard',n,'first descent',d,'residue20 events',events[:15])
if __name__=='__main__':main()
