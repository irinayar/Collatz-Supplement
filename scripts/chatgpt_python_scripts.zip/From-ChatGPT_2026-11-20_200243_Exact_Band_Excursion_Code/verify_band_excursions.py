from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
H,X=255,1023

def step(u):
 assert u%2 and u>1
 s=((u+1)&-(u+1)).bit_length()-1
 w=3**s*((u+1)//2**s)-1
 e=(w&-w).bit_length()-1
 v=w//2**e
 c=Fraction(2**s*w,3**s*u)
 assert c==1+Fraction(1, u)*(1-Fraction(2,3)**s)
 return v,c
@lru_cache(None)
def bounded(u):
 v,c=step(u)
 return c*bounded(v) if H<v<=X else c
vals=[(bounded(u),u) for u in range(H+2,X+1,2)]
M,u=max(vals)
assert M==Fraction(137438953472,135984591639) and u==793
Q=Fraction(8192,6561)
print('H,X',H,X,'band states',len(vals))
print('max band segment',M,'start',u,'decimal',float(M))
print('Q*M',Q*M,'decimal',float(Q*M),'safe',Q*M<Fraction(3,2))
print('high run bound',Fraction(X+1,X))
# replay maximum path and cross-check independent direct product
p=u; prod=Fraction(1); trace=[]
while H<p<=X:
 v,c=step(p);trace.append((p,v,str(c)));prod*=c;p=v
assert prod==M
print('max segment path',trace)
# explicit excursion budget: Q*M^J*((X+1)/X)^A < 3/2
for J in (1,2,3,5,10):
 A=0
 while Q*M**J*Fraction(X+1,X)**A < Fraction(3,2): A+=1
 print('J',J,'first A potentially unexcluded',A)
