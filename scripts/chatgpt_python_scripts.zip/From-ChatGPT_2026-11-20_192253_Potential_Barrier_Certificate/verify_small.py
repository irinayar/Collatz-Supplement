from fractions import Fraction
import csv
from pathlib import Path
results={int(row['max_k']):int(row['checked_states_at_n_ge3']) for row in csv.DictReader(Path(__file__).with_name('potential_barrier_results_k24.csv').open())}
for K in range(1,11):
    checked=0
    B=(1<<(K+1))-3
    for m in range(1,B):
        n,k,r=m,0,0
        while True:
            if k==K and n>=3:
                checked+=1
                assert Fraction(2**r*(2**k*n+1),3**r)<Fraction(3*(m+1),2)
            if k==K and n%2==0:break
            if n%2:n=(3*n+1)//2;r+=1
            else:n//=2;k+=1
    assert checked==results[K],(K,checked,results[K])
    print(K,checked,'OK')
