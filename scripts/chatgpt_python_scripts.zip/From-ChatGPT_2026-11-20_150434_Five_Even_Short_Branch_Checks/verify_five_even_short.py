from functools import lru_cache

def v3(n):
 a=0
 while n%3==0:a+=1;n//=3
 return a
@lru_cache(None)
def H(k,x,r):
 if r<0:return None
 a=v3(x+1)
 if k==0:return (2**r*(x+1)//3**r-1) if r<=a else None
 vals=[]
 for l in range(min(a,r)+1):
  y=2*(2**l*((x+1)//3**l)-1)
  z=H(k-1,y,r-l)
  if z is not None:vals.append(z)
 return min(vals) if vals else None

N=0; ties=0; win={0:0,1:0,2:0}; patterns={}
for a in range(2,7):
 for u in range(1,301):
  if u%3==0:continue
  x=3**a*u-1
  T=3*2**a*u-1
  D=16*T-5
  ymax=2+v3(16*2**a*u-7)
  y=2*(2**(a-2)*9*u-1)
  for s in range(ymax+1):
   formula=24*T-8 if s==0 else (16*T-8 if s==1 else (2**(s-1)*D//3**(s-1)-1))
   actual=H(4,y,s)
   assert formula==actual,(a,u,s,formula,actual)
   N+=1
  for r in range(a,min(a+12,a+ymax+2)):
   branches=[]
   for l in [a-2,a-1,a]:
    yy=2*(2**l*((x+1)//3**l)-1)
    branches.append(H(4,yy,r-l))
   good=[(v,i) for i,v in enumerate(branches) if v is not None]
   if not good:continue
   best=min(v for v,i in good)
   for v,i in good:
    if v==best:win[i]+=1
   if branches[0] is not None and branches[0]==best:
    patterns[(a,u,r)]=branches
print('short formula comparisons',N,'branch wins',win,'short winners',len(patterns))
print('first short winners',list(patterns.items())[:10])
for a in range(2,6):
 for u in range(1,200):
  if u%3==0:continue
  x=3**a*u-1
  r=a
  vals=[]
  for l in [a-2,a-1,a]:
   y=2*(2**l*((x+1)//3**l)-1)
   vals.append(H(4,y,r-l))
  assert vals==[2**(a+5)*u-15,2**(a+5)*u-24,2**(a+5)*u-32],(a,u,vals)
print('boundary checks pass')
