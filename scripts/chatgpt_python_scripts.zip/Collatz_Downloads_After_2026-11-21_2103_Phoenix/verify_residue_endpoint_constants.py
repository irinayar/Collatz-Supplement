#!/usr/bin/env python3
"""Exact final constants and aggregate checks for the mod-9 packing certificate.

This is NOT an independent reproduction of the dynamic-programming count.
It checks the supplied certificate's arithmetic, the finite power comparisons,
and a separate degree-10 exponential majorant. Standard library, Python 3.8+.
"""

from fractions import Fraction as Q
from pathlib import Path
import json
import math


HERE = Path(__file__).resolve().parent


def parse(row):
    return Q(int(row['numerator']), int(row['denominator']))


def certify(output=None):
    if not __debug__:
        raise RuntimeError('Assertions are required; do not use -O or -OO.')
    data = json.loads((HERE / 'residue_canonical_certificate.json').read_text())
    assert data['status'] == 'PASS'
    assert (data['level'], data['J'], data['S']) == (71, 512, 256)
    assert (data['endpoint_chunks'], data['precision']) == (64, 96)
    n, J, S = 2**71, 512, 256
    p = small = large = 1
    for r in range(1, J + 1):
        p *= 3
        small *= n
        large *= 3*n + 1
        assert large < small * (1 << p.bit_length())
    assert 2*3**44 < n < 2*3**45
    finite_units = 0
    remaining = 0
    for row in data['rows']:
        s = row['odd_count']
        for cell in row['classes']:
            a = cell['residue']
            low, high = max(n, 3**s + 1), 2*3**s - 1
            first = low + (a-low) % 9
            capacity = max(0, (high-first)//9 + 1)
            assert first == int(cell['first_endpoint'])
            assert capacity == int(cell['endpoint_capacity'])
            finite_units += int(cell['weight_units'])
            remaining += int(cell['capacity_left'])
    finite = Q(finite_units, 2**96)
    assert finite == parse(data['finite_endpoint_weight'])
    assert finite_units == 90967979218314767609676800115
    assert remaining == 0
    length_tail = Q(remaining, 2**(J+1))
    odd_tail = Q(200, 7) * Q(193, 200)**(S+1)
    boundary = Q(72, 2**70)
    assert length_tail == parse(data['uninspected_length_tail'])
    assert odd_tail == parse(data['large_odd_count_tail'])
    assert boundary == parse(data['terminal_boundary'])
    bound = finite + length_tail + odd_tail + boundary
    assert bound == parse(data['reciprocal_upper'])
    assert bound < Q(144, 125)
    assert bound < Q(575597, 500000)
    a = Q(193, 200)**3
    assert 9*a - 3 > 0 and (9*a - 3)**2 > 32*a*a
    # After term 11, every successive Taylor-term ratio is at most x/12.
    x = Q(48, 125)
    taylor10 = sum((x**k / math.factorial(k) for k in range(11)), Q(0))
    majorant = taylor10 + x**11 / math.factorial(11) / (1 - x/12)
    assert majorant == Q(318482310514689786049226261, 216928310692310333251953125)
    assert majorant < Q(47, 32) < Q(3, 2)
    # The certificate's sharper clean R bound absorbs the low-band potential
    # ratio, giving a uniform normalized per-return cap without that factor.
    sharp_x = Q(575597, 1500000)
    sharp_majorant = sum((sharp_x**k / math.factorial(k) for k in range(11)), Q(0))
    sharp_majorant += sharp_x**11 / math.factorial(11) / (1 - sharp_x/12)
    normalized_upper = sharp_majorant * (1 + Q(5, 4*n))
    assert normalized_upper < Q(367, 250) < Q(47, 32)
    assert Q(367, 250) - 1 == Q(117, 250)
    assert 2075*2**60 > n
    assert Q(47, 32) - 1 == Q(15, 32)
    assert 2*Q(15, 32) == Q(15, 16) < 1
    result = {
        'status': 'PASS',
        'scope': 'Independent exact final arithmetic and aggregate checks; the DP was not rerun by this checker.',
        'minimum_input': '2^71',
        'power_comparisons': 512,
        'finite_endpoint_units_at_2_to_96': str(finite_units),
        'unused_endpoint_capacity': remaining,
        'reciprocal_strict_upper': '144/125',
        'exponential_argument_strict_upper': '48/125',
        'degree_10_majorant': str(majorant),
        'degree_10_margin_below_47_over_32': str(Q(47, 32)-majorant),
        'product_strict_upper': '47/32',
        'normalized_return_strict_upper': '367/250',
        'positive_return_charge_strict_upper': '117/250',
        'normalized_return_scope': 'Every individual completed genuine first return at odd threshold n>=2^71; not repeated concatenation or a profile sum.',
        'normalized_degree_10_margin_below_367_over_250': str(Q(367, 250)-normalized_upper),
        'affine_consequence': '32 U_N < 15 * 3^r * a; in particular 2 U_N < 3^r * a',
        'project_base_covered': '2075 * 2^60 > 2^71',
    }
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    print(json.dumps(certify(HERE / 'residue_endpoint_constant_checks.json'), indent=2))
