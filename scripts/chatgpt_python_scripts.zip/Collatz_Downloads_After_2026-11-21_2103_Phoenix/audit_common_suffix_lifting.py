#!/usr/bin/env python3
"""Independent all-integer lift audit by Newton forward differences.

No producer module is imported.  Endpoint-derived affine coefficients and
positive Newton coefficients provide a second exact all-q certificate.
"""
from __future__ import annotations

import json
from fractions import Fraction as Q
from math import prod
from pathlib import Path


def certify(*, seeds_path=None, output=None):
    if not __debug__:
        raise RuntimeError("Assertions are required.")
    here = Path(__file__).resolve().parent
    seeds_path = Path(seeds_path) if seeds_path else here / "overlap_seed_profiles.json"
    seeds = json.loads(seeds_path.read_text())
    reports = []
    for family in seeds:
        G = max(len(row["word"]) for row in family["profiles"])
        W = 2 * 3**G
        high_slope = 4 * W // 3
        w = H = suffix = suffix_c = anchor_slope = None
        terms, prefix_coefficients, margins = [], [], []
        for row in family["profiles"]:
            u, word = row["source"], row["word"]
            states = [u]
            for e in word:
                z = 3 * states[-1] + 1
                assert (z & -z).bit_length() - 1 == e
                states.append(z // 2**e)
            if w is None:
                w = states[-1]
                H = (4 * w - 2) // 3
            assert states[-1] == w
            assert w <= u <= H and all(x > H for x in states[1:-1])
            g, E = len(word), sum(word)
            D = Q(2**E, 3**g)
            source_slope = W * D
            assert source_slope.denominator == 1
            assert W <= source_slope <= high_slope
            assert source_slope % (2**(E + 1)) == 0
            c = D * (w + 5) - (u + 5)
            assert c > 0
            terms.append((c, u + 5, int(source_slope)))
            anchor_index = states.index(family["anchor"])
            candidate = word[anchor_index:]
            if suffix is None:
                suffix = candidate
            assert candidate == suffix
            ds = Q(2**sum(candidate), 3**len(candidate))
            candidate_c = ds * (w + 5) - (family["anchor"] + 5)
            candidate_slope = W * ds
            if suffix_c is None:
                suffix_c, anchor_slope = candidate_c, candidate_slope
            assert suffix_c == candidate_c > 0
            assert anchor_slope == candidate_slope and anchor_slope.denominator == 1
            dp = Q(2**sum(word[:anchor_index]), 3**anchor_index)
            cp = dp * (family["anchor"] + 5) - (u + 5)
            prefix_coefficients.append(cp)
            if family["all_prefixes_negative"]:
                assert cp < 0
            proper_margins = []
            for j in range(1, g):
                slope = W * Q(2**sum(word[j:]), 3**(g - j))
                assert slope.denominator == 1 and slope > high_slope
                proper_margins.append(slope - high_slope)
            margins.append(str(min(proper_margins)))
        factor = Q(family["factor"])
        terms.append((-factor * suffix_c, family["anchor"] + 5, int(anchor_slope)))
        degree = len(terms) - 1
        values = []
        for q in range(degree + 1):
            denominators = [Q(b + a * q) for c, b, a in terms]
            values.append(sum((c / d for (c, b, a), d in zip(terms, denominators)), Q(0))
                          * prod(denominators))
        newton = []
        layer = values
        while layer:
            newton.append(layer[0])
            layer = [b - a for a, b in zip(layer, layer[1:])]
        assert all(value > 0 for value in newton)
        bs = suffix_c / (family["anchor"] + 5)
        total = sum((c / Q(b) for c, b, a in terms[:-1]), Q(0))
        deficit = sum((-cp / Q(row["source"] + 5)
                       for cp, row in zip(prefix_coefficients, family["profiles"])), Q(0))
        assert total == degree * bs - (1 + bs) * deficit
        reports.append({
            "name": family["name"], "threshold": w, "threshold_slope": W,
            "ratio_lower": str(factor), "all_full_coefficients_positive": True,
            "suffix_coefficient_positive": True,
            "prefix_coefficients": [str(v) for v in prefix_coefficients],
            "proper_slope_margins": margins,
            "positive_Newton_coefficients": [str(v) for v in newton],
            "sum_full_charge_at_q0": str(total), "suffix_charge_at_q0": str(bs),
            "deficit_at_q0": str(deficit),
        })
    result = {
        "status": "PASS",
        "method": "Independent seed replay; endpoint-derived affine coefficients; Newton forward differences of exact cleared numerators. No producer imports.",
        "proof": "A numerator of degree at most m equals sum_j Delta^j P(0) binom(q,j). Positive differences and binom(q,j)>=0 prove positivity for every integer q>=0.",
        "scope": "All-q first-source lift, charge signs, normalized identity and ratio inequalities. Selected slow-anchor diagnostic is not independently rerun here.",
        "families": reports,
    }
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    output = Path(__file__).with_name("common_suffix_lifting_independent_audit.json")
    result = certify(output=output)
    print(json.dumps({"status": result["status"], "families": len(result["families"]),
                      "output": str(output)}, indent=2))

