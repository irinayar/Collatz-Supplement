#!/usr/bin/env python3
"""Ordered parity counts combined with exact mod-9 endpoint capacities.

For finite nonrepeating actual shortcut paths. Endpoint may repeat or be low.
All inequalities are certified using integers, upward rounding and fractions.
"""

import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import time

from ordered_canonical_bound import minimum_ones, verify_power_rounding, fraction_record


RESIDUES = (1, 2, 4, 5, 7, 8)
ZERO = (0,) * 6


def shell_counts_mod9(level, length, maximum_ones, thresholds):
    offset = length + 1 - level
    assert offset >= 1
    dp = [ZERO] * (maximum_ones + 1)
    dp[1] = (0, 0, 0, 1, 0, 0)  # v after first odd bit is 1/2=5 mod9.
    for i in range(2, length + 1):
        lo = max(1, thresholds[i-offset] if i > offset else 0)
        hi = min(i, maximum_ones)
        nxt = [ZERO] * (maximum_ones + 1)
        for s in range(lo, hi + 1):
            a, b = dp[s], dp[s-1]
            nxt[s] = (a[1], a[2]+b[0]+b[2]+b[4], a[5],
                      a[0], a[3], a[4]+b[1]+b[3]+b[5])
        dp = nxt
    return dp


def class_capacity(n, s, residue):
    p = 3 ** s
    low, high = max(n, p+1), 2*p-1
    first = low + (residue-low) % 9
    count = max(0, (high-first)//9+1)
    return first, count


def weighted_units(n, J, s, j, first, consumed, count, chunks, precision):
    pieces = min(chunks, count)
    total = 0
    for part in range(pieces):
        left, right = count*part//pieces, count*(part+1)//pieces
        endpoint = first + 9*(consumed+left)
        numerator = 3*n*3**s*(right-left)*(1 << precision)
        denominator = (3*n-J)*(1 << j)*endpoint
        total += (numerator+denominator-1)//denominator
    return total, pieces


def exp_upper(value, degree=12):
    assert 0 <= value < degree+2
    term, total = Q(1), Q(1)
    for k in range(1, degree+1):
        term *= value/k
        total += term
    first_omitted = term*value/(degree+1)
    return total + first_omitted/(1-value/(degree+2))


def certify(*, level=71, maximum_length=512, maximum_ones=256,
            endpoint_chunks=64, precision=96, output=None):
    if not __debug__:
        raise RuntimeError("Assertions are required; do not use -O or -OO.")
    assert 2 <= level <= maximum_length and 2 <= maximum_ones <= maximum_length
    assert endpoint_chunks >= 1 and precision >= 1
    n, J, S = 1 << level, maximum_length, maximum_ones
    assert J < 3*n
    started = time.monotonic()
    verify_power_rounding(level, J)
    thresholds = minimum_ones(level)
    first = [[0]*6 for _ in range(S+1)]
    caps = [[0]*6 for _ in range(S+1)]
    for s in range(1, S+1):
        for a, residue in enumerate(RESIDUES):
            first[s][a], caps[s][a] = class_capacity(n,s,residue)
    assert sum(caps[1]) == 0  # Only rows s>=2 may use the mod9 endpoint identity.
    remaining = [row[:] for row in caps]
    units = [[0]*6 for _ in range(S+1)]
    filled = [[None]*6 for _ in range(S+1)]
    chosen_cells = rounding_terms = 0
    for j in range(level,J+1):
        counts = shell_counts_mod9(level,j,S,thresholds)
        for s in range(2,min(j,S)+1):
            for a in range(6):
                used = min(remaining[s][a],counts[s][a])
                if not used:
                    continue
                value,terms = weighted_units(
                    n,J,s,j,first[s][a],caps[s][a]-remaining[s][a],used,
                    endpoint_chunks,precision)
                units[s][a] += value
                remaining[s][a] -= used
                chosen_cells += 1
                rounding_terms += terms
                if remaining[s][a] == 0:
                    filled[s][a] = j
    finite = Q(sum(map(sum,units)),1 << precision)
    length_tail = Q(sum(map(sum,remaining)),1 << (J+1))
    a=Q(193,200)**3
    assert 9*a-3>0 and (9*a-3)**2>32*a*a
    odd_tail = Q(200,7)*Q(193,200)**(S+1)
    boundary = Q(level+1,1 << (level-1))
    bound = finite+length_tail+odd_tail+boundary
    rational_display_cap = Q((bound.numerator*1000000+bound.denominator-1)//bound.denominator,1000000)
    product_cap = exp_upper(rational_display_cap/3)
    theorem_reciprocal_cap = Q(144,125)
    theorem_log_cap = theorem_reciprocal_cap/3
    theorem_exp_majorant = exp_upper(theorem_log_cap,degree=10)
    theorem_product_cap = Q(47,32)
    default_parameters = (level,J,S,endpoint_chunks,precision)==(71,512,256,64,96)
    if default_parameters:
        assert bound < theorem_reciprocal_cap
        assert theorem_exp_majorant < theorem_product_cap < Q(3,2)
    result={
        "status":"PASS","level":level,"minimum_input":"2^"+str(level),
        "J":J,"S":S,"endpoint_modulus":9,"endpoint_classes":list(RESIDUES),
        "endpoint_chunks":endpoint_chunks,"precision":precision,
        "chosen_cells":chosen_cells,"upward_rounding_terms":rounding_terms,
        "finite_endpoint_weight":fraction_record(finite),
        "uninspected_length_tail":fraction_record(length_tail),
        "large_odd_count_tail":fraction_record(odd_tail),
        "terminal_boundary":fraction_record(boundary),
        "reciprocal_upper":fraction_record(bound),
        "clean_rational_reciprocal_upper":str(rational_display_cap),
        "product_upper":fraction_record(product_cap),
        "product_less_than_three_halves":product_cap<Q(3,2),
        "clean_theorem_constants":{
            "reciprocal_cap":str(theorem_reciprocal_cap),
            "log_product_cap":str(theorem_log_cap),
            "degree_10_exponential_majorant":fraction_record(theorem_exp_majorant),
            "product_cap":str(theorem_product_cap),
            "proved_for_this_run":bool(bound<theorem_reciprocal_cap and theorem_exp_majorant<theorem_product_cap),
        },
        "rows":[{
            "odd_count":s,"classes":[{
                "residue":residue,"first_endpoint":str(first[s][a]),
                "endpoint_capacity":str(caps[s][a]),"capacity_left":str(remaining[s][a]),
                "filled_at_length":filled[s][a],"weight_units":str(units[s][a])
            } for a,residue in enumerate(RESIDUES)]
        } for s in range(1,S+1)],
        "scope":"All finite actual shortcut paths with pairwise distinct inputs at least the stated floor; final output unrestricted. Exact joint parity-order and mod9 endpoint counts; no random-parity assumption. Infinite tails are bounded analytically.",
    }
    if output:
        Path(output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({
        "status":"PASS","level":level,"J":J,"S":S,
        "finite_display_only":float(finite),"length_tail_display_only":float(length_tail),
        "odd_tail_display_only":float(odd_tail),"reciprocal_display_only":float(bound),
        "clean_reciprocal_cap":str(rational_display_cap),
        "product_upper_display_only":float(product_cap),
        "product_below_three_halves_exact":product_cap<Q(3,2),
        "seconds":time.monotonic()-started,
    }))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--level",type=int,default=71)
    p.add_argument("--maximum-length",type=int,default=512)
    p.add_argument("--maximum-ones",type=int,default=256)
    p.add_argument("--endpoint-chunks",type=int,default=64)
    p.add_argument("--output",type=Path,default=Path(__file__).with_name("residue_canonical_certificate.json"))
    args=p.parse_args()
    certify(level=args.level,maximum_length=args.maximum_length,maximum_ones=args.maximum_ones,
            endpoint_chunks=args.endpoint_chunks,output=args.output)


if __name__=="__main__":
    main()
