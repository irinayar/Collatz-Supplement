#!/usr/bin/env python3
"""Exact ordered canonical-row packing, plus an analytic tail.

The finite DP counts necessary parity codes, not actual trajectories.
Canonical endpoint capacities require a single nonrepeating shortcut path.
Only Python standard-library integers and fractions decide inequalities.
"""

import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import time


def verify_power_rounding(level, maximum_length):
    n = 1 << level
    a, b, p = 1, 1, 1
    for r in range(1, maximum_length + 1):
        a *= 3 * n + 1
        b *= n
        p *= 3
        assert a < b * (1 << p.bit_length()), (level, maximum_length, r)
    return True


def minimum_ones(level):
    out = [0] * level
    p, r = 1, 0
    for t in range(1, level):
        while p <= (1 << t):
            p *= 3
            r += 1
        out[t] = r
    return out


def shell_counts(level, length, maximum_ones, thresholds):
    """First bit one; every prefix satisfies 3^r > 2^(i-length-1+level)."""
    offset = length + 1 - level
    assert offset >= 1
    dp = [0] * (maximum_ones + 1)
    dp[1] = 1
    for i in range(2, length + 1):
        lo = max(1, thresholds[i - offset] if i > offset else 0)
        hi = min(i, maximum_ones)
        nxt = [0] * (maximum_ones + 1)
        for r in range(lo, hi + 1):
            nxt[r] = dp[r] + dp[r - 1]
        dp = nxt
    return dp


def endpoint_capacity(n, odd_count):
    p = 3 ** odd_count
    low, high = max(n, p + 1), 2 * p - 1
    if low > high:
        return 0
    return high - low + 1 - (high // 3 - (low - 1) // 3)


def fraction_record(q):
    return {"numerator": str(q.numerator), "denominator": str(q.denominator)}


def kth_positive_unit(index):
    """The index-th positive integer not divisible by 3; index starts at one."""
    assert index >= 1
    return 3 * ((index - 1) // 2) + 1 + ((index - 1) % 2)


def weighted_cell_units(*, n, maximum_length, odd_count, length,
                        already_used, count, chunks, precision):
    """Upper Riemann sum on consecutive admissible endpoints, rounded upward."""
    if count == 0:
        return 0, 0
    p = 3 ** odd_count
    low = max(n, p + 1)
    offset = (low - 1) - (low - 1) // 3
    pieces = min(chunks, count)
    total = 0
    for part in range(pieces):
        left, right = count * part // pieces, count * (part + 1) // pieces
        first = kth_positive_unit(offset + already_used + left + 1)
        numerator = 3 * n * p * (right - left) * (1 << precision)
        denominator = (3 * n - maximum_length) * (1 << length) * first
        total += (numerator + denominator - 1) // denominator
    return total, pieces


def certify(*, level=71, maximum_length=512, maximum_ones=256,
            endpoint_chunks=64, precision=96, output=None):
    if not __debug__:
        raise RuntimeError("Assertions required: do not run with -O or -OO.")
    assert 2 <= level <= maximum_length and 1 <= maximum_ones <= maximum_length
    started = time.monotonic()
    n = 1 << level
    assert maximum_length < 3 * n and endpoint_chunks >= 1 and precision >= 1
    verify_power_rounding(level, maximum_length)
    thresholds = minimum_ones(level)
    caps = [0] + [endpoint_capacity(n, s) for s in range(1, maximum_ones + 1)]
    remaining = caps[:]
    filled_at = [None] * (maximum_ones + 1)
    row_numerators = [0] * (maximum_ones + 1)
    row_weighted_units = [0] * (maximum_ones + 1)
    chosen_cells = 0
    upward_rounding_terms = 0
    for length in range(level, maximum_length + 1):
        counts = shell_counts(level, length, maximum_ones, thresholds)
        shift = maximum_length - length
        for s in range(1, maximum_ones + 1):
            used = min(remaining[s], counts[s])
            if used:
                chosen_cells += 1
                row_numerators[s] += used << shift
                units, terms = weighted_cell_units(
                    n=n, maximum_length=maximum_length, odd_count=s, length=length,
                    already_used=caps[s]-remaining[s], count=used,
                    chunks=endpoint_chunks, precision=precision,
                )
                row_weighted_units[s] += units
                upward_rounding_terms += terms
                remaining[s] -= used
                if remaining[s] == 0:
                    filled_at[s] = length
    finite = Q(sum(row_numerators), 1 << maximum_length)
    beyond_inspected_lengths = Q(sum(remaining), 1 << (maximum_length + 1))
    # r=[3/(9-4sqrt(2))]^(1/3) < 193/200. The prefactor (2/3)^(1/3)<1.
    a = Q(193, 200) ** 3
    assert 9 * a - 3 > 0 and (9 * a - 3) ** 2 > 32 * a * a
    large_odd_count_tail = Q(200, 7) * Q(193, 200) ** (maximum_ones + 1)
    boundary = Q(level + 1, 1 << (level - 1))
    bound = finite + beyond_inspected_lengths + large_odd_count_tail + boundary
    weighted_finite = Q(sum(row_weighted_units), 1 << precision)
    weighted_bound = weighted_finite + beyond_inspected_lengths + large_odd_count_tail + boundary
    rows = [{
        "odd_count": s, "endpoint_capacity": str(caps[s]),
        "capacity_left": str(remaining[s]), "capacity_filled_at_length": filled_at[s],
        "finite_weight_numerator_at_2_to_J": str(row_numerators[s]),
        "weighted_endpoint_units": str(row_weighted_units[s]),
    } for s in range(1, maximum_ones + 1)]
    result = {
        "status": "PASS", "minimum_input": "2^" + str(level),
        "level": level, "maximum_inspected_canonical_length": maximum_length,
        "maximum_inspected_odd_count": maximum_ones, "power_rounding_checks": maximum_length,
        "chosen_nonzero_cells": chosen_cells,
        "finite_row_weight": fraction_record(finite),
        "beyond_inspected_lengths": fraction_record(beyond_inspected_lengths),
        "large_odd_count_tail": fraction_record(large_odd_count_tail),
        "boundary_inputs": fraction_record(boundary),
        "reciprocal_upper": fraction_record(bound),
        "reciprocal_less_than_one": bound < 1,
        "reciprocal_less_than_three_quarters": bound < Q(3, 4),
        "endpoint_chunks_per_cell": endpoint_chunks, "endpoint_weight_precision": precision,
        "upward_rounding_terms": upward_rounding_terms,
        "canonical_block_correction_upper": str(Q(3*n,3*n-maximum_length)),
        "weighted_finite_row_weight": fraction_record(weighted_finite),
        "weighted_reciprocal_upper": fraction_record(weighted_bound),
        "weighted_reciprocal_less_than_one": weighted_bound < 1,
        "weighted_reciprocal_less_than_three_quarters": weighted_bound < Q(3, 4),
        "rows": rows,
        "scope": "All finite nonrepeating shortcut paths whose input states are at least the stated floor. Endpoint unrestricted. Infinite tails are bounded analytically.",
    }
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "status": "PASS", "level": level, "J": maximum_length, "S": maximum_ones,
        "finite_display_only": float(finite), "length_tail_display_only": float(beyond_inspected_lengths),
        "odd_count_tail_display_only": float(large_odd_count_tail),
        "boundary_display_only": float(boundary), "reciprocal_bound_display_only": float(bound),
        "weighted_finite_display_only": float(weighted_finite),
        "weighted_reciprocal_bound_display_only": float(weighted_bound),
        "weighted_less_than_one_exact": weighted_bound < 1,
        "weighted_less_than_three_quarters_exact": weighted_bound < Q(3,4),
        "less_than_one_exact": bound < 1, "less_than_three_quarters_exact": bound < Q(3, 4),
        "seconds": time.monotonic() - started,
    }))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--level", type=int, default=71)
    p.add_argument("--maximum-length", type=int, default=512)
    p.add_argument("--maximum-ones", type=int, default=256)
    p.add_argument("--endpoint-chunks", type=int, default=64)
    p.add_argument("--output", type=Path, default=Path(__file__).with_name("ordered_canonical_certificate.json"))
    args = p.parse_args()
    certify(level=args.level, maximum_length=args.maximum_length,
            maximum_ones=args.maximum_ones, endpoint_chunks=args.endpoint_chunks, output=args.output)


if __name__ == "__main__":
    main()
