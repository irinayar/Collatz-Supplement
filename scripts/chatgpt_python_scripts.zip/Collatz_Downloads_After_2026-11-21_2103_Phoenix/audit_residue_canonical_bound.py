#!/usr/bin/env python3
"""Independent generic-modulus recomputation of the canonical mod-9 bound.

The producer is not imported. Small literal residue blocks check the generic
transition graph; the complete 512-depth packing is then recomputed and every
published row/class entry is compared. All decisions use integers/fractions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import operator
import time
from fractions import Fraction as Q
from math import factorial
from pathlib import Path


RESIDUES = tuple(a for a in range(9) if a % 3)
INDEX = {a: i for i, a in enumerate(RESIDUES)}
INV_TWO = pow(2, -1, 9)
ZERO_DEST = tuple(INDEX[(INV_TWO * a) % 9] for a in RESIDUES)
ONE_DEST = tuple(INDEX[(INV_TWO * (3 * a + 1)) % 9] for a in RESIDUES)


def thresholds(level: int) -> list[int]:
    return [0] + [next(r for r in range(1, level + 1) if 3 ** r > 2 ** k)
                  for k in range(1, level)]


def generic_cells(level: int, length: int, maximum_ones: int,
                  minimum: list[int]) -> list[list[int]]:
    """Residue-major arrays, generated from the maps rather than six formulas."""
    size = maximum_ones + 1
    current = [[0] * size for _ in RESIDUES]
    current[INDEX[INV_TWO]][1] = 1
    for position in range(2, length + 1):
        exponent = position - length - 1 + level
        low = 1 if exponent <= 0 else minimum[exponent]
        high = min(position, maximum_ones)
        following = [[0] * size for _ in RESIDUES]
        # Bit zero is a permutation on unit residues and preserves the count.
        for source, target in enumerate(ZERO_DEST):
            following[target][low:high + 1] = current[source][low:high + 1]
        # Bit one increments the odd count and follows its generic residue map.
        for source, target in enumerate(ONE_DEST):
            following[target][low:high + 1] = list(map(
                operator.add,
                following[target][low:high + 1],
                current[source][low - 1:high],
            ))
        current = following
    return current


def integer_barrier(odd_count: int, exponent: int) -> bool:
    return exponent < 0 or 3 ** odd_count > 2 ** exponent


def small_literal_checks() -> dict:
    checked_sources = checked_cells = zero_endpoint_identities = 0
    levels = (3, 5, 8)
    for length in range(3, 15):
        counts = {L: [[0] * (length + 1) for _ in RESIDUES]
                  for L in levels if L <= length}
        distinct_words = set()
        for x in range(2 ** length + 1, 2 ** (length + 1), 2):
            state = x
            affine_offset = 0
            ones = 0
            prefix_ones = []
            word = []
            shortcut_states = [state]
            for _ in range(length):
                bit = state & 1
                word.append(bit)
                ones += bit
                prefix_ones.append(ones)
                affine_offset = (INV_TWO * ((3 * affine_offset + 1)
                                            if bit else affine_offset)) % 9
                state = (3 * state + 1) // 2 if bit else state // 2
                shortcut_states.append(state)
            assert tuple(word) not in distinct_words
            distinct_words.add(tuple(word))
            assert 3 ** ones < state < 2 * 3 ** ones
            assert state % 3 and affine_offset in INDEX
            if ones >= 2:
                assert state % 9 == affine_offset
                zero_endpoint_identities += 1
            for L, table in counts.items():
                allowed = all(integer_barrier(r, i - length - 1 + L)
                              for i, r in enumerate(prefix_ones, 1))
                if allowed:
                    table[INDEX[affine_offset]][ones] += 1
                # At L>=5 the rounding comparisons through length14 hold.
                if L >= 5 and min(shortcut_states) >= 2 ** L:
                    assert allowed
            checked_sources += 1
        assert len(distinct_words) == 2 ** (length - 1)
        for L, table in counts.items():
            actual = generic_cells(L, length, length, thresholds(L))
            assert actual == table, (L, length)
            checked_cells += len(RESIDUES) * (length + 1)
    for L in (5, 8):
        for r in range(1, 15):
            assert (3 * 2 ** L + 1) ** r < 2 ** (L * r + (3 ** r).bit_length())
    return {'literal_sources': checked_sources,
            'residue_count_cells': checked_cells,
            'actual_endpoint_mod9_identities': zero_endpoint_identities,
            'maximum_canonical_length': 14, 'levels': list(levels)}


def class_range(n: int, s: int, residue: int) -> tuple[int, int]:
    low, high = max(n, 3 ** s + 1), 2 * 3 ** s - 1
    first = residue + 9 * (-((residue - low) // 9))
    assert first >= low and first % 9 == residue and first - 9 < low
    count = 0 if low > high else (high - residue) // 9 - (low - 1 - residue) // 9
    assert count >= 0
    return first, count


def exact_exp_cap(x: Q, degree: int = 16) -> Q:
    polynomial = sum((x ** k / factorial(k) for k in range(degree + 1)), Q(0))
    first_omitted = x ** (degree + 1) / factorial(degree + 1)
    return polynomial + first_omitted / (1 - x / (degree + 2))


def read_fraction(record: dict) -> Q:
    return Q(int(record['numerator']), int(record['denominator']))


def certify(*, producer_path: Path | None = None,
            output: Path | None = None) -> dict:
    if not __debug__:
        raise RuntimeError('Assertions required; do not run with -O.')
    started = time.monotonic()
    here = Path(__file__).resolve().parent
    producer_path = producer_path or here / 'residue_canonical_certificate.json'
    producer_bytes = producer_path.read_bytes()
    producer = json.loads(producer_bytes)
    L, J, S = producer['level'], producer['J'], producer['S']
    chunks, precision = producer['endpoint_chunks'], producer['precision']
    assert (L, J, S, chunks, precision) == (71, 512, 256, 64, 96)
    n = 2 ** L
    assert 2 <= S <= J < 3 * n
    assert producer['endpoint_classes'] == list(RESIDUES)
    toy = small_literal_checks()
    # Different evaluation from the producer's running power products.
    for r in range(1, J + 1):
        assert pow(3 * n + 1, r) < 1 << (L * r + pow(3, r).bit_length())
    minimum = thresholds(L)
    ranges = [[class_range(n, s, a) for a in RESIDUES] for s in range(S + 1)]
    remaining = [[count for first, count in row] for row in ranges]
    weight = [[0] * len(RESIDUES) for _ in range(S + 1)]
    filled = [[None] * len(RESIDUES) for _ in range(S + 1)]
    assert not any(remaining[1])
    chosen_cells = rounding_terms = 0
    scaled_numerators = [(3 * n * 3 ** s) << precision for s in range(S + 1)]
    for length in range(L, J + 1):
        cells = generic_cells(L, length, S, minimum)
        denominator_base = (3 * n - J) << length
        for s in range(2, min(length, S) + 1):
            for index in range(len(RESIDUES)):
                used = min(remaining[s][index], cells[index][s])
                if not used:
                    continue
                first, capacity = ranges[s][index]
                consumed = capacity - remaining[s][index]
                subdivisions = min(chunks, used)
                subtotal = 0
                for block in range(subdivisions):
                    left = (used * block) // subdivisions
                    right = (used * (block + 1)) // subdivisions
                    endpoint = first + 9 * (consumed + left)
                    denominator = denominator_base * endpoint
                    quotient, remainder = divmod(scaled_numerators[s] * (right - left), denominator)
                    subtotal += quotient + bool(remainder)
                weight[s][index] += subtotal
                remaining[s][index] -= used
                rounding_terms += subdivisions
                chosen_cells += 1
                if remaining[s][index] == 0:
                    filled[s][index] = length
    for row in producer['rows']:
        s = row['odd_count']
        for index, cell in enumerate(row['classes']):
            assert cell['residue'] == RESIDUES[index]
            first, cap = ranges[s][index]
            assert int(cell['first_endpoint']) == first, (s, index, 'first')
            assert int(cell['endpoint_capacity']) == cap, (s, index, 'capacity')
            assert int(cell['capacity_left']) == remaining[s][index], (s, index, 'remaining')
            assert cell['filled_at_length'] == filled[s][index], (s, index, 'filled')
            assert int(cell['weight_units']) == weight[s][index], (s, index, 'weight')
    assert chosen_cells == producer['chosen_cells']
    assert rounding_terms == producer['upward_rounding_terms']
    finite = Q(sum(map(sum, weight)), 2 ** precision)
    length_tail = Q(sum(map(sum, remaining)), 2 ** (J + 1))
    a = Q(193, 200) ** 3
    assert 9 * a > 3 and (9 * a - 3) ** 2 > 32 * a * a
    odd_tail = Q(200, 7) * Q(193, 200) ** (S + 1)
    boundary = Q(L + 1, 2 ** (L - 1))
    full = finite + length_tail + odd_tail + boundary
    assert finite == read_fraction(producer['finite_endpoint_weight'])
    assert length_tail == read_fraction(producer['uninspected_length_tail']) == 0
    assert odd_tail == read_fraction(producer['large_odd_count_tail'])
    assert boundary == read_fraction(producer['terminal_boundary'])
    assert full == read_fraction(producer['reciprocal_upper']) < Q(144, 125)
    exponential = exact_exp_cap(Q(48, 125))
    assert exponential < Q(47, 32) < Q(3, 2)
    assert Q(2075 * 2 ** 60, 2 ** 71) == Q(2075, 2048) > 1
    result = {
        'status': 'PASS',
        'scope': 'Independent full DP and packing recomputation, plus analytic constant checks; no orbit enumeration at the large cutoff.',
        'producer_sha256': hashlib.sha256(producer_bytes).hexdigest(),
        'producer_path': str(producer_path.resolve()),
        'generic_zero_destinations': [RESIDUES[i] for i in ZERO_DEST],
        'generic_one_destinations': [RESIDUES[i] for i in ONE_DEST],
        'small_literal_controls': toy,
        'power_rounding_comparisons': J,
        'shells_recomputed': J - L + 1,
        'row_class_records_compared': S * len(RESIDUES),
        'chosen_cells': chosen_cells, 'upward_rounding_terms': rounding_terms,
        'finite_units_at_2_to_96': str(sum(map(sum, weight))),
        'length_tail_exact': '0',
        'reciprocal_strict_upper': '144/125',
        'log_correction_strict_upper': '48/125',
        'correction_product_strict_upper': '47/32',
        'exact_Taylor_exponential_upper': str(exponential),
        'minimum_input': '2^71',
        'hypothesis': 'All shortcut inputs are distinct and at least2^71; final output unrestricted.',
        'seconds_display_only': time.monotonic() - started,
    }
    if output is not None:
        output.write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument('--producer', type=Path, default=here / 'residue_canonical_certificate.json')
    parser.add_argument('--output', type=Path, default=here / 'residue_canonical_independent_audit.json')
    arguments = parser.parse_args()
    result = certify(producer_path=arguments.producer, output=arguments.output)
    print(json.dumps({key: result[key] for key in (
        'status', 'shells_recomputed', 'row_class_records_compared',
        'reciprocal_strict_upper', 'correction_product_strict_upper',
        'seconds_display_only')}, indent=2))
