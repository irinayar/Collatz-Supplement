#!/usr/bin/env python3
"""Small exact controls for the seven incoming K147/K148-era audit notes.

No supplied verifier is imported.  These finite checks do not prove a CLT,
estimate a survival constant, or replace the analytic proof in the audit note.
All output stays next to this script.  Existing artifacts are read only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from fractions import Fraction
from math import comb
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bits(value: int, length: int) -> tuple[int, ...]:
    return tuple((value >> j) & 1 for j in range(length))


def survives(word: tuple[int, ...], initial_one: bool = True) -> bool:
    r = 0
    for j, bit in enumerate(word, 1):
        r += bit
        if initial_one:
            if 3 ** (r + 1) < 2 ** j:
                return False
        elif 3 ** r <= 2 ** (j - 1):
            return False
    return True


def exact_word_controls() -> dict:
    natural = {2: {2: 1}}
    for m in range(3, 257):
        prev = natural[m - 1]
        natural[m] = {
            r: prev.get(r, 0) + prev.get(r - 1, 0)
            for r in range(m + 1)
            if 3 ** r > 2 ** (m - 1)
        }
    published = json.loads((ROOT / 'continued_source_work/continuation_order/ordered_profile_certificate.json').read_text())
    for row in published['prefix_tables']:
        if row['length'] <= 256:
            assert sum(natural[row['length']].values()) == row['natural_initial11_prefixes']
    enumerated = surviving = endpoint_checks = 0
    rows = []
    for m in range(3, 17):
        h = m // 3
        middle = m - 2 * h
        assert 5 * h >= m and 3 * middle >= m
        endpoint_counts = Counter()
        natural_count = 0
        for value in range(1 << m):
            word = bits(value, m)
            enumerated += 1
            if word[:2] == (1, 1) and survives(word, False):
                natural_count += 1
            if not survives(word):
                continue
            surviving += 1
            r = sum(word)
            endpoint_counts[r] += 1
            # The last block, reversed and negated, survives from 1+r-qm.
            for j in range(1, h + 1):
                remaining_ones = r - sum(word[m - j:])
                assert 3 ** (1 + remaining_ones) >= 2 ** (m - j)
        assert natural_count == sum(natural[m].values())
        first_counts = Counter(sum(w) for v in range(1 << h)
                               if survives(w := bits(v, h)))
        for r in range(m + 1):
            last_counts = Counter()
            for v in range(1 << h):
                w = bits(v, h)
                allowed = True
                for j in range(1, h + 1):
                    exponent = 1 + r - sum(w[h - j:])
                    if exponent < 0 or 3 ** exponent < 2 ** (m - j):
                        allowed = False
                        break
                if allowed:
                    last_counts[sum(w)] += 1
            outer_middle_bound = 0
            for a, ca in first_counts.items():
                for b, cb in last_counts.items():
                    middle_ones = r - a - b
                    if 0 <= middle_ones <= middle:
                        outer_middle_bound += ca * cb * comb(middle, middle_ones)
            assert endpoint_counts[r] <= outer_middle_bound
            endpoint_checks += 1
        rows.append({'m': m, 'natural_initial11_count': natural_count,
                     'relaxed_survivors': sum(endpoint_counts.values())})
    assert enumerated == 131064 and surviving == 22492
    assert sum(natural[10].values()) == 120
    assert sum(natural[16].values()) == 4515
    assert sum(natural[20].values()) == 54098
    return {'enumerated_words': enumerated, 'relaxed_surviving_words': surviving,
            'endpoint_count_checks': endpoint_checks,
            'natural_recurrence_rows_matched_to_saved_certificate': 255,
            'rows': rows}


def shortcut_parities(x: int, m: int) -> tuple[int, ...]:
    result = []
    for _ in range(m):
        result.append(x & 1)
        x = (3 * x + 1) // 2 if x & 1 else x // 2
    return tuple(result)


def finite_injections() -> dict:
    residue_checks = 0
    for m in range(1, 13):
        images = {shortcut_parities(x, m) for x in range(1 << m)}
        assert len(images) == 1 << m
        residue_checks += 1 << m
    queries = genuine = profile_pairs = short_codes = long_codes = maximum_steps = 0
    overlaps = []
    saved = json.loads((ROOT / 'continued_source_work/continuation_order/ordered_profile_certificate.json').read_text())
    saved_rows = {r['n']: r for r in saved['rows']}
    for n in range(3, 1024, 2):
        H = (4 * n - 2) // 3
        m = H.bit_length()
        profiles = {}
        for u in range(n, H + 1, 2):
            queries += 1
            x = u
            word = []
            for _ in range(512):
                z = 3 * x + 1
                e = (z & -z).bit_length() - 1
                x = z >> e
                word.append(e)
                if x <= H:
                    break
            else:
                raise AssertionError(('unresolved bounded query', n, u))
            maximum_steps = max(maximum_steps, len(word))
            if x >= n:
                genuine += 1
                profiles.setdefault(tuple(word), u)
        images = ({}, {})
        for word, u in profiles.items():
            raw = tuple(bit for e in word for bit in (1,) + (0,) * (e - 1))
            is_long = len(raw) >= m
            code = raw[:m] if is_long else raw + (1,) * (m - len(raw))
            which = int(is_long)
            assert code not in images[which]
            assert code[:2] == (1, 1) and survives(code, False)
            if is_long:
                assert code == shortcut_parities(u, m)
            else:
                assert m - tuple(reversed(code)).index(0) == len(raw)
            images[which][code] = word
        short_codes += len(images[0])
        long_codes += len(images[1])
        profile_pairs += len(profiles)
        assert len(profiles) == saved_rows[n]['active_profiles']
        assert len(images[0]) == saved_rows[n]['short_profiles']
        assert len(images[1]) == saved_rows[n]['long_profiles']
        for code in images[0].keys() & images[1].keys():
            overlaps.append({'n': n, 'code': ''.join(map(str, code)),
                             'short': list(images[0][code]), 'long': list(images[1][code])})
    expected = {563, 565, 567}
    # The incoming note lists examples, not an exhaustive overlap classification.
    assert expected <= {r['n'] for r in overlaps}
    assert residue_checks == 8190
    assert (queries, genuine, profile_pairs, short_codes, long_codes, maximum_steps) == (
        43776, 6513, 3551, 2336, 1215, 51)
    return {'residue_checks': residue_checks, 'thresholds': 511,
            'first_hit_queries': queries, 'genuine_source_returns': genuine,
            'active_profile_threshold_pairs': profile_pairs,
            'short_codes': short_codes, 'long_codes': long_codes,
            'maximum_first_hit_steps': maximum_steps, 'overlaps': overlaps}


def exact_artifact_controls() -> dict:
    package = ROOT / 'deliverables/Collatz_Ordered_Parity_Research_2026-11-21_190057'
    expected = {
        ROOT / 'deliverables/Collatz_Method_Combinations_2026-11-21_193047/From-ChatGPT_2026-11-21_193047_Method_Combinations.md': 'b5e8429d6c900cc0b0a8f64b20d8e73329a12f64bd2c6edbf50a3bdd79de951a',
        package / 'continuation_analytic/Parity_Code_Profile_Theorem.md': 'c79331edc78636e996c004198e26b53d55691b3bbf3ac1a8f2bea81b24a97601',
        package / 'continuation_order/Ordered_Parity_Profile_Theorem.md': 'f9836fc86c3d92ef0e6db549477e934203db6190a0a53b312d8179efa8b3142d',
        ROOT / 'upload/From-Claude_2026-11-21_202003.md': 'a68c1159949370f2eb4e8e87a660c2fc7aa30b714dc52f49deed174c6106f442',
        ROOT / 'upload/From-Claude_2026-11-21_202700.md': '0ecd3a0493638186fd0142e3558b7e6e6df32b7b8039cde1d800b97e6bd4fdad',
        ROOT / 'upload/From-Claude_2026-11-21_203528.md': 'febb65537708d9692c59d3e6edebe8e18b0d205adf92c765fac6f3ac4ac8876e',
        ROOT / 'upload/From-Claude_2026-11-21_204307.md': 'bcf9b90503c99c3355d13c3b651bfca9c08c8a22d92270aa5e47fd8ccf7a5054',
    }
    for path, value in expected.items():
        assert sha256(path) == value, str(path)
    c4 = json.loads((package / 'continuation_four_reset/four_reset_certificate.json').read_text())
    analytic = c4['analytic']
    assert (analytic['considered_prefixes'], analytic['retained_tree_nodes'],
            analytic['excluded_prefixes'], analytic['retained_depth_10_prefixes'],
            analytic['selected_prefixes']) == (1420, 1223, 197, 594, 244)
    assert analytic['selected_depth_counts'] == {'7': 1, '8': 34, '9': 45, '10': 164}
    assert Fraction(analytic['short_upper_numerator'], 2 ** 96) < Fraction(32661310, 10 ** 9)
    assert Fraction(analytic['total_upper']) < Fraction(9, 125)
    assert c4['finite']['positive_source_intervals'] == 5739
    assert Fraction(c4['finite']['exact_maximum_source_sum']) == Fraction(17741, 439425)
    assert Fraction(23, 2025) + Fraction(1, 63) + Fraction(11, 837) == Fraction(17741, 439425)
    assert Fraction(24325110, 16899989) < Fraction(3, 2)
    assert Fraction(299, 200) - Fraction(13299, 8900) == Fraction(13, 17800)
    assert Fraction(71, 250) + Fraction(89, 48 * 118) == Fraction(212197, 708000)
    assert Fraction(7 * 2 ** 56, 3 ** 37) - 1 == Fraction(54119252374498189, 450283905890997363)
    assert Fraction(4) - (Fraction(9, 8) + Fraction(55, 24)) == Fraction(7, 12)
    assert Fraction(8, 3) + Fraction(5, 3 * 9) == Fraction(77, 27) < 4
    return {'matched_hashes': {str(p.relative_to(ROOT)): h for p, h in expected.items()},
            'C1_at_n9': '77/27', 'minimum_gap_4k_minus_rough_Ck_bound': '7/12',
            'source_27_exact_boundary': '54119252374498189/450283905890997363',
            'C4_source_maximum': '17741/439425',
            'C4_rounded_short_part_strictly_below_decimal': '0.032661310',
            'scope': 'Certificate comparison and exact arithmetic only; C4 and gap10 censuses not rerun.'}


def saved_path_sign_controls() -> dict:
    """Reclassify cached, previously certified path prefixes; no new walk."""
    path = ROOT / 'continued_source_work/first_source_work/certificates/unrestricted_finite_boundary.json'
    prior = json.loads(path.read_text())
    counts = Counter()
    positive_profiles = set()
    max_resets = 0
    neutral_lengths = set()
    for row in prior['source_first_descent_paths']:
        u = x = row['u']
        proper_min = None
        E = B = resets = 0
        prefix = []
        for e in row['word']:
            B = 3 * B + 2 ** E
            E += e
            resets += e >= 2
            prefix.append(e)
            g = len(prefix)
            numerator = 3 * x + 1
            assert numerator % (2 ** e) == 0
            x = numerator // (2 ** e)
            assert x & 1
            lo = max(3, (3 * max(u, x) + 5) // 4)
            hi = min(u, x, 65535)
            if proper_min is not None:
                hi = min(hi, (3 * proper_min + 1) // 4)
            lo += not (lo & 1)
            hi -= not (hi & 1)
            if lo <= hi:
                c_numerator = B + 5 * (2 ** E - 3 ** g)
                sign = (c_numerator > 0) - (c_numerator < 0)
                counts[('all', sign)] += 1
                if g <= 10 or resets <= 4:
                    counts[('C4', sign)] += 1
                if sign > 0:
                    positive_profiles.add(tuple(prefix))
                    max_resets = max(max_resets, resets)
                if sign == 0:
                    neutral_lengths.add(g)
                    assert prefix == [1, 2]
            proper_min = x if proper_min is None else min(proper_min, x)
        assert x == row['first_strict_descent'] < u
    assert counts['C4', 1] == 5739
    assert counts['C4', -1] + counts['C4', 0] == 5932
    assert counts['all', 1] == 6757 and len(positive_profiles) == 1767
    assert max_resets == 32 and neutral_lengths == {2}
    return {'scope': 'Exact reclassification of existing certified path data; not a new independent source census.',
            'C4_positive': counts['C4', 1], 'C4_negative': counts['C4', -1],
            'C4_zero': counts['C4', 0],
            'C4_negative_or_zero': counts['C4', -1] + counts['C4', 0],
            'all_positive_intervals': counts['all', 1],
            'all_distinct_positive_profiles': len(positive_profiles),
            'maximum_positive_reset_count': max_resets,
            'neutral_genuine_return_lengths_in_saved_range': sorted(neutral_lengths)}


def certify(*, input_root=None, output=None) -> dict:
    global ROOT
    ROOT = (Path(input_root).resolve() if input_root is not None
            else Path(__file__).resolve().parent.parent)
    if not __debug__:
        raise RuntimeError("Assertions are required; do not use -O or -OO.")
    result = {'status': 'PASS', 'scope': 'Focused K147/K148 controls; no asymptotic constants inferred from finite tests.',
              'exact_word_controls': exact_word_controls(),
              'finite_injections': finite_injections(),
              'saved_path_sign_controls': saved_path_sign_controls(),
              'artifact_controls': exact_artifact_controls()}
    output = (Path(output) if output is not None
              else Path(__file__).with_name('incoming_notes_exact_checks.json'))
    output.write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path,
                        help='Root containing the unchanged relative paths in incoming_notes_required_inputs.json.')
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('incoming_notes_exact_checks.json'))
    args = parser.parse_args()
    result = certify(input_root=args.input_root, output=args.output)
    print(json.dumps({'status': result['status'],
                      'output': str(args.output),
                      'words': result['exact_word_controls']['enumerated_words'],
                      'survivors': result['exact_word_controls']['relaxed_surviving_words'],
                      'queries': result['finite_injections']['first_hit_queries']}, indent=2))
