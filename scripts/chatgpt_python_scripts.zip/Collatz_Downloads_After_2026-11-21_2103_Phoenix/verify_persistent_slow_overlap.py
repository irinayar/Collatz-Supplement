#!/usr/bin/env python3
"""Exact certificate for an infinite large-threshold slow-overlap family."""

from datetime import datetime, timedelta, timezone
from fractions import Fraction
from pathlib import Path
import json

if not __debug__:
    raise SystemExit("Assertions are required; do not use -O or -OO.")

N0 = 15611
WORDS = (
    (1,2,1,1,1,1,1,1,2,2,2,1,1,1,5,1,2,1,2,3),
    (1,1,1,1,2,3,2,1,1,1,1,1,1,2,2,2,1,1,1,5,1,2,1,2,3),
)


def shortcut(x):
    return (3*x+1)//2 if x & 1 else x//2


def odd_step(x):
    z=3*x+1
    return z >> ((z & -z).bit_length()-1)


def slow(x):
    z=x
    for _ in range((x-1).bit_length()):
        z=shortcut(z)
        if 2*z<x:
            return False
    return True


def backward_coefficients(word):
    coeff=[None]*(len(word)+1)
    coeff[-1]=(Fraction(1),Fraction(0))
    for j in range(len(word)-1,-1,-1):
        lam,beta=coeff[j+1]
        coeff[j]=(Fraction(2**word[j],3)*lam,(2**word[j]*beta+1)/3)
    return coeff


def values(coeff,n):
    ans=[a*n-b for a,b in coeff]
    assert all(v.denominator==1 and v>0 for v in ans)
    return [int(v) for v in ans]


def sign_persists(coeff,j,k,sign):
    """Certify sign of 2*x_k(n)-x_j(n) for all n>=N0."""
    a=2*coeff[k][0]-coeff[j][0]
    at_base=a*N0-(2*coeff[k][1]-coeff[j][1])
    assert sign*a>0 and sign*at_base>0


def selected_slow(path):
    selected=[];i=0;g=len(path)-1
    while i<g:
        x=path[i]
        if slow(x):
            selected.append(x);i+=1
        else:
            j=i+1
            while j<=g and 2*path[j]>=x:
                j+=1
            assert j<=g
            i=j
    return selected


def main():
    Q=3**25
    assert 23*Q<2**45
    assert 3**256-1>23*Q*2**300
    fixed=[]
    coefficients=[]
    for index,word in enumerate(WORDS):
        g=len(word);E=sum(word);coeff=backward_coefficients(word)
        path=values(coeff,N0)
        assert path[0]==(19227,20255)[index]
        assert all(odd_step(a)==b for a,b in zip(path,path[1:]))
        a,b=coeff[0]
        assert 1<a<Fraction(4,3)
        assert path[0]>N0 and 4*N0-3*path[0]>2
        assert all(lam>Fraction(4,3) for lam,beta in coeff[1:-1])
        assert all(3*x>4*N0 for x in path[1:-1])
        assert all(lam<23 and beta>0 for lam,beta in coeff[:-1])
        B=int(coeff[0][1]*3**g)
        cnum=B+5*(2**E-3**g)
        assert cnum>0 and 2**E>3**g
        slow_indices=(0,1,2) if index==0 else (0,1,7)
        assert all(coeff[j][0]<2 for j in slow_indices)
        fast_specs=((3,g),) if index==0 else ((2,7),(8,g))
        for j,k in fast_specs:
            assert coeff[j][0]>2 and path[j]>2*N0
            for before in range(j+1,k):
                sign_persists(coeff,j,before,1)
            sign_persists(coeff,j,k,-1)
        fixed.append({'g':g,'E':E,'resets':sum(e>=2 for e in word),
                      'word':list(word),'seed_path':path,'B':B,
                      'positive_coefficient_numerator':cnum,
                      'positive_coefficient_denominator':3**g,
                      'slow_indices':list(slow_indices),
                      'affine_coefficients':[[str(a),str(b)] for a,b in coeff]})
        coefficients.append(coeff)
    assert coefficients[0][2]==coefficients[1][7]

    large_examples=[]
    for R in (256,257,300):
        t=(-15612*pow(Q,-1,2**R))%(2**R)
        n=N0+Q*t
        assert n>=2**R-1 and n%2==1 and n%Q==N0
        C=(n+1)//2**R
        assert (n+1)%2**R==0 and 1<=C<Q
        H=(4*n-2)//3
        case={'R':R,'n':str(n),'H':str(H),'C':str(C),'profiles':[]}
        for item,coeff in zip(fixed,coefficients):
            word=item['word'];path=values(coeff,n);u=path[0]
            assert n<=u<=H and all(x>H for x in path[1:-1])
            assert path[-1]==n
            for x,y,e in zip(path,path[1:],word):
                z=3*x+1
                assert z==(1<<e)*y and y%2==1
                assert ((z&-z).bit_length()-1)==e
            E=item['E'];g=item['g'];B=item['B'];period=2**(E+1)
            assert (u-period)*3**g+B==2**E*(n-2*3**g)
            residue=((2**E-B)*pow(3**g,-1,period))%period
            assert u%period==residue
            chosen=selected_slow(path)
            assert chosen==[path[j] for j in item['slow_indices']]
            case['profiles'].append({'source':str(u),'selected_slow':[str(x) for x in chosen],
                                     'least_source_reason':'Every smaller cylinder lift has endpoint below n.'})
        common=set(case['profiles'][0]['selected_slow']) & set(case['profiles'][1]['selected_slow'])
        assert len(common)==1
        case['shared_slow_anchor']=next(iter(common))
        large_examples.append(case)

    result={'timestamp':datetime.now(timezone(timedelta(hours=-7))).strftime('From-ChatGPT %Y-%m-%d %H:%M:%S America/Phoenix'),
            'status':'passed','fixed_word_certificates':fixed,
            'all_R_hypothesis':'Integer R>=256; endpoints and sources defined in the companion proof.',
            'exact_large_replays':large_examples,
            'symbolic_scope':'Selected slow multiplicity at least two at arbitrarily large thresholds, both profiles residual and least-active.',
            'limitation':'Does not disprove a weighted-overlap bound; this fixed-word family contributes O(log n/n) to the shared slow weight.'}
    destination=Path(__file__).with_name('persistent_slow_overlap_certificate.json')
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'passed','fixed_words':len(fixed),'large_replays':len(large_examples),
                      'destination':str(destination)},indent=2))


if __name__=='__main__':
    main()
