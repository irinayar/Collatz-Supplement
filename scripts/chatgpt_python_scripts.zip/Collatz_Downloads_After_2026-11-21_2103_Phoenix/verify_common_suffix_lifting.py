#!/usr/bin/env python3
"""Exact finite coefficient certificates for all-q first-source overlap lifts.

No unbounded trajectory search is used. Every seed path is replayed from its
listed word. Polynomial coefficient signs prove the stated inequalities for
every integer lift parameter q >= 0. Python 3.8+, standard library; no -O.
"""

from fractions import Fraction as Q
from pathlib import Path
import json


HERE = Path(__file__).resolve().parent


def affine(word):
    exponent = additive = 0
    for e in word:
        assert isinstance(e, int) and e >= 1
        additive = 3 * additive + (1 << exponent)
        exponent += e
    power = 3 ** len(word)
    coefficient = Q(additive + 5 * ((1 << exponent) - power), power)
    return exponent, additive, Q(1 << exponent, power), coefficient


def replay(source, word):
    path = [source]
    for e in word:
        z = 3 * path[-1] + 1
        assert (z & -z).bit_length() - 1 == e
        path.append(z >> e)
    return path


def is_slow(x):
    z = x
    for _ in range((x - 1).bit_length()):
        z = (3 * z + 1) // 2 if z & 1 else z // 2
        if 2 * z < x:
            return False
    return True


def selected_slow(inputs):
    selected = []
    i = 0
    while i < len(inputs):
        x = inputs[i]
        if is_slow(x):
            selected.append(x)
            i += 1
        else:
            i += 1
            while i < len(inputs) and 2 * inputs[i] >= x:
                i += 1
    return selected


def multiply(left, right):
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            result[i + j] += a * b
    return result


def cleared_numerator(coefficients, denominators):
    """Polynomial numerator of sum c_i/(d_i0+d_i1*q), common positive denominator."""
    result = [Q(0)] * len(denominators)
    for i, coefficient in enumerate(coefficients):
        term = [Q(1)]
        for j, denominator in enumerate(denominators):
            if i != j:
                term = multiply(term, denominator)
        for j, value in enumerate(term):
            result[j] += coefficient * value
    return result


def certify(output=None):
    if not __debug__:
        raise RuntimeError("This certificate requires assertions; do not use -O.")
    seeds = json.loads((HERE / 'overlap_seed_profiles.json').read_text())
    families = []
    for seed in seeds:
        gmax = max(len(row['word']) for row in seed['profiles'])
        threshold_slope = 2 * 3**gmax
        high_slope = 8 * 3**(gmax - 1)
        assert 3 * high_slope == 4 * threshold_slope
        arrivals = []
        suffix_words = []
        anchor_slopes = []
        coefficients = []
        denominators = []
        profiles = []
        for row in seed['profiles']:
            u, word = row['source'], row['word']
            path = replay(u, word)
            arrival = path[-1]
            arrivals.append(arrival)
            high = (4 * arrival - 2) // 3
            assert arrival <= u <= high
            assert all(x > high for x in path[1:-1])
            assert len(set(path[:-1])) == len(path) - 1
            g = len(word)
            e, additive, slope, c = affine(word)
            assert g >= 11 and sum(x >= 2 for x in word) >= 5 and c > 0
            modulus = 1 << (e + 1)
            residue = (((1 << e) - additive) * pow(3**g, -1, modulus)) % modulus
            assert u % modulus == residue
            source_slope = modulus * 3**(gmax - g)
            assert threshold_slope <= source_slope <= high_slope
            partial_exponent = 0
            state_slopes = []
            for j, x in enumerate(path):
                if j:
                    partial_exponent += word[j - 1]
                numerator = 3**j * source_slope
                assert numerator % (1 << partial_exponent) == 0
                state_slopes.append(numerator >> partial_exponent)
            assert state_slopes[-1] == threshold_slope
            assert all(v > high_slope for v in state_slopes[1:-1])
            # Every lifted source has the same full parity cylinder. The
            # preceding representative arrives below the chosen threshold.
            assert source_slope % modulus == 0
            assert 3**g * modulus // (1 << e) == 2 * 3**g
            anchor_index = path.index(seed['anchor'])
            assert 0 < anchor_index < g
            prefix_word, suffix_word = word[:anchor_index], word[anchor_index:]
            suffix_words.append(suffix_word)
            anchor_slopes.append(state_slopes[anchor_index])
            ep, bp, ap, cp = affine(prefix_word)
            es, bs, ass, cs = affine(suffix_word)
            assert cs > 0
            assert c == cp + ap * cs
            if seed['all_prefixes_negative']:
                assert cp < 0
            assert seed['anchor'] in selected_slow(path[:-1])
            charge = c / (u + 5)
            prefix_charge = cp / (u + 5)
            suffix_charge = cs / (seed['anchor'] + 5)
            assert 1 + charge == (1 + prefix_charge) * (1 + suffix_charge)
            coefficients.append(c)
            denominators.append([Q(u + 5), Q(source_slope)])
            # Literal small lifts are controls; the coefficient inequalities
            # above are the proof for arbitrary q, without an iteration cap.
            for q in (0, 1, 2):
                lifted = replay(u + source_slope * q, word)
                assert lifted == [a + b * q for a, b in zip(path, state_slopes)]
                nq = arrival + threshold_slope * q
                hq = high + high_slope * q
                assert hq == (4 * nq - 2) // 3
                assert lifted[-1] == nq <= lifted[0] <= hq
                assert all(x > hq for x in lifted[1:-1])
            profiles.append({
                'source': u, 'arrival': arrival, 'word': word, 'path': path,
                'g': g, 'E': e, 'resets': sum(x >= 2 for x in word),
                'source_slope': source_slope,
                'state_slopes': state_slopes,
                'charge_coefficient': str(c),
                'prefix_charge_coefficient': str(cp),
                'charge_at_q0': str(charge),
                'selected_slow_at_q0': selected_slow(path[:-1]),
                'minimum_proper_slope_margin': min(v - high_slope for v in state_slopes[1:-1]),
            })
        assert len(set(arrivals)) == 1
        assert len({tuple(w) for w in suffix_words}) == 1
        assert len(set(anchor_slopes)) == 1
        m = len(profiles)
        anchor_slope = anchor_slopes[0]
        cs = affine(suffix_words[0])[3]
        bs = cs / (seed['anchor'] + 5)
        deficit = sum((-Q(p['prefix_charge_coefficient']) / (p['source'] + 5)
                       for p in profiles), Q(0))
        total = sum((Q(p['charge_at_q0']) for p in profiles), Q(0))
        assert total == m * bs - (1 + bs) * deficit
        factor = Q(seed['factor'])
        polynomial = cleared_numerator(
            coefficients + [-factor * cs],
            denominators + [[Q(seed['anchor'] + 5), Q(anchor_slope)]],
        )
        assert all(x > 0 for x in polynomial)
        families.append({
            'name': seed['name'], 'profile_count': m,
            'n_q_intercept': arrivals[0], 'n_q_slope': threshold_slope,
            'H_q_intercept': (4 * arrivals[0] - 2) // 3, 'H_q_slope': high_slope,
            'anchor_intercept': seed['anchor'], 'anchor_slope': anchor_slope,
            'common_suffix_word': suffix_words[0], 'suffix_coefficient': str(cs),
            'sum_charges_q0': str(total), 'suffix_charge_q0': str(bs),
            'prefix_deficit_q0': str(deficit),
            'deficit_required_for_one_copy_q0': str((m - 1) * bs / (1 + bs)),
            'proved_charge_ratio_lower': str(factor),
            'strict_polynomial_coefficients': [str(x) for x in polynomial],
            'profiles': profiles,
        })
    result = {
        'status': 'PASS',
        'scope': 'Two explicit all-q least-source lifting families; exact common-suffix compensation identities.',
        'families': families,
        'limitations': [
            'Selected slow-anchor overlap is certified at q=0 only.',
            'Each fixed-word family contributes O(1/n_q); these examples do not violate the target budget.',
            'No uniform bound on arbitrary cross-profile multiplicity is asserted.',
        ],
    }
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    result = certify(HERE / 'common_suffix_lifting_certificate.json')
    print(json.dumps({'status': result['status'], 'families': [
        {k: f[k] for k in ('name', 'profile_count', 'n_q_intercept', 'n_q_slope', 'proved_charge_ratio_lower')}
        for f in result['families']
    ]}, indent=2))
