#!/usr/bin/env python3
"""Verify the packaged overlap research in an isolated temporary copy.

Python 3.10+ and the standard library are required.  Run this file from any
working directory.  The bundle root is its parent directory's parent.

The original package is read only: producers, timestamps, and audit outputs
are regenerated exclusively in a temporary copy.  This runs the explicitly
listed new proofs and focused incoming-note controls, not an unlisted broad
historical trajectory census.  Use --preflight-only to check packaging without
rerunning the dynamic-programming certificates.
"""

from __future__ import annotations

import sys

if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required.")
if not __debug__:
    raise SystemExit("Assertions are required; do not run this verifier with -O or -OO.")

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time


RESEARCH_NAME = "overlap_continuation_work"
COPY_DIRECTORIES = (
    RESEARCH_NAME,
    "continued_source_work",
    "deliverables",
    "upload",
)

# Each listed producer is executed, then its newly generated JSON is checked.
# The two secondary audits are included whenever they are present in the bundle.
STEPS = (
    ("mod-9 producer", "residue_canonical_bound.py", "residue_canonical_certificate.json", False),
    ("independent mod-9 audit", "audit_residue_canonical_bound.py", "residue_canonical_independent_audit.json", False),
    ("exact endpoint constants", "verify_residue_endpoint_constants.py", "residue_endpoint_constant_checks.json", False),
    ("common-suffix lifts", "verify_common_suffix_lifting.py", "common_suffix_lifting_certificate.json", False),
    ("independent common-suffix audit", "audit_common_suffix_lifting.py", "common_suffix_lifting_independent_audit.json", True),
    ("persistent slow overlap", "verify_persistent_slow_overlap.py", "persistent_slow_overlap_certificate.json", False),
    ("independent persistent-overlap audit", "audit_persistent_slow_overlap.py", "persistent_slow_overlap_independent_audit.json", True),
    ("focused incoming-note controls", "verify_incoming_notes.py", "incoming_notes_exact_checks.json", False),
)

REQUIRED_INPUTS = (
    f"{RESEARCH_NAME}/ordered_canonical_bound.py",
    f"{RESEARCH_NAME}/overlap_seed_profiles.json",
    "continued_source_work/continuation_order/ordered_profile_certificate.json",
    "continued_source_work/first_source_work/certificates/unrestricted_finite_boundary.json",
    "deliverables/Collatz_Ordered_Parity_Research_2026-11-21_190057/continuation_analytic/Parity_Code_Profile_Theorem.md",
    "deliverables/Collatz_Ordered_Parity_Research_2026-11-21_190057/continuation_order/Ordered_Parity_Profile_Theorem.md",
    "deliverables/Collatz_Ordered_Parity_Research_2026-11-21_190057/continuation_four_reset/four_reset_certificate.json",
    "deliverables/Collatz_Method_Combinations_2026-11-21_193047/From-ChatGPT_2026-11-21_193047_Method_Combinations.md",
    "upload/From-Claude_2026-11-21_202003.md",
    "upload/From-Claude_2026-11-21_202700.md",
    "upload/From-Claude_2026-11-21_203528.md",
    "upload/From-Claude_2026-11-21_204307.md",
)


class VerificationError(RuntimeError):
    pass


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def excluded(name):
    lower = name.lower()
    return name == "__pycache__" or lower.endswith((".zip", ".pyc", ".pyo"))


def copy_ignore(directory, names):
    return [name for name in names if excluded(name)]


def copied_files(root):
    """Enumerate only the research and dependency trees copied by this master."""
    for name in COPY_DIRECTORIES:
        base = root / name
        for current, directories, filenames in os.walk(base, followlinks=False):
            directories[:] = sorted(d for d in directories if not excluded(d))
            current_path = Path(current)
            for item in directories + filenames:
                candidate = current_path / item
                if not excluded(item) and candidate.is_symlink():
                    raise VerificationError("Package symlinks are not supported: " + str(candidate.relative_to(root)))
            for filename in sorted(filenames):
                if not excluded(filename):
                    yield current_path / filename


def snapshot(root):
    result = {}
    for path in copied_files(root):
        info = path.stat()
        result[str(path.relative_to(root))] = (info.st_size, info.st_mtime_ns, digest(path))
    return result


def verify_manifest(root):
    manifest = root / "SHA256SUMS.txt"
    if not manifest.exists():
        return {"present": False, "files_checked": 0}
    checked = set()
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64}) [ *](.+)", line)
        if match is None:
            raise VerificationError("Malformed SHA256SUMS.txt line " + str(number))
        expected, relative = match.groups()
        target = (root / relative).resolve()
        if Path(relative).is_absolute() or not target.is_relative_to(root):
            raise VerificationError("Manifest path escapes the bundle: " + relative)
        if relative in checked:
            raise VerificationError("Duplicate manifest path: " + relative)
        if not target.is_file():
            raise VerificationError("Missing manifest file: " + relative)
        if digest(target) != expected.lower():
            raise VerificationError("SHA256 mismatch: " + relative)
        checked.add(relative)
    if not checked:
        raise VerificationError("SHA256SUMS.txt contains no file entries.")
    return {"present": True, "files_checked": len(checked)}


def preflight(root):
    for directory in COPY_DIRECTORIES:
        if not (root / directory).is_dir():
            raise VerificationError("Missing packaged directory: " + directory)
    required = list(REQUIRED_INPUTS)
    required.extend(f"{RESEARCH_NAME}/{script}" for _, script, _, optional in STEPS if not optional)
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        raise VerificationError("Missing packaged inputs:\n  " + "\n  ".join(missing))
    selected, skipped = [], []
    for step in STEPS:
        label, script, output, optional = step
        if (root / RESEARCH_NAME / script).is_file():
            selected.append(step)
        elif optional:
            skipped.append(script)
        else:
            raise VerificationError("Missing required verifier: " + script)
    return selected, skipped


def successful_status(data, context):
    if not isinstance(data, dict) or str(data.get("status", "")).upper() not in {"PASS", "PASSED", "OK"}:
        raise VerificationError(context + " did not report a successful status.")


def run_step(copied_root, step, timeout):
    label, script, output_name, _ = step
    research = copied_root / RESEARCH_NAME
    output = research / output_name
    # A pre-existing packaged certificate must never mask failure to regenerate.
    if output.exists():
        output.unlink()
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONUNBUFFERED"] = "1"
    environment.pop("PYTHONOPTIMIZE", None)
    started = time.monotonic()
    print("Running " + label + "...", flush=True)
    try:
        process = subprocess.run(
            [sys.executable, "-B", str(research / script)],
            cwd=copied_root, env=environment, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired as error:
        raise VerificationError(label + " exceeded the per-script timeout.") from error
    if process.returncode:
        detail = (process.stderr or process.stdout).strip()[-6000:]
        raise VerificationError(label + " exited with code " + str(process.returncode) + ":\n" + detail)
    try:
        reported = json.loads(process.stdout)
    except json.JSONDecodeError as error:
        raise VerificationError(label + " did not emit valid JSON: " + process.stdout[-2000:]) from error
    successful_status(reported, label + " stdout")
    if not output.is_file():
        raise VerificationError(label + " did not regenerate " + output_name)
    try:
        certificate = json.loads(output.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise VerificationError(label + " generated malformed certificate JSON.") from error
    successful_status(certificate, output_name)
    seconds = time.monotonic() - started
    print("PASS: " + label + " (" + format(seconds, ".2f") + " s)", flush=True)
    return {"script": script, "certificate": output_name, "status": "PASS", "seconds": round(seconds, 3)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preflight-only", action="store_true",
                        help="Check required files and optional hash manifest without running certificate producers.")
    parser.add_argument("--timeout-seconds", type=float, default=300.0,
                        help="Maximum time per verifier subprocess (default: 300 seconds).")
    arguments = parser.parse_args(argv)
    if arguments.timeout_seconds <= 0:
        parser.error("--timeout-seconds must be positive")
    root = Path(__file__).resolve().parent.parent
    if Path(__file__).resolve().parent.name != RESEARCH_NAME:
        raise VerificationError("Keep verify_all.py inside the packaged " + RESEARCH_NAME + " directory.")
    steps, skipped = preflight(root)
    manifest = verify_manifest(root)
    print("Hash manifest: " + (str(manifest["files_checked"]) + " files verified" if manifest["present"] else "not supplied (optional)"), flush=True)
    for name in skipped:
        print("Independent checker not packaged; skipped explicitly: " + name, flush=True)
    if arguments.preflight_only:
        print(json.dumps({"status": "PREFLIGHT_ONLY", "planned_verifiers": len(steps),
                          "optional_checkers_not_packaged": skipped,
                          "mathematical_verification_performed": False}, indent=2))
        return 0

    original = snapshot(root)
    results = []
    started = time.monotonic()
    try:
        with tempfile.TemporaryDirectory(prefix="collatz_overlap_verify_") as temporary:
            copied_root = Path(temporary) / "bundle"
            copied_root.mkdir()
            for directory in COPY_DIRECTORIES:
                shutil.copytree(root / directory, copied_root / directory, ignore=copy_ignore)
            for step in steps:
                results.append(run_step(copied_root, step, arguments.timeout_seconds))
    finally:
        if snapshot(root) != original:
            raise VerificationError("Original package files, contents, or modification timestamps changed during verification.")

    print(json.dumps({
        "status": "PASS", "verifiers_run": len(results),
        "optional_checkers_not_packaged": skipped,
        "hash_manifest": manifest,
        "original_package_unchanged": True,
        "temporary_outputs_removed": True,
        "seconds": round(time.monotonic() - started, 3),
        "scope": "Listed new code-count, exact arithmetic, overlap-lift, and focused incoming-note checks only; no unlisted historical trajectory census.",
        "checks": results,
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except VerificationError as error:
        print("FAIL: " + str(error), file=sys.stderr)
        raise SystemExit(1)
