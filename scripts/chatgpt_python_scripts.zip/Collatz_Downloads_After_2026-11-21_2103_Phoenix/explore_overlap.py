"""Optional bounded exploration of cached records; not a universal proof."""
import collections
import functools
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError('Assertions are required; do not use -O or -OO.')

ROOT = Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'continued_source_work/first_source_work/certificates/unrestricted_finite_boundary.json').read_text())

@functools.lru_cache(None)
def slow(x):
    z=x
    for _ in range((x-1).bit_length()):
        z=(3*z+1)//2 if z&1 else z//2
        if 2*z<x:
            return False
    return True

def path(rec):
    x=rec['u']; result=[x]
    for e in rec['word']:
        z=3*x+1
        assert (z&-z).bit_length()-1==e
        x=z>>e;result.append(x)
    return result

def anchors(values):
    out=[];i=0
    while i<len(values):
        x=values[i]
        if slow(x):
            out.append(x);i+=1
        else:
            i+=1
            while i<len(values) and 2*values[i]>=x:
                i+=1
    return out

events=collections.defaultdict(list)
records=[]
for rec in data['first_source_records']:
    if len(rec['word'])<11 or rec['resets']<5:
        continue
    vals=path(rec)
    selected=anchors(vals[:-1])
    idx=len(records)
    records.append(dict(rec,path=vals,selected=selected))
    for y in selected:
        events[y].append((rec['n_lo'],idx,1))
        events[y].append((rec['n_hi']+2,idx,-1))

best=(0,0,0,[])
top=[]
for y,ev in events.items():
    active=set()
    for n,group in __import__('itertools').groupby(sorted(ev),lambda v:v[0]):
        for _,idx,change in group:
            if change==1:active.add(idx)
            else:active.remove(idx)
        if active:
            item=(len(active),n,y,sorted(active))
            if item[:3]>best[:3]:best=item
    top.append((max([1]),y))

count,n,y,ids=best
report={'scope':'Bounded exploration of existing finite certificate, not a new all-n theorem',
        'count':count,'n':n,'H':(4*n-2)//3,'anchor':y,
        'records':[records[i] for i in ids]}
(Path(__file__).parent/'largest_overlap_example.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='records'})
print([(r['u'],len(r['word']),r['resets'],r['path'][-1]) for r in report['records']])
