#!/usr/bin/env python3
"""Independent affine/CRT audit of persistent selected-slow overlap.

Forward affine prefixes derive all inverse-state coefficients.  The CRT is
solved for C modulo 3^25, rather than for t modulo 2^R as in the producer.
Finite slow replays check the construction; the all-R inequalities are exact.
"""
from __future__ import annotations

import json
from fractions import Fraction as Q
from pathlib import Path

N0 = 15611
WORDS = (
    (1, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 5, 1, 2, 1, 2, 3),
    (1, 1, 1, 1, 2, 3, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 5, 1, 2, 1, 2, 3),
)


def coefficients_from_forward_prefixes(word):
    E = B = 0
    prefixes = [(0, 0)]
    for exponent in word:
        B = 3 * B + 2**E
        E += exponent
        prefixes.append((E, B))
    g = len(word)
    source_a, source_b = Q(2**E, 3**g), Q(B, 3**g)
    states = []
    for j, (ej, bj) in enumerate(prefixes):
        states.append((3**j * source_a / 2**ej, (3**j * source_b - bj) / 2**ej))
    return E, B, states


def evaluated(coefficients, endpoint):
    answer = [a * endpoint - b for a, b in coefficients]
    assert all(x.denominator == 1 and x > 0 and x.numerator % 2 for x in answer)
    return [x.numerator for x in answer]


def actual_step(x):
    z = 3 * x + 1
    exponent = (z & -z).bit_length() - 1
    return z >> exponent, exponent


def is_slow(x):
    assert x >= 3 and x % 2
    state = x
    for _ in range(x.bit_length()):
        state = (3 * state + 1) // 2 if state % 2 else state // 2
        if 2 * state < x:
            return False
    return True


def greedy_indices(path):
    chosen = []
    at = 0
    end = len(path) - 1
    while at < end:
        departure = path[at]
        if is_slow(departure):
            chosen.append(at)
            at += 1
        else:
            later = next(j for j in range(at + 1, end + 1) if 2 * path[j] < departure)
            at = later
    return chosen


def certify(*, output=None):
    if not __debug__:
        raise RuntimeError("Assertions required.")
    modulus = 3**25
    assert modulus > N0 + 1
    assert 23 * modulus < 2**45
    assert 3**256 - 1 > 23 * modulus * 2**300
    data = []
    expected_slow = ((0, 1, 2), (0, 1, 7))
    fast_blocks = (((3, 20),), ((2, 7), (8, 25)))
    for index, word in enumerate(WORDS):
        g = len(word)
        E, B, coefficients = coefficients_from_forward_prefixes(word)
        path = evaluated(coefficients, N0)
        assert path[0] == (19227, 20255)[index] and path[-1] == N0
        for left, right, e in zip(path, path[1:], word):
            assert actual_step(left) == (right, e)
        a, b = coefficients[0]
        assert 1 < a < Q(4, 3)
        assert path[0] > N0 and 4 * N0 - 3 * path[0] > 2
        assert all(3 * x > 4 * N0 for x in path[1:-1])
        assert all(lam > Q(4, 3) for lam, beta in coefficients[1:-1])
        assert all(beta > 0 and lam < 23 for lam, beta in coefficients[:-1])
        assert g >= 11 and sum(e >= 2 for e in word) >= 5
        assert 2**E > 3**g and B > 0
        assert all(coefficients[j][0] < 2 for j in expected_slow[index])
        half_descent_signs = []
        preceding_even_signs = []
        for start, finish in fast_blocks[index]:
            assert sum(word[start:finish]) <= 40
            assert path[start] > 2 * N0 and coefficients[start][0] > 2
            # The final halving may pass through even states before the odd
            # endpoint.  Its smallest preceding even state is 2*x_finish.
            # This extra comparison makes the endpoint the first shortcut
            # state below half the block's starting height, not merely the
            # first odd state below it.
            even_slope = 4 * coefficients[finish][0] - coefficients[start][0]
            even_base = 4 * path[finish] - path[start]
            assert even_slope > 0 and even_base > 0
            preceding_even_signs.append({"start": start, "finish": finish,
                                         "slope": str(even_slope),
                                         "seed_value": even_base})
            for j in range(start + 1, finish + 1):
                sign = -1 if j == finish else 1
                slope = 2 * coefficients[j][0] - coefficients[start][0]
                base = 2 * path[j] - path[start]
                assert sign * slope > 0 and sign * base > 0
                half_descent_signs.append({"start": start, "test": j, "sign": sign,
                                           "slope": str(slope), "seed_value": base})
        data.append({"word": word, "g": g, "E": E, "B": B,
                     "coefficients": coefficients,
                     "seed_source": path[0], "half_descent_signs": half_descent_signs,
                     "preceding_even_signs": preceding_even_signs})
    assert data[0]["coefficients"][2] == data[1]["coefficients"][7]
    assert data[0]["coefficients"][2][0] == Q(2**29, 3**18)
    replays = []
    for R in (256, 257, 300):
        # Solve the equivalent CRT equation for C modulo the fixed odd modulus.
        C = ((N0 + 1) * pow(pow(2, R, modulus), -1, modulus)) % modulus
        assert 1 <= C < modulus
        N = C * 2**R - 1
        assert N >= 2**R - 1 > N0 and N % modulus == N0
        t = (N - N0) // modulus
        assert 0 <= t < 2**R
        assert t == (-(N0 + 1) * pow(modulus, -1, 2**R)) % 2**R
        assert (3**R - 1) > 23 * modulus * 2**(R + 44)
        entries = []
        for index, row in enumerate(data):
            path = evaluated(row["coefficients"], N)
            H = (4 * N - 2) // 3
            assert N <= path[0] <= H and path[-1] == N
            assert all(x > H for x in path[1:-1])
            for left, right, e in zip(path, path[1:], row["word"]):
                assert actual_step(left) == (right, e)
            selected = greedy_indices(path)
            assert selected == list(expected_slow[index])
            period = 2**(row["E"] + 1)
            assert (path[0] - period) * 3**row["g"] + row["B"] == 2**row["E"] * (N - 2 * 3**row["g"])
            entries.append({"source": str(path[0]), "selected_indices": selected,
                            "selected_values": [str(path[j]) for j in selected]})
        assert entries[0]["selected_values"][2] == entries[1]["selected_values"][2]
        replays.append({"R": R, "N": str(N), "C": str(C), "profiles": entries})
    result = {
        "status": "PASS",
        "scope": "Independent forward-affine sign certificate, equivalent CRT construction and finite slow controls; all-R claim uses the symbolic inequalities.",
        "all_R": "Every integer R>=256.",
        "fixed_seed_sources": [row["seed_source"] for row in data],
        "common_anchor_slope": str(data[0]["coefficients"][2][0]),
        "height_inequality": "3^256-1 > 23*3^25*2^300",
        "monotonicity_identity": "[(3^(R+1)-1)/2^(R+1)]-[(3^R-1)/2^R]=(3^R+1)/2^(R+1)>0",
        "half_descent_signs": [row["half_descent_signs"] for row in data],
        "preceding_even_signs": [row["preceding_even_signs"] for row in data],
        "replayed_endpoints": replays,
        "conclusion": "Two distinct residual least-source profiles select the same slow anchor at arbitrarily large thresholds.",
        "not_proved": "No unbounded multiplicity or violation of the weighted-overlap target.",
    }
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    output = Path(__file__).with_name("persistent_slow_overlap_independent_audit.json")
    result = certify(output=output)
    print(json.dumps({"status": result["status"], "all_R": result["all_R"],
                      "replay_count": len(result["replayed_endpoints"]),
                      "output": str(output)}, indent=2))
