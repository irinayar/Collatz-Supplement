from itertools import combinations
for j in range(2,15):
 for b in range(1,j):
  vals=sorted([sum((1<<i)*3**(b-h-1) for h,i in enumerate(pos)) for pos in combinations(range(j),b)],reverse=True)
  expected=3**(b-1)*2**(j-b-1)
  if vals[0]-vals[1]!=expected:
   print('FAIL',j,b,vals[:2],expected);raise SystemExit(1)
print('Verified exact top-two numerator gap for every 2<=j<=14, 1<=b<j (91 cases).')
