from functools import lru_cache
@lru_cache(None)
def H(x,k,r):
 if k<0 or r<0:return None
 if k+r==0:return x
 v=[]
 if k:
  a=H(2*x,k-1,r)
  if a is not None:v.append(a)
 if r and x%3==2:
  a=H((2*x-1)//3,k,r-1)
  if a is not None:v.append(a)
 return min(v) if v else None

def word(x,k,r):
 if k+r==0:return ''
 m=H(x,k,r)
 if k and H(2*x,k-1,r)==m:return word(2*x,k-1,r)+'E'
 if r and x%3==2 and H((2*x-1)//3,k,r-1)==m:return word((2*x-1)//3,k,r-1)+'O'
 raise AssertionError

def replay(m,w):
 for c in w:
  if c=='E':assert m%2==0;m//=2
  else:assert m%2==1;m=(3*m+1)//2
 return m

if __name__=='__main__':
 for x,k0 in [(4,4),(5,3)]:
  print('endpoint',x)
  for k in range(k0,25):
   a,b=H(x,k,3),H(x,k,4)
   assert a is not None and b is not None and b<a
   assert replay(a,word(x,k,3))==x
   assert replay(b,word(x,k,4))==x
   assert a==H(x,k0,3)*2**(k-k0)
   assert b==H(x,k0,4)*2**(k-k0)
  print('base',k0,H(x,k0,3),H(x,k0,4),word(x,k0,3),word(x,k0,4),'verified budgets',k0,'..24')
  for k in range(k0,25):
   for t in [0,1,2,9]:
    xx=x+81*t
    a,b=H(xx,k,3),H(xx,k,4)
    assert a==H(x,k,3)+3*2**(k+3)*t
    assert b==H(x,k,4)+2*2**(k+3)*t
    assert b<a
 print('ALL CHECKS PASS')
