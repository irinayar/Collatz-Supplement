from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def preimages(y):
    yield 2*y
    if (2*y-1)%3==0:
        m=(2*y-1)//3
        if m>0 and m%2: yield m

checks=0
for j in range(1,12):
    for k in range(1,5):
        n=(1<<j)*k-1
        x=n
        for i in range(j+1):
            assert x+1 == 3**i * (n+1)//(2**i)
            frontier={x}
            for ell in range(i+1):
                for m in frontier:
                    assert m>=n, (j,k,i,ell,n,m)
                    assert (m+1)*3**ell >= (x+1)*2**ell
                    checks+=1
                frontier={p for v in frontier for p in preimages(v)}
            if i<j: x=T(x)
print('PASS',checks,'exact endpoint inverse comparisons')
