from functools import lru_cache
from itertools import combinations
@lru_cache(None)
def H(x,k,r):
    if x<1 or k<0 or r<0:return None
    if k+r==0:return x
    a=[]
    if k:
        z=H(2*x,k-1,r)
        if z is not None:a.append(z)
    if r and x%3==2:
        y=(2*x-1)//3
        if y%2:
            z=H(y,k,r-1)
            if z is not None:a.append(z)
    return min(a) if a else None

def word(m,x,k,r):
    w=''; z=m
    for _ in range(k+r):
        if z%2:z=(3*z+1)//2;w+='O'
        else:z//=2;w+='E'
    assert z==x and w.count('E')==k and w.count('O')==r
    return w

def numerator(w):
    a=1;v=0
    for c in w:
        if c=='O':a*=3;v=3*v+1*(2**(w.index(c))) if False else 3*v+1 # incorrect? update affine denominator per step
    # proper recursive affine with 2^i
    a=1;v=0
    for i,c in enumerate(w):
        if c=='O':a*=3;v=3*v+2**i
    return v

cases=[]
for x in (4,5,7,8,10,11):
    k=next(k for k in range(8) if H(x,k,2) is not None)
    m=H(x,k,2); w=word(m,x,k,2)
    V=numerator(w)
    assert 2**(k+2)*x==9*m+V
    cases.append((x,x%9,k,m,w,V,H(x,k,1)))
print('base, residue, k0, m2, word, V, m1')
for c in cases:print(*c)
for k in range(5):
    residues=set()
    for os in combinations(range(k+2),2):
        w=''.join('O' if i in os else 'E' for i in range(k+2))
        v=numerator(w)
        for x in range(1,10):
            if (2**(k+2)*x-v)%9==0:
                residues.add(x%9)
    print('k',k,'residues',sorted(residues))
for x0,rem,k0,m2,w,V,m1 in cases:
    for t in range(0,101):
        x=x0+9*t
        origin=m2+(2**(k0+2))*t
        assert word(origin,x,k0,2)==w
        assert origin < H(x,k0,1)
        for k in range(k0, k0+5):
            assert 2**(k-k0)*origin < H(x,k,1)
print('verified 606 representatives x 5 k-values each')
