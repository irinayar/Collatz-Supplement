from fractions import Fraction
import random,json

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def affine(word):
    a=u=0
    for b in word:
        if b=='0': u*=1
        else: u=3*u+2**(len_seen) if False else u
    # standard recurrence numerator at fixed denominator
    u=0;a=0
    for i,b in enumerate(word):
        if b=='1': u=3*u+2**i;a+=1
    return len(word),a,u

def parity(n,L):
    out=[]
    for _ in range(L): out.append(str(n&1));n=T(n)
    return ''.join(out)

random.seed(31119)
checks=0;repeat_hits=0;maxk=0
for n in range(1,1001):
    z=n; seq=[z]
    for i in range(80): seq.append(T(seq[-1]))
    for i in range(30):
        for L in range(1,7):
            w=parity(seq[i],L)
            l,a,u=affine(w);d=3**a-2**l
            if d<=0: continue
            k=0
            while i+(k+1)*l<=80 and parity(seq[i],(k+1)*l)==w*(k+1): k+=1
            if k:
                assert (d*seq[i]+u)%(2**(k*l))==0
                assert 2**(k*l)<=d*seq[i]+u
                assert d*seq[i]+u<=d*(3**i)*(n+1)//(2**i)+u or Fraction(d*seq[i]+u)<=Fraction(d*3**i*(n+1),2**i)+u
                checks+=1;repeat_hits+=k;maxk=max(maxk,k)
result={'starts':1000,'start_positions':30,'word_lengths':6,'verified_expanding_blocks':checks,'total_repetitions':repeat_hits,'max_repetition_count':maxk,'status':'pass'}
with open('/mnt/data/expanding_block_rigidity/results.json','w') as f:json.dump(result,f,indent=2)
print(result)
