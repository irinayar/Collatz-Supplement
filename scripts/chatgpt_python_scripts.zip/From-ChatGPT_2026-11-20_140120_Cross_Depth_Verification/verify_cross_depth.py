from collections import defaultdict
T=lambda n: n//2 if n%2==0 else (3*n+1)//2
N=300; J=12
states={n:(n,0) for n in range(1,N+1)}
for j in range(J):
    fibres={}
    for n,(y,a) in states.items():
        fibres[(y,a)]=min(fibres.get((y,a),n),n)
    nextstates={n:(T(y),a+(y%2)) for n,(y,a) in states.items()}
    nf={}
    for n,(y,a) in nextstates.items(): nf[(y,a)]=min(nf.get((y,a),n),n)
    for (z,b),val in nf.items():
        preds=[2*z]
        if z%3==2: preds.append((2*z-1)//3)
        predvals=[fibres.get((p,b-(p%2)),float('inf')) for p in preds if b>=p%2]
        assert val==min(predvals), (j,z,b,val,predvals)
    states=nextstates
print('Verified finite-window fibre recurrence at 12 depths, 300 origins (relative to the bounded origin set).')
