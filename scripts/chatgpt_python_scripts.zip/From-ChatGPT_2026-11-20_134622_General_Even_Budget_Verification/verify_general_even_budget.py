from functools import lru_cache
from itertools import combinations
from collections import defaultdict

def v3(n):
 a=0
 while n%3==0:
  n//=3;a+=1
 return a

def T(n):return n//2 if n%2==0 else (3*n+1)//2

@lru_cache(None)
def origins(x,e,r):
 if e==0:
  if r>v3(x+1):return frozenset()
  m=2**r*((x+1)//3**r)-1
  return frozenset([m]) if m>0 else frozenset()
 out=set()
 for ell in range(min(r,v3(x+1))+1):
  Y=2*(2**ell*((x+1)//3**ell)-1)
  out.update(origins(Y,e-1,r-ell))
 return frozenset(out)

@lru_cache(None)
def R(x,e):
 if e==0:return v3(x+1)
 return max(ell+R(2*(2**ell*((x+1)//3**ell)-1),e-1) for ell in range(v3(x+1)+1))

checks=0
for x in range(1,81):
 for e in range(4):
  for r in range(9):
   actual=set()
   L=r+e
   for oddpos in combinations(range(L),r):
    V=sum(2**p*3**(r-1-k) for k,p in enumerate(oddpos))
    B=2**L*x
    if (B-V)%3**r:continue
    m=(B-V)//3**r
    if m<=0:continue
    z=m
    for t in range(L):
     assert z%2==(t in oddpos)
     z=T(z)
    assert z==x
    actual.add(m)
   assert actual==set(origins(x,e,r)),(x,e,r,actual,origins(x,e,r))
   checks+=1
  rr=R(x,e)
  assert origins(x,e,rr)
  assert not origins(x,e,rr+1)
print('PASS',checks,'exact (endpoint,even-count,odd-count) comparisons; 320 maxima attained and next count absent')
print('R_e(x) examples:')
for x in (1,2,3,7,20,251):print(x,[R(x,e) for e in range(4)])
