from functools import lru_cache
import json,time
@lru_cache(None)
def R(k,x):
 a=0;t=x+1
 while t%3==0:a+=1;t//=3
 if k==0:return a
 best=0
 for l in range(a+1):
  y=2*(2**l*((x+1)//3**l)-1)
  best=max(best,l+R(k-1,y))
 return best

def audit(k):
 B=3*(1<<k)-4; best={}; witnesses={}
 for m in range(1,B):
  n=m;e=r=0
  while e<=k:
   if e==k:
    key=(n,r)
    if m<best.get(key,B):best[key]=m;witnesses[key]=m
   if n&1:n=(3*n+1)//2;r+=1
   else:n//=2;e+=1
 violations=[];nonterminal=0
 for (x,r),m in best.items():
  top=R(k,x)
  if r<top:
   nonterminal+=1
   if best.get((x,r+1),B)>=m:violations.append((x,r,m,top,best.get((x,r+1))))
 return {'k':k,'B':B,'pairs':len(best),'nonterminal':nonterminal,'terminal':len(best)-nonterminal,'violations':violations,'cache_R':R.cache_info().currsize}
if __name__=='__main__':
 t=time.time();res=[]
 for k in range(7,13):
  d=audit(k);res.append(d);print(d,'elapsed',round(time.time()-t,2),flush=True)
 with open('/mnt/data/audit_k7_to_k12_results.json','w') as f:json.dump(res,f,indent=2)
