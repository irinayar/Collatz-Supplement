from functools import lru_cache
import json,time
@lru_cache(None)
def R(k,x):
 a=0;t=x+1
 while t%3==0:a+=1;t//=3
 if k==0:return a
 return max(l+R(k-1,2*(2**l*((x+1)//3**l)-1)) for l in range(a+1))
def audit(k):
 B=3*(1<<k)-4;best={}
 for m in range(1,B):
  n=m;e=r=0
  while e<=k:
   if e==k:
    key=(n,r)
    if m<best.get(key,B):best[key]=m
   if n&1:n=(3*n+1)//2;r+=1
   else:n//=2;e+=1
 candidates=[];witnessed=0
 for (x,r),m in best.items():
  if best.get((x,r+1),B)<m:witnessed+=1
  else:candidates.append((x,r,m,best.get((x,r+1))))
 violations=[];terminal=0
 for x,r,m,nextm in candidates:
  top=R(k,x)
  if r>=top:terminal+=1
  else:violations.append((x,r,m,top,nextm))
 return {'k':k,'B':B,'pairs':len(best),'witnessed_successors':witnessed,'terminal':terminal,'violations':violations,'R_cache':R.cache_info().currsize}
if __name__=='__main__':
 t=time.time();res=[]
 for k in range(13,20):
  d=audit(k);res.append(d);print(d,'elapsed',round(time.time()-t,2),flush=True)
  with open('/mnt/data/audit_k13_to_k19_results.json','w') as f:json.dump(res,f,indent=2)
