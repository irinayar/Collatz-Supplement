from fractions import Fraction
S=list(range(5,36,2))
for u in [3]+S:
    n=u; visited=set()
    while n!=1:
        assert n not in visited, (u,n)
        visited.add(n)
        n=(3*n+1)//2 if n%2 else n//2
P=Fraction(1)
for u in S: P*=Fraction(3*u+1,3*u)
B=P*Fraction(112,111)**5
assert B < Fraction(3,2)
assert Fraction(10,9)**2 < Fraction(3,2)
print('small odd states',len(S),'bound',B,'decimal',float(B))
print('positive margin',Fraction(3,2)-B)
