from collections import defaultdict

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def words(j):
    out=[]
    for mask in range(1<<j):
        a=0; U=0
        for i in range(j):
            if mask>>i&1:
                U=3*U+(1<<i);a+=1
        out.append((a,U,mask))
    return out

def verify():
    total=0; trich=[0,0,0,0]
    for j in range(1,11):
        B=1<<j
        by=defaultdict(list)
        for b,V,w in words(j): by[b].append(V)
        for n in range(1,301):
            x=n;a=0;U=0
            for i in range(j):
                if x%2: a+=1; U=3*U+(1<<i)
                x=T(x)
            y=x
            channels=[False]*3
            for b,vals in by.items():
                for V in vals:
                    numerator=B*y-V
                    q=3**b
                    if numerator%q: continue
                    m=numerator//q
                    assert m>0
                    if m<n:
                        channels[0 if b<a else 1 if b==a else 2]=True
            brute=any(iterate(m,j)==y for m in range(1,n))
            assert brute==any(channels),(j,n,channels,brute)
            for k in range(3):trich[k]+=channels[k]
            trich[3]+=brute
            total+=1
    print('checked',total,'source-depth pairs; lower/same/higher/any occurrences',trich)
    j=42;n=251
    y=iterate(n,j); a=count_odd(n,j)
    counts=defaultdict(list)
    for m in range(1,n):
        if iterate(m,j)==y:counts[count_odd(m,j)].append(m)
    assert y==2 and a==22 and set(counts)=={18,19,20,21}
    print('counterexample 251: j=42 endpoint',y,'odd source',a,'smaller odd-count levels',sorted(counts))

def iterate(n,j):
    for _ in range(j):n=T(n)
    return n

def count_odd(n,j):
    c=0
    for _ in range(j):c+=n%2;n=T(n)
    return c

if __name__=='__main__':verify()
