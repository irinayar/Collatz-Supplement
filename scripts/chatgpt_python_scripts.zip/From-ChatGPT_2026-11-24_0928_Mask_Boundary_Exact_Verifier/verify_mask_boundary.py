from fractions import Fraction as F
import random
random.seed(20261124)

def odd_run(a):
    assert a%2==1 and a>0
    s=0; e=0; x=a
    while True:
        z=3*x+1
        v=(z & -z).bit_length()-1
        x=z>>v; s+=1; e=v
        if v>=2: break
    beta=1-F(2,3)**s
    lam=F(2**(s+e-1),3**s)
    assert F(a,1)+beta==lam*x
    return x,beta,s,e

nchecks=0
nontrivial=0
for _ in range(1200):
    a=random.randrange(1,100000,2)
    starts=[a]; betas=[]; vals=[]
    for j in range(random.randint(1,14)):
        b,beta,s,e=odd_run(a)
        betas.append(beta); vals.append((s,e)); starts.append(b); a=b
    N=len(betas)
    mask=[random.randrange(2) for _ in range(N)]
    kappa=F(random.randrange(1,100),random.randrange(100,200))
    d=[betas[j]/starts[j] for j in range(N)]
    f=[F(1,starts[j])-F(1,starts[j+1]) for j in range(N)]
    t=[kappa*d[j]+f[j] for j in range(N)]
    c=[max(F(0),-f[j]-d[j]/15) for j in range(N)]
    h=[t[j]+c[j] for j in range(N)]
    Z=sum((-c[j]+h[j]*mask[j] for j in range(N)),F(0))
    boundary=(F(mask[0],starts[0])-F(mask[-1],starts[-1]) + sum((F(mask[j]-mask[j-1],starts[j]) for j in range(1,N)),F(0)))
    rhs=kappa*sum((d[j] for j in range(N) if mask[j]),F(0))+boundary-sum((c[j] for j in range(N) if not mask[j]),F(0))
    assert Z==rhs
    # verify block decomposition of boundary
    blocks=[];j=0
    while j<N:
        if mask[j]==1:
            k=j
            while k+1<N and mask[k+1]==1: k+=1
            blocks.append((j,k+1));j=k+1
        else:j+=1
    assert boundary==sum((F(1,starts[l])-F(1,starts[r]) for l,r in blocks),F(0))
    assert boundary<=sum((F(1,starts[l]) for l,r in blocks),F(0))
    nchecks+=1
    if len(blocks)>1:nontrivial+=1
print({'exact_rational_orbits':nchecks,'multiple_core_blocks':nontrivial,'failed':0})
