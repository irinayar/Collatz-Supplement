#!/usr/bin/env python3
"""Independent transfer-constant audit of the certified killed phase bound.

Run the primary exact certificate checks, then independently check the improved
positive-part inequalities and final rational budget arithmetic.  The source
capacity transfer is proved in Phase_Frontier_Independent_Audit.md, not inferred
from a random-residue simulation.  No primary files are modified.
"""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Run without -O: exact audit assertions must remain active.")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PRIMARY = ROOT / "phase_frontier_work" / "verify_phase_frontier.py"


def exp_lower(x: F, terms: int = 48) -> F:
    assert x >= 0
    term = result = F(1)
    for k in range(1, terms+1):
        term *= x/k
        result += term
    return result


def encoded(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {k: encoded(v) for k, v in x.items()}
    if isinstance(x, list):
        return [encoded(v) for v in x]
    return x


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--primary", type=Path, default=PRIMARY,
                        help="Primary exact verifier; defaults to the sibling phase_frontier_work directory.")
    parser.add_argument("--certificate", type=Path,
                        help="Supersolution JSON; defaults to killed_phase_certificate.json next to --primary.")
    parser.add_argument("--output", type=Path,
                        default=HERE / "phase_frontier_independent_audit_certificate.json",
                        help="Audit output JSON; defaults to the audit script's directory.")
    args = parser.parse_args()
    primary_path = args.primary
    certificate_path = args.certificate or primary_path.with_name("killed_phase_certificate.json")
    spec = importlib.util.spec_from_file_location("independent_frontier_source", primary_path)
    primary = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(primary)
    tail = primary.verify_small_multiplier_tail()
    mgf = primary.verify_supersolution(certificate_path)
    mass = primary.verify_run_mass()
    capacity = primary.verify_elementary_source_inequalities()
    assert mgf["minimum_supersolution_margin_exceeds_reported"]
    assert mgf["envelope_margin_exceeds_reported"]

    theta = F(1400, 1001)
    V0 = F(mgf["initial_mgf_bound"])
    run_mass = F(mass["total_upper"])
    assert V0 == F(82262531839, 10**10)
    assert run_mass == F(8563637, 26873856)

    # First improvement: x <= exp(theta*x-1)/theta, x>=0.
    ordinary_phase_upper = V0 / (theta*exp_lower(5*theta+1))
    ordinary_bulk_upper = run_mass*ordinary_phase_upper
    assert ordinary_bulk_upper < F(317, 500000)

    # Stronger tangent: exp(y)>=exp(1-epsilon)*(y+epsilon).
    # exp(theta*B+1-epsilon)>1/epsilon makes subtraction of 1 valid.
    epsilon = F(1, 2000)
    denominator_lower = exp_lower(5*theta+1-epsilon)
    assert denominator_lower > 1/epsilon
    phase_upper = (V0-1)/(theta*denominator_lower)
    bulk_upper = run_mass*phase_upper
    bulk_simple = F(557, 10**6)
    assert bulk_upper < bulk_simple < ordinary_bulk_upper

    # Imported canonical source-count constant.  This script verifies only
    # its use in the new arithmetic, not the previous theorem establishing it.
    alpha = F(4899, 3904)
    cstar = F(620751769493359576, 1180591620717411303425)
    n0 = 2**71+1
    excess = cstar*(2-F(4, 3)*alpha+alpha/(3*n0))
    remainder = F(6761, 3904000)-bulk_simple-excess
    assert excess > 0
    assert remainder > F(1002, 10**6)

    data = dict(
        status="Independent exact certificate and transfer-constant audit passed.",
        primary_certificate_sha256=sha256(certificate_path.read_bytes()).hexdigest(),
        scope="All positive original-core occurrences with full run-ending prefix modulus <= H-n. Integer lattice counting preserves every source occurrence. The all-atomic remainder is not bounded here.",
        small_multiplier_tail=tail, supersolution=mgf,
        run_mass=mass, source_inequalities=capacity,
        theta=theta, epsilon=epsilon,
        initial_mgf_bound=V0,
        ordinary_phase_upper=ordinary_phase_upper,
        ordinary_bulk_upper=ordinary_bulk_upper,
        ordinary_bulk_simple=F(317, 500000),
        tangent_denominator_lower=denominator_lower,
        tangent_denominator_required=1/epsilon,
        tangent_phase_upper=phase_upper,
        tangent_bulk_upper=bulk_upper,
        tangent_bulk_simple=bulk_simple,
        imported_canonical_count_constant=cstar,
        imported_first_late_excess=excess,
        second_and_later_signed_remainder=remainder,
        second_and_later_simple_allowance=F(1002, 10**6))
    out = args.output
    out.write_text(json.dumps(encoded(data), indent=2)+"\n")
    print("Independent primary certificate verification passed.")
    print("Improved bulk <", bulk_simple)
    print("Remaining second/later signed allowance >", F(1002, 10**6))
    print("wrote", out)


if __name__ == "__main__":
    main()
