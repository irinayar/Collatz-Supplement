#!/usr/bin/env python3
"""Exact R/C return controls and local inverse-residue checks.

Standard library only.  This is a deterministic construction of fixed controls,
not a census of original core-bearing first returns.  All decisions are exact.
The controls have EMPTY original cores: they refute a phase-to-credit lower
bound, not the requested central aggregate bound.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sys

if not __debug__:
    raise SystemExit("Run without -O: exact certificate checks use assertions.")
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

R = (1, 2)
C = (1, 1, 1, 1, 4)
ALPHA = F(9, 8)
GAMMA = F(243, 256)
LAMBDA_BAND = F(32, 27)
RECORDS = (13, 88, 163)


def ceil_fraction(x: F) -> int:
    return -((-x.numerator) // x.denominator)


def v2(x: int) -> int:
    assert x > 0
    return (x & -x).bit_length() - 1


def mechanical_blocks(length: int) -> tuple[list[str], list[F], list[int]]:
    """Stay in (1,32/27), by exact rational greedy rotation."""
    h = F(1)
    low = F(2)
    labels, heights, records = [], [h], []
    for j in range(1, length + 1):
        label = "R" if GAMMA * h <= 1 else "C"
        h *= ALPHA if label == "R" else GAMMA
        assert 1 < h < LAMBDA_BAND
        labels.append(label)
        heights.append(h)
        if h < low:
            records.append(j)
            low = h
    return labels, heights, records


def affine_word(word: list[int]) -> tuple[list[int], list[int], list[F], list[F]]:
    times, numerators, slopes, offsets = [0], [0], [F(1)], [F(0)]
    E = U = 0
    for g, e in enumerate(word, 1):
        U = 3 * U + 2**E
        E += e
        times.append(E)
        numerators.append(U)
        slopes.append(F(3**g, 2**E))
        offsets.append(F(U, 2**E))
    return times, numerators, slopes, offsets


def local_checks() -> dict:
    rows = []
    for name, word in (("R", R), ("C", C)):
        times, numerators, slopes, _ = affine_word(list(word))
        s, E, U = len(word), times[-1], numerators[-1]
        beta = 1 - F(2, 3)**s
        lam = 1 / slopes[-1]
        M = 2**(E + 1)
        residue = ((2**E - U) * pow(3**s, -1, M)) % M
        output_modulus = 3**s
        output_residue = U * pow(2**E, -1, output_modulus) % output_modulus
        assert lam <= 1 + beta / 15
        assert residue == {"R": 11, "C": 95}[name]
        assert output_residue == {"R": 4, "C": 91}[name]
        rows.append(dict(name=name, s=s, e=word[-1], E=E, U=U,
                         beta=beta, inverse_multiplier=lam,
                         source_residue=residue, source_modulus=M,
                         output_residue=output_residue,
                         output_modulus=output_modulus))
    assert rows[0]["output_residue"] % 9 != rows[1]["output_residue"] % 9

    # Any contraction of odd run length s<=4 is credited at the high floor.
    small = []
    for s in range(1, 5):
        beta = 1 - F(2, 3)**s
        e = 2
        while F(2**(s+e-1), 3**s) <= 1:
            e += 1
        lam = F(2**(s+e-1), 3**s)
        assert lam > (1 + beta / 2**71) * (1 + beta / 15)
        small.append(dict(s=s, first_contracting_reset=e,
                          least_contracting_inverse_multiplier=lam))
    cheap = []
    for s in range(1, 201):
        beta = 1 - F(2, 3)**s
        e = 2
        while F(2**(s+e-1), 3**s) <= 1:
            e += 1
        lam = F(2**(s+e-1), 3**s)
        if lam <= 1 + beta / 15:
            assert 15*2**(s+e-1) <= 16*3**s - 2**s
            cheap.append([s, e])
    assert cheap[:4] == [[5, 4], [17, 11], [29, 18], [41, 25]]

    # A larger zero-credit alphabet need not remain inverse-unambiguous.
    # R and A=(1 repeated 11 times,8) have compatible output cylinders.
    branch_modulus = 2*3**12
    branch_output = 602023 + branch_modulus*ceil_fraction(F(2**74-602023, branch_modulus))
    branch_rows = []
    for name, pattern in (("R", R), ("A", (1,)*11+(8,))):
        s, E = len(pattern), sum(pattern)
        U = 3**s-2**s  # A single complete run's affine numerator.
        a = F(2**E*branch_output-U, 3**s)
        assert a.denominator == 1
        a = a.numerator
        x = a
        for e in pattern:
            assert v2(3*x+1) == e
            x = (3*x+1)//2**e
        assert x == branch_output and a < branch_output and a >= 2**71
        beta = 1-F(2, 3)**s
        delta = beta/a
        flux = F(1, a)-F(1, branch_output)
        assert flux > 0 and max(F(0), -flux-delta/15) == 0
        branch_rows.append(dict(name=name, input=a, word=list(pattern),
                                flux=flux, credit=F(0)))
    assert branch_rows[0]["input"] != branch_rows[1]["input"]
    return dict(types=rows, lengths_below_five=small,
                uncredited_contracting_types_through_s200=cheap,
                zero_credit_branch=dict(output=branch_output, inputs=branch_rows,
                                        scope="Two actual local runs, not a completed common-core source family."))


def construct(length: int) -> dict:
    labels, heights, records = mechanical_blocks(length)
    assert length in records and length >= 13
    assert all(h > heights[-1] for h in heights[1:-1])
    word = [e for label in labels for e in (R if label == "R" else C)]
    times, numerators, slopes, offsets = affine_word(word)
    G, E, U = len(word), times[-1], numerators[-1]
    M = 2**(E+1)
    residue = ((2**E-U) * pow(3**G, -1, M)) % M
    assert residue % 2 == 1
    assert all(h > slopes[-1] for h in slopes[1:-1])

    # All proper odd states exceed the final state by >8; the state following
    # the first three runs also lies below 4u/3-8.  These are exact affine bounds.
    lower = max(2*M, 4*length, 2**74)
    for i in range(1, G):
        bound = (8 - offsets[i] + offsets[-1]) / (slopes[i] - slopes[-1])
        lower = max(lower, bound.numerator // bound.denominator + 1)
    early = sum(len(R if label == "R" else C) for label in labels[:3])
    assert slopes[early] < F(4, 3)
    bound = (offsets[early] + 8) / (F(4, 3) - slopes[early])
    lower = max(lower, bound.numerator // bound.denominator + 1)
    k = ceil_fraction(F(lower-residue, M))
    u = residue + k*M
    assert u >= lower
    odd = [a*u+b for a, b in zip(slopes, offsets)]
    assert all(x.denominator == 1 for x in odd)
    odd = [x.numerator for x in odd]
    w = odd[-1]
    xstar = min(odd[1:-1])
    minimizer = odd.index(xstar)
    n = (3*xstar+1)//4
    n -= (n+1) % 2
    H = (4*n-2)//3
    assert n % 2 and n >= 2**71
    assert 1 <= xstar-H <= 3
    assert n <= u < w <= H < xstar
    assert w+8 < xstar
    assert all(x > H for x in odd[1:-1])

    # Exact orbit and every inverse shortcut-parity residue.
    shortcut = [u]
    for i, e in enumerate(word):
        a = odd[i]
        assert e == v2(3*a+1)
        x = (3*a+1)//2
        shortcut.append(x)
        for _ in range(e-1):
            assert x % 2 == 0
            x //= 2
            shortcut.append(x)
        assert x == odd[i+1] and x % 2
    assert len(shortcut) == E+1
    assert len(set(shortcut[:-1])) == E
    inv_U = inv_r = 0
    for depth, x in enumerate(shortcut[:-1], 1):
        if x % 2:
            inv_U = 3*inv_U + 2**(depth-1)
            inv_r += 1
        inverse_residue = (-inv_U * pow(3**inv_r, -1, 2**depth)) % 2**depth
        assert inverse_residue == u % 2**depth
        assert 2**depth*shortcut[depth] == 3**inv_r*u+inv_U

    # Full genuine source interval, independently verifying least admissibility.
    low = max(n, ceil_fraction(F(2**E*n-U, 3**G)))
    high = min(H, (2**E*H-U)//3**G)
    for i in range(1, G):
        low = max(low, (2**times[i]*H-numerators[i])//3**i+1)
    assert low+(residue-low) % M == u <= high
    assert slopes[minimizer]*(u-M)+offsets[minimizer] <= H

    Q = F(U, 3**G)
    kappa = F(n-1, n+1)
    W = F(0)
    total_t = F(0)
    total_credit = F(0)
    runs = []
    start = 0
    for label in labels:
        pattern = R if label == "R" else C
        end = start+len(pattern)
        a, b = odd[start], odd[end]
        s = end-start
        beta = 1-F(2, 3)**s
        lam = F(2**(s+pattern[-1]-1), 3**s)
        delta = beta/a
        f = F(1, a)-F(1, b)
        credit = max(F(0), -f-delta/15)
        t = kappa*delta+f
        q = F(numerators[start], 3**start)
        qend = F(numerators[end], 3**end)
        assert b == (a+beta)/lam
        assert s == v2(a+1)
        assert (a < b) == (label == "R")
        assert credit == 0 and t > 0
        assert F(15, 32) < qend-q < 1
        assert qend-q == (u+q)*delta == beta/slopes[start]
        assert a >= u >= 2**(E+2)
        assert times[start]+a.bit_length()-1 > E
        assert b % 9 == {"R": 4, "C": 1}[label]
        # The preceding R/C run is decoded uniquely by its output residue.
        decoded = (8*b-5)//9 if b % 9 == 4 else (256*b-211)//243
        assert decoded == a
        W += delta
        total_t += t
        total_credit += credit
        runs.append(dict(label=label, a=a, b=b, q=q, qend=qend,
                         delta=delta, flux=f, t=t, credit=credit))
        start = end
    assert start == G
    assert F(15*length, 32) < Q < length
    assert 1+Q/u < F(5, 4) < F(47, 32)
    assert u*W > F(3*length, 8)
    assert u*total_t > F(3*length, 8)*kappa
    assert total_t == kappa*W+F(1, u)-F(1, w)
    assert total_credit == 0
    return dict(block_count=length, R_count=labels.count("R"),
                C_count=labels.count("C"), odd_length=G, shortcut_length=E,
                labels="".join(labels), word=word, n=n, H=H, u=u, w=w,
                source_residue=residue, source_modulus=M, source_lift=k,
                least_source_interval=[low, high], minimum_proper=xstar,
                homogeneous_final=slopes[-1], phase=Q, uW=u*W,
                total_credit=total_credit, whole_signed_score=total_t,
                u_whole_signed_score=u*total_t, actual_core_count=0,
                actual_retained_credit_score=F(0),
                core_emptiness_reason="Every canonical length exceeds total shortcut length.",
                runs=runs)


def encode(x):
    if isinstance(x, F):
        return {"numerator": str(x.numerator), "denominator": str(x.denominator)}
    if isinstance(x, int):
        return str(x)
    if isinstance(x, list):
        return [encode(y) for y in x]
    if isinstance(x, dict):
        return {k: encode(v) for k, v in x.items()}
    return x


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("zero_credit_returns_certificate.json"))
    args = parser.parse_args()
    local = local_checks()
    rows = [construct(n) for n in RECORDS]
    output = dict(
        scope="Fixed exact zero-credit genuine first returns; all actual cores are empty. No central bound or core census is claimed.",
        local=local, controls=rows,
        general_result="On prefixes containing only R and C, the unique inverse predecessor implies at most one genuine source at a common run-boundary cut.")
    args.output.write_text(json.dumps(encode(output), indent=2)+"\n")
    for row in rows:
        print("blocks", row["block_count"], "odd inputs", row["odd_length"],
              "Q", f'{float(row["phase"]):.10f}',
              "uW", f'{float(row["uW"]):.10f}',
              "u total t", f'{float(row["u_whole_signed_score"]):.10f}',
              "credits", row["total_credit"], "actual core", row["actual_core_count"])
    print("wrote", args.output)


if __name__ == "__main__":
    main()
