#!/usr/bin/env python3
"""Exact controls for fixed-prefix repetition cylinders and long R-chain tails.

Standard library only. The proof, rather than these finite controls, supplies
all-depth statements. Source injection and canonical endpoint capacity are
identified imports; their new arithmetic consequences are rebuilt here.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from math import comb, gcd
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: assertions implement exact checks.")

# Embedded, previously saved genuine first returns. No source search is run.
CORE_SEEDS = [{'name': 'asynchronous_1', 'n': '1049728399491224013995397943', 'u': '1244122547545154386957508671', 'word': [1, 1, 1, 1, 1, 4, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 4, 3, 3, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 3, 1, 1, 5, 1, 2, 1, 2, 2, 2], 'expected_core': [26, 28, 30, 32, 33, 35]}, {'name': 'asynchronous_2', 'n': '1049728399491224013995397943', 'u': '1399637865988298685327197255', 'word': [1, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 4, 3, 3, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 3, 1, 1, 5, 1, 2, 1, 2, 2, 2], 'expected_core': [23, 24, 26, 28, 30, 31, 33]}, {'name': 'synchronized_1', 'n': '26645514422485486121914504906678081', 'u': '35527352563313981495886006542237435', 'word': [1, 2, 1, 2, 1, 1, 3, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2, 1, 2, 4, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 3, 2, 2, 2, 1, 3, 2, 1, 3, 1, 1, 1, 3, 1, 4], 'expected_core': [23, 24, 26, 28, 30, 31, 33, 35, 36, 38, 40]}, {'name': 'synchronized_2', 'n': '26645514422485486121914504906678081', 'u': '35527352563313981495886006542237439', 'word': [1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 4, 3, 3, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2, 1, 2, 4, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 3, 2, 2, 2, 1, 3, 2, 1, 3, 1, 1, 1, 3, 1, 4], 'expected_core': [40]}]


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def affine(word):
    E = U = 0
    for e in word:
        U = 3 * U + 2**E
        E += e
    return 3**len(word), 2**E, U, E


def inverse_residue(word):
    A, D, U, E = affine(word)
    return ((D - U) * pow(A, -1, 2 * D)) % (2 * D)


def replay_word(a, word):
    odd = [a]
    shortcut = [a]
    times = [0]
    for e in word:
        assert e == v2(3 * odd[-1] + 1)
        x = (3 * odd[-1] + 1) // 2
        shortcut.append(x)
        for _ in range(e - 1):
            assert not x & 1
            x //= 2
            shortcut.append(x)
        assert x & 1
        odd.append(x)
        times.append(len(shortcut) - 1)
    A, D, U, _ = affine(word)
    assert D * odd[-1] == A * a + U
    return odd, shortcut, times


def runs_from_word(n, word, odd, times):
    kappa = F(n - 1, n + 1)
    runs, g0 = [], 0
    for g1, e in enumerate(word, 1):
        if e < 2:
            continue
        a, b = odd[g0], odd[g1]
        s = g1 - g0
        delta = (1 - F(2, 3)**s) / a
        flux = F(1, a) - F(1, b)
        t = kappa * delta + flux
        credit = max(F(0), -flux - delta / 15)
        assert s == v2(a + 1)
        assert flux <= delta
        assert max(F(0), t) <= F(2, a)
        runs.append(dict(a=a, b=b, s=s, e=e, odd_index=g0,
                         end=g1, time=times[g0], delta=delta,
                         flux=flux, t=t, credit=credit))
        g0 = g1
    assert g0 == len(word)
    return runs


def repetition_controls():
    records = []
    for W in ((1, 2), (1, 1, 2), (1, 2, 1, 2),
              (1, 1, 1, 2), (1, 1, 2, 1, 2)):
        A, D, B, E = affine(W)
        assert A > D
        common = gcd(B, A - D)
        c, d = B // common, (A - D) // common
        assert c & 1 and d & 1
        g0 = E0 = 0
        G = F(2)
        for pos, e in enumerate(W):
            g0 += 1
            E0 += e
            if e >= 2 and pos < len(W) - 1:
                G += 2 * F(2**E0, 3**g0)
        K = G / (1 - F(D, A))
        for k in range(1, 17):
            word = W * k
            M = 2**(k * E + 1)
            r = (-c * pow(d, -1, M)) % M
            assert r == inverse_residue(word)
            assert r & 1
            if M >= 2 * c:
                assert r >= F(M, 2 * d)
            for lift in (0, 1, 3):
                a = r + lift * M
                assert a > 1
                odd, shortcut, times = replay_word(a, word)
                assert d * odd[-1] + c == F(A, D)**k * (d * a + c)
                expected_bits = [bit for e in word
                                 for bit in [1] + [0] * (e - 1)] + [1]
                assert [x & 1 for x in shortcut] == expected_bits
                runs = runs_from_word(3, word, odd, times)
                positive = sum((max(F(0), r0["t"]) for r0 in runs), F(0))
                assert positive < K / a
            records.append(dict(word=list(W), repetitions=k, E=E,
                                c=c, d=d, residue=str(r),
                                reciprocal_coefficient=10*k*len(W)+90+2*d,
                                G=str(G), K=str(K),
                                corner_bound_applicable=M >= 2*c))
    R_records = []
    for k in range(1, 65):
        M = 2**(3*k + 1)
        assert inverse_residue((1, 2)*k) == M - 5
        a = M - 5
        odd, shortcut, times = replay_word(a, (1, 2)*k)
        n = 2**71+1 if a >= 2**71+1 else 3
        runs = runs_from_word(n, (1, 2)*k, odd, times)
        charge = F(0)
        for r in runs:
            assert (r["s"], r["e"]) == (2, 2)
            assert r["t"] > 0 and r["credit"] == 0
            assert r["t"] < 6*r["flux"]
            charge += r["t"]
        assert charge < 6*(F(1, a)-F(1, odd[-1])) < F(6, a)
        assert a > M//2 and a.bit_length()-1 == 3*k
        R_records.append(dict(k=k, source_bits=a.bit_length(),
                              exact_corner=str(a), runs=len(runs)))
    return dict(fixed_word_controls=records, R_telescope_controls=R_records)


def constants_and_source_rows():
    assert F(276, 125)**7 < 256
    assert F(151, 125)**35 > 3**6
    assert 3*40**8*125**7 < 39**8*151**7
    assert 3000**22 < 2**256
    state = {2: 1}
    rows = []
    for k in range(3, 256):
        nxt = defaultdict(int)
        for r, count in state.items():
            for bit in (0, 1):
                if 3**(r+bit) > 2**k:
                    nxt[r+bit] += count
        state = dict(nxt)
        if k < 70:
            continue
        n0 = max(2**71+1, 3*2**(k-1)+3)
        m0 = n0.bit_length()
        L = sum(state.values())
        ratio = F(L, 2**m0)
        rows.append(dict(width=k, m=m0, minimum_n=str(n0), count=str(L),
                         ratio=str(ratio), m_ratio=str(m0*ratio),
                         intercept=str((20*m0+316)*ratio),
                         slope=str(20*ratio)))
    assert len(rows) == 186
    for key in ("ratio", "m_ratio", "intercept", "slope"):
        assert max(rows, key=lambda r: F(r[key]))["width"] == 71
    peak = next(r for r in rows if r["width"] == 71)
    assert peak["m"] == 72 and int(peak["count"]) == 2483007077973438304
    a = F(34063753350948106733, 36893488147419103232)
    b = F(387969855933349735, 36893488147419103232)
    assert a == F(peak["intercept"]) and b == F(peak["slope"])
    analytic_a = F(96, 3000)*(20+F(296, 258))
    analytic_b = F(96, 3000)*F(20, 258)
    assert analytic_a < a and analytic_b < b
    assert a+20*b < F(6, 5)
    assert a+16*b < F(11, 10)
    C8 = F(7618091890243831687161, 272394937772592332800000)
    old_tail = F(33, 1048576)
    new_tail = F(3, 2621440)
    margin = F(7, 250)-C8-old_tail-new_tail
    assert margin == F(82026271063871239, 272394937772592332800000)
    assert margin > 0
    return dict(rows=rows, intercept=str(a), slope=str(b),
                analytic_intercept=str(analytic_a), analytic_slope=str(analytic_b),
                K20_exact=str((a+20*b)/2**20), K20_allowance=str(new_tail),
                C8=str(C8), old_tail=str(old_tail),
                combined_cap="7/250", combined_margin=str(margin),
                imports=["Actual least-source injection and P_C bounds",
                         "Canonical endpoint capacity for distinct-input paths",
                         "C8 balanced-group and earlier K15 tail allowances"])


def generating_series_controls():
    out = []
    for h, p in ((1, 1), (4, 3), (7, 5), (9, 2), (16, 8),
                 (31, 21), (64, 33)):
        for r in (p, p+1, 6*p, 12*p):
            for z in (F(1, 2), F(2, 5)):
                j0 = h+r-p
                partial = sum((comb(j-h, r-p)*z**j
                               for j in range(j0, j0+100)), F(0))
                exact = z**(h+r-p)/(1-z)**(r-p+1)
                assert partial < exact
                assert exact == z**(h-1)*(z/(1-z))**(r-p+1)
                if z == F(1, 2):
                    assert exact == F(1, 2**(h-1))
            out.append(dict(h=h, p=p, r=r))
    return out


def prehit_path(a):
    path = [a]
    seen = set()
    while path[-1] != 1:
        x = path[-1]
        assert x not in seen
        seen.add(x)
        path.append((3*x+1)//2 if x & 1 else x//2)
        assert len(path) < 20000
    return path


def actual_canonical_controls():
    records, corners = [], 0
    for seed in (3, 7, 27, 97, 871, 2**25-5, 2**49-5, 2**73-5):
        path = prehit_path(seed)
        N = len(path)-1
        cumulative = [0]
        for x in path[:-1]:
            cumulative.append(cumulative[-1]+(x & 1))
        Dtimes = [t+x.bit_length()-1 for t, x in enumerate(path)]
        assert all(v >= u for u, v in zip(Dtimes, Dtimes[1:]))
        for k in (1, 2, 3, 4, 8, 16, 24):
            h, p = 3*k+1, 2*k+1
            mass = F(0)
            cells = defaultdict(int)
            endpoints = defaultdict(set)
            corner_count = 0
            for t, a in enumerate(path[:-1]):
                if not a & 1 or (a+5) % 2**h:
                    continue
                j = a.bit_length()-1
                if t+j >= N:
                    continue
                mass += F(1, a)
                if j < h:
                    assert a == 2**h-5 and j == h-1
                    corner_count += 1
                    continue
                assert [x & 1 for x in path[t:t+h]] == [1, 1, 0]*k+[1]
                r = cumulative[t+j]-cumulative[t]
                assert r >= p
                y = path[t+j]
                assert 3**r < y < 2*3**r and y % 3
                assert y not in endpoints[r]
                endpoints[r].add(y)
                cells[j, r] += 1
            assert corner_count <= 1
            corners += corner_count
            for (j, r), count in cells.items():
                assert count <= comb(j-h, r-p)
            for r, targets in endpoints.items():
                assert len(targets) <= 2*3**(r-1)
            assert mass < F(20*k+92, 2**(3*k+1))
            records.append(dict(seed=str(seed), k=k, path_length=N,
                                matching_mass_positive=mass > 0,
                                corner_count=corner_count,
                                restricted_cells=len(cells)))
    return dict(records=records, corners=corners,
                scope="Actual pre-hit canonical paths; original core not asserted.")


def source_count(n):
    H = (4*n-2)//3
    k = (H-n).bit_length()
    row, short = {2: 1}, 0
    for depth in range(3, k+1):
        short += sum(count for odds, count in row.items()
                     if (3*n-k)*2**depth < 3*H*3**odds
                     and n*3**odds < H*2**depth)
        nxt = defaultdict(int)
        for odds, count in row.items():
            for bit in (0, 1):
                r = odds+bit
                if 2**depth*n**r < (3*n+1)**r:
                    nxt[r] += count
        row = dict(nxt)
    bandwidth = short+sum(row.values())
    row = {2: 1}
    for depth in range(3, H.bit_length()+1):
        nxt = defaultdict(int)
        for odds, count in row.items():
            for bit in (0, 1):
                r = odds+bit
                if 3**r > 2**(depth-1):
                    nxt[r] += count
        row = dict(nxt)
    return min(bandwidth, 2*sum(row.values()))


def actual_core_controls():
    results = []
    for seed in CORE_SEEDS:
        n, u, word = int(seed["n"]), int(seed["u"]), seed["word"]
        H, m = (4*n-2)//3, n.bit_length()
        odd, shortcut, times = replay_word(u, word)
        assert n >= 2**71 and n & 1 and n <= u <= H
        assert n <= odd[-1] <= H
        assert all(a > H for a in odd[1:-1])
        assert len(set(shortcut[:-1])) == len(shortcut)-1
        phases, nums, U, E = [F(0)], [0], 0, 0
        for g, e in enumerate(word, 1):
            U = 3*U+2**E
            E += e
            nums.append(U)
            phases.append(F(U, 3**g))
        modulus, residue = 2**(E+1), inverse_residue(word)
        low = max(n, -((-(2**E*n-U))//3**len(word)))
        high = min(H, (2**E*H-U)//3**len(word))
        for g in range(1, len(word)):
            low = max(low, (2**times[g]*H-nums[g])//3**g+1)
        assert low+(residue-low) % modulus == u <= high
        assert phases[-1]/u < F(15, 32)
        Pstar, Q = source_count(n), phases[-1]
        B = 5+F(n, 100000*Pstar)
        runs = runs_from_word(n, word, odd, times)
        C = set()
        for i, r in enumerate(runs):
            a, g = r["a"], r["odd_index"]
            ell = a.bit_length()-1
            height = ell-(m-1)
            J = 2**ell//(2000*Pstar*(height+1)*(height+2))
            dtime = r["time"]+ell
            if (g > 0 and H < a < 2**(64*m)
                and dtime < E and 64*shortcut[dtime] > a
                and phases[g] > B and Q-phases[g] > B
                and i > J and len(runs)-i > J):
                C.add(i)
        assert [runs[i]["odd_index"] for i in sorted(C)] == seed["expected_core"]
        chains, i = [], 0
        while i < len(runs):
            if (runs[i]["s"], runs[i]["e"]) != (2, 2):
                i += 1
                continue
            j = i
            while j < len(runs) and (runs[j]["s"], runs[j]["e"]) == (2, 2):
                j += 1
            chains.append((i, j))
            i = j
        chain_records = []
        original = sum((r["t"] if i in C else -r["credit"]
                        for i, r in enumerate(runs)), F(0))
        for k in (1, 2, 3, 4):
            selected = [(i, j) for i, j in chains
                        if j-i >= k and any(v in C for v in range(i, j))]
            positive, reciprocal, paid = F(0), F(0), set()
            for i, j in selected:
                a = runs[i]["a"]
                assert (a+5) % 2**(3*k+1) == 0
                assert runs[i]["time"]+a.bit_length()-1 < E
                reciprocal += F(1, a)
                local = sum((runs[v]["t"] for v in range(i, j)), F(0))
                assert 0 < local < F(6, a)
                positive += local
                paid |= C.intersection(range(i, j))
            assert reciprocal < F(20*k+92, 2**(3*k+1))
            assert positive < F(60*k+276, 2**(3*k))
            actual_paid = sum((max(F(0), runs[v]["t"]) for v in paid), F(0))
            residual = (sum((max(F(0), r["t"]) for i, r in enumerate(runs)
                             if i in C-paid), F(0))
                        -sum((max(F(0), -runs[i]["t"]) for i in C), F(0))
                        -sum((r["credit"] for i, r in enumerate(runs)
                              if i not in C), F(0)))
            assert original == actual_paid+residual
            assert actual_paid <= positive
            chain_records.append(dict(k=k, selected_chains=len(selected),
                                      selected_core_occurrences=len(paid),
                                      positive_charge=str(positive)))
        results.append(dict(name=seed["name"], n=str(n), source=str(u),
                            core_odd_indices=seed["expected_core"],
                            Pstar=str(Pstar), chains=chain_records,
                            K20_cutoff=(m+22)//3,
                            maximum_R_chain=max((j-i for i, j in chains), default=0),
                            scope="Exact saved least-source first return; original core and credits retained."))
    assert len(results) == 4
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path("short_signed_certificate.json"))
    args = parser.parse_args()
    certificate = dict(
        scope="Proof arithmetic and fixed exact controls; no exhaustive census or unrestricted central bound.",
        source_and_budget=constants_and_source_rows(),
        repetitions=repetition_controls(),
        generating_series=generating_series_controls(),
        canonical_paths=actual_canonical_controls(),
        original_core_profiles=actual_core_controls())
    args.output.write_text(json.dumps(certificate, indent=2)+"\n")
    print("Verified 186 source rows, 80 fixed-word repetition cylinders, 64 R telescopes,")
    print("56 canonical path/threshold controls, and 4 genuine original-core profiles.")
    print("K20 long-R-chain allowance:", certificate["source_and_budget"]["K20_allowance"])
    print("Combined 7/250 margin:", certificate["source_and_budget"]["combined_margin"])
    print("Certificate:", args.output)


if __name__ == "__main__":
    main()
