#!/usr/bin/env python3
"""Independent exact audit of phase/late-selection constants and credit ledger.

Standard library only. The certified auxiliary MGF, source injection, and
earlier group/tail inequalities are stated theorem inputs. This program does
not re-prove those theorems or bound the remaining unrestricted signed sum.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions must remain enabled.")


def exp_lower(x, terms=48):
    assert x >= 0
    term = total = F(1)
    for k in range(1, terms+1):
        term *= x/k
        total += term
    return total


def chi(s, e):
    return max(F(0), 2-F(2, 3)**s-F(2**(s+e-1), 3**s))


def phase_constants():
    theta, epsilon = F(200, 143), F(1, 2000)
    mgf = F(82262531839, 10**10)
    slices = []
    for s in range(1, 9):
        assert chi(s, 2*s+3) == 0
        slices.append(sum((chi(s, e)/2**(s+e-1)
                           for e in range(2, 2*s+3)), F(0)))
    mass = sum(slices, F(0))+F(1, 128)
    assert mass == F(8563637, 26873856)
    exponent = 5*theta+1-epsilon
    lower = exp_lower(exponent)
    assert lower > 2000
    assert epsilon*lower > 1
    bulk_upper = mass*(mgf-1)/(theta*lower)
    B0 = F(557, 10**6)
    assert bulk_upper < B0
    assert chi(2, 2) == F(2, 3) and 3*chi(2, 2) == 2
    assert chi(5, 4) == F(22, 27) and 2*chi(5, 4) < 2
    return dict(theta=str(theta), epsilon=str(epsilon), mgf_input=str(mgf),
                run_mass=str(mass), run_mass_slices=list(map(str, slices)),
                exponent=str(exponent), terms=48,
                exponential_lower=str(lower), rigorous_bulk_upper=str(bulk_upper),
                bulk_allowance=str(B0), R_coefficient=str(chi(2, 2)),
                C_coefficient=str(chi(5, 4)))


def source_ratio():
    cstar = F(620751769493359576, 1180591620717411303425)
    state = {2: 1}
    records = []
    for k in range(3, 256):
        nxt = defaultdict(int)
        for r, count in state.items():
            for bit in (0, 1):
                if 3**(r+bit) > 2**k:
                    nxt[r+bit] += count
        state = dict(nxt)
        if k < 70:
            continue
        n = max(2**71+1, 3*2**(k-1)+3)
        H = (4*n-2)//3
        L = sum(state.values())
        ratio = F(L, H+1)
        assert ratio <= cstar
        records.append(dict(width=k, n=str(n), H_plus_one=str(H+1),
                            L=str(L), ratio=str(ratio)))
    assert len(records) == 186
    peak = max(records, key=lambda r: F(r["ratio"]))
    assert peak["width"] == 71
    assert int(peak["n"]) == 3*2**70+3
    assert int(peak["H_plus_one"]) == 2**72+4
    assert int(peak["L"]) == 2483007077973438304
    assert F(peak["ratio"]) == cstar
    assert 3000**22 < 2**256
    analytic = F(96, 3000*258)
    assert analytic < cstar
    return dict(cstar=str(cstar), finite_rows=records,
                analytic_upper=str(analytic),
                source_injection_status="Imported theorem, not inferred from these counts.")


def final_constants():
    alpha = F(4899, 3904)
    n0 = 2**71+1
    cstar = F(620751769493359576, 1180591620717411303425)
    bstar = 2-F(4, 3)*alpha+alpha/(3*n0)
    assert bstar > 0
    xi = cstar*bstar
    assert xi == F(233780533697387848783846738578530187119279,
                   1360345457110368011635407200764280342013018600)
    B0 = F(557, 10**6)
    eta = F(6761, 3904000)-B0-xi
    assert eta == F(54574868297226451161980857248905415351224059717,
                    54413818284414720465416288030571213680520744000000)
    assert eta > F(1002, 10**6)
    margin = eta-F(1002, 10**6)
    assert margin == F(52222376242901255633736642273059243342274229,
                       54413818284414720465416288030571213680520744000000)
    C8 = F(7618091890243831687161, 272394937772592332800000)
    combined_earlier = C8+F(33, 1048576)+F(3, 2621440)
    group_margin = F(7, 250)-combined_earlier
    assert group_margin == F(82026271063871239, 272394937772592332800000)
    assert group_margin > 0
    assert F(116073, 3904000)-F(7, 250) == F(6761, 3904000)
    return dict(alpha=str(alpha), minimum_odd_n=str(n0), cstar=str(cstar),
                bstar=str(bstar), xi=str(xi), bulk_allowance=str(B0),
                eta=str(eta), simpler_sufficient_remainder="1002/1000000",
                margin_above_simple=str(margin),
                earlier_exact_envelope_allowance=str(combined_earlier),
                earlier_unused_numeric_margin=str(group_margin),
                full_combination_range="2^71 <= odd n < 2^272")


def ledger_controls():
    # Algebra controls on labeled occurrences, not Collatz paths.
    # Same numerical state 1001 is intentionally repeated in two profiles.
    scale = F(1, 10**30)
    rows = {
        ("A", 0): (True, F(3, 10)*scale, F(0), 1001),
        ("A", 1): (True, F(1, 5)*scale, F(0), 2003),
        ("A", 2): (True, -F(1, 7)*scale, F(0), 3001),
        ("A", 3): (False, F(1, 11)*scale, F(0), 4001),
        ("A", 4): (False, -F(1, 9)*scale, F(1, 20)*scale, 5003),
        ("B", 0): (True, F(3, 10)*scale, F(0), 1001),
        ("B", 1): (True, F(1, 4)*scale, F(0), 6007),
        ("B", 2): (True, -F(1, 13)*scale, F(0), 7001),
        ("B", 3): (False, F(1, 17)*scale, F(0), 8009),
        ("B", 4): (False, -F(1, 23)*scale, F(1, 19)*scale, 9001),
    }
    C = {i for i, row in rows.items() if row[0]}
    psi = {i: max(F(0), row[1]) for i, row in rows.items()}
    N0 = (sum((max(F(0), -rows[i][1]) for i in C), F(0))
          +sum((rows[i][2] for i in rows if i not in C), F(0)))
    original = sum((row[1] if i in C else -row[2]
                    for i, row in rows.items()), F(0))
    assert original == sum((psi[i] for i in C), F(0))-N0
    envelopes = [
        {("A", 0), ("A", 1), ("A", 3)},
        {("A", 1), ("B", 0)},
        {("B", 0), ("B", 3)},
        {("A", 0)},
    ]
    U = sum((psi[i] for env in envelopes for i in env), F(0))
    D = C.intersection(set().union(*envelopes))
    Scov = U-sum((psi[i] for i in D), F(0))
    assert Scov > 0
    selected = {("B", 1)}
    Yselected = sum((psi[i] for i in selected), F(0))
    Yrest = sum((psi[i] for i in C-D-selected), F(0))
    assert original == U+Yselected+Yrest-N0-Scov
    # Recover the single-group relation without duplicating negatives.
    G = envelopes[0]
    Ngroup = (sum((max(F(0), -rows[i][1]) for i in C.intersection(G)), F(0))
              +sum((rows[i][2] for i in G-C), F(0)))
    Sgroup = sum((psi[i] for i in G-C), F(0))
    Rgroup = (sum((max(F(0), -rows[i][1]) for i in C.intersection(G)), F(0))
              +sum((psi[i]+rows[i][2] for i in G-C), F(0)))
    assert Rgroup == Ngroup+Sgroup

    alpha, n = F(4899, 3904), 2**71+1
    H, P, M = (4*n-2)//3, 2, 1
    cstar = F(620751769493359576, 1180591620717411303425)
    bstar = 2-F(4, 3)*alpha+alpha/(3*n)
    bn = 2-alpha*F(H+1, n)
    assert F(M, H+1) < cstar and bstar >= bn
    assert Yselected <= F(2, H+1) and M <= P
    xi = cstar*bstar
    surplus_parts = [
        (cstar-F(M, H+1))*bstar,
        F(M, H+1)*(bstar-bn),
        F(2*M, H+1)-Yselected,
        alpha*F(P-M, n),
    ]
    assert all(x >= 0 for x in surplus_parts)
    Eselected = sum(surplus_parts, F(0))
    assert Yselected-alpha*F(P, n) == xi-Eselected
    assert (original-alpha*F(P, n)
            == U+xi+Yrest-N0-Scov-Eselected)
    assert psi["A", 0]+psi["B", 0] == F(3, 5)*scale
    return dict(scope="Finite algebra controls, not actual trajectories.",
                original_occurrences=len(rows), repeated_state_copies=2,
                whole_envelopes=len(envelopes), coverage_surplus=str(Scov),
                original_negative_resource=str(N0),
                selected_surplus_parts=list(map(str, surplus_parts)),
                exact_identity="Z-alpha*P/n=U+xi+Yrest-N0-Scov-Eselected")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path("combination_credits_certificate.json"))
    args = parser.parse_args()
    data = dict(status="exact arithmetic audit passed",
                scope="Remaining signed inequality is not proved.",
                phase=phase_constants(), canonical_ratio=source_ratio(),
                combination=final_constants(), retained_ledger=ledger_controls())
    args.output.write_text(json.dumps(data, indent=2)+"\n")
    print("Verified improved bulk <557/10^6 and 186 canonical source-ratio rows.")
    print("Verified eta >1002/10^6 and both nonnegative surplus identities.")
    print("Full combination remains restricted to odd 2^71 <= n < 2^272.")
    print("Certificate:", args.output)


if __name__ == "__main__":
    main()
