from pathlib import Path
from math import exp,sqrt
from bisect import bisect_left,bisect_right
import numpy as np
D=1<<40
lo=D//1024
bounds=[lo]
while bounds[-1]<D:
    bounds.append(min(D,(bounds[-1]*513+511)//512))
N=len(bounds)-1
print('N',N)
theta=1.4
# p index zero-tail or bin+1; ranges precomputed
rows=[]
for i in range(N):
    x0,x1=bounds[i],bounds[i+1]
    row=[];e=1
    while (1<<e)*x0 <=3*D:
        v0=(1<<e)*x0;v1=(1<<e)*x1
        # bins [a,b] that intersect exact transformed closed interval
        a=max(0,bisect_left(bounds,(v0+2)//3)-1)
        b=min(N-1,bisect_right(bounds,v1//3)-1)
        tail=100-50*sqrt(v0/(3*D)) if v0<3*bounds[0] else 0.
        if v1<3*bounds[0]:a,b=0,-1
        row.append((2.**-e,a,b,tail));e+=1
    rows.append((exp(theta*x1/(3*D)),2.**-(e-1),row))
F=np.ones(N)
for it in range(10000):
    new=np.empty(N)
    for i,(mult,k,r) in enumerate(rows):
        val=k
        for p,a,b,tail in r:
            val+=p*max(tail,float(np.max(F[a:b+1])) if b>=a else 1.)
        new[i]=mult*val
    dif=float(np.max(np.abs(new-F)))
    F=new
    if it%100==0:print(it,dif,F[-1],min(F),max(F),flush=True)
    if dif<1e-11:break
print('final',it,dif,F[-1],max(F),'postphase',(F[-1]-1)*exp(-theta*5)/theta)
print('global_envelope_margin',min(100-50*sqrt(bounds[i+1]/D)-F[i] for i in range(N)))
np.savez(Path(__file__).with_name('killed_phase_candidate.npz'),bounds=np.array(bounds),values=F,theta=theta)
