#!/usr/bin/env python3
"""Bounded diagnostic; candidates are independently checked exactly."""
from pathlib import Path
import importlib.util
import json
import time

SPEC=importlib.util.spec_from_file_location("controls", Path(__file__).resolve().parents[1]/"prior_results"/"verifiers"/"verify_chronological_coalescence.py")
controls=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(controls)

E=U=0
for i in range(4,50):
    e=(3**(i+1)).bit_length()-(3**i).bit_length()
    U=3*U+2**E
    E+=e
M=2**(E+1)
r=(2**E-U)*pow(3**46,-1,M)%M
base=r+M*((91-r)*pow(M,-1,729)%729)
period=729*M

start=time.monotonic()
stats={"first_lift":4383,"last_lift_inclusive":20766,"tested":0,"band_returns":0,
       "relaxed_candidates":0,"exact_rejections":0,"guarded":0}
for lift in range(4383,20767):
    stats["tested"]+=1
    z=base+lift*period
    u=(64*z-73)//81
    n=(3*u+5)//4
    if n%2==0:n+=1
    H=(4*n-2)//3
    assert n<=u<=H
    x=u
    word=[]
    states=[u]
    times=[0]
    phases=[0.0]
    q=0.0
    lam=1.0
    exponent=0
    seen={u}
    for g in range(1000):
        y=3*x+1
        e=(y&-y).bit_length()-1
        x=y>>e
        word.append(e)
        exponent+=e
        q+=lam/3.0
        lam*=2**e/3.0
        states.append(x);times.append(exponent);phases.append(q)
        if x<=H:break
        if x in seen:
            stats["guarded"]+=1
            break
        seen.add(x)
    else:
        stats["guarded"]+=1
        continue
    if not n<=x<=H:
        continue
    stats["band_returns"]+=1
    gsafe=next((g for g,t in enumerate(times) if 2**(t+1)>H-n),None)
    if gsafe is None:continue
    run_start=0
    relaxed=[]
    for end,e in enumerate(word,1):
        if e<2:continue
        s=end-run_start
        if (run_start>=gsafe and s==2 and e==2
            and phases[run_start]>5.2 and q-phases[run_start]>5.2
            and times[run_start]+states[run_start].bit_length()-1<exponent):
            relaxed.append(run_start)
        run_start=end
    if not relaxed:continue
    stats["relaxed_candidates"]+=1
    try:
        p=controls.replay(n,{"u":str(u),"word":word})
        Pstar=controls.source_count(n)
        C=controls.core(p,Pstar)
        future=[p["runs"][i]["i"] for i in C
                if p["runs"][i]["i"]>=gsafe and p["runs"][i]["s"]==2 and p["runs"][i]["e"]==2]
    except AssertionError:
        stats["exact_rejections"]+=1
        continue
    if future:
        data={"n":str(n),"source":str(u),"word":word,"lift":lift,
              "guaranteed_singleton_depth":gsafe,"post_singleton_R_core_starts":future,
              "original_core_odd_starts":[p["runs"][i]["i"] for i in sorted(C)],
              "Pstar":str(Pstar),"stats":stats,"elapsed_seconds":time.monotonic()-start}
        out=Path(__file__).with_name("post_resolution_candidate.json")
        out.write_text(json.dumps(data,indent=2)+"\n")
        print(json.dumps(data,indent=2))
        break
else:
    stats["elapsed_seconds"]=time.monotonic()-start
    Path(__file__).with_name("post_resolution_search_negative.json").write_text(json.dumps(stats,indent=2)+"\n")
    print(json.dumps(stats,indent=2))
