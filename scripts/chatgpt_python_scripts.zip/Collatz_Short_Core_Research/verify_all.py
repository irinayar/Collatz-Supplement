#!/usr/bin/env python3
"""Replay the exact short-core research packet offline, retaining imports.

Run from any working directory. The packet itself is not modified. Optional
--report writes a reproduction receipt to the specified location.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

if not __debug__:
    raise SystemExit("Run without -O or -OO: exact checks require assertions.")

ROOT = Path(__file__).resolve().parent
CHECKS = [
    ("phase/verify_phase_frontier.py", "phase/phase_frontier_verification.json"),
    ("repetition/verify_short_signed_transfer.py", "repetition/short_signed_certificate.json"),
    ("occupation/verify_zero_credit_returns.py", "occupation/zero_credit_returns_certificate.json"),
    ("audits/verify_phase_frontier_audit.py", "audits/phase_frontier_independent_audit_certificate.json"),
    ("audits/verify_combination_credits.py", "audits/combination_credits_certificate.json"),
]


def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()
                if key not in {"elapsed_seconds_informational", "runtime_seconds"}}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    return value


def verify_manifest():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for row in manifest["files"]:
        path = ROOT / row["path"]
        assert path.is_file(), "Missing file: " + row["path"]
        data = path.read_bytes()
        assert len(data) == row["bytes"], "Size mismatch: " + row["path"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"], "Hash mismatch: " + row["path"]
    return len(manifest["files"])


def run_command(command, env):
    run = subprocess.run(command, cwd=ROOT, env=env, text=True,
                         capture_output=True, timeout=120)
    if run.returncode:
        raise RuntimeError(" ".join(map(str, command)) + "\n" +
                           run.stdout[-6000:] + "\n" + run.stderr[-6000:])
    return run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        help="Optional reproduction receipt; normally outside the extracted packet.")
    args = parser.parse_args()
    start = time.monotonic()
    file_count = verify_manifest()
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    results, generated = [], {}
    with tempfile.TemporaryDirectory(prefix="collatz_short_core_verify_") as tempname:
        temp = Path(tempname)
        for script, expected_path in CHECKS:
            dest = temp / Path(expected_path).name
            cmd = [sys.executable, str(ROOT / script), "--output", str(dest)]
            if script == "audits/verify_phase_frontier_audit.py":
                cmd += ["--primary", str(ROOT / "phase/verify_phase_frontier.py"),
                        "--certificate", str(ROOT / "phase/killed_phase_certificate.json")]
            run_command(cmd, env)
            observed = json.loads(dest.read_text())
            expected = json.loads((ROOT / expected_path).read_text())
            assert normalized(observed) == normalized(expected), "Certificate mismatch: " + expected_path
            generated[Path(expected_path).name] = observed
            results.append({"verifier": script, "certificate": expected_path,
                            "exit_code": 0, "mathematical_certificate_equal": True})
            print("PASS:", script, flush=True)

        phase = generated["phase_frontier_verification.json"]
        audit = generated["phase_frontier_independent_audit_certificate.json"]
        combo = generated["combination_credits_certificate.json"]
        repetition = generated["short_signed_certificate.json"]
        assert phase["constants"]["all_positive_core_before_width_resolution_sharp_upper"] == "557/1000000"
        assert audit["tangent_bulk_simple"] == combo["phase"]["bulk_allowance"] == "557/1000000"
        assert (phase["constants"]["second_and_later_late_signed_allowance"]
                == audit["second_and_later_signed_remainder"]
                == combo["combination"]["eta"])
        assert repetition["source_and_budget"]["K20_allowance"] == "3/2621440"
        assert (repetition["source_and_budget"]["combined_margin"]
                == combo["combination"]["earlier_unused_numeric_margin"])
        assert phase["supersolution"]["sha256"] == audit["primary_certificate_sha256"]

        prior_receipt = temp / "prior_packet_reproduction.json"
        run_command([sys.executable, str(ROOT / "prior_results/verify_all.py"),
                     "--report", str(prior_receipt)], env)
        prior = json.loads(prior_receipt.read_text())
        assert prior["status"] == "PASS" and len(prior["checks"]) == 5
        print("PASS: prior_results/verify_all.py (five imported checks)", flush=True)

    report = {
        "status": "PASS",
        "manifest_files_verified": file_count,
        "new_exact_checks": results,
        "new_certificate_cross_consistency": True,
        "imported_prior_packet": normalized(prior),
        "bulk_bound": "557/1000000",
        "remaining_sufficient_signed_allowance": "1002/1000000",
        "remaining_signed_allowance_status": "UNPROVED for the unrestricted remaining contribution",
        "old_group_combination_range": "2^71 <= odd n < 2^272",
        "new_bulk_theorem_range": "all odd n >= 2^71",
        "excluded_comparison_fields": ["elapsed_seconds_informational", "runtime_seconds"],
        "runtime_seconds": round(time.monotonic() - start, 6),
    }
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
