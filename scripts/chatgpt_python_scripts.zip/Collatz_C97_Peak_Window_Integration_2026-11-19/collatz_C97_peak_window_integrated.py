#!/usr/bin/env python3
"""Exact C97 + rigorous peak-window + run-order modular sieve.
Run-boundary anchored, ordered compositions; no manuscript/inventory mutation.
"""
from collections import Counter
from functools import lru_cache
from math import gcd
import argparse, json

@lru_cache(None)
def order_3_over_2(q):
    assert q>1 and gcd(q,6)==1
    x=3*pow(2,-1,q)%q
    t=1;v=x
    while v!=1:
        v=v*x%q;t+=1
    return t

def factor_prime_powers(n):
    ans=[];p=2
    while p*p<=n:
        if n%p==0:
            q=1
            while n%p==0:n//=p;q*=p
            ans.append(q)
        p+=1 if p==2 else 2
    if n>1:ans.append(n)
    return ans

def word_data(rs,ds):
    bits=[v for r,d in zip(rs,ds) for v in ([1]*r+[0]*d)]
    L=len(bits);A=sum(bits);D=(1<<L)-3**A
    if D<=0:return None
    U=0
    for i,b in enumerate(bits):
        if b:U=3*U+(1<<i)
    X=U; xs=[]
    for b in bits:
        xs.append(X)
        if b:
            assert (3*X+D)%2==0
            X=(3*X+D)//2
        else:
            assert X%2==0
            X//=2
    assert X==U
    S=min(xs)+max(xs)
    flat=True
    for i,b in enumerate(bits):
        j=(i+1)%L
        if b and not bits[j] and xs[i]+xs[j]<=S:flat=False
        if not b and bits[j] and 3*xs[i]>=2*S:flat=False
    return D,U,xs,flat,bits

def search(maxL=22, prune=True):
    totals=Counter(); per_length={}; samples=[]
    for L in range(3,maxL+1):
        C=Counter()
        for A in range(2,L):
            if 3**A>=2**L:continue
            D=2**L-3**A
            # For flat words all r_i>=2; hence k<=A/2 and k<=L-A.
            for k in range(1,min(A//2,L-A)+1):
                def visit(rs,ds,ell,a,U,peaks,odd_run_parity,mod5):
                    C['dfs_nodes']+=1
                    used=len(rs)
                    if used==k:
                        if ell!=L or a!=A:return
                        C['anchored_compositions']+=1
                        if D%5==0 and odd_run_parity==1:
                            assert mod5!=0
                            C['C97_pruned']+=1
                            # Excluded from integer-cycle search, but still count flat geometry.
                            v=word_data(rs,ds)
                            if min(v[2])>=D and v[3]:C['flat_C97_excluded']+=1
                            return
                        assert U==word_data(rs,ds)[1]
                        if U%D==0:C['integral_before_geometry']+=1
                        if all(U%q==0 for q in factor_prime_powers(D)):
                            C['prime_power_pass']+=1
                        v=word_data(rs,ds)
                        if min(v[2])<D:return
                        C['minimum_ge_1']+=1
                        if not v[3]:return
                        C['flat']+=1
                        if U%D==0:C['flat_integral']+=1
                        # C97 is already applied at the terminal modular state.
                        if len(samples)<8:samples.append({'L':L,'A':A,'runs':list(rs),'gaps':list(ds),'U':U,'D':D})
                        return
                    remaining=k-used-1
                    for r in range(2,A-a-2*remaining+1):
                        aa=a+r
                        # End of odd run at index ell+r-1 is a peak vertex.
                        peak_j=ell+r
                        peak_a=a+r
                        # q_j=3^peak_a / 2^peak_j, a pure word-walk height.
                        qnum=3**peak_a;qden=1<<peak_j
                        newpeaks=peaks+((qnum,qden),)
                        # Flat peaks have p_i/p_j < 5/3. Distortion of log
                        # heights <= log(2^L/3^A), so q_i/q_j < 5*2^L/(3*3^A).
                        # All comparisons exact, no floating logs.
                        if prune and len(newpeaks)>1:
                            first_num,first_den=newpeaks[0]
                            bad=False
                            for oldnum,oldden in newpeaks[1:]:
                                if (3*3**A*oldnum*first_den >= 5*2**L*first_num*oldden or
                                    3*3**A*first_num*oldden >= 5*2**L*oldnum*first_den):
                                    bad=True;break
                            if bad:
                                C['rigorous_peak_pruned']+=1
                                continue
                        # all peaks pairwise: check new peak against all prior peaks
                        if prune and len(newpeaks)>2:
                            bad=False
                            for oldnum,oldden in newpeaks[1:-1]:
                                if (3*3**A*qnum*oldden >= 5*2**L*oldnum*qden or
                                    3*3**A*oldnum*qden >= 5*2**L*qnum*oldden):
                                    bad=True;break
                            if bad:
                                C['rigorous_peak_pruned']+=1
                                continue
                        u2=3**r*U+(1<<ell)*(3**r-2**r)
                        for d in range(1,L-ell-r-3*remaining+1):
                            if ell+r+d+3*remaining>L:continue
                            visit(rs+(r,),ds+(d,),ell+r+d,aa,u2,newpeaks,odd_run_parity+(r%2),u2%5)
                visit((),(),0,0,0,(),0,0)
        per_length[L]=dict(C);totals.update(C)
    return {'maxL':maxL,'prune':prune,'totals':dict(totals),'per_length':per_length,'samples':samples}

def verify():
    # Exhaustive independent comparison: pruning cannot discard a truly flat word.
    a=search(17,True);b=search(17,False)
    for L in range(3,18):
        for field in ('flat_integral',):
            assert a['per_length'][L].get(field,0)==b['per_length'][L].get(field,0),(L,field)
    assert a['totals'].get('flat_integral',0)==0
    # Run identity, prime power order and C97 for all indexed mixed words to 13.
    checks=0;c97=0
    for L in range(3,14):
        for mask in range(1,(1<<L)-1):
            bits=[(mask>>i)&1 for i in range(L)]
            A=sum(bits);D=2**L-3**A
            if D<=0 or bits[0]!=1 or bits[-1]!=0:continue
            runs=[];i=0;U=0
            for j,b in enumerate(bits):
                if b:U=3*U+(1<<j)
            V=0
            while i<L:
                s=i;r=0
                while i<L and bits[i]:r+=1;i+=1
                d=0
                while i<L and not bits[i]:d+=1;i+=1
                runs.append(r)
                V=3**r*V+(1<<s)*(3**r-2**r)
            assert U==V
            if D%5==0 and sum(r%2 for r in runs)==1:
                assert U%5!=0;c97+=1
            for q in factor_prime_powers(D):
                if q>1 and q<200:
                    t=order_3_over_2(q)
                    for r in runs:
                        assert ((3**r-2**r)%q==0)==(r%t==0)
            checks+=1
    return {'pruned_vs_unpruned_through_L':17,'anchored_word_identity_checks':checks,'C97_checks':c97}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--maxL',type=int,default=22);p.add_argument('--verify-only',action='store_true');args=p.parse_args()
    val=verify();print('VERIFIED',val,flush=True)
    if not args.verify_only:
        result=search(args.maxL,True);result['verification']=val
        with open('/mnt/data/Collatz_C97_Peak_DP_results.json','w') as f:json.dump(result,f,indent=2)
        print('RESULT',result['totals'],flush=True)
        print('BY_LENGTH',[(L,x.get('flat',0)) for L,x in result['per_length'].items()],flush=True)
