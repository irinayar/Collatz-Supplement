#!/usr/bin/env python3
"""Exact-integer audit of three reported k=2 zero-tail exceptions."""
STARTS=(2802175,12013819,7781407)
def T(n): return (3*n+1)//2 if n&1 else n//2
def check(n):
    x=n; a=0; peak=n; first_coefficient=None
    for j in range(1,1001):
        a+=x&1
        x=T(x)
        peak=max(peak,x)
        if first_coefficient is None and 3**a<2**j: first_coefficient=j
        if x<n:
            return j,x,peak,a,first_coefficient
    raise AssertionError('No descent in 1000 steps')
if __name__=='__main__':
    expected={2802175:(37,1919440,107725058,23,37),12013819:(51,9886250,493198010,32,51),7781407:(97,6245185,971415098,61,97)}
    for n in STARTS:
        result=check(n)
        assert result==expected[n],(n,result)
        print(n,result,'T32 coefficient crossing?',result[-1]<=32,'T100?',result[-1]<=100)
