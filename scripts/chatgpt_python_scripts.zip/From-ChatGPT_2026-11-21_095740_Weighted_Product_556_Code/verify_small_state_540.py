#!/usr/bin/env python3
"""Exact, reproducible finite certificate for odd-count separation r <= 540."""
from fractions import Fraction
from functools import lru_cache
B = 999
@lru_cache(None)
def orbit_data(u):
    assert u >= 3 and u % 2
    n=u; length=odd=0; product=Fraction(1); seen=set()
    while n != 2:
        assert n >= 2 and n not in seen, (u,n)
        seen.add(n)
        if n & 1:
            product *= Fraction(3*n+1,3*n)
            n=(3*n+1)//2; odd+=1
        else: n//=2
        length+=1
    assert product == Fraction(2**(length+1), 3**odd*u),u
    return product,length,odd,max(seen)

best=(Fraction(0),None)
max_peak=0
for u in range(3,B+1,2):
    p,length,odd,peak=orbit_data(u)
    if p > best[0]: best=(p,u)
    max_peak=max(max_peak,peak)
assert best[1] == 993, best
assert best[0] == Fraction(2**61,3**32*993),best
q=Fraction(3*(B+2)+1,3*(B+2))
assert q == Fraction(3004,3003)
assert best[0]*q**540 < Fraction(3,2)
assert best[0]*q**541 > Fraction(3,2)
print('small odd starts checked:',len(range(3,B+1,2)))
print('maximum product:',best[0], 'at',best[1])
print('maximum trajectory peak:',max_peak)
print('large-state factor:',q)
print('540 inequality exact:', 2*best[0].numerator*3004**540 < 3*best[0].denominator*3003**540)
print('541 bound fails:', 2*best[0].numerator*3004**541 > 3*best[0].denominator*3003**541)
print('540 bound decimal:',float(best[0]*q**540))
print('541 bound decimal:',float(best[0]*q**541))

# Sharper certificate: charge one q for every odd step of the small-state suffix.
# This prevents counting the same odd steps both in the small-state product
# and in the generic large-state factor.
weighted_best=(Fraction(1),None,0,None)
for u in range(3,B+1,2):
    n=u; ratio=Fraction(1); s=0; seen=set()
    while n != 2:
        assert n not in seen
        seen.add(n)
        if n & 1:
            ratio *= Fraction(3*n+1,3*n)/q
            s+=1
            n=(3*n+1)//2
        else:
            n//=2
        if ratio > weighted_best[0]:
            weighted_best=(ratio,u,s,n)
assert weighted_best[1:] == (9,6,8), weighted_best
W=weighted_best[0]
assert W*q**556 < Fraction(3,2)
assert W*q**557 > Fraction(3,2)
print('weighted maximum:',W,'start, odd count, endpoint:',weighted_best[1:])
print('556 inequality exact:',2*W.numerator*3004**556 < 3*W.denominator*3003**556)
print('557 inequality fails for this envelope:',2*W.numerator*3004**557 > 3*W.denominator*3003**557)
print('556 bound decimal:',float(W*q**556))
print('557 bound decimal:',float(W*q**557))
