#!/usr/bin/env python3
"""Arbitrary-precision replay of every selected certificate and both projector DPs.
Usage: python3 verify.py [certificates.csv] [classification.bin]
Set SIX_ONLY=1 to replay only the 371013 newly rescued rows, retaining all label/hash checks.
Run normally (not python -O). This checks the selected witnesses and counts; the
complete exclusions are independently reconstructed by direct.cpp and valuation.cpp.
"""
import sys, hashlib, os
from pathlib import Path
from collections import Counter

M=1<<41; P=1<<27; PARENT=103; STEP=8192
p3=[3**j for j in range(102)]; p2=[1<<j for j in range(102)]
EXPECTED=[16011,251887,281031,195329,248833,285653,371013,9402949]
SIX=[22765,73963,53627,106775,113883]+[0]*7
GROUPS={'101010101010':96768,'1010102110':24260,'1010211010':39670,
        '10103010':11260,'1021101010':45126,'10212110':9458,'10301010':22368,
        '104110':2669,'104210':80,'2110101010':47293,'21102110':11016,
        '21211010':17419,'213010':3343,'30101010':26314,'302110':5849,
        '411010':5578,'421010':919,'5010':1623}
EXPECTED_MATRIX=[
[0,12823,2697,417,63,10,1,0,0,0,0,0],
[12674,176404,46156,9016,5907,1301,304,57,44,24,0,0],
[115863,93648,30655,29546,7812,2261,510,460,276,0,0,0],
[28958,45946,75514,27342,9872,2745,2954,1998,0,0,0,0],
[14523,107106,62562,30432,10573,13393,10244,0,0,0,0,0],
[32287,80324,61404,28602,43908,39128,0,0,0,0,0,0],SIX]

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while (block:=f.read(1<<20)):h.update(block)
    return h.hexdigest()

def v3(n):
    assert n>0
    v=0
    while n%3==0:n//=3;v+=1
    return v

def forward(r,jmax):
    x=r; a=0
    for j in range(1,jmax+1):
        if x&1:x=(3*x+1)//2;a+=1
        else:x//=2
        if p3[a]<p2[j]:return None
        if x%3==2 and (2*x-1)//3<r and 2*p3[a]<3*p2[j]:return None
    return x,a

def group_and_inverse(x,w,b,e):
    z=x; i=0; pairs=[]
    while i<b+e:
        v=v3(z+1);p=0
        while i<b+e and w>>i&1:
            assert z%3==2
            z=(2*z-1)//3;assert z>0
            p+=1;i+=1
        d=0
        while i<b+e and not(w>>i&1):
            z*=2;d+=1;i+=1
        if d:pairs.append((d,v-p))
    return z,''.join(f'{d}{off}' for d,off in pairs)

if __name__=='__main__':
    assert __debug__, 'do not disable assertions'
    cert=Path(sys.argv[1] if len(sys.argv)>1 else 'certificates.csv')
    cls=Path(sys.argv[2] if len(sys.argv)>2 else 'classification.bin')
    assert digest(cert)=='dd7cf37e38bec7e63b390051f943a8cf15cbc64a4faf95dd6946f77ece52ba0e'
    assert digest(cls)=='aadb5e023394e10faa9ad68391403b000f2f62903f9d31e750a9d07e32e7d94d'
    labels=cls.read_bytes();assert len(labels)==1<<27
    labelcounts=Counter()
    for b,n in Counter(labels).items():labelcounts[b&15]+=n;labelcounts[b>>4]+=n
    assert [labelcounts[e] for e in range(8)]==EXPECTED
    assert labelcounts[8]==(1<<28)-11052706 and sum(labelcounts.values())==1<<28
    assert not(set(labelcounts)-set(range(9)))
    parents={r for r in range(PARENT,P,STEP) if forward(r,27) is not None}
    assert len(parents)==1982
    six_only=os.environ.get("SIX_ONLY")=="1"
    counts=[[0]*12 for _ in range(7)];groups=Counter();last=0;minimum0=M;minimum1=M;N=0;selected=0
    min0row=min1row=None
    with open(cert) as f:
        assert next(f).strip()=='r,x,a,e,b,word_bits,origin'
        for line in f:
            r,x,a,e,b,w,m=map(int,line.split(','))
            assert last<r<M and r%STEP==PARENT and r%P in parents
            last=r;N+=1
            if six_only and e!=6:continue
            selected+=1
            assert 0<=e<=6 and 26<=a<=37 and 0<=b<=a and w.bit_length()<=b+e and w.bit_count()==b
            i=(r-PARENT)//STEP;assert (labels[i//2]>>(4*(i%2)))&15==e
            assert forward(r,41)==(x,a)
            z=x
            # Replay every inverse edge in arbitrary-precision Python integers.
            for j in range(b+e):
                if w>>j&1:
                    assert z%3==2;z=(2*z-1)//3;assert z>0 and z&1
                else:z*=2
            assert z==m and 0<m<r
            shift=(1<<(b+e))*p3[a-b]
            assert shift<M
            assert b==a or m%3!=2 # canonical maximal last odd run
            counts[e][a-26]+=1
            if e==6:
                z2,group=group_and_inverse(x,w,b,e);assert z2==m;groups[group]+=1
                if r-m<minimum0:minimum0=r-m;min0row=(r,x,a,e,b,w,m)
                if M-shift<minimum1:minimum1=M-shift;min1row=(r,x,a,e,b,w,m)
    assert N==1649757 and groups==GROUPS
    if six_only:assert selected==371013 and counts[6]==SIX
    else:assert selected==1649757 and counts==EXPECTED_MATRIX
    assert minimum0==168040 and minimum1==217667600384
    print('PASS arbitrary-precision replay of',selected,'selected certificate rows')
    print('PASS all labels and counts; all eighteen groups; exact gap minima',minimum0,minimum1)
    print('min intercept row',min0row,'min slope row',min1row)
    # Forward weighted DP over all certified six-even length-41 masks.
    d={a:n for a,n in enumerate(SIX,26) if n}
    for j in range(41,100):
        nd=Counter()
        for a,n in d.items():
            for bit in (0,1):
                if p3[a+bit]>p2[j+1]:nd[a+bit]+=n
        d=nd
    forward_total=sum(d.values())
    # Independent backward continuation DP from depth 100.
    d={a:1 for a in range(101)}
    for j in range(99,40,-1):
        d={a:sum(d.get(a+b,0) for b in (0,1) if p3[a+b]>p2[j+1]) for a in range(j+1)}
    backward_total=sum(SIX[a-26]*d[a] for a in range(26,38))
    assert forward_total==backward_total==12083228764224801145504
    print('PASS independent forward/backward exact projector:',forward_total,'/ 2^100')
    for a in range(26,31):print('projector',a,SIX[a-26],d[a],SIX[a-26]*d[a])
