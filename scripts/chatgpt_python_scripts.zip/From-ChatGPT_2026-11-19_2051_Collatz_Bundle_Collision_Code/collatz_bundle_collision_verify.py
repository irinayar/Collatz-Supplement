from fractions import Fraction

def T(n):
    return n//2 if n%2==0 else (3*n+1)//2

def run(N=60000, depth=9):
    image=set(range(1,N+1))
    for j in range(depth):
        collisions=sum(1 for y in (x//2 for x in image if x%2==0) if y%3==2 and (2*y-1)//3 in image)
        nxt={T(x) for x in image}
        assert len(image)-len(nxt)==collisions
        M=N//(2**j)
        assert all(x in image for x in range(1,M+1))
        guaranteed=sum(1 for y in range(2,M//2+1,3))
        assert collisions>=guaranteed
        print(f'k={j+1}: image={len(image)}, collision={collisions}, guaranteed={guaranteed}, next={len(nxt)}')
        image=nxt

if __name__=='__main__':
    run()
