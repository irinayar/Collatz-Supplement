from functools import lru_cache
from itertools import combinations

def v3(n):
 a=0
 while n%3==0:
  n//=3;a+=1
 return a
@lru_cache(None)
def R(x,k):
 a=v3(x+1)
 if k==0:return a
 return max(l+R(2*(2**l*((x+1)//3**l)-1),k-1) for l in range(a+1))
@lru_cache(None)
def H(x,k,r):
 if r<0:return None
 a=v3(x+1)
 if k==0:return 2**r*((x+1)//3**r)-1 if r<=a else None
 values=(H(2*(2**l*((x+1)//3**l)-1),k-1,r-l) for l in range(min(a,r)+1))
 return min((z for z in values if z is not None),default=None)

def brute(x,k,r):
 vals=[];n=k+r
 for odds in combinations(range(n),r):
  V=sum(2**p*3**(r-1-h) for h,p in enumerate(odds))
  z=2**n*x-V
  if z>0 and z%3**r==0:
   m=z//3**r;y=m
   for i in range(n):
    assert y%2==(i in odds)
    y=(3*y+1)//2 if y%2 else y//2
   assert y==x
   vals.append(m)
 return min(vals,default=None)

checks=0; brute_checks=0
for u in range(2,3001,3):
 x=3*u-1; A=6*u-2;B=4*u-2
 assert R(B,5)==0
 assert H(A,5,1)==128*u-48
 assert H(B,5,0)==128*u-64
 assert H(A,5,2)==(256*u-104)//3 and (256*u-104)%3==0
 assert H(x,6,0)==192*u-64
 assert H(x,6,1)==128*u-64
 assert H(x,6,2)==(256*u-104)//3
 top=R(x,6)
 values=[H(x,6,r) for r in range(top+1)]
 assert all(v is not None and v>0 for v in values)
 assert all(values[r]>values[r+1] for r in range(top))
 checks+=top+7
 if u<=29:
  for r in range(min(top+2,5)):
   assert brute(x,6,r)==H(x,6,r)
   brute_checks+=1
print({'u_tested':1000,'recurrence_and_inequality_checks':checks,'independent_word_cells':brute_checks,'failures':0})
