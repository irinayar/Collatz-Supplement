from functools import lru_cache
from collections import Counter
@lru_cache(None)
def H(k,x,r):
    if r<0:return None
    if k==0:
        n=x+1
        for _ in range(r):
            if n%3:return None
            n=2*(n//3)
        return n-1
    n=x+1; ell=0; best=None
    while ell<=r:
        v=H(k-1,2*(n-1),r-ell)
        if v is not None and (best is None or v<best):best=v
        if n%3:break
        n=2*(n//3);ell+=1
    return best

def trajectory(m,steps):
    w='';v=m
    for _ in range(steps):
        w+=str(v%2)
        v=(3*v+1)//2 if v%2 else v//2
    return w,v

def v3(n):
    a=0
    while n%3==0:
        n//=3;a+=1
    return a

checks=Counter(); overlaps=Counter(); failures=[]
for q in range(1,1501):
    if q%3==0:continue
    for s in range(2,17):
        short=H(4,18*q-2,s)
        middle=H(4,12*q-2,s-1)
        long=H(4,8*q-2,s-2)
        if short is None:continue
        checks['short_feasible']+=1
        if middle is not None:
            overlaps['middle']+=1
            if not middle<short:failures.append(('middle',q,s,short,middle))
        if long is not None:
            overlaps['long']+=1
            if not long<short:failures.append(('long',q,s,short,long))
        if s>=5 and (middle is not None or long is not None):
            failures.append(('late_overlap',q,s,short,middle,long))
        if s in (2,3,4):
            target={2:128*q-24,3:4*(64*q-7)//3-8,4:8*(64*q-7)//9-6}[s]
            if middle!=target:failures.append(('middle_formula',q,s,middle,target))
            word,endpoint=trajectory(target,s+3)
            if endpoint!=12*q-2 or word.count('1')!=s-1 or word.count('0')!=4:
                failures.append(('replay',q,s,word,endpoint))
            checks['middle_constructed']+=1
        if s>=5 and v3(64*q-7)<3:failures.append(('short_valuation',q,s))
        if s>=5 and H(4,12*q-2,4) is not None:failures.append(('middle_max',q,s))
print('checks',dict(checks),'overlaps',dict(overlaps),'failures',len(failures))
if failures:print(failures[:10]);raise SystemExit(1)
print('q=25 example',[(s,H(4,18*25-2,s),H(4,12*25-2,s-1),H(4,8*25-2,s-2)) for s in range(2,7)])
