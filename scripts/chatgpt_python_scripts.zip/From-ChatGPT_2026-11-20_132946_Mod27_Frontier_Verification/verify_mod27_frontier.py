from functools import lru_cache
N=4064460795
states=[(92,75,1496632903889236,69),(92,74,997755269259490,68),(92,71,2660680718025304,67),(89,62,50454389911619506,61),(87,60,830524936813144,54),(84,55,8858932659283264,50),(84,54,5905955106188842,49),(82,51,5249737872152980,45),(82,50,3499825248101986,44),(82,47,9332867328271960,43)]
@lru_cache(None)
def table(t,h):
    cells={(0,0):(0,0)}
    for j in range(t):
        nxt={}
        for (b,r),(lo,hi) in cells.items():
            for nb,vl,vh in ((b,lo,hi),(b+1,3*lo+(1<<j),3*hi+(1<<j))):
                q=3**min(h,nb)
                nr=vl%q
                key=(nb,nr)
                if key in nxt:
                    oldlo,oldhi=nxt[key]
                    nxt[key]=(min(oldlo,vl),max(oldhi,vh))
                else: nxt[key]=(vl,vh)
        cells=nxt
    return cells

def test(t,z,b,h):
    B=(1<<t)*z; Q=3**b
    v=table(t,h).get((b,B%(3**min(h,b))))
    if v is None: return 'empty residue'
    lo,hi=v
    L=max(lo,B-Q*(N-1)); U=min(hi,B-Q)
    if L>U:return 'empty real interval'
    first=L+((B-L)%Q)
    if first>U:return 'empty integer lattice'
    return 'unresolved'
if __name__=='__main__':
    for root,t,z,b in states:
        print(root,t,b,test(t,z,b,3),test(t,z,b,4))
