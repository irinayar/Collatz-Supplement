from functools import lru_cache

def T(n): return (3*n+1)//2 if n%2 else n//2
@lru_cache(None)
def H(k,x,r):
    if k==0:
        a=0; y=x+1
        while y%3==0: a+=1;y//=3
        return (2**r*(x+1)//3**r-1) if r<=a else None
    a=0;y=x+1
    while y%3==0:a+=1;y//=3
    vals=[]
    for ell in range(min(a,r)+1):
        y=2*(2**ell*((x+1)//3**ell)-1)
        z=H(k-1,y,r-ell)
        if z is not None:vals.append(z)
    return min(vals) if vals else None

checked=0
for x in range(1,251):
 for k in range(0,9):
  for r in range(0,20):
   m=H(k,x,r)
   if m is not None and m%3==2:
    p=(2*m-1)//3
    assert p>0 and p<m and T(p)==m
    assert H(k,x,r+1) is not None and H(k,x,r+1)<=p
    checked+=1
assert H(20,2,21)==1 and H(20,2,22)==251
print('verified eligible cells:',checked)
print('k20 counterexample:',H(20,2,21),H(20,2,22))
