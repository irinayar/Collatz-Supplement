from fractions import Fraction
from collections import defaultdict
import json

def word_data(q,L):
 a=0; U=0; r=0; prefixes=[]
 for j in range(L):
  b=(q>>j)&1
  val=(3**r*a+U)//(2**j)
  eps=(b-val)&1
  a+=eps*(2**j)
  U=3**b*U+b*2**j
  r+=b
  prefixes.append((j+1,r,U))
 n0=a if a>0 else 2**L
 bounds=[Uj//(2**j-3**rj) for j,rj,Uj in prefixes if 2**j>3**rj]
 B=min(bounds) if bounds else None
 H=(2*U)//3**r
 bad=n0<=H
 survives=B is None or n0<=B
 # first descent at step L+1 iff survives and next T(n0)<n0
 return {'q':q,'L':L,'bits':''.join(str((q>>j)&1) for j in range(L)),'n0':n0,'r':r,'U':U,'H':H,'B':B,'bad':bad,'survives':survives}
counts=[]; examples=[]
for L in range(1,15):
 rows=[word_data(q,L) for q in range(1<<L)]
 bs=[v for v in rows if v['bad'] and v['survives']]
 counts.append({'L':L,'words':len(rows),'bad':sum(v['bad'] for v in rows),'bad_survivors':len(bs),'bad_survivors_n_gt_1':sum(v['n0']>1 for v in bs)})
 if L<=7: examples.extend(bs[:5])
print(json.dumps(counts,indent=2));print('EXAMPLES',json.dumps(examples[:18],indent=2))

# Independent forward replay of the criterion for every word up to length 10.
def T(n): return (3*n+1)//2 if n%2 else n//2
checked=0
for L in range(1,11):
 for q in range(1<<L):
  d=word_data(q,L)
  for t in range(4):
   n=d['n0']+(1<<L)*t
   x=n; bits=[]; survive=True
   for j in range(L):
    bits.append(x&1)
    x=T(x)
    survive &= x>=n
   assert sum(b<<j for j,b in enumerate(bits))==q
   G_bad=(2*d['U']>=3**d['r']*n)
   assert G_bad == (n<=d['H'])
   assert survive == (d['B'] is None or n<=d['B'])
   checked+=1
print('Independent forward replays:',checked,'passed')
