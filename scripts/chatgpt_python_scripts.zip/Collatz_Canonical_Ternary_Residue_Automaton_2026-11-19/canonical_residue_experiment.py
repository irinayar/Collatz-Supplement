#!/usr/bin/env python3
"""Exact exhaustive ternary canonical-residue / binary-cylinder experiment."""
import json, math, argparse
from collections import defaultdict

def run(maxdepth=16, threshold_start=8, N=100000):
    # (word integer, A, U, binary residue, current parity word text, all-guard-survived)
    nodes=[(0,0,0,0,'',True)]
    rows=[]; samples=[]
    for j in range(1,maxdepth+1):
        new=[]; counts=defaultdict(int)
        for _,a,u,r,w,alive in nodes:
            # Extend an actual parity cylinder: next bit of n is selected by congruence
            # 3^a n+U mod 2^(j) must have prescribed parity at step j-1.
            mod=1<<j
            for bit in (0,1):
                aa=a+bit
                uu=3*u+(1<<(j-1)) if bit else u
                rr=(-uu*pow(3**aa,-1,mod))%mod
                # Only one lift of previous r is valid per bit
                assert rr%(mod//2)==r
                ww=w+str(bit)
                ternmod=3**aa
                R=(uu*pow(1<<j,-1,ternmod))%ternmod if aa else 0
                low=(R<=j*j)
                live=alive and (j<threshold_start or low)
                nmin=rr if rr else mod
                end=(3**aa*nmin+uu)//mod
                assert (3**aa*nmin+uu)%mod==0
                assert end%ternmod==R
                counts['total']+=1
                counts['R_small']+=low
                counts['R_small_and_alive']+=live
                counts['nmin_le_N']+=(nmin<=N)
                counts['nmin_le_N_endpoint_small']+=(nmin<=N and end<=j*j)
                counts['R_small_but_no_small_endpoint']+=(low and end>j*j)
                if j==maxdepth and low and end>j*j and len(samples)<6:
                    samples.append(dict(word=ww, R=R, nmin=nmin, endpoint=end, threshold=j*j))
                new.append((0,aa,uu,rr,ww,live))
        nodes=new
        rows.append(dict(j=j,**counts))
        print(j,dict(counts),flush=True)
    return dict(maxdepth=maxdepth,threshold_start=threshold_start,N=N,rows=rows,samples=samples)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--depth',type=int,default=16);ap.add_argument('--start',type=int,default=8);ap.add_argument('--N',type=int,default=100000);args=ap.parse_args()
    data=run(args.depth,args.start,args.N)
    with open('/mnt/data/Collatz_Canonical_Residue_Experiment_Results_2026-11-19.json','w') as f:json.dump(data,f,indent=2)
