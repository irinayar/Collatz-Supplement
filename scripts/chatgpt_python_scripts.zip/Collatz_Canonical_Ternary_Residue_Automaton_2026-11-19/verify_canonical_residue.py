#!/usr/bin/env python3
"""Independent direct-iteration oracle for the canonical residue experiment."""
import json

def T(x): return (3*x+1)//2 if x&1 else x//2

def verify(maxdepth=12):
    count=0
    for j in range(1,maxdepth+1):
        for n in range(1,(1<<j)+1):
            x=n; bits=[];a=0;u=0
            for i in range(j):
                b=x&1;bits.append(b)
                if b:u=3*u+(1<<i);a+=1
                x=T(x)
            q=3**a
            R=(u*pow(1<<j,-1,q))%q if a else 0
            assert x==R if a else x==1
            assert x==((q*n+u)>>j)
            # Reconstruct least starting value of this same parity word from scratch
            r=(-u*pow(q,-1,1<<j))%(1<<j)
            assert n==(r or 1<<j)
            count+=1
    return count

if __name__=='__main__':
    print('Independent exhaustive direct checks:',verify())
