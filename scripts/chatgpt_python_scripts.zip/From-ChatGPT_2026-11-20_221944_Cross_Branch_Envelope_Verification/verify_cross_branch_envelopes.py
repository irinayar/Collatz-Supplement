from fractions import Fraction

def low(a,b,z):
    return Fraction(2**(a+b)*z-2**a*(3**b-2**b),3**b)
def up(a,b,z):
    return Fraction(2**(a+b)*z-(3**b-2**b),3**b)
checks=0
min_ab=None;min_ba=None
for k in range(2,31):
 for r in range(1,7):
  for x in range(5,1001,3):
   y=(2*x-1)//3
   ab=low(k,r-1,y)-up(k-2,r+1,4*x)
   ba=low(k-2,r,4*x)-up(k,r,y)
   assert ab==Fraction(2**k*(2**r*(x+3)-3**(r+1)),3**(r+1))+1-Fraction(2**(r+1),3**(r+1))
   assert ba==Fraction(2**k*(2**r*(4*x+7)-3**(r+1)),4*3**(r+1))+1-Fraction(2**r,3**r)
   if r<=2: assert ab>0
   if r<=5: assert ba>0
   if r<=2: min_ab=min(min_ab,ab) if min_ab is not None else ab
   if r<=5: min_ba=min(min_ba,ba) if min_ba is not None else ba
   checks+=1
print('checks',checks,'min AB for r<=2',min_ab,'min BA for r<=5',min_ba)
