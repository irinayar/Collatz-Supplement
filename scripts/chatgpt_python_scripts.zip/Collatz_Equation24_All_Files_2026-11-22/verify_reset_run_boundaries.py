#!/usr/bin/env python3
"""Exact chronological reset-run and shell-incidence controls.

Reads the compact saved first-hit words, independently replays all transitions,
then verifies the two-slot run lemma and boundary incidence inequalities on
actual least-source profiles.  No producer verifier is imported.
The all-depth theorem is algebraic; this finite replay does not prove the
remaining middle-of-word incidence bound.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from functools import lru_cache
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: this exact verifier uses assertions.")


HERE = Path(__file__).resolve().parent
DEFAULT_SEEDS = HERE.parent / "all_depth_work" / "incoming_inverse_saved_first_hits.json"
SCALE = 1 << 80


def odd_step(x: int) -> tuple[int, int]:
    v = 3 * x + 1
    e = (v & -v).bit_length() - 1
    return v >> e, e


@lru_cache(None)
def is_slow(x: int) -> bool:
    v = x
    for _ in range((x - 1).bit_length()):
        v = (3 * v + 1) // 2 if v & 1 else v // 2
        if 2 * v < x:
            return False
    return True


def selected_positions(path: list[int]) -> set[int]:
    result = set()
    at = 0
    while at < len(path) - 1:
        start = path[at]
        if is_slow(start):
            result.add(at)
            at += 1
        else:
            at += 1
            while at < len(path) - 1 and 2 * path[at] >= start:
                at += 1
    return result


def directed_dyadic_record(value: Q) -> dict:
    lo = value.numerator * SCALE // value.denominator
    hi = -(-value.numerator * SCALE // value.denominator)
    assert Q(lo, SCALE) <= value <= Q(hi, SCALE)
    return {"lower_units": str(lo), "upper_units": str(hi), "denominator": str(SCALE)}


def replay(n: int, source: int, word: tuple[int, ...]) -> dict:
    H = (4 * n - 2) // 3
    assert source & 1 and n <= source <= H
    path = [source]
    E = B = 0
    for e in word:
        after, actual_e = odd_step(path[-1])
        assert actual_e == e
        B = 3 * B + (1 << E)
        E += e
        path.append(after)
    assert path[-1] <= H
    assert all(x > H for x in path[1:-1])
    assert len(path[:-1]) == len(set(path[:-1]))
    assert (1 << E) * path[-1] == 3 ** len(word) * source + B
    return {"n": n, "H": H, "source": source, "word": word, "path": path,
            "E": E, "B": B, "g": len(word), "k": sum(e >= 2 for e in word)}


def check_runs(record: dict) -> tuple[list[dict], int, dict | None]:
    path, word = record["path"], record["word"]
    k = record["k"]
    assert word[-1] >= 2
    starts = [0] + [i + 1 for i, e in enumerate(word[:-1]) if e >= 2]
    ends = [i for i, e in enumerate(word) if e >= 2]
    assert len(starts) == len(ends) == k
    rows = []
    checked = 0
    two_slot_witness = None
    for run_no, (start, end) in enumerate(zip(starts, ends)):
        assert start <= end and all(e == 1 for e in word[start:end])
        assert word[end] >= 2
        z, w = path[start], path[end + 1]
        s, e = end - start + 1, word[end]
        assert (z + 1) % (1 << s) == 0 and (z + 1) % (1 << (s + 1)) != 0
        assert (1 << (s - 1 + e)) * w == 3**s * z + 3**s - 2**s
        correction = Q(1)
        for at in range(start, end + 1):
            correction *= 1 + Q(1, 3 * path[at])
        assert correction == 1 + Q(3**s - 2**s, 3**s * z)

        shell_positions = defaultdict(list)
        for at in range(start, end + 1):
            shell_positions[path[at].bit_length() - 1].append(at)
            rows.append({"g": at, "y": path[at], "before": run_no,
                         "after": k - run_no, "shell": path[at].bit_length() - 1})
        for shell, positions in shell_positions.items():
            assert len(positions) <= 2
            checked += 1
            if len(positions) == 2 and two_slot_witness is None:
                two_slot_witness = {"threshold": record["n"], "source": record["source"],
                                    "run_number_from_zero": run_no, "shell": shell,
                                    "inputs": [path[i] for i in positions]}
    assert len(rows) == len(word)
    for row in rows:
        assert row["before"] == sum(e >= 2 for e in word[:row["g"]])
        assert row["after"] == sum(e >= 2 for e in word[row["g"]:]) >= 1
    return rows, checked, two_slot_witness


def shell_controls(profiles: list[dict], cutoff_name: str, cutoff) -> dict:
    P = len(profiles)
    all_shells = defaultdict(list)
    selected_shells = defaultdict(list)
    max_cutoff = {}
    strict_extension = None
    for record in profiles:
        rows = record["rows"]
        selected = record["selected"]
        for row in rows:
            if row["y"] <= record["H"]:
                continue
            ell = row["shell"]
            K = cutoff(row["y"])
            assert K >= 0
            max_cutoff[ell] = max(max_cutoff.get(ell, 0), K)
            in_prefix = row["before"] <= K
            in_suffix = row["after"] <= K
            if in_prefix or in_suffix:
                all_shells[ell].append(row)
                if row["g"] in selected:
                    selected_shells[ell].append(row)
                    if strict_extension is None and row["g"] > K and record["g"] - row["g"] > K:
                        strict_extension = {"threshold": record["n"], "source": record["source"],
                                            "anchor": row["y"], "incoming_odd_depth": row["g"],
                                            "remaining_odd_depth": record["g"] - row["g"],
                                            "earlier_resets": row["before"], "remaining_resets": row["after"],
                                            "cutoff": K}

    rows_out = []
    for ell in sorted(max_cutoff):
        Y, K = 1 << ell, max_cutoff[ell]
        count_bound = 2 * sum(min(record["k"], 2 * K + 1) for record in profiles)
        uniform_count_bound = 2 * P * (2 * K + 1)
        assert count_bound <= uniform_count_bound
        all_rows, chosen = all_shells[ell], selected_shells[ell]
        assert len(chosen) <= len(all_rows) <= count_bound
        prefix_count = sum(row["before"] <= cutoff(row["y"]) for row in all_rows)
        suffix_count = sum(row["after"] <= cutoff(row["y"]) for row in all_rows)
        assert prefix_count <= 2 * sum(min(record["k"], K + 1) for record in profiles)
        assert suffix_count <= 2 * sum(min(record["k"], K) for record in profiles)
        shell_weight_cap = Q(2 * ell + 9, 3 * Y)
        # W(y) is bounded above by (2 ell+9)/(3y) on this shell.
        weight = sum((Q(2 * ell + 9, 3 * row["y"]) for row in chosen), Q(0))
        bound = count_bound * shell_weight_cap
        assert weight <= bound
        rows_out.append({"shell": ell, "max_cutoff": K, "all_boundary_incidences": len(all_rows),
                         "selected_boundary_incidences": len(chosen), "prefix_incidences": prefix_count,
                         "suffix_incidences": suffix_count, "count_bound": count_bound,
                         "uniform_profile_count_bound": uniform_count_bound,
                         "exact_rational_weight_majorant_interval": directed_dyadic_record(weight),
                         "exact_rational_shell_bound": str(bound)})
    return {"cutoff": cutoff_name, "profiles": P, "shells": rows_out,
            "strict_extension_of_odd_depth_boundary": strict_extension}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=Path, default=DEFAULT_SEEDS)
    parser.add_argument("--output", type=Path, default=HERE / "reset_run_boundary_certificate.json")
    args = parser.parse_args()
    raw = args.seeds.read_bytes()
    data = json.loads(raw)
    least = {}
    run_shell_checks = 0
    run_checks = 0
    witness = None
    genuine_candidates = 0
    for n, source, exponents in data["records"]:
        record = replay(n, source, tuple(exponents))
        if record["path"][-1] < n:
            continue
        genuine_candidates += 1
        assert record["word"][0] == 1 and source % 4 == 3
        rows, number, candidate_witness = check_runs(record)
        run_shell_checks += number
        run_checks += record["k"]
        if witness is None and candidate_witness is not None:
            witness = candidate_witness
        record["rows"] = rows
        key = (n, record["word"])
        if key not in least or source < least[key]["source"]:
            least[key] = record

    by_threshold = defaultdict(list)
    for record in least.values():
        record["selected"] = selected_positions(record["path"])
        by_threshold[record["n"]].append(record)

    controls = []
    summaries = []
    for n in data["thresholds"]:
        profiles = by_threshold[n]
        positive = sum(record["B"] + 5 * ((1 << record["E"]) - 3**record["g"]) > 0 for record in profiles)
        summaries.append({"threshold": n, "all_sign_least_source_profiles": len(profiles),
                          "positive_least_source_profiles": positive,
                          "reset_runs": sum(record["k"] for record in profiles)})
        for K in (0, 1, 2, 4, 8, 16):
            result = shell_controls(profiles, f"constant_{K}", lambda _y, K=K: K)
            result["threshold"] = n
            controls.append(result)
        result = shell_controls(profiles, "varying_y_mod_7", lambda y: y % 7)
        result["threshold"] = n
        controls.append(result)

    result = {
        "scope": "Exact chronological and weighted finite controls for the proved reset-run boundary theorem; no unrestricted middle-incidence estimate is inferred.",
        "seed_sha256": hashlib.sha256(raw).hexdigest(),
        "candidate_words_replayed": len(data["records"]),
        "genuine_candidate_words": genuine_candidates,
        "maximal_reset_runs_checked_before_least_source_filter": run_checks,
        "run_shell_cells_checked_before_least_source_filter": run_shell_checks,
        "two_slot_witness": witness,
        "threshold_summaries": summaries,
        "boundary_controls": controls,
        "checks_passed": True,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(data['records'])} candidate words replayed; {run_checks} actual reset runs and {run_shell_checks} run/shell cells checked.")
    print(f"PASS: {len(controls)} boundary cases, including K=0 and varying height-dependent budgets, with exact rational weight controls.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
