#!/usr/bin/env python3
"""Exact, focused controls for K153--K155 and the six incoming notes.

Uses five named saved merge groups (fourteen paths), not a trajectory census.
No canonical dynamic program or unavailable external script is rerun.
Python 3.10+, standard library, assertions required.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
import hashlib
import json
import sys
from pathlib import Path


HERE=Path(__file__).resolve().parent
A=Q(47,32)
ALPHA=Q(20,21)
FULL_CHARGE_CAP=Q(117,250)


def ceilq(x):return -((-x.numerator)//x.denominator)
def floorq(x):return x.numerator//x.denominator
def phi(x):return Q(x+5,x)


def replay(u,word):
    path=[u]
    E=0
    q=Q(0)
    for g,e in enumerate(word):
        x=path[-1]
        z=3*x+1
        actual=(z&-z).bit_length()-1
        assert actual==e
        q+=Q(1 << E,3**(g+1))
        E+=e
        path.append(z >> e)
    G=Q((1 << E)*path[-1],3**len(word)*u)
    assert G==1+q/u
    rho=G*phi(path[-1])/phi(u)
    assert rho==Q((1 << E)*(path[-1]+5),3**len(word)*(u+5))
    return path,E,G,rho,q


def slow(y):
    x=y
    for _ in range((y-1).bit_length()):
        x=(3*x+1)//2 if x&1 else x//2
        if 2*x<y:return False
    return True


def selected_slow(path):
    out=[]
    i=0
    while i<len(path)-1:
        x=path[i]
        if slow(x):
            out.append(x)
            i+=1
        else:
            i+=1
            while i<len(path)-1 and 2*path[i]>=x:i+=1
    return out


def q_interval(g):
    assert g>=1
    if g==1:return Q(1,3),Q(1,3)
    return 1-Q(2,3)**g,Q(5,9)+(g-2)*A/3


def phase_cap(g):
    lo,hi=q_interval(g)
    return 1+floorq((hi-lo)/4)


def phase_slots(n,y,g):
    H=(4*n-2)//3
    assert H*A<2*n
    p3=3**g
    e=g
    while (1 << e)*y<p3*n:e+=1
    if (1 << e)*y*A.denominator>=p3*H*A.numerator:
        return None,[]
    assert (1 << (e+1))*y*A.denominator>=p3*H*A.numerator
    lam=Q((1 << e)*y,p3)
    lo,hi=q_interval(g)
    lower=max(n,ceilq(lam-hi))
    upper=min(H,floorq(lam-lo))
    first=lower+(3-lower)%4
    slots=list(range(first,upper+1,4)) if first<=upper else []
    assert len(slots)<=phase_cap(g)
    return e,slots


def depth_cap(n,g):
    return min(A,Q(3*n,3*n-g)) if g<3*n else A


def envelope(n,rho_suffix,y):
    H=(4*n-2)//3
    v=rho_suffix*phi(y)/phi(H)
    C=min(FULL_CHARGE_CAP,max(Q(0),v*A-1))
    def c(g):return max(Q(0),min(C,v*depth_cap(n,g)-1))
    return v,C,c


def integrated_bound(C,c,K,D=0):
    assert 0<=D<K
    bound=c(D+1)*ALPHA**D
    for j in range(D+1,K):
        assert c(j+1)>=c(j)
        bound+=(c(j+1)-c(j))*ALPHA**j
    assert C>=c(K)
    bound+=(C-c(K))*ALPHA**K
    return bound


def analyze_group(n,y,sources,require_genuine=True):
    H=(4*n-2)//3
    rows=[]
    suffix_word=None
    for source in sources:
        u=source['u'];word=tuple(source['word'])
        path,E,G,rho,qfull=replay(u,word)
        genuine=(n<=u<=H and n<=path[-1]<=H and all(x>H for x in path[1:-1]))
        if not genuine:
            if require_genuine:raise AssertionError('Saved group is not a genuine first return.')
            return {'valid':False,'reason':'The lifted fixed words fail a source, arrival, or first-return height condition.'}
        assert word[0]==1 and u%4==3
        assert len(set(path[:-1]))==len(word)
        assert y in path[1:-1]
        g=path.index(y)
        prefix=word[:g]
        _,Ein,Gin,rhoin,qin=replay(u,prefix)
        if suffix_word is None:suffix_word=word[g:]
        else:assert suffix_word==word[g:]
        assert G<A and Gin<A
        assert rho<1+FULL_CHARGE_CAP
        qlo,qhi=q_interval(g)
        assert qlo<=qin<=qhi
        Eslot,slots=phase_slots(n,y,g)
        assert Eslot==Ein and u in slots
        threshold=Q(5*(y-u),y+5)
        assert (rhoin<1)==(qin<threshold)
        assert rhoin==Q((u+qin)*(y+5),y*(u+5))
        weight=Q(3**g,1 << (Ein+g))
        assert weight==Q(y,1 << g)/u/Gin
        assert weight*rhoin==Q(y+5,(1 << g)*(u+5))
        rows.append({'u':u,'g':g,'E':Ein,'weight':weight,'charge':max(Q(0),rho-1),
                     'prefix_charge':rhoin-1,'Q':qin,'threshold':threshold,
                     'G_full':G,'rho_full':rho,'Q_full':qfull,'word':word,'path':path})
    _,_,Gs,rhos,_=replay(y,suffix_word)
    v,C,c=envelope(n,rhos,y)
    for row in rows:
        assert row['charge']<=c(row['g'])
    maximum_depth=max(row['g'] for row in rows)
    for D in range(maximum_depth+2):
        mass=sum((row['weight'] for row in rows if row['g']>D),Q(0))
        assert mass<=ALPHA**D
        charge=sum((row['weight']*row['charge'] for row in rows if row['g']>D),Q(0))
        assert charge<=C*ALPHA**D
    weighted=sum((row['weight']*row['charge'] for row in rows),Q(0))
    integrated=[]
    for K in (1,6,11,32,128):
        bound=integrated_bound(C,c,K)
        assert weighted<=bound<=C
        for D in range(min(K,maximum_depth+2)):
            tail=sum((row['weight']*row['charge'] for row in rows if row['g']>D),Q(0))
            assert tail<=integrated_bound(C,c,K,D)
        integrated.append({'K':K,'exact_bound':str(bound),'display_only':float(bound)})
    shallow=[]
    for D in (6,11,16,32,64):
        exact_bound=sum((len(phase_slots(n,y,g)[1])*c(g) for g in range(1,D+1)),Q(0))
        actual=sum((r['charge'] for r in rows if r['g']<=D),Q(0))
        assert actual<=exact_bound
        delta=max(Q(0),v-1)
        loose=(delta*(D+Q(47*D*(D+1),768))+
               v/Q(3*n-D)*(Q(D*(D+1),2)+Q(47*D*(D+1)*(2*D+1),2304)))
        assert D<3*n and exact_bound<=loose
        shallow.append({'D':D,'actual_saved_charge':str(actual),'exact_slot_upper':str(exact_bound),
                        'loose_upper':str(loose),'display_slot_upper':float(exact_bound)})
    return {'valid':True,'n':n,'H':H,'y':y,'suffix_word':suffix_word,
            'rho_suffix':str(rhos),'C':str(C),'weighted_saved_charge':str(weighted),
            'unweighted_saved_charge':str(sum((r['charge'] for r in rows),Q(0))),
            'paths':[{'u':r['u'],'g':r['g'],'E':r['E'],'weight':str(r['weight']),
                      'full_charge':str(r['charge']),'prefix_signed_charge':str(r['prefix_charge']),
                      'Q':str(r['Q']),'sign_threshold':str(r['threshold'])} for r in rows],
            'integrated_checks':integrated,'shallow_checks':shallow}


def elementary_controls():
    for m in range(2,31):
        x=(1 << m)-1
        for j in range(m+1):
            assert x==3**j*(1 << (m-j))-1
            if j<m:x=(3*x+1)//2
    assert 3**5<2**8<Q(13,4)**5
    assert Q(13,4)**5==Q(371293,1024)
    assert Q(3*5+1,5)>Q(13,8)
    plain=[]
    for source,target in ((27,96),(871,57),(115783,68)):
        path=[source]
        while path[-1]>=source:
            assert len(path)<10000
            x=path[-1]
            path.append(3*x+1 if x&1 else x//2)
        assert len(path)-1==target
        trace=path[:-1]  # Inputs before the first below-source output.
        longest_even=max((next((j for j in range(len(trace)-i) if trace[i+j]&1),len(trace)-i)
                          for i in range(len(trace)) if not trace[i]&1),default=0)
        longest_pairs=0
        for i in range(len(trace)):
            k=0
            while i+2*k+1<len(trace) and trace[i+2*k]&1 and not trace[i+2*k+1]&1:k+=1
            longest_pairs=max(longest_pairs,k)
        plain.append({'source':source,'first_strict_descent_plain_steps':target,
                      'maximum_consecutive_even_states':longest_even,
                      'maximum_consecutive_odd_even_pairs':longest_pairs,
                      'run_count_scope':'Charged inputs only; final below-source output excluded.'})
    assert plain[-1]['maximum_consecutive_even_states']==3
    assert plain[-1]['maximum_consecutive_odd_even_pairs']==3
    caps=[]
    accumulated=Q(0)
    for g in range(1,257):
        m=phase_cap(g)
        assert m<=1+A*g/12
        if g<=11:assert m==1
        if g==12:assert m==2
        accumulated+=1+A*g/12
        assert accumulated==g+Q(47*g*(g+1),768)
        if g<=16:caps.append({'g':g,'phase_cap':m})
    critical_A=Q(40,27)-Q(2,3)**11/3
    assert A<critical_A<Q(3,2)
    return {'all_odd_prefix_m_range':[2,30],'cycle_compatibility':[5,8],
            'exact_13_over_4_power5':str(Q(13,4)**5),'plain_controls':plain,
            'phase_caps':caps,'phase_algebra_checked_through':256,
            'g11_uniqueness_sufficient_A_strict_upper':str(critical_A),
            'slack_above_47_over_32':str(critical_A-A)}


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O or -OO.')
    # K=128 high-lift rational envelopes have several thousand decimal digits.
    # Keep an explicit bounded serialization cap; no unbounded search is used.
    if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(20000)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seeds',type=Path,default=HERE/'incoming_six_note_seed_groups.json')
    parser.add_argument('--output',type=Path,default=HERE/'incoming_six_notes_certificate.json')
    args=parser.parse_args()
    raw=args.seeds.read_bytes()
    seeds=json.loads(raw)
    groups=[];lifts=[]
    for group in seeds['groups']:
        result=analyze_group(group['n'],group['y'],group['sources'])
        groups.append(result)
        R=max(len(source['word']) for source in group['sources'])
        t=1 << 80
        lifted_n=group['n']+3**R*t
        suffix=result['suffix_word']
        lifted_y=group['y']+(1 << sum(suffix))*3**(R-len(suffix))*t
        sources=[{'u':source['u']+(1 << sum(source['word']))*3**(R-len(source['word']))*t,
                  'word':source['word']} for source in group['sources']]
        assert lifted_n>1 << 71
        lifted=analyze_group(lifted_n,lifted_y,sources,require_genuine=False)
        lifts.append({'seed_n':group['n'],'seed_y':group['y'],**lifted})
    group55=seeds['groups'][0]
    words={r['u']:r['word'] for r in group55['sources']}
    path63,_,_,_,_=replay(63,words[63])
    assert 91 in selected_slow(path63) and 137 in selected_slow(path63)
    _,_,_,_,q6=replay(63,words[63][:6])
    _,_,_,_,q7=replay(63,words[63][:7])
    assert q6==Q(665,729) and q7==Q(2507,2187)
    margin6=Q(35,24)-q6
    margin7=Q(185,71)-q7
    assert q7>q6 and margin7>margin6
    _,_,_,_,q71_4=replay(71,words[71][:4])
    _,_,_,_,q63_5=replay(63,words[63][:5])
    assert q71_4==Q(73,81)>q63_5==Q(211,243)
    # Claude's ten-prefix sign observation concerns the first four groups.
    negative=sum(Q(p['prefix_signed_charge'])<0 for g in groups[:4] for p in g['paths'])
    assert negative==9
    result={'status':'PASS','seed_sha256':hashlib.sha256(raw).hexdigest(),
            'saved_groups':groups,'lift_controls':lifts,'elementary_controls':elementary_controls(),
            'prefix_sign_counts':{'scope':'The first four groups, exactly the ten prefixes in Claude091500.',
                                  'negative':negative,'positive':10-negative},
            'Q_scope_counterexamples':{
                'same_path_increasing_margin':{'source':63,'depth6_Q':str(q6),'depth7_Q':str(q7),
                                              'depth6_margin':str(margin6),'depth7_margin':str(margin7),
                                              'anchors':[91,137],'both_selected_slow':True},
                'cross_path_reversal':{'source71_depth4_Q':str(q71_4),'source63_depth5_Q':str(q63_5)}},
            'limitations':['No complete canonical DP rerun.',
                           'No unavailable external scripts rerun; five named groups only.',
                           'High-lift checks do not assert least-source or greedy-selected status.',
                           'Third-party PDF wording and bibliography require independent source review.',
                           'No central deep-incidence estimate inferred from these finite controls.']}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','saved_groups':len(groups),'saved_paths':sum(len(g['paths']) for g in groups),
                      'valid_high_lifts':sum(v['valid'] for v in lifts),
                      'invalid_high_lifts':sum(not v['valid'] for v in lifts),
                      'negative_prefixes':negative,'output':str(args.output)},indent=2))


if __name__=='__main__':main()
