#!/usr/bin/env python3
"""Exact checks for chronological phase windows on saved real return paths.

The all-profile asymptotic theorem is proved in the companion note using the
imported profile and slow-state counts.  These finite checks validate the new
phase identities and per-profile shell inequalities; they do not establish an
unrestricted Collatz bound or certify the slow predicate at these inputs.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction as Q
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact certificate checks use assertions.")


def odd_step(x: int) -> tuple[int, int]:
    value = 3 * x + 1
    exponent = (value & -value).bit_length() - 1
    return value >> exponent, exponent


def first_return(n: int, source: int) -> tuple[list[int], list[int]]:
    H = (4 * n - 2) // 3
    assert n <= source <= H and source % 2
    states = [source]
    exponents = []
    while True:
        assert len(states) < 10000  # Guard for these fixed saved regressions.
        v, e = odd_step(states[-1])
        exponents.append(e)
        states.append(v)
        if v <= H:
            assert v >= n, (n, source, v)
            break
        assert v not in states[:-1]
    assert len(set(states[:-1])) == len(states) - 1
    assert all(x > H for x in states[1:-1])
    assert exponents[0] == 1 and source % 4 == 3
    return states, exponents


def inspect_path(n: int, source: int) -> dict:
    states, exponents = first_return(n, source)
    B = 0
    E = 0
    phases = [Q(0)]
    corrections = [Q(1)]
    for i, (x, e) in enumerate(zip(states, exponents)):
        increment = Q(2**E, 3 ** (i + 1))
        assert increment == source * corrections[i] / (3 * x)
        B = 3 * B + 2**E
        E += e
        phases.append(Q(B, 3 ** (i + 1)))
        corrections.append(corrections[-1] * Q(3 * x + 1, 3 * x))
        assert phases[i + 1] - phases[i] == increment
        assert phases[i + 1] == source * (corrections[i + 1] - 1)
        assert 2**E * states[i + 1] == 3 ** (i + 1) * source + B

    for i, x in enumerate(states[:-1]):
        suffix_correction = corrections[-1] / corrections[i]
        assert phases[-1] - phases[i] == (
            source * corrections[i] * (suffix_correction - 1)
        )
        rho = corrections[i] * Q(source * (x + 5), x * (source + 5))
        assert rho - 1 == (
            phases[i] * (x + 5) - 5 * (x - source)
        ) / (x * (source + 5))
        if i and rho <= 1:
            assert phases[i] <= Q(5 * (x - source), x + 5) < 5

    budgets = [Q(0), Q(1, 3), Q(1), Q(5), Q(17, 2), Q(100)]
    direct_comparisons = 0
    for budget in budgets:
        early = [i for i in range(len(exponents)) if phases[i] <= budget]
        late = [i for i in range(len(exponents)) if phases[-1] - phases[i] <= budget]
        early_sum = sum(Q(1, 3 * states[i]) for i in early)
        late_sum = sum(Q(1, 3 * states[i]) for i in late)
        union_sum = sum(Q(1, 3 * states[i]) for i in set(early) | set(late))
        assert early_sum <= budget / source + Q(1, 3 * n)
        assert late_sum <= budget / source
        assert union_sum <= (2 * budget + Q(1, 3)) / n
        direct_comparisons += 3
    shells = sorted({x.bit_length() - 1 for x in states[:-1]})
    comparisons = 0
    max_early = 0
    max_late = 0
    for ell in shells:
        Y = 2**ell
        indices = [i for i, x in enumerate(states[:-1]) if Y <= x < 2 * Y]
        assert n < 2 * Y
        for budget in budgets:
            early = [i for i in indices if phases[i] <= budget]
            late = [i for i in indices if phases[-1] - phases[i] <= budget]
            union = set(early) | set(late)
            assert len(early) <= 1 + Q(6 * Y, n) * budget
            assert len(late) <= Q(6 * Y, n) * budget
            assert len(union) <= 1 + Q(12 * Y, n) * budget
            if len(early) >= 2:
                spent = sum(phases[i + 1] - phases[i] for i in early[:-1])
                assert spent <= phases[early[-1]] - phases[early[0]] <= budget
                assert spent >= Q((len(early) - 1) * n, 6 * Y)
            if late:
                spent = sum(phases[i + 1] - phases[i] for i in late)
                assert spent <= phases[-1] - phases[late[0]] <= budget
                assert spent >= Q(len(late) * n, 6 * Y)
            comparisons += 3
            max_early = max(max_early, len(early))
            max_late = max(max_late, len(late))

    return {
        "n": n,
        "source": source,
        "endpoint": states[-1],
        "odd_transitions": len(exponents),
        "resets": sum(e >= 2 for e in exponents),
        "total_phase": str(phases[-1]),
        "total_correction": str(corrections[-1]),
        "states": states,
        "exponents": exponents,
        "phase_shell_comparisons": comparisons,
        "direct_reciprocal_comparisons": direct_comparisons,
        "largest_early_count_tested": max_early,
        "largest_late_count_tested": max_late,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("chronological_phase_window_certificate.json"))
    args = parser.parse_args()
    saved_groups = [
        (55, [63, 71]),
        (61, [63, 71]),
        (4095, [4575, 5147]),
        (22331, [23207, 25407, 28583, 28975]),
        (65535, [72687, 76575, 80671]),
    ]
    paths = [inspect_path(n, u) for n, sources in saved_groups for u in sources]
    result = {
        "status": "PASS",
        "scope": "Finite exact tests of chronological identities and per-profile shell budgets; no slow-predicate or unrestricted incidence certification",
        "profiles_checked": len(paths),
        "phase_shell_comparisons": sum(p["phase_shell_comparisons"] for p in paths),
        "direct_reciprocal_comparisons": sum(p["direct_reciprocal_comparisons"] for p in paths),
        "paths": paths,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(paths)} actual first-return profiles; "
          f"{result['phase_shell_comparisons']} exact phase-shell inequalities; "
          f"{result['direct_reciprocal_comparisons']} direct reciprocal inequalities.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
