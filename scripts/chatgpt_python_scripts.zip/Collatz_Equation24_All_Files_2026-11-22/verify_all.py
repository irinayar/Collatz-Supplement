#!/usr/bin/env python3
"""Run the new Equation (24) arithmetic checks in isolated directories.

This driver verifies reproducibility of the delivered exact certificates.
The uniform theorems are written proofs; this is not a proof of the unresolved
central incidence estimate. No third-party packages or network are needed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without -O: the exact checkers use assertions.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=HERE / "equation24_verification_summary.json",
    )
    args = parser.parse_args()
    tasks = [
        (
            "reset_run_boundaries",
            "verify_reset_run_boundaries.py",
            "reset_run_boundary_certificate.json",
            [
                "--seeds",
                str(ROOT / "all_depth_work" / "incoming_inverse_saved_first_hits.json"),
            ],
        ),
        (
            "chronological_phase_windows",
            "verify_chronological_phase_windows.py",
            "chronological_phase_window_certificate.json",
            [],
        ),
        (
            "incoming_six_notes",
            "verify_incoming_six_notes.py",
            "incoming_six_notes_certificate.json",
            ["--seeds", str(HERE / "incoming_six_note_seed_groups.json")],
        ),
    ]
    results = []
    for label, script, certificate, extra in tasks:
        with tempfile.TemporaryDirectory(prefix="collatz_eq24_") as td:
            generated = Path(td) / certificate
            command = [
                sys.executable,
                "-B",
                str(HERE / script),
                *extra,
                "--output",
                str(generated),
            ]
            completed = subprocess.run(
                command,
                cwd=td,
                text=True,
                capture_output=True,
                timeout=180,
                check=False,
            )
            if completed.returncode:
                raise RuntimeError(
                    f"{label} failed with code {completed.returncode}\n"
                    f"{completed.stdout}\n{completed.stderr}"
                )
            expected_bytes = (HERE / certificate).read_bytes()
            actual_bytes = generated.read_bytes()
            expected = json.loads(expected_bytes)
            actual = json.loads(actual_bytes)
            if actual != expected:
                raise AssertionError(f"Certificate mismatch: {certificate}")
            row = {
                "check": label,
                "status": "PASS",
                "certificate": certificate,
                "semantic_json_match": True,
                "delivered_sha256": hashlib.sha256(expected_bytes).hexdigest(),
                "regenerated_sha256": hashlib.sha256(actual_bytes).hexdigest(),
                "byte_match": actual_bytes == expected_bytes,
            }
            results.append(row)
            print(f"PASS: {label}; regenerated certificate matches.", flush=True)
    summary = {
        "status": "PASS",
        "scope": (
            "Reproduction of the three new exact arithmetic certificates; "
            "no unrestricted central-incidence theorem is inferred."
        ),
        "isolated_checkers": len(results),
        "results": results,
    }
    args.output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(f"Summary: {args.output.resolve()}")


if __name__ == "__main__":
    main()
