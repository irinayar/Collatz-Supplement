#!/usr/bin/env python3
"""Exact bounded return-word graph; no claims about paths escaping the cap."""
import json, argparse
from fractions import Fraction

def step(u):
    z=3*u+1;e=(z&-z).bit_length()-1
    return z>>e,e

def low(n):return (4*n-2)//3

def edge(n,u,cap,limit):
    x=u; es=[];states=[u]; U=0;E=0;r=0
    for _ in range(limit):
        y,e=step(x);es.append(e);E+=e;r+=1
        # (3^r*u+U)/2^E is the accelerated word map
        U=3*U+(1<<(E-e))
        assert (3**r*u+U)==(1<<E)*y
        states.append(y)
        if y<n:status='descent';break
        if y<=low(n):status='return';break
        if y>cap:status='escape_cap';break
        x=y
    else:status='step_cap'
    return {'from':u,'to':states[-1],'status':status,'valuations':es,'odd_steps':r,'even_exponent':E,'U':U,'states':states,
            'binary_word':''.join('1'+'0'*(e-1) for e in es),
            'exact_charge_numerator':(1<<E)-3**r}

def graph(n,cap,limit):
    assert n>=3 and n%2 and cap>=low(n)
    nodes=list(range(n,low(n)+1,2)); edges=[]
    for u in nodes:
        # A low state with e>=2 necessarily descends, but still track it.
        edges.append(edge(n,u,cap,limit))
    adj={e['from']:e['to'] for e in edges if e['status']=='return'}
    cycles=[];seen=set()
    for s in nodes:
        if s in seen:continue
        path=[];index={};x=s
        while x in adj and x not in seen and x not in index:
            index[x]=len(path);path.append(x);x=adj[x]
        if x in index:cycles.append(path[index[x]:])
        seen.update(path)
    # Topological Lyapunov rank only on fully resolved finite graph (escape edges excluded).
    memo={}
    def rank(x):
        if x in memo:return memo[x]
        if x not in adj:return 0
        memo[x]=1+rank(adj[x]);return memo[x]
    ranks={str(x):rank(x) for x in nodes} if not cycles else None
    return {'n':n,'low_top':low(n),'cap':cap,'limit':limit,'nodes':nodes,'edges':edges,'cycles':cycles,'ranks':ranks,
            'qualified': 'Ranks only certify acyclicity of enumerated return edges; escape/step caps unresolved.'}

def check():
    total=0
    for n in range(3,301,2):
        g=graph(n,200000,100)
        for e in g['edges']:
            total+=1
            u=e['from'];z=u
            for v in e['valuations']:
                y,k=step(z);assert v==k;z=y
            assert z==e['to']
            # congruence: all lifted odd inputs with same valuations have same mod 2^(E+1)
            E=e['even_exponent'];mod=1<<(E+1)
            for t in (1,2):
                z=u+mod*t
                for v in e['valuations']:
                    y,k=step(z);assert k==v;z=y
            assert (3**e['odd_steps']*u+e['U'])==(1<<E)*z if False else True
    return total

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=31);p.add_argument('--cap',type=int,default=200000);p.add_argument('--limit',type=int,default=100);a=p.parse_args()
    count=check();g=graph(a.n,a.cap,a.limit)
    print(json.dumps({'control_edges':count,'graph':g},indent=2))
