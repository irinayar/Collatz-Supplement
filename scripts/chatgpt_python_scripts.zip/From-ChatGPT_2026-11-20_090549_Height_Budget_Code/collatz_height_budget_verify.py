from math import log2

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def word_data(n,j):
    x=n; U=0; a=0; last=-1
    for i in range(j):
        if x&1:
            U=3*U+(1<<i);a+=1;last=i
        x=T(x)
    return x,a,U,last

def u_bound(j,a,last):
    return 0 if a==0 else (1<<(last-a+1))*(3**a-2**a)

checks=0; strict_cross=0; forced=0; examples=[]
for n in range(1,2001):
    for j in range(1,31):
        x,a,U,last=word_data(n,j)
        assert (1<<j)*x==3**a*n+U
        assert U<=u_bound(j,a,last)
        if 3**a<1<<j:
            strict_cross+=1
            threshold=U//((1<<j)-3**a)
            assert (x<n)==(n>U/((1<<j)-3**a))
            if n>u_bound(j,a,last)//((1<<j)-3**a):
                assert x<n
                forced+=1
                if len(examples)<6 and n>2: examples.append((n,j,a,last,x,threshold))
        checks+=1
print('CHECKS',checks,'CROSSINGS',strict_cross,'FORCED_BY_LAST_ODD_BOUND',forced)
print('EXAMPLES',examples)
