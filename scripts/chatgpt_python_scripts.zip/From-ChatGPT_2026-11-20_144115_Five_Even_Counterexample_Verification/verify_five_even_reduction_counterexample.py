from itertools import combinations
from functools import lru_cache
@lru_cache(None)
def minimum(x,k,r):
    if r<0: return None
    if k==0:
        q=x+1
        for _ in range(r):
            if q%3: return None
            q=2*(q//3)
        return q-1
    a=0; q=x+1
    while q%3==0: a+=1;q//=3
    vals=[]
    for ell in range(min(a,r)+1):
        y=2*(2**ell*(x+1)//3**ell-1)
        z=minimum(y,k-1,r-ell)
        if z is not None: vals.append(z)
    return min(vals) if vals else None

def exhaustive(x,k,r):
    length=k+r; out=[]
    for positions in combinations(range(length),r):
        v=sum(2**p*3**(r-1-h) for h,p in enumerate(positions))
        n=2**length*x-v
        if n>0 and n%3**r==0:
            m=n//3**r; z=m
            for _ in range(length): z=(3*z+1)//2 if z%2 else z//2
            assert z==x
            out.append((m,''.join('1' if i in positions else '0' for i in range(length))))
    return sorted(out)
assert minimum(224,5,5)==943
assert minimum(149,5,4) is None
assert exhaustive(224,5,5)==[(943,'1111010000')]
assert exhaustive(149,5,4)==[]
assert [minimum(224,5,r) for r in range(7)]==[7168,4768,3168,2116,1410,943,None]
print('PASS: exact recurrence, exhaustive words, replay, and reduction counterexample')
