#!/usr/bin/env python3
"""Exact accelerated-Collatz parity-cylinder and descent-certificate experiments."""
from fractions import Fraction

def T(n): return (3*n+1)//2 if n&1 else n//2

def word_data(word):
    a=u=0
    for j,b in enumerate(word):
        if b: u=3*u+(1<<j); a+=1
    return len(word),a,u

def residue_for_word(word):
    """Lift unique starting residue mod 2**L realizing prescribed parity word."""
    r=0
    for j,b in enumerate(word):
        if (T_iter(r,j)&1)!=b:
            r+=1<<j
        assert (T_iter(r,j)&1)==b
    return r

def T_iter(n,j):
    for _ in range(j): n=T(n)
    return n

def certified_cylinder(word):
    L,A,U=word_data(word); D=(1<<L)-3**A
    if D<=0: return None
    r=residue_for_word(word)
    # n=r+2**L*t, t>=0. n>U/D iff D*n>U.
    t=max(0,(U-D*r)//(D*(1<<L))+1)
    n=r+(1<<L)*t
    assert D*n>U
    return dict(L=L,A=A,U=U,D=D,residue=r,first_certified_n=n,threshold=str(Fraction(U,D)))

def main():
    for q in [0,1,2,3,5,8,12,20]:
        word=[1,1,0]+[1]*q
        r=residue_for_word(word); L=len(word)
        n=r+(1<<L)*10
        vals=[T_iter(n,j) for j in range(L+1)]
        assert all(v>n for v in vals[1:]),(q,n,vals)
        assert [v&1 for v in vals[:-1]]==word
        print('delay',q,'L',L,'residue',r,'example',n,'end',vals[-1])
    for word in ([1,0],[1,1,0,0],[1,1,0,0,0],[1,1,0,1,0,0],[1,1,0,1,1,0,0]):
        cert=certified_cylinder(word)
        print('certificate', ''.join(map(str,word)),cert)
        if cert:
            n=cert['first_certified_n']; L=cert['L']; r=cert['residue']
            for t in range(10):
                m=n+t*(1<<L)
                assert T_iter(m,L)<m
                assert [T_iter(m,j)&1 for j in range(L)]==list(word)
    # Exhaustive equivalence for all words of length <= 10, each representative and 3 lifts
    checks=0
    for L in range(1,11):
        for mask in range(1<<L):
            word=[(mask>>j)&1 for j in range(L)]
            r=residue_for_word(word)
            ll,a,u=word_data(word)
            for t in range(1,4):
                n=r+(1<<L)*t
                assert [T_iter(n,j)&1 for j in range(L)]==word
                assert (1<<L)*T_iter(n,L)==3**a*n+u
                assert (T_iter(n,L)<n)==(((1<<L)-3**a)*n>u)
                checks+=1
    print('PASS exact comparisons',checks)
if __name__=='__main__':main()
