from collections import defaultdict

def iterate(n,j):
 x=n; bits=[]; U=0; a=0
 for i in range(j):
  odd=x&1; bits.append(odd)
  if odd:
   U=3*U+(1<<i); a+=1; x=(3*x+1)//2
  else: x//=2
 return x,bits,a,U

def ladder(y,bits):
 pos=[i for i,v in enumerate(bits) if v]
 j=len(bits); cur=(1<<j)*y
 out=[cur]
 for i in reversed(pos):
  assert (cur-(1<<i))%3==0
  cur=(cur-(1<<i))//3
  assert cur>0
  out.append(cur)
 return out

stats={'checked':0,'high_pairs':0,'late_crossings':0,'first_late':None}
for j in range(1,17):
 by_end={}
 for n in range(1,3001):
  y,bits,a,U=iterate(n,j)
  if y in by_end:
   m,mbits,b,V=by_end[y]
   if b>=a+2:
    chain=ladder(y,mbits)
    assert chain[-1]==m
    assert all(chain[i+1]<chain[i] for i in range(len(chain)-1))
    assert chain[a+1] >= m
    stats['high_pairs']+=1
    if chain[a+1]>=n:
     stats['late_crossings']+=1
     if stats['first_late'] is None: stats['first_late']=(j,n,m,a,b,chain)
  else: by_end[y]=(n,bits,a,U)
  stats['checked']+=1
print(stats)
print('example j=15 source64 partner25')
y,nb,a,U=iterate(64,15)
y2,mb,b,V=iterate(25,15)
assert y==y2
print('endpoint',y,'counts',a,b,'ladder',ladder(y,mb),'source',64)
