from collections import Counter
from fractions import Fraction

def step(u):
    x=3*u+1
    e=(x & -x).bit_length()-1
    return x>>e,e

def run(n,u):
    H=(4*n-2)//3
    states=[u]; es=[]
    for j in range(4):
        v,e=step(states[-1]); states.append(v);es.append(e)
    return H,states,tuple(es)

def check(limit=10001):
    counts=Counter(); cases=0
    for n in range(3,limit+1,2):
        H=(4*n-2)//3
        for u in range(n,H+1,2):
            h,s,es=run(n,u)
            if all(v>H for v in s[1:4]) and n<=s[4]<=H:
                cases+=1;counts[es]+=1
                assert es in ((1,1,1,3),(1,1,2,2)),(n,u,s,es)
                assert u%128==(79 if es==(1,1,1,3) else 71)
                U=65 if es==(1,1,1,3) else 73
                assert 64*s[-1]==81*u+U
                assert s[-1]>u
                G=Fraction(64*s[-1],81*u)
                rho=G*Fraction(s[-1]+5,s[-1])*Fraction(u,u+5)
                assert rho==1+Fraction(U-85,81*(u+5)) and rho<1
    print('thresholds:',(limit-1)//2,'first returns:',cases,'patterns:',dict(counts),'failures:0')
if __name__=='__main__':check()
