from functools import lru_cache
@lru_cache(None)
def H(k,x,r):
    if r<0:return None
    if k==0:
        y=x+1
        for _ in range(r):
            if y%3:return None
            y=y//3*2
        return y-1 if y>1 else None
    a=0;z=x+1
    while z%3==0:a+=1;z//=3
    out=[]
    for ell in range(min(a,r)+1):
        y=2*((2**ell*(x+1)//3**ell)-1)
        v=H(k-1,y,r-ell)
        if v is not None:out.append(v)
    return min(out) if out else None
checks=0; early=0; oddpred=0; div3=0
for k in range(0,9):
 for x in range(3,201):
  if x%3==0:
   assert all(H(k,x,r) is None for r in range(1,12));div3+=1
  for r in range(0,12):
   m=H(k,x,r);n=H(k,x,r+1)
   if m is None or n is None:continue
   if 3*2**k*(3**r) >= (2**(r+0))*(3**r):pass
   if 2**r*(x+3)>=3**(r+1):
    assert n<m;(early:=early+1)
   if m%3==2:
    assert n <=(2*m-1)//3<m;oddpred+=1
   checks+=1
print({'checked_adjacent_pairs':checks,'early_range_pairs':early,'odd_predecessor_pairs':oddpred,'multiple_of_3_endpoint_budgets':div3})
