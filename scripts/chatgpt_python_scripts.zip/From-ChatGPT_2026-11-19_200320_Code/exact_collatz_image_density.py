from fractions import Fraction
def T(x):
    return x//2 if x%2==0 else (3*x+1)//2
def exact_image_density(j):
    """Density of distinct T^j images of starts 1..N, normalized by N."""
    groups=[set() for _ in range(j+1)]
    for r in range(1,2**j+1):
        x=r; a=0
        for _ in range(j):
            a+=x&1; x=T(x)
        groups[a].add(x%(3**a))
    modulus=3**j
    covered=bytearray(modulus)
    densities={}
    for a in range(j,-1,-1):
        step=3**a
        for residue in groups[a]:
            covered[residue::step]=b'\x01'*((modulus-1-residue)//step+1)
        densities[a]=Fraction(sum(covered),modulus)
    result=Fraction(0)
    for a in range(j+1):
        lower=Fraction(3**(a-1),2**j) if a else Fraction(0)
        upper=Fraction(3**a,2**j)
        result+=(upper-lower)*densities[a]
    return result
if __name__=="__main__":
    expected=["1","5/6","3/4","5/8","25/48","43/96","77/192","139/384","85/256","157/512","877/3072","1639/6144"]
    for j,expect in enumerate(expected):
        value=exact_image_density(j)
        assert str(value)==expect,(j,value,expect)
        print(f"k={j+1}: d_k={value}")
