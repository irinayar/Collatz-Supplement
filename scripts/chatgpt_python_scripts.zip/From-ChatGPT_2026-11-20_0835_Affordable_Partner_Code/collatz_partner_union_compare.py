"""Exact affordable-partner residue comparison for accelerated Collatz."""
def T(x): return x//2 if x%2 == 0 else (3*x+1)//2

def words(j):
    Q=1<<j
    out=[]
    for r in range(1,Q+1):
        x=r; a=0
        for _ in range(j):
            a+=x&1; x=T(x)
        out.append((r,a,Q*x-3**a*r))
    return out

def primitive_residues(j):
    W=words(j); result={}
    for r,a,U in W:
        R=set()
        for s,b,V in W:
            if b==a and V>U and (V-U)%(3**a)==0:
                R.update(range(3))
            if b==a+1 and (V-U)%(3**a)==0:
                R.add(((V-U)//3**a)%3)
        result[r]=R
    return result

def compare(j):
    W=words(j); R=primitive_residues(j)
    high=0
    for r,a,U in W:
        for s,b,V in W:
            if b<a+2 or (V-U)%(3**a):continue
            high+=1
            residue=((V-U)//3**a)%3
            assert residue in R[r],(j,r,s,a,b,residue)
    return high, sum(len(v) for v in R.values())

if __name__=='__main__':
    for j in range(1,10):
        print('depth',j,'higher pairs',compare(j)[0],'primitive residue entries',compare(j)[1])
    for n,expected in [(212,[(23,3),(70,2)]),(236,[(78,2)])]:
        target=n
        for _ in range(3):target=T(target)
        partners=[]
        for m in range(1,n):
            x=m;a=0
            for _ in range(3):a+=x&1;x=T(x)
            if x==target:partners.append((m,a))
        assert partners==expected,(n,partners)
        print(n,target,partners)
