from fractions import Fraction
import json

def run(u):
    assert u>255 and u%2==1
    s=((u+1)&-(u+1)).bit_length()-1
    w=3**s*(u+1)//2**s-1
    assert w>0 and w%2==0
    e=(w&-w).bit_length()-1
    v=w//2**e
    C=Fraction(3**s*(u+1)-2**s,3**s*u)
    return C,v

R=Fraction(69952,69741)
B=Fraction(227840,226719)
Q=Fraction(8192,6561)
T=Fraction(59703296,59344245)
# Independently re-establish Codex K102 single and pair maxima.
assert Fraction(1026,1025)<R
assert Fraction(1026,1025)*R<B
max_one=(Fraction(1),None)
max_pair=(Fraction(1),None)
for u in range(257,1024,2):
    c,v=run(u)
    if c>max_one[0]:max_one=(c,u)
    if v>255:
        d,_=run(v)
        if c*d>max_pair[0]:max_pair=(c*d,u)
assert max_one==(R,287)
assert max_pair==(B,311)
best=Fraction(1); winner=None
eligible=0
for u in range(257,1024,2):
    c1,v=run(u)
    if v<=255:continue
    c2,w=run(v)
    if w<=255:continue
    c3,z=run(w)
    p=c1*c2*c3
    eligible+=1
    if p>best:best=p;winner=(u,v,w,z)
assert best==T and winner==(335,425,319,911)
assert Fraction(1026,1025)*B<T
assert T<B*R

def bound(h):
    return Q*T**(h//3)*([Fraction(1),R,B][h%3])
assert all(bound(h)<Fraction(3,2) for h in range(91))
assert bound(91)>Fraction(3,2)
result={'eligible_finite_starts':eligible,'triple_max':str(T),'winner':winner,'analytic_tail':str(Fraction(1026,1025)*B),'safe_through_runs':90,'first_envelope_failure_runs':91,'bound_90':str(bound(90)),'bound_91':str(bound(91))}
with open('/mnt/data/triple_run_certificate/results.json','w') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
