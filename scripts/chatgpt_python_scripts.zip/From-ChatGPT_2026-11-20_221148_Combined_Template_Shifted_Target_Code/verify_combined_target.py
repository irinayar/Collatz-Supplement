import json, math
from functools import lru_cache
cases=json.load(open('/mnt/data/shifted_target_56_results.json'))

def search(x,k,r,origin_upper, mode='old'):
    # Find a valid parity word with origin <= origin_upper, exact congruence and positive.
    L=k+r; target=(1<<L)*x-(3**r)*origin_upper
    stats={'nodes':0,'pruned_numerator':0,'leaves':0,'valid':0}
    def walk(p,e,o,V):
        stats['nodes']+=1
        K=k-e;R=r-o
        if K<0 or R<0: return None
        # Exact upper bound for all completions from this prefix.
        upper=3**R*V+(1<<p)*((1<<K)*(3**R-2**R))
        if upper<target:
            stats['pruned_numerator']+=1;return None
        if p==L:
            stats['leaves']+=1
            num=(1<<L)*x-V
            if num>0 and num%(3**r)==0:
                m=num//(3**r)
                if m<=origin_upper:
                    stats['valid']+=1
                    return (m,'')
            return None
        if e<k:
            z=walk(p+1,e+1,o,V)
            if z: return (z[0],'E'+z[1])
        if o<r:
            z=walk(p+1,e,o+1,3*V+(1<<p))
            if z:return (z[0],'O'+z[1])
        return None
    found=walk(0,0,0,0)
    return found,stats

summary={'cases':len(cases),'successor_found':0,'old_below_successor':0,'old_nodes':0,'old_pruned':0,'successor_nodes':0,'successor_pruned':0,'examples':[]}
for row in cases:
    x,k,r,m,n=(row[z] for z in ['x','k','r','m','n'])
    win,st=search(x,k,r+1,m-1)
    assert win and win[0]<m,(row,win)
    bad,st2=search(x,k,r,win[0])
    assert bad is None,(row,win,bad)
    summary['successor_found']+=1;summary['old_below_successor']+=1
    for key,stat in [('successor',st),('old',st2)]:
        summary[key+'_nodes']+=stat['nodes'];summary[key+'_pruned']+=stat['pruned_numerator']
    if len(summary['examples'])<8: summary['examples'].append({'x':x,'k':k,'r':r,'old_min':m,'candidate':win[0],'word':win[1],'successor_stats':st,'old_exclusion_stats':st2})
print(json.dumps(summary,indent=2))
json.dump(summary,open('/mnt/data/combined_target_results.json','w'),indent=2)
