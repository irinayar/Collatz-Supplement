from itertools import combinations
from math import comb

def wordV(pos,b):
    return sum(3**(b-i-1)*2**p for i,p in enumerate(pos))

def bounds(k,b,x,branch,j):
    L=k+b; target=(2**L)*x; mod=3**b
    low=None; high=None; survivors=0
    for tail in combinations(range(L),j):
        if branch=='B' and tail[-1]!=L-1: continue
        if branch=='A' and tail[-1]>=L-2: continue
        n=b-j; t=tail[0]
        if t<n: continue
        T=wordV(tail,j)
        if (target-T)%(3**j):continue
        d=((target-T)//(3**j))%(3**n)
        pmin=3**n-2**n
        pmax=2**(t-n)*(3**n-2**n) if n else 0
        if pmax<pmin: continue
        p_lo=pmin+(d-pmin)%(3**n)
        p_hi=pmax-(pmax-d)%(3**n)
        if p_lo>p_hi:continue
        v_lo=T+3**j*p_lo;v_hi=T+3**j*p_hi
        # positive origin, if possible: v<target
        if v_lo>=target:continue
        v_hi=min(v_hi,target-3**b) # m>=1, congruence
        if v_hi<v_lo:continue
        survivors+=1
        # old minimum lower bound corresponds maximum numerator
        # new maximum upper bound corresponds minimum numerator
        m_lo=(target-v_hi)//mod;m_hi=(target-v_lo)//mod
        low=m_lo if low is None else min(low,m_lo)
        high=m_hi if high is None else max(high,m_hi)
    return (low,high,survivors)

def exact(k,b,x,branch):
    L=k+b;target=2**L*x; mod=3**b
    vals=[]
    for pos in combinations(range(L),b):
        if branch=='B' and pos[-1]!=L-1:continue
        if branch=='A' and pos[-1]>=L-2:continue
        v=wordV(pos,b)
        if (target-v)%mod==0 and target>v:vals.append((target-v)//mod)
    return vals

if __name__=='__main__':
    checked=0; failures=0; early=0; full=0; example=None; inconclusive=None; hist={}
    for k in range(2,8):
      for r in range(1,7):
       for x in range(5,100,3):
        for new,old in [('A','B'),('B','A')]:
         bnew=r+1 if new=='A' else r # B_r+1 has r odd before final O
         knew=k-2 if new=='A' else k
         bold=r if old=='A' else r-1
         kold=k-2 if old=='A' else k
         # branch actual endpoint maps to 4x or y
         znew=4*x if new=='A' else (2*x-1)//3
         zold=4*x if old=='A' else (2*x-1)//3
         a=exact(knew,bnew,znew,'any') if False else None
         # branch prefix sets have no extra suffix restrictions, since branch last steps already removed
         def allvals(kk,bb,zz):
          L=kk+bb; t=2**L*zz;mod=3**bb
          return [(t-wordV(p,bb))//mod for p in combinations(range(L),bb) if (t-wordV(p,bb))%mod==0 and t>wordV(p,bb)]
         valsnew=allvals(knew,bnew,znew)
         valsold=allvals(kold,bold,zold)
         if not valsnew or not valsold:continue
         checked+=1
         if max(valsnew)>=min(valsold): failures+=1;continue
         jnewmax=bnew; joldmax=bold
         first=None
         for j in range(0,max(jnewmax,joldmax)+1):
          # zero tail handled with universal envelope
          def bd(kk,bb,zz,jj):
           if jj==0:
            L=kk+bb; T=2**L*zz; q=3**bb
            return ((T-2**kk*(3**bb-2**bb))//q,(T-(3**bb-2**bb))//q,1)
           return bounds(kk,bb,zz,'any',jj)
          jn=min(j,bnew); jo=min(j,bold)
          bn=bd(knew,bnew,znew,jn);bo=bd(kold,bold,zold,jo)
          if bn[1] is not None and bo[0] is not None and bn[1]<bo[0]:first=j;break
         hist[first]=hist.get(first,0)+1
         if first is not None and first<max(jnewmax,joldmax):early+=1
         if first is None or first==max(jnewmax,joldmax):full+=1
         if example is None and first is not None and first>0:example=(k,r,x,new,old,first,bnew,bold,max(valsnew),min(valsold))
         if inconclusive is None and first is None:inconclusive=(k,r,x,new,old,bnew,bold,max(valsnew),min(valsold))
    print(dict(checked=checked,failures=failures,early=early,full_or_no=full,example=example,inconclusive=inconclusive,hist=hist))
