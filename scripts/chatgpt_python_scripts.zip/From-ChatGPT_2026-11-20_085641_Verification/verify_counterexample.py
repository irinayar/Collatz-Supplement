"""Independent exact depth-42 Collatz counterexample replay (standard library)."""
def T(x): return x//2 if x%2==0 else (3*x+1)//2
def run(n,j):
    x=n; a=0
    for _ in range(j):
        a+=x&1
        x=T(x)
    return x,a
j=42; B=2**j; n=251; N=n+3*B
assert run(n,j)==(2,22)
assert run(2,j)==(2,21)
by_count={}
for m in range(1,n):
    y,b=run(m,j)
    if y==2: by_count.setdefault(b,[]).append(m)
assert sorted(by_count)==[18,19,20,21]
assert {b:min(v) for b,v in by_count.items()}=={18:128,19:32,20:8,21:2}
assert run(N,j)==(2+3**23,22)
assert (2*B)//3**23==93
print('PASS: finite replay, odd counts, inverse minima, shifted endpoint')
print('small-origin matching counts:',{b:len(v) for b,v in by_count.items()})
print('shifted N:',N)
