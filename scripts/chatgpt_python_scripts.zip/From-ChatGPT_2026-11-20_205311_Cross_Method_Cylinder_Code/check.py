from fractions import Fraction
import json
rows=[]
for L in range(1,17):
    crossings=0; outside=0; positiveV=0; bad=0; sample=[]
    for a in range(1,(1<<L)+1):
        n=a;r=0
        for j in range(L):
            if n&1:n=(3*n+1)//2;r+=1
            else:n//=2
        V=(1<<L)*n-pow(3,r)*a
        if V<0:bad+=1
        if 2*V>pow(3,r)*a:
            crossings+=1
            if n>=3:
                outside+=1
                if len(sample)<5:sample.append((a,n,r,V))
    rows.append(dict(length=L,classes=1<<L,crossing_least=crossings,crossing_outside=outside,negative_V=bad,samples=sample))
print(json.dumps(rows,indent=2))
open('/mnt/data/collatz_cross_method/results.json','w').write(json.dumps(rows,indent=2))
