#!/usr/bin/env python3
"""Second independent exact-arithmetic boundary and product-check implementation.
No use of the primary verification script or external dependencies.
"""
from fractions import Fraction


def ceiling_fraction(a,b):
    return -(-a//b)


def cutoff(x):
    assert x%6==5
    e=Fraction(3*(x+4)+1,3*(x+4))
    crit=Fraction(x+1,6)*(Fraction(3,1)**9 / e**9-Fraction(1,1))
    rmax=ceiling_fraction(crit.numerator,crit.denominator)-1
    assert rmax < crit <= rmax+1
    # Show a separate direct cross-product comparison at the transition.
    lhs1=e.numerator**9*(x+1+6*rmax)
    lhs2=e.numerator**9*(x+1+6*(rmax+1))
    rhs=3**9 * e.denominator**9*(x+1)
    assert lhs1<rhs<=lhs2
    return 2*rmax+1,2*rmax+2,rmax


def f(v): return Fraction(3*v+1,3*v)


def product_pair_check(x):
    # Exact data checks only; the all-v claim is the analytic proof in the MD.
    count=0
    for t in range(0,200):
        v=x+2+6*t
        lhs=f(v)*f(v+4)
        # Raise to the 9th power to avoid any roots or floating point.
        assert lhs**9 <= Fraction(v+5,v-1)
        count+=1
    return count


def main():
    x=89393
    simple=cutoff(x)
    conditional=cutoff(2075*2**60-3)
    assert simple==(586464555,586464556,293232277)
    print('UNCONDITIONAL CUTOFF b,a,R=',simple)
    print('CONDITIONAL M COROLLARY b,a,R=',conditional)
    print('EXACT PAIR INEQUALITY CONTROLS:',product_pair_check(x))
    print('PASS: independent exact rational and cross-multiplication checks')

if __name__=='__main__':main()
