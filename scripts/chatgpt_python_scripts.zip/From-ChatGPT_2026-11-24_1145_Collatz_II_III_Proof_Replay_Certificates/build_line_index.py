#!/usr/bin/env python3
"""Enumerate every theorem-like environment and sectional heading of exact CollatzTwo upload with line anchors.
Annotation 'nearby_proof' is syntactic only; never a claim of mathematical proof completeness.
"""
import csv,re,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/CollatzTwo(1).tex')
lines=p.read_text().splitlines()
head=[];cur='(front matter)'
for i,l in enumerate(lines,1):
 m=re.match(r'\\(section|subsection|subsubsection)\{(.+?)\}',l)
 if m:
  cur=m.group(2);head.append((i,m.group(1),cur))
with open('CollatzTwo_all_section_anchors.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['source_file','start_line','heading_level','heading'])
 for i,k,n in head:w.writerow([p.name,i,k,n])
entries=[]
for i,l in enumerate(lines):
 m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary)\}(?:\[([^]]*)\])?',l)
 if not m:continue
 kind=m.group(1); title=m.group(2) or '(unnamed)';end=i+1
 while end<len(lines) and ('\\end{'+kind+'}') not in lines[end]:end+=1
 after='\n'.join(lines[end+1:min(end+15,len(lines))])
 near=bool(re.search(r'\\begin\{proof\}',after))
 section=max((h for h in head if h[0]<=i+1),default=(0,'',''))
 entries.append((i+1,end+1,kind,title,section[0],section[2], 'nearby proof starts' if near else 'no proof starts in next 14 lines: check grouped proof, other section or certificate'))
with open('CollatzTwo_all_theorem_anchors.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['start_line','end_line','type','title','section_line','section','syntactic_proof_location_note']);w.writerows(entries)
print('headings',len(head),'theorem statements',len(entries),'local proof proximity',sum(x[-1]=='nearby proof starts' for x in entries))
