from fractions import Fraction
from collections import Counter
import math, json
# exact count 292
vals=[]
for g in range(4,706):
 p=3**g
 k=p.bit_length()-1
 vals.append((p,1<<k,g))
from functools import cmp_to_key
def cmp(a,b):
 d=a[0]*b[1]-b[0]*a[1]
 return (d>0)-(d<0)
vals.sort(key=cmp_to_key(cmp));N=len(vals)
# find count in open circular arc with ratio <4/3
best=0;first=[]
for i,(p,q,g) in enumerate(vals):
 c=0
 for t in range(N):
  u,v,h=vals[(i+t)%N]
  if i+t>=N:u*=2
  if 3*u*q<4*p*v:c+=1
  else:break
 if c>best:best=c;first=[g]
 elif c==best:first.append(g)
print('arc max, count max starters, sample=',best,len(first),first[:15]);assert best==292
# 86332 excludes
first=[]
for s in range(2,273):
 e=2
 while (1<<(s+e-1))<3**s:
  first.append((s,e));e+=1
print('first types',len(first));assert len(first)==21583
Hmax=((1<<274)-6)//3
cuttypes=[(193,114),(246,145),(299,176),(352,207)]
mins=[]
for s2,e2 in cuttypes:
 minr=None;minse=None
 for s1,e1 in first:
  g=s1+s2; E=g+e1+e2-2
  U=3**g+(1<<s1)*3**s2*((1<<(e1-1))-1)-(1<<(g+e1-1))
  mod=1<<(E+1)
  r=((1<<E)-U)*pow(3**g,-1,mod)%mod
  if minr is None or r<minr:minr=r;minse=(s1,e1)
  if r<=Hmax:
   raise ValueError('exclusion failed',s1,e1,s2,e2,r)
 mins.append((s2,e2,minr.bit_length(),minse))
print('86k mins',mins)
