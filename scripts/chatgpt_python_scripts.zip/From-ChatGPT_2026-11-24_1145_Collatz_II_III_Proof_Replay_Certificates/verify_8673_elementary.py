#!/usr/bin/env python3
"""Exact odd-product certificate for distinct odd Collatz inputs >=3.
Bound: among b distinct odd states >=3, at most one is divisible by 3.
The largest possible product of (1+1/(3u)) is achieved by 3
and the first b-1 odd numbers >=5 coprime to 3.
"""
from math import gcd
P=Q=1
u=3
cross=[]
for b in range(1,8674):
    while u>3 and u%3==0:
        u+=2
    P*=3*u+1;Q*=3*u
    if b in (8672,8673):
        cross.append((b,u, (P*1 > Q*3)-(P*1 < Q*3), P.bit_length(), Q.bit_length()))
    u+=2
assert cross[0][2]==-1 and cross[1][2]==1
for row in cross: print('b, last_odd, sign(P-3Q), digits_P, digits_Q:',row)
print('Exact cutoff: P_8672 < 3 < P_8673; valid upper bound, not an existence proof')
