#!/usr/bin/env python3
"""Independent reconstruction from CollatzTwo(1).tex BW.3/BW.6-10, WR.6 and FG.A4.
Not the author's original_core_profile.py or original_source_count.py."""
from fractions import Fraction as F
from math import floor
N=379283455055006348091611351977328444642239
U=[505711273406675130788815135969771259522983,473569587534005792343618380642931659580735]
H=(4*N-2)//3

def pstar(n):
 h=(4*n-2)//3; k=max(2,(h-n).bit_length()); ms=h.bit_length()
 old={2:1}
 for j in range(3,ms+1):
  old={r:v for r,v in ((r, (old.get(r,0)+old.get(r-1,0))) for r in range(2,j+1)) if v and 3**r>2**(j-1)}
 pold=2*sum(old.values())
 d={2:1}; pnew=0
 for j in range(3,k+1):
  # D_j: BW.8
  d={r:v for r,v in ((r,d.get(r,0)+d.get(r-1,0)) for r in range(2,j+1)) if v and 2**j*n**r<(3*n+1)**r}
  if j+1>=3:
   E=j+1
   if E<=k:
    for g,v in d.items():
     if (3*n-E)*2**E<3*h*3**g and n*3**g<h*2**E: pnew+=v
 pnew+=sum(d.values())
 # short E3 uses D2,2
 if k>=3 and (3*n-3)*8 < 3*h*9 and n*9 < h*8:pnew+=1
 return dict(pnew=pnew,pold=pold,pstar=min(pnew,pold),k=k,ms=ms)

def odd_trajectory(source):
 x=source;xs=[x];es=[];E=0
 for step in range(1000):
  z=3*x+1;e=(z&-z).bit_length()-1
  x=z>>e;es.append(e);xs.append(x);E+=e
  if N<=x<=H:break
  assert x>H,(step,x)
 else:raise RuntimeError('no return')
 return xs,es,E

def report(u,p):
 xs,es,E=odd_trajectory(u);g=len(es)
 print('u',u,'g,E',g,E,'return',xs[-1],'H',H)
 # full odd-word numerator B, recurrence (B_i,E_i)
 B=0; Et=0
 for i,e in enumerate(es):
  B=3*B+2**Et;Et+=e
 assert (3**g*u+B)==(2**E*xs[-1])
 mod=1<<(E+1); r=((1<<E)-B)*pow(3**g,-1,mod)%mod
 print('residue match',u==r,'mod',E+1)
 # phase q at each odd start, odd to odd affine numerator
 num=0; exp=0
 q=[]
 for i,(a,e) in enumerate(zip(xs,es)):
  q.append(F(num,3**i))
  num=3*num+2**exp;exp+=e
 qfinal=F(num,3**g)
 assert num==B
 m=N.bit_length()
 L=N.bit_length()-1
 # extract complete runs
 starts=[]; gstart=0;Estart=0; i=0
 while i<g:
  j=i
  while j<g and es[j]==1:j+=1
  assert j<g
  starts.append((i,j+1))
  i=j+1
 # run start time is sum exponent before it, remaining index
 core=[];details=[]
 for run_idx,(i,endi) in enumerate(starts):
  a=xs[i]; ell=a.bit_length()-1; v=ell-L
  jthresh=(1<<ell)//(2000*p*(v+1)*(v+2))
  past=run_idx;remaining=len(starts)-run_idx
  time=sum(es[:i]); canon_before=time+ell<E
  yy=a
  for z in range(ell):yy=(3*yy+1)//2 if yy&1 else yy//2
  canon_h=64*yy>a
  phase_in=q[i]>F(5,1)+F(N,100000*p)
  phase_left=qfinal-q[i]>F(5,1)+F(N,100000*p)
  ceiling=H<a< (1<<(64*m))
  iscore=ceiling and canon_before and canon_h and phase_in and phase_left and past>jthresh and remaining>jthresh
  if iscore:core.append((run_idx,i,a,es[j]))
  details.append(dict(run=run_idx,i=i,length=endi-i,exponent=es[j],a=a,ell=ell,time=time,cutoff=jthresh,pre=past,rem=remaining,canon_before=canon_before,canon_h=canon_h,phase_in=phase_in,phase_left=phase_left,iscore=iscore))
 print('runs',len(starts),'core',len(core),'types',[(d['length'],d['exponent']) for d in details if d['iscore']]);return xs,es,core,details
if __name__=='__main__':
 print('pstar',pstar(N));p=pstar(N)['pstar'];out=[report(u,p) for u in U]
 common=set(d[2] for d in out[0][2]) & set(d[2] for d in out[1][2]);print('common starts',len(common))
def score_profile(u,p):
 xs,es,core,details=report(u,p)
 cc=set(d[0] for d in core)
 total=F(0); records=[]
 for d in details:
  i=d['i'];s=d['length'];end=i+s; a=xs[i];b=xs[end]
  beta=1-F(2,3)**s; delta=beta/a; f=F(1,a)-F(1,b);t=F(N-1,N+1)*delta+f
  c=max(F(0),-f-delta/15); sc=t if d['run'] in cc else -c
  total+=sc
  records.append(dict(i=i,run=d['run'],a=a,b=b,s=s,e=d['exponent'],core=d['run'] in cc,t=t,c=c,score=sc))
 print('nZ',float(N*total),'positive_core',sum(1 for q in records if q['core'] and q['t']>0),'negative_core',sum(1 for q in records if q['core'] and q['t']<0))
 return total,records
if __name__=='__main__':
 p=pstar(N)['pstar']; rr=[score_profile(u,p) for u in U]
 m1={z['a']:z for z in rr[0][1] if z['core']}; m2={z['a']:z for z in rr[1][1] if z['core']}
 com=m1.keys()&m2.keys();shared=sum((m1[x]['score'] for x in com),F(0))
 print('nShared',float(N*shared),'types', {str((m1[x]['s'],m1[x]['e'])):sum((m1[y]['s'],m1[y]['e'])==(m1[x]['s'],m1[x]['e']) for y in com) for x in com})
 print('first two v', [(x['s'],x['e'],float(N*x['c'])) for x in rr[1][1][:2]])
