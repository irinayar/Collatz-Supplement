#!/usr/bin/env python3
"""RECONSTRUCTED original core fixture, not the original authored files. All arithmetic exact.
Reads BW.3/6-10 and WR.6 in CollatzTwo(1).tex and FG.A4 in CollatzThree(2).tex.
"""
import json,contextlib,io
from collections import Counter
from reconstruct_profile import N,H,U,pstar,score_profile,F

def ff(z):return f'{z.numerator}/{z.denominator}'

def run():
 p=pstar(N)
 with contextlib.redirect_stdout(io.StringIO()):
  a=score_profile(U[0],p['pstar']);b=score_profile(U[1],p['pstar'])
 rec=[]
 for u,(score,rr) in zip(U,(a,b)):
  mask=[dict(run=z['run'],odd_index=z['i'],odd_start=str(z['a']),odd_output=str(z['b']),length=z['s'],exponent=z['e'],core=z['core'],signed_score=ff(z['score']),t=ff(z['t']),credit=ff(z['c'])) for z in rr]
  core=[z for z in rr if z['core']]
  rec.append(dict(source=str(u),number_of_runs=len(rr),core_count=len(core),core_types={f"({s},{e})":v for (s,e),v in Counter((z['s'],z['e']) for z in core).items()},total_score=ff(score),scaled_score_20_digits=f'{float(N*score):.15f}',positive_core=sum(z['t']>0 for z in core),negative_core=sum(z['t']<0 for z in core),runs=mask))
 c0={z['a']:z for z in a[1] if z['core']};c1={z['a']:z for z in b[1] if z['core']};com=c0.keys() & c1.keys()
 shared=sum((c0[x]['score'] for x in com),F(0))
 c_entry=sum((z['c'] for z in b[1][:2]),F(0))
 assert len(com)==31 and len(c0)==31 and len(c1)==33
 assert Counter((c0[x]['s'],c0[x]['e']) for x in com)==Counter({(2,2):21,(1,2):8,(4,2):1,(3,2):1})
 assert abs(float(N*a[0])-4.8508)<.0001 and abs(float(N*b[0])-5.0504)<.0001
 assert abs(float(N*shared)-7.7664)<.0001 and float(shared/c_entry)>30
 doc=dict(scope='independent reconstruction of the manuscript formulas, NOT the authors original_core_profile.json',n=str(N),H=str(H),source_count={k:str(v) for k,v in p.items()},profiles=rec,shared_odd_inputs=[str(x) for x in sorted(com)],shared_core_count=len(com),shared_signed_score=ff(shared),scaled_shared_score=float(N*shared),second_source_entrance_credit=ff(c_entry),scaled_second_entry=float(N*c_entry),shared_over_entry=float(shared/c_entry),corrected_shared_types={'(2,2)':21,'(1,2)':8,'(4,2)':1,'(3,2)':1})
 with open('independent_original_core_profile.json','w') as f:json.dump(doc,f,indent=2)
 print('PASS source counts',p)
 print('PASS core',len(c0),len(c1),'shared',len(com),'types',doc['corrected_shared_types'])
 print('PASS scaled scores',float(N*a[0]),float(N*b[0]),float(N*shared),'scaled entry',float(N*c_entry))
if __name__=='__main__':run()
