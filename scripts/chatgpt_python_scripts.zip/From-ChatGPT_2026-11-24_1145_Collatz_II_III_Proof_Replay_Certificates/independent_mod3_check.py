#!/usr/bin/env python3
"""Independent compressed-tail, pairing and exact integer-bound verifier.
Uses only Python standard library, without importing the first verifier.
"""
from fractions import Fraction
import csv
from pathlib import Path

X=89393

def count_compressed(z):
    odd=steps=0
    seen=set()
    while z!=1:
        assert z not in seen, ('cycle',z)
        seen.add(z)
        w=3*z+1
        twos=(w & -w).bit_length()-1
        z=w>>twos
        steps+=twos;odd+=1
        assert steps<5000
    return odd,steps


def test_product_pairs():
    # Exact polynomial equivalent to pairwise g(v)>0 for sampled v.
    # General proof is by derivative monotonicity; see accompanying audit.
    for v in [5,7,11,100,89395,89395+6,89395+6*100,89395+6*100000]:
        # [ f(v)*f(v+4) ]^9 < (v+5)/(v-1).
        assert ((3*v+1)*(3*v+13))**9 * (v-1) < (9*v*(v+4))**9 * (v+5)
        # Verify displayed derivative identity at that v by exact arithmetic.
        diff=(Fraction(1,v+5)-Fraction(1,v-1))/9
        diff-=Fraction(3,3*v+1)-Fraction(1,v)
        diff-=Fraction(3,3*v+13)-Fraction(1,v+4)
        cube=3*v**3-8*v**2-65*v+390
        target=Fraction(-2*cube,3*v*(v-1)*(v+4)*(v+5)*(3*v+1)*(3*v+13))
        assert diff==target
        assert cube==3*(v-5)**3+37*(v-5)**2+80*(v-5)+240


def main():
    max_ratio=Fraction(0)
    maximizer=None
    count=0
    with Path(__file__).with_name('odd_tails_3_to_89393.csv').open(newline='') as f:
        for row in csv.DictReader(f):
            z=int(row['odd_start'])
            odd,steps=count_compressed(z)
            assert z==2*count+3
            assert (odd,steps)==(int(row['odd_inputs_to_1']),int(row['accelerated_steps_to_1']))
            ratio=Fraction(1<<steps,3**odd*z)
            if ratio>max_ratio:
                max_ratio=ratio;maximizer=z
            count+=1
    assert count==44696 and maximizer==993
    assert max_ratio==Fraction(2**61,3**32*993)
    test_product_pairs()
    V=89395
    F=max_ratio
    C=Fraction(3*V+1,3*V)
    A=(X+1)*((3*F.denominator*C.denominator)**9-(F.numerator*C.numerator)**9)
    B=6*(F.numerator*C.numerator)**9
    R=(A-1)//B
    assert R==38464724 and B*R<A<=B*(R+1)
    print('PASS: independent compressed validation',count,'odd inputs; pair samples; exact R=',R,'b_min=',2*R+1)

if __name__=='__main__':main()
