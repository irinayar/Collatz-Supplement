#!/usr/bin/env python3
"""Rebuild exact finite-tail maximum and prove the new mod-3-paired cutoff.

Standard library only. All integer and rational comparisons are exact.
"""
from fractions import Fraction
from pathlib import Path
import csv, json, hashlib

X=89393
P=2**61
Q=3**32*993
S=P*(3*(X+2)+1)
D=Q*3*(X+2)


def T(x):
    return (3*x+1)//2 if x%2 else x//2


def direct(z):
    n=z; a=j=0; seen=set()
    while n!=1:
        assert n not in seen, ('unexpected cycle',z,n)
        seen.add(n)
        a+=n%2
        n=T(n)
        j+=1
        assert j<5000, ('iteration limit',z)
    return a,j


def ratio_check():
    maxp,maxq,where=0,1,0
    path=Path(__file__).with_name('odd_tails_3_to_89393.csv')
    assert path.exists(), 'provided prior certificate needed'
    digest=hashlib.sha256()
    with path.open(newline='') as file:
        rows=csv.DictReader(file)
        cnt=0
        for row in rows:
            z=int(row['odd_start'])
            a=int(row['odd_inputs_to_1']);j=int(row['accelerated_steps_to_1'])
            assert z==2*cnt+3
            assert (a,j)==direct(z),('row mismatch',z)
            digest.update(f'{z},{a},{j}\n'.encode())
            rp=1<<j;rq=z*3**a
            if rp*maxq>maxp*rq:
                maxp,maxq,where=rp,rq,z
            cnt+=1
        assert cnt==44696
    assert digest.hexdigest()=='7714245d32255a50f21a19e50db9528f05b2364214fad5bb81ec2c58c8607994'
    assert Fraction(maxp,maxq)==Fraction(P,Q) and where==993
    return cnt,digest.hexdigest()


def exact_threshold():
    # With R=ceil(b/2), our sufficient condition for P_j(m)<3 is
    #      (S/D)^9 * (X+1+6R)/(X+1) < 3^9 .
    E=(X+1)*((3*D)**9-S**9)
    F=6*S**9
    R=(E-1)//F # largest integer R satisfying F*R<E
    assert F*R < E <= F*(R+1)
    assert R == 38464724
    bmax=2*R
    assert bmax==76929448
    return R,bmax,bmax+1,bmax+2


def bounded_orbit_sanity():
    # Independent finite sanity check of the new upper bound on real trajectories.
    count=0
    for n in range(3,1001):
        x=n; a=0; N=1; Z=1; visited=set()
        for j in range(125):
            if x==1: break
            assert x not in visited
            visited.add(x)
            if x & 1:
                a+=1
                N*=3*x+1
                Z*=3*x
            x=T(x)
            if x>=3:
                # P^9 <= (S/D)^9 * (X+1+6*ceil(a/2))/(X+1)
                assert N**9 * D**9*(X+1) < Z**9*S**9*(X+1+6*((a+1)//2)),(n,j,a)
                count+=1
    return count


def main():
    count,digest=ratio_check()
    R,bmax,bmin,amin=exact_threshold()
    controls=bounded_orbit_sanity()
    cert={
      'cutoff_X':X,'finite_certificate_rows_replayed':count,'csv_body_sha256':digest,
      'tail_F_numerator':P,'tail_F_denominator':Q,
      'exception_factor_numerator':3*(X+2)+1,
      'exception_factor_denominator':3*(X+2),
      'R_max':R,'excluded_lower_count_b_through':bmax,
      'necessary_smaller_partner_b_at_least':bmin,
      'necessary_larger_origin_a_at_least':amin,
      'finite_orbit_controls':controls,
      'scope':'m<n, common endpoint >=3, m known to converge to 1, A_j(m)<A_j(n)',
      'no_universal_collatz_claim':True,
      'no_new_density_coverage':True
    }
    Path(__file__).with_name('new_mod3_tail_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    print(json.dumps(cert,indent=2))

if __name__=='__main__':main()
