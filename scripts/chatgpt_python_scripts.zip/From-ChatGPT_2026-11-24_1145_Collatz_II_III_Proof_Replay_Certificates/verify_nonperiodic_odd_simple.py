#!/usr/bin/env python3
"""Independent, bounded integer-only verification of a nonperiodic coalescence
necessary condition.  Does not search for or assert a Collatz counterexample.
"""
import hashlib
import json
from fractions import Fraction
from pathlib import Path

X = 89393
assert X % 6 == 5


def T(n):
    return (3*n+1)//2 if n & 1 else n//2


def verify_small_odd_reach_one():
    # Deliberately recompute every trajectory from scratch, without memoization.
    # It is a finite calculation.  The cap is a safety guard, not a theorem.
    count = 0
    max_time = 0
    max_peak = 0
    for z in range(3, X+1, 2):
        n = z
        t = 0
        peak = z
        while n != 1 and t < 3000:
            n = T(n)
            peak = max(n, peak)
            t += 1
        assert n == 1, (z, t)
        count += 1
        max_time = max(t, max_time)
        max_peak = max(peak, max_peak)
    assert count == (X-1)//2
    return count, max_time, max_peak


def exact_boundary(x):
    # Choose the smallest permissible exceptional multiple of 3 (x+4).
    assert x % 6 == 5
    S = 3*(x+4)+1
    D = 3*(x+4)
    numerator = (x+1)*((3*D)**9 - S**9)
    denominator = 6*S**9
    Rmax = (numerator-1)//denominator
    assert denominator * Rmax < numerator
    assert denominator * (Rmax+1) >= numerator
    return {'X':x, 'exception_factor':f'{S}/{D}',
            'max_excludable_R':Rmax, 'min_smaller_odd_count_b':2*Rmax+1,
            'min_larger_odd_count_a':2*Rmax+2,
            'strict_boundary_slack': str(numerator-denominator*Rmax),
            'next_boundary_gap': str(denominator*(Rmax+1)-numerator)}


def finite_prefix_checks():
    # Independently verify P^9 <= C^9 * (1 + 6 ceil(b/2)/(X+1))
    # for finite actual prefixes consisting only of odd inputs >X.
    C = Fraction(3*(X+4)+1,3*(X+4))
    counts = 0
    sample_starts = [X+1, X+2, X+4, X+100, X+12345, 2*X+19]
    sample_starts += [X+1+k*19 for k in range(1,1001)]
    for start in sample_starts:
        n = start
        seen_odd = set()
        P = Fraction(1,1)
        b = 0
        for j in range(1,121):
            if n % 2:
                if n <= X or n in seen_odd:
                    break
                seen_odd.add(n)
                P *= Fraction(3*n+1,3*n)
                b += 1
            n = T(n)
            right = C**9 * Fraction(X+1+6*((b+1)//2), X+1)
            assert P**9 <= right, (start,j,b)
            counts += 1
    return counts


def main():
    # The published 44,696-row certificate also has its body hash verified.
    csv_path = Path(__file__).with_name('odd_tails_3_to_89393.csv')
    if csv_path.exists():
        body = csv_path.read_bytes().split(b'\n',1)[1]
        digest = hashlib.sha256(body).hexdigest()
        assert digest == '7714245d32255a50f21a19e50db9528f05b2364214fad5bb81ec2c58c8607994'
    small, mt, peak = verify_small_odd_reach_one()
    checks=finite_prefix_checks()
    main_bound=exact_boundary(X)
    M=2075*(2**60)
    conditional_bound=exact_boundary(M-3)
    result={'finite_odd_starts_converged':small,
            'max_accelerated_steps_to_one':mt,'largest_visited':peak,
            'valid_prefix_inequality_controls':checks,
            'unconditional_bound':main_bound,
            'conditional_M_based_bound':conditional_bound,
            'conditional_M_value':M,
            'note':'M corollary assumes independently certified convergence for EVERY start 1<=n<M; not verified by this script'}
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__': main()
