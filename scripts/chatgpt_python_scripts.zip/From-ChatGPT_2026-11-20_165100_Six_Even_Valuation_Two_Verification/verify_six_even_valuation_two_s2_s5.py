from itertools import combinations
from functools import lru_cache

def words(e,r):
 n=e+r
 for odd in combinations(range(n),r):
  v=sum(2**p*3**(r-1-j) for j,p in enumerate(odd))
  yield odd,v

def direct(e,y,r):
 n=e+r
 candidates=[]
 for odd,V in words(e,r):
  num=2**n*y-V
  if num<=0 or num%3**r:continue
  m=num//3**r; z=m; path=[]
  for _ in range(n):
   path.append(z&1)
   z=(3*z+1)//2 if z&1 else z//2
  if z==y and tuple(i for i,b in enumerate(path) if b)==odd:
   candidates.append((m,odd,V))
 return min(candidates,default=None)

@lru_cache(None)
def H(e,x,r):
 if r<0:return None
 a=0;t=x+1
 while t%3==0:a+=1;t//=3
 if e==0:return 2**r*(x+1)//3**r-1 if r<=a else None
 return min((v for l in range(min(a,r)+1) if (v:=H(e-1,2*(2**l*(x+1)//3**l-1),r-l)) is not None),default=None)

def branch(q,s):
 return [H(5,18*q-2,s),H(5,12*q-2,s-1),H(5,8*q-2,s-2)]

# Explicit residue tables at s=2,3,4. The 3-adic integrality
# depends only on q modulo 3^(s-2), and origins shift linearly.
for q in range(1,10):
 if q%3==0:continue
 for s in (2,3,4):
  actual=branch(q,s)
  expected=[direct(5,18*q-2,s),direct(5,12*q-2,s-1),direct(5,8*q-2,s-2)]
  assert [None if z is None else z[0] for z in expected]==actual,(q,s,expected,actual)

# Exhaustive certificate for the affine residue shift q -> q+9
# (all three branches at s<=4 have fixed numerator congruences).
for q in range(1,10):
 if q%3==0:continue
 for s in (2,3,4):
  a=branch(q,s)
  for t in (1,2,3,10,100):
   b=branch(q+9*t,s)
   scale=2**(5+s)*18*9//3**s # short branch shift per 9 (same for all)
   assert 2**(5+s)*18*9%3**s==0
   assert b==[None if z is None else z+t*scale for z in a],(q,s,t,a,b)

# Entire family: first three transitions are strictly decreasing.
for q in range(1,2001):
 if q%3==0:continue
 m=[min((z for z in branch(q,s) if z is not None),default=None) for s in (2,3,4)]
 assert all(z is not None for z in m)
 assert m[0]>m[1]>m[2],(q,m)

print('PASS: exhaustive parity-word minima at residues q=1,2,4,5,7,8;')
print('PASS: affine shift certificate q -> q+9t at s=2,3,4;')
print('PASS: strict monotonicity s=2->3->4 for 1334 q<=2000.')
for q in (1,2,4,5,7,8):
 print('q mod 9',q,'s3',branch(q,3),'s4',branch(q,4))
# All s=5 residue classes modulo 27: direct exact parity-word certificates.
for q in range(1,28):
 if q%3==0:continue
 actual=branch(q,5)
 expected=[direct(5,18*q-2,5),direct(5,12*q-2,4),direct(5,8*q-2,3)]
 assert [None if z is None else z[0] for z in expected]==actual,(q,5,expected,actual)
 for t in (1,2,10):
  b=branch(q+27*t,5)
  shift=2**10*18*27//3**5
  assert b==[None if z is None else z+t*shift for z in actual],(q,t,actual,b)
 old=min(z for z in branch(q,4) if z is not None)
 new=min(z for z in actual if z is not None)
 assert old>new,(q,old,new)
 print('q mod27',q,'s5',actual,'winner','SMB'[actual.index(new)],'drop s4->s5',old-new)
print('PASS: all 18 residue classes at s=5, exact origin words and positive s4->s5 gaps.')
