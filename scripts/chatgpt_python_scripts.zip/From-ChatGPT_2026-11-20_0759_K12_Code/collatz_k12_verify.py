"""Exact k=12 zero-tail affine verification, no external packages."""

def T(x): return x//2 if x%2==0 else (3*x+1)//2

def family(k,s):
    r=2
    while 3**(r+s)<=2**(r+2*s+k+1): r+=1
    q=3**(r+s); p=2**(r+2*s+k+1)
    U=q+p//(2**k)-2**r*3**(s+1)
    rho=U*pow(p,-1,q)%q
    return r,q,p,U,rho

for s in range(1,11):
    r,q,p,U,rho=family(12,s)
    assert rho%9==1
    assert rho%81==(46 if s==1 else 64 if s==2 else 37)
    for t in range(3):
        n=rho+q*t
        if n==0: continue
        assert (p*n-U)%q==0
        m=(p*n-U)//q
        assert 0<m<n
        word='1'*r+'01'*s+'0'*13
        x=m
        for bit in word:
            assert x%2==int(bit)
            x=T(x)
        assert x==n
    print(s,r,rho,q,'verified')
# k12,s1 not contained in C114,s2 (different residues mod C114 modulus)
q=family(6,2)[1]
assert family(12,1)[4]%q != family(6,2)[4]%q
print('30 trajectories and C114 overlap check passed')
