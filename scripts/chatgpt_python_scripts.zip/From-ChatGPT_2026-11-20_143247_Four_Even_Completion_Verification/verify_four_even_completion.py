from functools import lru_cache
from collections import Counter

def v3(n):
 k=0
 while n%3==0: n//=3;k+=1
 return k
@lru_cache(None)
def L(e,x,r):
 if r<0:return None
 a=v3(x+1)
 if e==0:return 2**r*((x+1)//3**r)-1 if r<=a else None
 vals=[]
 for l in range(min(a,r)+1):
  y=2*(2**l*((x+1)//3**l)-1)
  v=L(e-1,y,r-l)
  if v is not None:vals.append(v)
 return min(vals,default=None)

stats=Counter()
for u in range(1,10001):
 if u%3!=1:continue
 C=4*u-1;c=v3(C);v=C//3**c;G=2**(c+1)*v-1
 A=6*u-2;B=4*u-2
 for r in range(1,c+2):
  p=L(3,A,r);q=L(3,B,r-1)
  assert p is not None and q is not None and p-q==4,(u,r,p,q)
  stats['early']+=1
 p=L(3,A,c+2);q=L(3,B,c+1)
 if G%3==0:
  assert p is None and q is not None,(u,G,p,q)
  stats['G_divisible']+=1
 else:
  H=2*G+1;J=4*G-1
  assert p==4*H//3-2 and q==2*J//3-1 and p-q==1,(u,G,p,q)
  stats['late_gap_one']+=1
  h=v3(H);j=v3(J)
  assert min(h,j)==1
  pnext=L(3,A,c+3);qnext=L(3,B,c+2)
  if h>=2:
   assert j==1 and qnext is None and pnext==8*H//9-2
   assert q-pnext==(8*G-5)//9 and q>pnext,(u,G,q,pnext)
   stats['takeover_proved']+=1
  elif j>=2:
   assert h==1 and pnext is None and qnext is not None
   stats['P_ends']+=1
  else:
   assert qnext is None
   if pnext is not None:
    assert pnext==(8*H-15)//9
    assert q-pnext==8*(G-1)//9 and q>pnext,(u,G,q,pnext)
    stats['takeover_h1']+=1
   else: stats['both_end']+=1
 # Global monotonicity for e4
 x=3*u-1
 arr=[]
 for r in range(50):
  m=L(4,x,r)
  if m is None:break
  arr.append(m)
 assert all(arr[i]>arr[i+1] for i in range(len(arr)-1)),(u,arr)
 stats['global_series']+=1
print(dict(stats))
