#!/usr/bin/env python3
"""Exact arithmetic and status-partition controls for five incoming notes.

This is not a replay of the unavailable restoration packet or compiled
certificates, and it does not prove the unresolved central aggregate bound.
"""
from decimal import Decimal, localcontext
from fractions import Fraction as F
import json
from pathlib import Path


def decimal_text(value):
    with localcontext() as context:
        context.prec = 70
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def show(value):
    return {"exact": str(value), "decimal": decimal_text(value)}


def main():
    if not __debug__:
        raise RuntimeError("Run without -O; assertions are part of this verifier.")
    c8 = F(7618091890243831687161, 272394937772592332800000)
    tail = F(33, 1048576)
    repeated = F(3, 2621440)
    paid = c8 + tail + repeated
    rounded_paid = F(7, 250)
    margin = rounded_paid - paid
    assert paid == F(7626976231361521447161, 272394937772592332800000)
    assert margin == F(82026271063871239, 272394937772592332800000)
    assert F(301, 10**9) < margin < F(302, 10**9)
    assert margin > 300 * F(1, 10**9)
    ystar = F(116073, 3904000)
    previous_residual = ystar - rounded_paid
    assert rounded_paid == F(109312, 3904000)
    assert previous_residual == F(6761, 3904000)

    alpha = F(4899, 3904)
    cstar = F(620751769493359576, 1180591620717411303425)
    n0 = 2**71 + 1
    xi = cstar * (2 - 4 * alpha / 3 + alpha / (3 * n0))
    early = F(557, 10**6)
    late = F(149, 10**9)
    old_allowance = previous_residual - early - xi - late
    new_allowance = ystar - paid - early - xi - late
    assert new_allowance - old_allowance == margin
    assert F(1002, 10**6) < old_allowance < F(1003, 10**6)
    assert F(1003, 10**6) < new_allowance
    assert new_allowance < F(1004, 10**6)

    # Hypothetical accounting data, not a Collatz profile: S_cov uses
    # actual whole-envelope payments U, not the larger rounded ceiling.
    actual_u = paid / 2
    covered_positive = actual_u / 3
    coverage_surplus = actual_u - covered_positive
    remaining_signed = F(1, 1000)  # already includes all retained credits
    exact_total = actual_u + early + late + xi + remaining_signed
    assert actual_u - coverage_surplus == covered_positive
    assert exact_total <= paid + early + late + xi + remaining_signed
    assert paid + early + late + xi + F(1003, 10**6) < ystar

    first_present = {5, 6, 7, 8, 9, 10, 12}
    later_present = {13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24,
                     28, 29, 30, 31, 33}
    partial = {4, 25, 26, 32}
    undecided = {11, 16, 27}
    groups = [first_present, later_present, partial, undecided]
    for i, group in enumerate(groups):
        for other in groups[i + 1:]:
            assert group.isdisjoint(other)
    assert set.union(*groups) == set(range(4, 34))
    assert len(first_present | later_present) == 23
    report = {
        "status": "PASS",
        "scope": "Exact arithmetic and reported ledger-row partition only; no unavailable manuscript or compiled-certificate replay.",
        "C8": show(c8),
        "unrounded_group_tail_repetition_ceiling": show(paid),
        "margin_below_7_over_250": show(margin),
        "previous_residual": show(previous_residual),
        "source_selection_allowance_xi": show(xi),
        "old_after_late_allowance": show(old_allowance),
        "new_after_late_allowance": show(new_allowance),
        "new_margin_above_1003_over_1e6": show(new_allowance-F(1003, 10**6)),
        "same_sufficient_target_now_available": "R <= 1003/1000000",
        "scope_of_combined_budget": "2^71 <= n < 2^272; all original group, tail, source-family and credit hypotheses unchanged.",
        "actual_aggregate_target_proved": False,
        "reported_statement_comparison": {
            "present_among_R04_R33": sorted(first_present | later_present),
            "partial": sorted(partial),
            "undecided_reported": sorted(undecided),
            "proof_audit_claimed_by_Claude": False,
        },
    }
    output = Path(__file__).with_name("five_note_arithmetic.json")
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
