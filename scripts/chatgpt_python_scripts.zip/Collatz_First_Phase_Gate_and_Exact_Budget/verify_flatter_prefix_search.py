#!/usr/bin/env python3
"""Targeted exact search using proper-height prefixes with ceilings15/16,99/100.

This checks at most131072new starts. It stops after the first FULL original-core
lateR fixture, if any. It is not an unrestricted family exclusion.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
from verify_near_miss import source_count


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def prefix(depth,num,den):
    E=C=0;word=[];times=[0];nums=[0];threes=[1]
    for i in range(1,depth+1):
        newE=((num*3**i)//den).bit_length()-1
        word.append(newE-E);C=3*C+2**E;E=newE
        times.append(E);nums.append(C);threes.append(3**i)
    M=2**(E+1);a=(2**E-C)*pow(3**depth,-1,M)%M
    assert all(e in (1,2) for e in word)
    assert all(den*2**times[i]<num*threes[i] for i in range(1,depth+1))
    assert a%2
    return word,times,nums,threes,M,a


def full_core(n,u,word,states,times,nums,threes):
    H=(4*n-2)//3;W=H-n;E=times[-1];N=len(word);Q=F(nums[-1],threes[-1])
    shortcut=[u]
    for e in word:
        x=(3*shortcut[-1]+1)//2;shortcut.append(x)
        for _ in range(e-1):assert x%2==0;x//=2;shortcut.append(x)
        assert x%2
    assert shortcut[-1]==states[-1] and len(shortcut)-1==E
    assert len(set(shortcut[:-1]))==E
    modulus=2**(E+1);a=(2**E-nums[-1])*pow(3**N,-1,modulus)%modulus
    lo=max(n,-((-(2**E*n-nums[-1]))//3**N));hi=min(H,(2**E*H-nums[-1])//3**N)
    for i in range(1,N):lo=max(lo,(2**times[i]*H-nums[i])//threes[i]+1)
    assert lo+(a-lo)%modulus==u<=hi
    Pstar,bandwidth,ordered=source_count(n);B=5+F(n,100000*Pstar)
    kappa=F(n-1,n+1);L=n.bit_length()-1;m=n.bit_length()
    boundaries=[];start=0
    for end,e in enumerate(word,1):
        if e>=2:boundaries.append((start,end,e));start=end
    assert start==N
    runs=[];core=[];lateR=[]
    for k,(i,j,e) in enumerate(boundaries):
        a,b=states[i],states[j];s=j-i;q=F(nums[i],threes[i]);qend=F(nums[j],threes[j])
        delta=(1-F(2,3)**s)/a;flux=F(1,a)-F(1,b);signed=kappa*delta+flux
        credit=max(F(0),-flux-delta/15);ell=a.bit_length()-1;t=ell-L
        J=2**ell//(2000*Pstar*(t+1)*(t+2));canonical=times[i]+ell
        flags={'proper_height':i>0 and H<a<2**(64*m),'canonical_interior':canonical<E,
               'canonical_endpoint':canonical<len(shortcut) and 64*shortcut[canonical]>a,
               'incoming_phase':q>B,'remaining_phase':Q-q>B,
               'earlier_resets':k>J,'remaining_resets':len(boundaries)-k>J}
        selected=all(flags.values());late=2**(times[i]+1)>2*W
        if selected:core.append(k)
        if selected and late and s==e==2:lateR.append(k)
        runs.append({'run':k,'odd_start':i,'odd_end':j,'a':str(a),'b':str(b),'s':s,'e':e,
                     'time':times[i],'q':q,'remaining_phase':Q-q,'delta':delta,'flux':flux,'signed_t':signed,'credit':credit,
                     'J':J,'canonical_end':canonical,'flags':flags,'core':selected,'late':late})
    Z=sum((r['signed_t'] if r['core'] else -r['credit'] for r in runs),F(0))
    return {'n':str(n),'H':str(H),'W':str(W),'u':str(u),'w':str(states[-1]),'word':word,'odd_transitions':N,'E':E,
            'Pstar':str(Pstar),'bandwidth_bound':str(bandwidth),'ordered_bound':str(ordered),'B':B,'Q':Q,
            'core_run_indices':core,'late_R_core_run_indices':lateR,'all_runs':runs,'signed_profile_score':Z,
            'least_source_verified':True}


def main():
    import sys
    if not __debug__:raise RuntimeError('Run without -O.')
    if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(20000)
    folder=Path(__file__).resolve().parent
    saved=json.loads((folder/'near_miss_input.json').read_text())
    n0,u0=int(saved['n']),int(saved['u']);word0=saved['word']
    states0,times0,nums0,threes0=[u0],[0],[0],[1]
    E0=C0=0
    for i,e0 in enumerate(word0,1):
        assert (3*states0[-1]+1)%(2**e0)==0
        states0.append((3*states0[-1]+1)//2**e0)
        C0=3*C0+2**E0;E0+=e0
        times0.append(E0);nums0.append(C0);threes0.append(3**i)
    control=full_core(n0,u0,word0,states0,times0,nums0,threes0)
    assert control['Pstar']=='8780738570161207464047659560356896525'
    assert len(control['core_run_indices'])==31 and control['late_R_core_run_indices']==[]
    near=next(r for r in control['all_runs'] if r['odd_start']==87)
    assert [k for k,v in near['flags'].items() if not v]==['canonical_interior']
    begin=time.monotonic();digest=hashlib.sha256();ranges=[];profiles=[];found=None
    totals={'tested':0,'band_returns':0,'length_guard_hits':0,'late_R_starts':0,'phase5_passes':0,'canonical_horizon_passes':0,'joint_necessary_passes':0,'actual_late_core_R':0}
    for num,den,depth in [(15,16,80),(99,100,80),(15,16,96),(99,100,96)]:
        w0,t0,c0,p0,M,residue=prefix(depth,num,den);stats={key:0 for key in totals};last_lift=-1
        for lift in range(32768):
            if time.monotonic()-begin>110:raise RuntimeError('110-second guard reached; not a complete diagnostic.')
            last_lift=lift;u=residue+lift*M;n=(3*u+5)//4
            if n%2==0:n+=1
            H=(4*n-2)//3;W=H-n
            assert n>=2**71 and n%2 and n<=u<=H
            states=[(p0[i]*u+c0[i])//2**t0[i] for i in range(depth+1)]
            assert all(x>H for x in states[1:])
            for i,e in enumerate(w0):assert states[i]%2 and states[i+1]%2 and 3*states[i]+1==2**e*states[i+1]
            word=list(w0);times=list(t0);nums=list(c0);threes=list(p0)
            x,E,C,power3=states[-1],times[-1],nums[-1],threes[-1];stats['tested']+=1
            for _ in range(700):
                y=3*x+1;e=(y&-y).bit_length()-1;x=y>>e
                C=3*C+2**E;E+=e;power3*=3
                word.append(e);times.append(E);nums.append(C);threes.append(power3);states.append(x)
                if x<=H:break
            else:stats['length_guard_hits']+=1;continue
            digest.update(f'{num}/{den}:{depth}:{lift}:{x}:{E}:{len(word)}\n'.encode())
            if x<n:continue
            stats['band_returns']+=1;start=0;necessary=[]
            for end,e in enumerate(word,1):
                if e<2:continue
                if end-start==e==2 and 2**(times[start]+1)>2*W:
                    stats['late_R_starts']+=1
                    phase=(nums[start]>5*threes[start] and C-nums[start]*3**(len(word)-start)>5*power3)
                    horizon=times[start]+states[start].bit_length()-1<E
                    stats['phase5_passes']+=phase;stats['canonical_horizon_passes']+=horizon
                    if phase and horizon:stats['joint_necessary_passes']+=1;necessary.append(start)
                start=end
            if necessary:
                profile=full_core(n,u,word,states,times,nums,threes)
                profile['discovery']={'ceiling_num':num,'ceiling_den':den,'prefix_depth':depth,'lift':lift,'relaxed_necessary_starts':necessary}
                profiles.append(profile)
                stats['actual_late_core_R']+=len(profile['late_R_core_run_indices'])
                if profile['late_R_core_run_indices']:found=profile;break
        for key in totals:totals[key]+=stats[key]
        ranges.append({'ceiling':f'{num}/{den}','depth':depth,'E':t0[-1],'modulus':str(M),'residue':str(residue),'first_lift':0,'last_lift_inclusive':last_lift,'counts':stats})
        if found:break
    result={'status':'PASS','scope':'Bounded targeted discovery; finite tested ranges only. Original core checked on every joint necessary candidate.',
            'ranges':ranges,'totals':totals,'found_actual_late_core':found is not None,
            'completion_digest_sha256':digest.hexdigest(),'joint_candidate_profiles':profiles,
            'saved_near_miss_control':{'core_runs':31,'late_R_core_runs':0,'only_failed_gate':'canonical_interior'}}
    folder=Path(__file__).resolve().parent
    (folder/'flatter_prefix_search_certificate.json').write_text(json.dumps(encode(result),indent=2)+'\n')
    if found:(folder/'actual_late_core_fixture.json').write_text(json.dumps(encode(found),indent=2)+'\n')
    print(json.dumps({'status':'PASS','totals':totals,'found_actual_late_core':found is not None,'ranges':ranges,'elapsed_seconds':time.monotonic()-begin},indent=2))


if __name__=='__main__':main()
