#!/usr/bin/env python3
"""Exact bounded diagnostic of three new forced-prefix continuation families.

All arithmetic affecting the acceptance test is integral. A selected original
R core must pass the weaker B=5 phase gate and the canonical horizon. This
checks those necessary conditions only, not their sufficiency. The finite
source ranges are not asserted to exhaust any unrestricted family.
"""
from pathlib import Path
import hashlib
import json
import time


def prefix(depth):
    E = C = 0
    word, times, nums, threes = [], [0], [0], [1]
    for i in range(1, depth + 1):
        new_E = (3**(i + 1)).bit_length() - 3
        word.append(new_E-E)
        C = 3*C + 2**E
        E = new_E
        times.append(E); nums.append(C); threes.append(3**i)
    M = 2**(E+1)
    residue = ((2**E-C)*pow(3**depth, -1, M)) % M
    assert all(e in (1, 2) for e in word)
    assert all(4*2**times[i] < 3*threes[i] for i in range(1, depth+1))
    assert residue % 2
    return word, times, nums, threes, M, residue


def main():
    if not __debug__:
        raise RuntimeError('Run without -O.')
    started = time.monotonic()
    totals = {'tested':0, 'band_return_candidates':0,
              'below_band_endpoints':0, 'length_guard_hits':0,
              'late_R_starts':0, 'late_R_phase5_passes':0,
              'late_R_canonical_horizon_passes':0,
              'late_R_joint_necessary_passes':0}
    ranges = []
    digest = hashlib.sha256()
    examples = []
    phase_only_examples = []
    for depth in (64,80,96):
        word0, times0, nums0, threes0, M, residue = prefix(depth)
        subtotal = {key:0 for key in totals}
        for lift in range(65536):
            if time.monotonic()-started > 110:
                raise RuntimeError('110-second process guard reached; result incomplete.')
            u = residue + lift*M
            n = (3*u+5)//4
            if n % 2 == 0:
                n += 1
            H = (4*n-2)//3
            W = H-n
            assert n >= 2**71 and n % 2 and n <= u <= H
            states = [(threes0[i]*u+nums0[i])//2**times0[i]
                      for i in range(depth+1)]
            assert all(x > H for x in states[1:])
            # Check the entire prescribed prefix's actual valuations too.
            for i,e in enumerate(word0):
                assert states[i] % 2 and states[i+1] % 2
                assert 3*states[i]+1 == 2**e*states[i+1]
            word, times = list(word0), list(times0)
            nums, threes = list(nums0), list(threes0)
            x, E, C, power3 = states[-1],times[-1],nums[-1],threes[-1]
            subtotal['tested'] += 1
            for _ in range(700):
                y=3*x+1
                e=(y & -y).bit_length()-1
                x=y >> e
                C=3*C+2**E;E+=e;power3*=3
                word.append(e);times.append(E);nums.append(C);threes.append(power3);states.append(x)
                if x <= H:
                    break
            else:
                subtotal['length_guard_hits'] += 1
                continue
            digest.update(f'{depth}:{lift}:{x}:{E}:{len(word)}\n'.encode())
            if x < n:
                subtotal['below_band_endpoints'] += 1
                continue
            subtotal['band_return_candidates'] += 1
            start = 0
            for end,e in enumerate(word,1):
                if e < 2:
                    continue
                s = end-start
                if s == e == 2 and 2**(times[start]+1) > 2*W:
                    subtotal['late_R_starts'] += 1
                    phase = (nums[start] > 5*threes[start]
                             and C-nums[start]*3**(len(word)-start) > 5*power3)
                    horizon = times[start] + states[start].bit_length()-1 < E
                    subtotal['late_R_phase5_passes'] += phase
                    subtotal['late_R_canonical_horizon_passes'] += horizon
                    if phase and not horizon:
                        phase_only_examples.append({'n':str(n),'u':str(u),'w':str(x),'word':word,'R_start':start,'prefix_depth':depth,'lift':lift,
                            'R_height':str(states[start]),'R_prefix_E':times[start],'canonical_length':states[start].bit_length()-1,'final_E':E,
                            'incoming_phase':str(nums[start])+'/'+str(threes[start]),'remaining_phase':str(C-nums[start]*3**(len(word)-start))+'/'+str(power3)})
                    if phase and horizon:
                        subtotal['late_R_joint_necessary_passes'] += 1
                        examples.append({'n':str(n),'u':str(u),'word':word,'R_start':start,'prefix_depth':depth,'lift':lift})
                start=end
            assert start == len(word)
        for key in totals:
            totals[key] += subtotal[key]
        ranges.append({'prefix_depth':depth,'prefix_E':times0[-1],
                       'residue':str(residue),'modulus':str(M),
                       'first_lift':0,'last_lift_inclusive':65535,
                       'counts':subtotal})
    assert totals['tested'] == 196608
    assert totals['length_guard_hits'] == 0
    assert totals['band_return_candidates'] == 52015
    assert totals['late_R_joint_necessary_passes'] == 0
    report={'status':'PASS','scope':'Finite necessary-condition diagnostic only; no unrestricted exclusion or aggregate theorem.',
            'ranges':ranges,'totals':totals,'completion_digest_sha256':digest.hexdigest(),
            'joint_necessary_candidates':examples,
            'phase_only_near_misses':phase_only_examples,
            'Pstar_handling':'Original B=5+n/(100000 Pstar)>5; failure at relaxed B=5 suffices to reject the occurrence. Pstar is not recomputed or replaced.',
            'core_predicates_not_used':'Reset windows, canonical endpoint height, full height ceiling, and least-source eligibility are unnecessary for this negative test and are not asserted verified.'}
    path=Path(__file__).with_name('late_core_search_certificate.json')
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
