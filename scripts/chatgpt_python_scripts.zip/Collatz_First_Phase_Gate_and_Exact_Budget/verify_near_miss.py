#!/usr/bin/env python3
"""Exact original-core audit of the late-R canonical-boundary near-miss.

The Pstar recurrence is the existing prescribed bandwidth/ordered source
bound. This verifier reproduces it; it does not replace it by a chosen count.
"""
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import json
import sys


def v2(x):
    return (x & -x).bit_length()-1


def source_count(n):
    H=(4*n-2)//3
    width_depth=(H-n).bit_length()
    row={2:1};short=0
    for depth in range(3,width_depth+1):
        short += sum(count for odds,count in row.items()
                     if (3*n-width_depth)*2**depth < 3*H*3**odds
                     and n*3**odds < H*2**depth)
        nxt=defaultdict(int)
        for odds,count in row.items():
            for bit in (0,1):
                r=odds+bit
                if 2**depth*n**r < (3*n+1)**r:
                    nxt[r] += count
        row=dict(nxt)
    bandwidth=short+sum(row.values())
    row={2:1}
    for depth in range(3,H.bit_length()+1):
        nxt=defaultdict(int)
        for odds,count in row.items():
            for bit in (0,1):
                r=odds+bit
                if 3**r > 2**(depth-1):
                    nxt[r] += count
        row=dict(nxt)
    ordered=2*sum(row.values())
    return min(bandwidth,ordered),bandwidth,ordered


def dec(x):
    with localcontext() as c:
        c.prec=32
        return str(Decimal(x.numerator)/Decimal(x.denominator))


def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x


def main():
    if not __debug__:raise RuntimeError('Run without -O.')
    if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(20000)
    folder=Path(__file__).resolve().parent
    data=json.loads((folder/'near_miss_input.json').read_text())
    n,u=int(data['n']),int(data['u']);word=data['word']
    H=(4*n-2)//3;W=H-n;L=n.bit_length()-1;m=n.bit_length()
    assert n>=2**71 and n%2 and n<=u<=H and u%2
    states,shortcut,times,nums,powers=[u],[u],[0],[0],[1]
    E=C=0
    for j,e in enumerate(word,1):
        a=states[-1];assert e==v2(3*a+1)
        x=(3*a+1)//2;shortcut.append(x)
        for _ in range(e-1):assert x%2==0;x//=2;shortcut.append(x)
        assert x%2
        C=3*C+2**E;E+=e
        states.append(x);times.append(E);nums.append(C);powers.append(3**j)
        assert 2**E*x==3**j*u+C
    N=len(word);w=states[-1];Q=F(C,powers[-1])
    assert n<=w<=H and all(x>H for x in states[1:-1])
    assert len(set(shortcut[:-1]))==len(shortcut)-1
    assert len(shortcut)-1==E
    modulus=2**(E+1);residue=((2**E-C)*pow(3**N,-1,modulus))%modulus
    assert u==residue and modulus>W
    # Exact least-source clipping, including every proper high state.
    lo=max(n,-((-(2**E*n-C))//3**N))
    hi=min(H,(2**E*H-C)//3**N)
    for j in range(1,N):lo=max(lo,(2**times[j]*H-nums[j])//powers[j]+1)
    assert lo+(residue-lo)%modulus==u<=hi
    Pstar,bandwidth,ordered=source_count(n)
    assert Pstar==8780738570161207464047659560356896525
    B=5+F(n,100000*Pstar);kappa=F(n-1,n+1)
    starts=[];start=0
    for end,e in enumerate(word,1):
        if e>=2:starts.append((start,end,e));start=end
    assert start==N
    runs=[];core=[]
    for k,(i,end,e) in enumerate(starts):
        a,b=states[i],states[end];s=end-i
        q=F(nums[i],powers[i]);qend=F(nums[end],powers[end])
        beta=1-F(2,3)**s;delta=beta/a;flux=F(1,a)-F(1,b)
        signed=kappa*delta+flux;credit=max(F(0),-flux-delta/15)
        assert qend-q==(u+q)*delta and s==v2(a+1)
        ell=a.bit_length()-1;t=ell-L;J=2**ell//(2000*Pstar*(t+1)*(t+2))
        endpoint=times[i]+ell
        flags={'proper_height':i>0 and H<a<2**(64*m),
               'canonical_strictly_interior':endpoint<E,
               'canonical_endpoint_height':endpoint<len(shortcut) and 64*shortcut[endpoint]>a,
               'incoming_phase':q>B,'remaining_phase':Q-q>B,
               'earlier_resets':k>J,'remaining_resets':len(starts)-k>J}
        selected=all(flags.values())
        if selected:core.append(k)
        runs.append({'run_index':k,'odd_start':i,'odd_end':end,'a':str(a),'b':str(b),'s':s,'e':e,
                     'prefix_E':times[i],'canonical_length':ell,'canonical_end':endpoint,
                     'J':J,'q':q,'remaining_phase':Q-q,'delta':delta,'flux':flux,
                     'signed_t':signed,'off_core_credit':credit,'core':selected,'flags':flags,
                     'modulus_gt_2W':2**(times[i]+1)>2*W})
    target=next(r for r in runs if r['odd_start']==data['R_start'])
    assert target['run_index']==48 and target['s']==target['e']==2
    assert target['modulus_gt_2W'] and target['signed_t']>0
    assert target['canonical_end']==E==276
    assert [key for key,value in target['flags'].items() if not value]==['canonical_strictly_interior']
    selected_late_R=[r['run_index'] for r in runs if r['core'] and r['s']==r['e']==2 and r['modulus_gt_2W']]
    assert selected_late_R==[]
    core_sum=sum((r['signed_t'] for r in runs if r['core']),F(0))
    credits=sum((r['off_core_credit'] for r in runs if not r['core']),F(0))
    Z=core_sum-credits
    # First complete-run phase gate, using the original B.
    gate_k=next(k for k,r in enumerate(runs)
                if r['q'] <= B < F(nums[r['odd_end']],powers[r['odd_end']]))
    gr=runs[gate_k];g=gr['odd_end'];y=states[g];q_after=F(nums[g],powers[g])
    omega=(H+B)/F(H+1)
    assert gr['q']<=B<q_after<B+omega and omega<2
    assert H+B+omega<2*(n+B)
    candidate_E=[]
    exponent=0
    while F(2**exponent*y,3**g)<=H+B+omega:
        if F(2**exponent*y,3**g)>n+B:
            candidate_E.append(exponent)
        exponent+=1
    assert candidate_E==[times[g]]==[47]
    affine=F(2**times[g]*y,3**g)
    lower=affine-B-omega;upper=affine-B
    integer_low=max(n,lower.numerator//lower.denominator+1)
    integer_high=min(H,-((-upper.numerator)//upper.denominator)-1)
    first_odd=integer_low+(1-integer_low)%2
    decoded=list(range(first_odd,integer_high+1,2))
    assert decoded==[u]
    gate={'run_index':gate_k,'g':g,'E':times[g],'y':str(y),'u':str(u),
          'previous_phase':gr['q'],'crossing_phase':q_after,'omega':omega,
          'possible_exponents':candidate_E,'decoded_odd_sources':[str(v) for v in decoded]}
    # The sole maximal off-core segment immediately before the first R core.
    first_core=core[0];assert runs[first_core]['s']==runs[first_core]['e']==2
    assert all(k not in core for k in range(first_core))
    a=int(runs[first_core]['a']);q=runs[first_core]['q'];allowance=F(2,3*a)
    suffix_controls=[]
    for k in range(first_core):
        X=int(runs[k]['a']);phase=runs[k]['q']
        lower=max(F(0),F(1,a)-F(1,X)-(q-phase)/(15*(u+phase)))
        exact=sum((r['off_core_credit'] for r in runs[k:first_core]),F(0))
        assert lower<=exact
        suffix_controls.append({'start_run':k,'lower':lower,'exact_credit':exact})
    whole=suffix_controls[0];best=max(suffix_controls,key=lambda row:row['lower'])
    assert whole['lower']==0 and best['start_run']==16 and best['lower']<allowance
    assert whole['exact_credit']>=allowance
    segment={'start_run':0,'end_run_exclusive':first_core,'target_R_run':first_core,
             'R_allowance_2_over_3a':allowance,'whole_endpoint_lower':whole['lower'],
             'whole_exact_retained_credit':whole['exact_credit'],
             'best_suffix_endpoint_lower':best['lower'],'best_suffix_start':best['start_run'],
             'suffix_controls':suffix_controls,
             'double_counting_caution':'These credits are already included in the original signed profile score.'}
    report={'status':'PASS','scope':'One genuine least-source completed profile; the proposed late positive R is excluded by strict canonical interiority.',
            'n':str(n),'H':str(H),'W':str(W),'u':str(u),'w':str(w),'odd_transitions':N,'shortcut_length':E,
            'Pstar':str(Pstar),'bandwidth_bound':str(bandwidth),'ordered_bound':str(ordered),'B':B,'B_decimal':dec(B),'Q':Q,
            'least_source_verified':True,'first_complete_run_phase_gate':gate,'preceding_offcore_segment':segment,'core_run_indices':core,'core_odd_starts':[runs[k]['odd_start'] for k in core],
            'selected_late_R':selected_late_R,'near_miss':target,
            'core_signed_sum':core_sum,'noncore_credit_sum':credits,'original_signed_profile_score':Z,
            'original_signed_profile_score_decimal':dec(Z),'all_runs':runs}
    (folder/'near_miss_certificate.json').write_text(json.dumps(enc(report),indent=2)+'\n')
    print(json.dumps(enc({k:report[k] for k in ['status','scope','n','u','w','odd_transitions','shortcut_length','Pstar','B_decimal','core_odd_starts','selected_late_R','original_signed_profile_score_decimal']}),indent=2))


if __name__=='__main__':main()
