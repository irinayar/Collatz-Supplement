#!/usr/bin/env python3
"""Replay exact first-gate, signed-ledger, and budget checks.

The default is fast. --full also replays the two explicitly bounded
discovery diagnostics. No test proves the uniform aggregate estimate.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def count_intersection(left, right):
    a, m = int(left["residue"]), int(left["modulus"])
    b, q = int(right["residue"]), int(right["modulus"])
    lo = max(a+left["first_lift"]*m, b+right["first_lift"]*q)
    hi = min(a+left["last_lift_inclusive"]*m,
             b+right["last_lift_inclusive"]*q)
    if lo > hi:
        return 0
    if m < q:
        a, b, m, q = b, a, q, m
    assert m % q == 0
    if (a-b) % q:
        return 0
    first = a + (-((a-lo)//m))*m
    return max(0, 1+(hi-first)//m)


def check_search_union(root):
    one = json.loads((root/"fixture"/"late_core_search_certificate.json").read_text())
    two = json.loads((root/"fixture"/"flatter_prefix_search_certificate.json").read_text())
    rows = one["ranges"]+two["ranges"]
    assert len(rows) == 7
    intersections = []
    for i, left in enumerate(rows):
        for j in range(i+1, len(rows)):
            size = count_intersection(left, rows[j])
            intersections.append({"left": i, "right": j, "intersection": size})
            assert size == 0, (i, j, size)
    total = sum(row["last_lift_inclusive"]-row["first_lift"]+1 for row in rows)
    assert total == 327680
    report = {
        "status": "PASS",
        "scope": "Exact intersection counts of the seven specified finite source progressions.",
        "ranges": 7,
        "pairwise_intersection_checks": len(intersections),
        "distinct_starting_integers": total,
        "thresholds": "The band threshold varies with the source; these are not one fixed-threshold aggregate family.",
        "intersections": intersections,
    }
    (root/"verification"/"search_union_certificate.json").write_text(
        json.dumps(report, indent=2)+"\n"
    )
    print("PASS: 327680 distinct starts; all 21 pairwise intersections empty.")


def run(root, script, timeout):
    process = subprocess.run(
        [sys.executable, "-B", str(root/script)],
        cwd=root, text=True, capture_output=True, timeout=timeout, check=True,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    result = json.loads(process.stdout)
    assert (result.get("status") == "PASS" or result.get("passed") is True), script
    print("PASS:", script)


def main():
    if not __debug__:
        raise RuntimeError("Run without -O.")
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    inputs = json.loads((root/"input_manifest.json").read_text())["incoming_notes"]
    assert len(inputs) == 5
    for entry in inputs:
        raw = (root/"inputs"/entry["name"]).read_bytes()
        assert len(raw) == entry["bytes"]
        assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
    manifest = root/"MANIFEST.sha256"
    if manifest.exists():
        for row in manifest.read_text().splitlines():
            digest, name = row.split("  ", 1)
            assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
    run(root, "verify_five_note_audit.py", 60)
    run(root, "verify_first_gate.py", 60)
    run(root, "fixture/verify_near_miss.py", 60)
    run(root, "verify_gate_suffix_ledger.py", 60)
    if args.full:
        run(root, "fixture/verify_late_core_search.py", 120)
        run(root, "fixture/verify_flatter_prefix_search.py", 120)
    check_search_union(root)
    print(json.dumps({
        "status": "PASS", "incoming_notes": 5,
        "fast_exact_verifiers": 4,
        "full_diagnostics_replayed": 2 if args.full else 0,
        "all_depth_aggregate_proved": False,
    }, indent=2))


if __name__ == "__main__":
    main()
