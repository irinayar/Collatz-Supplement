"""Exact bounded controls for two arbitrary-depth Collatz lemmas."""
def T(x):
    return x//2 if x%2==0 else (3*x+1)//2

def trace(n,j):
    x=n; pos=[]
    for i in range(j):
        if x%2: pos.append(i)
        x=T(x)
    return x,pos

checks=0
for j in range(1,15):
    for n in range(1,10001):
        y,odd=trace(n,j)
        if y%3==0:
            assert not odd and n==(1<<j)*y,(j,n,y,odd)
        if not odd and j>=2:
            t=n//(1<<j)
            assert (t%3==0)==(y%3==0)
            if t%3:
                candidates=[((1<<j)*t-(1<<i))//3 for i in range(j) if ((1<<j)*t-(1<<i))%3==0]
                assert candidates and any(0<m<n and trace(m,j)[0]==t and len(trace(m,j)[1])==1 for m in candidates),(j,n,t)
        if len(odd)==1 and odd[0]+2<j:
            i=odd[0];m=n-(1<<i)
            assert m>0 and trace(m,j)[0]==y and trace(m,j)[1]==[i+2],(j,n,odd,m,trace(m,j))
        checks+=1
    print('depth',j,'passed')
print('Total',checks,'start-depth controls')
