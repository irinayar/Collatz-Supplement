from fractions import Fraction

def check(max_origin=5000, max_even=25):
    tested=0; outside=0; crossing=0
    for m in range(1,max_origin+1):
        n=m; k=r=0
        while k<=max_even:
            phi=Fraction(2**r,3**r)*(2**k*n+1)
            tested+=1
            if n>=3:
                outside+=1
                assert 2*phi<3*(m+1),(m,n,k,r)
            if n&1:
                nnew=(3*n+1)//2
                phi2=Fraction(2**(r+1),3**(r+1))*(2**k*nnew+1)
                assert phi2-phi==Fraction(2**r,3**r)*Fraction(2**k-1,3)
                if 2*phi<3*(m+1) and 2*phi2>=3*(m+1):
                    crossing+=1
                    assert nnew in (1,2),(m,n,k,r)
                n=nnew;r+=1
            else:
                n//=2;k+=1
                assert Fraction(2**r,3**r)*(2**k*n+1)==phi
    return {'states':tested,'outside':outside,'first_crossings':crossing}
if __name__=='__main__': print(check())
