from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def word(n,h):
 out=[]
 for _ in range(h): out.append(n%2);n=T(n)
 return out

checks=0
for H in range(1,13):
 for a in range(2**H):
  n=a+2**H*1000
  assert word(n,H)==word(a,H)
  z=n
  for j in range(H+1):
   assert z*2**j>=n
   assert Fraction(1,z)<=Fraction(2**H,n)
   checks+=1
   if j<H:z=T(z)
print({'H_max':12,'shadow_and_reciprocal_checks':checks,'status':'passed'})
