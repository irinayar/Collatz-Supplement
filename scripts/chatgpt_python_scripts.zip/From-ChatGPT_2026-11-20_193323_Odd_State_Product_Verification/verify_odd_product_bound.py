from fractions import Fraction
from math import prod
P=Fraction(1)
for j in range(12):
    u=2*j+3
    P*=Fraction(3*u+1,3*u)
    print(j+1,u,str(P),P<=Fraction(3,2))
assert prod([Fraction(3*(2*j+3)+1,3*(2*j+3)) for j in range(11)],start=Fraction(1)) == Fraction(1216348160,817887699)
assert P>Fraction(3,2)
# Exact exhaustive check of every prefix until first 1 or 2 for m <= 100000.
# Repeated odd states are recorded, not silently excluded.
N=100000
max_ratio=Fraction(1)
repeats=0
violations=0
for m in range(1,N+1):
    n=m; odd=set(); G=Fraction(1)
    for step in range(2000):
        if n<=2:break
        if n%2:
            if n in odd:repeats+=1;break
            odd.add(n)
            G*=Fraction(3*n+1,3*n)
            n=(3*n+1)//2
        else:n//=2
        if n>=3 and G>Fraction(3,2):violations+=1
        if n>=3 and G>max_ratio:max_ratio=G
    else:raise RuntimeError(f'step cap reached at {m}')
print('sample',N,'repeats',repeats,'violations',violations,'max_ratio',str(max_ratio))
