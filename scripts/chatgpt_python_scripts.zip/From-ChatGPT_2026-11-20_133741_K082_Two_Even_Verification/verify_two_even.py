from itertools import product

def num(w):
    v=a=0
    for t,c in enumerate(w):
        if c=='1':v=3*v+2**t;a+=1
    return v

def v3(n):
    if n==0:return None
    k=0
    while n%3==0:n//=3;k+=1
    return k

checks=0
for r in range(0,16):
 for i in range(r+1):
  for j in range(r-i+1):
   k=r-i-j
   w='1'*i+'0'+'1'*j+'0'+'1'*k
   expected=3**r-2**(r+2)+2**i*3**(j+k)+2**(i+j+1)*3**k
   assert num(w)==expected,(r,i,j,k)
   checks+=1
print('two-even affine identities:',checks)

# Confirm the general fixed-even budget upper bound by direct positive origins.
checks2=0
for m in range(1,301):
 x=m;r=e=0
 for t in range(70):
  if x%2:r+=1;x=(3*x+1)//2
  else:e+=1;x//=2
  assert 3**r*m<=2**(r+e)*x
  checks2+=1
print('fixed-even growth inequalities:',checks2)

# For every fixed endpoint x and e=2, a complete enumeration of words
# agrees with direct inversion and the universal odd-count bound.
checks3=0
for x in range(1,60):
 for r in range(0,13):
  if 3**r>2**(r+2)*x:
   for i in range(r+1):
    for j in range(r-i+1):
     k=r-i-j
     V=3**r-2**(r+2)+2**i*3**(j+k)+2**(i+j+1)*3**k
     assert not (0<2**(r+2)*x-V and (2**(r+2)*x-V)%3**r==0)
     checks3+=1
print('excluded full-divisibility word controls:',checks3)
