from functools import lru_cache
from collections import Counter
@lru_cache(maxsize=None)
def maxodd(y,j):
    if j==0:return 0
    v=maxodd(2*y,j-1)
    if y%3==2:
        z=(2*y-1)//3
        if z>0:v=max(v,1+maxodd(z,j-1))
    return v

def T(x):return x//2 if x%2==0 else (3*x+1)//2
stats=Counter();examples=[]
for n in range(3,501,2):
    x=n;seen={n};a=0
    for j in range(1,19):
        a+=x%2
        x=T(x)
        if x<n or x in seen:break
        seen.add(x)
        mx=maxodd(x,j)
        stats['eligible']+=1
        if mx>a:
            stats['surplus']+=1
            if len(examples)<10:examples.append((n,j,x,a,mx))
        else:stats['no_surplus']+=1
print(stats,examples,'cache',maxodd.cache_info())
def origin_max(y,j):
    if j==0:return y
    z=2*y
    if y%3==2 and 1+maxodd((2*y-1)//3,j-1)>maxodd(z,j-1):z=(2*y-1)//3
    return origin_max(z,j-1)
for n,j,y,a,mx in examples[:8]:
 m=origin_max(y,j)
 print('witness',n,j,y,a,mx,m,'valid',m<n)
