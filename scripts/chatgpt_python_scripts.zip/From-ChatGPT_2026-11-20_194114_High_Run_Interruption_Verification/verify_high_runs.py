from fractions import Fraction
from math import gcd
H=255
Q=Fraction(8192,6561)
x=Fraction(47,257)
# exp(x) <= 1+x+x^2/[2(1-x/3)] for 0<=x<3
E=1+x+x*x/(2*(1-x/3))
assert Q*E < Fraction(3,2)
print('Q * rational exp bound at 47 runs:',Q*E, float(Q*E))
print('48 run crude exp threshold is above 3/2 (nonproof of existence):',float(Q)*__import__('math').exp(48/257))
# exact rational product for each maximal v2=1 run within actual finite trajectories
runs=0; tested=0; max_ratio=Fraction(1)
for m in range(3,10001,2):
    u=m
    seen=set()
    for _ in range(300):
        if u<=1 or u in seen: break
        seen.add(u)
        start=u; prod=Fraction(1); count=0
        while u>1 and (3*u+1)%4==2 and count<300:
            prod*=Fraction(3*u+1,3*u)
            z=(3*u+1)//2
            assert z%2==1 and z>u
            u=z; count+=1
        if count:
            runs+=1
            # exact exp bound via rational upper bound for 1/start
            t=Fraction(1,start)
            ub=1+t+t*t/(2*(1-t/3))
            assert prod<=ub
            if prod>max_ratio: max_ratio=prod
        if u==1: break
        z=3*u+1
        u=z//(z&-z)
        tested+=1
print('run checks',runs,'other odd transitions',tested,'max observed run product',float(max_ratio))
