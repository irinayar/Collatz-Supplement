from fractions import Fraction
from math import comb
D=[Fraction(1),Fraction(5,6),Fraction(3,4),Fraction(5,8),Fraction(25,48),Fraction(43,96),Fraction(77,192),Fraction(139,384),Fraction(85,256),Fraction(157,512),Fraction(877,3072),Fraction(1639,6144),Fraction(3071,12288),Fraction(5767,24576),Fraction(3617,16384)]
J=800
lower=1+sum(D)
upper=lower+sum((Fraction(sum(min(comb(j,a),3**a) for a in range(j+1)),2**j) for j in range(15,J+1)),Fraction(0))
# Claude/Codex verified b_j <= (5/2) exp(-j/50); exp(-1/50) <= 50/51
upper+=Fraction(5,2)*51*Fraction(50,51)**(J+1)
print(float(lower),float(upper))
assert lower > Fraction(783,100) and upper < Fraction(2662,100)
print('lower:',lower,'~',float(lower))
print('certified upper:',float(upper))
print('certified interval: 7.83 < E[tau] < 26.62')
