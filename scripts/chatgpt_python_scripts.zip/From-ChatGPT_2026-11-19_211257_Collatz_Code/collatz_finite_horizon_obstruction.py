from fractions import Fraction

def T(x): return x//2 if x%2==0 else (3*x+1)//2

def orbit(n,j):
    out=[n]
    for _ in range(j): out.append(T(out[-1]))
    return out

def cylinder_residue(word):
    j=len(word)
    for r in range(1,2**j+1):
        x=r
        for bit in word:
            if x%2!=bit: break
            x=T(x)
        else: return r
    raise AssertionError('missing cylinder')

def check():
    cases=0
    for j in range(1,11):
        for v in range(2**j):
            w=[(v>>i)&1 for i in range(j)]
            r=cylinder_residue(w)
            for H in (100,1000):
                t=1+H*2**j
                n=r+2**j*t
                z=orbit(n,j)
                assert min(z)>H
                assert len(set(z))==len(z)
                assert [x%2 for x in z[:-1]]==w
                cases+=1
    return cases
if __name__=='__main__': print('passed',check(),'finite-horizon constructions')
