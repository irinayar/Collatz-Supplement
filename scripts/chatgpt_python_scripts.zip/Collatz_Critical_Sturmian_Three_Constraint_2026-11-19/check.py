from decimal import Decimal, localcontext
import json

def build(depth=400):
    with localcontext() as ctx:
        ctx.prec=110
        alpha=Decimal(2).ln()/Decimal(3).ln()
        floors=[int(alpha*i) for i in range(depth+1)]
        w=[floors[i+1]-floors[i] for i in range(depth)]
    U=0; a=0; r=0; samples=[]; checks=0
    for j,bit in enumerate(w,1):
        if bit: U=3*U+2**(j-1); a+=1
        modulus=1<<j
        residue=(-U*pow(3**a,-1,modulus))%modulus
        assert residue% (modulus>>1)==r if j>1 else True
        r=residue
        n=r if r else modulus
        z=n
        for b in w[:j]:
            assert z%2==b
            z=(3*z+1)//2 if b else z//2
        assert (3**a*n+U)==(1<<j)*z
        assert 9*z>=3*n+a and z<=3*n+a
        checks+=1
        if j in [1,2,3,4,5,8,10,16,20,32,50,64,100,128,200,256,400]:
            samples.append({'depth':j,'odd_count':a,'least_positive_origin':n,'origin_bits':n.bit_length(),'endpoint_bits':z.bit_length(),'parity_prefix':''.join(map(str,w[:min(j,32)]))})
    return {'depth':depth,'alpha_decimal':str(alpha),'checks':checks,'samples':samples}
if __name__=='__main__':
    data=build()
    with open('/mnt/data/sturmian_rigidity/results.json','w') as f:json.dump(data,f,indent=2)
    for x in data['samples']: print(x['depth'],x['odd_count'],x['origin_bits'],x['endpoint_bits'])
