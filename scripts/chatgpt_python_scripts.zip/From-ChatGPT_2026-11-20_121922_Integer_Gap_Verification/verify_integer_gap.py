from collections import defaultdict

def step(x): return (3*x+1)//2 if x%2 else x//2

def tables(J,h):
 d={(0,0):0}
 out={0:d}
 for j in range(J):
  nd={}
  for (b,r),v in d.items():
   for nb,nv in ((b,v),(b+1,3*v+(1<<j))):
    rr=nv%3**min(h,nb)
    key=(nb,rr)
    nd[key]=max(nd.get(key,-1),nv)
  d=nd;out[j+1]=d
 return out

def check():
 comparisons=0; stronger=0; newcases=[]
 for h in range(4):
  tb=tables(12,h)
  for n in range(1,201):
   y=n;a=0
   for j in range(1,13):
    a+=y%2;y=step(y)
    B=(1<<j)*y
    for b in range(j+1):
     R=tb[j].get((b,B%3**min(h,b)))
     if R is None: continue
     T=B-3**b*n
     old=(R<=T)
     new=(R<T+3**b)
     assert not old or new
     if new and not old:
      stronger+=1
      if len(newcases)<8: newcases.append((n,j,b,h,R,T,3**b))
     if new:
      # independent exhaustive forward check for smaller origin, matching odd count
      for m in range(1,n):
       z=m;c=0
       for _ in range(j): c+=z%2;z=step(z)
       assert not (z==y and c==b),(n,j,b,h,m)
     comparisons+=1
 print('comparisons',comparisons,'additional exclusions',stronger)
 print('examples',newcases)
check()
