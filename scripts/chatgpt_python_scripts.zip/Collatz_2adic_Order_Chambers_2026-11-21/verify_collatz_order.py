from fractions import Fraction
from itertools import product

def cylinder(bits):
    L=len(bits); a=0; U=0; r=0
    for j,b in enumerate(bits):
        current=(3**r*a+U)//2**j
        if (current&1)!=b: a+=2**j
        U=3**b*U+b*2**j
        r+=b
    if a==0:a=2**L
    states=[];U=0;r=0
    for j,b in enumerate(bits):
        if b:
            A=(3**r*a+U)//2**j
            D=3**r*2**(L-j)
            states.append((j,A,D))
        U=3**b*U+b*2**j;r+=b
    return a,U,r,states

def T(x):return (3*x+1)//2 if x%2 else x//2

def verify(bits):
    L=len(bits);a,U,r,states=cylinder(bits)
    for t in range(4):
        n=a+2**L*t;z=n;odd=[]
        for b in bits:
            assert z%2==b
            if b:odd.append(z)
            z=T(z)
        assert z*2**L==3**r*n+U
        assert odd==[A+D*t for _,A,D in states]
        for i in range(len(states)):
            for j in range(i+1,len(states)):
                di=odd[i]-odd[j]
                Ai,Di=states[i][1:];Aj,Dj=states[j][1:]
                assert di==(Ai-Aj)+(Di-Dj)*t
    # Exact crossing fractions and order-change verification
    for i in range(len(states)):
        for j in range(i+1,len(states)):
            _,Ai,Di=states[i];_,Aj,Dj=states[j]
            if Di!=Dj:
                c=Fraction(Aj-Ai,Di-Dj)
                if c>=0:
                    lo=max(0,c.numerator//c.denominator)
                    for t in (max(0,lo-1),lo,lo+1,lo+2):
                        assert (Ai+Di*t)-(Aj+Dj*t)==(Ai-Aj)+(Di-Dj)*t

count=0
for L in range(1,13):
    for bits in product((0,1),repeat=L):
        verify(bits);count+=1
print('PASS: exact affine trajectories and pairwise order formulas for',count,'parity words, lengths 1..12; four lifts per word.')
