from functools import lru_cache

def T(n): return n//2 if n%2==0 else (3*n+1)//2

@lru_cache(None)
def words(j):
    if j==0:return ((0,0),)
    prev=words(j-1)
    return tuple((a,U) for a,U in prev)+tuple((a+1,3*U+2**(j-1)) for a,U in prev)

@lru_cache(None)
def max_table(j):
    out={}
    for a,U in words(j):
        k=(a,U%(3**a))
        out[k]=max(out.get(k,-1),U)
    return out

checks=0; positive=0; strict=0
for n in range(1,1001):
    x=n;a=0;U=0;gap=0
    for j in range(0,13):
        r=U%(3**a)
        newgap=max_table(j)[(a,r)]-U
        assert newgap>=gap*(3 if (j and prev_odd) else 1),(n,j,gap,newgap)
        checks+=1
        if newgap>0:positive+=1
        if j<12:
            prev_odd=x%2
            if prev_odd:U=3*U+2**j;a+=1
            x=T(x)
            gap=newgap
print('PASS',checks,'source-depth gap checks;',positive,'positive gaps')
print('example n=15 depth6:',max_table(6)[(4,65%81)]-65)
