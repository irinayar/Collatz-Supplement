from itertools import combinations
from functools import lru_cache

def words(e,w):
    L=e+3
    endpoint=(6*w-1) if e==3 else (3*w-1)
    out=[]
    for positions in combinations(range(L),3):
        V=sum(2**p*3**(2-j) for j,p in enumerate(positions))
        if (2**L*endpoint-V)%27==0:
            origin=(2**L*endpoint-V)//27
            assert origin>0
            word=''.join('1' if i in positions else '0' for i in range(L))
            n=origin
            for bit in word:
                assert n%2==int(bit)
                n=(3*n+1)//2 if bit=='1' else n//2
            assert n==endpoint
            out.append((V,word,origin))
    return out

def v3(n):
    a=0
    while n%3==0: n//=3;a+=1
    return a

@lru_cache(None)
def H(x,e,r):
    if r<0:return None
    a=v3(x+1)
    if e==0:return (2**r*(x+1)//3**r-1) if r<=a else None
    vals=[]
    for l in range(min(a,r)+1):
        Y=2*(2**l*(x+1)//3**l-1)
        m=H(Y,e-1,r-l)
        if m is not None:vals.append(m)
    return min(vals) if vals else None

for w in (2,5,8):
    print('w',w,'P3',words(3,w),'Q3',words(4,w))
for w in range(2,3000,3):
    p2,q2=H(6*w-1,3,2),H(3*w-1,4,2)
    assert p2==(64*w-20)//3 and q2==(64*w-26)//3
    p3,q3=H(6*w-1,3,3),H(3*w-1,4,3)
    assert p3==(128*w-{2:31,5:46,8:52}[w%9])//9
    assert q3==((128*w-{2:58,5:55}[w%9])//9 if w%9!=8 else None)
    if w%9==8:assert q2>p3
print('999 endpoint tests and all finite word cases passed')
