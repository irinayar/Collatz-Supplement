"""Exact finite-budget coalescence bound, accelerated Collatz."""
from math import comb, ceil, log2

def T(x):
    return x//2 if x%2 == 0 else (3*x+1)//2

def bound(N,j):
    # Each parity class has at most ceil(N/2^j) representatives.
    B=min(3**h+sum(comb(j,a) for a in range(h+1,j+1)) for h in range(j+1))
    return min(N, ceil(N/(2**j))*B), B

def image_size(N,j):
    a=set(range(1,N+1))
    for _ in range(j):
        a={T(x) for x in a}
    return len(a)

def run():
    checks=0
    for N in (100,1000,10000):
        for j in range(1,13):
            actual=image_size(N,j)
            upper,B=bound(N,j)
            assert actual<=upper,(N,j,actual,upper)
            checks+=1
            print(f'N={N:5d} j={j:2d} actual={actual:5d} upper={upper:5d} B={B}')
    print('PASS',checks,'finite-budget upper-bound comparisons')
if __name__=='__main__':run()
