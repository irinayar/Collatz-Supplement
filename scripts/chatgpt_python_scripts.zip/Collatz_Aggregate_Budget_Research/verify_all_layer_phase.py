#!/usr/bin/env python3
"""Exact constants and arithmetic for the all-layer phase/modulus sector.

The universal supersolution is a prior certificate. This script evaluates
it at a new starting point and verifies all new rational comparisons.
Its full supersolution verifier is replayed separately by verify_all.py.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

if not __debug__:
    raise SystemExit('Run without -O or -OO: assertions are required.')

HERE = Path(__file__).resolve().parent


def exp_lower(x, degree):
    assert x >= 0
    term = total = F(1)
    for k in range(1, degree + 1):
        term *= x / k
        total += term
    return total


def certificate_value(path):
    raw = path.read_bytes()
    data = json.loads(raw)
    z = F(32, 47)
    bounds, D, S = data['endpoints'], data['denominator'], data['value_denominator']
    cells = [i for i in range(len(data['values']))
             if F(bounds[i], D) <= z <= F(bounds[i+1], D)]
    assert cells == [3355]
    assert F(bounds[3355], D) < z < F(bounds[3356], D)
    value = max(F(data['values'][i], S) for i in cells)
    assert value == F(22718390719, 2500000000)
    assert (data['tilt_numerator'], data['tilt_denominator']) == (7, 5)
    return value, dict(sha256=sha256(raw).hexdigest(), initial_z=str(z),
                       initial_cells=cells, moment_bound=str(value),
                       full_supersolution_verified_separately=True)


def layer_controls():
    checked = 0
    for W in range(1, 50):
        for offset in range(8):
            low, high = 100 + offset, 100 + offset + W
            for exponent in range(1, 11):
                M = 2**exponent
                if M <= 2*W:
                    continue
                d = 1
                while M > 2**(d+1)*W:
                    d += 1
                assert 2**d*W < M <= 2**(d+1)*W
                inflation = F(2**(d+1)*W, M)
                assert inflation >= 1
                # Only occupied residues can test the nonzero atom count.
                for source in (low, (low+high)//2, high):
                    residue = source % M
                    first = low + (residue-low) % M
                    count = 0 if first > high else 1+(high-first)//M
                    assert count == 1 and count <= inflation
                    checked += 1
    return checked


def verify(path):
    J, imported = certificate_value(path)
    A, tau, eps = F(47, 32), F(224, 235), F(1, 2000)
    assert tau*A == F(7, 5)
    assert exp_lower(7*tau+1-eps, 48) > 2000
    rows = []
    for a,c in ((8,2), (10,1), (10,2), (12,2)):
        e0 = exp_lower(a*tau+1-eps, 48)
        e1 = exp_lower(c*tau, 30)
        assert e1 > 2
        upper = (J-1)/(tau*e0)*2/(e1-2)
        if (a,c) == (10,2):
            assert upper < F(96, 10**6)
            assert F(2,3)*upper < F(64, 10**6)
            selected = upper
        rows.append(dict(a=a, c=c, reciprocal_upper=str(upper),
                         decimal_informational=float(upper)))
    assert 2-F(47,96) == F(145,96)
    assert 10+F(5,32) == F(325,32)
    assert F(325,32)*F(96,145) == F(975,145)
    # Rational lower log(2) bound proves ln(2)/tau > 47/96.
    assert F(2,3)/tau > F(47,96)
    data = json.loads(path.read_text())
    z = F(1000,1001)
    cells = [i for i in range(len(data['values']))
             if F(data['endpoints'][i],data['denominator']) <= z
             <= F(data['endpoints'][i+1],data['denominator'])]
    J_small = max(F(data['values'][i],data['value_denominator']) for i in cells)
    assert J_small == F(82262531839,10**10)
    theta = F(200,143)
    assert 2*F(192,145) < 4
    assert 2*71 < F(2**71,2**63)
    assert 1+F(1,3*2**63-1) < F(1001,1000)
    improved = (J_small-1)/(theta*exp_lower(10*theta+1-eps,48))*2/(exp_lower(2*theta,30)-2)
    assert improved < F(223,10**9)
    assert F(2,3)*improved < F(149,10**9)
    n0 = 2**71+1
    cstar = F(620751769493359576,1180591620717411303425)
    alpha = F(4899,3904)
    xi = cstar*(2-F(4,3)*alpha+alpha/(3*n0))
    eta = F(6761,3904000)-F(557,10**6)-xi
    remaining = eta-F(149,10**9)
    assert remaining > F(1002,10**6)
    return dict(status='PASS', imported=imported, scale=str(A), tilt=str(tau),
                tail_threshold_verified_from=7, layer_controls=layer_controls(),
                bounds=rows, selected_sector='M>2W and q>10+2d, 2^dW<M<=2^(d+1)W',
                weaker_large_barrier_upper=str(selected),
                exact_reciprocal_upper=str(improved),
                small_barrier_moment=str(J_small), small_barrier_tilt=str(theta),
                reciprocal_display_bound='223/1000000000',
                whole_run_charge_display_bound='149/1000000000',
                automatic_depth_bound='E < (192*log2(W)-975)/145',
                previous_allowance=str(eta), new_sufficient_allowance=str(remaining),
                simple_sufficient_unproved_target='1002/1000000',
                scope='Actual completed-profile sector with full source multiplicities. Deep slowly accumulating inputs remain uncontrolled by this estimate.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--certificate', type=Path,
                        default=(HERE/'imports/phase/killed_phase_certificate.json'
                                 if (HERE/'imports/phase/killed_phase_certificate.json').is_file()
                                 else HERE.parent/'phase_frontier_work/killed_phase_certificate.json'))
    parser.add_argument('--output', type=Path,
                        default=HERE/'all_layer_phase_certificate.json')
    args = parser.parse_args()
    result = verify(args.certificate)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','layer_controls',
          'reciprocal_display_bound','whole_run_charge_display_bound',
          'automatic_depth_bound')}, indent=2))


if __name__ == '__main__':
    main()
