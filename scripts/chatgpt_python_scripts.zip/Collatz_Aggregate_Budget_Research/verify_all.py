#!/usr/bin/env python3
"""Hash-check and reproduce this aggregate-budget research packet."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

if not __debug__:
    raise SystemExit('Run without -O or -OO: assertions must be enabled.')


def normalized(value):
    if isinstance(value, dict):
        return {k: normalized(v) for k,v in value.items()
                if k != 'elapsed_seconds_informational'}
    if isinstance(value, list):
        return [normalized(v) for v in value]
    return value


def verify():
    root = Path(__file__).resolve().parent
    checked = 0
    for line in (root/'MANIFEST.sha256').read_text().splitlines():
        expected, relative = line.split('  ',1)
        path = (root/relative).resolve()
        if root not in path.parents or not path.is_file():
            raise RuntimeError(f'Invalid manifest path: {relative}')
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f'Hash mismatch: {relative}')
        checked += 1
    cert = root/'imports/phase/killed_phase_certificate.json'
    jobs = [
        ('imports/phase/verify_phase_frontier.py', ['--certificate',str(cert)],
         'imports/phase/phase_frontier_verification.json'),
        ('obstruction/verify_raw_budget_obstruction.py', [],
         'obstruction/raw_budget_obstruction_certificate.json'),
        ('obstruction/verify_genuine_budget_obstruction.py', [],
         'obstruction/genuine_budget_obstruction_certificate.json'),
        ('transport/verify_suffix_budget_transport.py', [],
         'transport/suffix_budget_transport_certificate.json'),
        ('frontier/verify_stopped_aggregate.py', [],
         'frontier/stopped_aggregate_certificate.json'),
        ('frontier/verify_late_wedge_audit.py', ['--certificate',str(cert)],
         'frontier/late_wedge_audit_certificate.json'),
        ('verify_all_layer_phase.py', ['--certificate',str(cert)],
         'all_layer_phase_certificate.json'),
    ]
    replayed = []
    with tempfile.TemporaryDirectory(prefix='aggregate-budget-replay-') as tmp:
        for script, options, expected_path in jobs:
            target = Path(tmp)/Path(expected_path).name
            subprocess.run([sys.executable,str(root/script),*options,'--output',str(target)],
                           cwd=root, text=True, capture_output=True, check=True)
            actual = json.loads(target.read_text())
            expected = json.loads((root/expected_path).read_text())
            if normalized(actual) != normalized(expected):
                raise RuntimeError(f'Certificate mismatch: {script}')
            replayed.append({'script':script,'certificate_matches':True})
    return {'status':'PASS','hashed_files':checked,'replays':replayed,
            'scope':'Six new exact checks plus the full imported phase certificate. Infinite results are proved in the notes; unrestricted aggregate remains open.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=verify()
    text=json.dumps(result,indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    print(text,end='')


if __name__=='__main__':
    main()
