#!/usr/bin/env python3
"""Exact coalescent reciprocal-budget controls on four saved profiles.

No search or extra trajectory step is performed. The saved words, including
their original core masks, are replayed. Core membership is an imported
property of these unchanged fixtures; this checker does not replace its
earlier full verification.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

if not __debug__:
    raise RuntimeError("Run without -O or -OO: assertions must remain enabled.")

HERE = Path(__file__).resolve().parent


def enc_interval(q, bits=80):
    q = F(q)
    D = 1 << bits
    lo = q.numerator*D//q.denominator
    return {"lower": str(F(lo, D)), "upper": str(F(lo+1, D)),
            "display_only": float(q)}


def reciprocal(xs):
    return sum((F(1, x) for x in xs), F(0))


def packing_bound(L, S):
    return (F(3**S-1, 2**L) + F(200, 7)*F(193, 200)**(S+1)
            + F(L+1, 2**(L-1)))


def replay(n, data):
    H = (4*n-2)//3
    u = int(data["u"])
    word = data["word"]
    xs = [u]
    phases = [F(0)]
    valuations = [0]
    E = U = 0
    for e in word:
        z = 3*xs[-1]+1
        assert (z & -z).bit_length()-1 == e
        xs.append(z >> e)
        U = 3*U+2**E
        E += e
        phases.append(F(U, 3**(len(xs)-1)))
        valuations.append(E)
    assert n >= 2**71 and n & 1
    assert n <= xs[0] <= H and n <= xs[-1] <= H
    assert all(x > H for x in xs[1:-1])
    assert len(set(xs[:-1])) == len(xs)-1
    M = 2**(E+1)
    residue = ((2**E-U)*pow(3**len(word), -1, M)) % M
    assert residue == u < M and 2**E*xs[-1] == 3**len(word)*u+U
    starts = [0]+[i+1 for i, e in enumerate(word[:-1]) if e >= 2]
    assert set(data["expected_core"]).issubset(starts)
    runs = []
    kappa = F(n-1, n+1)
    for i, j in zip(starts, starts[1:]+[len(word)]):
        s, e = j-i, word[j-1]
        assert all(v == 1 for v in word[i:j-1]) and e >= 2
        beta = 1-F(2, 3)**s
        lam = F(2**(s+e-1), 3**s)
        a, b = xs[i], xs[j]
        assert b == (a+beta)/lam
        t = kappa*beta/a+F(1, a)-F(1, b)
        c = reciprocal(xs[i:j])
        gamma = max(F(0), 1+beta-lam)/(3*beta)
        assert max(F(0), t) <= gamma*c
        assert 0 <= gamma < F(2, 3)
        runs.append(dict(i=i, j=j, charge=max(F(0), t), cost=c,
                         gamma=gamma, core=i in data["expected_core"]))
    return dict(xs=xs, word=word, starts=starts, runs=runs,
                phases=phases, valuations=valuations,
                core=set(data["expected_core"]), source=u)


def channels(p, i, L, common_cap):
    return [F(144, 125)-reciprocal(p["xs"][:i]),
            common_cap-reciprocal([x for x in p["xs"][:i] if x >= 2**L])]


def rank_controls(profiles, indices, n, H, L, cap):
    # Original core fixtures have q > B_* > 5. Use the weaker rational B=5.
    B, M = F(5), 4
    B0 = max(B, F(1, 3))
    A = min(F(144, 125)-3*B0/(H+B0), cap-(3*B0-1)/(H+B0))
    d = F(3*M)/(H+B0)
    cells = {}
    for p, g in zip(profiles, indices):
        x, u, q = p["xs"][g], p["source"], p["phases"][g]
        assert g > 0 and x > H and q > B
        assert u+q == F(2**p["valuations"][g], 3**g)*x
        S = reciprocal(p["xs"][:g])
        Shigh = reciprocal([y for y in p["xs"][:g] if y >= 2**L])
        assert S >= 3*q/(u+q)
        assert Shigh >= (3*q-1)/(u+q)
        assert S >= 6*q/(2*u+q)
        assert Shigh >= 6*(q-F(1, 3))/(2*u+q+F(1, 3))
        key = (g, x, u % M)
        cells.setdefault(key, []).append((u, q, min(channels(p, g, L, cap))))
    rows = []
    for (g, x, residue), entries in sorted(cells.items()):
        entries.sort(reverse=True)
        m = len(entries)
        C = entries[0][0]+entries[0][1]
        assert all(u+q == C for u, q, _ in entries)
        for j, (u, q, b) in enumerate(entries):
            assert u <= H-j*M and q >= B0+j*M
            assert b <= A-d*j
            if j:
                assert entries[j-1][0]-u >= M
                assert q-entries[j-1][1] == entries[j-1][0]-u
        pooled = min(b for _, _, b in entries)
        assert pooled <= A-d*(m-1)
        assert sum(b for _, _, b in entries) <= m*A-d*m*(m-1)/2
        assert m*pooled <= m*A-d*m*(m-1)
        assert pooled >= F(1, x)
        assert d*(m-1) <= A-F(1, x)
        Rall = F(H+B0, H-(m-1)*M)
        Rproper = F(H+B0, H-(m-1)*M+F(1, 3))
        rational_log_cap = min(F(144, 125)-6*(Rall-1)/(Rall+1),
                               cap-6*(Rproper-1)/(Rproper+1))
        assert pooled <= rational_log_cap <= A-d*(m-1)
        rows.append(dict(odd_depth=g, source_residue=str(residue), spacing=M,
                         cell_size=m, rank_bound=True,
                         quadratic_discount_times_H_plus_1=enc_interval(d*m*(m-1)*(H+1)),
                         independent_rank_discount_times_H_plus_1=enc_interval(d*m*(m-1)*(H+1)/2),
                         rational_log_cap=enc_interval(rational_log_cap)))
    return rows


def verify_family(seed):
    n = int(seed["n"])
    H = (4*n-2)//3
    L = (H+1).bit_length()-1
    p, q = [replay(n, item) for item in seed["sources"]]
    qs = {x:i for i, x in enumerate(q["xs"])}
    common_boundaries = [(i, qs[x]) for i, x in enumerate(p["xs"][:-1])
                         if x in qs and i in p["starts"] and qs[x] in q["starts"]
                         and x > H]
    ip, iq = common_boundaries[0]
    assert p["xs"][ip:] == q["xs"][iq:]
    common_core = [(i, j) for i, j in common_boundaries if i in p["core"] and j in q["core"]]
    jp, jq = common_core[0]
    assert jp > ip and jq > iq
    # Deliberately mismatch the two checkpoints along their common suffix.
    initial_indices = [ip, jq]
    aligned_indices = [jp, jq]
    target = p["xs"][jp]
    assert target == q["xs"][jq]
    bounds = [packing_bound(L, S) for S in range(2*L+1)]
    S = min(range(len(bounds)), key=lambda j: bounds[j])
    cap = bounds[S]
    initial_channels = [channels(x, i, L, cap) for x, i in zip((p, q), initial_indices)]
    aligned_channels = [channels(x, i, L, cap) for x, i in zip((p, q), aligned_indices)]
    d = [reciprocal(x["xs"][i:j]) for x, i, j in zip((p, q), initial_indices, aligned_indices)]
    assert d[0] > 0 and d[1] == 0
    for ci, ca, spent in zip(initial_channels, aligned_channels, d):
        assert all(a-spent == b for a, b in zip(ci, ca))
        # Future proper inputs exceed H, hence belong to both cost channels.
        assert min(ci)-spent == min(ca)
    initial_caps = [min(z) for z in initial_channels]
    aligned_caps = [min(z) for z in aligned_channels]
    actual_tail = reciprocal(p["xs"][jp:-1])
    assert p["xs"][jp:] == q["xs"][jq:]
    assert all(actual_tail <= b for b in aligned_caps)
    common = min(aligned_caps)
    slack = sum(aligned_caps)-2*common
    assert slack > 0
    naive = sum(initial_caps)
    synced = sum(d)+2*common
    assert naive-synced == slack
    actual_initial_cost = sum(d)+2*actual_tail
    assert actual_initial_cost <= synced < naive
    selected = [r for x, i in zip((p, q), initial_indices)
                for r in x["runs"] if r["i"] >= i and r["core"]]
    actual_charge = sum((r["charge"] for r in selected), F(0))
    assert actual_charge <= F(2, 3)*actual_initial_cost <= F(2, 3)*synced
    rank_rows = rank_controls((p, q), aligned_indices, n, H, L, cap)
    assert sorted(row["cell_size"] for row in rank_rows) == ([1, 1] if seed["name"] == "asynchronous" else [2])

    # Exact deterministic forest invariant. Every group retains all labels.
    next_state = {}
    distance = {}
    for x in (p, q):
        for k, a in enumerate(x["xs"][:-1]):
            b = x["xs"][k+1]
            assert a not in next_state or next_state[a] == b
            next_state[a] = b
            dist = len(x["xs"])-1-k
            assert a not in distance or distance[a] == dist
            distance[a] = dist
    groups = {}
    for label, x, i, b in zip((0, 1), (p, q), initial_indices, initial_caps):
        a = x["xs"][i]
        assert a not in groups
        groups[a] = ({label}, b)
    spent = merge_credits = retired = F(0)
    advances = merges = 0
    while groups:
        potential = sum((len(labels)*b for labels, b in groups.values()), F(0))
        assert spent+potential+merge_credits+retired == naive
        a = max(groups, key=lambda x: distance[x])
        labels, b = groups.pop(a)
        cost = F(1, a)
        assert b >= cost
        spent += len(labels)*cost
        residual = b-cost
        y = next_state[a]
        advances += 1
        if y <= H:
            assert n <= y <= H
            retired += len(labels)*residual
        elif y not in groups:
            groups[y] = (labels, residual)
        else:
            old_labels, old_budget = groups.pop(y)
            assert labels.isdisjoint(old_labels)
            z = min(old_budget, residual)
            merge_credits += len(labels)*(residual-z)+len(old_labels)*(old_budget-z)
            groups[y] = (labels | old_labels, z)
            merges += 1
    assert spent == actual_initial_cost
    assert merge_credits == slack and merges == 1
    assert spent+merge_credits+retired == naive
    return dict(name=seed["name"], original_source_count=2,
                checkpoint_depths=initial_indices, aligned_depths=aligned_indices,
                target_state=str(target), source_labels_retained=True,
                high_packing_L=L, high_packing_S=S,
                merge_credit_times_H_plus_1=enc_interval(slack*(H+1)),
                relative_merge_saving=enc_interval(slack/naive, bits=512),
                actual_remaining_cost_times_H_plus_1=enc_interval(actual_initial_cost*(H+1)),
                common_budget=enc_interval(common),
                actual_future_core_positive_times_H_plus_1=enc_interval(actual_charge*(H+1)),
                forest_advances=advances, forest_merges=merges,
                forest_identity=True, distinct_clock_depths=(initial_indices[0] != initial_indices[1]),
                source_rank_cells=rank_rows,
                scope="Four frozen genuine profiles; no future step beyond supplied words; original core masks imported unchanged.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE/"suffix_budget_transport_certificate.json")
    args = parser.parse_args()
    seed_path = HERE/"central_collision_seeds.json"
    data = json.loads(seed_path.read_text())
    families = [verify_family(x) for x in data["families"]]
    result = dict(status="PASS", fixture_sha256=hashlib.sha256(seed_path.read_bytes()).hexdigest(),
                  families=families, theorem="Multiplicity-preserving coalescent budget transport",
                  unresolved="Uniform bound for residual weighted cluster capacities across all sources.")
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status":"PASS", "families":len(families),
                      "source_profiles":4, "exact_merge_credits_positive":True}))


if __name__ == "__main__":
    main()
