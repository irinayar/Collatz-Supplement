#!/usr/bin/env python3
"""Exact controls for unused K188 caps on genuine completed returns.

Full word family at k=6; fixed sample words at k=33 and k=46. The infinite
incidence/rotation theorem is proved in the companion Markdown, not inferred
from these finite controls. Stops at each prescribed genuine return.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

if not __debug__:
    raise SystemExit('Do not use -O or -OO: assertions must remain enabled.')

R, D = (1, 2), (1, 1, 2)
r = F(193, 200)


def ceil_div(a, b):
    return -((-a)//b)


def make_word(choice, f):
    word = list(R)
    for bit in choice:
        word.extend(R+D if bit == 0 else D+R)
    return tuple(word+[f, 2])


def inverse_residue(word):
    E = U = 0
    for e in word:
        U = 3*U+2**E
        E += e
    M = 2**(E+1)
    residue = ((2**E-U)*pow(3**len(word), -1, M)) % M
    return E, M, residue


def replay(u, word, n, cut_M):
    H = (4*n-2)//3
    assert n & 1 and n <= u <= H
    cut_g = len(word)-1
    x = u
    states = [u]
    odd = [u]
    E = U = 0
    low = n
    cut = None
    for g, e in enumerate(word, 1):
        y = 3*x+1
        assert (y & -y).bit_length()-1 == e
        y //= 2
        states.append(y)
        for _ in range(e-1):
            assert y % 2 == 0
            y //= 2
            states.append(y)
        x = y
        odd.append(x)
        assert x & 1
        U = 3*U+2**E
        E += e
        q = F(U, 3**g)
        assert 2**E*x == 3**g*u+U
        if g <= cut_g:
            assert x > H
            assert q < 3
            low = max(low, (2**E*H-U)//3**g+1)
        else:
            assert n < x < u <= H
            assert q < 5
        if g == cut_g:
            M = 2**(E+1)
            assert M == cut_M
            residue = ((2**E-U)*pow(3**g, -1, M)) % M
            active_low = max(low, (32*q.numerator)//(15*q.denominator)+1)
            least = active_low+(residue-active_low) % M
            capacity = 0 if least > H else 1+(H-least)//M
            assert capacity == 1 and least == u
            lam = F(2**E, 3**g)
            assert F(4, 5) <= lam <= F(5, 6)
            assert F(6*u, 5) < x < F(5*(u+3), 4)
            assert F(1, x) < F(5, 24*M)
            assert q < F(15*u, 32)
            assert all(a >= u for a in odd[:-1])
            cut = dict(q=q, multiplier=lam, v=x, E=E,
                       past_odd_count=g, capacity=capacity)
    assert len(states) == E+1
    assert len(set(states)) == len(states)
    assert len(odd) == len(word)+1
    assert cut is not None
    assert (H+5)/F(9) < cut_M
    assert u-4*cut_M < n and u+4*cut_M > H
    assert F(9*u, 10) < odd[-1] < u
    assert q < 5
    cut.update(H=H, n=n, terminal=odd[-1], final_phase=q,
               core_positive_occurrences=0)
    return cut


def B(L, S):
    return F(3**S-1, 2**L)+F(200, 7)*r**(S+1)+F(L+1, 2**(L-1))


def case(k, f):
    Ecut = 3+7*k+f
    M = 2**(Ecut+1)
    lam = F(2**Ecut, 3**(3+5*k))
    assert F(4, 5) <= lam <= F(5, 6)
    assert 2 <= f <= k+2
    assert M >= 2**(7*k+6)
    full = k <= 6
    choices = list(product((0, 1), repeat=k)) if full else [
        tuple((j >> (i % 6)) & 1 for i in range(k)) for j in range(64)
    ]
    assert len(set(choices)) == len(choices)
    records = []
    for choice in choices:
        word = make_word(choice, f)
        E, full_M, residue = inverse_residue(word)
        assert E == Ecut+2 and full_M == 4*M
        u = 4*M+(residue-4*M) % (4*M)
        assert 4*M <= u < 8*M
        assert u % 16 == 11 and u <= 8*M-5
        b1 = (9*u+5)//8
        assert 8*b1 == 9*u+5
        lo = ceil_div(3*u+2, 4)
        hi = (3*b1+1)//4
        lo += (1-lo) % 2
        hi -= (hi-1) % 2
        assert lo <= hi
        assert (hi-lo)//2+1 >= M//8
        assert 3*M <= lo <= hi <= 7*M
        records.append(dict(word=word, u=u, lo=lo, hi=hi))
    assert len({z['u'] for z in records}) == len(records)
    events = defaultdict(int)
    for z in records:
        events[z['lo']] += 1
        events[z['hi']+2] -= 1
    running = maximum = 0
    n0 = None
    for n, delta in sorted(events.items()):
        running += delta
        if running > maximum:
            maximum = running
            n0 = n
    assert running == 0 and n0 is not None
    selected = [z for z in records if z['lo'] <= n0 <= z['hi']]
    assert len(selected) == maximum and 16*maximum >= len(records)
    max_phase = F(0)
    min_phase = F(5)
    largest_L = 0
    for z in selected:
        info = replay(z['u'], z['word'], n0, M)
        assert info['H'] <= 9*M-6
        L = (info['H']+1).bit_length()-1
        assert L <= Ecut+4 <= 8*k+9
        largest_L = max(largest_L, L)
        past_upper = F(3+5*k, z['u'])
        assert past_upper <= F(3+5*k, 4*M)
        assert past_upper <= r**(8*k+9)/2
        assert r**L-past_upper >= r**(8*k+9)/2
        assert F(1, info['v']) < F(5, 24*M)
        max_phase = max(max_phase, info['final_phase'])
        min_phase = min(min_phase, info['final_phase'])

    # Test the optimized scalar envelope only once per chosen finite sample.
    L = largest_L
    past_uniform_upper = F(3+5*k, 4*M)
    assert F(3**(2*L)-1, 2**L) > F(144, 125)
    cap_lower = min(F(144, 125), min(B(L, S) for S in range(2*L+1)))-past_uniform_upper
    assert cap_lower >= r**L-past_uniform_upper >= r**(8*k+9)/2
    theoretical_cap_sum_lower = r**9/F(32)*(2*r**8)**k
    actual_cost_upper = F(5*2**k, 24*M)
    assert actual_cost_upper <= F(5, 1536)*F(1, 2**(6*k))
    if k == 33:
        assert M == 2**267
        assert theoretical_cap_sum_lower > 16000
        assert actual_cost_upper < F(1, 10**71)
        assert 3*M >= 2**71 and 7*M < 2**272
    return dict(k=k, f=f, multiplier=str(lam), cut_modulus=str(M),
                total_theoretical_words=str(2**k),
                whole_family_enumerated=full,
                fixed_words_checked=len(records),
                selected_genuine_sample_profiles=maximum,
                sample_threshold=str(n0),
                sample_threshold_scope='Maximizes only the explicitly checked finite sample.',
                exact_singleton_cuts=True, final_phase_range=[str(min_phase),str(max_phase)],
                original_core_empty=True,
                theoretical_full_family_profile_count_lower=str(F(2**k,16)),
                theoretical_cap_sum_lower=str(theoretical_cap_sum_lower),
                cap_sum_lower_decimal_informational=float(theoretical_cap_sum_lower),
                actual_future_reciprocal_sum_upper=str(actual_cost_upper),
                actual_future_upper_decimal_informational=float(actual_cost_upper),
                research_floor_satisfied=n0 >= 2**71,
                below_2_to_272=n0 < 2**272,
                steps_after_prescribed_return=0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path('genuine_budget_obstruction_certificate.json'))
    args = parser.parse_args()
    assert 2*r**8 > F(3,2)
    assert F(3,256) < r**9/2
    assert F(8,3*128) < r**8
    assert F(319,115)+F(1024,6561) < 3
    assert F(3)+F(5,18) < 5
    assert 2**7 < 3**5 < 2**8 and 3**3 < 2**5
    cases = [case(k,f) for k,f in ((6,7),(33,32),(46,44))]
    result = dict(status='PASS', cases=cases,
                  exact_growth_base=str(2*r**8), growth_base_exceeds='3/2',
                  scope='Unused scalar caps on genuine completed returns; actual future costs tend to zero and original cores are empty.',
                  infinite_sequence_proof='Irrational rotation and exact incidence argument in companion note; not inferred from samples.',
                  steps_after_prescribed_return=0)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status':'PASS', 'fixed_words_checked':sum(z['fixed_words_checked'] for z in cases),
                      'genuine_profiles_replayed':sum(z['selected_genuine_sample_profiles'] for z in cases),
                      'scope':result['scope'], 'certificate':str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
