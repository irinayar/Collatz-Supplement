#!/usr/bin/env python3
"""Exact controls for the raw K188 scalar-cap aggregation obstruction.

Only prescribed finite prefixes are computed; no trajectory continuation or
source census is performed. The proof of unboundedness is in the companion MD.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Do not use -O or -OO: assertions must remain enabled.")

R = (1, 2)
D = (1, 1, 2)
r = F(193, 200)


def ceil_div(a, b):
    return -((-a)//b)


def word_data(choice):
    word = list(R)
    for bit in choice:
        word.extend(R + D if bit == 0 else D + R)
    E = U = 0
    for e in word:
        U = 3*U + 2**E
        E += e
    M = 2**(E+1)
    residue = ((2**E-U)*pow(3**len(word), -1, M)) % M
    assert residue & 1
    return tuple(word), E, U, M, residue


def replay(u, word, n):
    H = (4*n-2)//3
    assert n & 1 and n <= u <= H
    x = u
    odd = [u]
    all_states = [u]
    E = U = 0
    low = n
    max_q = F(0)
    for g, e in enumerate(word, 1):
        y = 3*x+1
        assert (y & -y).bit_length()-1 == e
        y //= 2
        all_states.append(y)
        for _ in range(e-1):
            assert y % 2 == 0
            y //= 2
            all_states.append(y)
        x = y
        odd.append(x)
        assert x & 1 and x > H
        U = 3*U+2**E
        E += e
        q = F(U, 3**g)
        assert q < F(319, 115) < 5
        assert q < F(15*u, 32)
        max_q = max(q, max_q)
        low = max(low, (2**E*H-U)//3**g+1)
        assert 2**E*x == 3**g*u+U
    assert len(all_states) == E+1
    assert len(all_states) == len(set(all_states))
    M = 2**(E+1)
    residue = ((2**E-U)*pow(3**len(word), -1, M)) % M
    low = max(low, (32*max_q.numerator)//(15*max_q.denominator)+1)
    least = low+(residue-low) % M
    capacity = 0 if least > H else 1+(H-least)//M
    assert capacity == 1 and least == u
    past = sum((F(1, a) for a in odd[:-1]), F(0))
    L = (H+1).bit_length()-1
    past_hi = sum((F(1, a) for a in odd[:-1] if a >= 2**L), F(0))
    assert past <= F(len(word), u)
    return dict(H=H, E=E, L=L, q=max_q, past=past,
                past_hi=past_hi, capacity=capacity)


def B(L, S):
    return F(3**S-1, 2**L)+F(200, 7)*r**(S+1)+F(L+1, 2**(L-1))


def exact_cap_control(info):
    L = info['L']
    # Beyond S=2L the first term is >144/125 and keeps increasing. Thus
    # those S cannot lower the min(144/125-past, B-past_hi) cap.
    assert F(3**(2*L)-1, 2**L) > F(144, 125)
    b_bound = min(B(L, S) for S in range(2*L+1))
    scalar = min(F(144, 125)-info['past'], b_bound-info['past_hi'])
    assert scalar >= r**L-info['past']
    return dict(optimized_scalar_cap=str(scalar),
                proven_lower_bound=str(r**L-info['past']),
                optimized_S_range=[0, 2*L])


def construction(k):
    records = []
    M = 2**(4+7*k)
    for choice in product((0, 1), repeat=k):
        word, E, U, word_M, residue = word_data(choice)
        assert E == 3+7*k and len(word) == 2+5*k and M == word_M
        u = 3*M//2 + (residue-3*M//2) % M
        assert 3*M//2 <= u < 5*M//2
        v = (9*u+5)//8
        assert 8*v == 9*u+5 and v & 1
        lo = ceil_div(3*u+2, 4)
        hi = (3*v+1)//4
        lo += (1-lo) % 2
        hi -= (hi-1) % 2
        assert lo & 1 and hi & 1 and lo <= hi
        assert M <= lo <= hi <= 9*M//4
        count = (hi-lo)//2+1
        assert count >= M//16
        records.append(dict(word=word, u=u, residue=residue, lo=lo, hi=hi))
    assert len(records) == len({z['residue'] for z in records}) == 2**k
    assert len({z['u'] for z in records}) == 2**k

    events = defaultdict(int)
    for z in records:
        events[z['lo']] += 1
        events[z['hi']+2] -= 1
    running = maximum = 0
    chosen = None
    for n, delta in sorted(events.items()):
        running += delta
        if running > maximum:
            maximum = running
            chosen = n
    assert running == 0 and chosen is not None
    chosen_records = [z for z in records if z['lo'] <= chosen <= z['hi']]
    assert len(chosen_records) == maximum
    assert 10*maximum >= 2**k
    assert chosen & 1 and M <= chosen <= 9*M//4
    H = (4*chosen-2)//3
    W = H-chosen
    assert W < 3*M//4 < M
    L = (H+1).bit_length()-1
    assert L <= 7*k+5

    past_bound = F(2*(2+5*k), 3*M)
    assert past_bound <= r**(7*k+5)/2
    assert r**L-past_bound >= r**(7*k+5)/2
    min_phase = F(5)
    max_phase = F(0)
    sample = None
    for z in chosen_records:
        info = replay(z['u'], z['word'], chosen)
        assert info['past'] <= past_bound
        min_phase = min(min_phase, info['q'])
        max_phase = max(max_phase, info['q'])
        if sample is None:
            sample = exact_cap_control(info)
    aggregate_lower = maximum*(r**L-past_bound)
    theorem_lower = r**5/F(20)*(2*r**7)**k
    assert aggregate_lower >= theorem_lower

    # The separate explicit-band family has exactly one source per word.
    n0 = 27*M//4-1
    H0 = (4*n0-2)//3
    assert H0 == 9*M-2
    assert (H0+1).bit_length()-1 == 7*k+7
    assert F(2+5*k, 8*M-1) < r**(7*k+7)/2
    for z in records:
        u0 = 8*M-1 + (z['residue']-(8*M-1)) % M
        assert 8*M-1 <= u0 <= 9*M-3
        replay(u0, z['word'], n0)

    return dict(k=k, word_count=len(records), total_exponent=3+7*k,
                odd_transition_count=2+5*k, modulus=str(M),
                late_threshold=str(chosen), H=str(H), W=str(W),
                active_singletons=maximum,
                count_lower_bound=str(F(2**k, 10)),
                after_width_resolution=True,
                phases=[str(min_phase), str(max_phase)],
                scalar_aggregate_lower_bound=str(aggregate_lower),
                theorem_lower_bound=str(theorem_lower),
                theorem_lower_decimal_informational=float(theorem_lower),
                sample_scalar_cap=sample,
                explicit_threshold=str(n0),
                explicit_singletons=len(records),
                research_floor_satisfied=chosen >= 2**71,
                future_steps_computed=0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path('raw_budget_obstruction_certificate.json'))
    args = parser.parse_args()
    assert 2*r**7 > F(3, 2)
    assert r**5 > F(4, 5)
    assert F(7, 2*128) < r**7
    assert F(2, 127) < r**7/2
    assert F(1, 12) < r**5/2
    assert F(5, 9)+F(8, 9)*F(287, 243)/(1-F(128, 243)) == F(319, 115)
    assert F(3, 4)*F(9, 8)**3 > 1
    assert F(3, 4)*F(27, 16) > 1
    assert F(421, 13) < 33
    cases = [construction(k) for k in (1, 2, 3, 4, 6, 8, 10)]
    result = dict(status='PASS', cases=cases,
                  rational_growth_base=str(2*r**7),
                  growth_base_exceeds='3/2',
                  finite_prefixes_only=True,
                  future_steps_computed=0,
                  scope='Unbounded scalar-cap sums on actual unresolved singleton prefix frontiers; no claim about genuine completions or actual core cost.')
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status':result['status'],
                      'constructed_words':sum(z['word_count'] for z in cases),
                      'late_singletons_replayed':sum(z['active_singletons'] for z in cases),
                      'k10_active_singletons':cases[-1]['active_singletons'],
                      'future_steps_computed':0,
                      'certificate':str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
