from itertools import combinations
from functools import lru_cache
from collections import Counter
import json
@lru_cache(None)
def H(x,k,r):
 if k==r==0:return x
 z=[]
 if k:
  t=H(2*x,k-1,r)
  if t is not None:z.append(t)
 if r and x%3==2:
  t=H((2*x-1)//3,k,r-1)
  if t is not None:z.append(t)
 return min(z) if z else None

def candidates(x,k,r):
 L=k+r; mod=3**r; A=2**L*x
 out=[]; validmod=0;positive=0
 for pos in combinations(range(L),r):
  V=0
  for i in range(L):
   if i in pos: V=3*V+2**i
  if (A-V)%mod==0:
   validmod+=1
   m=(A-V)//mod
   if m>0:
    positive+=1
    out.append((m,V,pos))
 return out,validmod,positive

cases=[]
for k in range(9):
 for r in range(7):
  for x in range(3,3**(r+1)+3):
   m=H(x,k,r);n=H(x,k,r+1)
   if m is None or n is None or m%3==2 or (k>=1 and m>=2**(k+1)-3):continue
   old,_,_=candidates(x,k,r)
   new,modhits,positive=candidates(x,k,r+1)
   assert min(t[0] for t in old)==m
   assert min(t[0] for t in new)==n
   target=3*(2**(k+r)*x-3**r*m)-2**(k+r)*x
   winners=[t for t in new if t[1]>target]
   assert winners and min(t[0] for t in winners)==n
   cases.append({'x':x,'k':k,'r':r,'m':m,'n':n,'total_words':len(list(combinations(range(k+r+1),r+1))), 'mod_hits':modhits,'positive':positive,'winners':len(winners),'target':target,'best_numerator':max(t[1] for t in new),'margin':max(t[1] for t in new)-target})
assert len(cases)==56
print('cases',len(cases))
for field in ['total_words','mod_hits','positive','winners','margin']:
 vals=[c[field] for c in cases];print(field,'sum',sum(vals),'min',min(vals),'max',max(vals))
print('winners distribution',dict(sorted(Counter(c['winners'] for c in cases).items())))
print('fewest winners',[(c['x'],c['k'],c['r'],c['winners'],c['positive']) for c in cases if c['winners']==1][:20])
print('margin divisibility',all(c['margin']%3**(c['r']+1)==0 for c in cases))
with open('/mnt/data/shifted_target_56_results.json','w') as f:json.dump(cases,f,indent=2)
