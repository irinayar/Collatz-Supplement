from itertools import combinations
from shifted_target_experiment import H
import json
cases=json.load(open('/mnt/data/shifted_target_56_results.json'))
checked=0
for c in cases:
 x,k,r,m=c['x'],c['k'],c['r'],c['m'];L=k+r+1
 for pos in combinations(range(L),r+1):
  V=0
  for i in range(L):
   if i in pos:V=3*V+2**i
  if (2**L*x-V)%3**(r+1):continue
  a=(2**L*x-V)//3**(r+1)
  if a<=0:continue
  z=a
  for i in range(L):
   if i in pos:
    assert z%2==1
    z=(3*z+1)//2
   else:
    assert z%2==0
    z//=2
  assert z==x and a<m
  checked+=1
assert checked==192
print('independent forward parity verification',checked,'candidates passed')
