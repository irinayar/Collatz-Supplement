#!/usr/bin/env python3
"""Exact arithmetic controls for the all-length weighted positive-profile sum.

This checks the constants and finite algebra in the attached analytic proof.
It does not enumerate all return profiles or prove Collatz convergence.
"""
from fractions import Fraction as Q
import json


def odd_step(u):
    v=3*u+1
    e=(v&-v).bit_length()-1
    return v>>e,e


def small_band_exclusions():
    certificates=[]
    for n in (3,5,7,9):
        H=(4*n-2)//3
        for u in range(n,H+1,2):
            states=[u]
            z=u
            while True:
                z,e=odd_step(z)
                states.append(z)
                assert z not in states[:-1], (n,u,states)
                if z<n:
                    break
                assert z>H, (n,u,states)
            certificates.append({'n':n,'H':H,'source':u,'states':states})
    return certificates


def generating_mass(g,z=Q(3,4)):
    """Exact sum of 2^(-E) z^E over e1=1, eg>=2, other exponents>=1."""
    assert g>=2
    return (z/2)*(z/(2-z))**(g-2)*(z*z/(2*(2-z)))


def check():
    f=Q(34,33)
    z=Q(3,4)
    slope=3*f
    assert slope==Q(34,11)
    slope_margin=2**18*11**11-34**11
    assert slope_margin>0
    beta11=Q(34,55)**11*Q(4,3)**18
    assert beta11==Q(4823340607510508017102618624,5397245456324245545849609375)
    assert beta11<1
    assert Q(1,3)/(f-1)==11
    assert Q(11)+Q(20,3)==Q(53,3)
    assert Q(53,18)*Q(4,3)*Q(15,64)==Q(265,288)
    for g in range(2,101):
        assert generating_mass(g)==Q(15,64)*Q(3,5)**g
    # Entire sum from g>=2: regroup into blocks 11q+r, and beta<1.
    # This rational ceiling is deliberately coarse but avoids irrational arithmetic.
    prefactor=Q(265,288)
    rational_total_ceiling=prefactor*11/(1-beta11)
    assert rational_total_ceiling>0
    return {
        'scope':'all-length analytic density-weighted positive-profile sum; no uniform trajectory product bound',
        'small_band_exclusions':small_band_exclusions(),
        'f':str(f),
        'z':str(z),
        'power_slope_margin':slope_margin,
        'beta_power':11,
        'beta11':str(beta11),
        'beta11_below_one_margin':beta11.denominator-beta11.numerator,
        'coefficient':str(prefactor),
        'generating_function_checks':99,
        'rational_total_ceiling':str(rational_total_ceiling),
        'exact_tail_bound':'For M>=2, sum_(g>=M) T_g <= (265/288)*11*beta11^floor(M/11)/(1-beta11).',
    }


if __name__=='__main__':
    result=check()
    print(json.dumps(result,indent=2))
