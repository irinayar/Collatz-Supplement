#!/usr/bin/env python3
"""Rebuild every new exact certificate with the Python standard library.

Run: python3 verify_all.py
Analytic arguments, stated hypotheses and limitations are in the report.
These certificates verify finite reductions, not the Collatz conjecture.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json
import time

import audit_residues_and_sources as audits
import boundary_family_examples as boundary
import verify_eight_returns as eight
import verify_eight_tail as mixed
import verify_primitive_cycle_obstructions as cycles
import weighted_sum_certificate as density


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,
                        default=Path(__file__).with_name('certificates'))
    args=parser.parse_args()
    out=args.output_dir
    out.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    certificates={}
    certificates['eight_returns']=eight.classify()
    certificates['supplied_note_audit']=audits.note_audit()
    certificates['fixed_band_source_intervals']=audits.source_audit(certificates['eight_returns'])
    certificates['all_length_density']=density.check()
    examples=[x for g in range(3,61) if (x:=boundary.example(g)) is not None]
    assert len(examples)==19
    certificates['boundary_family_examples']=dict(
        scope='Finite controls of the analytic infinite-family proof.',
        count=len(examples),examples=examples)
    certificates['mixed_eight_tail']=mixed.certify()
    certificates['primitive_cycle_obstructions']=cycles.certify()
    graphs=certificates['primitive_cycle_obstructions']
    g7=graphs['finite_short_graph_certificates']
    g8=graphs['separate_gap8_graph_certificates']
    assert sum(len(row['edges']) for row in g8)==6580
    assert max(row['maximum_rank'] for row in g8)==3
    # Certificate-level consistency with the full eight-return classification.
    allowed8={tuple(row['word']) for row in certificates['eight_returns']['profiles']
              if row['witness']}
    for graph in g8:
        for edge in graph['edges']:
            if edge['gap']==8:
                assert tuple(edge['valuations']) in allowed8
            assert edge['source_rank']>edge['arrival_rank']
    for name,certificate in certificates.items():
        (out/(name+'.json')).write_text(json.dumps(certificate,indent=2)+'\n',encoding='utf-8')
    m=certificates['mixed_eight_tail']
    summary=dict(status='PASS',
                 scope='Theorems and conditional bounds stated in the companion report; no universal Collatz proof.',
                 eight_return_profiles=85,eight_excluded_profiles=125,
                 residue_representatives=8192,
                 all_length_density_beta11=certificates['all_length_density']['beta11'],
                 finite_threshold_charge_checks=m['finite_count'],
                 completed_uniform_upper=m['completed_max']['completed_bound'],
                 tail_t_at_most_n_uniform_upper=m['tail_max']['tail_t_eq_n_bound'],
                 finite_graph_thresholds=len(g7),finite_graph_vertices=48690,
                 gap7_graph_edges=sum(len(row['edges'])for row in g7),
                 gap8_graph_edges=sum(len(row['edges'])for row in g8),
                 restricted_cycle_necessary_conditions=graphs['necessary_conditions'],
                 source_interval_controls=certificates['fixed_band_source_intervals']['source_witnesses'],
                 finite_boundary_family_controls=len(examples))
    assert Q(summary['completed_uniform_upper'])<Q(11,10)
    assert Q(summary['tail_t_at_most_n_uniform_upper'])<Q(3,2)
    (out/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('Rebuilt certificates in',out)
    print('Elapsed seconds (informational):',round(time.perf_counter()-start,3))


if __name__=='__main__':
    main()
