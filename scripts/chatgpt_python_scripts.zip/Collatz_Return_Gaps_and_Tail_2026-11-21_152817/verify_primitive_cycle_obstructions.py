#!/usr/bin/env python3
"""Necessary obstructions for cycles whose low-band returns have gaps <=7.

No claim of universal cycle exclusion. No long-orbit search: every local source
is followed for at most seven accelerated odd transitions. All comparisons use
integers or Fraction. Previous classification of gaps 2,3,4,5,7 is assumed and
checked on each encountered local return.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json


def odd_step(u):
    z = 3*u + 1
    exponent = (z & -z).bit_length() - 1
    return z >> exponent, exponent


def local_edges(n,maximum_gap=7):
    high = (4*n - 2)//3
    assert maximum_gap in (7,8)
    allowed=(2,3,4,5,7) if maximum_gap==7 else (2,3,4,5,7,8)
    result = {g: [] for g in allowed}
    for source in range(n, high+1, 2):
        state = source
        exponent = 0
        valuations = []
        for gap in range(1,maximum_gap+1):
            state, e = odd_step(state)
            valuations.append(e)
            exponent += e
            if state <= high:
                if state >= n:
                    assert gap in result
                    assert exponent == {2:3,3:5,4:6,5:8,7:11,8:13}[gap]
                    rho = Q((1 << exponent)*(state+5), 3**gap*(source+5))
                    if gap == 2:
                        assert rho == 1
                    elif gap == 4:
                        assert rho < 1
                    else:
                        assert rho > 1
                        if gap<=7:
                            assert rho <= 1+Q(16,9*(n+5))
                    result[gap].append((rho, source, state, tuple(valuations)))
                break
    for gap in result:
        result[gap].sort(reverse=True)
    return result


def fixed_k_bound(k):
    # R parity equals K parity, R>=3K, and a positive cycle requires
    # (2^E/3^R)^2 = 2^K*(8/9)^R > 1.
    r_max = 3*k
    assert (1 << k)*8**r_max > 9**r_max
    while (1 << k)*8**(r_max+2) > 9**(r_max+2):
        r_max += 2
    e_max = (3*r_max+k)//2
    minimum_cycle_factor = Q(1 << e_max, 3**r_max)
    tail_threshold = 3
    while (1+Q(16,9*(tail_threshold+5)))**k >= minimum_cycle_factor:
        tail_threshold += 2
    return r_max, e_max, minimum_cycle_factor, tail_threshold


def candidate_count_vectors(n, k, edges):
    r_max, _, _, _ = fixed_k_bound(k)
    capacities = {g: len(rows) for g,rows in edges.items()}
    prefix_products = {}
    for gap in (3,5,7):
        prefix_products[gap] = [Q(1)]
        for rho,_,_,_ in edges[gap]:
            prefix_products[gap].append(prefix_products[gap][-1]*rho)
    examined = 0
    best_ratio = Q(0)
    passing = []
    for a3 in range(min(k,capacities[3])+1):
        for a5 in range(min(k-a3,capacities[5])+1):
            a7 = k-a3-a5
            if a7 > capacities[7]:
                continue
            upper = (prefix_products[3][a3]*prefix_products[5][a5]
                     *prefix_products[7][a7])
            base_r = 3*a3+5*a5+7*a7
            for a2 in range(capacities[2]+1):
                for a4 in range(capacities[4]+1):
                    r = base_r+2*a2+4*a4
                    if r > r_max:
                        continue
                    e = 3*a2+5*a3+6*a4+8*a5+11*a7
                    assert 2*e == 3*r+k
                    factor = Q(1 << e,3**r)
                    if factor <= 1:
                        continue
                    examined += 1
                    best_ratio = max(best_ratio,upper/factor)
                    if factor <= upper:
                        passing.append(dict(n=n, counts={2:a2,3:a3,4:a4,5:a5,7:a7},
                                            R=r,E=e,cycle_factor=str(factor),
                                            relaxed_charge_upper=str(upper)))
    return examined,best_ratio,passing


def affine(word):
    B=E=0
    for e in word:
        B=3*B+(1<<E)
        E+=e
    return 3**len(word),1<<E,B,E


def repeated_word_control():
    words=[(1,2),(1,1,3),(1,2,2),(1,1,1,3),
           (1,1,2,2),(1,1,1,1,4),(1,2,1,1,1,2,3)]
    checked=0
    for word in words:
        a,d,B,E=affine(word)
        D=d-a
        for copies in range(1,5):
            extended=word*copies
            ar,dr,Br,Er=affine(extended)
            modulus=1<<(Er+1)
            x0=(((1<<Er)-Br)*pow(ar,-1,modulus))%modulus
            assert x0>0 and x0%2
            x=x0
            for e in extended:
                x,actual=odd_step(x)
                assert actual==e
            left=d**copies*(D*x-B)
            right=a**copies*(D*x0-B)
            assert left==right
            defect=D*x0-B
            assert defect%(1<<(copies*E+1))==0
            if defect:
                assert abs(defect)>=(1<<(copies*E+1))
            checked+=1
    # Trivial cycle is a CONTROL of the zero-defect exception, not a candidate.
    a,d,B,E=affine((2,))
    assert (d-a)*1-B==0
    return checked


def short_return_graph_certificate(n, edges):
    """Complete graph for the supplied gap cutoff, not all later returns."""
    labelled = {u: (v,gap,word) for gap,rows in edges.items()
                for _,u,v,word in rows}
    ranks = {}
    for source in labelled:
        trail = []
        visited = set()
        state = source
        while state in labelled and state not in ranks:
            assert state not in visited, (n, 'directed cycle', trail, state)
            visited.add(state)
            trail.append(state)
            state = labelled[state][0]
        rank = ranks.get(state,0)
        for source_on_trail in reversed(trail):
            rank += 1
            ranks[source_on_trail] = rank
    rows=[]
    for u,(v,gap,word) in sorted(labelled.items()):
        assert ranks[u] == 1+ranks.get(v,0)
        rows.append(dict(source=u,arrival=v,gap=gap,valuations=word,
                         source_rank=ranks[u],arrival_rank=ranks.get(v,0)))
    high=(4*n-2)//3
    return dict(n=n,H=high,vertices=(high-n)//2+1,edges=rows,
                maximum_rank=max(ranks.values(),default=0))


def certify():
    edge_cache={}
    thresholds=[]
    for k in range(1,16):
        r_max,e_max,lower,threshold=fixed_k_bound(k)
        assert threshold<=1081
        thresholds.append(dict(K=k,R_max=r_max,E_at_R_max=e_max,
                               cycle_factor_lower=str(lower),
                               large_n_exclusion_from=threshold))
    graph_rows=[]
    for n in range(3,1081,2):
        edges=edge_cache.setdefault(n,local_edges(n))
        graph_rows.append(short_return_graph_certificate(n,edges))
    assert len(graph_rows)==539
    assert sum(row['vertices']for row in graph_rows)==48690
    assert sum(len(row['edges'])for row in graph_rows)==6435
    assert max(row['maximum_rank']for row in graph_rows)==3
    eight_graph_rows=[short_return_graph_certificate(n,local_edges(n,8))
                      for n in range(3,1081,2)]
    assert len(eight_graph_rows)==539
    assert sum(row['vertices']for row in eight_graph_rows)==48690
    # K>=16, R<=93 has minimum possible cycle factors according to R parity.
    assert Q(1<<146,3**92)>Q(11,10)
    assert Q(1<<148,3**93)>Q(11,10)
    # The count-and-charge relaxation alone leaves a false candidate;
    # exact ordering is certified acyclic on that same n=523 graph.
    n=523
    _,_,passing=candidate_count_vectors(n,7,local_edges(n))
    assert passing
    first=passing[0]
    assert first['R']==41 and first['E']==65
    matching_graph=next(row for row in graph_rows if row['n']==523)
    first['exact_graph_acyclic']=True
    first['exact_graph_maximum_rank']=matching_graph['maximum_rank']
    return dict(scope='Primitive positive cycle composed entirely of first '
                      'low-band returns with gaps 2,3,4,5,7. No cycle asserted.',
                all_K_1_to_15_excluded=True,
                analytic_thresholds=thresholds,
                finite_short_graph_certificates=graph_rows,
                separate_gap8_graph_certificates=eight_graph_rows,
                necessary_conditions=dict(K_at_least=16,R_at_least=94,
                                          E_at_least=149,n_at_least=1081),
                count_relaxation_false_candidate=first,
                repeated_word_identity_controls=repeated_word_control())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,
                        default=Path('primitive_cycle_obstruction_certificate.json'))
    args=parser.parse_args()
    result=certify()
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='PASS',K_1_to_15_excluded=True,
                          necessary_conditions=result['necessary_conditions'],
                          finite_short_graphs=len(result['finite_short_graph_certificates']),
                          graph_vertices=48690,short_return_edges=6435,
                          separate_gap8_graph_edges=sum(len(row['edges'])for row in result['separate_gap8_graph_certificates']),
                          separate_gap8_maximum_rank=max(row['maximum_rank']for row in result['separate_gap8_graph_certificates']),
                          count_relaxation_false_candidate=result['count_relaxation_false_candidate'],
                          repeated_word_identity_controls=result['repeated_word_identity_controls'],
                          certificate=str(args.output)),indent=2))


if __name__=='__main__':
    main()
