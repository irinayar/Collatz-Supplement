#!/usr/bin/env python3
"""Exact finite examples of the analytic infinite boundary-divergence family."""
from fractions import Fraction as Q
import json


def odd_step(u):
    z=3*u+1
    e=(z&-z).bit_length()-1
    return z>>e,e


def example(g):
    a=3**g
    E=a.bit_length()  # 2^E is strictly larger than odd a.
    d=1<<E
    if not (4*d<5*a):
        return None
    last=E-g+1
    if last<2:return None
    B=a-2**g
    modulus=1<<(E+1)
    residue=((d-B)*pow(a,-1,modulus))%modulus
    assert residue%2==1
    for t in range(100):
        u=residue+modulus*t
        w=(a*u+B)//d
        lo=(3*u+5)//4
        if lo%2==0:lo+=1
        if w>=lo and w<u:
            n=lo;H=(4*n-2)//3
            z=u;states=[u]
            es=[]
            for _ in range(g):
                z,e=odd_step(z);states.append(z);es.append(e)
            assert es==[1]*(g-1)+[last]
            assert z==w and n<=u<=H and n<=w<=H
            assert all(x>H for x in states[1:-1])
            c=Q(B+5*(d-a),a)
            assert c>Q(5,9)
            return {'g':g,'E':E,'last_exponent':last,'D':str(Q(d,a)),
                    'residue':residue,'modulus':modulus,'source':u,'arrival':w,
                    'n':n,'H':H,'c':str(c),'lift':t}
    raise AssertionError(('no witness within construction range',g))

if __name__=='__main__':
    examples=[x for g in range(3,61) if (x:=example(g))]
    print(json.dumps({'count':len(examples),'scope':'finite controls of analytic infinite-family theorem','examples':examples},indent=2))
