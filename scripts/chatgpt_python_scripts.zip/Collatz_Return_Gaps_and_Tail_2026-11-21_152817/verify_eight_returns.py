#!/usr/bin/env python3
"""Complete exact eight-return classification and fixed-band residue intervals.

Standard library only.  The companion report proves the unbounded-exponent
reduction; this program checks its constants, every residual case, all 210
valuation profiles, and an independent scan of all odd residues modulo 16384.
It does not infer a universal Collatz theorem from bounded trajectories.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json


def odd_step(u):
    z = 3 * u + 1
    e = (z & -z).bit_length() - 1
    return z >> e, e


def compositions(total, minima):
    if len(minima) == 1:
        if total >= minima[0]:
            yield (total,)
        return
    for e in range(minima[0], total - sum(minima[1:]) + 1):
        for tail in compositions(total - e, minima[1:]):
            yield (e,) + tail


def affine_prefixes(word):
    E = B = 0
    rows = []
    for j, e in enumerate(word, 1):
        B = 3 * B + (1 << E)
        E += e
        rows.append((3 ** j, B, 1 << E))
    return rows


def replay(u, length):
    states, word = [u], []
    for _ in range(length):
        u, e = odd_step(u)
        states.append(u)
        word.append(e)
    return states, tuple(word)


def ceil_div(a, b):
    assert b > 0
    return -((-a) // b)


def source_interval(n, word):
    """Exact first-return sources: residue r mod M intersected with [L,U]."""
    assert n >= 3 and n % 2
    H = (4 * n - 2) // 3
    aff = affine_prefixes(word)
    A, B, D = aff[-1]
    M = 2 * D
    r = ((D - B) * pow(A, -1, M)) % M
    lower = max([n, ceil_div(D * n - B, A)] +
                [(d * H - b) // a + 1 for a, b, d in aff[:-1]])
    upper = min(H, (D * H - B) // A)
    first = r + M * ceil_div(lower - r, M)
    return dict(n=n, H=H, lower=lower, upper=upper, modulus=M,
                residue=r, first=first if first <= upper else None)


def threshold_interval(states):
    u, w = states[0], states[-1]
    lo = max(3, ceil_div(3 * max(u, w) + 2, 4))
    hi = min(u, w, min((3 * x + 1) // 4 for x in states[1:-1]))
    lo += (lo % 2 == 0)
    hi -= (hi % 2 == 0)
    return lo, hi


def classify():
    # E<=12 has slope exceeding the endpoint ratio 4/3.
    assert Q(6561, 4096) > Q(4, 3)
    # Bmax(E)=3645+665*2^(E-7), attained by (1,E-8,1,1,1,1,1,2).
    assert 3 ** 7 + 2 * 3 ** 6 == 3645
    assert sum(3 ** (5 - j) * 2 ** j for j in range(6)) == 665
    assert 18015 * 9 - 157501 > 0  # all E>=15, u>=9 excluded.
    assert (80573 // 5727) == 14  # E14: odd u<=13.
    small_totals = []
    for u in (3, 5, 7, 9, 11, 13):
        states, word = replay(u, 8)
        E = sum(word)
        assert E != 14
        small_totals.append(dict(u=u, total=E, word=word, states=states))
    assert [x['total'] for x in small_totals] == [17, 18, 17, 17, 18, 19]
    # All bands admitting u<=7, regardless of exponent, are excluded directly.
    tiny = []
    for n in (3, 5, 7, 9):
        H = (4 * n - 2) // 3
        for u in range(n, H + 1, 2):
            states = [u]
            v = u
            while True:
                v, _ = odd_step(v)
                states.append(v)
                if v < n:
                    break
                assert v > H and v not in states[:-1]
            tiny.append(dict(n=n, u=u, states=states))

    rows = []
    for tail in compositions(12, [1] * 6 + [2]):
        word = (1,) + tail
        aff = affine_prefixes(word)
        A, B, D = aff[-1]
        assert (A, D) == (6561, 8192)
        M = 2 * D
        r = ((D - B) * pow(A, -1, M)) % M
        states, actual = replay(r, 8)
        assert actual == word and all(x > 0 and x % 2 for x in states)
        exclusions = []
        for j, (a, b, d) in enumerate(aff[:-1], 1):
            for target, at, bt, dt in [('departure', 1, 0, 1),
                                      ('arrival', A, B, D)]:
                slope = at * d - a * dt
                intercept = bt * d - b * dt
                # target - proper state >=0 for EVERY positive lift r+k*M.
                if slope >= 0 and slope * r + intercept >= 0:
                    exclusions.append(dict(prefix=j, target=target, slope=slope,
                                           intercept=intercept,
                                           margin=slope * r + intercept))
        lo, hi = threshold_interval(states)
        witness = None
        if lo <= hi:
            H = (4 * lo - 2) // 3
            assert lo <= r <= H and lo <= states[-1] <= H
            assert all(x > H for x in states[1:-1])
            interval = source_interval(lo, word)
            assert interval['first'] is not None
            assert interval['lower'] <= r <= interval['upper']
            witness = dict(n=lo, H=H, u=r, w=states[-1], states=states)
        assert bool(exclusions) != bool(witness), (word, r)
        rows.append(dict(word=word, B=B, residue=r, modulus=M,
                         charge_num=B + 8155, charge_den=6561,
                         exclusions=exclusions, witness=witness))

    assert len(rows) == 210
    retained = [row for row in rows if row['witness']]
    assert len(retained) == 85
    assert len(rows) - len(retained) == 125
    assert min(row['B'] for row in retained) == 6305
    assert max(row['B'] for row in retained) == 13349
    assert min(row['residue'] for row in retained) == 207
    assert min(row['charge_num'] for row in retained) == 14460
    assert max(row['charge_num'] for row in retained) == 21504
    assert sum(row['charge_num'] for row in retained) == 1499376
    assert min(1631 * row['residue'] - row['B'] for row in retained) == 327680
    expected = {tuple(row['word']): row['residue'] for row in rows}
    observed = {}
    for u in range(1, 16384, 2):
        _, word = replay(u, 8)
        if sum(word) == 13 and word[0] == 1 and word[-1] >= 2:
            assert word not in observed
            observed[word] = u
    assert observed == expected
    return dict(scope='Complete eight-transition first returns; not a global Collatz proof.',
                total_valuation=13, candidates=210, excluded=125, retained=85,
                E14_controls=small_totals, small_band_exclusions=tiny,
                independent_odd_residues_checked=8192,
                total_positive_coefficient=str(Q(1499376, 6561)), profiles=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('eight_return_certificate.json'))
    args = parser.parse_args()
    certificate = classify()
    args.output.write_text(json.dumps(certificate, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: certificate[key] for key in
                      ('candidates', 'excluded', 'retained', 'total_valuation',
                       'independent_odd_residues_checked', 'total_positive_coefficient')}, indent=2))


if __name__ == '__main__':
    main()
