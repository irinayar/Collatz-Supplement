#!/usr/bin/env python3
"""Exact certificate for <=n unfinished-tail odd inputs after short-return chains.

Python standard library only.  No Collatz convergence assumption is made.
The analytic n>=1023 argument is in the companion mathematical note.
"""
from fractions import Fraction as Q
from pathlib import Path
import json


def weak_compositions(total, slots):
    if slots == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for rest in weak_compositions(total - first, slots - 1):
            yield (first,) + rest


def affine_numerator(word):
    E = B = 0
    for e in word:
        B = 3 * B + (1 << E)
        E += e
    return E, B


def odd_step(u):
    v = 3 * u + 1
    e = (v & -v).bit_length() - 1
    return v >> e, e


def positive_classes():
    classes = [(55, 64, Q(44, 27)), (43, 64, Q(48, 27))]
    classes += [(r, 512, Q(B + 65, 243)) for B, r in
                [(211, 95), (227, 175), (259, 335), (251, 295),
                 (283, 455), (287, 219), (319, 379)]]
    seven = []
    for extras in weak_compositions(3, 6):
        word = (1,) + tuple(x + 1 for x in extras[:-1]) + (extras[-1] + 2,)
        # Every proper suffix must contract for a genuine first return.
        if any(3 ** (7 - j) >= 2 ** sum(word[j:]) for j in range(1, 7)):
            continue
        E, B = affine_numerator(word)
        assert E == 11
        residue = ((2 ** E - B) * pow(3 ** 7, -1, 2 ** (E + 1))) % 2 ** (E + 1)
        u = residue
        for e in word:
            u, actual = odd_step(u)
            assert actual == e
        seven.append((residue, 4096, Q(B - 695, 2187)))
    assert len(seven) == 30
    classes += seven
    assert len(classes) == 39
    return classes


CLASSES = positive_classes()


def positive_budget(n):
    H = (4 * n - 2) // 3
    total = Q(0)
    for r, modulus, coefficient in CLASSES:
        first = r + max(0, (n - r + modulus - 1) // modulus) * modulus
        for u in range(first, H + 1, modulus):
            total += coefficient / (u + 5)
    return total


def least_high(n):
    H = (4 * n - 2) // 3
    u = H + 1
    if u % 2 == 0:
        u += 1
    while u % 3 == 0:
        u += 2
    return u


def ceiling(q):
    return -((-q.numerator) // q.denominator)


def basic_bound(n, tail_inputs):
    """For tail_inputs>=2; t=0,1 are bounded directly by K(n)."""
    assert tail_inputs >= 2
    H = (4 * n - 2) // 3
    h = least_high(n)
    S = positive_budget(n)
    assert S < 1
    K = Q(n + 5, n) * Q(9 * H + 5, 9 * (H + 5)) / (1 - S)
    q = Q(tail_inputs - 2, 3 * h)
    assert q < 1
    return K / (1 - q), K, S, h


def main():
    records = []
    for n in range(3, 1023, 2):
        bound, K, S, h = basic_bound(n, n)
        assert bound < Q(3, 2)
        allowance = ceiling(2 + 3 * h - 2 * h * K) - 1
        assert allowance >= n
        assert 3 * h >= 4 * n - 1
        records.append({'n': n, 'h': h, 'S': str(S), 'K': str(K),
                        'tail_input_limit_checked': n,
                        'rational_bound': str(bound),
                        'explicit_allowance': allowance})
    maximum = max(records, key=lambda row: Q(row['rational_bound']))
    assert maximum['n'] == 43
    assert Q(maximum['rational_bound']) == Q(24325110, 16899989)

    alpha = sum((c / (3 * M) for r, M, c in CLASSES), Q(0))
    beta = sum((c for r, M, c in CLASSES), Q(0))
    assert alpha == Q(176525, 6718464)
    assert beta == Q(92228, 2187)
    assert beta > 5 * alpha
    N = 1023
    large_S = (alpha * N + beta) / (N + 5)
    large = Q(4, 3) * Q(N + 5, N) / (1 - large_S)
    assert large == Q(116871856128, 81368554883)
    assert large < Q(maximum['rational_bound']) < Q(3, 2)

    certificate = {'scope': 'completed gaps 2,3,4,5,7; distinct positive-charge departures; tail_inputs<=n',
                   'positive_classes': [{'residue': r, 'modulus': M, 'coefficient': str(c)}
                                        for r, M, c in CLASSES],
                   'small_rows': records, 'small_maximum': maximum,
                   'alpha': str(alpha), 'beta': str(beta),
                   'large_start_cutoff': N, 'large_bound': str(large),
                   'global_bound': str(Q(maximum['rational_bound']))}
    path = Path(__file__).with_name('linear_tail_certificate.json')
    path.write_text(json.dumps(certificate, indent=2) + '\n')
    print(json.dumps({'small_thresholds': len(records), 'small_maximum': maximum,
                      'large_bound': str(large), 'passed': True}, indent=2))


if __name__ == '__main__':
    main()
