#!/usr/bin/env python3
"""Independent exact checks for the supplied notes and fixed-band interval map.

The interval formula has an all-word algebraic proof in the report.  Its finite
controls below check strict endpoints, residue lifts, uniqueness, and actual
valuation order. They are not an extrapolation to unrestricted trajectories.
"""
from fractions import Fraction as Q
from verify_eight_returns import (affine_prefixes, classify, compositions,
                                  odd_step, source_interval)
from verify_linear_tail import positive_classes, affine_numerator, weak_compositions
from verify_eight_tail import eight_classes


def note_audit():
    margins = {}
    for length, total, slope, offset, count, expected_min in [
            (6, 10, 39, 512, 35, 4864),
            (7, 12, 885, 2048, 126, 105472)]:
        rows = []
        for tail in compositions(total - 1, [1] * (length - 2) + [2]):
            word = (1,) + tail
            a, B, d = affine_prefixes(word)[-1]
            modulus = 2 * d
            r = ((d - B) * pow(a, -1, modulus)) % modulus
            margin = slope * r - B + offset
            assert margin > 0
            rows.append(dict(word=word, residue=r, B=B, margin=margin))
        assert len(rows) == count and min(x['margin'] for x in rows) == expected_min
        margins[str(length)] = dict(count=count, minimum_margin=expected_min, rows=rows)

    old_classes = positive_classes()
    maximum, max_n = Q(0), None
    product_rows = []
    for n in range(3, 511, 2):
        H = (4 * n - 2) // 3
        value = Q((n + 5) * H, n * (H + 5))
        for r, modulus, c in old_classes:
            first = n + (r - n) % modulus
            for u in range(first, H + 1, modulus):
                value *= 1 + c / (u + 5)
        product_rows.append(dict(n=n, envelope=str(value)))
        if value > maximum:
            maximum, max_n = value, n
    assert (maximum, max_n) == (Q(10436608, 9560835), 43)
    C = Q(64148, 2187)
    n = 511
    S = Q(25, 972) + C / 12288 + (Q(1184, 81) + C) / (n + 5)
    large = Q(4 * (n + 5), 4 * n + 15) / (1 - S)
    assert large == Q(596277116928, 527450457635) < Q(32, 27)
    return dict(source_notes=['From-Claude_2026-11-21_144343.md',
                              'From-Codex_2026-11-21_144402.md'],
                residue_exclusions=margins,
                K139_finite_rows=product_rows, K139_maximum=str(maximum),
                K139_maximizing_n=max_n, K139_analytic_constant=str(large),
                scope='Arithmetic/profile audits only; source-reported large scans not rerun.')


def source_audit(eight_certificate=None):
    if eight_certificate is None:
        eight_certificate = classify()
    old_words = [(1, 1, 3), (1, 2, 2),
                 (1, 1, 1, 1, 4), (1, 1, 1, 2, 3),
                 (1, 1, 1, 3, 2), (1, 1, 2, 1, 3),
                 (1, 1, 2, 2, 2), (1, 2, 1, 1, 3), (1, 2, 1, 2, 2)]
    for extras in weak_compositions(3, 6):
        word = (1,) + tuple(x + 1 for x in extras[:-1]) + (extras[-1] + 2,)
        if all(3 ** (7 - j) < 2 ** sum(word[j:]) for j in range(1, 7)):
            old_words.append(word)
    eight = [row for row in eight_certificate['profiles'] if row['witness']]
    words = old_words + [tuple(row['word']) for row in eight]
    assert len(words) == 124
    full_eight_classes = {(r['residue'], r['modulus'],
                           Q(r['charge_num'], r['charge_den'])) for r in eight}
    assert full_eight_classes == set(eight_classes())
    wordset = set(words)
    records = []
    witnesses = 0
    for n in range(3, 511, 2):
        H = (4 * n - 2) // 3
        predicted = {}
        for word in words:
            info = source_interval(n, word)
            if info['first'] is None:
                continue
            for u in range(info['first'], info['upper'] + 1, info['modulus']):
                assert u not in predicted  # first-return profiles cannot overlap
                predicted[u] = word
        observed = {}
        for u in range(n, H + 1, 2):
            state, word = u, []
            for _ in range(8):
                state, e = odd_step(state)
                word.append(e)
                if state <= H:
                    if state >= n and tuple(word) in wordset:
                        observed[u] = tuple(word)
                    break
        assert predicted == observed, n
        witnesses += len(predicted)
        records.append(dict(n=n, positive_sources=len(predicted)))
    return dict(scope='Exact fixed-band source interval controls for lengths3,5,7,8.',
                thresholds_checked=len(records), source_witnesses=witnesses,
                interval_and_actual_paths_agree=True,
                active_profiles_have_disjoint_sources=True,
                eight_classes_match_independent_classifier=True, rows=records)


if __name__ == '__main__':
    import json
    print(json.dumps(dict(note_audit=note_audit(), source_audit=source_audit()), indent=2))
