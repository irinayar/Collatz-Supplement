#!/usr/bin/env python3
"""Exact certificate for seven-transition low-band first returns.

Standard library only, Python 3.9+. The accompanying mathematical note proves
the all-exponent reduction. This program independently checks its finite cases,
the complete 56-word/30-word classification, all exact valuation residues,
first-return witnesses, and the potential charges. It uses no floating point.
"""
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import argparse
import csv
import json


def odd_step(u):
    if u <= 0 or u % 2 == 0:
        raise ValueError("u must be a positive odd integer")
    x = 3 * u + 1
    e = (x & -x).bit_length() - 1
    return x >> e, e


def replay(u, length):
    states, word = [u], []
    for _ in range(length):
        u, e = odd_step(u)
        states.append(u)
        word.append(e)
    return states, tuple(word)


def compositions(total, parts):
    if parts == 1:
        if total >= 1:
            yield (total,)
        return
    for first in range(1, total - parts + 2):
        for rest in compositions(total - first, parts - 1):
            yield (first,) + rest


def affine_prefixes(word):
    exponent = numerator = 0
    result = []
    for j, e in enumerate(word, 1):
        numerator = 3 * numerator + (1 << exponent)
        exponent += e
        result.append((j, exponent, numerator))
    return result


def candidates(total):
    return [(1,) + rest for rest in compositions(total - 1, 6)
            if rest[-1] >= 2]


def odd_ceiling(k):
    return k if k % 2 else k + 1


def odd_floor(k):
    return k if k % 2 else k - 1


def threshold_interval(states):
    """All odd n for which this path is a first return to [n,floor((4n-2)/3)]."""
    u, w = states[0], states[-1]
    smallest_intermediate = min(states[1:-1])
    low = max(3, (3 * max(u, w) + 5) // 4)
    high = min(u, w, (3 * smallest_intermediate + 1) // 4)
    return odd_ceiling(low), odd_floor(high)


def certify():
    # Audit the newly supplied K138 finite residue certificate. This is prior
    # work, retained as a dependency for the mixed-gap statement, not recredited.
    six_rows = []
    for rest in compositions(9, 5):
        if rest[-1] < 2:
            continue
        word = (1,) + rest
        _, total, B = affine_prefixes(word)[-1]
        assert total == 10
        residue = ((1024 - B) * pow(729, -1, 2048)) % 2048
        assert replay(residue, 6)[1] == word
        margin = 39 * residue - B + 512
        assert margin > 0
        six_rows.append(dict(word=word, B=B, residue=residue, margin=margin))
    assert len(six_rows) == 35
    assert min(row['margin'] for row in six_rows) == 4864

    # Exact arithmetic behind the unbounded exponent argument.
    assert Q(2187, 1024) > Q(4, 3)
    # For E>=13 and u>=7, the endpoint upper bound is too small.
    # 8192 * [(3u+2)/4 - ((2187u+1215)/8192 +211/64)]
    # equals 3957u-24127, whose minimum here is positive.
    assert 3957 * 7 - 24127 == 3572 > 0
    assert 12671 // 885 == 14  # E=12 forces odd u<=13.
    small = []
    for u in range(3, 14, 2):
        states, word = replay(u, 7)
        assert sum(word) != 12
        small.append(dict(u=u, states=states, valuations=word,
                          total_exponent=sum(word)))
    assert [row['total_exponent'] for row in small] == [15, 16, 15, 15, 16, 17]
    assert replay(3, 2)[0] == [3, 5, 1]
    assert replay(5, 1)[0] == [5, 1]

    # Controls for the maximum-numerator formula. The proof for every E is
    # the monotone transfer of excess exponent to the second position.
    maxima = []
    for total in range(8, 15):
        words = candidates(total)
        maximum = max(affine_prefixes(word)[-1][2] for word in words)
        expected = 1215 + 211 * (1 << (total - 6))
        assert maximum == expected
        maximizing_word = (1, total - 7, 1, 1, 1, 1, 2)
        assert affine_prefixes(maximizing_word)[-1][2] == maximum
        maxima.append(dict(E=total, candidates=len(words), Bmax=maximum))

    words = candidates(11)
    assert len(words) == 56
    modulus = 4096
    caps = (1, 3, 4, 6, 7, 9)
    # Independent inverse map: replay every odd residue, without using the
    # affine inverse formula, to obtain the exact finite valuation cylinders.
    residue_map = {}
    word_set = set(words)
    for residue in range(1, modulus, 2):
        _, word = replay(residue, 7)
        if word in word_set:
            assert word not in residue_map
            residue_map[word] = residue
    assert len(residue_map) == 56

    rows = []
    for word in words:
        prefixes = affine_prefixes(word)
        _, E, B = prefixes[-1]
        assert E == 11
        # Endpoint is odd: 2187u+B ==2048 (mod4096).
        residue = ((2048 - B) * pow(2187, -1, modulus)) % modulus
        assert residue == residue_map[word]
        assert residue > 0 and residue % 2
        prefix_es = [prefix[1] for prefix in prefixes[:-1]]
        accepted = all(e <= cap for e, cap in zip(prefix_es, caps))
        suffix_tests = [3 ** (7 - j) < (1 << (11 - e))
                        for j, e, _ in prefixes[:-1]]
        assert accepted == all(suffix_tests)
        row = dict(word=word, E=E, B=B, modulus=modulus, residue=residue,
                   prefix_exponents=prefix_es, admissible_profile=accepted,
                   charge_numerator=B - 695, charge_denominator=2187)
        if not accepted:
            j = next(j for j, ok in enumerate(suffix_tests, 1) if not ok)
            _, ej, bj = prefixes[j - 1]
            suffix_num = 3 ** (7 - j)
            suffix_den = 1 << (11 - ej)
            assert suffix_num >= suffix_den
            # Direct exact affine contradiction: w-z_j>0 at every u>0.
            a = Q(2187, 2048) - Q(3 ** j, 1 << ej)
            b = Q(B, 2048) - Q(bj, 1 << ej)
            assert a > 0 and b > 0
            row['exclusion'] = dict(intermediate_index=j,
                suffix_coefficient_numerator=suffix_num,
                suffix_coefficient_denominator=suffix_den,
                arrival_minus_intermediate_slope=str(a),
                arrival_minus_intermediate_intercept=str(b))
        else:
            assert 2059 <= B <= 3767
            assert 0 < B - 695 <= 3072
            witnesses = []
            for lift in (0, 1, 2):
                u = residue + modulus * lift
                states, actual_word = replay(u, 7)
                assert actual_word == word
                w = states[-1]
                assert 2048 * w == 2187 * u + B and w > u
                n_low, n_high = threshold_interval(states)
                assert n_low <= n_high
                n = n_low
                H = (4 * n - 2) // 3
                assert n <= u <= H and n <= w <= H
                assert all(v > H for v in states[1:-1])
                G = Q(1)
                for v in states[:-1]:
                    G *= Q(3 * v + 1, 3 * v)
                assert G == Q(2048 * w, 2187 * u)
                rho = G * Q(w + 5, w) / Q(u + 5, u)
                assert rho == 1 + Q(B - 695, 2187 * (u + 5)) > 1
                witnesses.append(dict(lift=lift, n=n, H=H, u=u, w=w,
                    states=states, threshold_min=n_low, threshold_max=n_high,
                    G=str(G), rho=str(rho)))
            row['witnesses'] = witnesses
        rows.append(row)

    retained = [row for row in rows if row['admissible_profile']]
    excluded = [row for row in rows if not row['admissible_profile']]
    assert len(retained) == 30 and len(excluded) == 26
    assert len({row['residue'] for row in retained}) == 30
    assert min(row['residue'] for row in retained) == 155
    assert sum(row['charge_numerator'] for row in retained) == 64148
    assert Counter(row['exclusion']['intermediate_index'] for row in excluded) == {
        2: 6, 3: 10, 4: 3, 5: 7}
    return dict(status='PASS', forced_E=11,
        audited_K138_six_return_rows=six_rows,
        small_E12_exclusions=small, numerator_envelope_controls=maxima,
        prefix_caps=caps, candidate_count=56, admitted_count=30,
        rejected_count=26, independently_replayed_odd_residues=2048,
        exact_first_return_witnesses=90, charge_numerator_sum=64148,
        profiles=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path('seven_return_certificate.json'))
    parser.add_argument('--table', type=Path,
                        default=Path('seven_return_profiles.csv'))
    args = parser.parse_args()
    result = certify()
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    with args.table.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        writer.writerow(['valuations', 'B', 'residue_mod_4096', 'charge_numerator'])
        for row in result['profiles']:
            if row['admissible_profile']:
                writer.writerow([','.join(map(str, row['word'])), row['B'],
                                 row['residue'], row['charge_numerator']])
    print(json.dumps({key: result[key] for key in (
        'status', 'forced_E', 'candidate_count', 'admitted_count',
        'rejected_count', 'independently_replayed_odd_residues',
        'exact_first_return_witnesses', 'charge_numerator_sum')}, indent=2))


if __name__ == '__main__':
    main()
