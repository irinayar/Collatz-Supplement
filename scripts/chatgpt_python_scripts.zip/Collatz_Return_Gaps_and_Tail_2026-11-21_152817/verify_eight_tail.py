#!/usr/bin/env python3
"""Mixed completed gaps through8 and <=n tail-input certificate.

Standard library only.  Regenerates positive-charge classes and verifies
finite-threshold sums by independent progression and sliding-band methods.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
from verify_linear_tail import weak_compositions, affine_numerator, odd_step, positive_classes, least_high


def eight_classes():
    answer = []
    for extras in weak_compositions(4, 7):
        word = (1,) + tuple(x+1 for x in extras[:-1]) + (extras[-1]+2,)
        E = 0
        keep = True
        for j, e in enumerate(word[:-1], 1):
            E += e
            if 3**j <= 2**E:
                keep = False
        if not keep:
            continue
        E, B = affine_numerator(word)
        assert E == 13
        r = ((2**E-B)*pow(3**8,-1,2**(E+1))) % 2**(E+1)
        x = r
        for e in word:
            x, actual = odd_step(x)
            assert actual == e
        answer.append((r,16384,Q(B+8155,6561)))
    assert len(answer) == 85
    assert sum((c for r,M,c in answer),Q(0)) == Q(499792,2187)
    return answer


def progression_sum(n, classes):
    H = (4*n-2)//3
    total = Q(0)
    for r, M, c in classes:
        first = r+max(0,(n-r+M-1)//M)*M
        for v in range(first,H+1,M):
            total += c/(v+5)
    return total


def certify():
    classes = positive_classes()+eight_classes()
    assert len(classes) == 124
    mod_tables = {}
    for r,M,c in classes:
        table = mod_tables.setdefault(M,{})
        assert r not in table
        table[r] = c
    cutoff = 8191
    max_n = cutoff-2
    max_H = (4*max_n-2)//3
    point_charge = [Q(0)]*(max_H+1)
    for v in range(1,max_H+1,2):
        coefficient = sum((table.get(v%M,Q(0)) for M,table in mod_tables.items()),Q(0))
        point_charge[v] = coefficient/(v+5)
    records=[]
    H_old=0
    sliding=Q(0)
    previous_n=1
    for n in range(3,cutoff,2):
        H=(4*n-2)//3
        # Maintain the exact sum over integers in[n,H].
        for v in range(H_old+1,H+1): sliding+=point_charge[v]
        for v in range(previous_n,n): sliding-=point_charge[v]
        S=progression_sum(n,classes)
        assert S==sliding,(n,S,sliding)
        assert S<1
        R=Q((n+5)*H,n*(H+5))
        completed=R/(1-S)
        h=least_high(n)
        K=Q(n+5,n)*Q(9*H+5,9*(H+5))/(1-S)
        tail=K/(1-Q(n-2,3*h))
        assert completed<Q(11,10),(n,completed)
        assert tail<Q(3,2),(n,tail)
        records.append({'n':n,'H':H,'h':h,'S':str(S),'completed_bound':str(completed),'tail_t_eq_n_bound':str(tail)})
        H_old=H
        previous_n=n
    mc=max(records,key=lambda r:Q(r['completed_bound']))
    mt=max(records,key=lambda r:Q(r['tail_t_eq_n_bound']))
    assert mc['n']==43 and Q(mc['completed_bound'])==Q(1088640,994117)
    assert mt['n']==43 and Q(mt['tail_t_eq_n_bound'])==Q(24325110,16899989)
    alpha=sum((c/(3*M) for r,M,c in classes),Q(0))
    beta=sum((c for r,M,c in classes),Q(0))
    assert beta>5*alpha
    Slarge=(alpha*cutoff+beta)/(cutoff+5)
    assert 0<=Slarge<1
    large_completed=Q(4*(cutoff+5),4*cutoff+15)/(1-Slarge)
    large_tail=Q(4*(cutoff+5),3*cutoff)/(1-Slarge)
    assert large_completed<Q(mc['completed_bound'])<Q(11,10)
    assert large_tail<Q(mt['tail_t_eq_n_bound'])
    cert={'scope':'completed first-return gaps2,3,4,5,7,8; distinct positive-charge departures3,5,7,8; tail inputs<=n',
          'classes': [{'residue':r,'modulus':M,'coefficient':str(c)} for r,M,c in classes],
          'finite_count':len(records),'finite_range':[3,max_n],'completed_max':mc,'tail_max':mt,
          'alpha':str(alpha),'beta':str(beta),'large_cutoff':cutoff,'large_completed_bound':str(large_completed),'large_tail_bound':str(large_tail),
          'rows':records}
    return cert


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,
                        default=Path(__file__).with_name('eight_tail_certificate.json'))
    args=parser.parse_args()
    cert=certify()
    path=args.output
    path.write_text(json.dumps(cert,indent=2)+'\n')
    print(json.dumps({k:cert[k] for k in ['finite_count','finite_range','alpha','beta','large_cutoff','large_completed_bound','large_tail_bound']},indent=2))
    print('max completed',cert['completed_max']['n'],cert['completed_max']['completed_bound'])
    print('max total',cert['tail_max']['n'],cert['tail_max']['tail_t_eq_n_bound'])
    print('PASS two independent exact charge-count methods; certificate bytes',path.stat().st_size)

if __name__=='__main__':main()
