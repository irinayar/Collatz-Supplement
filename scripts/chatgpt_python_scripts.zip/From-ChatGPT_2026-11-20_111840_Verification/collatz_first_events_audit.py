from collections import defaultdict
N=20000; J=90
z=list(range(N+1)); odd=[0]*(N+1); seenstates=[set() for _ in range(N+1)]
valid=[True]*(N+1); first=[None]*(N+1)
counts={'same_only':0,'higher':0,'lower_only':0,'mixed':0}
examples={}
for n in range(1,N+1): seenstates[n].add(n)
for j in range(1,J+1):
    for n in range(1,N+1):
        x=z[n];odd[n]+=x&1;z[n]=x//2 if x%2==0 else (3*x+1)//2
        if z[n]<n or z[n] in seenstates[n]:valid[n]=False
        seenstates[n].add(z[n])
    fibre={}
    for n in range(1,N+1):
        y=z[n];a=odd[n]
        if y in fibre and first[n] is None:
            lo,counts_seen=fibre[y]
            if valid[n] and n%2==1:
                channels=tuple(k for k in ('lower','same','higher') if any((b<a if k=='lower' else b==a if k=='same' else b>a) for b in counts_seen))
                kind='higher' if 'higher' in channels else 'same_only' if 'same' in channels else 'lower_only'
                counts[kind]+=1
                examples.setdefault(kind,(n,j,y,a,lo,channels))
            first[n]=j
        if y not in fibre:fibre[y]=(n,{a})
        else:fibre[y][1].add(a)
print('N',N,'J',J,'eligible first meetings',counts,'examples',examples)
