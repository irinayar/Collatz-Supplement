from collections import defaultdict

def T(x): return x//2 if x%2==0 else (3*x+1)//2
for j in range(1,15):
    B=1<<j
    endpoints={}
    for n in range(1,5001):
        x=n; a=0
        for _ in range(j):
            a+=x&1;x=T(x)
        old=endpoints.get(x)
        if old is None: endpoints[x]=[(n,a)]
        else: old.append((n,a))
    checked=0
    for arr in endpoints.values():
        for n,a in arr:
            if 12*n<B:continue
            partners=[b for m,b in arr if m<n]
            if partners:
                assert any(b==a or b==a+1 for b in partners),(j,n,a,partners)
                checked+=1
    print(j,checked)
