from itertools import combinations
from math import comb

def numerator(pos):
    b=len(pos)
    return sum((1<<i)*3**(b-1-h) for h,i in enumerate(pos))

def e3(j,b,y):
    if b==0: return 0
    return max(((1<<(l-b+1))*(3**b-2**b) for l in range(b-1,j) if (1<<l)%3 == ((1<<j)*y)%3), default=None) if y%3 else None

def e9(j,b,y):
    if b<2: return e3(j,b,y)
    opts=[]
    for p in range(b-2,j-1):
        pref=(1<<(p-b+2))*(3**(b-2)-2**(b-2))
        for l in range(p+1,j):
            if ((1<<l)+3*(1<<p)-(1<<j)*y)%9==0:
                opts.append(9*pref+3*(1<<p)+(1<<l))
    return max(opts) if opts else None

comparisons=0; improved=0; exact=0; empty=0; samples=[]
for j in range(2,13):
 for b in range(2,j+1):
  by_res={r:[] for r in range(9)}
  for pos in combinations(range(j),b):
   v=numerator(pos)
   for r in range(9):
    if (v-(1<<j)*r)%9==0: by_res[r].append(v)
  for r in range(9):
   vals=by_res[r]
   bound=e9(j,b,r)
   old=e3(j,b,r)
   comparisons+=1
   if (bound is None)!=(not vals) or (vals and max(vals)>bound):
    raise AssertionError((j,b,r,vals,bound))
   if bound is None: empty+=1
   if vals and bound==max(vals): exact+=1
   if old is not None and (bound is None or bound<old):
    improved+=1
    if len(samples)<12: samples.append((j,b,r,old,bound,max(vals) if vals else None))
print('comparisons',comparisons,'strict_improvements',improved,'exact_nonempty',exact,'empty',empty)
print('samples',samples)
