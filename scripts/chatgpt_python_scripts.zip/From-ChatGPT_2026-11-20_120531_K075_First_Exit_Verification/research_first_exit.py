from collections import defaultdict
from fractions import Fraction
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
from zipfile import ZipFile

def T(x):return (3*x+1)//2 if x%2 else x//2

def table(J,h):
    d={(0,0):0}; out=[d]
    for j in range(J):
        nd={}
        for (b,r),v in d.items():
            q=3**min(h,b)
            k=(b,v%q)
            if v>nd.get(k,-1):nd[k]=v
            b1=b+1;v1=3*v+2**j;q1=3**min(h,b1);k=(b1,v1%q1)
            if v1>nd.get(k,-1):nd[k]=v1
        d=nd;out.append(d)
    return out

def state(n,j):
    x=n;a=0
    for _ in range(j):
        a+=x%2;x=T(x)
    return x,a

def Xgood(n,j,a,y):
    if a==0:return False
    e=j-a
    return (y+1)*2**(a-1)*2**(e+1)>=3**(a-1)*(2**(e+1)+n*2**(a-1)) if False else (Fraction(y+1)*Fraction(2,3)**(a-1)-Fraction(n,2**(e+1)))>=1

def evaln(n,js,hs=(0,1,2,3,4,5)):
    result=[]
    for j in js:
        y,a=state(n,j);B=2**j
        if a==0:continue
        base=not Xgood(n,j,a,y)
        row={'n':n,'j':j,'a':a,'y':y,'K075_failed':base,'layers':{}}
        for h in hs:
            d=tables[h][j]; excluded=[]; unresolved=[]
            for b in range(a):
                q=3**min(h,b);v=d.get((b,(B*y)%q))
                bound=B*y-3**b*n
                if v is None or v<=bound:excluded.append(b)
                else:unresolved.append(b)
            row['layers'][h]={'excluded':len(excluded),'unresolved':unresolved}
        # direct check smaller origins, independent
        lower=[]
        for m in range(1,n):
            z,b=state(m,j)
            if z==y and b<a:lower.append((m,b))
        row['actual_lower']=lower[:12];row['actual_lower_count']=len(lower)
        result.append(row)
    return result

if __name__=='__main__':
    hs=(0,1,2,3,4,5)
    tables={h:table(39,h) for h in hs}
    cases=[(7,range(9,13)),(251,range(23,31)),(667,range(25,30)),(871,range(31,40))]
    import json
    rows=[r for n,js in cases for r in evaln(n,js,hs)]
    for r in rows:
        print(r['n'],r['j'],'a',r['a'],'K075fails',r['K075_failed'],'lower',r['actual_lower_count'],'unresolved', {h:len(v['unresolved']) for h,v in r['layers'].items()})
        assert all(r['actual_lower_count']==0 or r['layers'][h]['unresolved'] for h in hs)
    p=Path('/mnt/data/first_exit_results.json');p.write_text(json.dumps(rows,indent=2))

def gap_excluded(n,j,y,a,b):
    if b==0:return True
    e=j-b
    vmax=2**e*(3**b-2**b)
    if b<j and vmax%(3**b)!=(2**j*y)%(3**b):
        vmax-=3**(b-1)*2**(e-1)
    return vmax<=2**j*y-3**b*n

if __name__=='__main__':
    for r in rows:
        n,j,a,y=(r[k] for k in ('n','j','a','y'))
        g=[b for b in range(a) if not gap_excluded(n,j,y,a,b)]
        r['gap_unresolved']=g
        if j==min(js for nn,jsr in cases if nn==n for js in jsr):
            print('FIRST_EXIT',n,j,'gap_unresolved',g,'h1',r['layers'][1]['unresolved'],'h2',r['layers'][2]['unresolved'])
    Path('/mnt/data/first_exit_results.json').write_text(json.dumps(rows,indent=2))
