from collections import Counter

def T(x): return x//2 if x%2==0 else (3*x+1)//2
checked=0; positive=0; cycles=set(); candidates=[]
for L in range(1,19):
 for bits in range(1<<L):
  a=bits.bit_count(); U=0
  for i in range(L):
   if (bits>>i)&1: U=3*U+(1<<i)
  den=(1<<L)-3**a
  if den<=0 or U<=0 or U%den: continue
  n=U//den
  if n<=0:continue
  checked+=1
  x=n; ok=True
  for i in range(L):
   if (x&1)!=((bits>>i)&1):ok=False;break
   x=T(x)
  if not ok or x!=n: continue
  positive+=1
  seq=[];x=n
  for i in range(L):seq.append(x);x=T(x)
  if set(seq)=={1,2}:cycles.add(tuple(sorted(set(seq))))
  else:candidates.append((L,n,seq))
print('closure_integer_candidates',checked,'valid_words',positive,'nontrivial',candidates,'trivial_sets',cycles)
