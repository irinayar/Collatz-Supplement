from itertools import combinations
from functools import lru_cache

def best(w,s,e,endpoint_factor):
    length=s+e
    target=(1<<length)*(endpoint_factor*w-1)
    modulus=3**s
    candidates=[]
    for pos in combinations(range(length),s):
        v=sum((1<<p)*3**(s-1-j) for j,p in enumerate(pos))
        if (target-v)%modulus==0:
            candidates.append((v, ''.join('1' if k in pos else '0' for k in range(length))))
    if not candidates:return None,None,None
    v,word=max(candidates)
    return (target-v)//modulus,v,word

@lru_cache(None)
def h(x,e,r):
    if r<0:return None
    a=0;t=x+1
    while t%3==0:a+=1;t//=3
    if e==0:return ((1<<r)*(x+1)//3**r-1) if r<=a else None
    vals=[h(2*((1<<l)*(x+1)//3**l-1),e-1,r-l) for l in range(min(a,r)+1)]
    return min((v for v in vals if v is not None),default=None)

checks=0
for u in range(1,5001,3):
    C=4*u-1;c=0;v=C
    while v%3==0:c+=1;v//=3
    w=(1<<(c-1))*v
    G=4*w-1
    g=0;t=G
    while t%3==0:g+=1;t//=3
    if g>=2:continue
    # The K089 reduction P=H3(6w-1,s), Q=H4(3w-1,s), s=r-c.
    for s in (2,3,4):
        P,_,_=best(w,s,3,6)
        Q,_,_=best(w,s,4,3)
        assert P==h(6*w-1,3,s)
        assert Q==h(3*w-1,4,s)
        checks+=2
    P2,_,_=best(w,2,3,6);Q2,_,_=best(w,2,4,3)
    if g==0:
        assert (P2,Q2)==((16*G-4)//3,(16*G-10)//3)
    else:
        assert (P2,Q2)==((16*G+3)//3,(16*G-24)//3)
    checks+=2
    P3,_,_=best(w,3,3,6);Q3,_,_=best(w,3,4,3)
    if w%9==8:
        assert Q3 is None and P3 is not None
        assert Q2-P3==(192*w-78)//27>0
        checks+=2
    if w%27 in (14,23):
        P4,_,_=best(w,4,3,6);Q4,_,_=best(w,4,4,3)
        assert Q3 is not None and Q4 is None and P4 is not None
        vP=175 if w%27==14 else 202
        assert Q3-P4==(384*w+vP-367)//81>0
        checks+=2
print('PASS',checks,'exact comparisons')
