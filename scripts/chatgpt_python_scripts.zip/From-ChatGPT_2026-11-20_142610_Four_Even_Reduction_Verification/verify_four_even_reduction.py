from functools import lru_cache
from itertools import combinations

def v3(n):
 a=0
 while n%3==0:a+=1;n//=3
 return a
@lru_cache(None)
def H(e,x,r):
 if r<0:return None
 a=v3(x+1)
 if e==0:return 2**r*((x+1)//3**r)-1 if r<=a else None
 vals=[]
 for ell in range(min(a,r)+1):
  y=2*(2**ell*((x+1)//3**ell)-1)
  z=H(e-1,y,r-ell)
  if z is not None:vals.append(z)
 return min(vals,default=None)

red=low=bridge=mon=overlap=0
bad=[];takeovers=[]
for x in range(1,5001):
 a=v3(x+1)
 star=3*2**(a-1)*((x+1)//3**a)-1 if a else None
 prev=None
 for r in range(0,35):
  z=H(4,x,r)
  if a:
   if r<a:
    assert z==16*(2**r*((x+1)//3**r)-1),(x,r,z)
    low+=1
   else:
    assert z==H(4,star,r-a+1),(x,r,z)
    red+=1
  else:
   assert z==H(3,2*x,r)
  if z is None:break
  if prev is not None:
   if not z<prev:bad.append((x,r,prev,z))
   mon+=1
   if r==a:bridge+=1
  prev=z
  if a==1 and r>=1:
   u=(x+1)//3
   p=H(3,2*x,r);q=H(3,4*u-2,r-1)
   if p is not None and q is not None:
    overlap+=1
    assert q<p,(x,r,p,q)
   if q is None and p is not None and H(3,4*u-2,r-2) is not None:
    takeovers.append((x,r))
print('REDUCTION',red,'LOW',low,'BRIDGES',bridge,'ADJACENT',mon,'OVERLAP',overlap,'VIOLATIONS',len(bad),'TAKEOVERS',len(takeovers))
print('TAKEOVER_EXAMPLES',takeovers[:10]);print('CACHE',H.cache_info())
# Independent complete word enumeration for small lengths
cells=0
for x in range(1,81):
 for r in range(0,8):
  n=r+4;best=None
  for ev_tuple in combinations(range(n),4):
   ev=set(ev_tuple)
   odd=[i for i in range(n) if i not in ev]
   V=sum(2**p*3**(r-1-j) for j,p in enumerate(odd))
   q,rem=divmod(2**n*x-V,3**r)
   if rem or q<1:continue
   y=q
   for t in range(n):
    assert (y%2==0)==(t in ev)
    y=y//2 if y%2==0 else (3*y+1)//2
   assert y==x
   best=q if best is None else min(best,q)
  assert best==H(4,x,r),(x,r,best,H(4,x,r))
  cells+=1
print('INDEPENDENT_ENUMERATION_CELLS',cells)
