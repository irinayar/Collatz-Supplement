#!/usr/bin/env python3
"""Exact finite-horizon parity-discrepancy counting; no universal convergence claim."""
from math import comb

def parity_affine(w):
    a=u=0
    for j,b in enumerate(w):
        if b:
            u=3*u+(1<<j); a+=1
    return a,u

def threshold_count(L,N):
    # Compare 2^L*N^a <= (3*N+1)^a (non-forced-exit necessary at time L)
    bad=sum(comb(L,a) for a in range(L+1) if (1<<L)*pow(N,a) <= pow(3*N+1,a))
    return bad,1<<L

def direct_verify(L,N):
    bad=0
    for n in range(N,N+(1<<L)):
        x=n;a=0; exited=False
        for j in range(1,L+1):
            if x&1:a+=1;x=(3*x+1)//2
            else:x//=2
            if (1<<j)*pow(n,a)>pow(3*n+1,a): exited=True
        if not exited:bad+=1
    return bad

if __name__=='__main__':
    for L,N in [(8,100),(12,100),(16,1000),(20,10000),(32,10000),(64,10000),(128,10000)]:
        bad,total=threshold_count(L,N)
        print(f'L={L} N={N} max_possible_nonexit_classes={bad}/{total} fraction={bad/total:.9g}')
    # Directly verify: each class of residue mod 2^L, and if no descent through L
    # then its parity count passes necessary threshold using n itself.
    for L in range(2,11):
        for n in range(2,300):
            x=n;a=0
            for j in range(1,L+1):
                if x&1:a+=1;x=(3*x+1)//2
                else:x//=2
                if x<n:
                    break
                assert (1<<j)*pow(n,a)<=pow(3*n+1,a), (L,n,j)
    print('Verified necessary inequality for all non-descending endpoints n=2..299, L<=10')
