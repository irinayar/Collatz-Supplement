from fractions import Fraction

def run(limit=10001):
    checks=visits=returns=0
    for n in range(3,limit+1,2):
        H=(4*n-2)//3
        u=n; seen=set(); low=0; last=None
        for step in range(2000):
            if u<n or u in seen: break
            seen.add(u)
            if n<=u<=H: low+=1; visits+=1
            z=3*u+1;e=(z&-z).bit_length()-1;v=z>>e
            if n<=u<=H and v>=n:
                assert e==1 and u%4==3
                if u!=n: assert u%12 in (7,11)
            if n<=v<=H and v>=n and u>=n:
                assert e>=2 and (e%2==0)==(v%3==1)
                assert 3*u+1==(1<<e)*v
                returns+=1
            checks+=1
            u=v
        eligible=sum(x%12 in (7,11) for x in range(n,H+1,2))
        assert low<=eligible+2
    return dict(starts=(limit-1)//2,odd_transitions=checks,low_visits=visits,returns=returns)
if __name__=='__main__':print(run())
