from functools import lru_cache
@lru_cache(None)
def H(k,x,r):
 if r<0:return None
 if k==0:
  z=x+1
  for _ in range(r):
   if z%3:return None
   z=z//3*2
  return z-1 if z>1 else None
 a=0;z=x+1
 while z%3==0:a+=1;z//=3
 vals=[]
 for ell in range(min(a,r)+1):
  y=2*((2**ell)*(x+1)//(3**ell)-1)
  v=H(k-1,y,r-ell)
  if v is not None:vals.append(v)
 return min(vals) if vals else None
n=0; failures=[]; tighter=0
for k in range(1,9):
 for x in range(1,301):
  for r in range(0,19):
   m=H(k,x,r);mp=H(k,x,r+1)
   if m is None or mp is None:continue
   n+=1
   if m>=2**(k+1)-3:
    tighter+=1
    if mp>=m:failures.append((k,x,r,m,mp))
print({'pairs':n,'covered_by_new_uniform_cutoff':tighter,'failures':failures[:5]})
