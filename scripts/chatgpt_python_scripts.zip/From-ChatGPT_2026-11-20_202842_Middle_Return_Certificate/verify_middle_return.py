#!/usr/bin/env python3
"""Exact finite certificate for odd-run-start middle-band returns."""
from fractions import Fraction
from collections import Counter
import json

def transition(u):
    assert u > 0 and u % 2 == 1
    s = ((u + 1) & -(u + 1)).bit_length() - 1
    w = 3**s * ((u + 1) // 2**s) - 1
    assert w > 0 and w % 2 == 0
    e = (w & -w).bit_length() - 1
    v = w >> e
    assert v % 2 == 1 and e >= 1
    C = Fraction(2**s * w, 3**s * u)
    assert C == 1 + Fraction(1 - Fraction(2, 3)**s, u)
    return v, C

def verify(u):
    start=u; seen=set(); middle=0; high=0; runs=0; in_middle=False
    entrances=[]; product=Fraction(1)
    while u>255:
        assert u not in seen, f'cycle at {u}, start {start}'
        seen.add(u)
        if u<=1023:
            if not in_middle:
                middle+=1;entrances.append(u)
            in_middle=True
        else:
            high+=1;in_middle=False
        v,C=transition(u)
        product*=C;u=v;runs+=1
        assert runs<10000
    return dict(start=start, middle_excursions=middle, high_runs=high,
                total_runs=runs, low_endpoint=u, middle_entries=entrances,
                product_numerator=product.numerator,
                product_denominator=product.denominator)

def main():
    results=[verify(u) for u in range(257,1024,2)]
    assert len(results)==384
    stats={}
    for name in ('middle_excursions','high_runs','total_runs'):
        mx=max(row[name] for row in results)
        stats[name]={'maximum':mx,'attaining_starts':[row['start'] for row in results if row[name]==mx]}
    largest=max(results,key=lambda row:Fraction(row['product_numerator'],row['product_denominator']))
    p=Fraction(largest['product_numerator'],largest['product_denominator'])
    q=Fraction(8192,6561)
    assert q*p < Fraction(3,2)
    assert stats['middle_excursions']['maximum']==3
    assert stats['high_runs']['maximum']==17
    assert stats['total_runs']['maximum']==19
    assert p==Fraction(268280837177344,265201334755659)
    stats['max_product']={'start':largest['start'],'numerator':p.numerator,'denominator':p.denominator,'decimal':float(p)}
    stats['distribution_middle_excursions']=dict(sorted(Counter(row['middle_excursions'] for row in results).items()))
    stats['low_tail_combined_bound']={'numerator':(p*q).numerator,'denominator':(p*q).denominator,'decimal':float(p*q)}
    with open('/mnt/data/middle_return_results.json','w') as f:json.dump({'summary':stats,'all_384_certificates':results},f,indent=2)
    print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
