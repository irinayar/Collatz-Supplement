from math import comb

def T(x): return x//2 if x%2==0 else (3*x+1)//2

def U_for_positions(positions):
    a=len(positions)
    return sum((1<<i)*3**(a-h-1) for h,i in enumerate(positions))

for j in range(2,11):
    for a in range(j):
        for y in range(1,40):
            target=((1<<j)*y)%3
            predicted=sum(comb(ell,a) for ell in range(a,j) if (1<<ell)%3==target)
            direct=sum(1 for ell in range(a,j) if (1<<ell)%3==target for _ in range(comb(ell,a)))
            assert predicted==direct
            if y%3==0: assert predicted==0
    # inverse dynamic program for all y<=200
    from functools import lru_cache
    @lru_cache(None)
    def H(k,y):
        if k==0:return 0
        return max(H(k-1,2*y),1+H(k-1,(2*y-1)//3) if y%3==2 else -1)
    for y in range(1,201):
        assert (H(j,y)==0)==(y%3==0)
print('PASS: last-odd-position residue sieve j=2..10, all odd-count targets, y=1..39; H_j(y)=0 iff 3|y for j=2..10,y=1..200')
