#!/usr/bin/env python3
"""Exact adaptive parity-cylinder descent and residue-height envelope experiments."""
from collections import defaultdict, Counter
import json


def T(n): return n//2 if n%2==0 else (3*n+1)//2

def forward(n, cap=2000):
    x=n; a=0; u=0; xwalk=0
    for j in range(1,cap+1):
        bit=x&1
        # numerator affine (3^a*n+u)/2^j
        if bit: u=3*u+2**(j-1); a+=1
        x=T(x)
        assert x*2**j==3**a*n+u
        if x<n: return j,a,u
    raise RuntimeError((n,cap))

def smallest(residue,mod,N):
    # integers in [2,N] with given residue
    z=residue%mod
    if z<2: z+=((2-z+mod-1)//mod)*mod
    return z if z<=N else None

def hierarchy(N, max_depth=500):
    # nodes: (residue, modulus, depth, odd_count, U)
    stack=[(0,1,0,0,0)]
    stats=Counter(); leaves=[]; max_seen=0
    while stack:
        r,m,j,a,u=stack.pop()
        lo=smallest(r,m,N)
        if lo is None: continue
        if j:
            D=2**j-3**a
            if D>0 and lo*D>u:
                stats['D_leaves']+=1
                cnt=(N-lo)//m+1
                stats['D_integers']+=cnt
                leaves.append((r,m,j,a,u,lo,cnt))
                max_seen=max(max_seen,j)
                continue
        if j>=max_depth: raise RuntimeError(('depth_cap',r,m,j,lo))
        # each parity word of length j corresponds to unique r modulo 2^j
        # For a new bit, distinguish n = r or r+m modulo 2m; actual parity of T^j(n)
        for rr in (r,r+m):
            nn=smallest(rr,2*m,N)
            if nn is None: continue
            bit=((3**a*nn+u)//m)&1
            aa=a+bit
            uu=(3*u+m) if bit else u
            stack.append((rr,2*m,j+1,aa,uu))
    assert stats['D_integers']==N-1
    return stats,leaves,max_seen

def envelopes(N,M,R):
    assert M%2==1
    B=[0]*M
    for s in range(M):
        z=(N-1)-((N-1-s)%M)
        B[s]=z if z>=1 else 0
    out=[B]
    for j in range(R):
        C=[0]*M
        for s,h in enumerate(B):
            if h==0:continue
            for parity in (0,1):
                z=h-M*((h-parity)%2)
                if z<1:continue
                y=T(z)
                C[y%M]=max(C[y%M],y)
        B=C;out.append(B)
    return out

def check_envelopes(N,M,R):
    E=envelopes(N,M,R)
    count=0
    for n in range(1,N):
        x=n
        for j in range(R+1):
            assert x<=E[j][x%M],(N,M,R,n,j,x,E[j][x%M])
            count+=1;x=T(x)
    return count

def claude_identity_check(N,R):
    # exact scaled identity, avoiding floating logs:
    # z_j=(3^A*n+U)/2^j; U=sum_{odd i<j} 3^(A-A_(i+1))*2^i
    checks=0
    for n in range(1,N+1):
        x=n;bits=[]
        for j in range(1,R+1):
            bits.append(x&1);x=T(x)
            a=sum(bits)
            U=sum(3**(a-sum(bits[:i+1]))*2**i for i,b in enumerate(bits) if b)
            assert 2**j*x==3**a*n+U
            checks+=1
    return checks

def main():
    N=100000
    stats,leaves,depth=hierarchy(N)
    # representative trajectory oracle for all n; D guard must not lie
    checks=0; distribution=Counter()
    for r,m,j,a,u,lo,cnt in leaves:
        for n in range(lo,N+1,m):
            x=n
            for k in range(j): x=T(x)
            assert x<n
            assert x*2**j==3**a*n+u
            checks+=1
        distribution[j]+=cnt
    assert checks==N-1
    envelope_checks=sum(check_envelopes(n,M,12) for n in (40,80,120) for M in (3,9,27))
    identity_checks=claude_identity_check(100,30)
    out={"N":N,"D_leaves":stats['D_leaves'],"D_integers":stats['D_integers'],"max_leaf_depth":depth,
         "leaf_depth_distribution":dict(sorted(distribution.items())),
         "exact_leaf_representative_checks":checks,"envelope_containment_checks":envelope_checks,
         "claude_affine_identity_checks":identity_checks,
         "sample_leaves":[{"r":r,"modulus":m,"depth":j,"A":a,"U":u,"min":lo,"count":cnt} for r,m,j,a,u,lo,cnt in leaves[:12]]}
    with open('results.json','w') as f:json.dump(out,f,indent=2)
    print(json.dumps({k:v for k,v in out.items() if k not in ('leaf_depth_distribution','sample_leaves')},indent=2))
if __name__=='__main__':main()
