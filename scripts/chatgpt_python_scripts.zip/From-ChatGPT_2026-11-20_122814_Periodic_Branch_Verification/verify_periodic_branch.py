from itertools import product

def step(n): return (3*n+1)//2 if n&1 else n//2

def numerator(word):
 u=0
 for i,bit in enumerate(word):
  if bit: u=3*u+(1<<i)
 return u

def valuation2(z):
 z=abs(z)
 if z==0:return None
 return (z&-z).bit_length()-1

checks=0
for L in range(1,9):
 for word in product((0,1),repeat=L):
  a=sum(word);u=numerator(word)
  for n in range(1,401):
   x=n;k=0
   for _ in range(5):
    bits=[]
    for i in range(L):
     bits.append(x&1);x=step(x)
    if tuple(bits)!=word:break
    k+=1
    d=((1<<L)-3**a)*n-u
    if d:
     assert valuation2(d)>=k*L,(L,word,n,k,d)
    else:
     assert x==n,(L,word,n,k,x)
    checks+=1
print('PASS:',checks,'verified complete repeated blocks; lengths 1..8, origins 1..400, up to 5 blocks')
for word in [(1,1),(1,0),(1,1,0)]:
 L=len(word);a=sum(word);u=numerator(word);den=2**L-3**a
 print('word', ''.join(map(str,word)), 'den',den,'U',u,'candidate', f'{u}/{den}' if den else 'none')
