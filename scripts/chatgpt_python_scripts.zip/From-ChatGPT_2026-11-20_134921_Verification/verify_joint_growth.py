"""Exact checks for inverse odd-count height bound and endpoint recursion."""
from functools import lru_cache
from math import log, floor

def v3(n):
    a=0
    while n%3==0:
        n//=3;a+=1
    return a

@lru_cache(None)
def R(e,x):
    a=v3(x+1)
    if e==0:return a
    return max(l+R(e-1,2*(2**l*((x+1)//3**l)-1)) for l in range(a+1))

cases=0
for x in range(1,501):
    for e in range(7):
        r=R(e,x)
        # Exact inequality: 2*3^r <= 2^(e+r)*(x+1)
        assert 2*3**r <= 2**(e+r)*(x+1)
        if x%3==0: assert r==0
        cases+=1
print('Exact maximum/bound comparisons:',cases)
for x in [1,2,3,7,20,251,871,242]:
    print(x, [R(e,x) for e in range(7)])
