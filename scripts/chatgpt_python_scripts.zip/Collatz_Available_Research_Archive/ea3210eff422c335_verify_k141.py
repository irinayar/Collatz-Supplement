#!/usr/bin/env python3
"""Independent exact reconstruction of K141's nine-return baseline.

Python standard library only.  The supplied Markdown note is compared with
the generated table; none of its missing supplementary JSON files is used.
The all-exponent proof is in Nine_Return_Audit.md.  This program checks all
finite reductions, all valuation cylinders, every retained witness, both
residue-budget computations, and the analytic-envelope constants.

Run: python verify_k141.py
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json
import re


COMPLETED = Q(1088640, 994117)
TAIL = Q(24325110, 16899989)


def weak_compositions(total, slots):
    if slots == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for rest in weak_compositions(total-first, slots-1):
            yield (first,) + rest


def odd_step(u):
    z = 3*u+1
    e = (z & -z).bit_length()-1
    return z >> e, e


def replay(u, length):
    states, word = [u], []
    for _ in range(length):
        u, e = odd_step(u)
        states.append(u)
        word.append(e)
    return states, tuple(word)


def affine(word):
    E = B = 0
    prefixes = [(1, 0, 1)]
    for j, e in enumerate(word, 1):
        B = 3*B + 2**E
        E += e
        prefixes.append((3**j, B, 2**E))
    return E, B, prefixes


def binary_parity_at(u, index):
    for _ in range(index):
        u = (3*u+1)//2 if u % 2 else u//2
    return u % 2


def chronological_residue(word):
    """Lift one binary digit at a time, including the odd arrival bit."""
    E = sum(word)
    bits = [0]*(E+1)
    j = 0
    bits[0] = 1
    for e in word:
        j += e
        bits[j] = 1
    residue = 0
    for index, target in enumerate(bits):
        p0 = binary_parity_at(residue, index)
        p1 = binary_parity_at(residue+2**index, index)
        assert p0 != p1
        if p0 != target:
            residue += 2**index
        assert binary_parity_at(residue, index) == target
    return residue


def real_departure_interval(prefixes):
    """All lower/upper threshold comparisons, with exact rational coefficients."""
    A, B, D = prefixes[-1]
    a, b = Q(A, D), Q(B, D)
    lowers = [('n>=3', Q(0), Q(3)),
              ('source_in_band', Q(3, 4), Q(1, 2)),
              ('arrival_in_band', 3*a/4, 3*b/4+Q(1, 2))]
    uppers = [('n<=source', Q(1), Q(0)), ('n<=arrival', a, b)]
    uppers += [('proper_'+str(j), Q(3*A, 4*D), Q(3*B, 4*D)+Q(1, 4))
               for j, (A, B, D) in enumerate(prefixes[1:-1], 1)]
    lo, hi = Q(0), None
    lo_reason, hi_reason = None, None
    impossible = None
    for ln, la, lb in lowers:
        for un, ua, ub in uppers:
            slope, intercept = ua-la, ub-lb
            label = [ln, un]
            if slope > 0:
                candidate = -intercept/slope
                if candidate > lo:
                    lo, lo_reason = candidate, label
            elif slope < 0:
                candidate = -intercept/slope
                if hi is None or candidate < hi:
                    hi, hi_reason = candidate, label
            elif intercept < 0:
                impossible = dict(comparison=label, intercept=str(intercept))
    feasible = impossible is None and (hi is None or lo <= hi)
    return dict(feasible=feasible, lower=str(lo),
                upper=None if hi is None else str(hi),
                lower_comparison=lo_reason, upper_comparison=hi_reason,
                constant_contradiction=impossible)


def ceil_div(a, b):
    assert b > 0
    return -((-a)//b)


def threshold_interval(states):
    lower = max(3, ceil_div(3*max(states[0], states[-1])+2, 4))
    upper = min(states[0], states[-1],
                min((3*x+1)//4 for x in states[1:-1]))
    lower += (lower % 2 == 0)
    upper -= (upper % 2 == 0)
    return lower, upper


def parse_supplied_table(note):
    table = {}
    for line in note.splitlines():
        m = re.fullmatch(r'\|\s*([0-9]+(?:,[0-9]+){8})\s*\|\s*([0-9]+)\s*\|\s*([0-9]+)\s*\|',
                         line.strip())
        if m:
            word = tuple(map(int, m.group(1).split(',')))
            assert word not in table
            table[word] = (int(m.group(2)), int(m.group(3)))
    assert len(table) == 113
    return table


def classify_nine(note):
    # Exact constants in the unbounded-exponent reduction.
    assert Q(3**9, 2**13) > Q(4, 3)
    assert 3**8+2*3**7 == 10935
    assert sum(3**(6-j)*2**j for j in range(7)) == 2059
    assert -2*19683//3+10935+2059*256 == 524917
    assert (65536-26244)*15 > 524917
    assert 3*32768//4-19683 == 4893

    small_controls = []
    for n in (3, 5, 7, 9, 11, 13):
        H = (4*n-2)//3
        for u in range(n, H+1, 2):
            states, vals = [u], []
            v = u
            while True:
                v, e = odd_step(v)
                states.append(v)
                vals.append(e)
                assert len(vals) < 9
                if v <= H:
                    break
            small_controls.append(dict(n=n, H=H, source=u, states=states,
                                       valuations=vals,
                                       outcome='return' if v >= n else 'descent'))
    assert len(small_controls) == 9

    rows14, rows15, accepted = [], [], []
    expected_by_E = {14: {}, 15: {}}
    for Egoal in (14, 15):
        for extras in weak_compositions(Egoal-10, 8):
            word = (1,) + tuple(x+1 for x in extras[:-1]) + (extras[-1]+2,)
            E, B, prefixes = affine(word)
            assert E == Egoal
            modulus = 2**(E+1)
            residue = ((2**E-B)*pow(3**9, -1, modulus)) % modulus
            assert residue == chronological_residue(word)
            expected_by_E[E][word] = residue
            for lift in (0, 1):
                states, actual = replay(residue+lift*modulus, 9)
                assert actual == word
                assert all(x > 0 and x % 2 for x in states)
                assert 2**E*states[-1] == 3**9*states[0]+B
            row = dict(word=word, E=E, B=B, residue=residue, modulus=modulus,
                       resets=sum(e >= 2 for e in word))
            if E == 15:
                margin = 4893*residue-B+16384
                assert margin > 0
                row.update(disposition='endpoint_residue_exclusion',
                           strict_margin=margin)
                rows15.append(row)
                continue
            interval = real_departure_interval(prefixes)
            violations = [j for j in range(1, 9)
                          if 3**(9-j) >= 2**sum(word[j:])]
            # This compact suffix test independently agrees with the full LP.
            assert interval['feasible'] == (not violations)
            row.update(real_interval=interval, suffix_violations=violations,
                       charge_numerator=B-16495, charge_denominator=19683)
            if violations:
                row['disposition'] = 'real_exclusion'
            else:
                states, actual = replay(residue, 9)
                nlo, nhi = threshold_interval(states)
                assert nlo <= nhi
                H = (4*nlo-2)//3
                assert nlo <= states[0] <= H and nlo <= states[-1] <= H
                assert all(x > H for x in states[1:-1])
                assert states[-1] > states[0] and B-16495 > 0
                row.update(disposition='genuine', witness=dict(n=nlo, H=H,
                           threshold_upper=nhi, source=residue,
                           arrival=states[-1], states=states))
                accepted.append(row)
            rows14.append(row)

    assert len(rows14) == 330 and len(rows15) == 792
    assert len(accepted) == 113
    assert sum(r['disposition'] == 'real_exclusion' for r in rows14) == 217
    assert min(r['strict_margin'] for r in rows15) == 614400
    # Complete independent replay of every odd residue for both candidate moduli.
    observed = {14: {}, 15: {}}
    for u in range(1, 65536, 2):
        _, word = replay(u, 9)
        E = sum(word)
        if E not in (14, 15) or word[0] != 1 or word[-1] < 2:
            continue
        if u >= 2**(E+1):
            continue
        assert word not in observed[E]
        observed[E][word] = u
    assert observed == expected_by_E
    supplied = parse_supplied_table(note)
    assert supplied == {tuple(r['word']): (r['B'], r['residue']) for r in accepted}
    assert min(r['B'] for r in accepted) == 19171
    assert max(r['B'] for r in accepted) == 38155
    assert min(r['residue'] for r in accepted) == 359
    assert sum(r['charge_numerator'] for r in accepted) == 1216804
    assert min(r['witness']['n'] for r in accepted) == 327
    reset_breakdown = []
    for count in range(1, 6):
        subset = [r for r in accepted if r['resets'] == count]
        reset_breakdown.append(dict(resets=count, profiles=len(subset),
            coefficient_sum=str(sum((Q(r['charge_numerator'], 19683)
                                     for r in subset), Q(0)))))
    assert [r['profiles'] for r in reset_breakdown] == [1, 15, 47, 41, 9]
    new = [r for r in accepted if r['resets'] >= 3]
    assert len(new) == 97
    new_coefficient = sum((Q(r['charge_numerator'], 19683) for r in new), Q(0))
    assert new_coefficient == Q(1119772, 19683)
    return dict(candidates_E14=330, real_exclusions_E14=217, retained=113,
                candidates_E15=792, min_E15_strict_margin=614400,
                binary_lifting_checks=1122, integer_lifts_per_word=2,
                independent_odd_residues_replayed=32768,
                complete_moduli_checked=[32768, 65536],
                supplied_table_entries_matched=113,
                prefix_caps=[1,2,4,6,7,9,10,12],
                coefficient_sum='1216804/19683',
                reset_breakdown=reset_breakdown,
                new_beyond_C2_profiles=97,
                new_beyond_C2_coefficient_sum=str(new_coefficient),
                minimum_retained_residue=359, minimum_witness_threshold=327,
                small_band_controls=small_controls,
                E14_profiles=rows14, E15_exclusions=rows15)


def old_positive_classes():
    """Reproduce the already established complete short positive tables."""
    answer = [(55, 64, Q(44, 27)), (43, 64, Q(48, 27))]
    answer += [(r, 512, Q(B+65, 243)) for B, r in
               [(211,95),(227,175),(259,335),(251,295),
                (283,455),(287,219),(319,379)]]
    for gap, extra, slots in ((7,3,6),(8,4,7)):
        group = []
        for xs in weak_compositions(extra, slots):
            word = (1,) + tuple(x+1 for x in xs[:-1]) + (xs[-1]+2,)
            if gap == 7 and any(3**(gap-j) >= 2**sum(word[j:])
                                for j in range(1,gap)):
                continue
            if gap == 8 and any(3**j <= 2**sum(word[:j])
                                for j in range(1,gap)):
                continue
            E, B, _ = affine(word)
            modulus = 2**(E+1)
            residue = ((2**E-B)*pow(3**gap,-1,modulus)) % modulus
            c = Q(B+5*(2**E-3**gap),3**gap)
            assert c > 0 and replay(residue,gap)[1] == word
            group.append((residue,modulus,c))
        assert len(group) == (30 if gap == 7 else 85)
        answer.extend(group)
    assert len(answer) == 124
    return answer


def class_sum(n, classes):
    H = (4*n-2)//3
    result = Q(0)
    for r, modulus, c in classes:
        first = r+ceil_div(n-r, modulus)*modulus
        for u in range(first, H+1, modulus):
            result += c/(u+5)
    return result


def least_high(H):
    h = H+1
    h += (h % 2 == 0)
    while h % 3 == 0:
        h += 2
    return h


def mixed_bounds(classification):
    retained = [r for r in classification['E14_profiles']
                if r['disposition'] == 'genuine']
    classes = old_positive_classes() + [
        (r['residue'],32768,Q(r['charge_numerator'],19683)) for r in retained]
    assert len(classes) == 237
    alpha = sum((c/(3*m) for r,m,c in classes),Q(0))
    beta = sum((c for r,m,c in classes),Q(0))
    assert alpha == Q(15263065,483729408)
    assert beta == Q(6544984,19683)
    assert beta > 5*alpha
    cutoff = 8191
    maxH = (4*(cutoff-2)-2)//3
    tables = {}
    for r,m,c in classes:
        table = tables.setdefault(m,{})
        assert r not in table
        table[r] = c
    point = [Q(0)]*(maxH+1)
    for u in range(1,maxH+1,2):
        coefficient = sum((table.get(u%m,Q(0))
                           for m,table in tables.items()),Q(0))
        point[u] = coefficient/(u+5)
    records = []
    oldH, oldn, sliding = 0, 1, Q(0)
    for n in range(3,cutoff,2):
        H = (4*n-2)//3
        for u in range(oldH+1,H+1):
            sliding += point[u]
        for u in range(oldn,n):
            sliding -= point[u]
        S = class_sum(n,classes)
        assert S == sliding and S < 1
        complete = Q((n+5)*H,n*(H+5))/(1-S)
        h = least_high(H)
        K = Q((n+5)*(9*H+5),9*n*(H+5))/(1-S)
        tail = K/(1-Q(n-2,3*h))
        assert complete <= COMPLETED and tail <= TAIL
        records.append(dict(n=n,H=H,h=h,S=str(S),K=str(K),
                            completed_upper=str(complete),tail_n_upper=str(tail)))
        oldH, oldn = H, n
    max_complete = max(records,key=lambda r:Q(r['completed_upper']))
    max_tail = max(records,key=lambda r:Q(r['tail_n_upper']))
    assert max_complete['n'] == max_tail['n'] == 43
    assert Q(max_complete['completed_upper']) == COMPLETED
    assert Q(max_tail['tail_n_upper']) == TAIL
    assert max_complete['S'] == '26/405'
    Sbar = (alpha*cutoff+beta)/(cutoff+5)
    large_complete = Q(4*(cutoff+5),4*cutoff+15)/(1-Sbar)
    large_tail = Q(4*(cutoff+5),3*cutoff)/(1-Sbar)
    assert large_complete == Q(129976961937702912,120586629177572051) < COMPLETED
    assert large_tail == Q(43325653979234304,30132861880883879) < TAIL
    # The 8n successor-packing certificate's finite budgets are unchanged.
    assert classification['minimum_retained_residue'] > (4*87-2)//3
    transported_large = Q(11,10)*Q(806,801)*Q(27,20)
    assert transported_large == Q(13299,8900) < Q(299,200)
    return dict(positive_classes=237,alpha=str(alpha),beta=str(beta),
                exact_thresholds=len(records),finite_range=[3,8189],
                independent_methods=['class progression sums',
                                     'integer residue lookup and sliding bands'],
                completed_maximum=max_complete,tail_n_maximum=max_tail,
                analytic_cutoff=cutoff,analytic_Sbar=str(Sbar),
                analytic_completed_upper=str(large_complete),
                analytic_tail_n_upper=str(large_tail),
                eight_n_transport=dict(small_thresholds_unchanged=[11,87],
                                       minimum_new_residue=359,
                                       analytic_upper=str(transported_large),
                                       final_strict_upper='299/200',
                                       extra_hypothesis='y_2,...,y_(t-2) pairwise distinct'),
                finite_rows=records)


def certify(note_path):
    note_bytes = note_path.read_bytes()
    note = note_bytes.decode('utf-8-sig')
    classification = classify_nine(note)
    budgets = mixed_bounds(classification)
    return dict(
        status='PASS',
        scope=('All nine-transition first-return profiles, completed gaps<=9 '
               'with distinct positive departures, and a <=n-input unfinished '
               'tail without tail distinctness. The 8n extension retains its '
               'internal-tail distinctness hypothesis. No unrestricted '
               'Collatz convergence theorem.'),
        supplied_source=dict(filename=note_path.name,
                             sha256=hashlib.sha256(note_bytes).hexdigest(),
                             table_rows_independently_matched=113),
        referenced_supplementary_files_not_supplied=[
            'profiles.json','profile_witnesses.json','small_band_controls.json',
            'small_n_certificate.json','tail_n_certificate.json',
            'tmp/nine_returns_profiles.py','tmp/nine_returns_test.py'],
        source_reported_scans_not_rerun=[
            '230 gap-nine returns for odd thresholds 3..1999',
            '999-start first-descent replay and its 209 return edges',
            '194 completed-prefix, 291 two-input-tail, and 649 longer-tail checks'],
        classification=classification,mixed_bounds=budgets)


def main():
    if not __debug__:
        raise SystemExit('Run without optimization: exact verification uses assertions.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-note',type=Path,
                        default=Path(__file__).with_name('K141_Source.md'))
    parser.add_argument('--output',type=Path,
                        default=Path(__file__).with_name('k141_certificate.json'))
    args = parser.parse_args()
    result = certify(args.source_note)
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    c,b = result['classification'],result['mixed_bounds']
    profiles_path = args.output.with_name('nine_return_profiles.json')
    profiles_path.write_text(json.dumps(
        [row for row in c['E14_profiles'] if row['disposition']=='genuine'],
        indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=result['status'],
                          candidates_E14=c['candidates_E14'],
                          real_exclusions_E14=c['real_exclusions_E14'],
                          retained=c['retained'],
                          candidates_E15=c['candidates_E15'],
                          min_E15_margin=c['min_E15_strict_margin'],
                          coefficient_sum=c['coefficient_sum'],
                          reset_breakdown=c['reset_breakdown'],
                          finite_thresholds=b['exact_thresholds'],
                          alpha=b['alpha'],beta=b['beta'],
                          completed_maximum_n=b['completed_maximum']['n'],
                          completed_bound=b['completed_maximum']['completed_upper'],
                          tail_n_bound=b['tail_n_maximum']['tail_n_upper'],
                          analytic_completed=b['analytic_completed_upper'],
                          analytic_tail=b['analytic_tail_n_upper']),indent=2))
    print('Wrote',args.output)
    print('Wrote',profiles_path)


if __name__ == '__main__':
    main()
