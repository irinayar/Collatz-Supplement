from fractions import Fraction as Q
import json

def F(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def comps(total,mins):
 if len(mins)==1:
  if total>=mins[0]:yield(total,)
 else:
  for e in range(mins[0],total-sum(mins[1:])+1):
   for tail in comps(total-e,mins[1:]):yield(e,)+tail

def aff(word):
 U=E=0;res=[]
 for j,e in enumerate(word,1):
  U=3*U+(1<<E);E+=e;res.append((3**j,U,1<<E))
 return res
rows=[]
for tail in comps(12,[1]*6+[2]):
 word=(1,)+tail;fs=aff(word);a,B,d=fs[-1];mod=2*d;r=((d-B)*pow(a,-1,mod))%mod
 ex=[]
 for j,(aj,bj,dj) in enumerate(fs[:-1],1):
  for label,at,bt,dt in [('departure',1,0,1),('arrival',a,B,d)]:
   alpha=at*dj-aj*dt;beta=bt*dj-bj*dt
   if alpha>=0 and alpha*r+beta>=0:ex.append((j,label,alpha,beta))
 wit=None
 for t in range(5):
  u=r+mod*t;z=u;ss=[u]
  for e in word:
   z,ee=F(z);assert ee==e;ss.append(z)
  lo=max(3,(3*max(u,z)+5)//4);hi=min(u,z,min((3*x+1)//4 for x in ss[1:-1]))
  if lo%2==0:lo+=1
  if hi%2==0:hi-=1
  if lo<=hi:
   wit={'n':lo,'u':u,'w':z,'states':ss,'t':t};break
 rows.append({'word':word,'B':B,'residue':r,'charge_num':B+5*(d-a),'exclusions':ex,'witness':wit})
print('candidates',len(rows),'excluded',sum(bool(x['exclusions']) for x in rows),'witness',sum(bool(x['witness']) for x in rows))
print('unresolved',[x for x in rows if not x['exclusions'] and not x['witness']])
keep=[x for x in rows if x['witness']]
print('Bmin,max',min(x['B'] for x in keep),max(x['B'] for x in keep),'rmin',min(x['residue'] for x in keep),'sumC',sum(x['charge_num'] for x in keep))
print('chargeC min,max',min(x['charge_num'] for x in keep),max(x['charge_num'] for x in keep))
print('finite-excluded',[x for x in rows if x['exclusions'] and all(z[3]<0 for z in x['exclusions'])][:2])
json.dump(rows,open('longer_returns_agent/eight_profiles.json','w'),indent=2)
# Independently enumerate the complete modulus to verify every cylinder residue.
by_word={}
for u in range(1,16384,2):
    z=u;es=[]
    for _ in range(8):
        z,e=F(z);es.append(e)
    key=tuple(es)
    if es[0]==1 and es[-1]>=2 and sum(es)==13:
        assert key not in by_word
        by_word[key]=u
assert len(by_word)==210
assert len(keep)==85 and len(rows)-len(keep)==125
assert all(bool(x['exclusions'])!=bool(x['witness']) for x in rows)
for x in rows:
    assert by_word[x['word']]==x['residue']
    if x['exclusions']:
        j,label,alpha,beta=x['exclusions'][0]
        assert alpha>=0 and alpha*x['residue']+beta>=0
    else:
        assert 1631*x['residue']-x['B']>0
        assert x['charge_num']>0
assert sum(x['charge_num'] for x in keep)==1499376
print('PASS: all8192 odd residues independently replayed; all210 candidate records partitioned into85 witnessed and125 excluded profiles.')
