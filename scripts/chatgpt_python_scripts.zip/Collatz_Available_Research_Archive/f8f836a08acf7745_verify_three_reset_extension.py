#!/usr/bin/env python3
"""Exact unbounded three-reset return extension of the K141 baseline.

Allowed completed returns have gap<=9 OR at most3 valuations>=2.
Positive-charge departures are distinct.  No Collatz convergence assumption.
Standard library only; the established short-profile classification is prior.
"""
from collections import Counter
from fractions import Fraction as Q
from math import gcd
from pathlib import Path
import json

LENGTH = 9
RESETS = 3
CUTOFF = 65535
SCALE = 1 << 64
COMPLETED_MAX = Q(1088640, 994117)
TAIL_MAX = Q(24325110, 16899989)


def ceildiv(a, b):
    assert b > 0
    return -((-a) // b)


def ceiling(q):
    return ceildiv(q.numerator, q.denominator)


def odd_step(u):
    v = 3 * u + 1
    e = (v & -v).bit_length() - 1
    return v >> e, e


def affine(word):
    E = B = 0
    records = []
    for j, e in enumerate(word, 1):
        B = 3 * B + (1 << E)
        E += e
        records.append((j, E, B))
    return E, B, records


def weak_compositions(total, slots):
    if slots == 1:
        yield (total,)
        return
    for a in range(total + 1):
        for rest in weak_compositions(total - a, slots - 1):
            yield (a,) + rest


def short_positive_classes():
    answer = [(55, 64, Q(44, 27)), (43, 64, Q(48, 27))]
    answer += [(r, 512, Q(B + 65, 243)) for B, r in
               [(211, 95), (227, 175), (259, 335), (251, 295),
                (283, 455), (287, 219), (319, 379)]]
    for g, extra, expected, expected_E in [(7, 3, 30, 11), (8, 4, 85, 13),
                                           (9, 4, 113, 14)]:
        group = []
        for xs in weak_compositions(extra, g - 1):
            word = (1,) + tuple(x + 1 for x in xs[:-1]) + (xs[-1] + 2,)
            if g == 8:
                keep = all(3 ** j > 2 ** sum(word[:j]) for j in range(1, g))
            else:
                keep = all(3 ** (g - j) < 2 ** sum(word[j:]) for j in range(1, g))
            if not keep:
                continue
            E, B, prefixes = affine(word)
            assert E == expected_E
            M = 2 ** (E + 1)
            r = ((2 ** E - B) * pow(3 ** g, -1, M)) % M
            c = Q(B + 5 * (2 ** E - 3 ** g), 3 ** g)
            assert c > 0
            x = r
            for e in word:
                x, actual = odd_step(x)
                assert actual == e
            group.append((r, M, c))
        assert len(group) == expected
        if g == 9:
            assert sum((c for r, M, c in group), Q(0)) == Q(1216804, 19683)
        answer.extend(group)
    assert len(answer) == 237
    assert sum((c / (3 * M) for r, M, c in answer), Q(0)) == Q(15263065, 483729408)
    assert sum((c for r, M, c in answer), Q(0)) == Q(6544984, 19683)
    return answer


def prefix_cover():
    caps = []
    for j in range(1, LENGTH + 1):
        E = 0
        while 2 ** (E + 1) * 11 ** j < 34 ** j:
            E += 1
        caps.append(E)
    assert caps == [1, 3, 4, 6, 8, 9, 11, 13, 14]
    candidates = []
    retained = []

    def visit(word, E, B, upper):
        j = len(word)
        if j == LENGTH:
            M = 2 ** (E + 1)
            r = ((2 ** E - B) * pow(3 ** LENGTH, -1, M)) % M
            first = r + max(0, ceildiv(11 - r, M)) * M
            _, _, prefixes = affine(word)
            violations = []
            for z, ez, bz in prefixes:
                if 2 ** ez > 3 ** z:
                    margin = (2 ** ez - 3 ** z) * first - bz
                    if margin >= 0:
                        violations.append(dict(position=z, E=ez, B=bz,
                                               margin=margin))
            accepted = upper is None or first <= upper
            assert accepted == (not violations)
            k = sum(e >= 2 for e in word)
            A = Q(B + 2 ** E, 3 ** LENGTH)
            assert A >= 1
            row = dict(word=list(word), E=E, B=B, residue=r, modulus=M,
                       first_source_at_least11=first, prefix_source_upper=upper,
                       resets=k, A=str(A), remaining_after_first=RESETS-k-1,
                       accepted=accepted, rejection_witnesses=violations)
            for u in (r, r + M):
                x = u
                for e in word:
                    x, actual = odd_step(x)
                    assert actual == e
            candidates.append(row)
            if accepted:
                # In this concrete cover, all retained cylinders expand
                # at every prefix.  Finite-height exceptions were tested.
                assert upper is None
                assert all(3 ** z > 2 ** ez for z, ez, bz in prefixes)
                retained.append(row)
            return
        for e in range(1, caps[j] - E + 1):
            if e >= 2 and sum(z >= 2 for z in word) == RESETS - 1:
                continue
            newE, newB, newupper = E + e, 3 * B + 2 ** E, upper
            if 2 ** newE > 3 ** (j + 1):
                bound = (newB - 1) // (2 ** newE - 3 ** (j + 1))
                newupper = bound if upper is None else min(upper, bound)
            visit(word + (e,), newE, newB, newupper)

    visit((), 0, 0, None)
    assert len(candidates) == 163 and len(retained) == 139
    for i, p in enumerate(retained):
        for q in retained[:i]:
            assert (p['residue'] - q['residue']) % gcd(p['modulus'], q['modulus']) != 0
    density = sum((Q(1, p['modulus']) for p in retained), Q(0))
    assert density == Q(85, 4096)
    charge_density = sum(((Q(p['A']) + p['remaining_after_first'] + Q(5, 3)) /
                          (3 * p['modulus']) for p in retained), Q(0))
    assert charge_density == Q(46244065, 1934917632)
    return caps, candidates, retained, density, charge_density


def prefix_coefficient_cap(p, n):
    A, m = Q(p['A']), p['remaining_after_first']
    return (n + 5) * ((1 + A / n) * (1 + Q(1, n)) ** m - 1) + Q(5, 3) - Q(10, 3 * n)


def run_to_reset(u):
    a = ((u + 1) & -(u + 1)).bit_length() - 1
    z = (u + 1) >> a
    numerator = 3 ** a * z - 1
    k = (numerator & -numerator).bit_length() - 1
    h = k + 1
    return a, h, numerator >> k


def threshold_interval(u, w, minimum_proper, maximum_n):
    lo = max(3, ceildiv(3 * max(u, w) + 2, 4))
    hi = min(u, w, (3 * minimum_proper + 1) // 4, maximum_n)
    if lo % 2 == 0:
        lo += 1
    if hi % 2 == 0:
        hi -= 1
    return lo, hi


def add_candidate(records, u, w, word, E, B, minimum_proper, maximum_n):
    g = len(word)
    if g <= LENGTH:
        return
    lo, hi = threshold_interval(u, w, minimum_proper, maximum_n)
    if lo > hi:
        return
    d = B + 5 * (2 ** E - 3 ** g)
    if d <= 0:
        return
    den = 3 ** g * (u + 5)
    weight = ceildiv(SCALE * d, den)
    assert Q(weight - 1, SCALE) < Q(d, den) <= Q(weight, SCALE)
    records.append(dict(u=u, w=w, g=g, word=list(word), resets=sum(e>=2 for e in word),
                        E=E, B=B, coefficient=str(Q(d, 3 ** g)),
                        charge_numerator=d, charge_denominator=den,
                        lo=lo, hi=hi, integer_weight=weight))


def source_profiles(maximum_n, literal=False):
    maximum_H = (4 * maximum_n - 2) // 3
    answer = []
    for u in range(3, maximum_H + 1, 4):
        if literal:
            x, E, B, resets = u, 0, 0, 0
            word, states = [], [u]
            while resets < RESETS:
                x, e = odd_step(x)
                B = 3 * B + 2 ** E
                E += e
                word.append(e)
                states.append(x)
                if e == 1:
                    continue
                resets += 1
                add_candidate(answer, u, x, word, E, B,
                              min(states[1:-1]), maximum_n)
                if x <= u:
                    break
        else:
            x, E, B = u, 0, 0
            minimum_proper = (3 * u + 1) // 2
            word = []
            for resets in range(1, RESETS + 1):
                a, h, w = run_to_reset(x)
                word += [1] * (a - 1) + [h]
                B = 3 ** a * B + 2 ** E * (3 ** a - 2 ** a)
                E += a - 1 + h
                x = w
                add_candidate(answer, u, x, word, E, B, minimum_proper, maximum_n)
                if x <= u:
                    break
                minimum_proper = min(minimum_proper, x)
    return answer


def least_high(n):
    H = (4 * n - 2) // 3
    h = H + 1
    if h % 2 == 0:
        h += 1
    while h % 3 == 0:
        h += 2
    return h


def allowed_edge(n, u, base_gap=9, resets_limit=3):
    H = (4 * n - 2) // 3
    x, g, resets = u, 0, 0
    while True:
        x, e = odd_step(x)
        g += 1
        resets += e >= 2
        if x <= H:
            return (x, g) if n <= x and (g <= base_gap or resets <= resets_limit) else None
        if g >= base_gap and resets > resets_limit:
            return None


def graph_controls():
    total_vertices = total_edges = maximum_rank = 0
    small_pairs = small_edges = small_maxgap = 0
    records = []
    for n in range(3, 1081, 2):
        H = (4 * n - 2) // 3
        vertices = list(range(n, H + 1, 2))
        edges = {}
        for u in vertices:
            result = allowed_edge(n, u)
            if result is not None:
                edges[u] = result
            if 11 <= n <= 87:
                small_pairs += 1
                if result is not None:
                    small_edges += 1
                    small_maxgap = max(small_maxgap, result[1])
        ranks = {}
        for u in vertices:
            x, stack, seen = u, [], set()
            while x not in ranks:
                assert x not in seen, ('cycle', n, x)
                seen.add(x)
                stack.append(x)
                if x not in edges:
                    ranks[x] = 0
                    break
                x = edges[x][0]
            for x in reversed(stack):
                ranks[x] = ranks[edges[x][0]] + 1 if x in edges else 0
        for u, (v, g) in edges.items():
            assert ranks[u] == 1 + ranks[v]
        total_vertices += len(vertices)
        total_edges += len(edges)
        maximum_rank = max(maximum_rank, max(ranks.values()))
        records.append(dict(n=n, edges=[[u, v, g] for u, (v, g) in edges.items()],
                            ranks=[[u, ranks[u]] for u in vertices]))
    assert (small_pairs, small_edges, small_maxgap) == (325, 44, 5)
    return dict(thresholds=539, vertices=total_vertices, edges=total_edges,
                maximum_rank=maximum_rank, small_tail_transport_pairs=small_pairs,
                small_tail_transport_edges=small_edges,
                small_tail_transport_maxgap=small_maxgap, graphs=records)


def main():
    classes = short_positive_classes()
    caps, candidates, cover, density, charge_density = prefix_cover()
    by_word = {tuple(p['word']): p for p in cover}
    maximum_n = CUTOFF - 2
    maximum_H = (4 * maximum_n - 2) // 3
    profiles = source_profiles(maximum_n)
    independent_profiles = source_profiles(maximum_n, literal=True)
    assert profiles == independent_profiles
    assert len(profiles) == 131
    for p in profiles:
        prefix = by_word[tuple(p['word'][:LENGTH])]
        assert p['u'] % prefix['modulus'] == prefix['residue']
        assert Q(p['coefficient']) < prefix_coefficient_cap(prefix, p['hi'])
        x = p['u']
        states = [x]
        for e in p['word']:
            x, actual = odd_step(x)
            assert e == actual
            states.append(x)
        assert x == p['w']
        # Directly recheck both extremal thresholds; all intervening
        # thresholds follow from the monotone interval inequalities.
        for n in [p['lo'], p['hi']]:
            H = (4 * n - 2) // 3
            assert n <= p['u'] <= H and n <= x <= H
            assert all(v > H for v in states[1:-1])
    tables = {}
    for r, M, c in classes:
        tables.setdefault(M, {})[r] = c
    old_point = [0] * (maximum_H + 1)
    old_count = [0] * (maximum_H + 1)
    for u in range(1, maximum_H + 1, 2):
        for M, table in tables.items():
            c = table.get(u % M)
            if c:
                old_point[u] += ceiling(SCALE * c / (u + 5))
                old_count[u] += 1
    independent_point = [0] * (maximum_H + 1)
    for r, M, c in classes:
        for u in range(r, maximum_H + 1, M):
            q = c / (u + 5)
            rounded = ceiling(SCALE * q)
            assert Q(rounded - 1, SCALE) < q <= Q(rounded, SCALE)
            independent_point[u] += rounded
    assert old_point == independent_point
    for u in range(1, maximum_H + 1):
        old_point[u] += old_point[u - 1]
        old_count[u] += old_count[u - 1]
    events = [0] * (CUTOFF + 2)
    for p in profiles:
        events[p['lo']] += p['integer_weight']
        events[p['hi'] + 2] -= p['integer_weight']
    rows = []
    maximum_terms = extra = 0
    max_other_complete = (Q(0), 0)
    max_other_tail = (Q(0), 0)
    max_finite_charge = (Q(0), 0)
    for n in range(3, CUTOFF, 2):
        H = (4 * n - 2) // 3
        extra += events[n]
        active = [p for p in independent_profiles if p['lo'] <= n <= p['hi']]
        assert extra == sum(p['integer_weight'] for p in active)
        s = old_point[H] - old_point[n - 1] + extra
        assert 0 <= s < SCALE
        terms = old_count[H] - old_count[n - 1] + len(active)
        maximum_terms = max(maximum_terms, terms)
        S = Q(s, SCALE)
        if n == 43:
            assert extra == 0
            S = sum((c / (u + 5) for r, M, c in classes
                     for u in range(r, H + 1, M) if u >= n), Q(0))
            assert S == Q(26, 405)
        max_finite_charge = max(max_finite_charge, (S, n))
        completed = Q((n + 5) * H, n * (H + 5)) / (1 - S)
        h = least_high(n)
        tail = Q(n + 5, n) * Q(9 * H + 5, 9 * (H + 5)) / (1 - S) / (1 - Q(n - 2, 3 * h))
        if n == 43:
            assert completed == COMPLETED_MAX and tail == TAIL_MAX
        else:
            assert completed < COMPLETED_MAX and tail < TAIL_MAX
            max_other_complete = max(max_other_complete, (completed, n))
            max_other_tail = max(max_other_tail, (tail, n))
        rows.append(dict(n=n, charge_upper_numerator=s, extra_upper_numerator=extra))
    alpha = sum((c / (3 * M) for r, M, c in classes), Q(0))
    beta = sum((c for r, M, c in classes), Q(0))
    n = CUTOFF
    Slarge = (alpha * n + beta) / (n + 5)
    Slarge += sum((prefix_coefficient_cap(p, n) * (Q(n, 3 * p['modulus']) + 1) /
                   (n + 5) for p in cover), Q(0))
    assert 0 < Slarge < 1
    large_completed = Q(4 * (n + 5), 4 * n + 15) / (1 - Slarge)
    large_tail = Q(4 * (n + 5), 3 * n) / (1 - Slarge)
    assert large_completed < COMPLETED_MAX and large_tail < TAIL_MAX
    assert max_finite_charge == (Q(26, 405), 43)
    assert max_finite_charge[0] < Slarge < Q(17, 250)
    graph = graph_controls()
    summary = dict(scope='Completed returns have gap<=9 OR at most3 exponents>=2; positive departures distinct; tail inputs<=n without tail distinctness.',
                   prefix_length=LENGTH, reset_limit=RESETS, prefix_exponent_caps=caps,
                   prefix_candidates=len(candidates), prefix_cylinders=len(cover),
                   excluded_prefixes=len(candidates)-len(cover),
                   finite_height_prefix_exceptions=0, source_density=str(density),
                   added_asymptotic_charge_density=str(charge_density),
                   old_alpha=str(alpha), old_beta=str(beta),
                   combined_asymptotic_charge_density=str(alpha+charge_density),
                   analytic_cutoff=CUTOFF, large_charge_bound=str(Slarge),
                   large_completed_bound=str(large_completed), large_tail_bound=str(large_tail),
                   completed_bound=str(COMPLETED_MAX), tail_bound=str(TAIL_MAX),
                   finite_threshold_count=len(rows), finite_source_profiles=len(profiles),
                   finite_source_maximum_H=maximum_H, directed_dyadic_denominator=SCALE,
                   maximum_rounding_terms=maximum_terms,
                   rounding_error_strictly_less_than=str(Q(maximum_terms, SCALE)),
                   maximum_threshold=43, other_completed_max_n=max_other_complete[1],
                   other_tail_max_n=max_other_tail[1],
                   finite_charge_maximum=str(max_finite_charge[0]),
                   finite_charge_maximum_n=max_finite_charge[1],
                   uniform_genuine_source_charge_bound=str(Slarge),
                   uniform_boundary_strict_bound='17/250',
                   graph_summary={k:v for k,v in graph.items() if k!='graphs'})
    result = dict(**summary, short_positive_classes=[dict(residue=r,modulus=M,coefficient=str(c)) for r,M,c in classes],
                  prefix_records=candidates, long_positive_source_profiles=profiles,
                  finite_rows=rows, graph_certificate=graph)
    target = Path(__file__).with_name('three_reset_certificate.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    print('PASS both independent source and charge implementations; certificate bytes:', target.stat().st_size)


if __name__ == '__main__':
    main()
