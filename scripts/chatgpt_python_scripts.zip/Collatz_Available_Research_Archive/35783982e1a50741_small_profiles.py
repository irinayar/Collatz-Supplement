from fractions import Fraction as Q
from prototype import proper_cap,final_bounds

def F(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def classify(N=129):
 profiles={};tests=[];maxsteps=0
 for n in range(3,N,2):
  H=(4*n-2)//3
  for u in range(n,H+1,2):
   z=u;es=[];states=[u];seen={u}
   for _ in range(10000):
    z,e=F(z);es.append(e);states.append(z)
    if z<n:status='descent';break
    if z<=H:status='return';break
    if z in seen:status='high_cycle';break
    seen.add(z)
   else:raise ValueError('cap')
   tests.append((n,u,status,len(es)))
   maxsteps=max(maxsteps,len(es))
   if status=='return':profiles.setdefault(tuple(es),(n,u,states))
 exceptions=[]
 for word,wit in profiles.items():
  g=len(word);E=sum(word);Bj=Ej=0
  prefix_ok=True
  for j,e in enumerate(word,1):
   Bj=3*Bj+2**Ej;Ej+=e
   if j<g and Ej>proper_cap(j,N):prefix_ok=False
  lo,hi=final_bounds(g,N);passes=prefix_ok and lo<=E<=hi
  if not passes:
   c=Q(Bj+5*(2**E-3**g),3**g)
   exceptions.append((word,c,wit))
 print('N',N,'sources',len(tests),'unique_profiles',len(profiles),'max_steps',maxsteps,'exceptions',len(exceptions))
 print(exceptions)
 print('exceptionT',sum((max(c,Q(0))/(3*2**(sum(w)+1)) for w,c,_ in exceptions),Q(0)))
 return profiles,tests,exceptions
if __name__=='__main__':classify()
