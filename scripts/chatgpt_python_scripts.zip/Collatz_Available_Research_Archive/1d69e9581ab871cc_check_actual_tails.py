#!/usr/bin/env python3
"""Independent actual-prefix control of the endpoint-cancelled tail formula."""
from fractions import Fraction as Q
from pathlib import Path
import json
from verify_linear_tail import odd_step, positive_budget, least_high


def main():
    count = 0
    qualifying_tails_longer_than_two = 0
    terminal_next_state_below_n = 0
    maximum = (Q(0), None)
    max_tail = 0
    for n in range(3, 2000, 2):
        H = (4*n-2)//3
        S = positive_budget(n)
        h = least_high(n)
        K = Q(n+5,n)*Q(9*H+5,9*(H+5))/(1-S)
        G = Q(1)
        x = n
        low_source = n
        low_index = 0
        edge_product = Q(1)
        positive_sources = set()
        qualified = True
        seen = set()
        for i in range(1000):
            if x < n:
                break
            if x in seen:
                raise AssertionError(('unexpected finite-control repetition', n, x))
            seen.add(x)
            if i > 0 and x <= H:
                gap = i - low_index
                rho = edge_product * Q(x+5,x) / Q(low_source+5,low_source)
                if gap not in (2,3,4,5,7):
                    qualified = False
                if rho > 1:
                    if low_source in positive_sources:
                        qualified = False
                    positive_sources.add(low_source)
                if qualified:
                    assert (rho > 1) == (gap in (3,5,7))
                low_source = x
                low_index = i
                edge_product = Q(1)
            factor = Q(3*x+1,3*x)
            G *= factor
            edge_product *= factor
            t = i - low_index + 1
            next_x, e = odd_step(x)
            if qualified and t <= n:
                if t <= 1:
                    bound = K
                else:
                    bound = K/(1-Q(t-2,3*h))
                assert G <= bound < Q(3,2), (n,i,t,G,bound)
                count += 1
                qualifying_tails_longer_than_two += t > 2
                terminal_next_state_below_n += next_x < n
                max_tail = max(max_tail,t)
                if G > maximum[0]: maximum=(G,{'n':n,'odd_inputs':i+1,'tail_inputs':t})
            x = next_x
        else:
            raise AssertionError(('control cap reached',n))
    result={'starts':999,'prefix_checks':count,'tails_longer_than_two':qualifying_tails_longer_than_two,
            'last_next_odd_below_n_cases':terminal_next_state_below_n,
            'maximum_checked_tail_length':max_tail,
            'maximum_actual_product':str(maximum[0]),'maximum_example':maximum[1],'passed':True}
    Path(__file__).with_name('actual_tail_control.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
