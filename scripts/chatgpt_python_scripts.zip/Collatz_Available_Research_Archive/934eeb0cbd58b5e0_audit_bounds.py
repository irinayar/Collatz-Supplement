from fractions import Fraction as Q
import json
from collections import defaultdict

def odd(u):
 x=3*u+1;e=0
 while x%2==0:x//=2;e+=1
 return x,e

def get_profile(u,k):
 es=[]
 for _ in range(k):u,e=odd(u);es.append(e)
 return tuple(es)

def B(word):
 b=0;E=0
 for e in word:b=3*b+2**E;E+=e
 return b

families={3:[],5:[],7:[]}
# Independent extraction of all desired valuation classes from entire residue sets.
for k,E,cap in [(3,5,None),(5,8,None),(7,11,(1,3,4,6,7,9))]:
 M=2**(E+1)
 for r in range(1,M,2):
  es=get_profile(r,k)
  if sum(es)!=E or es[0]!=1 or es[-1]<2:continue
  # General suffix-contraction condition is necessary for first return;
  # for k3,5,7 it coincides with the retained established profiles.
  if any(3**(k-j)>=2**sum(es[j:]) for j in range(1,k)):continue
  delta=B(es)+5*(2**E-3**k)
  if delta>0:families[k].append((r,M,Q(delta,3**k)))
print('families', {k:len(v) for k,v in families.items()})
assert [len(families[k]) for k in (3,5,7)]==[2,7,30]
C={k:sum((q for r,M,q in v),Q(0)) for k,v in families.items()}
print('C',C)
assert C=={3:Q(92,27),5:Q(764,81),7:Q(64148,2187)}
alpha=sum((q/Q(3*M) for v in families.values() for r,M,q in v),Q(0))
beta=sum(C.values(),Q(0))
assert alpha==Q(176525,6718464) and beta==Q(92228,2187)
records=[]
for n in range(3,1023,2):
 H=(4*n-2)//3;S=Q(0)
 for v in families.values():
  for r,M,q in v:
   u=r+max(0,(n-r+M-1)//M)*M
   while u<=H:S+=q/(u+5);u+=M
 R=Q((n+5)*H,n*(H+5))
 assert S<1
 bound=R/(1-S)
 assert bound<Q(11,10)
 records.append({'n':n,'S':str(S),'bound':str(bound)})
mx=max(records,key=lambda x:Q(x['bound']))
print('max small',mx)
assert mx['n']==43 and Q(mx['bound'])==Q(1088640,994117)
assert beta>5*alpha
N=1023
S=(alpha*N+beta)/(N+5)
R=Q(4*(N+5),4*N+15)
upper=R/(1-S)
assert upper==Q(350615568384,326667306847) and upper<Q(11,10)
print('large bound',upper,float(upper))
json.dump({'C':{k:str(v) for k,v in C.items()},'alpha':str(alpha),'beta':str(beta),'records':records,'max':mx,'large':str(upper)},open('seven_audit_agent/bounds_audit.json','w'),indent=2)
