#!/usr/bin/env python3
"""Exact charge bounds for an unbounded family of Collatz first returns.

The added return words are (1,...,1,h), with h>=2 and arbitrary length.
This certificate proves a theorem under distinct positive-charge departures;
it makes no assertion that all Collatz trajectories belong to this family.

Standard library only.  Run this file to regenerate the JSON certificate.
The previously proved gap<=8 classifications are reconstructed here, rather
than imported from any other verifier.  Their completeness is a prior theorem.
"""

from fractions import Fraction as Q
from pathlib import Path
import json


def weak_compositions(total, slots):
    if slots == 1:
        yield (total,)
        return
    for x in range(total + 1):
        for rest in weak_compositions(total - x, slots - 1):
            yield (x,) + rest


def odd_step(u):
    v = 3 * u + 1
    e = (v & -v).bit_length() - 1
    return v >> e, e


def affine(word):
    E = B = 0
    for e in word:
        B = 3 * B + (1 << E)
        E += e
    return E, B


def short_positive_classes():
    classes = [(55, 64, Q(44, 27)), (43, 64, Q(48, 27))]
    classes += [(r, 512, Q(B + 65, 243)) for B, r in
                [(211, 95), (227, 175), (259, 335), (251, 295),
                 (283, 455), (287, 219), (319, 379)]]
    for g, extra, expected, total_E in [(7, 3, 30, 11), (8, 4, 85, 13)]:
        added = []
        for parts in weak_compositions(extra, g - 1):
            word = (1,) + tuple(x + 1 for x in parts[:-1]) + (parts[-1] + 2,)
            if g == 7:
                keep = all(3 ** (g-j) < 2 ** sum(word[j:]) for j in range(1, g))
            else:
                keep = all(3 ** j > 2 ** sum(word[:j]) for j in range(1, g))
            if not keep:
                continue
            E, B = affine(word)
            assert E == total_E
            M = 2 ** (E + 1)
            a = ((2 ** E - B) * pow(3 ** g, -1, M)) % M
            c = Q(B + 5 * (2 ** E - 3 ** g), 3 ** g)
            assert c > 0
            x = a
            for e in word:
                x, actual = odd_step(x)
                assert e == actual
            added.append((a, M, c))
        assert len(added) == expected
        classes += added
    assert len(classes) == 124
    assert sum((c / (3 * M) for a, M, c in classes), Q(0)) == Q(34627, 1119744)
    assert sum((c for a, M, c in classes), Q(0)) == Q(65780, 243)
    # No short-return cylinder intersects u=-1 modulo512.
    for a, M, c in classes:
        assert (a - 511) % min(M, 512) != 0
    return classes


def family_profile(g, h):
    assert g >= 2 and h >= 2
    A = 3 ** g
    E = g - 1 + h
    B = A - 2 ** g
    D = Q(2 ** E, A)
    t = Q(2 ** g, A)
    c = 5 * D - 4 - t
    z = (pow(A, -1, 2 ** h) * (1 + 2 ** (h - 1))) % (2 ** h)
    a = 2 ** g * z - 1
    M = 2 ** (g + h)
    assert 0 < a < M and z % 2 == 1
    assert affine((1,) * (g - 1) + (h,)) == (E, B)
    assert a == ((2 ** E - B) * pow(A, -1, M)) % M
    assert ((a + 1) & -(a + 1)) == 2 ** g
    return {'g': g, 'h': h, 'E': E, 'A': A, 'B': B,
            'D': D, 't': t, 'c': c, 'a': a, 'M': M}


def positive_candidate(g):
    # At most this one h can be a genuine positive-charge profile, at any n.
    A = 3 ** g
    E = 0
    while 5 * (1 << E) <= 4 * A + 2 ** g:
        E += 1
    return family_profile(g, E - g + 1)


def sole_return_candidate(g):
    # Any genuine return has3/4<D<16/11<3/2.  Exactly one dyadic
    # denominator lies in the wider interval(3/4,3/2) for a fixed g.
    E = (3 ** (g + 1)).bit_length() - 2
    p = family_profile(g, E - g + 1)
    assert Q(3, 4) < p['D'] < Q(3, 2)
    return p


def ceildiv(a, b):
    assert b > 0
    return -((-a) // b)


def active_interval(n, p):
    H = (4 * n - 2) // 3
    A, B, d = p['A'], p['B'], 2 ** p['E']
    lo = max(n, ceildiv(d * n - B, A))
    hi = min(H, (d * H - B) // A)
    a, M = p['a'], p['M']
    b = a + M * ceildiv(lo - a, M)
    return lo, hi, b


def exact_family_sums(n):
    H = (4 * n - 2) // 3
    boundary = total = Q(0)
    active = []
    for g in range(2, (H + 1).bit_length()):
        p = positive_candidate(g)
        lo, hi, b = active_interval(n, p)
        if b > hi:
            continue
        assert b >= lo and b - p['M'] < lo and p['c'] > 0
        assert p['c'] < Q(8 * n + 5, 3 * n)
        assert ((b + 1) & -(b + 1)) == 2 ** g
        x = b
        for j in range(g):
            x, e = odd_step(x)
            assert e == (1 if j < g - 1 else p['h'])
            assert (x > H) if j < g - 1 else (n <= x <= H)
        boundary += p['c'] / (b + 5)
        total += sum((p['c'] / (u + 5) for u in range(b, hi + 1, p['M'])), Q(0))
        active.append((g, p['h'], b))
    k = max(0, (H + 1).bit_length() - 2)
    assert boundary <= Q(8 * n + 5, 3 * n) * k / (n + 5)
    return boundary, total, active


def progression_sum(n, classes):
    H = (4 * n - 2) // 3
    answer = Q(0)
    for a, M, c in classes:
        first = a + max(0, ceildiv(n - a, M)) * M
        answer += sum((c / (u + 5) for u in range(first, H + 1, M)), Q(0))
    return answer


def least_high(n):
    H = (4 * n - 2) // 3
    h = H + 1
    if h % 2 == 0:
        h += 1
    while h % 3 == 0:
        h += 2
    return h


def structural_controls():
    controls = []
    for g in range(2, 65):
        p = positive_candidate(g)
        for u in [p['a'], p['a'] + p['M']]:
            x = u
            for j in range(g):
                x, e = odd_step(x)
                assert e == (1 if j < g - 1 else p['h'])
            assert 2 ** p['E'] * x == p['A'] * u + p['B']
        candidate = sole_return_candidate(g)
        D, q = candidate['D'], 1 - candidate['t']
        lower = (3 * q + 2 * D) / (4 * D - 3)
        lo = max(3, ceildiv(lower.numerator, lower.denominator))
        a, M = candidate['a'], candidate['M']
        b = a + M * ceildiv(lo - a, M)
        upper = None if D < Q(4, 3) else (4 * q - 2 * D) / (3 * D - 4)
        retained = upper is None or b <= upper
        if retained:
            x = b
            for j in range(g):
                x, e = odd_step(x)
                assert e == (1 if j < g - 1 else candidate['h'])
            n = min(b, x)
            H = (4 * n - 2) // 3
            assert max(b, x) <= H
            assert b * 3 + 2 <= 4 * x and x * 3 + 2 <= 4 * b
            assert D < Q(16, 11)
            if candidate['c'] > 0:
                assert candidate['E'] == p['E']
        controls.append({'g': g, 'positive_candidate_h': p['h'],
                         'positive_candidate_E': p['E'],
                         'positive_candidate_residue': p['a'],
                         'positive_candidate_coefficient': str(p['c']),
                         'sole_return_candidate_h': candidate['h'],
                         'sole_return_candidate_E': candidate['E'],
                         'sole_return_candidate_residue': a,
                         'sole_return_candidate_coefficient': str(candidate['c']),
                         'global_source_lower_bound': str(lower),
                         'global_source_upper_bound': None if upper is None else str(upper),
                         'first_residue_above_lower_bound': b,
                         'has_first_return_realization': retained})
    # Integer certificates for the five-rotation covering argument.
    assert 3 ** 12 > 2 ** 19
    assert 3 ** 5 < 2 ** 8
    assert 5 ** 4 > 2 * 4 ** 4
    good = []
    for g in range(2, 103):
        A = 3 ** g
        E = A.bit_length()
        if A < 2 ** E and 4 * 2 ** E < 5 * A:
            good.append(g)
            p = family_profile(g, E - g + 1)
            assert p['c'] > Q(5, 9)
            # The theorem applies to every odd n>=64*3^g.
            n = 64 * A + 1
            lo, hi, b = active_interval(n, p)
            assert b <= hi
    for start in range(2, 99):
        assert any(g in good for g in range(start, start + 5))
    # The enlarged family adds no edges to any previous n<=1079 graph.
    assert (4 * 1079 - 2) // 3 == 1438
    for g, E, a in [(9, 14, 22015), (10, 16, 91135)]:
        p = family_profile(g, E - g + 1)
        assert p['a'] == a > 1438
        assert Q(3, 4) < p['D'] < Q(16, 11)
        assert p['D'] / 2 <= Q(3, 4)
        assert p['D'] * 2 >= Q(16, 11)
    # A genuine newly covered edge, outside the previous gap cutoff.
    p = family_profile(9, 6)
    n = 19839
    lo, hi, b = active_interval(n, p)
    assert b == 22015 <= hi and p['c'] == Q(892, 6561)
    H = (4 * n - 2) // 3
    x = b
    for j in range(9):
        x, e = odd_step(x)
        assert e == (1 if j < 8 else 6)
        assert x > H if j < 8 else x == 26449 <= H
    return controls


def main():
    controls = structural_controls()
    classes = short_positive_classes()
    cutoff = 8191
    max_H = (4 * (cutoff - 2) - 2) // 3
    tables = {}
    for a, M, c in classes:
        assert a not in tables.setdefault(M, {})
        tables[M][a] = c
    short_point = [Q(0)] * (max_H + 1)
    new_point = [Q(0)] * (max_H + 1)
    for u in range(1, max_H + 1, 2):
        short_point[u] = sum((tab.get(u % M, Q(0)) for M, tab in tables.items()), Q(0)) / (u + 5)
        if u % 512 == 511:
            assert short_point[u] == 0
            new_point[u] = Q(1, u + 5)
    rows = []
    old_H = 0
    previous_n = 1
    short_sliding = new_sliding = Q(0)
    for n in range(3, cutoff, 2):
        H = (4 * n - 2) // 3
        for u in range(old_H + 1, H + 1):
            short_sliding += short_point[u]
            new_sliding += new_point[u]
        for u in range(previous_n, n):
            short_sliding -= short_point[u]
            new_sliding -= new_point[u]
        short_S = progression_sum(n, classes)
        reciprocal = progression_sum(n, [(511, 512, Q(1))])
        assert short_S == short_sliding and reciprocal == new_sliding
        C = Q(8 * n + 5, 3 * n)
        extra_S = C * reciprocal
        S = short_S + extra_S
        assert S < 1
        family_B, family_S, active = exact_family_sums(n)
        assert family_S <= S
        R = Q((n + 5) * H, n * (H + 5))
        completed = R / (1 - S)
        h = least_high(n)
        K = Q(n + 5, n) * Q(9 * H + 5, 9 * (H + 5)) / (1 - S)
        tail = K / (1 - Q(n - 2, 3 * h))
        assert completed < Q(11, 10)
        assert tail < Q(3, 2)
        rows.append({'n': n, 'H': H, 'short_charge_sum': str(short_S),
                     'additional_charge_bound': str(extra_S),
                     'combined_charge_bound': str(S),
                     'completed_bound': str(completed), 'tail_t_eq_n_bound': str(tail),
                     'single_reset_boundary': str(family_B),
                     'single_reset_exact_charge_sum': str(family_S),
                     'active_single_reset_profiles': active})
        old_H, previous_n = H, n
    mc = max(rows, key=lambda r: Q(r['completed_bound']))
    mt = max(rows, key=lambda r: Q(r['tail_t_eq_n_bound']))
    assert mc['n'] == 43 and Q(mc['completed_bound']) == Q(1088640, 994117)
    assert mt['n'] == 43 and Q(mt['tail_t_eq_n_bound']) == Q(24325110, 16899989)
    alpha = sum((c / (3 * M) for a, M, c in classes), Q(0))
    beta = sum((c for a, M, c in classes), Q(0))
    assert beta > 5 * alpha
    n = cutoff
    old_large = (alpha * n + beta) / (n + 5)
    new_large = Q(8 * n + 5, 3 * n) * (Q(n, 1536) + 1) / (n + 5)
    large_S = old_large + new_large
    large_completed = Q(4 * (n + 5), 4 * n + 15) / (1 - large_S)
    large_tail = Q(4 * (n + 5), 3 * n) / (1 - large_S)
    assert large_completed < Q(mc['completed_bound'])
    assert large_tail < Q(mt['tail_t_eq_n_bound'])
    short_family_density = Q(44, 27) / 192 + Q(92, 81) / 1536 + Q(1364, 2187) / 12288 + Q(4820, 2187) / 49152
    family_density_upper = short_family_density + Q(5, 4 * 3 ** 9)
    assert family_density_upper == Q(756731, 80621568)
    certificate = {
        'scope': 'Completed gaps<=8 or a word(1^(g-1),h>=2) of arbitrary g; distinct positive-charge departures; unfinished tail inputs<=n.',
        'finite_threshold_count': len(rows), 'finite_range': [3, cutoff - 2],
        'completed_maximum': mc, 'tail_maximum': mt,
        'analytic_cutoff': cutoff, 'alpha_short': str(alpha), 'beta_short': str(beta),
        'large_additional_charge_bound': str(new_large),
        'large_combined_charge_bound': str(large_S),
        'large_completed_bound': str(large_completed), 'large_tail_bound': str(large_tail),
        'family_density_upper_bound': str(family_density_upper),
        'structural_controls': controls, 'rows': rows,
    }
    path = Path(__file__).with_name('infinite_terminal_reset_certificate.json')
    path.write_text(json.dumps(certificate, indent=2) + '\n')
    print('PASS: exact progression and sliding-band counts agree for', len(rows), 'thresholds')
    print('Completed maximum:', mc['completed_bound'], 'at n=', mc['n'])
    print('Tail maximum:', mt['tail_t_eq_n_bound'], 'at n=', mt['n'])
    print('Large-n completed:', large_completed)
    print('Large-n tail:', large_tail)
    print('Full single-reset family density upper bound:', family_density_upper)
    print('Certificate:', path, 'bytes:', path.stat().st_size)


if __name__ == '__main__':
    main()
