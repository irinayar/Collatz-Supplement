from fractions import Fraction as Q
from itertools import product

def F(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def options(n):
 H=(4*n-2)//3;out={g:[] for g in(2,3,4,5,7)}
 for u in range(n,H+1,2):
  x=u;E=0
  for j in range(1,8):
   x,e=F(x);E+=e
   if x<=H:
    if x>=n:
     assert j in out,(n,u,j)
     rho=Q((1<<E)*(x+5),3**j*(u+5))
     out[j].append((rho,u,x))
    break
 for g in out:out[g].sort(reverse=True)
 return out

def threshold(K):
 R=3*K
 while 2**K*8**(R+2)>9**(R+2):R+=2
 E=(3*R+K)//2;T=Q(2**E,3**R)
 n=3
 while (1+Q(16,9*(n+5)))**K>=T:n+=2
 return n,R,T

for K in range(1,16):
 N,Rmax,T=threshold(K);passing=[]
 for n in range(3,N,2):
  o=options(n);c={g:len(o[g]) for g in o}
  if c[3]+c[5]+c[7]<K:continue
  p={}
  for g in(3,5,7):
   p[g]=[Q(1)]
   for rho,_,_ in o[g]:p[g].append(p[g][-1]*rho)
  passed=False
  for a3 in range(min(K,c[3])+1):
   for a5 in range(min(K-a3,c[5])+1):
    a7=K-a3-a5
    if a7>c[7]:continue
    posbound=p[3][a3]*p[5][a5]*p[7][a7]
    baseR=3*a3+5*a5+7*a7
    for a2 in range(c[2]+1):
     for a4 in range(c[4]+1):
      R=baseR+2*a2+4*a4
      if R>Rmax:continue
      E=(3*R+K)//2;G=Q(2**E,3**R)
      if 1<G<=posbound:
       passing.append((n,(a2,a3,a4,a5,a7),R,E,str(G),str(posbound)));passed=True;break
     if passed:break
    if passed:break
   if passed:break
 print('K',K,'tail',N,'Rmax',Rmax,'passing_n',len(passing),'first',passing[:1],flush=True)
