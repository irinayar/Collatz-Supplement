from fractions import Fraction as Q
from math import log2
import time

def proper_cap(j,N):
    # largest E with2^E <[(3N+1)/N]^j
    num=(3*N+1)**j;den=N**j
    cap=num.bit_length()-den.bit_length()
    while (1<<max(cap,0))*den>=num:cap-=1
    while (1<<(cap+1))*den<num:cap+=1
    return cap

def final_bounds(g,N):
    a=3**g
    # D>3/4 =>4*2^E>3*a
    lo=(3*a).bit_length()-3
    while 4*(1<<lo)<=3*a:lo+=1
    num=4*(3*N+1)**g;den=3*N**g
    hi=num.bit_length()-den.bit_length()
    while (1<<max(hi,0))*den>=num:hi-=1
    while (1<<(hi+1))*den<num:hi+=1
    return lo,hi

def dp(N=129,L=300):
    f=Q(3*N+1,3*N)
    states={1:(1,1,1,1)}
    total=0.;rows=[]
    for g in range(2,L+1):
        lo,hi=final_bounds(g,N);cap=proper_cap(g,N)
        n=b=0;mn=None;mx=None
        nexts={};row=0.;mass=0
        for E in range(2,max(hi,cap)+1):
            # For internal transition allowedlast>=1: parentE<=E-1; forfinal>=2 parentE<=E-2.
            if E-2 in states:
                nn,bb,ll,hh=states[E-2]
                n+=nn;b+=3*bb+(1<<(E-2))*nn
                ll=3*ll+(1<<(E-2));hh=3*hh+(1<<(E-2))
                mn=ll if mn is None else min(mn,ll);mx=hh if mx is None else max(mx,hh)
            if lo<=E<=hi and n:
                a=3**g;d=1<<E;T=5*(a-d)
                if T<=mn:pos=b-T*n
                elif T>=mx:pos=0
                else:pos=(mx-T)*(b-mn*n)/(mx-mn)
                row+=pos/(6*a*d)
            nn=n;bb=b;ll=mn;hh=mx
            if E-1 in states:
                nd,bd,ld,hd=states[E-1]
                nn+=nd;bb+=3*bd+(1<<(E-1))*nd
                ld=3*ld+(1<<(E-1));hd=3*hd+(1<<(E-1))
                ll=ld if ll is None else min(ll,ld);hh=hd if hh is None else max(hh,hd)
            if E<=cap and nn:nexts[E]=(nn,bb,ll,hh)
        total+=row;rows.append((g,row,total))
        states=nexts
        if g in (8,20,50,100,200,L):print(N,g,row,total,len(states))
    return rows,states

if __name__=='__main__':
    t=time.time();dp();print('seconds',time.time()-t)
