from fractions import Fraction as Q
from itertools import product
import json

def F(u):
 z=3*u+1;e=(z&-z).bit_length()-1
 return z>>e,e

def words(E,k=7):
 def comps(total,size,mins):
  if size==1:
   if total>=mins[0]:yield (total,)
   return
  for v in range(mins[0], total-sum(mins[1:])+1):
   for rest in comps(total-v,size-1,mins[1:]):yield (v,)+rest
 for rest in comps(E-1,k-1,[1]*(k-2)+[2]):yield (1,)+rest

def affine(word):
 U=E=0;row=[]
 for j,e in enumerate(word,1):
  U=3*U+(1<<E);E+=e;row.append((3**j,U,1<<E))
 return row

def residue(word):
 E=sum(word);mod=1<<(E+1);aff=affine(word);a,U,d=aff[-1]
 # endpoint odd iff a u+U=2^E mod2^(E+1), and exact previous valuations independently replay
 r=((d-U)*pow(a,-1,mod))%mod
 u=r
 for e in word:
  u,ee=F(u)
  assert ee==e,(word,r,e,ee)
 return r

def n_interval(states):
 # n<=u,w and 3*max(u,w)+2<=4n; intermediate x>H iff 4n<=3x+1.
 lo=max(3,(3*max(states[0],states[-1])+5)//4)
 hi=min(states[0],states[-1], min((3*x+1)//4 for x in states[1:-1]))
 if lo%2==0:lo+=1
 if hi%2==0:hi-=1
 return lo,hi

rows=[]
for word in words(11):
 aff=affine(word);a,B,d=aff[-1];r=residue(word)
 exclusions=[]
 # If an intermediate state <=departure or <=arrival for all u>=r => impossible first return.
 for j,(aj,Bj,dj) in enumerate(aff[:-1],1):
  for name,at,Bt,dt in [('source',1,0,1),('arrival',a,B,d)]:
   slope=at*dj-aj*dt;intercept=Bt*dj-Bj*dt
   if slope>=0 and slope*r+intercept>=0:
    exclusions.append((j,name,slope,intercept))
 witnesses=[]
 for t in range(20):
  u=r+4096*t;z=u;ss=[u]
  for e in word:z,ee=F(z);ss.append(z);assert e==ee
  lo,hi=n_interval(ss)
  if lo<=hi:witnesses.append({'n':lo,'u':u,'w':z,'t':t,'states':ss,'n_upper':hi});break
 rows.append({'word':word,'B':B,'residue':r,'charge_num':B+5*(d-a),'exclusions':exclusions,'witnesses':witnesses})
print('rows',len(rows),'witness',sum(bool(x['witnesses']) for x in rows),'excluded',sum(bool(x['exclusions']) for x in rows))
for x in rows:print(x)
for u in range(3,15,2):
 z=u;es=[];ss=[u]
 for _ in range(7):z,e=F(z);ss.append(z);es.append(e)
 print('small',u,es,sum(es),ss)
json.dump(rows,open('seven_classification_agent/rows.json','w'),indent=2)
