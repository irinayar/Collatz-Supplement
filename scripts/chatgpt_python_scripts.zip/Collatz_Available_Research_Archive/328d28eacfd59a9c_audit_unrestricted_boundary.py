#!/usr/bin/env python3
"""Independent replay and interval-arrangement audit of the finite boundary.

No producer import. Every recorded source path is replayed literally, all
positive-return intervals are reconstructed, and least sources are obtained
by splitting at interval endpoints, not by the producer's source-union or
heap-sweep algorithms. Only the stated finite threshold range is certified.
"""
from collections import defaultdict
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json


def odd_step(u):
    z=3*u+1
    e=(z&-z).bit_length()-1
    return z>>e,e


def ceil_div(a,b):
    return -((-a)//b)


def audit(c):
    N=c['maximum_threshold']
    Hmax=(4*N-2)//3
    scale=c['directed_denominator']
    assert N==65535 and Hmax==87379 and scale==2**96
    paths=c['source_first_descent_paths']
    assert [p['u'] for p in paths]==list(range(3,Hmax+1,4))
    reconstructed={}
    maxsteps=0
    for path in paths:
        u=path['u'];x=u;E=B=resets=0
        states=[u];word=[]
        for index,prescribed in enumerate(path['word']):
            x,e=odd_step(x)
            assert e==prescribed
            B=3*B+2**E;E+=e;word.append(e);states.append(x)
            resets+=(e>=2)
            lower=max(3,ceil_div(3*max(u,x)+2,4))
            upper=min(u,x,N)
            if len(word)>1:
                upper=min(upper,(3*min(states[1:-1])+1)//4)
            lower+=(lower%2==0);upper-=(upper%2==0)
            d=B+5*(2**E-3**len(word))
            if lower<=upper and d>0:
                key=(u,tuple(word))
                assert key not in reconstructed
                reconstructed[key]=dict(u=u,w=x,n_lo=lower,n_hi=upper,
                    E=E,B=B,coefficient_numerator=d,resets=resets,
                    charge_upper_numerator=ceil_div(scale*d,3**len(word)*(u+5)))
            if index<len(path['word'])-1:
                assert x>u
        assert x<u and x==path['first_strict_descent']
        maxsteps=max(maxsteps,len(word))
    assert len(paths)==21845 and maxsteps==85
    supplied={(r['u'],tuple(r['word'])):r for r in c['positive_source_records']}
    assert len(supplied)==len(c['positive_source_records'])==6757
    assert set(supplied)==set(reconstructed)
    for key,p in reconstructed.items():
        r=supplied[key]
        assert all(p[field]==r[field] for field in p)

    grouped=defaultdict(list)
    for (u,word),p in reconstructed.items():
        grouped[word].append(p)
    assert len(grouped)==1767
    first={}
    for word,records in grouped.items():
        endpoints=sorted({e for r in records for e in (r['n_lo'],r['n_hi']+2)})
        pieces=[]
        for lo,stop in zip(endpoints,endpoints[1:]):
            active=[r for r in records if r['n_lo']<=lo<=r['n_hi']]
            if not active:continue
            chosen=min(active,key=lambda r:r['u'])
            hi=stop-2
            if pieces and pieces[-1][0]==chosen['u'] and pieces[-1][2]+2==lo:
                pieces[-1]=(chosen['u'],pieces[-1][1],hi)
            else:
                pieces.append((chosen['u'],lo,hi))
        for u,lo,hi in pieces:
            p=reconstructed[(u,word)]
            first[(word,u,lo,hi)]=p
    oldfirst={(tuple(r['word']),r['u'],r['n_lo'],r['n_hi']):r
              for r in c['first_source_records']}
    assert len(first)==len(oldfirst)==6180
    assert set(first)==set(oldfirst)
    for key,p in first.items():
        r=oldfirst[key]
        assert p['charge_upper_numerator']==r['charge_upper_numerator']
        assert p['coefficient_numerator']==r['coefficient_numerator']
        assert r['coefficient_denominator']==3**len(key[0])

    # Reconstruct all threshold rows from independently derived intervals.
    diffB=[0]*(N+3);diffS=[0]*(N+3)
    countB=[0]*(N+3);countS=[0]*(N+3)
    categories={k:[0]*(N+3) for k in ('one','two','three','four_or_more')}
    for p in reconstructed.values():
        lo,hi,weight=p['n_lo'],p['n_hi'],p['charge_upper_numerator']
        diffS[lo]+=weight;diffS[hi+2]-=weight
        countS[lo]+=1;countS[hi+2]-=1
    for (word,u,lo,hi),p in first.items():
        weight=p['charge_upper_numerator']
        diffB[lo]+=weight;diffB[hi+2]-=weight
        countB[lo]+=1;countB[hi+2]-=1
        category=('one','two','three')[p['resets']-1] if p['resets']<=3 else 'four_or_more'
        categories[category][lo]+=weight
        categories[category][hi+2]-=weight
    Bnum=Snum=Bcount=Scount=0
    group_totals={k:0 for k in categories}
    target=Q(54119252374498189,450283905890997363)
    max_tail=(Q(0),0)
    for row in c['rows']:
        n=row['n'];H=(4*n-2)//3
        Bnum+=diffB[n];Snum+=diffS[n]
        Bcount+=countB[n];Scount+=countS[n]
        assert (Bnum,Snum,Bcount,Scount)==(
            row['boundary_upper_numerator'],row['total_upper_numerator'],
            row['boundary_terms'],row['total_terms'])
        for k in categories:group_totals[k]+=categories[k][n]
        assert group_totals==row['boundary_groups']
        assert 0<=Bnum<=Snum<scale
        if n not in (21,23):
            assert Q(Bnum,scale)<target
        h=H+1
        while not(h%2 and h%3):h+=1
        K=Q((n+5)*(9*H+5)*scale,9*n*(H+5)*(scale-Snum))
        tail=K/(1-Q(n-2,3*h))
        max_tail=max(max_tail,(tail,n))
    assert len(c['rows'])==32767
    assert str(max_tail[0])==c['maximum_tail_upper']
    assert max_tail[1]==c['maximum_tail_n']
    controls=[]
    for n in (21,23):
        active=[p for (word,u,lo,hi),p in first.items() if lo<=n<=hi]
        assert len(active)==1
        p=active[0]
        assert p['u']==27 and p['w']==23 and p['E']==59 and p['resets']==15
        word=next(word for (u,word),r in reconstructed.items() if r is p)
        assert len(word)==37
        exact=Q(p['coefficient_numerator'],3**37*32)
        assert exact==target==Q(7*2**56,3**37)-1
        controls.append(dict(n=n,u=27,w=23,gap=37,E=59,resets=15,
                             exact_boundary=str(exact)))
    assert target<Q(121,1000)<Q(6,25)
    return dict(status='PASS',
        scope='All odd thresholds 3..65535 only; no reset or return-length cutoff.',
        source_paths_replayed=21845,maximum_first_descent_steps=85,
        reconstructed_positive_source_intervals=6757,
        distinct_positive_profiles=1767,
        independent_first_source_interval_method='Arrangement of every interval endpoint, then minimum active source on each segment.',
        first_source_intervals=6180,threshold_rows_reproduced=32767,
        exact_boundary_maximum=str(target),maximizing_thresholds=[21,23],
        clean_boundary_strict_upper='121/1000',
        source27_controls=controls,
        unrestricted_n_tail_envelope_maximum=str(max_tail[0]),
        unrestricted_n_tail_envelope_maximum_n=max_tail[1],
        tail_scope='An upper-envelope maximum, not a trajectory product or counterexample.',
        completeness='All possible sources lie below H(65535). Odd sources 1 mod4 descend below the band immediately. Every first return must end no later than the first strict descent below its departure; all recorded paths are checked to reach that descent.')


def main():
    if not __debug__:
        raise SystemExit('Run without optimization: exact verification uses assertions.')
    parser=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    parser.add_argument('--producer-certificate',type=Path,
        default=here.parent/'first_source_work'/'unrestricted_finite_boundary.json')
    parser.add_argument('--output',type=Path,
        default=here/'unrestricted_boundary_independent_audit.json')
    args=parser.parse_args()
    result=audit(json.loads(args.producer_certificate.read_text()))
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
