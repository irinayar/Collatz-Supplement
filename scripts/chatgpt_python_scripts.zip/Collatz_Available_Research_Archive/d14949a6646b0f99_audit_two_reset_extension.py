#!/usr/bin/env python3
"""Independent audit of the two-reset extension and its small-band graphs.

The source enumeration uses literal odd steps, not the run formula.  The finite
charge sums use residue-progression filling and direct interval membership,
not the main certificate's residue lookup and threshold difference events.
"""
from fractions import Fraction as Q
from math import gcd
from pathlib import Path
import json
from verify_infinite_terminal_reset import short_positive_classes, odd_step, least_high, progression_sum

BASE = Path(__file__).resolve().parent
ROOT_CERT = BASE.parent / 'continuation_work' / 'two_reset_certificate.json'
SCALE = 1 << 64
CUTOFF = 32767


def ceiling(q):
    return -((-q.numerator) // q.denominator)


def literal_sources(maximum_n):
    maximum_H = (4 * maximum_n - 2) // 3
    records = []
    for u in range(3, maximum_H + 1, 4):
        x, E, B, resets = u, 0, 0, 0
        states = [u]
        word = []
        while resets < 2:
            x, e = odd_step(x)
            B = 3 * B + (1 << E)
            E += e
            word.append(e)
            states.append(x)
            if e == 1:
                continue
            resets += 1
            g = len(word)
            assert (1 << E) * x == 3 ** g * u + B
            if g >= 9:
                lo = max(3, ceiling(Q(3 * max(u, x) + 2, 4)))
                hi = min(u, x, (3 * min(states[1:-1]) + 1) // 4, maximum_n)
                if lo % 2 == 0:
                    lo += 1
                if hi % 2 == 0:
                    hi -= 1
                if lo <= hi:
                    charge = Q(B + 5 * ((1 << E) - 3 ** g), 3 ** g * (u + 5))
                    weight = ceiling(SCALE * charge) if charge > 0 else 0
                    if charge > 0:
                        assert Q(weight - 1, SCALE) < charge <= Q(weight, SCALE)
                    # Independently check all thresholds in each admitted range.
                    for n in range(lo, hi + 1, 2):
                        H = (4 * n - 2) // 3
                        assert n <= u <= H and n <= x <= H
                        assert all(v > H for v in states[1:-1])
                    records.append(dict(u=u, w=x, g=g, E=E, B=B,
                                        lo=lo, hi=hi, charge=str(charge),
                                        integer_weight=weight, word=list(word)))
            if resets == 1 and x <= u:
                # This state cannot be proper to a first return: H>=u.
                break
    return records


def allowed_edge(n, u, extended):
    H = (4 * n - 2) // 3
    x, g, resets = u, 0, 0
    while True:
        x, e = odd_step(x)
        g += 1
        resets += e >= 2
        permitted = g <= 8 or (extended and resets <= 2)
        if x <= H:
            return (x, g) if n <= x and permitted else None
        if g >= 8 and (not extended or resets >= 3):
            return None


def rank_function(vertices, edges):
    ranks = {}
    for u in vertices:
        stack = []
        seen = set()
        x = u
        while x not in ranks:
            assert x not in seen, ('directed cycle', x)
            seen.add(x)
            stack.append(x)
            if x not in edges:
                ranks[x] = 0
                break
            x = edges[x][0]
        while stack:
            y = stack.pop()
            if y in edges:
                ranks[y] = ranks[edges[y][0]] + 1
            else:
                ranks[y] = 0
    for u, (v, g) in edges.items():
        assert ranks[u] == ranks[v] + 1
    return ranks


def graph_audit():
    counts = dict(thresholds=0, vertices=0, old_edges=0, enlarged_edges=0,
                  maximum_rank=0)
    graph_records = []
    added = []
    for n in range(3, 1081, 2):
        H = (4 * n - 2) // 3
        vertices = list(range(n, H + 1, 2))
        old, new = {}, {}
        for u in vertices:
            edge = allowed_edge(n, u, False)
            if edge is not None:
                old[u] = edge
            edge = allowed_edge(n, u, True)
            if edge is not None:
                new[u] = edge
        for u, edge in old.items():
            assert new[u] == edge
        for u, edge in new.items():
            if u not in old:
                added.append(dict(n=n, u=u, w=edge[0], g=edge[1]))
        ranks = rank_function(vertices, new)
        counts['thresholds'] += 1
        counts['vertices'] += len(vertices)
        counts['old_edges'] += len(old)
        counts['enlarged_edges'] += len(new)
        counts['maximum_rank'] = max(counts['maximum_rank'], max(ranks.values()))
        graph_records.append(dict(n=n, edges=[[u, v, g] for u, (v, g) in new.items()],
                                  ranks=[[u, ranks[u]] for u in vertices]))
    assert counts == dict(thresholds=539, vertices=48690, old_edges=6580,
                          enlarged_edges=6603, maximum_rank=3), counts
    assert added == [dict(n=n, u=479, w=577, g=9) for n in range(435, 481, 2)]
    return counts, added, graph_records


def refined_cover_audit(root):
    cover = [dict(first_run_at_least=9, residue=511, modulus=512)]
    expected_ranges = [[2], [2], [2, 3], [2, 3], [2, 3, 4],
                       [2, 3, 4, 5], [2, 3, 4, 5]]
    for a, expected in zip(range(2, 9), expected_ranges):
        minimum_u = max(11, 2 ** a - 1)
        A, B = 3 ** a, 3 ** a - 2 ** a
        h = 2
        found = []
        while 2 ** (a - 1 + h) * minimum_u < A * minimum_u + B:
            found.append(h)
            d = 2 ** (a - 1 + h)
            M = d * 2 ** (9 - a)
            r = ((-d - B) * pow(A, -1, M)) % M
            assert ((r + 1) & -(r + 1)) == 2 ** a
            z = (r + 1) >> a
            v = A * z - 1
            exact_h = (v & -v).bit_length()
            assert exact_h == h
            cover.append(dict(first_run=a, reset_exponent=h,
                              residue=r, modulus=M))
            h += 1
        assert found == expected
    assert len(cover) == 18
    for i, p in enumerate(cover):
        for q in cover[:i]:
            assert (p['residue'] - q['residue']) % gcd(p['modulus'], q['modulus']) != 0
    density = sum((Q(1, p['modulus']) for p in cover), Q(0))
    assert density == Q(25, 2048)
    Gmax, Tmax = Q(1088640, 994117), Q(24325110, 16899989)
    classes = short_positive_classes()
    other_completed = (Q(0), 0)
    other_tail = (Q(0), 0)
    for row in root['finite_rows']:
        n = row['n']
        H = (4 * n - 2) // 3
        if n == 43:
            S = progression_sum(n, classes)
            assert S == Q(26, 405)
            assert row['extra_upper_numerator'] == 0
        else:
            S = Q(row['charge_upper_numerator'], SCALE)
        completed = Q((n + 5) * H, n * (H + 5)) / (1 - S)
        h = least_high(n)
        tail = Q(n + 5, n) * Q(9 * H + 5, 9 * (H + 5)) / (1 - S) / (1 - Q(n - 2, 3 * h))
        if n == 43:
            assert completed == Gmax and tail == Tmax
        else:
            assert completed < Gmax and tail < Tmax
            other_completed = max(other_completed, (completed, n))
            other_tail = max(other_tail, (tail, n))
    n = 16383
    alpha, beta = Q(34627, 1119744), Q(65780, 243)
    cap = Q(11, 3) + Q(23, 3 * n) + Q(5, n * n)
    S = (alpha * n + beta) / (n + 5) + cap * (Q(25 * n, 6144) + 18) / (n + 5)
    large_completed = Q(4 * (n + 5), 4 * n + 15) / (1 - S)
    large_tail = Q(4 * (n + 5), 3 * n) / (1 - S)
    assert large_tail == Q(973193163894816768, 681238246055842439)
    assert large_completed < Gmax and large_tail < Tmax
    assert beta > 5 * alpha and 18 > 5 * Q(25, 6144)
    return dict(covering_classes=cover, density=str(density),
                analytic_start=16383, large_completed=str(large_completed),
                large_tail=str(large_tail), exact_completed_maximum=str(Gmax),
                exact_tail_maximum=str(Tmax), exact_maximum_threshold=43,
                largest_other_completed_n=other_completed[1],
                largest_other_completed=str(other_completed[0]),
                largest_other_tail_n=other_tail[1],
                largest_other_tail=str(other_tail[0]))


def main():
    root = json.loads(ROOT_CERT.read_text())
    all_profiles = literal_sources(CUTOFF - 2)
    positive = [p for p in all_profiles if Q(p['charge']) > 0]
    theirs = root['long_positive_source_profiles']
    key = lambda p: (p['u'], p['g'], p['E'], p['B'])
    ours_map = {key(p): p for p in positive}
    theirs_map = {key(p): p for p in theirs}
    assert len(ours_map) == len(positive) == len(theirs_map) == 28
    assert ours_map.keys() == theirs_map.keys()
    for k, p in ours_map.items():
        r = theirs_map[k]
        assert (p['w'], p['lo'], p['hi'], p['integer_weight']) == (
            r['w'], r['threshold_lo'], r['checked_threshold_hi'],
            r['dyadic_weight_numerator'])
    classes = short_positive_classes()
    maximum_H = (4 * (CUTOFF - 2) - 2) // 3
    point = [0] * (maximum_H + 1)
    number_of_terms = [0] * (maximum_H + 1)
    for a, M, c in classes:
        for u in range(a, maximum_H + 1, M):
            q = c / (u + 5)
            k = ceiling(SCALE * q)
            assert Q(k - 1, SCALE) < q <= Q(k, SCALE)
            point[u] += k
            number_of_terms[u] += 1
    prefix = [0]
    for x in point[1:]:
        prefix.append(prefix[-1] + x)
    maximum_rounding_terms = 0
    for row in root['finite_rows']:
        n = row['n']
        H = (4 * n - 2) // 3
        active = [p for p in positive if p['lo'] <= n <= p['hi']]
        extra = sum(p['integer_weight'] for p in active)
        complete = prefix[H] - prefix[n - 1] + extra
        assert extra == row['extra_upper_numerator']
        assert complete == row['charge_upper_numerator']
        assert complete < SCALE
        maximum_rounding_terms = max(maximum_rounding_terms,
                                    sum(number_of_terms[n:H + 1]) + len(active))
    small = literal_sources(1079)
    assert len(small) == 1
    assert (small[0]['u'], small[0]['w'], small[0]['lo'], small[0]['hi']) == (479, 577, 435, 479)
    graph_counts, added_edges, graph_records = graph_audit()
    refined = refined_cover_audit(root)
    result = dict(
        audit='PASS',
        independent_method='Literal odd steps through second reset; progression-filled dyadic point weights; direct threshold membership; direct first-return graph and exact ranks.',
        finite_thresholds_checked=len(root['finite_rows']),
        long_positive_profiles=len(positive),
        maximum_dyadic_rounding_terms=maximum_rounding_terms,
        maximum_total_charge_rounding_error_strictly_less_than=str(Q(maximum_rounding_terms, SCALE)),
        refined_eighteen_class_audit=refined,
        small_graph_counts=graph_counts, added_small_graph_edges=added_edges,
        literal_long_positive_profiles=positive, small_graphs=graph_records)
    target = BASE / 'two_reset_independent_audit.json'
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('literal_long_positive_profiles', 'small_graphs',
                                   'refined_eighteen_class_audit',
                                   'added_small_graph_edges')}, indent=2))
    print('Audit certificate:', target, 'bytes:', target.stat().st_size)


if __name__ == '__main__':
    main()
