from fractions import Fraction as Q
from collections import Counter
from pathlib import Path
import json

K,L=4,10
caps=[]
for j in range(1,L+1):
    e=0
    while 2**(e+1)*11**j<34**j:e+=1
    caps.append(e)
nodes=[];leaves=[];excluded=[]
def visit(word,E,B,U,prefixes):
    j=len(word);k=sum(e>=2 for e in word)
    M=2**(E+1);r=((2**E-B)*pow(3**j,-1,M))%M
    first=r+max(0,(11-r+M-1)//M)*M
    if U is not None and first>U:
        excluded.append((word,E,B,U,first));return None
    lower=[(Q(1),Q(0))]+[(Q(4*2**ee,3*3**z),Q(4*2**ee,3*3**z)+Q(bb,3**z)) for z,ee,bb in prefixes]
    ell=max(x for x,d in lower);delta=min(d for x,d in lower if x==ell)
    p=dict(word=word,j=j,E=E,B=B,M=M,r=r,U=U,A=Q(B+2**E,3**j),m=K-k-1,ell=ell,delta=delta,children=[])
    nodes.append(p)
    if j==L:leaves.append(p);return p
    for e in range(1,caps[j]-E+1):
        if e>=2 and k==K-1:continue
        ee=E+e;bb=3*B+2**E;uu=U
        if 2**ee>3**(j+1):
            bnd=(bb-1)//(2**ee-3**(j+1));uu=bnd if uu is None else min(uu,bnd)
        child=visit(word+(e,),ee,bb,uu,prefixes+[(j+1,ee,bb)])
        if child:p['children'].append(child)
    return p
root=visit((),0,0,None,[])
def cap(p,n):
    return (n+5)*((1+p['A']/n)*(1+Q(1,n))**p['m']-1)+Q(5,3)-Q(10,3*n)
def cost(p,n,interval=True):
    if interval:
        ell,delta=p['ell'],p['delta']
        lam=Q(4,3)-ell;gamma=p['M']+delta-Q(2,3)
        if p['j']:
            assert lam*(5-delta)-ell*gamma<0
        assert ell*n+5-delta>0
        return cap(p,n)*(lam*n+gamma)/(p['M']*(ell*n+5-delta))
    return cap(p,n)*(Q(n,3*p['M'])+1)/(n+5)
def pick(p,n,interval):
    if p['U'] is not None and p['U']<n:return Q(0),[]
    if p['j']==L:return cost(p,n,interval),[p]
    solutions=[pick(c,n,interval) for c in p['children']]
    total=sum((q for q,ps in solutions),Q(0));chosen=[v for q,ps in solutions for v in ps]
    if p['j'] and cost(p,n,interval)<=total:return cost(p,n,interval),[p]
    return total,chosen

base=Path(__file__).resolve().parent.parent
old=json.loads((base/'three_reset_agent/three_reset_certificate.json').read_text())['short_positive_classes']
ten=json.loads((base/'continuation_audit/ten_return_profiles.json').read_text())
short=[]
for rec in old+ten:
    M=rec['modulus'];g={64:3,512:5,4096:7,16384:8,32768:9,131072:10}[M]
    r=rec['residue'];x=r;E=B=0;prefixes=[];word=[]
    for j in range(1,g+1):
        z=3*x+1;e=(z&-z).bit_length()-1;x=z>>e
        B=3*B+2**E;E+=e;prefixes.append((j,E,B));word.append(e)
    c=Q(B+5*(2**E-3**g),3**g)
    D=Q(2**E,3**g);q=Q(B,3**g)
    lower=[(Q(1),Q(0)),(D,q)]+[(Q(4*2**ee,3*3**z),Q(4*2**ee,3*3**z)+Q(bb,3**z)) for z,ee,bb in prefixes[:-1]]
    ell=max(v for v,d in lower);delta=min(d for v,d in lower if v==ell)
    upper=[(Q(4,3),Q(2,3)),(Q(4,3)*D,Q(2,3)*D+q)]
    rr=min(v for v,e in upper);eps=max(e for v,e in upper if v==rr)
    assert ell<rr
    short.append(dict(r=r,M=M,c=c,ell=ell,delta=delta,rr=rr,eps=eps))
def short_cost(p,n,interval=True):
    if not interval:return p['c']*(Q(n,3*p['M'])+1)/(n+5)
    ell,delta,rr,eps=p['ell'],p['delta'],p['rr'],p['eps']
    lam=rr-ell;gamma=p['M']+delta-eps
    assert gamma>0 and lam*(5-delta)-ell*gamma<0
    assert ell*n+5-delta>0
    return p['c']*(lam*n+gamma)/(p['M']*(ell*n+5-delta))

print('nodes',len(nodes),'leaves',len(leaves),'excluded',len(excluded),'finite',sum(p['U'] is not None for p in nodes))
print('short intervals asymptotic',float(sum((p['c']*(p['rr']-p['ell'])/(p['M']*p['ell']) for p in short),Q(0))))
for n in [16383,32767,65535,131071]:
    sh=sum((short_cost(p,n) for p in short),Q(0))
    full=sum((cost(p,n) for p in leaves),Q(0))
    ad,chosen=pick(root,n,True)
    print(n,'short',float(sh),'full',float(sh+full),'adaptive',float(sh+ad),'leaves',len(chosen),Counter(p['j'] for p in chosen))
    print('G',float(Q(4*(n+5),4*n+15)/(1-sh-ad)),'tail',float(Q(4*(n+5),3*n)/(1-sh-ad)))

