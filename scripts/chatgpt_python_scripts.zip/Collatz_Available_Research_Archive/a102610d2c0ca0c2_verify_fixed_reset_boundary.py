#!/usr/bin/env python3
"""Exact certificates for the fixed-reset boundary-growth theorem.

The theorem is analytic for every fixed reset count. This program checks its
integer constants and constructs actual first-return witnesses for the lower
family. Finite checks are not substituted for the general proof.

Python standard library only. No floating-point acceptance decisions.
"""

from fractions import Fraction as Q
from itertools import product
from math import comb, factorial
from pathlib import Path
import json


def odd_step(x):
    numerator = 3 * x + 1
    exponent = (numerator & -numerator).bit_length() - 1
    return numerator >> exponent, exponent


def affine(word):
    total = numerator = 0
    for exponent in word:
        numerator = 3 * numerator + (1 << total)
        total += exponent
    return total, numerator


def ceil_fraction(x):
    return -((-x.numerator) // x.denominator)


def candidate_exponent(g):
    """Unique exponent compatible with 3/4 < 2^E/3^g < 3/2."""
    return (3 ** (g + 1)).bit_length() - 2


def good_length(g):
    exponent = (3 ** g).bit_length()
    return 4 * (1 << exponent) < 5 * 3 ** g


def coefficient_cap(n, k):
    return (n + 5) * ((1 + Q(1, n)) ** k - 1) + Q(5, 3) - Q(10, 3 * n)


def coarse_length_cap(n, k):
    """A rationally certified cap; the proof states a sharper alpha-based cap."""
    H = (4 * n - 2) // 3
    # ceil(log2(H+1)), computed exactly, including powers of two.
    binary_length = H.bit_length()
    return (2 ** k - 1) * binary_length


def binomial_or_zero(n, r):
    return comb(n, r) if 0 <= r <= n else 0


def count_majorant(G, k):
    """Exact endpoint-composition majorant for profiles of at most k resets."""
    total = 0
    for g in range(2, G + 1):
        E = candidate_exponent(g)
        total += sum(binomial_or_zero(g - 2, ell - 1) *
                     binomial_or_zero(E - g - 1, ell - 1)
                     for ell in range(1, k + 1))
    return total


def integrated_count_majorant(G, k):
    return sum((Q((G - 1) ** (2 * ell - 1),
                  (2 * ell - 1) * factorial(ell - 1) ** 2)
                for ell in range(1, k + 1)), Q(0))


def lower_family_words(g, k):
    """All words in the explicitly counted lower family at one good length."""
    assert k >= 1 and g >= 8 * k and good_length(g)
    E = (3 ** g).bit_length()
    assert E == candidate_exponent(g)
    assert 2 * E > 3 * g
    m = g // (2 * k)
    assert m >= 4
    for internal_lengths in product(range(m, 2 * m), repeat=k - 1):
        last_length = g - sum(internal_lengths)
        assert last_length >= 2 * m
        lengths = internal_lengths + (last_length,)
        for internal_exponents in product(range(2, m // 2 + 1), repeat=k - 1):
            last_exponent = E - g + k - sum(internal_exponents)
            assert last_exponent >= 2
            resets = internal_exponents + (last_exponent,)
            word = tuple(exponent
                         for length, reset in zip(lengths, resets)
                         for exponent in (1,) * (length - 1) + (reset,))
            assert len(word) == g and sum(word) == E
            assert sum(exponent >= 2 for exponent in word) == k
            yield lengths, resets, word


def check_lower_family(g, k):
    assert good_length(g)
    n = 64 * 3 ** g + 1
    H = (4 * n - 2) // 3
    E = (3 ** g).bit_length()
    D = Q(1 << E, 3 ** g)
    modulus = 1 << (E + 1)
    assert 1 < D < Q(5, 4)
    # The whole real interval below contains compatible integer starts.
    lower_real = D * n
    upper = H - 2
    assert upper - lower_real > modulus
    lower = ceil_fraction(lower_real)

    records = []
    residues = set()
    words = set()
    for lengths, resets, word in lower_family_words(g, k):
        actual_E, B = affine(word)
        assert actual_E == E
        prefix_D = Q(1)
        affine_Q = Q(0)
        for index, (length, reset) in enumerate(zip(lengths, resets)):
            run_q = 1 - Q(2, 3) ** length
            affine_Q += prefix_D * run_q
            run_D = Q(1 << (length - 1 + reset), 3 ** length)
            if index < k - 1:
                assert 2 * reset <= length and run_D < Q(1, 2)
            prefix_D *= run_D
        assert prefix_D == D and affine_Q == Q(B, 3 ** g)
        assert Q(65, 81) <= affine_Q < 2
        c = affine_Q + 5 * (D - 1)
        assert c > Q(65, 81)

        residue = ((1 << E) - B) * pow(3 ** g, -1, modulus) % modulus
        source = residue + ((lower - residue + modulus - 1) // modulus) * modulus
        assert lower_real <= source <= upper
        states = [source]
        x = source
        for expected in word:
            x, actual = odd_step(x)
            assert actual == expected
            states.append(x)
        assert n <= source <= H and n <= x <= H
        assert all(z > H for z in states[1:-1])
        assert c < coefficient_cap(n, k)
        assert g <= coarse_length_cap(n, k)
        assert residue not in residues and word not in words
        residues.add(residue)
        words.add(word)

        # Only a compact witness is needed: all states regenerate from source.
        records.append(dict(lengths=lengths, reset_exponents=resets,
                            residue=residue, source=source, arrival=x,
                            B=B, coefficient=str(c)))

    m = g // (2 * k)
    expected_count = (m * (m // 2 - 1)) ** (k - 1)
    assert len(records) == expected_count
    return dict(k=k, g=g, n=n, H=H, E=E, modulus=modulus,
                profile_count=expected_count, witnesses=records)


def certify():
    # These exact comparisons establish the analytic rotation-gap constants.
    assert 3 ** 12 > 2 ** 19       # log2(3)-1 > 7/12
    assert 3 ** 5 < 2 ** 8         # log2(3)-1 < 3/5
    assert 5 ** 4 > 2 * 4 ** 4     # log2(5/4) > 1/4
    assert 3 ** 2 > 2 ** 3         # alpha > 3/2
    # Sanity check of the exact integer implementation of the good predicate.
    assert all(any(good_length(g) for g in range(start, start + 5))
               for start in range(1, 301))

    # The general proofs, not these samples, cover all n and all k.
    for k in range(1, 13):
        for n in (9 * k, 9 * k + 1, 20 * k + 1, 100 * k + 1):
            assert (1 + Q(1, n)) ** k < Q(9, 8)
            assert coefficient_cap(n, k) < Q(9 * k, 8) + Q(55, 24)
    for G in range(2, 61):
        for k in range(1, 7):
            assert count_majorant(G, k) <= integrated_count_majorant(G, k)

    rows = []
    for k in range(1, 7):
        g = next(g for g in range(8 * k, 8 * k + 5) if good_length(g))
        rows.append(check_lower_family(g, k))
    # A second block has more than one choice of an internal reset exponent.
    rows.append(check_lower_family(32, 2))
    rows.append(check_lower_family(39, 3))
    total = sum(row['profile_count'] for row in rows)
    return dict(
        theorem=('For each fixed integer k>=1, both the exact-k and at-most-k '
                 'first-source boundary functionals are Theta_k(log(n)^(2k-1)/n) '
                 'as odd n tends to infinity.'),
        implication=('An O_k(log(n)^k/n) bound is false for every fixed k>=2.'),
        general_proof='Fixed_Reset_Boundary_Theorem.md',
        construction_rows=rows,
        actual_first_return_witnesses_checked=total,
        status='PASS')


if __name__ == '__main__':
    certificate = certify()
    destination = Path(__file__).with_name('fixed_reset_boundary_certificate.json')
    destination.write_text(json.dumps(certificate, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(status=certificate['status'],
                         witness_count=certificate['actual_first_return_witnesses_checked'],
                         rows=[{key: row[key] for key in ('k', 'g', 'profile_count')}
                               for row in certificate['construction_rows']],
                         certificate=str(destination)), indent=2))
