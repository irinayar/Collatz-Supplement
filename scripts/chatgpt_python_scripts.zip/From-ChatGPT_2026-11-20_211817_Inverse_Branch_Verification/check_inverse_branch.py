from functools import lru_cache
INF=10**100
@lru_cache(None)
def H(x,k,r):
    if k<0 or r<0:return INF
    if k==0 and r==0:return x
    a=H(2*x,k-1,r) if k else INF
    b=H((2*x-1)//3,k,r-1) if r and x%3==2 else INF
    return min(a,b)
for x in range(3,35):
 for k in range(0,7):
  for r in range(0,9):
   h=H(x,k,r)
   if x%3==1 and (k+r)>0: assert h==H(2*x,k-1,r)
   if x%3==2 and (k+r)>0 and not (k==1 and r==0):
    a=H(4*x,k-2,r) if k>=2 else INF
    b=H((2*x-1)//3,k,r-1) if r else INF
    assert h==min(a,b),(x,k,r,h,a,b)
print('Exact two-branch recurrence verified on 32 endpoints x 7 budgets x 9 odd counts')
for k in range(1,9):
 print('x5 k',k,[(r,H(5,k,r)) for r in range(0,8) if H(5,k,r)<INF])
