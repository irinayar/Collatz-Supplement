"""Reproduce exact finite-depth image-density upper bounds (standard library only)."""
from fractions import Fraction
from math import comb, sqrt

def finite_binomial_bound(j):
    # For A~Binomial(j,1/2), d_{j+1} <= min_a (3^a/2^j + Pr[A>a]).
    tail = 0
    best = None
    for a in range(j, -1, -1):
        candidate = Fraction(3**a + tail, 2**j)
        if best is None or candidate < best[0]:
            best = candidate, a
        tail += comb(j, a)
    return best

# Independently established exact d_{j+1} for j=0,...,14.
known = ['1','5/6','3/4','5/8','25/48','43/96','77/192',
         '139/384','85/256','157/512','877/3072',
         '1639/6144','3071/12288','5767/24576','3617/16384']
for j, value in enumerate(known):
    upper, a = finite_binomial_bound(j)
    assert Fraction(value) <= upper, (j, value, upper)
    print(f'k={j+1:2d}: exact d={value:>12s}, upper={float(upper):.9f}, threshold a={a}')

q = (1+sqrt(3))/(2*sqrt(2))
rate = q**(2/3)
assert 0 < q < 1
print(f'Closed-form upper bound: d_(j+1) <= 2 * ({rate:.12f})^j')
for j in (50, 100, 200, 500):
    exact_bound, a = finite_binomial_bound(j)
    print(f'j={j:3d}: binomial bound={float(exact_bound):.12g}; '
          f'Chernoff bound={2*rate**j:.12g}; a={a}')
