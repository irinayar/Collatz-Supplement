from fractions import Fraction

def T(x):return x//2 if x%2==0 else (3*x+1)//2

def exact(j):
    groups=[set() for _ in range(j+1)]
    for r in range(1,(1<<j)+1):
        x=r;a=0
        for _ in range(j):
            a+=x&1;x=T(x)
        groups[a].add(x%(3**a))
    M=3**j
    covered=bytearray(M)
    delta={}
    total_covered=0
    for a in range(j,-1,-1):
        step=3**a
        for r in groups[a]:
            count=(M-1-r)//step+1
            old=covered[r::step].count(1)
            total_covered+=count-old
            covered[r::step]=b'\x01'*count
        delta[a]=Fraction(total_covered,M)
    result=delta[0]*Fraction(1,2**j)
    for a in range(1,j+1):
        result+=Fraction(3**a-3**(a-1),2**j)*delta[a]
    return result, len(groups[0]), sum(map(len,groups))

if __name__=='__main__':
    import sys
    upto=int(sys.argv[1]) if len(sys.argv)>1 else 14
    for j in range(upto+1):
        v,_,_=exact(j)
        print(j+1,v,float(v),flush=True)
