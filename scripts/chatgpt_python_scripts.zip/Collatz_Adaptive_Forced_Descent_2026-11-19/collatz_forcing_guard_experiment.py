from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def v2(n):
 c=0
 while n%2==0 and n>0: c+=1;n//=2
 return c

def min_d(j):
 d=0
 while (1<<(j+d))<=3**j:d+=1
 return d

def run():
 checks=0; rows=[]; examples=[]
 for j in range(2,81):
  d=min_d(j); D=(1<<(j+d))-3**j; threshold=Fraction((1<<d)-1,D)
  inv=pow(pow(3,j,1<<d),-1,1<<d)
  k=inv
  while k<=threshold:k+=1<<d
  n=(1<<j)*k-1; y=3**j*k-1
  assert y%(1<<d)==0 and y//(1<<d)<n
  if j<=14:
   x=n
   for _ in range(j):assert x%2==1;x=T(x);checks+=1
   assert x==y
   for _ in range(d):assert x%2==0;x=T(x);checks+=1
   assert x<n
   examples.append((j,d,k,n,j+d,x))
  rows.append((j,d,str(threshold),k))
 # validate all small actual first-descent starts and lower-bound on target depth
 for n in range(2,1001):
  x=n
  for i in range(0,30):
   # universal target lower bound: (3/2)^ell*n >= x+1
   for ell in range(0,9):
    if 3**ell*n < (x+1)*2**ell:
     for m in range(1,n):
      z=m
      for _ in range(ell):z=T(z)
      assert z!=x
      checks+=1
   x=T(x)
 return checks,examples,rows
if __name__=='__main__':
 checks,examples,rows=run()
 print('checks',checks,'examples',examples[:8],'j80',rows[-1])
