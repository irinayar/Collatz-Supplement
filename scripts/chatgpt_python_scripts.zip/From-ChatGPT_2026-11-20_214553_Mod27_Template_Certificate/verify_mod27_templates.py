#!/usr/bin/env python3
"""Exact certificate for the complete r=2 -> r=3 minimum-origin layer."""
from itertools import combinations
from functools import lru_cache

@lru_cache(None)
def H(x,k,r):
    if k<0 or r<0: return None
    if k+r==0:return x
    v=[]
    if k:
        a=H(2*x,k-1,r)
        if a is not None:v.append(a)
    if r and x%3==2:
        a=H((2*x-1)//3,k,r-1)
        if a is not None:v.append(a)
    return min(v) if v else None

def word(x,k,r):
    if k+r==0:return ''
    z=H(x,k,r)
    if k and H(2*x,k-1,r)==z:return word(2*x,k-1,r)+'E'
    if r and x%3==2 and H((2*x-1)//3,k,r-1)==z:return word((2*x-1)//3,k,r-1)+'O'
    raise AssertionError((x,k,r))

def replay(m,w):
    n=m
    for c in w:
        if c=='E':assert n%2==0; n//=2
        else:assert n%2==1; n=(3*n+1)//2
    return n

def numerator(w):
    a,b,steps=1,0,0
    for c in w:
        if c=='O':a,b=3*a,3*b+2**steps
        steps+=1
    return b

def feasible_residues(k):
    L=k+3;out=set()
    for inds in combinations(range(L),3):
        w=''.join('O' if j in inds else 'E' for j in range(L))
        V=numerator(w)
        for x in range(27):
            if (2**L*x-V)%27==0:out.add(x)
    return out

rows=[]
for x in range(3,30):
    if x%3==0:continue
    k=next(k for k in range(9) if H(x,k,3) is not None)
    m=H(x,k,3);w=word(x,k,3)
    assert len(w)==k+3 and w.count('O')==3
    assert replay(m,w)==x
    assert 9*m<2**k*(4*x-5),(x,k,m)
    assert x%27 in feasible_residues(k)
    for j in range(k):assert x%27 not in feasible_residues(j),(x,k,j)
    for t in [0,1,3,100]:
        xt=x+27*t
        for extra in [0,1,2,5]:
            kk=k+extra; mm=2**extra*(m+2**(k+3)*t)
            assert replay(mm,'E'*extra+w)==xt
            assert 9*mm<2**kk*(4*xt-5)
            h2=H(xt,kk,2)
            assert h2 is not None and mm<h2
    rows.append((x%27,x,k,m,w,2**k*(4*x-5)-9*m))
assert len(rows)==18
print('ALL 18 RESIDUE TEMPLATES CERTIFIED; 288 translated/budget replay cases passed')
for row in rows:print(*row)
