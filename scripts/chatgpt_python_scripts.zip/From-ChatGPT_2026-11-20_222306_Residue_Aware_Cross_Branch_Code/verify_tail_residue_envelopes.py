from itertools import combinations
from functools import lru_cache
from fractions import Fraction

@lru_cache(None)
def bounds(a,b,z,j):
    if a<0 or b<0:return None
    if b==0:
        return (2**a*z,2**a*z)
    j=min(j,b); L=a+b; modulus=3**j; target=(2**L*z)%modulus
    low=None;high=None
    for tail in combinations(range(L),j):
        p=tail[0]; q=b-j
        if p<q:continue
        Vtail=sum(3**(j-1-i)*2**t for i,t in enumerate(tail))
        if (Vtail-target)%modulus:continue
        d=3**q-2**q
        Vmin=3**j*d+Vtail
        Vmax=3**j*2**(p-q)*d+Vtail
        # Any earlier positions are < p, and q of them; Vprefix extremes exact.
        # Bounds for origin reverse order.
        denom=3**b; top=2**L*z
        minorigin=Fraction(top-Vmax,denom)
        maxorigin=Fraction(top-Vmin,denom)
        low=minorigin if low is None else min(low,minorigin)
        high=maxorigin if high is None else max(high,maxorigin)
    return (low,high) if low is not None else None

@lru_cache(None)
def exact(a,b,z):
    if a<0 or b<0:return ()
    if a==b==0:return (z,)
    res=[]
    if a:res.extend(exact(a-1,b,2*z))
    if b and z%3==2:res.extend(exact(a,b-1,(2*z-1)//3))
    return tuple(res)

def compare(k,r,x):
    y=(2*x-1)//3
    pairs=[('AB',(k-2,r+1,4*x),(k,r-1,y)),('BA',(k,r,y),(k-2,r,4*x))]
    out=[]
    for name, new,old in pairs:
        no=exact(*new); oo=exact(*old)
        if not no or not oo:continue
        actual=min(oo)-max(no)
        def coarse(a,b,z):
            L=a+b;d=3**b-2**b;den=3**b
            return (Fraction(2**L*z-2**a*d,den),Fraction(2**L*z-d,den))
        cnew=coarse(*new);cold=coarse(*old);c_gap=cold[0]-cnew[1]
        # j=1,2,3 and full r
        ds=[]
        for j in (1,2,3):
            bn=bounds(*new,j);bo=bounds(*old,j)
            ds.append(bo[0]-bn[1] if bn and bo else None)
        out.append((name,actual,c_gap,ds))
    return out

if __name__=='__main__':
    stats={name:{'total':0,'coarse':0,'j1':0,'j2':0,'j3':0,'actual_positive':0} for name in ('AB','BA')}
    examples=[]
    for k in range(2,10):
      for r in range(1,9):
       for x in range(5,101,3):
        for name,actual,c_gap,ds in compare(k,r,x):
         st=stats[name];st['total']+=1;st['actual_positive']+=actual>0;st['coarse']+=c_gap>0
         for j,d in enumerate(ds,1):st['j'+str(j)]+=d>0
         if ds[0]<=0 and ds[2]>0 and len(examples)<10:examples.append((name,k,r,x,actual,[str(d) for d in ds]))
    print(stats);print('improved examples:',examples)
    # Exact envelope containment, finite validation
    checked=0
    for a in range(0,7):
     for b in range(1,7):
      for z in range(3,45):
       origins=exact(a,b,z)
       if not origins:continue
       for j in (1,2,3):
        bd=bounds(a,b,z,j)
        assert bd is not None and bd[0]<=min(origins) and bd[1]>=max(origins),(a,b,z,j)
        checked+=1
    print('envelope checks',checked)
