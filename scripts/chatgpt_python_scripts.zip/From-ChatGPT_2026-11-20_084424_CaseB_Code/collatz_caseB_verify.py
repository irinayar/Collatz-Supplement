"""Exact small inverse-tree example, standard library only."""
def T(n): return n//2 if n%2==0 else (3*n+1)//2
def path(n,j):
    out=[n]
    for _ in range(j): out.append(T(out[-1]))
    return out

def inv(z,L):
    rows=[(z,0,'')]
    for _ in range(L):
        next_rows=[]
        for x,a,word in rows:
            next_rows.append((2*x,a,word+'E'))
            if x%3==2: next_rows.append(((2*x-1)//3,a+1,word+'O'))
        rows=next_rows
    return rows
w,L=13,4
source=208
higher=23
primitive=69
assert path(source,L+1)[-1]==path(higher,L+1)[-1]==path(primitive,L+1)[-1]==20
assert sum(x%2 for x in path(source,L+1)[:-1])==1
assert sum(x%2 for x in path(higher,L+1)[:-1])==3
assert sum(x%2 for x in path(primitive,L+1)[:-1])==2
assert not any(m<source and b==1 for m,b,_ in inv(3*w+1,L))
assert any(m<source and b==1 for m,b,_ in inv(w,L))
print('PASS: local Case B primitive replacement fails, global primitive exists')
print('source',path(source,L+1),'higher',path(higher,L+1),'primitive',path(primitive,L+1))
print('inverse from 40:',inv(40,L))
