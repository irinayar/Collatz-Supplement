from fractions import Fraction

def analyze(bits):
    a=0; U=0; r=0; B=None; power=1
    prefixes=[]
    for j,b in enumerate(bits):
        # At this point a represents the unique first-j parity cylinder.
        value=(3**r*a+U)//power
        epsilon=(b-value)%2
        a+=epsilon*power
        U=3**b*U+b*power
        r+=b
        power*=2
        if power>3**r:
            cap=U//(power-3**r)
            B=cap if B is None else min(B,cap)
        prefixes.append((a,U,r,B))
    return a,U,r,B,prefixes

def replay(n,bits):
    x=n
    vals=[]
    for b in bits:
        assert x%2==b
        x=(3*x+1)//2 if b else x//2
        vals.append(x)
    return vals

def test():
    count=0
    for L in range(1,13):
        for q in range(1<<L):
            bits=[(q>>i)&1 for i in range(L)]
            a,U,r,B,_=analyze(bits)
            assert 0<=a<2**L
            for t in range(0,5):
                n=a+(1<<L)*t
                if n==0: continue
                vals=replay(n,bits)
                assert (1<<L)*vals[-1]==3**r*n+U
                survive=all(x>=n for x in vals)
                assert survive==(B is None or n<=B)
                assert Fraction((1<<L)*vals[-1],3**r*n)==1+Fraction(U,3**r*n)
                count+=1
    print('PASS: 8190 words,',count,'positive cylinder lifts, all exact checks')
    for bits in ([1,1,0,1,0],[1,1,1,0,1],[1,0,1,0,1]):
        print('word', ''.join(map(str,bits)), 'a,U,r,B',analyze(bits)[:4])
if __name__=='__main__':test()
