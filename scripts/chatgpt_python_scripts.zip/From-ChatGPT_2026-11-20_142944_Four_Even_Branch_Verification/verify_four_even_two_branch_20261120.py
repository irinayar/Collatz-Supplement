from functools import lru_cache
from collections import Counter

def v3(n):
    k=0
    while n%3==0:
        n//=3;k+=1
    return k
@lru_cache(None)
def L(e,x,r):
    if r<0:return None
    a=v3(x+1)
    if e==0:return 2**r*((x+1)//3**r)-1 if r<=a else None
    vals=[]
    for l in range(min(a,r)+1):
        y=2*(2**l*((x+1)//3**l)-1)
        v=L(e-1,y,r-l)
        if v is not None:vals.append(v)
    return min(vals,default=None)

N=6000
stats=Counter();bad=[];take=[]
for u in range(1,N+1):
    if u%3==0:continue
    A=6*u-2;B=4*u-2
    if u%3==2:
        assert L(3,B,0)==8*(4*u-2)
        assert L(3,B,1) is None
        assert L(3,A,1)==L(3,B,0)+4
        assert L(3,A,2)<L(3,B,0)
        stats['u2_proved_case_test']+=1
    for r in range(1,38):
        p=L(3,A,r);q=L(3,B,r-1)
        if p is not None and q is not None:
            stats['overlap']+=1
            stats[f'gap_{p-q}']+=1
            if p-q not in (1,4):bad.append(('gap',u,r,p,q))
        if r>=2 and p is not None and q is None:
            old=L(3,B,r-2)
            if old is not None:
                take.append((u,r,old,p,L(3,A,r-1)))
                if not p<old:bad.append(('takeover',u,r,old,p))
        if p is None and q is None:break
print('stats',dict(stats),'takeovers',len(take),'minimum takeover A-before',min((t[4] for t in take),default=None),'failures',bad[:5]);assert not bad
