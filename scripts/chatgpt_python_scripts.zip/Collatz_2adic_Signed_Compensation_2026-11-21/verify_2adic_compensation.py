from fractions import Fraction

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def profile(bits):
    a=0; u=0; r=0
    for j,b in enumerate(bits):
        z=(3**r*a+u)//(2**j)
        e=(b-z)%2
        a+=e*(2**j)
        if b:
            u=3*u+2**j; r+=1
    return a,u,r

def test(Lmax=12):
    tested=0; maxfirst=(Fraction(0),None)
    for L in range(1,Lmax+1):
        for q in range(1<<L):
            bits=[(q>>j)&1 for j in range(L)]
            a,u,r=profile(bits)
            n=a if a else 1<<L
            v=n
            for b in bits:
                assert v%2==b
                v=T(v)
            assert (3**r*n+u)==(1<<L)*v
            G=Fraction(3**r*n+u,3**r*n)
            assert G==1+Fraction(u,3**r*n)
            assert profile(bits)[0]==a
            # Exact cylinder monotonicity
            n2=n+(1<<L)
            assert 1+Fraction(u,3**r*n2)<=G
            tested+=1
            if G>maxfirst[0]:maxfirst=(G,(L,q,n,bits))
    return tested,maxfirst

if __name__=='__main__':
    n,m=test()
    print('verified finite words:',n)
    print('maximum unrestricted cylinder correction:',m)
    print('cycle 1 -> 2 -> 1, first 2k steps: G=(4/3)^k, for k=2:',Fraction(4,3)**2)
