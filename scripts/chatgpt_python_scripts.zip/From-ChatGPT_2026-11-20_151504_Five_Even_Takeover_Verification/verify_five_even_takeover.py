from itertools import combinations
from functools import lru_cache
INF=10**100
@lru_cache(None)
def H(x,k,r):
    if r<0:return INF
    a=0;t=x+1
    while t%3==0:t//=3;a+=1
    if k==0:return (2**r*(x+1)//3**r-1) if r<=a else INF
    return min(H(2*(2**l*(x+1)//3**l-1),k-1,r-l) for l in range(min(a,r)+1))
# Enumerate all 35 parity words of 7 steps with three odd steps.
compatible=[]
for positions in combinations(range(7),3):
    V=sum(2**p*3**(2-i) for i,p in enumerate(positions))
    if (128*(12*25-2)-V)%27==0:
        compatible.append((''.join('1' if p in positions else '0' for p in range(7)),V))
assert sorted(compatible)==[('0101010',74),('1100010',47)]
count=0
for q in range(25,27001,27):
    A=64*q-7
    m4=8*A//9-6
    s5=16*A//27-1
    assert H(12*q-2,4,3)==m4
    assert H(18*q-2,4,5)==s5
    assert H(8*q-2,4,2)==INF
    assert H(18*q-2,4,4)==m4+5
    assert m4>s5
    count+=1
print('compatible words',compatible,'q samples',count,'failures 0')
