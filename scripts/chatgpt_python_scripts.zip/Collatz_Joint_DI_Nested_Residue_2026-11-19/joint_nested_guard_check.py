from collections import Counter
import json

def T(x): return x//2 if x%2==0 else (3*x+1)//2

def word_preimages(y,depth):
    # Enumerate exact positive preimages with all lengths <= depth
    frontier={y}; out={y}
    for _ in range(depth):
        nxt=set()
        for x in frontier:
            nxt.add(2*x)
            if (2*x-1)%3==0:
                m=(2*x-1)//3
                if m>0 and m%2==1: nxt.add(m)
        out.update(nxt); frontier=nxt
    return out

def check(j,K=4096,d=5,ell=10,horizon=12):
    counts=Counter(); examples={}; nested=Counter(); checks=0
    for k in range(1,K+1):
        n=(1<<j)*k-1; y=pow(3,j)*k-1
        x=n
        for i in range(j):
            assert x%2==1
            x=T(x)
        assert x==y
        I0=(k%3==0 and n>2)
        Dblock=(pow(3,j)*k-1)%(1<<d)==0 and (pow(3,j)*k-1)//(1<<d)<n
        # Exact inverse search of endpoint, not the whole source prefix.
        Iendpoint=any(0<m<n for m in word_preimages(y,ell))
        x=y; Dlater=False
        for h in range(1,horizon+1):
            x=T(x)
            if x<n: Dlater=True; break
        resolved=I0 or Dblock or Iendpoint or Dlater
        for tag,ok in [('I0',I0),('Dblock',Dblock),('Iendpoint',Iendpoint),('Dlater',Dlater),('union',resolved)]:
            if ok:counts[tag]+=1
        if not resolved:
            key=(k%3,k%8)
            nested[str(key)]+=1
            examples.setdefault(str(key),k)
        checks+=1
    return {'j':j,'k_range':[1,K],'d':d,'endpoint_target_depth':ell,'postprefix_descent_horizon':horizon,'counts':dict(counts),'unresolved':K-counts['union'],'unresolved_by_k_mod3_mod8':dict(nested),'examples':examples,'checked':checks}

if __name__=='__main__':
    data=[check(j) for j in (3,4,5)]
    with open('/mnt/data/joint_nested_guard_results.json','w') as f:json.dump(data,f,indent=2)
    for x in data:print(x['j'],x['counts'],x['unresolved'],x['unresolved_by_k_mod3_mod8'])
