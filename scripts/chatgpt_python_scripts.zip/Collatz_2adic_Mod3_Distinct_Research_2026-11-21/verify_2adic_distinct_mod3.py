from fractions import Fraction

def word_data(n,L):
 x=n; bits=[]; U=0;r=0;states=[];prefix=[]
 for j in range(L):
  b=x&1;bits.append(b)
  if b: states.append(x)
  U=(3 if b else 1)*U+b*(1<<j);r+=b
  x=(3*x+1)//2 if b else x//2
  prefix.append(x)
 return bits,U,r,states,prefix

def residue(bits):
 a=0;U=0;r=0
 for j,b in enumerate(bits):
  x=(pow(3,r)*a+U)//(1<<j)
  a+=((b-x)&1)<<j
  U=(3 if b else 1)*U+b*(1<<j);r+=b
 return a

def eligible(n,k):
 out=[];v=n
 while len(out)<k:
  if v&1 and v%3 and v!=n:out.append(v)
  v+=1
 return out

checks=0; applicable=0;exceptional=0
for n in range(3,2000,2):
 bits,U,r,states,prefix=word_data(n,70)
 for L in range(1,71):
  bs=bits[:L];a=residue(bs);assert n%(1<<L)==a
  R=sum(bs); ul=0
  for j,b in enumerate(bs):ul=(3 if b else 1)*ul+b*(1<<j)
  assert ul== (1<<L)*prefix[L-1]-3**R*n
  checks+=1
  if min(prefix[:L])<n or len(set(states[:R]))!=R:continue
  applicable+=1
  vals=eligible(n,max(0,R-1))
  G=Fraction((1<<L)*prefix[L-1],3**R*n)
  bound=Fraction(3*n+1,3*n)
  for v in vals:bound*=Fraction(3*v+1,3*v)
  assert G<=bound,(n,L)
  if G>=Fraction(3,2):exceptional+=1
print('checked',checks,'eligible distinct survival prefixes',applicable,'exceptional',exceptional)
print('asymptotic coefficient',((1.5)**9-1)/3)
