from itertools import combinations
from fractions import Fraction
from datetime import datetime

def words(r,k):
    L=r+k
    for positions in combinations(range(L),r):
        V=sum((2**p)*3**(r-1-i) for i,p in enumerate(positions))
        yield V,''.join('1' if t in positions else '0' for t in range(L))

def min_origin(y,r,k):
    L=r+k
    candidates=[]
    for V,w in words(r,k):
        z=2**L*y-V
        if z>0 and z%3**r==0:
            m=z//3**r
            # replay parity word
            n=m
            for ch in w:
                assert n%2==int(ch)
                n=(3*n+1)//2 if n%2 else n//2
            assert n==y
            candidates.append((m,V,w))
    return min(candidates) if candidates else None

rows=[]
for u in range(1,28,3):
    p3=min_origin(6*u-2,3,5)
    q3=min_origin(4*u-2,2,5)
    p4=min_origin(6*u-2,4,5)
    q4=min_origin(4*u-2,3,5)
    assert p3 and q3 and q4
    rows.append((u,p3,q3,p4,q4))
    # entire residue class by affine shift
    for t in range(1,5):
        uu=u+27*t
        pp3=min_origin(6*uu-2,3,5)
        qq3=min_origin(4*uu-2,2,5)
        pp4=min_origin(6*uu-2,4,5)
        qq4=min_origin(4*uu-2,3,5)
        for base, new, r, mult in [(p3,pp3,3,6),(q3,qq3,2,4),(p4,pp4,4,6),(q4,qq4,3,4)]:
            assert (base is None)==(new is None)
            if base:
                assert new[1:]==base[1:]
                assert new[0]-base[0] == (2**(r+5)*mult*27*t)//3**r
                assert (2**(r+5)*mult*27*t)%3**r==0
    old=min(p3[0],q3[0]); new=min([z[0] for z in (p4,q4) if z])
    assert new<old
print('9 residue classes; 36 affine shift replays; 9 strict r3->r4 drops; all pass')
for u,p3,q3,p4,q4 in rows:
    print(u, p3[0],q3[0],p4[0] if p4 else None,q4[0], 'P4-Q4',p4[0]-q4[0] if p4 else None,'Q3-min4',q3[0]-min(z[0] for z in (p4,q4) if z))
