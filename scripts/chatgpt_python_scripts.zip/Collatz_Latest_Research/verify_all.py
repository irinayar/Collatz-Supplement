#!/usr/bin/env python3
"""Reproduce the aggregate-central research packet with exact arithmetic.

All six checks are local and standard-library-only. Their deterministic
certificates must reproduce byte for byte. Passing this program does not prove
the uniform signed-resource or central bound.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
CHECKS = [
    ("verify_actual_central_collisions.py", "actual_central_collisions_certificate.json"),
    ("verify_inverse_residue_phase_ranks.py", "inverse_residue_phase_rank_certificate.json"),
    ("verify_single_input_run_elimination.py", "single_input_run_elimination_certificate.json"),
    ("verify_collision_phase_audit.py", "collision_phase_audit_certificate.json"),
    ("verify_unfinished_excursion_flux.py", "unfinished_excursion_flux_certificate.json"),
    ("verify_positive_run_inverse_kernel.py", "positive_run_inverse_kernel_certificate.json"),
]


def decode(value: dict) -> F:
    if "exact" in value:
        return F(value["exact"])
    return F(int(value["numerator"]), int(value["denominator"]))


def reproduce(pair: tuple[str, str], temporary: Path) -> tuple[dict, dict]:
    script, certificate = pair
    output = temporary / certificate
    result = subprocess.run(
        [sys.executable, str(HERE / script), "--output", str(output)],
        cwd=HERE, capture_output=True, text=True, timeout=120,
    )
    if result.returncode:
        raise RuntimeError(f"{script} failed:\n{result.stdout}\n{result.stderr}")
    raw = output.read_bytes()
    if raw != (HERE / certificate).read_bytes():
        raise AssertionError(f"{script}: certificate is not byte-for-byte reproducible")
    data = json.loads(raw)
    assert data.get("status") == "PASS" or data.get("checks_passed") is True
    receipt = {
        "script": script, "script_sha256": sha256((HERE / script).read_bytes()).hexdigest(),
        "certificate": certificate, "certificate_sha256": sha256(raw).hexdigest(),
        "byte_for_byte_reproduction": True,
    }
    return receipt, data


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without -O or -OO: exact assertions are required.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=HERE / "master_verification_certificate.json")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="collatz_aggregate_check_") as name:
        temp = Path(name)
        with ThreadPoolExecutor(max_workers=4) as executor:
            checked = list(executor.map(lambda pair: reproduce(pair, temp), CHECKS))
    receipts, reports = zip(*checked)
    collisions, ranks, flux, audit, unfinished, kernel = reports

    assert ranks["rank_comparisons"] == 320
    assert audit["path_count"] == 31 and audit["budget_checks"] == 104
    assert flux["run_controls"]["exact_run_cylinders"] == 459
    constants = flux["constants"]
    target = F(constants["target"])
    coefficient = F(constants["positive_resource_coefficient"])
    remainder = F(constants["complementary_constant"])
    simple = F(constants["sufficient_positive_resource"])
    assert target == F(327, 3904)
    assert coefficient == F(3000, 2797)
    assert remainder == F(8850, 170617)
    assert simple == F(37, 1250)
    assert target - (coefficient*simple+remainder) == F(7719, 54597440)
    assert F(488,375)*target+F(59,1000) == F(21,125)

    rank_families = {row["family"]: row for row in ranks["families"]}
    flux_families = {row["family"]: row for row in flux["collision_controls"]["families"]}
    cross_checks = []
    for family in collisions["families"]:
        name = family["name"]
        ranked = rank_families[name]
        independent = audit["actual_core_collisions"][name]
        balanced = flux_families[name]
        assert family["n"] == ranked["n"] == independent["n"]
        pstar = family["source_count_definition"]["Pstar"]
        assert pstar == ranked["Pstar"] == independent["Pstar"] == balanced["imported_exact_Pstar"]
        pairs = [[row["depth_first"], row["depth_second"]] for row in family["common_core"]]
        assert pairs == independent["shared_actual_core_depth_pairs"]
        mass = decode(family["total_weighted_core_occurrences"])
        distinct = decode(family["unique_state_weighted_core"])
        assert mass > distinct
        assert F(balanced["occurrence_core_weight"]) == mass
        rows = [row for row in ranked["checks"]
                if row["prescribed_core_cutoff"] and row["k"] == 2
                and row["rank_retained_per_cell"] == 1]
        assert len(rows) == 1
        row = rows[0]
        assert decode(row["total"]) == mass
        signed_total = sum((F(p["positive_resource"]) for p in balanced["profiles"]), F(0))
        assert decode(row["signed_positive_resource"]) == signed_total
        assert decode(row["principal"])+decode(row["excess_rank_mass"]) == mass
        assert decode(row["resource_principal"])+decode(row["resource_excess_rank"]) == signed_total
        if name == "asynchronous":
            assert decode(family["synchronized_core_pair_energy"]) == 0
            assert decode(family["all_depth_core_pair_energy"]) > 0
            assert len(pairs) == 6 and decode(row["excess_rank_mass"]) == 0
        else:
            assert pairs == [[40,40]] and decode(row["excess_rank_mass"]) > 0
        cross_checks.append({
            "family": name, "n": family["n"], "Pstar": pstar,
            "shared_actual_core_depth_pairs": pairs,
            "all_occurrence_mass_agrees": True,
            "signed_positive_resource_agrees": True,
            "distinct_state_deduplication_would_lose_mass": True,
        })
    report = {
        "status": "PASS", "checks": list(receipts),
        "cross_checks": cross_checks,
        "numerical_reduction": {
            "signed_resource_coefficient": str(coefficient),
            "complementary_constant": str(remainder),
            "sufficient_signed_resource": str(simple),
            "sufficient_central_target": str(target),
            "strict_central_margin": "7719/54597440",
            "original_budget_if_target_proved": "21/125",
        },
        "scope": {
            "all_depth_inverse_residue_phase_bound_proved": True,
            "all_required_occurrences_retained": True,
            "single_input_flux_compensation_proved": True,
            "finite_unfinished_prefix_flux_proved": True,
            "uniform_signed_resource_bound_proved": False,
            "uniform_central_bound_proved": False,
            "arbitrary_full_trajectory_repetition_excluded": False,
            "arbitrary_unfinished_excursion_aggregate_bound_proved": False,
            "Collatz_conjecture_proved": False,
            "prior_large_canonical_computation_rerun": False,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print("PASS: all six certificates reproduced byte-for-byte.")
    print("PASS: independent collision, residue-rank, and signed-flux results agree.")
    print("PASS: every required occurrence remains in the principal-plus-rank partition.")
    print("OPEN: the uniform Y_+ <= 37/1250 target and the original central budget.")


if __name__ == "__main__":
    main()
