#!/usr/bin/env python3
"""Exact all-depth inverse-residue rank and phase-span controls.

The theorem retains every central occurrence. The principal mass remaining
after rank selection is not bounded by this certificate.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Exact assertions are required; do not use -O or -OO.")

HERE = Path(__file__).resolve().parent
A = F(47, 32)


def ceil(q: F) -> int:
    return -((-q.numerator) // q.denominator)


def floor(q: F) -> int:
    return q.numerator // q.denominator


def encode(q: F) -> dict:
    return {"exact": str(q), "display_only": float(q)}


def profile_count(n: int) -> int:
    """Independent integer implementation of the prescribed count upper bound."""
    H = (4*n-2)//3
    k = max(2, (H-n).bit_length())
    powers3 = [3**i for i in range(k+1)]
    powersn = [n**i for i in range(k+1)]
    perturbed = [(3*n+1)**i for i in range(k+1)]
    row, short = {2: 1}, 0
    for t in range(3, k+1):
        short += sum(count for g, count in row.items()
                     if (3*n-k)*(1 << t) < 3*H*powers3[g]
                     and n*powers3[g] < H*(1 << t))
        nxt = defaultdict(int)
        for g, count in row.items():
            for bit in (0, 1):
                gg = g+bit
                if (1 << t)*powersn[gg] < perturbed[gg]:
                    nxt[gg] += count
        row = dict(nxt)
    new = sum(row.values())+short
    row = {2: 1}
    for t in range(3, H.bit_length()+1):
        nxt = defaultdict(int)
        for g, count in row.items():
            for bit in (0, 1):
                gg = g+bit
                if 3**gg > 1 << (t-1):
                    nxt[gg] += count
        row = dict(nxt)
    return min(new, 2*sum(row.values()))


def replay(n: int, item: dict) -> dict:
    u, word = int(item["u"]), item["word"]
    H = (4*n-2)//3
    assert n >= 1 << 71 and n % 2 and u % 4 == 3
    odd, shortcut, times, phases = [u], [u], [0], [F(0)]
    affines = [(0, 0)]
    odd_affine, cumulative = 0, 0
    r, U = 0, 0
    for i, e in enumerate(word):
        z = 3*odd[-1]+1
        assert (z & -z).bit_length()-1 == e
        odd.append(z >> e)
        odd_affine = 3*odd_affine+(1 << cumulative)
        cumulative += e
        times.append(cumulative)
        phases.append(F(odd_affine, 3**(i+1)))
        for _ in range(e):
            x = shortcut[-1]
            j = len(shortcut)-1
            if x % 2:
                U = 3*U+(1 << j)
                r += 1
                y = (3*x+1)//2
            else:
                y = x//2
            shortcut.append(y)
            affines.append((r, U))
            assert (1 << (j+1))*y == 3**r*u+U
        assert shortcut[-1] == odd[-1]
    assert n <= u <= H and n <= odd[-1] <= H
    assert min(odd[1:-1]) > H
    assert len(set(shortcut[:-1])) == cumulative
    assert affines[-1] == (len(word), odd_affine)
    modulus = 1 << (cumulative+1)
    least = (((1 << cumulative)-odd_affine)*pow(3**len(word), -1, modulus)) % modulus
    assert least == u  # All supplied fixtures are globally least cylinder representatives.
    G = 1+phases[-1]/u
    assert G < A
    runs = []
    start = 0
    for end, e in enumerate(word, 1):
        if e >= 2:
            s, a = end-start, odd[start]
            beta = 1-F(2,3)**s
            delta = beta/a
            assert phases[end]-phases[start] == (u+phases[start])*delta
            kappa = 1-F(4,3*n+1)
            signed = kappa*delta+F(1,a)-F(1,odd[end])
            psi = max(F(0),signed)
            assert psi <= (kappa+1)*delta
            if s == 1:
                assert psi == 0
            runs.append({"i": start, "end": end, "s": s, "a": a, "b": odd[end],
                         "time": times[start], "E": times[start],
                         "q": phases[start], "qend": phases[end],
                         "c": phases[-1]-phases[start], "beta": beta, "delta": delta,
                         "signed": signed, "psi": psi})
            start = end
    assert start == len(word)
    return {"u": u, "word": word, "odd": odd, "shortcut": shortcut,
            "affines": affines, "runs": runs, "Q": phases[-1],
            "total_steps": cumulative, "expected_core": item["expected_core"]}


def select_core(n: int, P: int, profile: dict, B: F) -> list[dict]:
    H, L, m = (4*n-2)//3, n.bit_length()-1, n.bit_length()
    result = []
    for ordinal, run in enumerate(profile["runs"]):
        i, a, time = run["i"], run["a"], run["time"]
        if i == 0:
            continue
        ell = a.bit_length()-1
        t = ell-L
        J = (1 << ell)//(2000*P*(t+1)*(t+2))
        if not (H < a < 1 << (64*m)):
            continue
        endpoint_time = time+ell
        if endpoint_time >= profile["total_steps"]:
            continue
        if 64*profile["shortcut"][endpoint_time] <= a:
            continue
        if not (run["q"] > B and run["c"] > B):
            continue
        if not (ordinal > J and len(profile["runs"])-ordinal > J):
            continue
        # The whole-prefix inverse residue has already stabilized at the source.
        assert endpoint_time >= H.bit_length()
        r, U = profile["affines"][endpoint_time]
        residue = (-U*pow(3**r, -1, 1 << endpoint_time)) % (1 << endpoint_time)
        assert residue == profile["u"]
        result.append(run)
    return result


def rank_bound(n: int, profiles: list[dict], cores: list[list[dict]], B: F,
               k: int, rank: int) -> dict:
    H, M = (4*n-2)//3, 1 << k
    assert 2 <= k <= H.bit_length() and rank >= 0
    cells = defaultdict(list)
    for pid, (p, rows) in enumerate(zip(profiles, cores)):
        if not rows:
            continue
        assert p["total_steps"] > H.bit_length()
        r, U = p["affines"][k]
        residue = (-U*pow(3**r, -1, M)) % M
        assert residue == p["u"] % M
        for run in rows:
            cells[(run["i"], run["a"], residue)].append((pid, run))
    selected = defaultdict(list)
    principal = duplicate = F(0)
    psi_principal = psi_duplicate = F(0)
    nontrivial_cells = 0
    floor_cap_checks = 0
    for (g, y, residue), arrivals in cells.items():
        arrivals.sort(key=lambda pair: pair[1]["q"])
        exponent_set = {run["E"] for _, run in arrivals}
        assert len(exponent_set) == 1
        E = next(iter(exponent_set))
        lam = F(1 << E, 3**g)
        assert A*H/n < 2
        assert len({run["c"] for _, run in arrivals}) == 1
        assert len({run["delta"] for _, run in arrivals}) == 1
        assert len({run["psi"] for _, run in arrivals}) == 1
        assert len({run["qend"]-run["q"] for _, run in arrivals}) == 1
        lo = max(n, floor(lam*y/A)+1)
        hi = min(H, ceil(lam*y-B)-1)
        cap = max(0, (hi-residue)//M - (-((-(lo-residue))//M)) + 1)
        # Equivalent direct expression using the helper avoids any rounding ambiguity.
        cap2 = max(0, floor(F(hi-residue,M))-ceil(F(lo-residue,M))+1)
        assert cap == cap2 and len(arrivals) <= cap
        floor_cap_checks += 1
        if len(arrivals) > 1:
            nontrivial_cells += 1
        for j, (pid, run) in enumerate(arrivals):
            assert run["q"] == lam*y-profiles[pid]["u"]
            assert profiles[pid]["u"] % M == residue
            assert run["q"] > B+j*M
            if j:
                assert run["q"]-arrivals[j-1][1]["q"] >= M
                assert (run["q"]-arrivals[j-1][1]["q"]) % M == 0
            if j < rank:
                principal += run["delta"]
                psi_principal += run["psi"]
            else:
                duplicate += run["delta"]
                psi_duplicate += run["psi"]
                selected[pid].append(run)
    total = sum((run["delta"] for rows in cores for run in rows),F(0))
    assert principal+duplicate == total
    psi_total = sum((run["psi"] for rows in cores for run in rows),F(0))
    assert psi_principal+psi_duplicate == psi_total
    selected_span = F(0)
    for pid, rows in selected.items():
        rows.sort(key=lambda run: run["i"])
        p = profiles[pid]
        for x, y in zip(rows,rows[1:]):
            assert x["qend"] <= y["q"]
        assert rows[0]["q"] > B+rank*M
        assert rows[-1]["q"] < p["Q"]-B
        span = rows[-1]["q"]-rows[0]["q"]
        spent = sum((run["qend"]-run["q"] for run in rows[:-1]),F(0))
        assert spent <= span
        actual = sum((run["delta"] for run in rows),F(0))
        bound = span/(p["u"]+rows[0]["q"])+rows[-1]["delta"]
        assert actual <= bound
        assert rows[-1]["delta"] < F(1,H+1)
        selected_span += bound
    shifted = B+rank*M
    moments = [max(F(0),p["Q"]-B-shifted) for p in profiles]
    tail_bound = sum((z/(p["u"]+shifted) for z,p in zip(moments,profiles)),F(0))
    tail_bound += F(sum(z>0 for z in moments),H+1)
    assert duplicate <= selected_span <= tail_bound
    kappa = 1-F(4,3*n+1)
    assert psi_duplicate <= (kappa+1)*duplicate <= (kappa+1)*tail_bound
    combined_upper = psi_principal+(kappa+1)*tail_bound
    assert psi_total <= combined_upper
    if k == H.bit_length() and rank >= 1:
        assert duplicate == 0 and principal == total
    return {"k":k,"rank_retained_per_cell":rank,"cells":len(cells),
            "nontrivial_cells":nontrivial_cells,"lattice_cap_checks":floor_cap_checks,
            "principal":encode(principal),"excess_rank_mass":encode(duplicate),
            "selected_span_bound":encode(selected_span),"shifted_phase_bound":encode(tail_bound),
            "total":encode(total),"signed_positive_resource":encode(psi_total),
            "resource_principal":encode(psi_principal),"resource_excess_rank":encode(psi_duplicate),
            "combined_residue_phase_resource_bound":encode(combined_upper)}


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds",type=Path,default=HERE/"central_collision_seeds.json")
    parser.add_argument("--output",type=Path,default=HERE/"inverse_residue_phase_rank_certificate.json")
    args=parser.parse_args()
    raw=args.seeds.read_bytes()
    fixtures=json.loads(raw)["families"]
    records=[]
    for fixture in fixtures:
        n=int(fixture["n"]);H=(4*n-2)//3
        P=profile_count(n)
        B=F(5)+F(n,100000*P)
        profiles=[replay(n,item) for item in fixture["sources"]]
        true_core=[select_core(n,P,p,B) for p in profiles]
        for p,rows in zip(profiles,true_core):
            assert [x["i"] for x in rows] == p["expected_core"]
        ks=sorted(set([2,3,4,8,16,32,64,H.bit_length()]))
        assert max(ks)<=H.bit_length()
        checks=[]
        for cut in [F(0),F(1,2),F(1),F(5),B]:
            cores=[select_core(n,P,p,cut) for p in profiles]
            for k in ks:
                for rank in [0,1,2,3]:
                    row=rank_bound(n,profiles,cores,cut,k,rank)
                    row["phase_cut"]=str(cut)
                    row["prescribed_core_cutoff"]=(cut==B)
                    checks.append(row)
        prescribed=[x for x in checks if x["prescribed_core_cutoff"] and x["k"]==2 and x["rank_retained_per_cell"]==1][0]
        if fixture["name"]=="synchronized":
            assert F(prescribed["excess_rank_mass"]["exact"])>0
            assert prescribed["nontrivial_cells"]==1
            refined=[x for x in checks if x["prescribed_core_cutoff"] and x["k"]==3 and x["rank_retained_per_cell"]==1][0]
            assert F(refined["excess_rank_mass"]["exact"])==0
            assert F(refined["principal"]["exact"])==F(prescribed["total"]["exact"])
        else:
            assert F(prescribed["excess_rank_mass"]["exact"])==0
        records.append({"family":fixture["name"],"n":str(n),"Pstar":str(P),"Bstar":str(B),
                        "core_indices":[[x["i"] for x in rows] for rows in true_core],"checks":checks})
    report={"status":"PASS","seeds_sha256":sha256(raw).hexdigest(),
            "arithmetic":"integers and Fraction; decimals are display only",
            "families":records,"rank_comparisons":sum(len(x["checks"]) for x in records),
            "scope":["Every actual central occurrence is principal or excess-rank, exactly once.",
                     "The all-depth shifted phase bound spends each profile's intervals once.",
                     "Source residues are reconstructed by the inverse shortcut parity map.",
                     "Refining to unique source residues transfers all mass to principal cells.",
                     "No uniform bound on that principal mass or on the full central sum is proved."]}
    args.output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"status":"PASS","families":len(records),"rank_comparisons":report["rank_comparisons"],
                      "true_core_synchronized_collision_tested":True,"principal_mass_not_deleted":True}))


if __name__=="__main__":
    main()
