#!/usr/bin/env python3
"""Independent exact audit of compact paths and all-depth collision budgets.

Only the adjacent seed JSON is read. No producer verifier is imported, and no
source interval or trajectory census is searched. All inequalities use Fraction.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

sys.set_int_max_str_digits(0)


A = F(47, 32)


def ceil_div(a, b):
    return -(-a // b)


def v2(x):
    assert x
    return (abs(x) & -abs(x)).bit_length() - 1


def replay(n, item):
    u = int(item['u']); word = [int(e) for e in item['word']]
    H = (4*n-2)//3; odd = [u]; shortcut = [u]
    exp = [0]; numer = [0]; phase = [F(0)]
    B = E = 0
    for i, e in enumerate(word):
        x = odd[-1]; z = 3*x+1
        assert e >= 1 and v2(z) == e
        z //= 2; shortcut.append(z)
        for _ in range(e-1):
            assert z % 2 == 0
            z //= 2; shortcut.append(z)
        assert z & 1
        odd.append(z)
        B = 3*B+(1 << E); E += e
        exp.append(E); numer.append(B); phase.append(F(B, 3**(i+1)))
        assert (1 << E)*z == 3**(i+1)*u+B
        assert phase[-1]-phase[-2] == (u+phase[-2])/F(3*x)
    g = len(word); w = odd[-1]
    assert g and word[0] == 1 and u % 4 == 3 and word[-1] >= 2
    assert n <= u <= H and n <= w <= H
    assert all(x > H for x in odd[1:-1])
    assert len(set(odd[:-1])) == len(odd)-1
    assert len(shortcut) == E+1 and all(x >= n for x in shortcut[:-1])
    G = F(1)+phase[-1]/u
    product = F(1)
    for x in odd[:-1]:
        product *= 1+F(1, 3*x)
    assert G == product and G < A
    rho = G*(1+F(5,w))/(1+F(5,u))

    # Full odd-output cylinder plus exact first-return height interval.
    modulus = 1 << (E+1)
    residue = (((1 << E)-B)*pow(3**g, -1, modulus)) % modulus
    lo = max(n, ceil_div((1 << E)*n-B, 3**g))
    hi = min(H, ((1 << E)*H-B)//3**g)
    for i in range(1, g):
        lo = max(lo, ((1 << exp[i])*H-numer[i])//3**i+1)
    least = lo+(residue-lo) % modulus
    assert least == u <= hi
    assert u % modulus == residue

    starts = [0]+[i+1 for i,e in enumerate(word[:-1]) if e >= 2]
    runs = []
    W = F(0); W1 = F(0); WL = F(0); flux = F(0)
    kappa = 1-F(4,3*n+1)
    for ordinal, (i,j) in enumerate(zip(starts, starts[1:]+[g])):
        s = j-i; a = odd[i]; b = odd[j]
        assert all(e == 1 for e in word[i:j-1]) and word[j-1] >= 2
        beta = 1-F(2,3)**s; delta = beta/a
        d = phase[j]-phase[i]
        assert d == (u+phase[i])*delta
        assert b == F(3**s*(a+1)-2**s, 2**(s-1+word[j-1]))
        f = F(1,a)-F(1,b)
        if s == 1:
            assert f <= -kappa*delta
            W1 += delta
        else:
            assert f <= delta
            z=1-beta;power=1 << (word[j-1]-1)
            eta=(1-2*z)/beta+2*z/(n+beta)
            assert f/delta==(1-power*z)/beta+power*z/(a+beta)
            assert f/delta<=eta<1
            assert (kappa*delta+f>0)==(b>F(a)/(1+kappa*beta))
            WL += delta
        W += delta; flux += f
        runs.append({'i':i,'j':j,'s':s,'y':a,'beta':beta,'delta':delta,
                     'q':phase[i],'c':phase[-1]-phase[i],'d':d,
                     'E':exp[i],'ordinal':ordinal,'flux':f})
    assert flux == F(1,u)-F(1,w)
    assert kappa*W1 <= WL+F(1,w)-F(1,u)
    assert W <= G-1
    return {'n':n,'H':H,'u':u,'w':w,'word':word,'g':g,'E':E,
            'odd':odd,'shortcut':shortcut,'exp':exp,'numer':numer,
            'phase':phase,'Q':phase[-1],'G':G,'rho':rho,'runs':runs,
            'W':W,'W1':W1,'WL':WL,'label':item['label'],
            'least_interval':[lo,hi],'residue':residue,'modulus':modulus}


def profile_upper(n):
    """Exact two necessary-code recurrences; not a trajectory enumeration."""
    H = (4*n-2)//3; k = (H-n).bit_length()
    assert n >= 1 << 71 and 2 <= k <= 255
    row = {2:1}; short = 0
    for j in range(3,k+1):
        short += sum(c for r,c in row.items()
                     if (3*n-k)*(1 << j) < 3*H*3**r
                     and n*3**r < H*(1 << j))
        row = {r:row.get(r,0)+row.get(r-1,0)
               for r in range(1,j+1) if 3**r > (1 << j)}
    long = sum(row.values())
    old = {2:1}
    for j in range(3,H.bit_length()+1):
        old = {r:old.get(r,0)+old.get(r-1,0)
               for r in range(1,j+1) if 3**r > (1 << (j-1))}
    old_bound = 2*sum(old.values())
    return {'k':k,'long':long,'short':short,'old':old_bound,
            'Pstar':min(long+short,old_bound)}


def exact_core(p, Pstar):
    n=p['n'];H=p['H'];L=n.bit_length()-1;m=n.bit_length()
    Bstar=5+F(n,100000*Pstar);total=len(p['runs'])
    indices=[]; records=[]
    for a in p['runs']:
        i=a['i'];y=a['y'];ell=y.bit_length()-1;t=ell-L
        J=(1 << ell)//(2000*Pstar*(t+1)*(t+2))
        position=a['E']+ell
        interior=position<p['E']
        slow=interior and 64*p['shortcut'][position]>y
        before=a['ordinal'];remaining=total-before
        conditions=[i>0,H<y<(1 << (64*m)),interior,slow,
                    a['q']>Bstar,a['c']>Bstar,before>J,remaining>J]
        if all(conditions):
            indices.append(i)
            records.append({'i':i,'y':str(y),'s':a['s'],'E':a['E'],
                            'q':str(a['q']),'remaining_phase':str(a['c']),
                            'J':str(J),'before':before,'remaining':remaining,
                            'canonical_endpoint':str(p['shortcut'][position])})
    return {'Bstar':Bstar,'indices':indices,'records':records,
            'Wcore':sum((a['delta'] for a in p['runs'] if a['i'] in indices),F(0))}


def partition(p, kind):
    if kind == 'runs':
        return p['runs']
    assert kind == 'odd_steps'
    return [{'i':i,'j':i+1,'s':1,'y':x,'beta':F(1,3),'delta':F(1,3*x),
             'q':p['phase'][i],'c':p['Q']-p['phase'][i],
             'd':p['phase'][i+1]-p['phase'][i],'E':p['exp'][i]}
            for i,x in enumerate(p['odd'][:-1])]


def family_budget(paths, B, kind='runs', cores=None):
    n=paths[0]['n'];H=paths[0]['H'];cells=defaultdict(list)
    by_profile=defaultdict(list)
    for p_id,p in enumerate(paths):
        for a in partition(p,kind):
            if not (a['i']>0 and a['q']>B and a['c']>B):
                continue
            if cores is not None and a['i'] not in cores[p_id]['indices']:
                continue
            assert a['y']>H
            entry=dict(a,p=p_id)
            cells[(a['i'],a['y'])].append(entry)
    excess=[max(p['Q']-2*B,F(0)) for p in paths]
    E1=sum(excess,F(0));E2=sum((e*e for e in excess),F(0))
    weighted_pairs=F(0);trimmed_quadratic=F(0)
    duplicate_recip=F(0);duplicates=0;fixed=defaultdict(lambda:[0,F(0)])
    collisions=[]
    for key,entries in cells.items():
        entries.sort(key=lambda a:a['q']);base=entries[0];m=len(entries)
        assert len({a['p'] for a in entries})==m
        assert len({a['E'] for a in entries})==1
        assert len({a['c'] for a in entries})==1
        assert len({a['delta'] for a in entries})==1
        assert len({a['d'] for a in entries})==1
        lam=F(1 << base['E'],3**base['i'])
        assert base['d']==lam*base['beta']
        ell=min(base['d'],base['c']-B)
        assert ell>0
        for rank,a in enumerate(entries):
            assert a['q']>B+4*rank
            assert a['q']==lam*a['y']-paths[a['p']]['u']
            assert a['d']==(paths[a['p']]['u']+a['q'])*a['delta']
            if rank:
                gap=a['q']-entries[rank-1]['q']
                assert gap.denominator==1 and int(gap)%4==0 and gap>=4
            by_profile[a['p']].append(dict(a,rank=rank,ell=ell))
        local_excess=sum((paths[a['p']]['Q']-2*B for a in entries),F(0))
        assert local_excess>m*(base['c']-B)+2*m*(m-1)
        assert m-1<=local_excess/4
        duplicates+=m-1;duplicate_recip+=F(m-1,key[1])
        fixed[key[0]][0]+=m-1;fixed[key[0]][1]+=F(m-1,key[1])
        weighted_pairs+=F(m*(m-1),2)*base['delta']
        trimmed_quadratic+=m*(m-1)*ell
        if m>1:
            collisions.append({'incoming_depth':key[0],'anchor':str(key[1]),
                               'm':m,'E':base['E'],'remaining_phase':str(base['c'])})
    for count,weight in fixed.values():
        assert count<=E1/4 and weight<=E1/(4*(H+1))
    for p_id,entries in by_profile.items():
        entries.sort(key=lambda a:a['i'])
        last_end=B;overflows=0
        for a in entries:
            assert a['q']>=last_end
            assert B<a['q']<a['q']+a['ell']<=paths[p_id]['Q']-B
            last_end=a['q']+a['ell']
            if a['d']>a['ell']:
                overflows+=1
        assert overflows<=1
    assert trimmed_quadratic<=E2/4
    pair_bound=E2/(8*(n+B))+E1/(4*(H+1))
    assert weighted_pairs<=pair_bound
    tails=[]
    for rank_cut in range(4):
        actual=sum((max(len(es)-rank_cut,0)*es[0]['delta'] for es in cells.values()),F(0))
        upper=F(0);count=0
        for p in paths:
            excess_cut=max(p['Q']-2*B-4*rank_cut,F(0))
            upper+=excess_cut/(p['u']+B+4*rank_cut)
            if excess_cut:
                upper+=F(1,H+1);count+=1
        assert actual<=upper
        tails.append({'r':rank_cut,'weight':str(actual),'upper':str(upper),
                      'eligible_profiles':count})
    return {'B':str(B),'partition':kind,'actual_core_only':cores is not None,
            'cells':len(cells),'selected_occurrences':sum(map(len,cells.values())),
            'collisions':collisions,'rank_tails':tails,
            'trimmed_quadratic':str(trimmed_quadratic),'quadratic_budget':str(E2/4),
            'weighted_pairs':str(weighted_pairs),'pair_budget':str(pair_bound),
            'all_depth_duplicate_count':duplicates,'all_depth_duplicate_recip':str(duplicate_recip),
            'fixed_depth_count_budget':str(E1/4),
            'fixed_depth_recip_budget':str(E1/(4*(H+1)))}


def small_algebra_controls():
    # New flux reduction uses the already certified complement exactly once.
    c=F(488,375);ce=F(235,128);kappa=F(999,1000)
    assert F(15,4)-16*ce/c == -F(73485,3904)
    slope=15*(kappa+1)/(15*kappa-1)
    intercept=16/c*F(59,1000)/(15*kappa-1)
    assert slope==F(5997,2797) and intercept==F(8850,170617)
    slack=F(327,3904)-slope*F(37,2500)-intercept
    assert slack>0
    signed_slope=F(3000,2797)
    signed_threshold=(F(327,3904)-intercept)/signed_slope
    signed_slack=F(327,3904)-signed_slope*F(37,1250)-intercept
    assert signed_threshold==F(116073,3904000)
    assert signed_slack==F(7719,54597440)>0
    inverse_rows={}
    for b in [1,2,4,5,7,8]:
        value=sum((F(3,2**e) for e in range(2,8)
                   if (pow(2,e,9)*b)%9 in [4,7]),F(0))/(1-F(1,64))
        inverse_rows[str(b)]=str(value)
    assert list(inverse_rows.values())==['20/21','17/42','17/21','10/21','5/21','5/42']

    # Exact finite repetition control from the incoming note, not its 40k scan.
    word=[1,1,1,1,4];u=60511;B=E=0
    for e in word:
        B=3*B+(1 << E);E+=e
    D=1 << E;Aw=3**len(word);defect=(D-Aw)*u-B
    assert (Aw,D,B,defect,v2(defect))==(243,256,211,786432,18)
    assert (v2(defect)-1)//E==2
    x=u;copies=0
    while copies<3:
        ok=True
        for e in word:
            if v2(3*x+1)!=e:
                ok=False;break
            x=(3*x+1)//(1 << e)
        if not ok:break
        copies+=1
    assert copies==2

    # The fixed W=(1,1,3) all-source subfamily, only its explicit cylinder.
    # This validates the limiting calculation's exact arithmetic ingredients.
    ap=[]
    for n in [4095,65535,131071]:
        H=(4*n-2)//3;lo=ceil_div(32*n-19,27);first=lo+(55-lo)%64
        total=F(0);count=0
        for u in range(first,H+1,64):
            x1=(3*u+1)//2;x2=(3*x1+1)//2;w=(3*x2+1)//8
            assert v2(3*u+1)==1 and v2(3*x1+1)==1 and v2(3*x2+1)==3
            assert n<=u<=H and min(x1,x2)>H and n<=w<=H
            rho=F(32*(w+5),27*(u+5))
            assert rho-1==F(44,27*(u+5))
            total+=rho-1;count+=1
        assert count and total>F(1,400)
        ap.append({'n':n,'count':count,'charge_sum':str(total)})
    return {'flux_slope':str(slope),'flux_intercept':str(intercept),
            'sufficient_long_run_target_slack':str(slack),
            'signed_positive_resource_slope':str(signed_slope),
            'signed_positive_resource_exact_threshold':str(signed_threshold),
            'signed_positive_resource_simple_target_slack':str(signed_slack),
            'short_inverse_rows':inverse_rows,
            'repetition':{'word':word,'u':60511,'defect':defect,'copies':copies},
            'explicit_W113_AP_controls':ap,
            'W113_limit':'(11/432)*log(9/8); proved by the fixed AP reciprocal sum, not fitted'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seeds',type=Path,default=Path(__file__).with_name('audit_collision_seed_groups.json'))
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('collision_phase_audit_certificate.json'))
    args=parser.parse_args();data=json.loads(args.seeds.read_text())
    summaries=[];budgets=[];core_reports=[];naive=None;total=0;special={}
    for group in data['groups']:
        n=int(group['n']);paths=[replay(n,s) for s in group['sources']];total+=len(paths)
        assert len({p['u'] for p in paths})==len(paths)
        assert len({tuple(p['word']) for p in paths})==len(paths)
        H=(4*n-2)//3
        kappa=1-F(4,3*n+1)
        assert kappa*sum((p['W1'] for p in paths),F(0))<=sum((p['WL'] for p in paths),F(0))+len(paths)*(F(1,n)-F(1,H))
        for p in paths:
            summaries.append({'label':p['label'],'n':str(n),'u':str(p['u']),
                              'w':str(p['w']),'g':p['g'],'E':p['E'],
                              'Q':str(p['Q']),'rho_minus_one':str(p['rho']-1),
                              'least_source':str(p['u']),'full_modulus':str(p['modulus'])})
            if p['u']==63:
                assert (n,p['g'],p['E'],p['w'],p['modulus'])==(55,34,54,61,1 << 55)
        for kind in ['runs','odd_steps']:
            for B in [F(0),F(1,2),F(1),F(5)]:
                report=family_budget(paths,B,kind);report['n']=str(n);budgets.append(report)
                if paths[0]['label'].startswith('legacy_synchronized') and kind=='odd_steps' and B==0:
                    count=report['all_depth_duplicate_count']
                    mass=F(report['all_depth_duplicate_recip'])
                    old_bound=F(report['fixed_depth_recip_budget'])
                    assert count==32 and count>F(report['fixed_depth_count_budget'])
                    assert mass>old_bound
                    naive={'n':str(n),'shared_depths':[x['incoming_depth'] for x in report['collisions']],
                           'duplicates':count,'fixed_depth_count_budget':report['fixed_depth_count_budget'],
                           'all_depth_reciprocal_duplicate_mass':str(mass),
                           'invalid_reused_budget':str(old_bound),'violation_ratio':str(mass/old_bound),
                           'scope':'B=0, proper odd inputs; not the prescribed Bstar core or a reset-only counterexample'}
        if n>=1 << 71:
            counts=profile_upper(n);Pstar=counts['Pstar']
            cores=[exact_core(p,Pstar) for p in paths]
            Bstar=cores[0]['Bstar']
            core_weight=sum((c['Wcore'] for c in cores),F(0))
            off_weight=sum((p['W'] for p in paths),F(0))-core_weight
            actual_flux_resource=sum((kappa*a['delta']+a['flux']
                                      for p,c in zip(paths,cores) for a in p['runs']
                                      if a['s']>=2 and a['i'] in c['indices']),F(0))
            assert kappa*core_weight<=actual_flux_resource+off_weight+len(paths)*(F(1,n)-F(1,H))
            report=family_budget(paths,Bstar,'runs',cores);report['n']=str(n);budgets.append(report)
            core_reports.append({'n':str(n),'Pstar':str(Pstar),'Bstar':str(Bstar),
                                 'profiles':[{'u':str(p['u']),'label':p['label'],
                                              'indices':c['indices'],'Wcore':str(c['Wcore']),
                                              'core_records':c['records']}
                                             for p,c in zip(paths,cores)]})
            if paths[0]['label'].startswith('actual_core_'):
                for p in paths:
                    assert p['rho']>1 and p['modulus']>p['u']
                common=[]
                for i in cores[0]['indices']:
                    for j in cores[1]['indices']:
                        if paths[0]['odd'][i]==paths[1]['odd'][j]:
                            common.append([i,j])
                if paths[0]['label'].startswith('actual_core_synchronized'):
                    assert Pstar==1439135905268522777796261774512
                    assert [c['indices'] for c in cores]==[[23,24,26,28,30,31,33,35,36,38,40],[40]]
                    assert common==[[40,40]]
                    assert paths[1]['u']-paths[0]['u']==4
                    name='synchronized'
                else:
                    assert Pstar==295379016355744007183102
                    assert [c['indices'] for c in cores]==[[26,28,30,32,33,35],[23,24,26,28,30,31,33]]
                    assert common==[[26,24],[28,26],[30,28],[32,30],[33,31],[35,33]]
                    name='asynchronous'
                special[name]={'n':str(n),'Pstar':str(Pstar),'shared_actual_core_depth_pairs':common,
                               'whole_words':[{'g':p['g'],'E':p['E']} for p in paths],
                               'scope':'Actual prescribed central set, full least-source genuine returns; no relaxed phase cutoff'}
            if paths[0]['label']=='g46_terminal_phase_witness':
                assert paths[0]['Q']>2*Bstar and cores[0]['indices']==[]
    assert total==31 and naive and set(special)=={'synchronized','asynchronous'}
    result={'status':'PASS','arithmetic':'Exact integers and fractions; no producer imports',
            'scope':'31 fixed constructed/cached paths in 12 threshold groups, not an exhaustive census',
            'seed_sha256':hashlib.sha256(args.seeds.read_bytes()).hexdigest(),
            'path_count':total,'threshold_groups':len(data['groups']),
            'budget_checks':len(budgets),'paths':summaries,'core_controls':core_reports,
            'actual_core_collisions':special,'invalid_all_depth_reuse_control':naive,
            'small_algebra_controls':small_algebra_controls(),'budget_certificates':budgets}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','paths':total,'groups':len(data['groups']),
                      'budget_checks':len(budgets),'actual_core_collisions':special},indent=2))


if __name__=='__main__':
    main()
