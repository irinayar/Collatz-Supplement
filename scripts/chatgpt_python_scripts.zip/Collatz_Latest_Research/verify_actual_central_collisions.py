#!/usr/bin/env python3
"""Exact actual-core collisions with every source occurrence retained.

Replays four fixed profiles, reconstructs the previously specified exact
profile-count bound, and checks every current central predicate. No search,
trajectory census, floating-point proof, or convergence hypothesis is used.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: assertions are part of verification.")

HERE = Path(__file__).resolve().parent


def enc(value: F | int) -> dict:
    q = F(value)
    return {"numerator": str(q.numerator), "denominator": str(q.denominator),
            "display_only": float(q)}


def ceil_div(a: int, b: int) -> int:
    return -((-a)//b)


def T(x: int) -> int:
    return (3*x+1)//2 if x & 1 else x//2


def profile_upper(n: int) -> dict:
    """Independently evaluate the established n-dependent P_* definition."""
    H = (4*n-2)//3
    k = max(2, (H-n).bit_length())
    row = {2: 1}
    short = 0
    for j in range(3, k+1):
        short += sum(c for r, c in row.items()
                     if (3*n-k)*(1 << j) < 3*H*3**r
                     and n*3**r < H*(1 << j))
        nxt = defaultdict(int)
        for r, count in row.items():
            for odd in (0, 1):
                rr = r+odd
                if (1 << j)*n**rr < (3*n+1)**rr:
                    nxt[rr] += count
        row = dict(nxt)
    new = short+sum(row.values())
    old = {2: 1}
    for j in range(3, H.bit_length()+1):
        nxt = defaultdict(int)
        for r, count in old.items():
            for odd in (0, 1):
                rr = r+odd
                if 3**rr > 1 << (j-1):
                    nxt[rr] += count
        old = dict(nxt)
    old_bound = 2*sum(old.values())
    return {"width_exponent": k, "new_count": str(new),
            "old_count": str(old_bound), "Pstar": min(new, old_bound)}


def parity_residues(u: int, shortcut: list[int]) -> list[int]:
    """q_L has bit j equal to parity(T^j(u)), j=0,...,L-1.

    The affine numerator U_L gives a_L=-U_L/3^r mod 2^L.
    The last output's odd bit is also included, to check the full
    exact odd-arrival cylinder modulo 2^(E+1).
    """
    U, r, encoded_word = 0, 0, 0
    residues = [0]
    for j, x in enumerate(shortcut):
        bit = x & 1
        encoded_word += bit << j
        if bit:
            U = 3*U+(1 << j)
            r += 1
        modulus = 1 << (j+1)
        residue = (-U*pow(3**r, -1, modulus)) % modulus
        assert residue == u % modulus
        assert residue % (modulus//2) == residues[-1]
        assert ((3**r)*u+U)//modulus == T(x)
        residues.append(residue)
    assert residues[-1] == u
    assert all(a == u for a in residues[u.bit_length():])
    return residues


def replay(n: int, source: dict, Pstar: int) -> dict:
    u, word = int(source["u"]), source["word"]
    H = (4*n-2)//3
    L, m = n.bit_length()-1, (n-1).bit_length()
    phase_cut = F(5)+F(n, 100000*Pstar)
    xs, path, times, phases, affine = [u], [u], [0], [F(0)], [(0, 0)]
    E, B = 0, 0
    for i, exponent in enumerate(word):
        z = 3*xs[-1]+1
        assert (z & -z).bit_length()-1 == exponent
        xs.append(z >> exponent)
        for _ in range(exponent):
            path.append(T(path[-1]))
        assert path[-1] == xs[-1]
        B = 3*B+(1 << E)
        E += exponent
        times.append(E)
        phases.append(F(B, 3**(i+1)))
        affine.append((E, B))
    g, w = len(word), xs[-1]
    assert n >= (1 << 71) and n & 1
    assert n <= u <= H and n <= w <= H
    assert all(x > H for x in xs[1:-1])
    assert min(path[:-1]) >= n
    assert len(set(path[:-1])) == E
    assert word[0] == 1 and word[-1] >= 2
    residues = parity_residues(u, path)
    modulus = 1 << (E+1)
    residue = (((1 << E)-B)*pow(3**g, -1, modulus)) % modulus
    assert residue == residues[-1] == u < H+1 < modulus

    # Independently intersect the actual band/height constraints with the
    # exact complete cylinder; this checks least genuine source status.
    lo = max(n, ceil_div((1 << E)*n-B, 3**g))
    for i, (Ei, Bi) in enumerate(affine[1:-1], 1):
        lo = max(lo, ((1 << Ei)*H-Bi)//3**i+1)
    hi = min(H, ((1 << E)*H-B)//3**g)
    least = residue+ceil_div(lo-residue, modulus)*modulus
    assert lo <= least == u <= hi
    D = F(1 << E, 3**g)
    G = D*w/u
    assert G == 1+phases[-1]/u < F(47, 32)
    charge = (phases[-1]+5*(D-1))/(u+5)
    assert charge == G*F(w+5, w)*F(u, u+5)-1 > 0

    starts = [0]+[i+1 for i, e in enumerate(word[:-1]) if e >= 2]
    core, all_runs = [], []
    for r, (i, stop) in enumerate(zip(starts, starts[1:]+[g])):
        a, s = xs[i], stop-i
        assert all(e == 1 for e in word[i:stop-1]) and word[stop-1] >= 2
        beta = 1-F(2, 3)**s
        delta = beta/a
        assert phases[stop]-phases[i] == (u+phases[i])*delta
        assert F((1 << (times[stop]-times[i]))*xs[stop], 3**s*a) == 1+delta
        j = a.bit_length()-1
        t = j-L
        J = (1 << j)//(2000*Pstar*(t+1)*(t+2))
        end_time = times[i]+j
        interior = end_time < E
        endpoint = path[end_time] if interior else None
        is_core = (i > 0 and H < a < (1 << (64*m)) and interior
                   and 64*endpoint > a
                   and phases[i] > phase_cut and phases[-1]-phases[i] > phase_cut
                   and r > J and len(starts)-r > J)
        # A canonical endpoint of a proper high start already identifies the
        # source as the inverse parity cylinder's least positive residue.
        if i > 0 and interior:
            assert end_time >= u.bit_length()
            assert residues[end_time] == u
        item = {"i": i, "a": a, "s": s, "beta": beta, "delta": delta,
                "phase": phases[i], "remaining_phase": phases[-1]-phases[i],
                "shortcut_time": times[i], "canonical_length": j,
                "canonical_end_time": end_time, "endpoint": endpoint,
                "earlier_resets": r, "remaining_resets": len(starts)-r,
                "reset_cut": J, "in_core": is_core}
        all_runs.append(item)
        if is_core:
            core.append(item)
    assert [x["i"] for x in core] == source["expected_core"]
    assert core
    return {"u": u, "w": w, "g": g, "E": E, "Q": phases[-1],
            "G": G, "charge": charge, "xs": xs, "times": times,
            "phases": phases, "core": core, "runs": all_runs,
            "least_interval": [lo, hi], "full_modulus": modulus,
            "inverse_prefixes_checked": len(residues)-1,
            "word": word}


def json_record(record: dict) -> dict:
    rows = []
    for r in record["core"]:
        rows.append({k: enc(v) if isinstance(v, F) else str(v) if k in ("a", "endpoint") else v
                     for k, v in r.items()})
    return {"source": str(record["u"]), "arrival": str(record["w"]),
            "odd_transitions": record["g"], "shortcut_length": record["E"],
            "phase": enc(record["Q"]), "correction": enc(record["G"]),
            "positive_charge": enc(record["charge"]),
            "least_source_interval": [str(x) for x in record["least_interval"]],
            "full_cylinder_modulus": str(record["full_modulus"]),
            "full_cylinder_least_residue": str(record["u"]),
            "inverse_prefixes_checked": record["inverse_prefixes_checked"],
            "core": rows,
            "weighted_core": enc(sum((x["delta"] for x in record["core"]), F(0)))}


def verify_family(seed: dict) -> dict:
    n = int(seed["n"])
    H = (4*n-2)//3
    counts = profile_upper(n)
    Pstar = counts["Pstar"]
    p, q = [replay(n, item, Pstar) for item in seed["sources"]]
    # Reconstruct the compact constructors, not just their literal starts.
    start_depth = 4 if seed["name"] == "asynchronous" else 22
    stem = [(3**(i+1)).bit_length()-(3**i).bit_length()
            for i in range(start_depth, start_depth+46)]
    first_arm = 6 if seed["name"] == "asynchronous" else 22
    assert p["word"][first_arm:first_arm+46] == stem
    assert q["word"][start_depth:start_depth+46] == stem
    assert q["u"] % 8 == 7 and n == (3*q["u"]+7)//4 and H == q["u"]+1
    if seed["name"] == "asynchronous":
        Es, Bs = 0, 0
        for e in stem:
            Bs = 3*Bs+(1 << Es)
            Es += e
        M = 1 << (Es+1)
        stem_residue = (((1 << Es)-Bs)*pow(3**46, -1, M)) % M
        y0 = stem_residue+M*(((91-stem_residue)*pow(M, -1, 729)) % 729)
        y = y0+seed["constructor_lift"]*729*M
        assert y == p["xs"][6] == q["xs"][4]
        assert p["u"] == (512*y-665)//729 and q["u"] == (64*y-73)//81
    else:
        Ep, Bp = 0, 0
        for e in p["word"][:68]:
            Bp = 3*Bp+(1 << Ep)
            Ep += e
        M = 1 << (Ep+1)
        prefix_residue = (((1 << Ep)-Bp)*pow(3**68, -1, M)) % M
        assert p["u"] == prefix_residue+seed["constructor_lift"]*M
    first = {x: i for i, x in enumerate(p["xs"][:-1])}
    second = {x: i for i, x in enumerate(q["xs"][:-1])}
    common = sorted(set(first) & set(second), key=lambda x: first[x])
    core1 = {x["a"]: x for x in p["core"]}
    core2 = {x["a"]: x for x in q["core"]}
    common_core = sorted(core1.keys() & core2.keys(), key=lambda x: core1[x]["i"])
    assert [core1[x]["i"] for x in common_core] == seed["expected_common_core_indices_first"]
    assert common_core
    for x in common_core:
        assert core1[x]["beta"] == core2[x]["beta"]
        assert core1[x]["endpoint"] == core2[x]["endpoint"]
    pair_mass = sum((core1[x]["delta"] for x in common_core), F(0))
    synchronized_mass = sum((core1[x]["delta"] for x in common_core
                             if core1[x]["i"] == core2[x]["i"]), F(0))
    total = sum((r["delta"] for rec in (p, q) for r in rec["core"]), F(0))
    unique = sum((r["delta"] for r in {**core1, **core2}.values()), F(0))
    assert total == unique+pair_mass
    assert 0 < total < F(327, 3904)
    common_table = []
    for x in common_core:
        common_table.append({"state": str(x), "depth_first": core1[x]["i"],
                             "depth_second": core2[x]["i"],
                             "run_length": core1[x]["s"],
                             "run_charge": enc(core1[x]["delta"]),
                             "phase_first": enc(core1[x]["phase"]),
                             "phase_second": enc(core2[x]["phase"]),
                             "remaining_first": enc(core1[x]["remaining_phase"]),
                             "remaining_second": enc(core2[x]["remaining_phase"])})
    if seed["name"] == "asynchronous":
        assert p["word"][:6] == [1, 1, 1, 1, 1, 4]
        assert q["word"][:4] == [1, 1, 2, 2]
        assert p["word"][6:] == q["word"][4:]
        assert first[common[0]] == 6 and second[common[0]] == 4
        assert all(first[x]-second[x] == 2 for x in common)
        assert 9*p["u"] == 8*q["u"]-1
        for x in common:
            assert 9*p["phases"][first[x]] == 8*q["phases"][second[x]]+1
            assert 9*(p["Q"]-p["phases"][first[x]]) == 8*(q["Q"]-q["phases"][second[x]])
        assert synchronized_mass == 0 < pair_mass
        assert F(5) < F(5)+F(n, 100000*Pstar) < F(51, 10)
        for x in common_core:
            assert core1[x]["phase"] > F(51, 10)
            assert core1[x]["remaining_phase"] > F(13, 2)
            assert core1[x]["canonical_length"] == 90
            assert core1[x]["reset_cut"] == core2[x]["reset_cut"] == 0
    else:
        assert q["u"]-p["u"] == 4
        assert p["word"][22:] == q["word"][22:]
        assert first[common[0]] == second[common[0]] == 22
        assert all(first[x] == second[x] for x in common)
        for x in common:
            assert p["phases"][first[x]]-q["phases"][second[x]] == 4
            assert p["Q"]-p["phases"][first[x]] == q["Q"]-q["phases"][second[x]]
        assert pair_mass == synchronized_mass > 0
        assert F(518, 100) < F(5)+F(n, 100000*Pstar) < F(519, 100)
    return {"name": seed["name"], "n": str(n), "H": str(H),
            "source_count_definition": {**counts, "Pstar": str(Pstar)},
            "phase_cut": enc(F(5)+F(n, 100000*Pstar)),
            "profiles": [json_record(p), json_record(q)],
            "all_shared_odd_input_count": len(common),
            "common_core": common_table,
            "total_weighted_core_occurrences": enc(total),
            "unique_state_weighted_core": enc(unique),
            "all_depth_core_pair_energy": enc(pair_mass),
            "synchronized_core_pair_energy": enc(synchronized_mass),
            "constructor_prefix_lifts_inspected": seed["constructor_prefix_lifts_inspected"]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=Path, default=HERE/"central_collision_seeds.json")
    parser.add_argument("--output", type=Path, default=HERE/"actual_central_collisions_certificate.json")
    args = parser.parse_args()
    raw = args.seeds.read_bytes()
    data = json.loads(raw)
    families = [verify_family(seed) for seed in data["families"]]
    result = {"scope": "Actual unchanged-core synchronized and asynchronous collisions. No aggregate constant bound or arbitrary-multiplicity theorem is claimed.",
              "seed_sha256": hashlib.sha256(raw).hexdigest(),
              "checks_passed": True, "families": families}
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print("PASS: four positive least-source genuine returns; every exact parity-prefix residue and current core predicate checked.")
    print("PASS: six asynchronous actual-core collisions with zero synchronized pair energy, plus one synchronized actual-core collision.")


if __name__ == "__main__":
    main()
