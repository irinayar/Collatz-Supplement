#!/usr/bin/env python3
"""Exact controls for single-input central-run elimination.

All arithmetic is integer/Fraction. The adjacent fixed collision seeds are
replayed without repeating their search. The previously proved uniform
complementary certificate is imported mathematically, not rerun here.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json


C = Q(488, 375)
CE = Q(235, 128)
NEGATIVE_ENDPOINT = Q(73485, 3904)


def odd_step(x):
    z = 3*x+1
    e = (z & -z).bit_length()-1
    return z >> e, e


def shortcut(x):
    return (3*x+1)//2 if x % 2 else x//2


def follow_word(source, word):
    states = [source]
    for e in word:
        y, actual = odd_step(states[-1])
        assert actual == e
        states.append(y)
    return states


def run_cylinder_controls():
    controls = 0
    equal_short = 0
    for s in range(1, 18):
        for e in range(2, 11):
            word = (1,)*(s-1)+(e,)
            a_coeff = 3**s
            d = 1 << (s-1+e)
            b_coeff = 3**s-2**s
            residue = ((d-b_coeff)*pow(a_coeff, -1, 2*d)) % (2*d)
            assert residue % 2
            for lift in (0, 1, 7):
                a = residue+2*d*lift
                path = follow_word(a, word)
                b = path[-1]
                assert d*b == a_coeff*a+b_coeff
                beta = 1-Q(2, 3)**s
                delta = beta/a
                correction = Q(1)
                for x in path[:-1]:
                    correction *= 1+Q(1, 3*x)
                assert correction == 1+delta
                flux = Q(1, a)-Q(1, b)
                z = Q(2, 3)**s
                q = (1 << (e-1))*z
                signed_coefficient = (1-q)/beta+q/(a+beta)
                assert flux == signed_coefficient*delta
                upper_coefficient = (1-2*z)/beta+2*z/(a+beta)
                assert signed_coefficient <= upper_coefficient
                if e == 2:
                    assert signed_coefficient == upper_coefficient
                assert flux <= delta
                assert b <= Q(a+beta, 2*Q(2, 3)**s)
                assert b <= Q(a, Q(2, 3)**s)
                if s == 1:
                    kappa = 1-Q(4, 3*a+1)
                    assert flux <= -kappa*delta
                    if e == 2:
                        assert flux == -kappa*delta
                        equal_short += 1
                controls += 1
    return dict(exact_run_cylinders=controls, short_reset_equalities=equal_short)


def first_return(n, source):
    h = (4*n-2)//3
    assert n % 2 and source % 2 and n <= source <= h
    states, word = [source], []
    for _ in range(1000):
        arrival, e = odd_step(states[-1])
        states.append(arrival)
        word.append(e)
        if arrival <= h:
            assert arrival >= n
            break
    else:
        raise AssertionError('Specified control did not complete.')
    assert all(x > h for x in states[1:-1])
    assert len(set(states[:-1])) == len(states)-1
    offsets = [0]
    phases = [Q(0)]
    numerator = 0
    for i, e in enumerate(word):
        numerator = 3*numerator+(1 << offsets[-1])
        offsets.append(offsets[-1]+e)
        phases.append(Q(numerator, 3**(i+1)))
    runs = []
    start = 0
    resets_before = 0
    while start < len(word):
        end = start
        while word[end] == 1:
            end += 1
            assert end < len(word), 'Completed first return must end with a reset.'
        end += 1
        s = end-start
        a, b = states[start], states[end]
        delta = (1-Q(2, 3)**s)/a
        runs.append(dict(i=start, end=end, s=s, a=a, b=b, delta=delta,
                         q=phases[start], qend=phases[end],
                         offset=offsets[start], resets_before=resets_before))
        resets_before += 1
        start = end
    return states, word, offsets, phases, runs


def actual_core(n, source, data, pstar):
    states, word, offsets, phases, runs = data
    h = (4*n-2)//3
    lower_log = n.bit_length()-1
    ceil_log = (n-1).bit_length()
    bstar = 5+Q(n, 100000*pstar)
    path = [source]
    for _ in range(offsets[-1]):
        path.append(shortcut(path[-1]))
    assert path[-1] == states[-1]
    selected = set()
    for index, run in enumerate(runs):
        a = run['a']
        if run['i'] == 0 or not h < a < 1 << (64*ceil_log):
            continue
        j = a.bit_length()-1
        endpoint_time = run['offset']+j
        if endpoint_time >= offsets[-1] or 64*path[endpoint_time] <= a:
            continue
        if not run['q'] > bstar or not phases[-1]-run['q'] > bstar:
            continue
        shell = j-lower_log
        reset_window = (1 << j)//(2000*pstar*(shell+1)*(shell+2))
        if not run['resets_before'] > reset_window:
            continue
        if not len(runs)-run['resets_before'] > reset_window:
            continue
        selected.add(index)
    return selected


def selected_inequalities(n, runs, selected, profile_count=1):
    h = (4*n-2)//3
    kappa = 1-Q(4, 3*n+1)
    endpoint_gap = Q(1, n)-Q(1, h)
    total = sum((r['delta'] for r in runs), Q(0))
    core = sum((r['delta'] for i, r in enumerate(runs) if i in selected), Q(0))
    long_core = sum((r['delta'] for i, r in enumerate(runs)
                     if i in selected and r['s'] >= 2), Q(0))
    short_core = core-long_core
    off = total-core
    assert kappa*short_core <= long_core+off+profile_count*endpoint_gap
    # This is the least actual F making the off-core inequality true for this
    # control selection. It is not substituted for the universal theorem's F.
    actual_f = max(Q(0), off-total/16)
    assert off <= total/16+actual_f
    assert off <= core/15+16*actual_f/15
    assert (15*kappa-1)*core <= 15*(kappa+1)*long_core+16*actual_f+15*profile_count*endpoint_gap
    actual_e = C*actual_f+CE*profile_count/n
    strong_rhs = 15*(kappa+1)*long_core+Q(750, 61)*actual_e-NEGATIVE_ENDPOINT*profile_count/n
    assert (15*kappa-1)*core <= strong_rhs
    signed_long = sum((kappa*r['delta']+Q(1, r['a'])-Q(1, r['b'])
                       for i, r in enumerate(runs)
                       if i in selected and r['s'] >= 2), Q(0))
    length_long = Q(0)
    for i, r in enumerate(runs):
        if i in selected and r['s'] >= 2:
            z = Q(2, 3)**r['s']
            beta = 1-z
            eta_at_n = (1-2*z)/beta+2*z/(n+beta)
            assert 0 < eta_at_n < 1
            length_long += (kappa+eta_at_n)*r['delta']
    assert signed_long <= length_long <= (kappa+1)*long_core
    signed_rhs = 15*signed_long+Q(750, 61)*actual_e-NEGATIVE_ENDPOINT*profile_count/n
    assert (15*kappa-1)*core <= signed_rhs
    return core, long_core


def profile_controls():
    t = 1 << 80
    high_n = 54523+118098*t
    core_source = 1194734292994222926486523
    n0 = 896050719745667194864893
    n1 = 906694364710971881029631
    fixtures = [(11, 11), (33, 43), (55, 63), (119, 123), (119, 139),
                (10697, 13503), (54523, 60511), (54523, 57439),
                (high_n, 60511+131072*t), (high_n, 57439+124416*t),
                (n0, core_source), (n1, core_source)]
    total_runs = selected_checks = 0
    core_controls = []
    groups = {}
    for n, source in fixtures:
        data = first_return(n, source)
        states, word, offsets, phases, runs = data
        total_runs += len(runs)
        w1 = sum((r['delta'] for r in runs if r['s'] == 1), Q(0))
        wl = sum((r['delta'] for r in runs if r['s'] >= 2), Q(0))
        flux = sum((Q(1, r['a'])-Q(1, r['b']) for r in runs), Q(0))
        assert flux == Q(1, source)-Q(1, states[-1])
        kappa = 1-Q(4, 3*n+1)
        assert kappa*w1 <= wl+Q(1, states[-1])-Q(1, source)
        groups.setdefault(n, []).append((w1, wl, source, states[-1]))
        for modulus in (1, 2, 3, 5):
            for residue in range(modulus):
                selected = {i for i in range(len(runs)) if i % modulus == residue}
                selected_inequalities(n, runs, selected)
                selected_checks += 1
        for short in (True, False):
            selected = {i for i, r in enumerate(runs) if (r['s'] == 1) == short}
            selected_inequalities(n, runs, selected)
            selected_checks += 1

        if source == core_source:
            pstar = 243760439224954652518
            selected = actual_core(n, source, data, pstar)
            assert [r['i'] for i, r in enumerate(runs) if i in selected] == [21, 23, 24, 26, 28, 30, 31, 33, 35]
            wc, x = selected_inequalities(n, runs, selected)
            assert wc < Q(5997, 2797)*x+Q(8850, 170617)
            assert x < Q(37, 2500) and wc < Q(327, 3904)
            core_controls.append(dict(threshold=str(n), source=str(source),
                                      selected_runs=len(selected),
                                      short_selected_runs=sum(r['s'] == 1 for i, r in enumerate(runs) if i in selected),
                                      core_weight=str(wc), long_core_weight=str(x),
                                      source_count_plateau_imported=True))
    for n, group in groups.items():
        p = len(group)
        kappa = 1-Q(4, 3*n+1)
        assert kappa*sum(x[0] for x in group) <= sum(x[1] for x in group)+p*(Q(1, n)-Q(1, (4*n-2)//3))
    return dict(actual_return_controls=len(fixtures), complete_runs=total_runs,
                selected_subset_checks=selected_checks, aggregate_flux_groups=len(groups),
                nonempty_true_core_controls=core_controls,
                scope='Flux allows all source occurrences; uniform numerical complement remains least-source only.')


def constants():
    k0 = Q(999, 1000)
    assert 1-Q(4, 3*1333+1) == k0
    assert Q(15, 4)-16*CE/C == -NEGATIVE_ENDPOINT
    a = 15*(k0+1)/(15*k0-1)
    b = Q(750, 61)/(15*k0-1)
    constant = b*Q(59, 1000)
    assert a == Q(5997, 2797)
    assert constant == Q(8850, 170617)
    margin = Q(327, 3904)-a*Q(37, 2500)-constant
    assert margin > 0
    assert constant < Q(327, 3904)
    positive_coefficient = 15/(15*k0-1)
    assert positive_coefficient == Q(3000, 2797)
    exact_positive_threshold = (Q(327, 3904)-constant)/positive_coefficient
    assert exact_positive_threshold == Q(116073, 3904000)
    positive_margin = Q(327, 3904)-positive_coefficient*Q(37, 1250)-constant
    assert positive_margin == Q(7719, 54597440) > 0
    assert [(1-2*Q(2, 3)**s)/(1-Q(2, 3)**s) for s in (2, 3, 4)] == [Q(1, 5), Q(11, 19), Q(49, 65)]
    # Both coefficient derivatives have negative numerator for kappa>1/15.
    assert 15*(-1-15) == -240
    return dict(kappa_lower=str(k0), long_core_coefficient=str(a),
                complementary_constant=str(constant), sufficient_long_core=str(Q(37, 2500)),
                target=str(Q(327, 3904)), sufficient_target_margin=str(margin),
                retained_negative_endpoint_coefficient=str(-NEGATIVE_ENDPOINT),
                longer_run_flux_coefficients=['1/5', '11/19', '49/65'],
                positive_resource_coefficient=str(positive_coefficient),
                exact_positive_resource_threshold=str(exact_positive_threshold),
                sufficient_positive_resource=str(Q(37, 1250)),
                positive_resource_margin=str(positive_margin))


def collision_profile_controls(seed_path):
    raw = seed_path.read_bytes()
    seeds = json.loads(raw)
    imported_counts = {
        'asynchronous': 295379016355744007183102,
        'synchronized': 1439135905268522777796261774512,
    }
    controls = []
    selections = 0
    profile_count = 0
    for family in seeds['families']:
        n = int(family['n'])
        pstar = imported_counts[family['name']]
        combined, combined_selected, row_controls = [], set(), []
        for seed in family['sources']:
            u = int(seed['u'])
            data = first_return(n, u)
            states, word, offsets, phases, runs = data
            assert word == seed['word']
            E, g = offsets[-1], len(word)
            numerator = phases[-1]*3**g
            assert numerator.denominator == 1
            modulus = 1 << (E+1)
            least = (((1 << E)-numerator.numerator)*pow(3**g, -1, modulus)) % modulus
            assert least == u
            selected = actual_core(n, u, data, pstar)
            assert [r['i'] for i, r in enumerate(runs) if i in selected] == seed['expected_core']
            core, long_core = selected_inequalities(n, runs, selected)
            kappa = 1-Q(4, 3*n+1)
            positive_resource = sum((max(Q(0), kappa*r['delta']+Q(1, r['a'])-Q(1, r['b']))
                                     for i, r in enumerate(runs)
                                     if i in selected and r['s'] >= 2), Q(0))
            assert positive_resource < Q(37, 1250)
            assert core < Q(3000, 2797)*positive_resource+Q(8850, 170617)
            for i in selected:
                combined_selected.add(len(combined)+i)
            combined.extend(runs)
            row_controls.append(dict(source=str(u), selected_runs=len(selected),
                                     core_weight=str(core), long_core_weight=str(long_core),
                                     positive_resource=str(positive_resource), least_residue_checked=True))
            selections += 1
            profile_count += 1
        core, long_core = selected_inequalities(n, combined, combined_selected,
                                                profile_count=len(family['sources']))
        unique = {r['a']: r['delta'] for i, r in enumerate(combined) if i in combined_selected}
        assert core > sum(unique.values(), Q(0))
        selections += 1
        controls.append(dict(family=family['name'], profiles=row_controls,
                             core_occurrences=len(combined_selected), unique_core_states=len(unique),
                             occurrence_core_weight=str(core), imported_exact_Pstar=str(pstar)))
    assert profile_count == 4
    return dict(seed_sha256=hashlib.sha256(raw).hexdigest(), actual_profiles=profile_count,
                selected_set_checks=selections, families=controls,
                source_count_values_imported=True, seed_search_repeated=False)


def inverse_short_rows():
    expected = {1: Q(20, 21), 2: Q(17, 42), 4: Q(17, 21),
                5: Q(10, 21), 7: Q(5, 21), 8: Q(5, 42)}
    computed = {}
    for residue, target in expected.items():
        row = sum((Q(3, 1 << e) for e in range(2, 8)
                   if pow(2, e, 9)*residue % 9 in (4, 7)), Q(0))/(1-Q(1, 64))
        assert row == target
        computed[residue] = str(row)
    lam = max(expected.values())
    assert lam == Q(20, 21) and lam/(1-lam) == 20
    edges = 0
    for b in (5, 7, 11, 13, 17, 19, 37, 101, (1 << 80)+1):
        assert b > 1 and b % 2 and b % 3
        for e in range(2, 50):
            if pow(2, e, 9)*(b % 9) % 9 not in (4, 7):
                continue
            a = ((1 << e)*b-1)//3
            assert a > b and a % 2 and a % 3
            assert odd_step(a) == (b, e)
            assert Q(1, a-1) <= Q(3, (1 << e)*(b-1))
            edges += 1
    depth_controls = 0
    for b in (19, 37):
        current = {b}
        seen = {b}
        for depth in range(1, 5):
            nxt = set()
            for y in current:
                for e in range(2, 9):
                    if pow(2, e, 9)*(y % 9) % 9 in (4, 7):
                        a = ((1 << e)*y-1)//3
                        assert a not in seen and a not in nxt
                        nxt.add(a)
            assert sum((Q(1, a-1) for a in nxt), Q(0)) <= lam**depth/(b-1)
            seen.update(nxt)
            current = nxt
            depth_controls += 1
    return dict(exact_infinite_geometric_rows=computed, contraction=str(lam),
                actual_inverse_edge_controls=edges, finite_tree_depth_controls=depth_controls,
                profile_multiplicity_removed=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('single_input_run_elimination_certificate.json'))
    parser.add_argument('--seeds', type=Path,
                        default=Path(__file__).with_name('central_collision_seeds.json'))
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Do not run this verifier with -O or -OO.')
    result = dict(status='PASS', arithmetic='integer and Fraction only',
                  run_controls=run_cylinder_controls(), profile_controls=profile_controls(),
                  constants=constants(), inverse_short_rows=inverse_short_rows(),
                  collision_controls=collision_profile_controls(args.seeds),
                  uniform_complement_recomputed=False,
                  unrestricted_long_core_bound_proved=False)
    result['verifier_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status='PASS', run_controls=result['run_controls'],
                         actual_returns=result['profile_controls']['actual_return_controls']+result['collision_controls']['actual_profiles'],
                         selected_subset_checks=result['profile_controls']['selected_subset_checks']+result['collision_controls']['selected_set_checks'],
                         constants=result['constants'],
                         inverse_row_contraction=result['inverse_short_rows']['contraction'],
                         certificate=str(args.output)), indent=2))


if __name__ == '__main__':
    main()
