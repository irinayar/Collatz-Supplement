#!/usr/bin/env python3
"""Exact finite-prefix signed flux, with one actual terminal partial run.

No producer imports, trajectory search, distinctness assumption, or completed
profile-count bound. Only cached complete words supply the finite prefix seeds.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json


def v2(x):
    return (x & -x).bit_length()-1


def control_prefix(n, u, word, odd, m):
    H=(4*n-2)//3;kappa=1-F(4,3*n+1)
    assert n>=3 and n<=u<=H and kappa>0
    assert all(x>H for x in odd[1:m+1])
    completed=[];start=0
    for i,e in enumerate(word[:m]):
        if e>=2:
            a=odd[start];b=odd[i+1];s=i+1-start
            beta=1-F(2,3)**s;delta=beta/a;flux=F(1,a)-F(1,b)
            assert all(t==1 for t in word[start:i])
            if s==1:
                assert flux<=-kappa*delta
            else:
                assert flux<=delta
            completed.append((s,a,b,delta,flux));start=i+1
    s=m-start;a=odd[start];v=odd[m]
    assert all(e==1 for e in word[start:m])
    z=F(2,3)**s;beta=1-z;partial=beta/a
    reserve=F(1,a)-F(1,v)
    assert v==(a+beta)/z
    assert reserve==partial*F(a+1)/(a+beta)
    assert 0<=partial<=reserve<F(1,a)<=F(1,n)
    assert v2(a+1)>=s+1
    direct_partial=F(1)
    for x in odd[start:m]:
        direct_partial*=1+F(1,3*x)
    assert direct_partial==1+partial
    W1=sum((d for t,aa,b,d,f in completed if t==1),F(0))
    WL=sum((d for t,aa,b,d,f in completed if t>=2),F(0))
    flux=sum((f for t,aa,b,d,f in completed),F(0))
    assert flux==F(1,u)-F(1,a)
    endpoint=F(1,v)-F(1,u)
    assert reserve+endpoint==F(1,a)-F(1,u)
    assert kappa*W1<=WL+reserve+endpoint
    if completed:
        assert a>H>=u and kappa*W1<WL
        assert partial<F(1,H+1)
    else:
        assert a==u and W1==WL==0
    Y=sum((max(kappa*d+f,F(0))
           for t,aa,b,d,f in completed if t>=2),F(0))
    Wcomplete=W1+WL;Wprefix=Wcomplete+partial
    assert kappa*Wcomplete<=Y-(F(1,u)-F(1,a))
    sharp=Y/kappa-(F(1,u)-F(1,a))/kappa+partial
    assert Wprefix<=sharp<=Y/kappa+partial<Y/kappa+F(1,n)
    assert Wprefix<=(1+1/kappa)*WL+partial
    product=F(1)
    for x in odd[:m]:product*=1+F(1,3*x)
    run_product=1+partial
    for t,aa,b,d,f in completed:run_product*=1+d
    assert product==run_product and Wprefix<=product-1
    return {'n':str(n),'u':str(u),'odd_prefix_length':m,
            'endpoint':str(v),'completed_runs':len(completed),
            'partial_length':s,'partial_start':str(a),
            'partial_weight':str(partial),'partial_flux_reserve':str(reserve),
            'combined_reserve_and_endpoint':str(reserve+endpoint),
            'W_completed':str(Wcomplete),'W_prefix':str(Wprefix),
            'Y_completed':str(Y),'sharp_signed_upper':str(sharp)}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seeds',type=Path,default=Path(__file__).with_name('audit_collision_seed_groups.json'))
    ap.add_argument('--output',type=Path,default=Path(__file__).with_name('unfinished_excursion_flux_certificate.json'))
    args=ap.parse_args();data=json.loads(args.seeds.read_text())
    paths=prefixes=zero_partial=no_completed=long_partial=0
    max_s=0;examples={}
    for group in data['groups']:
        n=int(group['n']);H=(4*n-2)//3
        for source in group['sources']:
            u=int(source['u']);word=source['word'];odd=[u]
            for e in word:
                z=3*odd[-1]+1
                assert v2(z)==e
                odd.append(z//(1<<e))
            assert n<=odd[-1]<=H and all(x>H for x in odd[1:-1])
            paths+=1
            # The final band arrival is omitted: these are unfinished cuts.
            for m in range(len(word)):
                r=control_prefix(n,u,word,odd,m);prefixes+=1
                s=r['partial_length'];c=r['completed_runs']
                if s==0:
                    zero_partial+=1
                    if c:examples.setdefault('completed_reset_with_zero_partial_length',r)
                if c==0:
                    no_completed+=1
                    if s>=3:examples.setdefault('no_completed_reset_with_at_least_three_ones',r)
                if s>=3:
                    long_partial+=1
                    if c:examples.setdefault('completed_runs_then_at_least_three_ones',r)
                if s>max_s:
                    max_s=s;examples['longest_observed_partial']=r
    assert paths==31 and zero_partial and no_completed and long_partial
    assert len(examples)==4
    result={'status':'PASS','scope':'Finite exact signed algebra on cached unfinished odd prefixes; no census or aggregate profile bound.',
            'seed_sha256':hashlib.sha256(args.seeds.read_bytes()).hexdigest(),
            'paths':paths,'unfinished_prefix_checks':prefixes,
            'zero_partial_length_checks':zero_partial,
            'no_completed_reset_checks':no_completed,
            'at_least_three_terminal_one_steps_checks':long_partial,
            'max_observed_partial_length':max_s,'examples':examples,
            'counts_are_controls_not_an_exhaustive_population':True}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='examples'},indent=2))


if __name__=='__main__':main()
