#!/usr/bin/env python3
"""Exact prescribed controls for the positive-run inverse-kernel obstruction.

This verifies local complete runs and least run-cylinder residues, not genuine
full first returns or retained-core membership. No search or external files.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json


def valuation_two(x):
    assert x > 0
    return (x & -x).bit_length()-1


def verify_length(n, s):
    assert n > 1 and n % 2 and s >= 3 and s % 2
    h = (4*n-2)//3
    a = (1 << s)-1
    b = (3**s-1)//2
    assert a > h >= n and b > a
    states = [a]
    for i in range(s):
        x = states[-1]
        assert x == 3**i*(1 << (s-i))-1
        assert x % 2 and x % 3 and x > h
        exponent = valuation_two(3*x+1)
        assert exponent == (1 if i < s-1 else 2)
        states.append((3*x+1) >> exponent)
    assert states[-1] == b and b % 2 and b % 3 == 1
    assert a % 3 == 1 and all(x % 3 == 2 for x in states[1:-1])
    assert all(states[i+1] > states[i] for i in range(s-1))
    A, D, B = 3**s, 1 << (s+1), 3**s-(1 << s)
    assert D*b == A*a+B
    modulus = 2*D
    residue = ((D-B)*pow(A, -1, modulus)) % modulus
    assert 0 < a == residue < modulus
    assert (a+1)*3**s == (1 << s)*(2*b+1)
    assert 2*b+1 == 3**s and valuation_two(a+1) == s

    kappa = 1-Q(4, 3*n+1)
    z = Q(2, 3)**s
    beta = 1-z
    delta = beta/a
    correction = Q(D*b, A*a)
    assert correction == 1+delta
    psi = max(Q(0), kappa*delta+Q(1, a)-Q(1, b))
    assert psi == (1+kappa*beta)/a-Q(1, b) > 0
    normalized_row = b*psi
    assert normalized_row == (1+kappa*beta)*Q(3**s-1, 2*((1 << s)-1))-1
    lower = (1+Q(19, 27)*kappa)*Q(3, 2)**s/2-1
    assert normalized_row > lower > 0
    scaled = z*(normalized_row+1)
    exact_scaled = (1+kappa-kappa*z)*Q(1-Q(1, 3**s), 1-Q(1, 1 << s))/2
    assert scaled == exact_scaled
    error = abs(scaled-(1+kappa)/2)
    assert error <= z+Q(2, 1 << s)
    # Shifted reciprocal potentials are also directly controlled for this row.
    coefficient = a*psi
    shifted_ratio = coefficient*Q(b+5, a+5)
    assert shifted_ratio >= normalized_row*Q(n, n+5)
    return dict(run_length=s, departure=str(a), arrival=str(b),
                full_modulus=str(modulus), least_run_cylinder_residue=str(residue),
                normalized_incoming_resource=str(normalized_row),
                explicit_lower_bound=str(lower), normalized_limit_error=str(error),
                all_unit_states=True, actual_full_first_return_claimed=False,
                retained_core_membership_claimed=False)


def main():
    if not __debug__:
        raise RuntimeError('Assertions are required; do not use -O or -OO.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('positive_run_inverse_kernel_certificate.json'))
    args = parser.parse_args()
    n = (1 << 71)+1
    lengths = [73, 75, 81, 95, 127, 255, 511, 1023]
    controls = [verify_length(n, s) for s in lengths]
    rows = [Q(item['normalized_incoming_resource']) for item in controls]
    assert all(y > x for x, y in zip(rows, rows[1:]))
    result = dict(status='PASS', arithmetic='integer and Fraction only',
                  fixed_floor=str(n), prescribed_lengths=lengths,
                  odd_input_controls=sum(lengths), controls=controls,
                  local_reciprocal_kernel_obstruction=True,
                  full_core_counterexample_claimed=False,
                  unrestricted_core_bound_proved=False,
                  verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status='PASS', prescribed_lengths=lengths,
                         odd_input_controls=sum(lengths),
                         least_full_run_cylinders_checked=len(controls),
                         full_core_counterexample_claimed=False,
                         certificate=str(args.output)), indent=2))


if __name__ == '__main__':
    main()
