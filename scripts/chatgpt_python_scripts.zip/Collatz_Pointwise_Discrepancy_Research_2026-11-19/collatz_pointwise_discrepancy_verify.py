"""Exact verification of sufficient first-descent criterion; no floating point needed."""

def check(n, steps=200):
    x=n; a=0; first=None; tests=0
    for j in range(1,steps+1):
        if x&1:
            a+=1; x=(3*x+1)//2
        else: x//=2
        if x<n and first is None: first=j
        # Integer comparison: 2**j * n**a > (3*n+1)**a.
        if (1<<j)*pow(n,a)>pow(3*n+1,a):
            assert first is not None and first<=j, (n,j,a,first)
            tests+=1
    return tests

if __name__=='__main__':
    count=sum(check(n) for n in range(2,3002))
    print('PASS; exact sufficient-criterion checks:',count)
