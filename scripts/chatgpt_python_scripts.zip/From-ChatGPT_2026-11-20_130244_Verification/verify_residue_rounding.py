from itertools import product

def T(n):return n//2 if n%2==0 else (3*n+1)//2

def vmax(j,b):return (1<<(j-b))*(3**b-2**b) if b else 0

def gap(j,b):return 3**(b-1)*(1<<(j-b-1))

def check():
  layers=0; equivalent=0; old_exclusions=0; topgap_extra=0; witnesses_checked=0
  for n in range(3,601):
    y=n;a=0
    for j in range(1,21):
      a+=y%2;y=T(y);B=(1<<j)*y
      for b in range(1,a):
        q=3**b;v=vmax(j,b); d=(v-B)%q
        # K077: unique top word, else second-largest envelope
        U=v if d==0 else v-gap(j,b)
        Urounded=U-((U-B)%q)
        threshold=B-q*(n-1)
        assert (U<threshold)==(Urounded<threshold)
        layers+=1;equivalent+=1
        if U<threshold:old_exclusions+=1
        if U<threshold and v>=threshold:topgap_extra+=1
  print('source/count layers',layers)
  print('residue-rounding equivalence checks',equivalent)
  print('K077+K080 exclusions',old_exclusions)
  print('extra versus K012 top envelope',topgap_extra)
  # Exact upper bound verified against all formal words to depth 12
  comparisons=0
  for j in range(1,13):
    vals={b:[] for b in range(j+1)}
    for mask in range(1<<j):
      b=0;U=0
      for i in range(j):
        if mask>>i&1:U=3*U+(1<<i);b+=1
      vals[b].append(U)
    for b in range(1,j):
      q=3**b
      for B in range(1,25):
        v=vmax(j,b);d=(v-B)%q
        U=v if d==0 else v-gap(j,b)
        R=U-(U-B)%q
        actual=[x for x in vals[b] if (x-B)%q==0]
        if actual:assert max(actual)<=R
        comparisons+=1
  print('complete formal-word residue comparisons',comparisons)
if __name__=='__main__':check()
