from fractions import Fraction
from math import ceil

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def run(n,L):
    w=[]
    for _ in range(L):
        w.append(n%2);n=T(n)
    return tuple(w),n

def verify(max_L=12,max_t=8):
    tests=0
    for L in range(1,max_L+1):
        for r in range(1,2**L+1):
            w,b=run(r,L)
            a=sum(w)
            for t in range(max_t+1):
                n=r+(2**L)*t
                wt,z=run(n,L)
                assert wt==w and z==b+3**a*t
                assert Fraction(1,z)==Fraction(1,b+3**a*t)
                tests+=1
    return tests

if __name__=='__main__':
    print('verified:',verify(),'exact cylinder/reciprocal identities')
