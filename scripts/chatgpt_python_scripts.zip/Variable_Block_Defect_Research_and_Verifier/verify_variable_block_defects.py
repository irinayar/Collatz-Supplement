from fractions import Fraction
from itertools import product

def block(e,s):
    a=3**(s+1); d=2**(s+e)
    b=3**s*(1+2**e)-d
    delta=b+7*(d-a)
    return a,b,d,delta

def nextodd(y):
    z=3*y+1; e=(z & -z).bit_length()-1
    return z//(2**e),e

def least_word(word):
    a,b,d=1,0,1
    for e in word:
        b=3*b+d; a*=3; d*=2**e
    return ((d-b)*pow(a,-1,2*d))%(2*d) or 2*d

def test_word(word):
    x=least_word(word); y=x; G=Fraction(1)
    for e in word:
        G*=Fraction(3*y+1,3*y)
        y,got=nextodd(y)
        assert got==e,(word,x,e,got)
    return x,y,G

assert block(2,1)[-1]==0
assert block(3,3)[-1]>0 and block(3,4)[-1]<0
assert block(4,7)[-1]>0 and block(4,8)[-1]<0
for e in range(2,11):
    for s in range(1,25):
        a,b,d,delta=block(e,s)
        formula=3**s*(2**e-20)+6*2**(s+e)
        assert delta==formula
        assert (delta<=0)==(e==2 or e==3 and s>=4 or e==4 and s>=8)
        y,z,G=test_word([e]+[1]*s)
        assert G*(1+Fraction(7,z))-(1+Fraction(7,y))==Fraction(delta,a*y)

# Mixed, nonperiodic admissible sequences, exact verification of EVERY prefix.
choices=[(2,1),(2,2),(3,4),(3,5),(4,8),(4,9)]
cases=0; prefixes=0
for count in range(1,4):
    for seq in product(choices,repeat=count):
        word=[1,1,1]+[v for e,s in seq for v in [e]+[1]*s]
        x=least_word(word)
        assert x>=15
        y=x; G=Fraction(1)
        cap=1+Fraction(25,9*x)
        for e in word:
            G*=Fraction(3*y+1,3*y)
            assert G<cap and G<Fraction(3,2),(seq,x,G)
            y,got=nextodd(y)
            assert got==e
            prefixes+=1
        cases+=1
print('PASS',cases,'mixed exact cylinders',prefixes,'exact prefixes; 216 block parameter checks')
print('Sample e=3,s=4',block(3,4))
print('Sample e=4,s=8',block(4,8))
print('Positive defect example e=3,s=1',block(3,1))
