from functools import lru_cache
from itertools import combinations

def v3(n):
 a=0
 while n%3==0:
  a+=1;n//=3
 return a
@lru_cache(None)
def H(e,x,r):
 if r<0:return None
 a=v3(x+1)
 if e==0:
  return 2**r*((x+1)//3**r)-1 if r<=a else None
 out=[]
 for l in range(min(a,r)+1):
  Y=2*(2**l*((x+1)//3**l)-1)
  v=H(e-1,Y,r-l)
  if v is not None:out.append(v)
 return min(out,default=None)

reduction=0;low=0;bridge=0;strict=0;full=0
for x in range(1,10001):
 a=v3(x+1)
 if a==0:continue
 u=(x+1)//3**a
 star=3*2**(a-1)*u-1
 assert v3(star+1)==1
 vals=[]
 for r in range(0,34):
  v=H(3,x,r)
  if r<a:
   expected=8*(2**r*((x+1)//3**r)-1)
   assert v==expected,(x,r,v,expected)
   low+=1
  else:
   expected=H(3,star,r-a+1)
   assert v==expected,(x,r,v,expected)
   reduction+=1
  if v is None:break
  if vals:
   assert v<vals[-1],(x,r,v,vals[-1]);strict+=1
   if r==a:bridge+=1
  vals.append(v)
  full+=1
 else:raise AssertionError(('increase r cap',x))
print({'reduction_comparisons':reduction,'low_range_comparisons':low,'bridge_comparisons':bridge,'strict_adjacent_comparisons':strict,'finite_values':full})
# independent parity-word enumeration for every x 1..100 and r 0..9
checks=0
for x in range(1,101):
 for r in range(10):
  n=r+3;best=None
  for even_pos in combinations(range(n),3):
   ev=set(even_pos)
   odd=[i for i in range(n) if i not in ev]
   V=sum(2**p*3**(r-1-j) for j,p in enumerate(odd))
   q,rem=divmod(2**n*x-V,3**r)
   if rem or q<1:continue
   y=q
   for i in range(n):
    assert (y%2==0)==(i in ev)
    y=y//2 if y%2==0 else (3*y+1)//2
   assert y==x
   if best is None or q<best:best=q
  assert best==H(3,x,r),(x,r,best,H(3,x,r))
  checks+=1
print({'independent_word_enumeration_cells':checks,'cache':H.cache_info()._asdict()})
