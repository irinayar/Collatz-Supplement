from fractions import Fraction

def F(u):
    z=3*u+1;e=0
    while z%2==0:z//=2;e+=1
    return z,e

def epochs(start,limit=5000):
    u=start; seq=[]; seen=set()
    for _ in range(limit):
        if u==1 or u in seen:break
        seen.add(u);v,e=F(u);seq.append((u,v,e));u=v
    # maximal consecutive e>=2 followed by maximal consecutive e=1
    out=[];i=0
    while i<len(seq):
        if seq[i][2]<2:i+=1;continue
        j=i
        while j<len(seq) and seq[j][2]>=2:j+=1
        if j==len(seq) or seq[j][2]!=1:i=j;continue
        v=seq[j][0];k=j
        while k<len(seq) and seq[k][2]==1:k+=1
        s=k-j
        charge=(Fraction(2)-Fraction(2,3)**s)/(v-1) if v>1 else None
        out.append((v,s,charge))
        i=k
    return out

N=10000; total=0; failures=0; min_margin=None; longest=0
for a in range(3,2*N+3,2):
    for v,s,c in epochs(a):
        if c is None:continue
        total+=1;longest=max(longest,s)
        assert (v+1)%(2**(s+1))==0
        assert c <= Fraction(2,2**(s+1)-2)
        if s>=2: assert c <= Fraction(1,2**s-1)
        else: assert v>=7 and c<=Fraction(2,9)
print('starts',N,'epochs',total,'max_s',longest,'all exact checks passed')
