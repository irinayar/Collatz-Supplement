from itertools import combinations

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def edges(H): return [(x,3*x+1) for x in range(1,H+1,2) if 3*x+1<=H]

def collisions(A):
    A=set(A)
    return sum(x in A and 3*x+1 in A for x in A if x%2)

for H in range(1,101):
    E=edges(H)
    assert len(E)==(H+2)//6
    assert len(set(v for pair in E for v in pair))==2*len(E)
    A=set(range(1,H+1))-{x for x,y in E}
    assert len(A)==H-len(E) and collisions(A)==0
    assert len({T(x) for x in A})==len(A)
    for n in range(1,H+1):
        assert collisions(range(1,n+1)) == (n+2)//6
for H in range(1,12):
    for bits in range(1<<H):
        A={i+1 for i in range(H) if bits>>i&1}
        C=collisions(A)
        assert len({T(x) for x in A})==len(A)-C
        assert C>=max(0,len(A)-(H-(H+2)//6))
print('Verified H=1..100 matching construction and H=1..11 exhaustive subsets (4094 subsets).')
