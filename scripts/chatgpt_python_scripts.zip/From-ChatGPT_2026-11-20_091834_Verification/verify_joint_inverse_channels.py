from itertools import combinations
from collections import Counter

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def numerator(j, positions):
    a=len(positions)
    return sum((2**i)*3**(a-h-1) for h,i in enumerate(positions))

def feasible(j,y,a):
    return [numerator(j,pos) for pos in combinations(range(j),a) if (2**j*y-numerator(j,pos))%3**a==0 and (2**j*y-numerator(j,pos))//3**a>0]

def maxword(j,y,a):
    v=feasible(j,y,a)
    return max(v) if v else None

for j in range(1,9):
    for a in range(j+1):
        for y in range(1,151):
            assert maxword(j,y,a)==maxword(j,y+3**a,a),(j,a,y)

for n in [15+192*t for t in range(100)]+[79+192*t for t in range(100)]:
    assert n%64==15 and n%3 in (0,1)
    s=n;p=n-1
    for k in range(1,7):
        s=T(s);p=T(p)
        if k<6: assert s!=p
    assert s==p
    assert maxword(6,s,4)>65
    assert maxword(6,s,5) is None and maxword(6,s,6) is None
print('PASS: 6600 fixed-count ternary-shift comparisons; 200 family controls')
for n in (15,79,143):
    y=n
    for _ in range(6):y=T(y)
    print(n,y,{a:maxword(6,y,a) for a in range(4,7)})
