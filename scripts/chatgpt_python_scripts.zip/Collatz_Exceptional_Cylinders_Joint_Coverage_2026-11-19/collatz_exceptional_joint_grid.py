from itertools import product
from math import gcd
import json

def data(w):
 a=u=0
 for i,b in enumerate(w):
  if b: a+=1;u=3*u+2**i
 return len(w),a,u

def residue(w):
 j,a,u=data(w);return (-u*pow(3**a,-1,2**j))%(2**j)

def forward(n,w):
 x=n
 for b in w:
  assert x%2==b,(n,w,x,b)
  x=(3*x+1)//2 if b else x//2
 return x

def join(w,v):
 j,a,u=data(w);ell,b,uv=data(v);r=residue(w)
 y=(3**a*r+u)//2**j;B=2**ell*y-uv;C=2**ell*3**a;Q=3**b;g=gcd(C,Q)
 if B%g:return None
 q=Q//g;t0=(-B//g*pow(C//g,-1,q))%q if q>1 else 0
 n0=r+2**j*t0;m0=(B+C*t0)//Q
 sn=2**j*q;sm=C//g
 return dict(q=q,t0=t0,n0=n0,m0=m0,sn=sn,sm=sm,positive_slope=(sm<sn))

def exceptional(w):
 j,a,u=data(w)
 return all(3**data(w[:i])[1]>=2**i for i in range(1,j+1))

def scan(w,ellmax=8,K=10):
 j,a,u=data(w);r=residue(w)
 assert K>j and exceptional(w)
 allwords=[v for ell in range(1,ellmax+1) for v in product((0,1),repeat=ell)]
 catalog=[(v,z) for v in allwords if (z:=join(w,v)) and z['positive_slope']]
 B=max((data(v)[1]-a for v,z in catalog),default=0);B=max(0,B)
 q=3**B;binmod=2**(K-j);P=q*binmod
 # Eventual meeting coverage from each target congruence; exact affordability beyond a computable threshold.
 # for t=t0+qv*z, m0+sm*z<n0+sn*z. n>0,m>0, m<n for all z >= z_min.
 def ceildiv(x,y):return -((-x)//y)
 thresholds=[]
 for v,z in catalog:
  dz=z['sn']-z['sm'];assert dz>0
  zmin=max(ceildiv(1-z['m0'],z['sm']),ceildiv(1-z['n0'],z['sn']), (z['m0']-z['n0'])//dz+1,0)
  thresholds.append(z['t0']+z['q']*zmin)
 threshold=max(thresholds,default=0)
 # At each t class mod P, future parity through K is fixed. For a contracting prefix s,
 # eventual descent holds when n>U_s/(2^i-3^a); compute explicit t threshold.
 descent_prefixes=[]
 for bbits in product((0,1),repeat=K-j):
  ext=w+bbits
  if residue(ext)%(2**j)!=r:continue
  # this ext corresponds to exactly one t residue modulo binmod
  rr=residue(ext);tbin=((rr-r)//2**j)%binmod
  best=None
  for i in range(j+1,K+1):
   ii,aa,uu=data(ext[:i]);D=2**ii-3**aa
   if D>0:
    # n=r+2^j*t, n*D>uu
    tmin=max(0,(uu//D-r)//(2**j)+1)
    if best is None or tmin<best:best=tmin
  if best is not None:descent_prefixes.append((tbin,best))
 descdict=dict(descent_prefixes)
 meet=set();desc=set()
 for t in range(P):
  if any(t%z['q']==z['t0'] for v,z in catalog):meet.add(t)
  if t%binmod in descdict:desc.add(t)
 union=meet|desc
 # strict explicit universal threshold for union classes; every sufficiently large t in union certifies
 desc_threshold=max([x for x in descdict.values()]+[threshold,0])
 # independently sample 3 representatives of every class above threshold and verify all claims
 checks=0
 for t0 in range(P):
  for off in (1,2):
   t=t0+P*(1+(desc_threshold//P)+off)
   n=r+2**j*t;assert forward(n,w)>0
   if t0 in meet:
    valid=False
    for v,z in catalog:
     if t%z['q']==z['t0']:
      zz=(t-z['t0'])//z['q'];m=z['m0']+z['sm']*zz
      if 1<=m<n:
       assert forward(m,v)==forward(n,w)
       valid=True;break
    assert valid
   if t0 in desc:
    x=n;hit=False
    for i in range(1,K+1):
     x=(3*x+1)//2 if x%2 else x//2
     if i>=j+1 and x<n:hit=True
    assert hit
   checks+=1
 return dict(prefix=''.join(map(str,w)),length=j,source_residue=r,target_max=ellmax,descent_depth=K,ternary_mod=q,binary_mod=binmod,combined_mod=P,targets=len(catalog),eventual_meeting=len(meet),eventual_descent=len(desc),both=len(meet&desc),union=len(union),uncovered=len(set(range(P))-union),uncovered_residues=sorted(set(range(P))-union) if P<=5000 else [],sufficient_t_threshold=desc_threshold+P,checks=checks)

if __name__=='__main__':
 results=[]
 for w in ((1,1,0,1,1),(1,1,1,0,1),(1,1,0,1,1,0,1),(1,1,1,0,1,1)):
  if exceptional(w):
   res=scan(w,ellmax=8,K=10);results.append(res);print({k:v for k,v in res.items() if k!='uncovered_residues'},flush=True)
 with open('/mnt/data/Collatz_Exceptional_Joint_Grid_Results_2026-11-19.json','w') as f:json.dump(results,f,indent=2)
