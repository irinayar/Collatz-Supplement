from itertools import combinations
from collections import defaultdict

def num(pos):
 b=len(pos)
 return sum((1<<p)*3**(b-1-i) for i,p in enumerate(pos))

def bound(j,b,r):
 assert b>=3
 best=None
 for q,p,l in combinations(range(j),3):
  if q<b-3 or (9*(1<<q)+3*(1<<p)+(1<<l))%27!=r: continue
  c=b-3
  val=27*(1<<(q-c))*(3**c-2**c)+9*(1<<q)+3*(1<<p)+(1<<l)
  if best is None or val>best:best=val
 return best

comparisons=0; nonempty=0; empty=0; improved=0; failures=[]
for j in range(3,14):
 for b in range(3,j+1):
  actual={}
  mod9={}
  for positions in combinations(range(j),b):
   v=num(positions)
   r=v%27
   actual[r]=max(actual.get(r,-1),v)
   r9=v%9
   mod9[r9]=max(mod9.get(r9,-1),v)
  for r in range(27):
   v=bound(j,b,r)
   expected=actual.get(r)
   comparisons+=1
   if v!=expected:failures.append((j,b,r,v,expected))
   if v is None:empty+=1
   else:
    nonempty+=1
    if v<mod9[r%9]:improved+=1
print(dict(comparisons=comparisons,nonempty=nonempty,empty=empty,strict_mod9_improvements=improved,failures=failures[:5]))
assert not failures
