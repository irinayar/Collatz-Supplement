from itertools import product

def v3(n):
 if n==0:return 10**9
 k=0
 while n%3==0:n//=3;k+=1
 return k

def numerator(bits):
 v=a=0
 for t,c in enumerate(bits):
  if c=='1':v=3*v+2**t;a+=1
 return v

def classification(x,r,i,j,k):
 a=v3(x+1);u=(x+1)//3**a
 if j>=1:
  if a>=r:return False
  if k!=a:return False
  C=2**(j+1)*(2**(a+1)*u-1)-3**j
  return i+j<=v3(C)
 # j=0
 if a>=r:
  return i<=1
 if a!=k+1:return False
 return i-1<=v3(2**(a+1)*u-1)

cases=0
for x in range(1,301):
 for r in range(0,15):
  for i in range(r+1):
   for j in range(r-i+1):
    k=r-i-j
    bits='1'*i+'0'+'1'*j+'0'+'1'*k
    V=numerator(bits)
    valid=(2**(r+2)*x-V)%3**r==0
    pred=classification(x,r,i,j,k)
    assert pred==valid,(x,r,i,j,k,pred,valid)
    if valid:
     m=(2**(r+2)*x-V)//3**r
     assert m>0
     y=m
     for c in bits:
      assert y%2==int(c)
      y=(3*y+1)//2 if y%2 else y//2
     assert y==x
    cases+=1
print('PASS',cases,'exact valuation classifications and parity reconstructions')
