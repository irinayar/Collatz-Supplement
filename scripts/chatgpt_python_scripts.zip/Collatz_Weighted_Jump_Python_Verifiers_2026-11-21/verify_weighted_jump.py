#!/usr/bin/env python3
"""Exact finite-prefix checks; not a proof of a uniform Collatz bound."""
from fractions import Fraction as Q
from math import log

def odd_step(u):
    assert u > 0 and u % 2
    v = 3*u + 1
    e = (v & -v).bit_length() - 1
    return v >> e, e

def block_constant(e, s):
    a = 3**(s+1)
    d = 2**(s+e)
    B = 3**s * (1 + 2**e) - d
    assert e >= 2 and s >= 1 and a > d and B > 0
    return Q(B, a-d)

def check(x, max_steps=2000):
    u=x
    valuations=[]; states=[u]
    for _ in range(max_steps):
        u,e=odd_step(u)
        valuations.append(e); states.append(u)
        if u==1: break
    if len(valuations)<3 or valuations[:3] != [1,1,1]: return None
    y1=states[3]
    assert y1 == Q(27*x+19, 8)
    blocks=[]; pos=3
    while pos < len(valuations):
        e=valuations[pos]
        if e<2: break
        s=0
        while pos+1+s < len(valuations) and valuations[pos+1+s]==1:
            s+=1
        if s==0 or 3**(s+1)<=2**(s+e): break
        end=pos+1+s
        blocks.append((pos,end,e,s,block_constant(e,s)))
        pos=end
    if not blocks: return None
    G0=Q(27*x+19,27*x)
    G=G0
    A=Q(0); S=Q(0)
    signed=Q(1)
    for j,(start,end,e,s,c) in enumerate(blocks):
        y,z=states[start],states[end]
        # Product of stepwise correction factors in the block.
        gb=Q(1)
        for t in range(start,end): gb*=Q(3*states[t]+1,3*states[t])
        assert gb == (1+c/Q(y))/(1+c/Q(z))
        G*=gb
        if j+1<len(blocks):
            cnext=blocks[j+1][4]
            jump=(cnext-c)/Q(z+c)
            signed*=1+jump
            delta=max(Q(0),cnext-c)
            S+=delta/Q(z+c)
            E=sum(valuations[:end]); b=end
            A+=delta*Q(2**E,3**b)
    assert S <= A/Q(x)
    c1=blocks[0][4]; cN=blocks[-1][4]
    signed_G=G0*(1+c1/Q(y1))*signed/(1+cN/Q(states[blocks[-1][1]]))
    assert G==signed_G
    # Exact rational upper bound using exp(t) >= 1+t, and product <= exp(S).
    # Floating evaluation is only a diagnostic, not a certificate.
    bound_log=log(float(1+Q(19+8*c1,27*x)))+float(A/Q(x))
    return {'x':x,'blocks':len(blocks),'max_reset':max(b[2] for b in blocks),
            'S':str(S),'A':str(A),'G':str(G),'log_upper_diagnostic':bound_log,
            'sufficient_cutoff_met':bound_log<log(1.5)}

if __name__=='__main__':
    tested=0; longest=0; high=0; examples=[]
    for x in range(1,200000,2):
        result=check(x,500)
        if result is None: continue
        tested+=1; longest=max(longest,result['blocks'])
        if result['max_reset']>=6: high+=1
        if len(examples)<8: examples.append(result)
    print({'checked_eligible_starts':tested,'longest_completed_expanding_block_run':longest,
           'cases_with_reset_at_least_6':high,'examples':examples})
