#!/usr/bin/env python3
"""Exact block constants and fixed-C obstruction calculations."""
from fractions import Fraction as Q
from verify_weighted_jump import block_constant

def minimum_expanding_s(e):
    s=1
    while 3**(s+1)<=2**(s+e): s+=1
    return s

if __name__=='__main__':
    for e in range(2,16):
        s=minimum_expanding_s(e)
        c=block_constant(e,s)
        assert all(block_constant(e,t)<=c for t in range(s,s+15))
        print(f'e={e} minimum_s={s} c={c} approx={float(c):.8f}')
    assert block_constant(5,6)==Q(22009,139)
