#!/usr/bin/env python3
"""Exact implementation controls for first-crossing structural theorems.

No new CST verification horizon, high-cycle exclusion, or divergent orbit is
claimed. Imported canonical packing bounds are not recomputed by this script.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json


def T(x):
    assert x > 0
    return (3*x+1)//2 if x % 2 else x//2


def v2(x):
    assert x != 0
    x = abs(x)
    return (x & -x).bit_length()-1


def affine(bits):
    a, b, d, g = 1, 0, 1, 0
    for bit in bits:
        assert bit in (0, 1)
        if bit:
            b = 3*b+d
            a *= 3
            g += 1
        d *= 2
    return a, d, b, g


def follow(source, count):
    states = [source]
    for _ in range(count):
        states.append(T(states[-1]))
    return states


def critical_table(max_g):
    result = {0: (1, 0, ())}
    a, b = 1, 0
    positions = []
    for g in range(1, max_g+1):
        position = a.bit_length()-1
        positions.append(position)
        b = 3*b+(1 << position)
        a *= 3
        result[g] = (a, b, tuple(positions))
    return result


def first_crossing_word_controls(max_length=18):
    critical = critical_table(max_length)
    leaves = 0
    least_source_replays = 0
    maximum = {}
    attaining_counts = {}
    stack = [((), 1, 1, 0, 0)]
    while stack:
        bits, a, d, b, g = stack.pop()
        length = len(bits)
        if length and a < d:
            leaves += 1
            assert bits[-1] == 0
            if g:
                assert bits[0] == 1 and length == a.bit_length()
                ac, bc, positions = critical[g]
                assert ac == a and b <= bc
                actual_positions = tuple(i for i, bit in enumerate(bits) if bit)
                assert all(t <= bound for t, bound in zip(actual_positions, positions))
                assert Q(b, a) <= Q(bc, a) <= Q(g, 3)
                if g > 1:
                    assert Q(bc, a) < Q(g, 3)
                maximum[g] = max(maximum.get(g, -1), b)
                if b == bc:
                    attaining_counts[g] = attaining_counts.get(g, 0)+1
            else:
                assert bits == (0,) and b == 0
            residue = (-b*pow(a, -1, d)) % d
            source = residue if residue >= 2 else residue+d
            for n in (source, source+d):
                path = follow(n, length)
                assert tuple(x % 2 for x in path[:-1]) == bits
                assert d*path[-1] == a*n+b
                # A small diagnostic already covered by published/project work.
                assert path[-1] < n
                if g:
                    upper = (critical[g][1]-(d-a)*n)//d
                    assert path[-1]-n <= upper
                least_source_replays += 1
            continue
        if length == max_length:
            continue
        stack.append((bits+(0,), a, 2*d, b, g))
        stack.append((bits+(1,), 3*a, 2*d, 3*b+d, g+1))

    critical_controls = []
    for g, observed in sorted(maximum.items()):
        a, b, positions = critical[g]
        j = a.bit_length()
        bits = tuple(int(i in positions) for i in range(j))
        assert affine(bits) == (a, 1 << j, b, g)
        aa, dd = 1, 1
        for index, bit in enumerate(bits, 1):
            aa *= 3 if bit else 1
            dd *= 2
            assert (aa < dd) == (index == j)
        assert observed == b and attaining_counts[g] == 1
        critical_controls.append(dict(g=g, j=j, numerator=b,
                                      maximal_phase=str(Q(b, a))))
    return dict(max_length=max_length, first_crossing_words=leaves,
                least_source_and_lift_replays=least_source_replays,
                critical_maxima=critical_controls,
                scope='Finite implementation check, not new CST horizon coverage.')


def ordered_cutoffs():
    expected = {
        24: (25, 8, 5), 64: (282, 46, 29), 128: (868, 65, 41),
        256: (4863, 233, 147), 512: (72059, 485, 306),
        1000: (72059, 485, 306), 4096: (620859, 3647, 2301),
    }
    rows = []
    critical = critical_table(4096)
    for horizon, expected_row in expected.items():
        best = Q(0)
        maximizer = None
        for g in range(1, horizon+1):
            a, b, _ = critical[g]
            j = a.bit_length()
            if j > horizon:
                break
            d = 1 << j
            bound = Q(b, d-a)
            if bound > best:
                best = bound
                maximizer = (j, g)
        cutoff = best.numerator//best.denominator+1
        assert (cutoff, *maximizer) == expected_row
        rows.append(dict(horizon=horizon, analytic_cutoff=cutoff,
                         maximizing_length=maximizer[0],
                         maximizing_odd_count=maximizer[1]))
    return rows


def double_word_controls(max_length=11):
    contracting_words = replays = closing_controls = 0
    for j in range(1, max_length+1):
        for code in range(1 << j):
            bits = tuple((code >> i) & 1 for i in range(j))
            a, d, b, _ = affine(bits)
            assert b <= 3**j-2**j < d*d
            if a >= d:
                continue
            contracting_words += 1
            ar, dr, br, _ = affine(bits+bits)
            assert (ar, dr, br) == (a*a, d*d, b*(a+d))
            residue = (-br*pow(ar, -1, dr)) % dr
            least = residue if residue else dr
            for source in (least, least+dr):
                path = follow(source, 2*j)
                assert tuple(x % 2 for x in path[:-1]) == bits+bits
                middle = path[j]
                assert (middle-source) % d == 0
                assert middle <= source
                if middle == source:
                    assert path[2*j] == source
                    assert (d-a)*source == b
                    closing_controls += 1
                    # The finite controls never lie above the research floor.
                    assert min(path) < 1 << 71
                replays += 1
    return dict(max_length=max_length, contracting_words=contracting_words,
                complete_double_word_replays=replays,
                ineligible_small_closing_controls=closing_controls)


def parity_change_controls():
    controls = []
    for source, length in ((7, 8), (91, 46), (73, 65), (487, 73),
                           (3567, 92), (885, 27), (859, 46), (859, 65), (859, 73)):
        path = follow(source, length)
        bits = tuple(x % 2 for x in path[:-1])
        a, d, b, g = affine(bits)
        endpoint = path[-1]
        displacement = endpoint-source
        assert a < d and displacement > 0
        assert 0 < displacement < Q(b, d) < d
        agreement = v2(displacement)
        left = follow(source, agreement+1)
        right = follow(endpoint, agreement+1)
        assert all(left[i] % 2 == right[i] % 2 for i in range(agreement))
        assert left[agreement] % 2 != right[agreement] % 2
        aa = 1
        for i in range(agreement+1):
            assert (right[i]-left[i])*(1 << i) == aa*displacement
            aa *= 3 if left[i] % 2 else 1
        future = follow(endpoint, length)
        assert tuple(x % 2 for x in future[:-1]) != bits
        prefix_a = 1
        first_cross = None
        for i, bit in enumerate(bits, 1):
            prefix_a *= 3 if bit else 1
            if first_cross is None and prefix_a < 1 << i:
                first_cross = i
        assert first_cross < length  # Not a first-crossing counterexample.
        controls.append(dict(source=source, length=length, odd_count=g,
                             endpoint=endpoint, displacement=displacement,
                             shared_parity_bits=agreement,
                             first_coefficient_crossing=first_cross))

    isometry_cases = 0
    for source in (1, 2, 3, 7, 27, 859, (1 << 80)-1):
        for displacement in (1, 2, 3, 4, 8, 12, 52, 1 << 80):
            agreement = v2(displacement)
            x, y = source, source+displacement
            for i in range(agreement+1):
                assert ((x-y) % 2 == 0) == (i < agreement)
                x, y = T(x), T(y)
            isometry_cases += 1
    return dict(actual_paradoxical_controls=controls,
                additional_exact_isometry_cases=isometry_cases)


def progression_count(lo, hi, residue, modulus):
    if hi < lo:
        return 0
    first = lo+(residue-lo) % modulus
    return max(0, (hi-first)//modulus+1)


def finite_band_controls():
    cases = []
    for n in list(range(3, 204, 2))+[(1 << 71)+1, (1 << 190)+1]:
        hi = (367*n-1)//250  # largest integer strictly below (367/250)*n
        count = sum(progression_count(n, hi, residue, 6) for residue in (1, 5))
        upper = (117*n+749)//750+2
        assert count <= upper
        if n <= 203:
            assert count == sum(x % 6 in (1, 5) for x in range(n, hi+1))
        assert Q(367, 500)*n < n
        if n >= 11:
            assert Q(146, 125)*n <= (4*n-2)//3
        cases.append(dict(n=str(n), available_continuing_cut_vertices=str(count),
                          elementary_upper=str(upper)))
    assert 62*11-625 > 0  # algebraic all-n>=11 low-band inclusion
    return dict(exact_band_count_cases=len(cases), large_examples=cases[-2:])


def finite_coefficient_minimum_controls():
    # Finite controls for the future-minimum identity; none certifies an
    # infinite-CST source or a divergent orbit.
    paths = [follow((1 << 80)-1, 60)]
    t = 1 << 80
    paths.append(follow(60511+131072*t, 17))
    rows = []
    for path in paths:
        assert len(set(path)) == len(path)
        assert min(path) >= 1 << 71
        a, d = 1, 1
        coefficients = [Q(1)]
        correction = Q(1)
        corrections = [correction]
        for x in path[:-1]:
            if x % 2:
                a *= 3
                correction *= 1+Q(1, 3*x)
            d *= 2
            coefficients.append(Q(a, d))
            corrections.append(correction)
        assert all(path[i] == path[0]*coefficients[i]*corrections[i]
                   for i in range(len(path)))
        assert max(corrections) < Q(367, 250)
        minimum_index = min(range(len(path)), key=lambda i: coefficients[i])
        assert coefficients[minimum_index] <= 1
        assert all(coefficients[i] > coefficients[minimum_index]
                   for i in range(minimum_index+1, len(path)))
        assert path[minimum_index] < Q(367, 250)*path[0]
        rows.append(dict(source=str(path[0]), observed_steps=len(path)-1,
                         coefficient_minimum_index=minimum_index,
                         selected_source=str(path[minimum_index]),
                         future_observed_steps=len(path)-1-minimum_index,
                         infinite_CST_claimed=False))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('first_crossing_structure_certificate.json'))
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Do not run this verifier with -O or -OO.')
    result = dict(status='PASS', arithmetic='integer and Fraction only',
                  first_crossing_word_controls=first_crossing_word_controls(),
                  ordered_analytic_cutoffs=ordered_cutoffs(),
                  double_word_controls=double_word_controls(),
                  parity_change_controls=parity_change_controls(),
                  finite_band_controls=finite_band_controls(),
                  finite_coefficient_minimum_controls=finite_coefficient_minimum_controls(),
                  CST_conjecture_proved=False, no_crossing_sources_excluded=False,
                  canonical_packing_rerun=False, new_verification_horizon_claimed=False)
    result['verifier_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(status='PASS',
                         first_crossing_words=result['first_crossing_word_controls']['first_crossing_words'],
                         cylinder_replays=result['first_crossing_word_controls']['least_source_and_lift_replays'],
                         double_word_controls=result['double_word_controls'],
                         analytic_cutoff_4096=result['ordered_analytic_cutoffs'][-1],
                         finite_band_controls=result['finite_band_controls'],
                         certificate=str(args.output)), indent=2))


if __name__ == '__main__':
    main()
