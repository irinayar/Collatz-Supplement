#!/usr/bin/env python3
"""Independent exact audit of K167--K169 and chronological run weights.

No producer Python module is imported. The existing source-code certificate is
read as an already audited input, not regenerated. No broad trajectory census
or unavailable finite-base/cylinder certificate is represented as rerun.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
A=F(47,32)


def ceildiv(a,b):
    return -((-a)//b)


def T(x):
    return (3*x+1)//2 if x&1 else x//2


def horizon_table():
    expected={24:(35,24,15),64:(392,46,29),128:(1200,65,41),
              256:(6750,233,147),512:(99832,485,306),
              1000:(99883,970,612),1539:(330912,1539,971),
              2048:(330912,1539,971),3000:(583561,2593,1636),
              4096:(860947,3647,2301)}
    p3=1;a=0;best_num=0;best_den=1;best_pair=(1,0);rows=[]
    for j in range(1,4097):
        D=1<<j
        while 3*p3<D:
            p3*=3;a+=1
        assert p3<D<=3*p3
        num=a*D;den=3*(D-p3)
        if num*best_den>best_num*den:
            best_num,best_den,best_pair=num,den,(j,a)
        if j in expected:
            N=1+best_num//best_den
            assert (N,*best_pair)==expected[j]
            assert N*best_den>best_num>=(N-1)*best_den
            rows.append({'J':j,'N_J':N,'maximizing_j':best_pair[0],
                         'maximizing_a':best_pair[1],
                         'exact_maximum':str(F(best_num,best_den))})
    assert (1<<71)*best_den>best_num
    return {'rows':rows,'integer_depth_comparisons':4096,
            'high_floor_pure_prefix_horizon':4096,
            'scope':'The large-source lemma is proved algebraically. The all-starts finite-base scans and 23488 cylinder certificates are source-reported, not rerun.'}


def first_crossing(start,cap=4096):
    x=start;a=U=0;parities=[]
    for j in range(1,cap+1):
        parity=x&1;parities.append(parity)
        if parity:
            a+=1;U=3*U+(1<<(j-1))
        x=T(x)
        assert (1<<j)*x==3**a*start+U
        if 3**a<(1<<j):
            assert x<start
            return {'source':str(start),'depth':j,'odd_inputs':a,
                    'endpoint':str(x),'numerator_U':str(U),
                    'parity_word_lsb_first':''.join(map(str,parities))}
        assert x>=start
    raise AssertionError('The specified compact control did not cross within the cap.')


def crossing_controls():
    r=3906279020429388260071
    historical=first_crossing(r)
    assert (historical['depth'],historical['odd_inputs'])==(97,61)
    examples=[first_crossing(n) for n in [100007,100015,100027]]
    assert [(d['depth'],int(d['endpoint'])) for d in examples]==[(12,53398),(8,94937),(7,63299)]
    return {'historical_start':historical,'three_displayed_controls':examples,
            'historical_failure_mechanism':'Not identified for the nine original flags; their individual parameters and unchecked program were not rerun.'}


def residue_filter():
    rows=[];retained=[]
    for r in range(1,32,2):
        source=r+32;x=source;a=U=0;descent=None
        for j in range(1,6):
            if x&1:
                a+=1;U=3*U+(1<<(j-1))
            x=T(x)
            assert (1<<j)*x==3**a*source+U
            if x<source:
                descent=j;break
            assert 3**a>=(1<<j)
        slope=(32*3**a)//(1<<j)
        assert slope*(1<<j)==32*3**a
        row={'residue_mod32':r,'seed':source,'steps':j,'odd_inputs':a,
             'endpoint':x,'U':U,'lift_endpoint_slope':slope}
        if descent is None:
            retained.append(r)
            assert slope>=32 and x>=source
            row['status']='survives five steps for every source=seed+32t, t>=0'
        else:
            assert slope<32
            if r%4==1:assert (j,a,U)==(2,1,1)
            elif r%16==3:assert (j,a,U)==(4,2,5)
            elif r==11:assert (j,a,U)==(5,3,23)
            else:assert r==23 and (j,a,U)==(5,3,19)
            row['status']='strict descent for every source=seed+32t, t>=0'
            row['gap_constant']=source-x
            row['gap_slope']=32-slope
        rows.append(row)
    assert retained==[7,15,27,31]
    counts={}
    for r in range(1,32,2):
        first=100001+(r-100001)%32
        counts[r]=max(0,(860946-first)//32+1)
    remaining=sum(counts[r] for r in retained)
    eliminated=sum(counts.values())-remaining
    assert (remaining,eliminated,sum(counts.values()))==(95118,285355,380473)
    return {'exact_affine_lift_rows':rows,'retained_odd_residues':retained,
            'new_interval':'100001 <= n < 860947',
            'retained_source_count':remaining,'eliminated_source_count':eliminated,
            'remaining_trajectories_replayed':False}


def affine_rows(word):
    E=B=0;rows=[(0,0)]
    for e in word:
        B=3*B+(1<<E);E+=e;rows.append((E,B))
    return rows


def actual_return(n,u,word):
    H=(4*n-2)//3;odd=[u];shortcut=[u]
    for e in word:
        z=3*odd[-1]+1
        assert (z&-z).bit_length()-1==e
        for _ in range(e):shortcut.append(T(shortcut[-1]))
        odd.append(z>>e)
        assert shortcut[-1]==odd[-1] and odd[-1]&1
    assert n<=u<=H and n<=odd[-1]<=H and all(x>H for x in odd[1:-1])
    assert len(set(shortcut[:-1]))==len(shortcut)-1
    return odd,shortcut


def run_weight_controls(seed_path):
    raw=seed_path.read_bytes();groups=json.loads(raw)['groups']
    paths=runs_seen=moments=nonempty=phase_windows=0;largest_phase=F(0)
    for group in groups:
        n=group['n'];H=(4*n-2)//3
        for source in group['sources']:
            u=source['u'];word=source['word'];g=len(word)
            odd,shortcut=actual_return(n,u,word)
            rows=affine_rows(word)
            phases=[F(B,3**i) for i,(E,B) in enumerate(rows)]
            G=1+phases[-1]/u
            assert G<A  # Direct comparison on these named controls only.
            largest_phase=max(largest_phase,phases[-1])
            run_rows=[];start=0;W=F(0);run_product=F(1)
            for i,e in enumerate(word):
                if e<2:continue
                s=i-start+1;beta=1-F(2,3)**s;mass=beta/odd[start]
                assert all(v==1 for v in word[start:i])
                assert phases[i+1]-phases[start]==(u+phases[start])*mass
                run_product*=1+mass;W+=mass
                assert beta/F(s+1)<=F(5,27)
                run_rows.append((start,i+1,s,mass));start=i+1
            assert start==g and run_product==G
            R=sum((F(1,odd[i]) for i,_,_,_ in run_rows),F(0))
            M=sum((F(1,x) for x in shortcut[:-1]),F(0))
            even_mass=sum((F(1,x) for x in shortcut[:-1] if x%2==0),F(0))
            compensated=sum((F(x+1,x*(3*x+1)) for x in shortcut[:-1] if x&1),F(0))
            assert even_mass==compensated+F(1,odd[-1])-F(1,u)
            assert M<=3*W+R-F(1,u)+F(1,odd[-1])
            assert R<=3*W and M<=6*W+F(1,n)-F(1,H)
            assert W<=G-1
            assert M<=(4+F(2,3*n+1))*W+F(1,odd[-1])-F(1,u)
            assert M<=4*W+F(1,n)-F(1,H)+2*(A-1)/(3*n+1)
            assert G-1<=G*W
            assert G-1<F(61,50)*W
            for budget in [F(0),F(1,10),F(1),F(5)]:
                removed=sum((mass for i,_,_,mass in run_rows
                    if phases[i]<=budget or phases[-1]-phases[i]<=budget),F(0))
                assert removed<=(2*budget+1)/n
                chosen=[mass for i,_,_,mass in run_rows
                    if i>0 and phases[i]>budget and phases[-1]-phases[i]>budget]
                Z=max(F(0),phases[-1]-2*budget)
                upper=Z/(u+budget)+(F(1,H+1) if phases[-1]>2*budget else 0)
                assert sum(chosen,F(0))<=upper
                moments+=1;nonempty+=bool(chosen);phase_windows+=1
            paths+=1;runs_seen+=len(run_rows)
    assert paths==23 and largest_phase<10
    # Exact maximization of beta_s/(s+1): the difference changes sign after s=1.
    assert F(1,3)/2<F(5,9)/3==F(5,27)
    assert F(2,3)**2*(2+4)<3
    # For s>=2, [(2/3)^(s+1)(s+5)] / [(2/3)^s(s+4)] <1.
    assert 2*(2+5)<3*(2+4)
    return {'seed_sha256':sha256(raw).hexdigest(),'saved_paths':paths,
            'run_controls':runs_seen,'weighted_moment_controls':moments,
            'nonempty_weighted_moment_controls':nonempty,
            'phase_window_controls':phase_windows,'maximum_saved_phase':str(largest_phase),
            'scope':'These 23 previously saved paths do not represent all profiles at their thresholds.'}


def mechanical_phase_control():
    # This interval deliberately avoids a terminal coefficient near one.
    g=54;Aword=3**g;E=Aword.bit_length();D=1<<E
    assert 3*D<4*Aword and 5*Aword<4*D
    cumulative=[(3**i).bit_length()-1 for i in range(g)]+[E]
    word=[cumulative[i+1]-cumulative[i] for i in range(g)]
    rows=affine_rows(word);assert rows[-1][0]==E
    B=rows[-1][1];a=((D-B)*pow(Aword,-1,2*D))%(2*D)
    assert a%16==11
    u=a+4*D;n=3*(u+1)//4;H=(4*n-2)//3
    assert H==u and n>=1<<71
    assert u-2*D<n and (H-n)<2*D
    assert (D-Aword)*u>B and (4*Aword-3*D)*u>3*D-4*B
    odd,shortcut=actual_return(n,u,word)
    crossing=first_crossing(u)
    assert crossing['depth']==E and crossing['odd_inputs']==g
    phase=F(B,Aword)
    assert F(g+1,6)<phase<F(g,3) and phase>10
    charge=(1+phase/u)*(1+F(5,odd[-1]))/(1+F(5,u))-1
    assert charge>0
    starts=[0]+[i+1 for i,e in enumerate(word[:-1]) if e>=2]
    assert all(E-rows[i][0]<=odd[i].bit_length()-1 for i in starts)
    return {'g':g,'E':E,'source_residue_mod_2D':str(a),'source':str(u),
            'threshold':str(n),'endpoint':str(odd[-1]),'word':word,
            'terminal_multiplier':str(F(Aword,D)),'phase':str(phase),
            'phase_display_only':float(phase),'positive_charge':str(charge),
            'least_source_reason':'Band width<2D and preceding source u-2D<n.',
            'run_starts':len(starts),'interior_run_starts':0,
            'scope':'Linear phase growth is compatible with terminal multiplier in (3/4,4/5); this family is entirely terminal and does not refute the central bound.'}


def profile_upper(n):
    H=(4*n-2)//3;k=(H-n).bit_length()
    assert n>=1<<71 and k<=4096
    # The independently verified N_4096 threshold makes the pure prefix
    # barrier exact at these lengths. Short endpoint restrictions stay exact.
    row={2:1};short=0
    for j in range(3,k+1):
        short+=sum(c for r,c in row.items()
                   if (3*n-k)*(1<<j)<3*H*3**r and n*3**r<H*(1<<j))
        row={r:row.get(r,0)+row.get(r-1,0)
             for r in range(1,j+1) if 3**r>1<<j}
    long=sum(row.values());new=long+short
    old={2:1}
    for j in range(3,H.bit_length()+1):
        old={r:old.get(r,0)+old.get(r-1,0)
             for r in range(1,j+1) if 3**r>1<<(j-1)}
    old_bound=2*sum(old.values())
    return {'k':k,'long':long,'short':short,'new':new,'old':old_bound,
            'Pstar':min(new,old_bound)}


def nonempty_core_control(seed_path):
    raw=seed_path.read_bytes();data=json.loads(raw)
    n=int(data['n']);u=int(data['u']);word=data['word']
    H=(4*n-2)//3;g=len(word)
    odd,shortcut=actual_return(n,u,word);rows=affine_rows(word)
    E,B=rows[-1];Q=F(B,3**g)
    assert (g,E)==(121,192) and u==H
    source_residue=(((1<<E)-B)*pow(3**g,-1,1<<(E+1)))%(1<<(E+1))
    assert source_residue==u and (H-n)<1<<(E+1)
    counts=profile_upper(n);Pstar=counts['Pstar']
    assert Pstar==243760439224954652518
    budget=5+F(n,100000*Pstar)
    L=n.bit_length()-1;m=n.bit_length()
    phases=[F(Bi,3**i) for i,(Ei,Bi) in enumerate(rows)]
    starts=[0]+[i+1 for i,e in enumerate(word[:-1]) if e>=2]
    total_runs=len(starts);core=[];Rmass=Wmass=F(0)
    for ordinal,i in enumerate(starts):
        if i==0:continue
        state=odd[i];ell=state.bit_length()-1;t=ell-L
        J=(1<<ell)//(2000*Pstar*(t+1)*(t+2))
        next_start=starts[ordinal+1] if ordinal+1<total_runs else g
        run_length=next_start-i;beta=1-F(2,3)**run_length
        endpoint_position=rows[i][0]+ell
        interior=endpoint_position<E
        endpoint=shortcut[endpoint_position] if interior else None
        included=(H<state<1<<(64*m) and interior and 64*endpoint>state
                  and phases[i]>budget and Q-phases[i]>budget
                  and ordinal>J and total_runs-ordinal>J)
        if included:
            Rmass+=F(1,state);Wmass+=beta/state
            core.append({'odd_index':i,'state':str(state),'phase_before':str(phases[i]),
                         'phase_after':str(Q-phases[i]),'J':J,
                         'r_minus':ordinal,'r_plus':total_runs-ordinal,
                         'canonical_length':ell,'canonical_endpoint':str(endpoint),
                         'run_odd_inputs':run_length,'beta':str(beta)})
    assert [r['odd_index'] for r in core]==[21,23,24,26,28,30,31,33,35]
    assert 0<Wmass<=Rmass
    assert Wmass<=(Q-2*budget)/(u+budget)+F(1,H+1)
    charge=(1+Q/u)*(1+F(5,odd[-1]))/(1+F(5,u))-1
    assert charge>0
    n_high=906694364710971881029631;H_high=(4*n_high-2)//3
    assert n_high>=n and n_high&1 and n_high<=min(u,odd[-1])
    assert H_high<min(odd[1:-1])
    assert (H_high-n_high).bit_length()==counts['k']
    assert H_high.bit_length()==H.bit_length()==80
    assert n_high.bit_length()==n.bit_length()==80
    plateau_checks=0
    for length in range(3,counts['k']+1):
        Dshort=1<<length
        for odd_count in range(2,length):
            Ashort=3**odd_count
            if 4*Ashort>3*Dshort and 3*Ashort<4*Dshort:
                assert (4*Ashort-3*Dshort)*n+counts['k']*Dshort-4*Ashort>0
                assert (4*Dshort-3*Ashort)*n>4*Dshort
            elif 4*Ashort<=3*Dshort:
                assert (3*Dshort-4*Ashort)*n>=counts['k']*Dshort
            else:assert 3*Ashort>=4*Dshort
            plateau_checks+=1
    assert profile_upper(n_high)==counts
    upper_budget=5+F(n_high,100000*Pstar)
    assert all(F(row['phase_before'])>upper_budget and F(row['phase_after'])>upper_budget for row in core)
    threshold_choices=(n_high-n)//2+1
    assert threshold_choices==5321822482652343082370
    return {'seed_sha256':sha256(raw).hexdigest(),'n':str(n),'u':str(u),
            'endpoint':str(odd[-1]),'g':g,'E':E,'Q':str(Q),
            'least_source_verified':True,'exact_profile_upper':counts,
            'phase_budget':str(budget),'core_rows':core,
            'core_R':str(Rmass),'core_W':str(Wmass),
            'core_R_display_only':float(Rmass),'core_W_display_only':float(Wmass),
            'positive_charge':str(charge),
            'threshold_interval':{'first_odd':str(n),'last_odd':str(n_high),
                'odd_threshold_choices':str(threshold_choices),'exact_endpoint_window_comparisons':plateau_checks,
                'same_nine_core_starts':True,'scope':'Threshold choices for one fixed trajectory, not different source trajectories.'},
            'scope':'One fully compatible nonempty-core return, far below either proposed aggregate target; no census was rerun.'}


def supplied_dependencies(certificate_path,seed_path):
    raw=certificate_path.read_bytes();cert=json.loads(raw)
    assert cert['checks_passed'] is True
    finite=cert['finite_source_code_bounds']
    assert finite['finite_width_cases']==186 and finite['worst_width_exponent']==71
    assert cert['constants']['analytic_tail_complement_bound']=='67497/500000'
    assert F(47,30)*F(51,4700)==F(17,1000)
    assert F(151,1000)+F(17,1000)==F(21,125)
    assert 3000**22<1<<256 and 3**39<1<<62 and 4*193**39<200**39
    assert cert['saved_path_controls']['sha256']==sha256(seed_path.read_bytes()).hexdigest()
    return {'canonical_source_count_certificate':certificate_path.name,
            'certificate_sha256':sha256(raw).hexdigest(),
            'compact_seed_file':seed_path.name,'seed_sha256':sha256(seed_path.read_bytes()).hexdigest(),
            'status':'The exact original two K169 dependencies are supplied; the old DP is not rerun here.'}


def weighted_uniform_complement(certificate_path):
    inherited=json.loads(certificate_path.read_bytes())
    product_coefficient=F(61,50);C=F(488,375);rho=F(1,1000);beta0=F(1,100000)
    t=(A-1)/(A+1);log_lower=2*(t+t**3/3)
    assert t==F(15,79) and log_lower==F(189480,493039)
    assert product_coefficient*log_lower-(A-1)==F(8571,78886240)>0
    assert C==product_coefficient/(1-F(4,64))
    maximum=F(0);worst=None;digest_rows=[]
    rows=inherited['finite_source_code_bounds']['rows']
    assert [r['width_exponent'] for r in rows]==list(range(70,256))
    for row in rows:
        k=row['width_exponent'];n=int(row['smallest_odd_threshold']);P=int(row['P_upper'])
        assert n==max((1<<71)+1,3*(1<<(k-1))+3)
        L=n.bit_length()-1
        tau=F(5*(L+1),27*(1<<(L-1)))
        bound=C*(P*tau+F(11*P,n)+F(9*P,1024*n)+F(214*P,7*n*n)
                 +rho+2*beta0)+A*F(5*P,4*n)
        assert bound<F(59,1000)
        digest_rows.append([k,str(n),str(P),str(bound)])
        if bound>maximum:maximum=bound;worst=k
    assert worst==71
    analytic_coefficient=C*(F(640,9)+11+F(9,1024)+1)+5*A/4
    assert analytic_coefficient==F(23760569,216000)<120
    assert 3000**22<1<<256
    tail=F(120,3000)+C*(rho+2*beta0)
    assert tail==F(32287,781250)<F(59,1000)
    assert C*F(327,3904)+F(59,1000)==F(21,125)
    return {'inherited_rows_used':186,'source_code_DP_rerun':False,
            'new_complement_values_recomputed':186,
            'ordered_exact_rows_sha256':sha256(json.dumps(digest_rows,separators=(',',':')).encode()).hexdigest(),
            'worst_width':worst,'maximum':str(maximum),'display_only':float(maximum),
            'margin_below_59_over_1000':str(F(59,1000)-maximum),
            'analytic_coefficient':str(analytic_coefficient),'analytic_tail':str(tail),
            'product_coefficient':'61/50','logarithm_lower_bound':str(log_lower),
            'absorption_coefficient':'488/375','uniform_complement':'59/1000',
            'sufficient_weighted_or_unweighted_core_target':'327/3904',
            'scope':'This proves the complementary numerical allocation using the previously audited count theorem; it does not bound the central moment.'}


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dependencies',type=Path,default=HERE/'audit_dependencies')
    parser.add_argument('--output',type=Path,default=HERE/'eight_note_horizon_audit_certificate.json')
    args=parser.parse_args()
    seed=args.dependencies/'incoming_eleven_saved_groups.json'
    cert=args.dependencies/'bandwidth_uniform_complement_certificate.json'
    result={'status':'PASS','horizon':horizon_table(),'crossing_controls':crossing_controls(),
            'residue_filter':residue_filter(),'weighted_runs':run_weight_controls(seed),
            'mechanical_phase':mechanical_phase_control(),
            'nonempty_core':nonempty_core_control(args.dependencies/'nonempty_core_seed.json'),
            'weighted_uniform_complement':weighted_uniform_complement(cert),
            'supplied_K169_dependencies':supplied_dependencies(cert,seed),
            'scope':['No broad trajectory or inverse-cylinder census was rerun.',
                     'The K167/K168 finite-base evidence remains source-reported.',
                     'No unrestricted central bound or cycle exclusion is claimed.']}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','horizon':4096,'saved_paths':result['weighted_runs']['saved_paths'],
                      'new_phase':result['mechanical_phase']['phase_display_only'],
                      'certificate':str(args.output)},indent=2))


if __name__=='__main__':main()
