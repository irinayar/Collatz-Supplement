#!/usr/bin/env python3
"""Exact checks for weighted-run compensation and the 59/1000 complement.

No new trajectory census.  Replays the saved 23-path family and one supplied
nonempty-core witness, and reconstructs the 186 finite necessary-code bounds.
The remaining central moment is not proved by this certificate.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")

HERE = Path(__file__).resolve().parent
A, K, C, THETA = Q(47, 32), Q(61, 50), Q(488, 375), Q(1, 64)
RHO, BETA = Q(1, 1000), Q(1, 100000)
LIMIT = Q(59, 1000)
N0 = (1 << 71)+1
SCALE = 1 << 160


def enc(q: Q) -> dict:
    value = q.numerator*SCALE
    lo, hi = value//q.denominator, -((-value)//q.denominator)
    assert Q(lo, SCALE) <= q <= Q(hi, SCALE)
    return {"lower_units": str(lo), "upper_units": str(hi),
            "denominator": str(SCALE), "display_only": float(q)}


def ceil_div(a: int, b: int) -> int:
    return -((-a)//b)


def profile_upper(n: int) -> int:
    """Previously proved exact n-dependent new/old code minimum."""
    H = (4*n-2)//3
    k = max(2, (H-n).bit_length())
    row, short = {2: 1}, 0
    powers3 = [3**r for r in range(k+1)]
    powersn = [n**r for r in range(k+1)]
    powers3n1 = [(3*n+1)**r for r in range(k+1)]
    for j in range(3, k+1):
        short += sum(c for r, c in row.items()
                     if (3*n-k)*(1 << j) < 3*H*powers3[r]
                     and n*powers3[r] < H*(1 << j))
        nxt = {}
        for r, c in row.items():
            for bit in (0, 1):
                rr = r+bit
                if (1 << j)*powersn[rr] < powers3n1[rr]:
                    nxt[rr] = nxt.get(rr, 0)+c
        row = nxt
    new = sum(row.values())+short
    old = {2: 1}
    for j in range(3, H.bit_length()+1):
        nxt = {}
        for r, c in old.items():
            for bit in (0, 1):
                rr = r+bit
                if 3**rr > 1 << (j-1):
                    nxt[rr] = nxt.get(rr, 0)+c
        old = nxt
    return min(new, 2*sum(old.values()))


def constants_and_finite_count(old_certificate: Path) -> dict:
    previous = json.loads(old_certificate.read_bytes())
    expected = {r["width_exponent"]: int(r["P_upper"])
                for r in previous["finite_source_code_bounds"]["rows"]}
    for s in range(1, 513):
        beta = 1-Q(2, 3)**s
        assert Q(1, 3) <= beta < 1
        assert beta <= Q(5*(s+1), 27)
        assert (beta == Q(5*(s+1), 27)) == (s == 2)
    # The proof extends the s=2 equality using the decreasing increment.
    assert Q(1, 3)*Q(2, 3)**2 == Q(4, 27) < Q(5, 27)
    t = (A-1)/(A+1)
    log_lower = 2*(t+t**3/3)
    assert t == Q(15, 79) and log_lower == Q(189480, 493039)
    assert K*log_lower-(A-1) == Q(8571, 78886240) > 0
    assert K/(1-4*THETA) == C
    assert C*Q(327, 3904) == Q(109, 1000)
    assert LIMIT+Q(109, 1000) == Q(21, 125)

    row, short = {2: 1}, 0
    rows, maximum, worst = [], Q(0), None
    for k in range(3, 256):
        short += sum(c for r, c in row.items()
                     if 4*3**r > 3*(1 << k) and 3*3**r < 4*(1 << k))
        nxt = {}
        for r, c in row.items():
            for bit in (0, 1):
                rr = r+bit
                if 3**rr > 1 << k:
                    nxt[rr] = nxt.get(rr, 0)+c
        row = nxt
        if k < 70:
            continue
        P = sum(row.values())+short
        assert P == expected[k]
        n = max(N0, 3*(1 << (k-1))+3)
        L = n.bit_length()-1
        tau = Q(5*(L+1), 27*(1 << (L-1)))
        bound = C*(P*tau+Q(11*P, n)+Q(9*P, 1024*n)
                   +Q(214*P, 7*n*n)+RHO+2*BETA)+A*Q(5*P, 4*n)
        assert bound < LIMIT
        if bound > maximum:
            maximum, worst = bound, k
        rows.append({"k": k, "minimum_odd_n": str(n), "P_upper": str(P),
                     "weighted_terminal_bound_per_profile": str(tau),
                     "complement": enc(bound)})
    assert len(rows) == 186 and worst == 71
    # Exact inherited power and new analytic-tail comparisons.
    assert 2**180 < 3**33*5**55
    assert 3000**22 < 2**256
    base = C*(Q(640, 9)+11+Q(9, 1024)+1)+A*Q(5, 4)
    assert base == Q(23760569, 216000) < 120
    tail = Q(120, 3000)+C*(RHO+2*BETA)
    assert tail == Q(32287, 781250) < LIMIT
    return {"old_certificate_sha256": hashlib.sha256(old_certificate.read_bytes()).hexdigest(),
            "source_code_counts_reconstructed": len(rows), "worst_width": worst,
            "maximum_complement": enc(maximum), "margin_to_59_over_1000": enc(LIMIT-maximum),
            "log_A_rational_lower": str(log_lower), "run_to_product_coefficient": str(K),
            "log_lower_certificate_margin": str(K*log_lower-(A-1)),
            "analytic_tail_base_constant": str(base), "analytic_tail_complement": str(tail),
            "remaining_weighted_or_unweighted_core_target": "327/3904", "rows": rows}


def replay(n: int, u: int, word: list[int]) -> dict:
    H, E, B = (4*n-2)//3, 0, 0
    odd, shortcut, times, phases, affine = [u], [u], [0], [Q(0)], [(0, 0)]
    for i, e in enumerate(word):
        num = 3*odd[-1]+1
        assert (num & -num).bit_length()-1 == e
        odd.append(num >> e)
        for _ in range(e):
            x = shortcut[-1]
            shortcut.append((3*x+1)//2 if x & 1 else x//2)
        assert shortcut[-1] == odd[-1]
        B = 3*B+(1 << E)
        E += e
        times.append(E)
        affine.append((E, B))
        phases.append(Q(B, 3**(i+1)))
    assert n <= u <= H and n <= odd[-1] <= H
    assert all(x > H for x in odd[1:-1])
    assert len(set(shortcut[:-1])) == E
    assert word[0] == 1 and word[-1] >= 2
    G = Q((1 << E)*odd[-1], 3**len(word)*u)
    assert G == 1+phases[-1]/u and G < A
    # Full least-source interval, not merely a prefix representative.
    lo = max(n, ceil_div((1 << E)*n-B, 3**len(word)))
    for i, (Ei, Bi) in enumerate(affine[1:-1], 1):
        lo = max(lo, ((1 << Ei)*H-Bi)//3**i+1)
    hi = min(H, ((1 << E)*H-B)//3**len(word))
    modulus = 1 << (E+1)
    residue = (((1 << E)-B)*pow(3**len(word), -1, modulus)) % modulus
    least = residue+ceil_div(lo-residue, modulus)*modulus
    assert least == u and least <= hi
    starts = [0]+[i+1 for i, e in enumerate(word[:-1]) if e >= 2]
    runs = []
    for r, (i, stop) in enumerate(zip(starts, starts[1:]+[len(word)])):
        s, a, b = stop-i, odd[i], odd[stop]
        assert word[stop-1] >= 2 and all(e == 1 for e in word[i:stop-1])
        beta = 1-Q(2, 3)**s
        delta = beta/a
        run_G = Q((1 << (times[stop]-times[i]))*b, 3**s*a)
        assert run_G == 1+delta
        assert phases[stop]-phases[i] == (u+phases[i])*delta
        odd_mass = sum((Q(1, x) for x in odd[i:stop]), Q(0))
        assert odd_mass <= 3*delta
        assert beta <= Q(5, 27)*(times[stop]-times[i])
        j = a.bit_length()-1
        interior = times[i]+j < E
        endpoint = shortcut[times[i]+j] if interior else None
        runs.append({"i": i, "stop": stop, "s": s, "a": a, "beta": beta,
                     "delta": delta, "phase": phases[i], "next_phase": phases[stop],
                     "j": j, "time": times[i], "interior": interior, "endpoint": endpoint,
                     "before": r, "after": len(starts)-r})
    return {"n": n, "H": H, "u": u, "w": odd[-1], "E": E,
            "G": G, "Q": phases[-1], "odd": odd, "shortcut": shortcut, "runs": runs}


def family_checks(n: int, records: list[dict], expected_core: list[int] | None = None) -> dict:
    P, H = len(records), (4*n-2)//3
    L, m = n.bit_length()-1, (n-1).bit_length()
    Pstar = profile_upper(n)
    assert P <= Pstar
    phase_cut = 5+BETA*n/Pstar
    W = R = M = charge = Wfast = Wnc = Wterm = Wphase = Wreset = Whigh = Wcore = Rcore = Qmoment = Qspan_bound = Qmoment_count = Q(0)
    capacities, end_counts = Counter(), Counter()
    source_gap = Q(0)
    core_indices, terminal_shells, phase_checks = [], 0, 0
    for rec in records:
        u, w, path, runs = rec["u"], rec["w"], rec["shortcut"], rec["runs"]
        local_W = sum((r["delta"] for r in runs), Q(0))
        odd_mass = sum((Q(1, x) for x in path[:-1] if x & 1), Q(0))
        even_mass = sum((Q(1, x) for x in path[:-1] if not x & 1), Q(0))
        signed_odd = sum((Q(x+1, x*(3*x+1)) for x in path[:-1] if x & 1), Q(0))
        assert even_mass == signed_odd+Q(1, w)-Q(1, u)
        assert odd_mass <= 3*local_W
        assert odd_mass+even_mass <= (4+Q(2, 3*n+1))*local_W+Q(1, w)-Q(1, u)
        assert local_W <= rec["G"]-1 < K*local_W
        W += local_W
        R += sum((Q(1, r["a"]) for r in runs), Q(0))
        M += odd_mass+even_mass
        source_gap += Q(1, w)-Q(1, u)
        rho = rec["G"]*(1+Q(5, w))/(1+Q(5, u))
        charge += max(Q(0), rho-1)
        capacities.update(path[:-1])
        seen_endpoints, terminal_by_shell = set(), {}
        local_core = []
        for r in runs:
            a, ell, delta = r["a"], r["j"], r["delta"]
            if r["interior"]:
                endpoint = r["endpoint"]
                assert endpoint not in seen_endpoints
                seen_endpoints.add(endpoint)
                end_counts[endpoint] += 1
                if 64*endpoint <= a:
                    Wfast += delta
                    assert delta <= THETA/endpoint
                else:
                    Wnc += delta
            else:
                Wterm += delta
                terminal_by_shell[ell] = terminal_by_shell.get(ell, Q(0))+r["beta"]
            in_phase = r["phase"] <= phase_cut or rec["Q"]-r["phase"] <= phase_cut
            if in_phase:
                Wphase += delta
            t = ell-L
            J = (RHO*(1 << ell)/(2*Pstar*(t+1)*(t+2)))
            J = J.numerator//J.denominator
            in_reset = r["i"] > 0 and (r["before"] <= J or r["after"] <= J)
            if in_reset:
                Wreset += delta
            in_high = r["i"] > 0 and a >= 1 << (64*m)
            if in_high:
                Whigh += delta
            if (r["i"] > 0 and r["interior"] and 64*r["endpoint"] > a
                    and not in_phase and not in_reset and not in_high):
                Wcore += delta
                Rcore += Q(1, a)
                local_core.append(r)
                core_indices.append(r["i"])
        for j, beta_sum in terminal_by_shell.items():
            assert beta_sum <= Q(5*j, 27)
            terminal_shells += 1
        # Includes smaller phase cuts as nonvacuous controls on old saved paths.
        for B in (Q(0), Q(1, 2), Q(1), Q(5), phase_cut):
            early = sum((r["delta"] for r in runs if r["phase"] <= B), Q(0))
            late = sum((r["delta"] for r in runs if rec["Q"]-r["phase"] <= B), Q(0))
            assert early <= B/u+Q(1, n)
            assert late <= B/u
            central = [r for r in runs if r["phase"] > B and rec["Q"]-r["phase"] > B]
            mass = sum((r["delta"] for r in central), Q(0))
            bound = max(Q(0), rec["Q"]-2*B)/(u+B)
            if rec["Q"] > 2*B:
                bound += Q(1, H+1)
            assert mass <= bound
            phase_checks += 1
        if local_core:
            span = (local_core[-1]["phase"]-local_core[0]["phase"])/(u+local_core[0]["phase"])+local_core[-1]["delta"]
            assert sum((r["delta"] for r in local_core), Q(0)) <= span
            Qspan_bound += span
        Qmoment += max(Q(0), rec["Q"]-2*phase_cut)
        Qmoment_count += rec["Q"] > 2*phase_cut
    assert all(count <= capacities[v] for v, count in end_counts.items())
    assert M <= 4*W+Q(2, 3*n+1)*P*(A-1)+source_gap
    assert M < 4*W+Q(9*P, 16*n)
    assert Wfast <= THETA*M
    assert W == Wfast+Wnc+Wterm
    tau = Q(5*(L+1), 27*(1 << (L-1)))
    assert Wterm <= P*tau
    assert Wphase <= Q(11*P, n)+2*BETA*P/Pstar
    assert Wreset <= RHO*P/Pstar
    assert Whigh <= Q(214*P, 7*n*n)
    assert Wnc <= Wcore+Wphase+Wreset+Whigh
    assert Wcore <= Rcore
    assert Wcore <= Qspan_bound <= Qmoment/(n+phase_cut)+Qmoment_count/(H+1)
    remainder = C*(P*tau+Q(11*P, n)+Q(9*P, 1024*n)+Q(214*P, 7*n*n)+RHO+2*BETA)+A*Q(5*P, 4*n)
    assert charge <= C*Wcore+remainder
    if expected_core is not None:
        assert core_indices == expected_core and Wcore > 0
    return {"n": str(n), "profiles": P, "P_upper": str(Pstar), "phase_cut": str(phase_cut),
            "W": enc(W), "R": enc(R), "M": enc(M), "positive_charge": enc(charge),
            "weighted_fast": enc(Wfast), "weighted_terminal": enc(Wterm),
            "weighted_core": enc(Wcore), "unweighted_core": enc(Rcore),
            "core_indices": core_indices, "core_span_upper": enc(Qspan_bound),
            "phase_excess_moment": enc(Qmoment), "phase_excess_profiles": int(Qmoment_count),
            "terminal_shell_controls": terminal_shells, "phase_window_controls": phase_checks,
            "canonical_endpoint_capacities": len(end_counts)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--counts", type=Path, default=HERE/"audit_dependencies"/"bandwidth_uniform_complement_certificate.json")
    parser.add_argument("--seeds", type=Path, default=HERE/"audit_dependencies"/"incoming_eleven_saved_groups.json")
    parser.add_argument("--witness", type=Path, default=HERE/"audit_dependencies"/"nonempty_core_seed.json")
    parser.add_argument("--output", type=Path, default=HERE/"weighted_run_compensation_certificate.json")
    args = parser.parse_args()
    finite = constants_and_finite_count(args.counts)
    seed_raw, witness_raw = args.seeds.read_bytes(), args.witness.read_bytes()
    groups, witness = json.loads(seed_raw)["groups"], json.loads(witness_raw)
    checks = []
    for group in groups:
        n = int(group["n"])
        records = [replay(n, int(s["u"]), s["word"]) for s in group["sources"]]
        checks.append(family_checks(n, records))
    n = int(witness["n"])
    record = replay(n, int(witness["u"]), witness["word"])
    witness_check = family_checks(n, [record], [21, 23, 24, 26, 28, 30, 31, 33, 35])
    assert witness_check["P_upper"] == "243760439224954652518"
    result = {"scope": "Proved weighted-run compensation and uniform complement below59/1000; the central weighted moment remains unbounded at the target strength.",
              "finite_uniform_bound": finite, "saved_seed_sha256": hashlib.sha256(seed_raw).hexdigest(),
              "saved_families": checks, "nonempty_witness_sha256": hashlib.sha256(witness_raw).hexdigest(),
              "nonempty_core_witness": witness_check, "checks_passed": True}
    args.output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print("PASS: exact signed reciprocal compensation, run weights, terminal capacities, phase windows, and central moments.")
    print(f"PASS: {finite['source_code_counts_reconstructed']} finite width cases; maximum below59/1000 at width{finite['worst_width']}.")
    print(f"PASS: {sum(r['profiles'] for r in checks)} saved paths and one high-floor witness with {len(witness_check['core_indices'])} nonempty core starts.")
    print(f"Certificate: {args.output.resolve()}")


if __name__ == "__main__":
    main()
