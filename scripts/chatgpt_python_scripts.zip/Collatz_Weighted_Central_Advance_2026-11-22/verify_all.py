#!/usr/bin/env python3
"""Reproduce and cross-check the weighted-central research packet.

Run without -O. Uses the standard library and four independent/standalone
checks. No network, external service, or files outside this packet are needed.
Passing this program does not prove the remaining central inequality.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
CHECKS = [
    ("verify_weighted_run_compensation.py", "weighted_run_compensation_certificate.json"),
    ("verify_nonempty_central_family.py", "nonempty_central_family_certificate.json"),
    ("verify_first_crossing_structure.py", "first_crossing_structure_certificate.json"),
    ("verify_eight_note_horizon_audit.py", "eight_note_horizon_audit_certificate.json"),
]


def exact_interval(encoded: dict) -> tuple[F, F]:
    d = int(encoded["denominator"])
    return F(int(encoded["lower_units"]), d), F(int(encoded["upper_units"]), d)


def run_one(pair: tuple[str, str], temporary: Path) -> tuple[dict, dict]:
    script, certificate = pair
    output = temporary / certificate
    process = subprocess.run([sys.executable, str(HERE / script), "--output", str(output)],
                             cwd=HERE, capture_output=True, text=True, timeout=120)
    if process.returncode:
        raise RuntimeError(f"{script} failed:\n{process.stdout}\n{process.stderr}")
    raw = output.read_bytes()
    reference = (HERE / certificate).read_bytes()
    if raw != reference:
        raise AssertionError(f"{script}: regenerated certificate differs from supplied certificate")
    report = json.loads(raw)
    assert report.get("status") == "PASS" or report.get("checks_passed") is True
    return ({"script": script, "script_sha256": sha256((HERE / script).read_bytes()).hexdigest(),
             "certificate": certificate, "certificate_sha256": sha256(raw).hexdigest(),
             "byte_for_byte_reproduction": True}, report)


def main() -> None:
    if not __debug__:
        raise RuntimeError("Assertions are required. Do not use -O or -OO.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "master_verification_certificate.json")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="collatz_weighted_check_") as name:
        temporary = Path(name)
        with ThreadPoolExecutor(max_workers=4) as executor:
            outputs = list(executor.map(lambda pair: run_one(pair, temporary), CHECKS))
    receipts, reports = zip(*outputs)
    weighted, witness, structure, audit = reports
    finite = weighted["finite_uniform_bound"]
    independent = audit["weighted_uniform_complement"]
    maximum = F(independent["maximum"])
    low, high = exact_interval(finite["maximum_complement"])
    assert low <= maximum <= high < F(59, 1000)
    assert finite["worst_width"] == independent["worst_width"] == 71
    assert finite["source_code_counts_reconstructed"] == independent["new_complement_values_recomputed"] == 186
    assert F(finite["analytic_tail_complement"]) == F(independent["analytic_tail"]) == F(32287, 781250)
    assert F(488, 375) * F(327, 3904) + F(59, 1000) == F(21, 125)
    indices = [row["odd_index"] for row in witness["core"]]
    assert indices == weighted["nonempty_core_witness"]["core_indices"] == [21,23,24,26,28,30,31,33,35]
    core = audit["nonempty_core"]
    assert core["g"] == witness["g"] == 121 and core["E"] == witness["E"] == 192
    assert witness["source"] == core["u"] and witness["endpoint"] == core["endpoint"]
    assert witness["threshold_interval"]["odd_thresholds"] == core["threshold_interval"]["odd_threshold_choices"]
    assert structure["CST_conjecture_proved"] is False
    assert structure["no_crossing_sources_excluded"] is False
    assert structure["new_verification_horizon_claimed"] is False
    report = {
        "status": "PASS", "checks": list(receipts),
        "cross_checks": {"finite_widths": 186, "worst_width": 71,
                         "exact_maximum_complement": str(maximum),
                         "uniform_complement": "59/1000", "core_coefficient": "488/375",
                         "sufficient_core_target": "327/3904", "budget_if_target_proved": "21/125",
                         "core_witness_odd_steps": 121, "core_witness_shortcut_steps": 192,
                         "core_witness_retained_starts": indices,
                         "threshold_choices_for_one_trajectory": witness["threshold_interval"]["odd_thresholds"]},
        "scope": {"new_uniform_complement_proved_using_inherited_count_and_canonical_lemmas": True,
                  "central_bound_proved": False, "full_trajectory_cycle_exclusion_proved": False,
                  "infinite_CST_sources_excluded": False, "Collatz_conjecture_proved": False,
                  "unavailable_external_finite_base_scan_rerun": False},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("PASS: all four certificates reproduced byte-for-byte; independent results agree.")
    print("PASS: 186 width cases plus analytic tail; uniform complement <59/1000.")
    print("PASS: one genuine 121-odd-transition profile has nine central starts throughout its certified threshold interval.")
    print("OPEN: the uniform central target 327/3904, cycles, and infinite-CST sources.")
    print(f"Certificate: {args.output}")


if __name__ == "__main__":
    main()
