#!/usr/bin/env python3
"""An exact genuine least-source return with a nonempty central core.

The same word and nine core starts work at every odd threshold in the stated
large interval.  This verifies a parameter family, not a count of different
starting trajectories and not a counterexample to the proposed aggregate bound.
"""

from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Run without -O: exact assertions are required.")

SOURCE = 1194734292994222926486523
N_LOW = 896050719745667194864893
N_HIGH = 906694364710971881029631
EXPECTED_CORE = [21, 23, 24, 26, 28, 30, 31, 33, 35]


def ceildiv(a: int, b: int) -> int:
    return -((-a) // b)


def T(x: int) -> int:
    return (3 * x + 1) // 2 if x % 2 else x // 2


def encode(q: F) -> dict:
    return {"numerator": str(q.numerator), "denominator": str(q.denominator),
            "display_only": float(q)}


def construct_path() -> dict:
    # Mechanical proper prefix: its final cumulative exponent uses the floor.
    prefix_length = 46
    cum0 = [(3**i).bit_length() - 1 for i in range(prefix_length + 1)]
    prefix = [cum0[i + 1] - cum0[i] for i in range(prefix_length)]
    B = 0
    for i in range(prefix_length):
        B = 3 * B + (1 << cum0[i])
    period = 1 << (cum0[-1] + 1)
    residue = (((1 << cum0[-1]) - B) * pow(3**prefix_length, -1, period)) % period
    assert SOURCE == residue + 126 * period
    assert SOURCE % 8 == 3 and N_LOW == 3 * (SOURCE + 1) // 4

    states = [SOURCE]
    shortcut = [SOURCE]
    word, cum, numerators = [], [0], [0]
    for _ in range(200):
        z = 3 * states[-1] + 1
        e = (z & -z).bit_length() - 1
        word.append(e)
        numerators.append(3 * numerators[-1] + (1 << cum[-1]))
        cum.append(cum[-1] + e)
        for _ in range(e):
            shortcut.append(T(shortcut[-1]))
        states.append(z >> e)
        assert states[-1] == shortcut[-1] and states[-1] % 2
        if states[-1] <= SOURCE:
            break
    else:
        raise AssertionError("Specified witness did not complete in 200 odd steps")
    assert word[:prefix_length] == prefix
    assert len(word) == 121 and cum[-1] == 192
    assert states[-1] == 1026086522416072566002429
    assert min(states[1:-1]) == 1211034369283948566961147
    assert len(set(shortcut[:-1])) == 192
    assert len(set(states)) == len(states)
    assert (1 << cum[-1]) * states[-1] == 3**len(word) * SOURCE + numerators[-1]
    modulus = 1 << (cum[-1] + 1)
    complete_residue = (((1 << cum[-1]) - numerators[-1])
                        * pow(3**len(word), -1, modulus)) % modulus
    assert complete_residue == SOURCE < modulus

    # Verify that this particular word first coefficient-crosses at its end.
    odd_count = 0
    for j, x in enumerate(shortcut[:-1], 1):
        odd_count += x % 2
        if j < len(shortcut) - 1:
            assert 3**odd_count > 1 << j
        else:
            assert 3**odd_count < 1 << j
    phases = [F(b, 3**i) for i, b in enumerate(numerators)]
    assert phases[-1] > 13
    runs = []
    start = 0
    for end, e in enumerate(word, 1):
        if e >= 2:
            s = end - start
            beta = 1 - F(2, 3)**s
            run_product = F(1)
            for x in states[start:end]:
                run_product *= F(3 * x + 1, 3 * x)
            assert run_product == 1 + beta / states[start]
            assert phases[end] - phases[start] == (SOURCE + phases[start]) * beta / states[start]
            runs.append({"start": start, "end": end, "length": s, "beta": beta})
            start = end
    assert start == len(word) and len(runs) == 54
    G = F(1)
    for x in states[:-1]:
        G *= F(3 * x + 1, 3 * x)
    assert G == 1 + phases[-1] / SOURCE < F(47, 32)
    rho = G * F(states[-1] + 5, states[-1]) * F(SOURCE, SOURCE + 5)
    assert rho > 1
    return dict(word=word, states=states, shortcut=shortcut, cumulative=cum,
                numerators=numerators, phases=phases, runs=runs, G=G, rho=rho,
                source_modulus=modulus, prefix_residue=residue, prefix_period=period)


def pure_count_tables(k: int, m: int) -> tuple[int, int, int]:
    proper_rows = {2: {2: 1}}
    for length in range(3, k + 1):
        previous = proper_rows[length - 1]
        next_row = {}
        for odd in range(2, length + 1):
            count = previous.get(odd, 0) + previous.get(odd - 1, 0)
            if count and 3**odd > 1 << length:
                next_row[odd] = count
        proper_rows[length] = next_row
    long = sum(proper_rows[k].values())
    short = sum(count for E in range(3, k + 1)
                for g, count in proper_rows[E - 1].items()
                if 4 * 3**g > 3 * (1 << E) and 3 * 3**g < 4 * (1 << E))
    old = {2: 1}
    for length in range(3, m + 1):
        old = {g: old.get(g, 0) + old.get(g - 1, 0)
               for g in range(2, length + 1)
               if 3**g > 1 << (length - 1)}
    return long, short, 2 * sum(old.values())


def certify_count_plateau() -> dict:
    H_low, H_high = (4 * N_LOW - 2) // 3, (4 * N_HIGH - 2) // 3
    assert H_low == SOURCE and H_high == 1208925819614629174706174
    k = (H_low - N_LOW).bit_length()
    assert (H_high - N_HIGH).bit_length() == k == 78
    assert H_low.bit_length() == H_high.bit_length() == 80
    assert N_LOW.bit_length() == N_HIGH.bit_length() == 80
    # These dimensions stay fixed between the endpoints by monotonicity.
    proper_comparisons = endpoint_comparisons = 0
    for j in range(1, k + 1):
        r = 0
        while 3**(r + 1) <= 1 << j:
            r += 1
        assert (1 << j) * (3 * N_LOW - r) >= 3 * N_LOW * 3**r
        proper_comparisons += 1
    # The n-dependent endpoint tests are uniformly equivalent to the pure
    # strict 3/4 < 3^g/2^E < 4/3 window.  Use 3H >= 4n-4 and H<4n/3.
    for E in range(3, k + 1):
        D = 1 << E
        for g in range(2, E):
            A = 3**g
            if 4 * A > 3 * D and 3 * A < 4 * D:
                assert (4 * A - 3 * D) * N_LOW + k * D - 4 * A > 0
                assert (4 * D - 3 * A) * N_LOW > 4 * D
            elif 4 * A <= 3 * D:
                assert (3 * D - 4 * A) * N_LOW >= k * D
            else:
                assert 3 * A >= 4 * D
            endpoint_comparisons += 1
    long, short, old = pure_count_tables(k, 80)
    P = min(long + short, old)
    assert P == 243760439224954652518
    return {"k": k, "m": 80, "L": 79, "long_codes": long,
            "short_codes": short, "old_code_upper": old, "Pstar": P,
            "proper_barrier_comparisons": proper_comparisons,
            "endpoint_window_comparisons": endpoint_comparisons}


def core_at(n: int, d: dict, P: int) -> list[dict]:
    H, L, m = (4 * n - 2) // 3, n.bit_length() - 1, n.bit_length()
    assert n <= SOURCE <= H and n <= d["states"][-1] <= H
    assert min(d["states"][1:-1]) > H
    Bcut = F(5) + F(n, 100000 * P)
    total_resets = len(d["runs"])
    result = []
    for ordinal, run in enumerate(d["runs"]):
        i = run["start"]
        if i == 0:
            continue
        a = d["states"][i]
        ell, position = a.bit_length() - 1, d["cumulative"][i]
        shell = ell - L
        J = (1 << ell) // (2000 * P * (shell + 1) * (shell + 2))
        if not (H < a < 1 << (64 * m)):
            continue
        if position + ell >= d["cumulative"][-1]:
            continue
        endpoint = d["shortcut"][position + ell]
        if not (64 * endpoint > a):
            continue
        if not (d["phases"][i] > Bcut and d["phases"][-1] - d["phases"][i] > Bcut):
            continue
        if not (ordinal > J and total_resets - ordinal > J):
            continue
        result.append({"odd_index": i, "state": str(a), "run_length": run["length"],
                       "beta": str(run["beta"]), "shortcut_index": position,
                       "canonical_length": ell, "canonical_endpoint": str(endpoint),
                       "phase_before": str(d["phases"][i]),
                       "phase_after": str(d["phases"][-1] - d["phases"][i]),
                       "r_minus": ordinal, "r_plus": total_resets - ordinal,
                       "J": J, "shell": shell})
    assert [row["odd_index"] for row in result] == EXPECTED_CORE
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("nonempty_central_family_certificate.json"))
    args = parser.parse_args()
    d = construct_path()
    counts = certify_count_plateau()
    assert N_LOW % 2 == N_HIGH % 2 == 1 and N_LOW >= 1 << 71
    assert N_HIGH <= min(d["states"][-1], (3 * min(d["states"][1:-1]) + 1) // 4)
    low_core, high_core = core_at(N_LOW, d, counts["Pstar"]), core_at(N_HIGH, d, counts["Pstar"])
    assert low_core == high_core
    # All conditions except phase are constant on this interval; Bcut grows.
    # Equal endpoint core sets therefore prove the same core set throughout.
    Rcore = sum((F(1, int(x["state"])) for x in low_core), F(0))
    Wcore = sum((F(x["beta"]) / int(x["state"]) for x in low_core), F(0))
    Wtotal = sum((run["beta"] / d["states"][run["start"]] for run in d["runs"]), F(0))
    assert 0 < Wcore <= Rcore < F(51, 4700) < F(291, 4700)
    assert Wtotal <= d["G"] - 1
    report = {
        "status": "PASS", "arithmetic": "integer and Fraction; decimals display only",
        "source": str(SOURCE), "endpoint": str(d["states"][-1]),
        "threshold_interval": {"first_odd": str(N_LOW), "last_odd": str(N_HIGH),
                               "odd_thresholds": str((N_HIGH - N_LOW) // 2 + 1)},
        "g": 121, "E": 192, "reset_count": 54,
        "word": d["word"], "odd_states": [str(x) for x in d["states"]],
        "phase": encode(d["phases"][-1]),
        "phase_cut_at_lower": encode(F(5) + F(N_LOW, 100000 * counts["Pstar"])),
        "phase_cut_at_upper": encode(F(5) + F(N_HIGH, 100000 * counts["Pstar"])),
        "source_modulus": str(d["source_modulus"]),
        "least_positive_complete_cylinder_representative": True,
        "first_coefficient_crossing_and_descent": 192,
        "profile_count_plateau": counts,
        "core": low_core, "Rcore": encode(Rcore), "Wcore": encode(Wcore),
        "total_run_weight": encode(Wtotal), "normalized_charge": encode(d["rho"] - 1),
        "construction": {"mechanical_prefix_odd_steps": 46,
                         "prefix_residue": str(d["prefix_residue"]),
                         "prefix_period": str(d["prefix_period"]), "lift": 126},
        "scope": ["One fixed genuine least-source profile over a threshold interval.",
                  "Nine actual current-core starts; not an empty-core control.",
                  "Thresholds are different problems, not different source trajectories.",
                  "No aggregate-bound counterexample or new convergence count is claimed."],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "odd_steps": 121, "shortcut_steps": 192,
                      "core_starts": len(low_core),
                      "odd_thresholds": report["threshold_interval"]["odd_thresholds"],
                      "Q_display_only": float(d["phases"][-1]),
                      "Rcore_display_only": float(Rcore)}))


if __name__ == "__main__":
    main()
