#!/usr/bin/env python3
"""Exact controls for contracting-chain payments and copied suffix flow.

Uniform statements depend on the written proof and the inherited forced-prefix
and source-capacity theorems. No full residual or global forcing is asserted.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
CSTAR = F(620751769493359576,1180591620717411303425)
R = F(256,243)


def enc(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [enc(v) for v in x]
    return x


def v2(x):
    assert x>0
    return (x&-x).bit_length()-1


def chain_control(k,q,lift):
    assert 1<=k<=q<=2*k-1
    modulus=2**(8*q+1)
    residue=211*pow(13,-1,modulus)%modulus
    a=residue+lift*modulus
    assert 13*a>modulus
    n=2**71+1
    # These are high-floor actual prefixes, not asserted first-return profiles.
    if a<=n:
        a+=((n-a)//modulus+1)*modulus
    start=a;states=[a];bits=[];run_inputs=[];score=F(0)
    kappa=F(n-1,n+1)
    for j in range(q):
        run_inputs.append(a)
        before=a
        for e in [1,1,1,1,4]:
            assert v2(3*a+1)==e
            x=(3*a+1)//2;bits.append(1);states.append(x)
            for _ in range(e-1):
                assert x%2==0
                x//=2;bits.append(0);states.append(x)
            assert x&1
            a=x
        assert a==(243*before+211)//256
        assert F(a)-F(211,13)==F(243,256)*(F(before)-F(211,13))
        delta=F(211,243*before)
        f=F(1,before)-F(1,a)
        t=kappa*delta+f
        c=max(F(0),-f-delta/15)
        assert c==0
        if a>=n:
            assert max(t,0)<=F(22,27*before)
        score+=max(t,F(0))
        assert before>=F(start)*F(243,256)**j
    assert bits==[int(c) for c in '11111000'*q]
    assert states[-1]&1
    assert start%2**(8*k+1)==211*pow(13,-1,2**(8*k+1))%2**(8*k+1)
    assert all(i+(x.bit_length()-1)<=i+1+(y.bit_length()-1)
               for i,(x,y) in enumerate(zip(states,states[1:])))
    if a>=n:
        K=F(198,13)*(R**q-1)
        assert score<=K/start
    return {'k':k,'q':q,'start_bits':start.bit_length(),
            'exact_terminal_odd_bit':True,'canonical_time_monotone':True,
            'nonempty_original_core_asserted':False}


def partition(N,k):
    assert N>=k>=1
    a,b=divmod(N,k)
    return [k]*(a-1)+[k+b]


def envelopes():
    results={}
    for shift,ceiling in [(32,F(122,10**9)),(40,F(542,10**12))]:
        rows=[]
        for m in range(72,273):
            k=(m+shift+7)//8
            K=F(198,13)*(R**(2*k-1)-1)
            envelope=F(4,3)*CSTAR*2**m*K*(50*k+103)*F(1,2**(8*k+1))
            assert envelope<ceiling
            rows.append((envelope,m,k))
        maximum=max(rows)
        assert maximum[1:]==(272,(272+shift)//8)
        results[str(shift)]={'height_cases':len(rows),'threshold_range':
            [(72+shift+7)//8,(272+shift+7)//8],
            'maximum':maximum,'rounded_uniform_envelope':ceiling}
    return results


def actual_forest():
    spec=importlib.util.spec_from_file_location('saved_original_replay',HERE/'fixture/original_replay.py')
    rp=importlib.util.module_from_spec(spec);spec.loader.exec_module(rp)
    data=json.loads((HERE/'fixture/original_core_profile.json').read_text())
    n=int(data['n']);u=int(data['u']);P=8780738570161207464047659560356896525
    v=473569587534005792343618380642931659580735
    profiles=[rp.replay(n,u,data['word'],P),
              rp.replay(n,v,[1,1,1,1,1,3,1,3]+data['word'][1:],P)]
    assert [p['core_count'] for p in profiles]==[31,33]
    M=Counter();N=Counter();J=Counter();terminal=Counter();activation=Counter()
    edges={};credits=F(0);actual=F(0)
    for p in profiles:
        gate_index=next(i for i,r in enumerate(p['runs']) if r['phase']<=1<r['phase_end'])
        gate=p['runs'][gate_index]['b']
        assert gate>p['H']
        assert all(not r['core'] for r in p['runs'][:gate_index+1])
        credits+=sum((r['c'] for r in p['runs'][:gate_index+1]),F(0))
        J[gate]+=1
        previous=0
        for r in p['runs'][gate_index+1:]:
            a,b=r['a'],r['b'];I=int(r['core'])
            M[a]+=1;N[a]+=I;activation[a]+=I-previous;previous=I
            if a in edges:
                assert all(edges[a][key]==r[key] for key in ['b','delta','t','c'])
            else:edges[a]=r
            actual+=r['t'] if I else -r['c']
        terminal[p['w']]+=1
        activation[p['w']]-=previous
    inflow=Counter();core_inflow=Counter()
    for a,r in edges.items():
        inflow[r['b']]+=M[a];core_inflow[r['b']]+=N[a]
    for a in edges:
        assert M[a]==J[a]+inflow[a]
        assert N[a]-core_inflow[a]==activation[a]
    for w,t in terminal.items():
        assert inflow[w]==t
        assert -core_inflow[w]==activation[w]
    fsum=sum((M[a]*(F(1,a)-F(1,r['b'])) for a,r in edges.items()),F(0))
    endpoints=sum((F(v,a) for a,v in J.items()),F(0))-sum((F(v,a) for a,v in terminal.items()),F(0))
    assert fsum==endpoints
    correction=F(n-1,n+1)*sum((N[a]*r['delta'] for a,r in edges.items()),F(0))
    boundary=sum((F(v,a) for a,v in activation.items()),F(0))
    off=sum(((M[a]-N[a])*r['c'] for a,r in edges.items()),F(0))
    assert actual==correction+boundary-off
    full=sum((p['signed_score'] for p in profiles),F(0))
    assert full==-credits+actual
    return {'profiles':len(profiles),'physical_complete_run_vertices':len(edges),
            'copied_suffix_runs':sum(M.values()),'core_copies':sum(N.values()),
            'max_later_multiplicity':max(M.values()),
            'unit_gate_injection_states':[str(a) for a in J],
            'scaled_correction':n*correction,'scaled_activation_flux':n*boundary,
            'scaled_off_core_credit':n*off,'scaled_suffix_score':n*actual,
            'scaled_full_score':n*full,'all_flow_identities_exact':True}


def main():
    if not __debug__:raise SystemExit('Run without -O or -OO.')
    assert F(256,243)<1+F(211,3645)
    controls=[chain_control(k,q,lift) for k,q,lift in
              [(1,1,2**80),(2,3,2**80),(3,5,2**80),
               (13,13,0),(13,25,0),(38,75,0),(39,77,0)]]
    partitions=0
    for k in range(1,50):
        for N in range(k,10*k+3):
            lengths=partition(N,k)
            assert sum(lengths)==N and all(k<=q<=2*k-1 for q in lengths)
            partitions+=1
    env=envelopes();forest=actual_forest()
    result={'status':'PASS','actual_C_prefix_controls':controls,
            'disjoint_partition_controls':partitions,'envelopes':env,
            'actual_copied_core_forest':forest,
            'new_nonempty_core_C_chain_exhibited':False,
            'inherited_forced_prefix_certificate_recomputed':False,
            'full_signed_residual_proved':False,'global_forcing_proved':False}
    (HERE/'contracting_chain_and_forest_certificate.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    print(json.dumps({'status':'PASS','height_cases':201,
          'C_chain_envelope':'122/10^9','optional_longer_threshold':'542/10^12',
          'actual_prefix_controls':len(controls),'partition_controls':partitions,
          'actual_core_copies':forest['core_copies'],
          'forest_flow_exact':True,'global_bound_proved':False},indent=2))


if __name__=='__main__':main()
