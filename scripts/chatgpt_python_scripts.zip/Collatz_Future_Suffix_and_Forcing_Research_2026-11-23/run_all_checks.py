#!/usr/bin/env python3
"""Run the six new exact checkers from a relocated or extracted release.

The nested historical archive is preserved unchanged and is not re-executed.
The mathematical notes supply the infinite-quantifier arguments and identify
the inherited dependencies. This runner does not claim a Collatz proof.
"""
from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CHECKS = [
    "residual/verify_initial_rc_aggregate.py",
    "residual/verify_initial_six_type_aggregate.py",
    "transport/verify_contracting_chain_and_forest.py",
    "transport/verify_positive_alphabet_obstruction.py",
    "forcing/verify_all_odd_forcing_barrier.py",
    "verify_independent_audit.py",
]


def main():
    if not __debug__ or os.environ.get("PYTHONOPTIMIZE"):
        raise SystemExit("Run without -O, -OO, or PYTHONOPTIMIZE: assertions are proof checks.")
    results = []
    for relative in CHECKS:
        start = time.monotonic()
        outcome = subprocess.run([sys.executable,"-B",str(ROOT/relative)],
                                 cwd=ROOT,text=True,capture_output=True)
        result = {"checker":relative,"exit_code":outcome.returncode,
                  "seconds":round(time.monotonic()-start,3)}
        try:
            result["result"] = json.loads(outcome.stdout)
        except json.JSONDecodeError:
            result["stdout"] = outcome.stdout
        if outcome.stderr:
            result["stderr"] = outcome.stderr
        results.append(result)
        print(json.dumps({"checker":relative,
                          "status":"PASS" if outcome.returncode==0 else "FAIL",
                          "seconds":result["seconds"]}),flush=True)
        if outcome.returncode:
            break
    passed = len(results)==len(CHECKS) and all(r["exit_code"]==0 for r in results)
    summary = {"status":"PASS" if passed else "FAIL",
               "checkers_run":len(results),"results":results,
               "scope":"Exact controls, reduced exhaustive phase certificate, and portable replay of new results.",
               "full_signed_future_suffix_bound_proved":False,
               "global_forcing_proved":False,
               "inherited_dependencies_recomputed":False}
    (ROOT/"Verification_Summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
