#!/usr/bin/env python3
"""Exact actual two-source coalescence with original nonempty cores.

Only a finite witness is certified. No uniform aggregate or convergence claim.
The original source-count recurrence is bundled unchanged and kept fixed.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('original_source_count',HERE/'original_source_count.py')
sc=importlib.util.module_from_spec(spec);spec.loader.exec_module(sc)

def v2(x):return (x&-x).bit_length()-1
def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def replay(n,u,word,P):
    H=(4*n-2)//3;bits=[];odd=[u];times=[0];shortcut=[u]
    for e in word:
        assert v2(3*odd[-1]+1)==e
        x=(3*odd[-1]+1)//2;bits.append(1);shortcut.append(x)
        for _ in range(e-1):
            assert x%2==0;x//=2;bits.append(0);shortcut.append(x)
        assert x%2;odd.append(x);times.append(len(bits))
    assert len(set(shortcut[:-1]))==len(shortcut)-1
    assert n>=2**71 and n%2 and n<=u<=H and n<=odd[-1]<=H
    assert all(x>H for x in odd[1:-1])
    # Direct sum (not numerator recurrence) independently reconstructs phases.
    phase=[F(0)];q=F(0)
    for i in range(len(word)):
        q+=F(2**times[i],3**(i+1));phase.append(q)
    E=len(bits);g=len(word);C=int(phase[-1]*3**g)
    assert 2**E*odd[-1]==3**g*u+C
    M=2**(E+1);residue=((2**E-C)*pow(3**g,-1,M))%M
    assert residue==u and 0<u<M and M>H-n
    # Entire source band contains just this residue: it is the least genuine source.
    assert u-M<n and u+M>H
    B=5+F(n,100000*P);kappa=F(n-1,n+1)
    spans=[];start=0
    for end,e in enumerate(word,1):
        if e>=2:spans.append((start,end,e));start=end
    assert start==g
    L=n.bit_length()-1;m=n.bit_length();runs=[]
    for k,(i,j,e) in enumerate(spans):
        a,b=odd[i],odd[j];s=j-i;delta=(1-F(2,3)**s)/a
        f=F(1,a)-F(1,b);t=kappa*delta+f;c=max(F(0),-f-delta/15)
        ell=a.bit_length()-1;layer=ell-L
        J=2**ell//(2000*P*(layer+1)*(layer+2))
        canonical=times[i]+ell
        core=(i>0 and H<a<2**(64*m) and canonical<E
              and 64*shortcut[canonical]>a and phase[i]>B
              and phase[-1]-phase[i]>B and k>J and len(spans)-k>J)
        runs.append({'ordinal':k,'start_odd':i,'end_odd':j,'a':a,'b':b,'s':s,'e':e,
                     'delta':delta,'t':t,'c':c,'core':core,'phase':phase[i],'phase_end':phase[j]})
    z=sum((r['t'] if r['core'] else -r['c'] for r in runs),F(0))
    gate=next(r for r in runs if r['phase']<=B<r['phase_end'])
    return {'n':n,'u':u,'w':odd[-1],'H':H,'Pstar':P,'g':g,'E':E,'modulus':M,
            'residue':residue,'word':word,'odd':odd,'runs':runs,'Q':phase[-1],'B':B,
            'core_count':sum(r['core'] for r in runs),'signed_score':z,
            'gate_odd_depth':gate['end_odd'],'gate_state':odd[gate['end_odd']]}

def main():
    if not __debug__:raise SystemExit('Run without -O')
    data=json.loads((HERE/'original_core_profile.json').read_text())
    n=int(data['n']);u=int(data['u']);v=473569587534005792343618380642931659580735
    prefix=[1,1,1,1,1,3,1,3];newword=prefix+data['word'][1:]
    P,_,_=sc.source_count(n)
    assert P==8780738570161207464047659560356896525
    a=replay(n,u,data['word'],P);b=replay(n,v,newword,P)
    assert a['odd'][1]==b['odd'][8]==758566910110012696183222703954656889284475
    assert a['odd'][1:]==b['odd'][8:]
    assert a['w']==b['w']==435233337021757997534559614113553093329423
    assert a['core_count']==31 and b['core_count']==33
    ar={(r['a'],r['b']):r for r in a['runs']}
    br={(r['a'],r['b']):r for r in b['runs']}
    common=[(ar[k],br[k]) for k in ar.keys()&br.keys() if ar[k]['core'] and br[k]['core']]
    assert len(common)==31
    assert sum(x['t']>0 for x,y in common)==23
    assert sum(x['t']<0 for x,y in common)==8
    assert all(x['t']==y['t'] and x['c']==y['c'] for x,y in common)
    common_signed=sum((x['t'] for x,y in common),F(0))
    common_positive=sum((max(F(0),x['t']) for x,y in common),F(0))
    common_negative=sum((min(F(0),x['t']) for x,y in common),F(0))
    assert common_signed>0 and common_positive>0 and common_negative<0
    assert a['signed_score']>0 and b['signed_score']>0
    # Source gate positions differ: this is a genuine common-core suffix collision,
    # not a claim that the two actual first gates are the same physical state.
    assert a['gate_state']!=b['gate_state']
    c_before_join=sum((r['c'] for r in b['runs'] if r['end_odd']<=8),F(0))
    assert c_before_join>0
    assert common_signed>30*c_before_join
    # Core-carrying words have their canonical horizon before the final time.
    for p in (a,b):
        assert all(p['E']>(r['a'].bit_length()-1) for r in p['runs'] if r['core'])
        assert p['modulus']>p['H']-n
    cert={'status':'PASS','scope':'two actual distinct least-source completed returns at one fixed threshold, with original core predicates and all multiplicities',
          'n':str(n),'H':str(a['H']),'Pstar':str(P),'sources':[str(u),str(v)],
          'common_state':str(a['odd'][1]),'incoming_odd_depths':[1,8],
          'incoming_shortcut_depths':[1,sum(prefix)],'common_terminal':str(a['w']),
          'odd_counts':[a['g'],b['g']],'shortcut_lengths':[a['E'],b['E']],
          'core_counts':[31,33],'shared_core_runs':31,'shared_positive_core_runs':23,'shared_negative_core_runs':8,
          'shared_run_types':sorted(set((x['s'],x['e']) for x,y in common)),
          'n_scaled_signed_scores':[n*a['signed_score'],n*b['signed_score']],
          'n_scaled_shared_signed_once':n*common_signed,
          'n_scaled_shared_positive_once':n*common_positive,
          'n_scaled_shared_negative_once':n*common_negative,
          'n_scaled_incoming_credit_second':n*c_before_join,
          'shared_signed_exceeds_thirty_times_incoming_credit':common_signed>30*c_before_join,
          'first_gate_states':[str(a['gate_state']),str(b['gate_state'])],
          'input_sha256':hashlib.sha256((HERE/'original_core_profile.json').read_bytes()).hexdigest(),
          'new_profile':{'n':str(n),'u':str(v),'word':newword},
          'nonclaims':['not a counterexample to the uniform aggregate','not a collision at one actual first gate','not an all-zero-entry-credit pair','not all shared positive terms are asserted unpaid by existing envelopes']}
    (HERE/'nonempty_core_coalescence_certificate.json').write_text(json.dumps(enc(cert),indent=2)+'\n')
    print(json.dumps({'status':'PASS','sources':2,'shared_core_runs':31,'shared_positive':23,'shared_negative':8,
                      'n_scaled_signed_scores':[float(n*a['signed_score']),float(n*b['signed_score'])],
                      'n_scaled_shared_signed_once':float(n*common_signed),
                      'n_scaled_incoming_credit_second':float(n*c_before_join)},indent=2))

if __name__=='__main__':main()
