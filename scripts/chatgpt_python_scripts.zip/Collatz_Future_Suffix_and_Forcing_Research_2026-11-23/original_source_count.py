"""Unchanged prescribed Pstar recurrence, copied from the prior fixture verifier.

Source: first_gate_release/fixture/verify_near_miss.py, source_count.
No subfamily-dependent recomputation or substitute source count is used.
"""
from collections import defaultdict

def source_count(n):
    H=(4*n-2)//3
    width_depth=(H-n).bit_length()
    row={2:1};short=0
    for depth in range(3,width_depth+1):
        short += sum(count for odds,count in row.items()
                     if (3*n-width_depth)*2**depth < 3*H*3**odds
                     and n*3**odds < H*2**depth)
        nxt=defaultdict(int)
        for odds,count in row.items():
            for bit in (0,1):
                r=odds+bit
                if 2**depth*n**r < (3*n+1)**r:
                    nxt[r] += count
        row=dict(nxt)
    bandwidth=short+sum(row.values())
    row={2:1}
    for depth in range(3,H.bit_length()+1):
        nxt=defaultdict(int)
        for odds,count in row.items():
            for bit in (0,1):
                r=odds+bit
                if 3**r > 2**(depth-1):
                    nxt[r] += count
        row=dict(nxt)
    ordered=2*sum(row.values())
    return min(bandwidth,ordered),bandwidth,ordered
