#!/usr/bin/env python3
"""Exact controls for formal positive-run masses and a scoped merge obstruction.

The unbounded construction is proved in the companion note. This finite check
does not assert a counterexample to any unit-gate-conditioned or core estimate.
"""
from fractions import Fraction as F
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def run(a, s, e):
    x = a
    internal = []
    for exponent in [1] * (s - 1) + [e]:
        assert v2(3 * x + 1) == exponent
        x = (3 * x + 1) // 2**exponent
        internal.append(x)
    return x, internal


def main():
    dyadic = ternary = F(0)
    first_five = F(0)
    for s in range(2, 101):
        for e in range(2, s + 1):
            if 2**s + 2**(s + e - 1) < 2 * 3**s:
                dyadic += F(1, 2**(s + e - 1))
                ternary += F(1, 3**s)
                if s <= 5:
                    first_five += F(1, 2**(s + e - 1))
    assert first_five + F(1, 32) == F(85, 256) < F(1, 3)
    assert dyadic + F(1, 2**100) < F(1, 3)
    assert ternary + F(201, 4 * 3**100) < F(1, 4)

    types = [(2, 2), (12, 8)]
    largest_s, largest_e = types[-1]
    modulus3 = 3**largest_s
    residue = -pow(2, -(largest_e - 1), modulus3) % modulus3
    y = next(residue + t * modulus3 for t in range(8)
             if (residue + t * modulus3) % 8 == 1)
    period = 8 * modulus3
    y += ((2**100 - y) // period + 1) * period
    n = (3 * y + 1) // 4
    H = (4 * n - 2) // 3
    assert n % 2 == 1 and H == y - 1 and n >= 2**71
    terminal, _ = run(y, 1, 2)
    assert terminal == n
    kappa = F(n - 1, n + 1)
    terminal_delta = F(1, 3 * y)
    terminal_f = F(1, y) - F(1, n)
    terminal_credit = -terminal_f - terminal_delta / 15
    assert terminal_credit > 0

    profiles = []
    starts = set()
    for s, e in types:
        E = s + e - 1
        beta = 1 - F(2**s, 3**s)
        lam = F(2**E, 3**s)
        assert F(4, 5) < lam < 1
        a_fraction = lam * y - beta
        assert a_fraction.denominator == 1
        a = int(a_fraction)
        starts.add(a)
        assert n < a <= H and v2(a + 1) == s
        endpoint, states = run(a, s, e)
        assert endpoint == y and min(states) == y and all(x > H for x in states)
        delta = beta / a
        f = F(1, a) - F(1, y)
        credit = max(F(0), -f - delta / 15)
        assert credit == 0 and kappa * delta + f > 0
        Q = beta + lam / 3
        assert beta < 1 and Q < F(4, 3)
        source_modulus = 2**(E + 3)
        previous = a - source_modulus
        assert previous > 0
        previous_y, _ = run(previous, s, e)
        assert previous_y == y - 8 * 3**s <= H
        previous_endpoint, _ = run(previous_y, 1, 2)
        assert previous_endpoint == n - 6 * 3**s < n
        profiles.append({"s": s, "e": e, "source": str(a),
                         "initial_credit": "0", "gate_phase_below_one": True,
                         "full_phase": str(Q), "core_count": 0,
                         "previous_lift_excluded_by_proper_height": True})
    assert len(starts) == len(types)
    all_threshold = (F(33, 26) * (1 + F(1, 2**70)) * 853
                     * F(1, 2**32) * F(9, 16)**15)
    assert F(256, 243)**2 < F(9, 8)
    assert all_threshold < F(5, 10**11)
    data = {"status": "PASS", "formal_dyadic_mass_ceiling": "85/256",
            "formal_ternary_mass_ceiling": "1/4",
            "dyadic_mass_upper_at_100": str(dyadic + F(1, 2**100)),
            "ternary_mass_upper_at_100": str(ternary + F(201, 4 * 3**100)),
            "n": str(n), "H": str(H), "shared_state": str(y),
            "profiles": profiles, "terminal_credit_per_copy": str(terminal_credit),
            "total_original_signed_score": str(-len(profiles) * terminal_credit),
            "all_threshold_C_chain_bound": str(all_threshold),
            "unit_gate_or_core_counterexample_claimed": False,
            "full_future_suffix_bound_proved": False}
    (HERE / "positive_alphabet_obstruction_certificate.json").write_text(
        json.dumps(data, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "finite_sources": len(profiles),
                      "core_copies": 0, "terminal_credits_retained": True,
                      "all_threshold_C_chain_upper": float(all_threshold),
                      "full_future_suffix_bound_proved": False}, indent=2))


if __name__ == "__main__":
    main()
