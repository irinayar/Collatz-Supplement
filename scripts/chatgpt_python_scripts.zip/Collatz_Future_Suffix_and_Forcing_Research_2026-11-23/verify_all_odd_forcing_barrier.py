#!/usr/bin/env python3
"""Exact controls for the all-odd prefix / ternary divisibility forcing barrier.

The note proves the universal all-even-budget statement. These bounded
inverse enumerations and actual large CRT prefixes are independent controls.
"""
from __future__ import annotations

from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent


def step(x):
    return (3*x+1)//2 if x & 1 else x//2


def v3(x):
    assert x > 0
    v = 0
    while x % 3 == 0:
        x //= 3
        v += 1
    return v


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(x) for x in value]
    return value


def crt_source(J, P, floor=1):
    two, three = 2**(J+1), 3**(P+1)
    t = ((3**P+1)*pow(two, -1, three)) % three
    n = two*t-1
    modulus = two*three
    if n < floor:
        n += ((floor-n+modulus-1)//modulus)*modulus
    assert n % two == two-1 and n % three == 3**P
    assert v3(n) == P
    return n


@lru_cache(maxsize=None)
def inverse_origins(z, r, d):
    if r == 0:
        return frozenset([z*2**d])
    if d == 0:
        q, rem = divmod(z+1, 3**r)
        if rem or 2**r*q-1 <= 0:
            return frozenset()
        return frozenset([2**r*q-1])
    result = set(inverse_origins(2*z, r, d-1))
    if z % 3 == 2:
        result.update(inverse_origins((2*z-1)//3, r-1, d))
    return frozenset(result)


def main():
    if not __debug__:
        raise SystemExit('Run without optimization flags.')
    cases = 0
    origin_count = 0
    feasible_extra_layers = 0
    controls = []
    for P in range(1, 4):
        for J in range(1, 5):
            n = crt_source(J, P)
            x = n
            for j in range(1, J+1):
                assert x & 1
                x = step(x)
                assert x == F(3, 2)**j*(n+1)-1 and x & 1
                assert v3(x+1) == j
                for r in range(0, j+P+1):
                    for d in range(0, 7):
                        origins = inverse_origins(x, r, d)
                        cases += 1
                        origin_count += len(origins)
                        assert all(m >= n for m in origins)
                        if r <= j:
                            lower = 2**d*(F(3, 2)**(j-r)*(n+1)-1)
                            assert all(m >= lower for m in origins)
                        else:
                            p = r-j
                            rho = F(2**(p+d), 3**p)
                            if origins:
                                feasible_extra_layers += 1
                                assert rho > 2
                            for m in origins:
                                m0 = m-rho*n
                                assert m0.denominator == 1 and m0 >= 1
                                upper = rho-1-(2**d-1)*F(2, 3)**r
                                assert m0 <= upper and m > 2*n
                controls.append({'source': n, 'j': j, 'v3_source': P,
                                 'endpoint': x, 'inverse_even_budget_checked': 6,
                                 'maximum_target_odd_count_checked': j+P})

    # General residue-window controls, including p beyond v3(n).
    residue_queries = 0
    residue_origins = 0
    for n in range(3, 128, 2):
        x = n
        for j in range(1, 4):
            if not x & 1:
                break
            x = step(x)
            for p in range(1, 4):
                q, s = divmod(n, 3**p)
                for d in range(0, 5):
                    origins = inverse_origins(x, j+p, d)
                    residue_queries += 1
                    rho = F(2**(p+d), 3**p)
                    upper = rho*(s+1)-1-(2**d-1)*F(2, 3)**(j+p)
                    for m in origins:
                        residue_origins += 1
                        m_p = m-2**(p+d)*q
                        assert 1 <= m_p <= upper
                        a, b = m, m_p
                        for _ in range(p+d):
                            assert a % 2 == b % 2
                            a, b = step(a), step(b)

    # The formal-word comparison from a negative integer, and numerator
    # extrema, checked independently over every word through length nine.
    formal_cases = 0
    for length in range(1, 10):
        for mask in range(2**length):
            U, r = 0, 0
            z = F(-1)
            for i in range(length):
                bit = (mask >> i) & 1
                if bit:
                    U = 3*U+2**i
                    r += 1
                    z = (3*z+1)/2
                else:
                    z /= 2
            d = length-r
            assert 3**r-2**r <= U <= 2**d*(3**r-2**r)
            assert z < F(3, 2)**length-1
            formal_cases += 1

    # Large exact prefixes evade any requested finite extra-odd precision P.
    large = []
    for J, P in [(10, 7), (64, 16), (128, 32)]:
        n = crt_source(J, P, 2**71)
        H = (4*n-2)//3
        x = n
        for j in range(1, J+1):
            assert x & 1
            x = step(x)
            h = F(3, 2)**j
            G = F(x, n)/h
            shifted = F(x+5, n+5)/h
            assert x > H and x & 1
            assert 1 < G < 1+F(1, n)
            assert 0 < shifted < 1
            assert v3(x+1) == j
        large.append({'J': J, 'P': P, 'source': n, 'source_bits': n.bit_length(),
                      'endpoint': x, 'raw_correction': G,
                      'shifted_correction': shifted,
                      'all_odd_inputs_and_final_odd_bit': True,
                      'proper_states_above_H': True,
                      'no_smaller_meeting_with_at_most_J_plus_P_odd_inputs': True,
                      'future_completion_asserted': False})

    # The barrier is a required count increase, not a ban on all meetings.
    # 31 reaches 167, which is the first odd iterate of 111 (v3(111)=1).
    x, r, d, path = 31, 0, 0, [31]
    while x != 167:
        assert len(path) < 200
        if x & 1:
            r += 1
        else:
            d += 1
        x = step(x)
        path.append(x)
    assert step(111) == 167 and r > 1+v3(111)
    witness = {'source': 111, 'smaller_origin': 31, 'meeting_endpoint': 167,
               'source_counts': [1, 0], 'target_counts': [r, d], 'target_path': path}
    result = {'status': 'PASS', 'bounded_inverse_queries': cases,
              'bounded_inverse_origins_checked': origin_count,
              'general_residue_queries': residue_queries,
              'general_residue_origins_checked': residue_origins,
              'nonempty_extra_odd_layers': feasible_extra_layers,
              'formal_word_controls': formal_cases,
              'small_source_controls': controls, 'large_CRT_prefixes': large,
              'meeting_beyond_the_barrier': witness,
              'all_even_budget_statement_proved_by_written_argument': True,
              'global_forcing_proved': False, 'global_collatz_proof': False,
              'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'all_odd_forcing_barrier_certificate.json').write_text(
        json.dumps(encode(result), indent=2)+'\n')
    print(json.dumps({'status': 'PASS', 'inverse_queries': cases,
                      'inverse_origins': origin_count,
                      'general_residue_queries': residue_queries,
                      'general_residue_origins': residue_origins,
                      'formal_words': formal_cases,
                      'large_actual_prefixes': len(large),
                      'global_forcing_proved': False}, indent=2))


if __name__ == '__main__':
    main()
