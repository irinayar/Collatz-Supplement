#!/usr/bin/env python3
"""Exact certificate for the initial six-type core envelope (<8/10^10).

Python standard library only. Infinite quantifiers are proved analytically in
Initial_Six_Type_Core_Aggregate.md. No full residual or global proof is claimed.
"""
from collections import defaultdict
from fractions import Fraction as F
from itertools import product, combinations
from pathlib import Path
import argparse
import hashlib
import json

TYPES = {"A2":(2,2), "A3":(4,3), "A4":(5,4),
         "A5":(7,5), "A6":(9,6), "A7":(11,7)}
LOCAL = {name:(3**s, 3**s-2**s, 2**(s+e-1), s+e-1)
         for name,(s,e) in TYPES.items()}
CHI = {name:2-F(2,3)**s-F(2**(s+e-1),3**s)
       for name,(s,e) in TYPES.items()}


def fraction_data(x):
    x=F(x)
    return {"numerator":x.numerator,"denominator":x.denominator,"decimal":float(x)}


def encode(word):
    A,B,D=1,0,1
    for name in word:
        a,b,d,_=LOCAL[name]
        A,B,D=a*A,a*B+b*D,d*D
    return A,B,D


def source_cylinder(word):
    A,B,D=encode(word)
    return ((D-B)*pow(A,-1,2*D))%(2*D),2*D


def output_cylinder(word):
    A,B,D=encode(word)
    return (B*pow(D,-1,A))%A,A


def replay(a,word):
    x=a
    assert x>0 and x%2
    for name in word:
        s,e=TYPES[name]
        for expected in [1]*(s-1)+[e]:
            z=3*x+1
            actual=(z & -z).bit_length()-1
            assert actual==expected
            x=z>>actual
    A,B,D=encode(word)
    assert x*D==A*a+B
    return x


def phase_certificate():
    """Explore every prefix to depth eight or its first Lambda>1 cut.

    At a cut, proper survival would imply u<B/(D-A). Check this <557.
    Non-cut nodes have every prior coefficient <1. Their phase is B/A.
    """
    counts=[0]*9
    first_cuts=[0]*9
    maximum=[(0,1,()) for _ in range(9)]
    cut_maximum=[(0,1,()) for _ in range(9)]
    phase_mass=[defaultdict(int) for _ in range(9)]

    def visit(A,B,D,depth,E,word):
        counts[depth]+=1
        p,q,_=maximum[depth]
        if B*q>p*A:
            maximum[depth]=(B,A,word)
        if B>5*A:
            phase_mass[depth][E]+=1
        if depth==8:
            return
        for name,(a,b,d,e) in LOCAL.items():
            aa,bb,dd=a*A,a*B+b*D,d*D
            child=word+(name,)
            assert aa!=dd
            if dd>aa:
                k=depth+1
                first_cuts[k]+=1
                assert bb<557*(dd-aa)
                p,q,_=cut_maximum[k]
                if bb*q>p*(dd-aa):
                    cut_maximum[k]=(bb,dd-aa,child)
            else:
                visit(aa,bb,dd,depth+1,E+e,child)

    visit(1,0,1,0,0,())
    expected=[1,5,30,179,1073,6435,38604,231609,1389619]
    assert counts==expected
    for j in range(1,9):
        assert counts[j]+first_cuts[j]==6*counts[j-1]
    assert 557<2**71
    densities=[]
    records=[]
    for j in range(1,9):
        density=sum((F(c,2**e) for e,c in phase_mass[j].items()),F(0))
        densities.append(density)
        if j<=5:
            assert density==0 and F(*maximum[j][:2])<5
        records.append({"depth":j,"coefficient_surviving_nodes":counts[j],
          "first_expansion_cuts":first_cuts[j],
          "phase_above_five_nodes":sum(phase_mass[j].values()),
          "maximum_phase":fraction_data(F(*maximum[j][:2])),
          "phase_maximizer":list(maximum[j][2]),
          "maximum_cut_source_bound":fraction_data(F(*cut_maximum[j][:2])),
          "cut_maximizer":list(cut_maximum[j][2]),
          "weighted_phase_density":fraction_data(density),
          "phase_density_by_total_valuation":dict(sorted(phase_mass[j].items()))})
    assert densities[5]==F(4723505,2**75)
    assert densities[6]==F(54676993561995995,2**98)
    assert densities[7]==F(129202771513994966674259,2**116)
    phase_sum=sum(densities,F(0))
    assert phase_sum<F(2,10**12)
    return records,phase_sum


def cylinder_controls(rho,eta,w,csum):
    base_outputs=[output_cylinder((name,))[0]%9 for name in TYPES]
    assert base_outputs==[4,2,1,5,7,8]
    assert len(set(base_outputs))==6
    source_checks=inverse_checks=local_replays=0
    for depth in range(1,4):
        words=list(product(TYPES,repeat=depth))
        sources=[source_cylinder(v) for v in words]
        outputs=[output_cylinder(v) for v in words]
        for (a,M),(b,N) in combinations(sources,2):
            assert (a-b)%min(M,N)!=0
            source_checks+=1
        for (a,M),(b,N) in combinations(outputs,2):
            assert (a-b)%min(M,N)!=0
            inverse_checks+=1
        assert sum((F(1,M) for _,M in sources),F(0))==rho**depth/2
        assert sum((F(1,M) for _,M in outputs),F(0))==eta**depth
        total_density=F(0)
        total_endpoints=F(0)
        for word,(r3,M3) in zip(words,outputs):
            for current in TYPES:
                r2,M2=source_cylinder((current,))
                residue=(r2+M2*((r3-r2)*pow(M2,-1,M3)%M3))%(M2*M3)
                a=residue+(M2*M3)*2**80
                A,B,D=encode(word)
                u=(D*a-B)//A
                assert u*A==D*a-B
                assert replay(u,word)==a
                replay(a,(current,))
                total_density+=CHI[current]/(M2*M3)
                total_endpoints+=CHI[current]
                local_replays+=1
        assert total_density==eta**depth*w
        assert total_endpoints==6**depth*csum
    return {"source_pair_checks":source_checks,"inverse_pair_checks":inverse_checks,
            "exact_local_CRT_replays":local_replays,"base_output_classes_mod9":base_outputs}


def low_exponent_merge_control():
    """High-floor proper prefixes, not claimed to be nonempty-core examples."""
    v=991+2048*2**80
    u=(9*v+1)//8
    n=9*v//10
    if n%2==0:
        n+=1
    H=(4*n-2)//3
    a=(9*u+5)//8
    b=(243*v+211)//128
    y=(243*u+287)//128
    assert 8*u-9*v==1
    assert y==(2187*v+2539)//1024
    assert (243*u+287)%128==0 and (2187*v+2539)%1024==0
    assert n>=2**71 and n<=v<u<=H<min(a,b,y)
    paths=[]
    for source,seq in [(u,[1,2,1,1,2]),(v,[1,1,1,1,3,1,2])]:
        x=source
        path=[x]
        for e in seq:
            z=3*x+1
            assert (z & -z).bit_length()-1==e
            x=z>>e
            assert x>H
            path.append(x)
        assert x==y
        paths.append(path)
    return {"claim":"Two exact proper high-floor prefixes with all terminal exponents <=3 merge.",
       "scope":"Local source-band injection obstruction only; no original-core witness asserted.",
       "n":n,"H":H,"u":u,"v":v,"meeting":y,"odd_paths":paths,
       "higher_source_types":[[2,2],[3,2]],"lower_source_types":[[5,3],[2,2]]}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",default=str(Path(__file__).with_name(
        "Initial_Six_Type_Core_Aggregate_Certificate.json")))
    args=parser.parse_args()
    phase,phase_sum=phase_certificate()
    rho=sum((F(1,D) for _,_,D,_ in LOCAL.values()),F(0))
    eta=sum((F(1,A) for A,_,_,_ in LOCAL.values()),F(0))
    w=sum((CHI[name]/(2*LOCAL[name][2]) for name in TYPES),F(0))
    csum=sum(CHI.values(),F(0))
    assert rho==F(19017,131072)
    assert eta==F(22690,177147)
    assert w==F(1194665107,23219011584)
    assert csum==F(1043216,177147)
    assert 2*eta<1
    for name,(s,e) in TYPES.items():
        beta=1-F(2,3)**s
        lam=F(2**(s+e-1),3**s)
        assert CHI[name]>0 and lam<=1+beta/15
    controls=cylinder_controls(rho,eta,w,csum)
    n0=2**71
    K0=F(n0+1,4*n0-1)
    early=K0*w*(phase_sum+rho**9/(1-rho))
    endpoints=F(6,5)*csum*6**14/F(2**71)
    deep=w*F(224,5)*eta**14*128
    total=early+endpoints+deep
    allowance=F(8,10**10)
    assert total<allowance
    # Adaptive bin identities: k=ceil(log2 m), J=7+k, m>=72.
    # For k>=8 the first m is 2^(k-1)+1; the next bin bound ratio is
    # 6/2^(2^(k-1))<1. The special initial bin starts at m=72.
    assert 6<2**57
    for m in [72,73,127,128,129,255,256,257,1024,4096]:
        k=(m-1).bit_length()
        J=7+k
        assert 6**J*2**71<=6**14*2**(m-1)
        assert eta**J*m<=eta**14*128
    result={
       "status":"PASS",
       "theorem":"Initial six-type positive original-core mass < 8/10^10",
       "domain":"All odd n>=2^71; original source family, core and Pstar retained.",
       "palette":{name:list(se) for name,se in TYPES.items()},
       "scope":"All initial-prefix occurrences over the fixed six types, arbitrary order/length, future unrestricted.",
       "full_signed_residual_proved":False,"global_Collatz_proof":False,
       "phase_tree":phase,"phase_density_sum_depths_6_to_8":fraction_data(phase_sum),
       "all_first_expansion_cuts_less_than":557,
       "rho":fraction_data(rho),"eta":fraction_data(eta),
       "weighted_current_density":fraction_data(w),"charge_sum":fraction_data(csum),
       "adaptive_depth":"J(m)=7+ceil(log2(m))",
       "early_density_bound":fraction_data(early),
       "all_endpoint_bound":fraction_data(endpoints),"deep_log_bound":fraction_data(deep),
       "uniform_bound":fraction_data(total),"allowance":fraction_data(allowance),
       "strict_margin":fraction_data(allowance-total),"cylinder_controls":controls,
       "variable_length_merge_control":low_exponent_merge_control(),
       "verifier_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       "limitations":["Fixed lengths are essential to the injection proof.",
          "No claim for later blocks after an arbitrary prefix.",
          "Use as a replacement for the initial RC envelope; do not add overlapping payments.",
          "All original negatives, entrance credits and old envelope surpluses remain retained.",
          "No variable-length original-core counterexample is asserted."]}
    Path(args.output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":"PASS","bound":float(total),"allowance":float(allowance),
       "surviving_depth_eight_nodes":phase[-1]["coefficient_surviving_nodes"],
       "weighted_phase_nodes_depth_eight":phase[-1]["phase_above_five_nodes"],
       "controls":controls,"certificate":str(Path(args.output).resolve())},indent=2))


if __name__=="__main__":
    main()
