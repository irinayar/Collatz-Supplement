#!/usr/bin/env python3
"""Exact controls for the all-threshold initial R/C core aggregate theorem.

Standard library only.  This certifies finite identities and the rational
constant in the companion proof; it does not assert a complete Collatz proof.
Run: python verify_initial_rc_aggregate.py
"""
from fractions import Fraction as F
from itertools import product, combinations
from pathlib import Path
import argparse
import hashlib
import json

TYPES = {"R": (2, 2), "C": (5, 4)}
CHI = {"R": F(2, 3), "C": F(22, 27)}


def encode(word):
    """b=(A*a+B)/D for a word of complete-run letters."""
    A, B, D = 1, 0, 1
    for letter in word:
        s, e = TYPES[letter]
        Ai, Bi, Di = 3**s, 3**s - 2**s, 2**(s + e - 1)
        A, B, D = Ai*A, Ai*B + Bi*D, Di*D
    return A, B, D


def source_cylinder(word):
    A, B, D = encode(word)
    M = 2*D
    return ((D-B)*pow(A, -1, M)) % M, M


def output_cylinder(word):
    A, B, D = encode(word)
    return (B*pow(D, -1, A)) % A, A


def crt_23(r2, M2, r3, M3):
    return (r2 + M2*((r3-r2)*pow(M2, -1, M3) % M3)) % (M2*M3)


def valuations(word):
    return tuple(v for letter in word
                 for v in ([1]*(TYPES[letter][0]-1) + [TYPES[letter][1]]))


def replay(a, word):
    """Check every exact odd valuation, not only the affine endpoints."""
    x = a
    assert x > 0 and x % 2
    for expected in valuations(word):
        z = 3*x + 1
        actual = (z & -z).bit_length()-1
        assert actual == expected, (a, word, x, actual, expected)
        x = z >> actual
        assert x % 2
    A, B, D = encode(word)
    assert x*D == A*a+B
    return x


def data_fraction(x):
    x = F(x)
    return {"numerator": x.numerator, "denominator": x.denominator,
            "decimal": float(x)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(Path(__file__).with_name(
        "Initial_RC_Core_Aggregate_Certificate.json")))
    args = parser.parse_args()

    # Finite proof that a proper initial RC prefix with q>5 has >=8 runs.
    phase = []
    for depth in range(1, 8):
        surviving = []
        for word in product(TYPES, repeat=depth):
            q, lam = F(0), F(1)
            for letter in word:
                s, e = TYPES[letter]
                q += lam*(1-F(2, 3)**s)
                lam *= F(2**(s+e-1), 3**s)
                if lam >= 1:
                    break
            else:
                A, B, D = encode(word)
                assert q == F(B, A) and lam == F(D, A)
                surviving.append((q, "".join(word)))
        maximum, maximizer = max(surviving)
        assert maximum < 5
        phase.append({"depth": depth, "words_tested": 2**depth,
                      "coefficient_survivors": len(surviving),
                      "maximum_phase": data_fraction(maximum),
                      "maximizer": maximizer})
    assert [r["coefficient_survivors"] for r in phase] == [1,2,4,7,14,28,53]
    assert phase[-1]["maximum_phase"]["numerator"] == 12182956761197
    assert phase[-1]["maximum_phase"]["denominator"] == 2541865828329
    assert 7*F(256,243)**6 < 11
    assert 11*3**35 < 2**71

    # Explicit individual source and inverse-output cylinders.
    assert source_cylinder("R") == (11, 16)
    assert source_cylinder("C") == (95, 512)
    assert output_cylinder("R") == (4, 9)
    assert output_cylinder("C") == (91, 243)
    assert 4 % 9 != 91 % 9

    source_pairs_checked = 0
    inverse_pairs_checked = 0
    crt_replays = 0
    finite_depth_records = []
    r, d = F(33,256), F(28,243)
    w, csum = F(299,6912), F(40,27)
    for depth in range(1,9):
        words = list(product(TYPES, repeat=depth))
        sources = [source_cylinder(word) for word in words]
        outputs = [output_cylinder(word) for word in words]
        for (a, M), (b, N) in combinations(sources, 2):
            assert (a-b) % min(M,N) != 0
            source_pairs_checked += 1
        for (a, M), (b, N) in combinations(outputs, 2):
            assert (a-b) % min(M,N) != 0
            inverse_pairs_checked += 1
        assert sum((F(1,M) for _,M in sources), F(0)) == r**depth/2
        assert sum((F(1,M) for _,M in outputs), F(0)) == d**depth

        weighted_crt_density = F(0)
        weighted_endpoint_sum = F(0)
        for word, (r3,M3) in zip(words, outputs):
            for current in TYPES:
                r2,M2 = source_cylinder(current)
                residue = crt_23(r2,M2,r3,M3)
                modulus = M2*M3
                # One large local realization checks the entire inverse
                # history and current run.  It is not claimed to be a
                # band-surviving original core witness.
                a = residue + modulus*2**80
                A,B,D = encode(word)
                u = (D*a-B)//A
                assert u*A == D*a-B
                assert replay(u,word) == a
                replay(a,current)
                weighted_crt_density += CHI[current]/modulus
                weighted_endpoint_sum += CHI[current]
                crt_replays += 1
        assert weighted_crt_density == d**depth*w
        assert weighted_endpoint_sum == 2**depth*csum
        finite_depth_records.append({"depth": depth, "words": len(words),
             "source_density": data_fraction(r**depth/2),
             "inverse_density": data_fraction(d**depth),
             "weighted_two_sided_density": data_fraction(d**depth*w)})

    # Exact all-threshold majorant, J(m)=12+ceil(log2(m)), m>=72.
    # The infinite quantifiers follow from the companion analytic proof.
    n_floor = 2**71
    K0 = F(n_floor+1,4*n_floor-1)
    assert d < F(1,8)
    assert w == CHI["R"]/16 + CHI["C"]/512
    assert csum == CHI["R"] + CHI["C"]
    early_main = K0*w*r**8/(1-r)
    endpoints = 2*csum*8192*72/F(2**71)
    deep_log = w*F(224,5)*d**12/(72**2)
    bound = early_main + endpoints + deep_log
    allowance = F(1,10**9)
    assert bound < allowance
    # Exact illustrative checks of the adaptive algebra at boundary and
    # very large bit lengths; these are controls, not substitutes for proof.
    for m in (72,73,127,128,129,271,272,273,1024,10**6,10**30):
        k = (m-1).bit_length()
        J = 12+k
        assert 2**J < 8192*m
        assert d**J <= d**12/F(m**3)
        assert F(7,10)*(63*m+1) <= F(224,5)*m

    certificate = {
        "status": "PASS",
        "theorem": "Initial-RC positive-core aggregate < 1/10^9",
        "domain": "All odd n >= 2^71; original source family and original core",
        "scope": "All positive core occurrences whose complete initial prefix, including the current run, contains only R=(2,2) and C=(5,4). Future unrestricted.",
        "full_signed_residual_proved": False,
        "global_Collatz_proof": False,
        "phase_records": phase,
        "finite_depth_records": finite_depth_records,
        "source_pair_disjointness_checks": source_pairs_checked,
        "inverse_pair_disjointness_checks": inverse_pairs_checked,
        "exact_local_CRT_replays": crt_replays,
        "r": data_fraction(r), "d": data_fraction(d),
        "weighted_current_density": data_fraction(w),
        "adaptive_depth": "J(m)=12+ceil(log2(m))",
        "early_main_bound": data_fraction(early_main),
        "all_endpoint_bound": data_fraction(endpoints),
        "deep_log_bound": data_fraction(deep_log),
        "uniform_bound": data_fraction(bound),
        "allowance": data_fraction(allowance),
        "strict_margin": data_fraction(allowance-bound),
        "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "limitations": [
            "No claim for later RC blocks after an arbitrary earlier letter.",
            "No entrance credit, negative term, or old coverage surplus is spent.",
            "The finite CRT replays are local exact-cylinder controls, not original-core examples.",
            "The infinite-depth and all-threshold claims use the analytic proof.",
            "Adding this sector to the residual must exclude its already-covered copies."]
    }
    Path(args.output).write_text(json.dumps(certificate,indent=2)+"\n")
    print(json.dumps({"status":"PASS", "bound":float(bound),
                     "allowance":float(allowance),
                     "source_pair_checks":source_pairs_checked,
                     "inverse_pair_checks":inverse_pairs_checked,
                     "local_CRT_replays":crt_replays,
                     "certificate":str(Path(args.output).resolve())},indent=2))


if __name__ == "__main__":
    main()
