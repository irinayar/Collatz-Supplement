"""Exact overlay of the reconstructed depth-41 masks onto the frozen ledger.
Inputs: prior depth-53 census and transcribed CRT rules, strata from replay.cpp.
All numerical proof comparisons use integers/Fraction; no external libraries.
"""
from fractions import Fraction as F
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path
from math import lcm
import csv,json
assert __debug__
R=json.loads(Path('results.json').read_text());Q=F(2519180,4782969)
P=103;L=41
D=[(int(r['residue']),int(r['exponent'])) for r in csv.DictReader(open('projected181.csv'))]
parents={int(r) for r in Path('parents27.txt').read_text().split()};assert len(parents)==1982
def live_parent(r):
 x=r;a=0
 for j in range(1,28):
  if x&1:x=(3*x+1)//2;a+=1
  else:x//=2
  if 3**a<2**j or (x%3==2 and (2*x-1)//3<r and 2*3**a<3*2**j):return False
 return True
assert parents=={r for r in range(103,2**27,8192) if live_parent(r)}
# Every selected mask lies in a parent child from this set. Check disjointness
# even for projection exponents 47 and 53 (intersection test, not containment).
assert all((r-z)%2**min(d,27) for r in parents for z,d in D)
# Verify the fixed initial parity prefix resolves C08.
z=P;w=[]
for j in range(5):
 w.append(z%2);z=(3*z+1)//2 if z%2 else z//2
assert w==[1,1,1,0,1]
rows=[];pure=[]
for row in csv.DictReader(open('finite_ledger_transcribed.csv')):
 z,m=int(row['residue']),int(row['modulus']);d=e=0
 while m%2==0:m//=2;d+=1
 while m%3==0:m//=3;e+=1
 assert m==1
 if e:rows.append((z%2**d,d,z%3**e,e))
 else:pure.append((z%2**d,d))
assert len(rows)==103 and max(d for _,d,_,_ in rows)==11
assert all((r-z)%2**min(27,d) for r in parents for z,d in pure)
active=[(z,e) for a,d,z,e in rows if P%2**d==a]
def antichain(c):
 out=[]
 for z,e in sorted(set(c),key=lambda p:p[1]):
  if not any(z%3**v==u for u,v in out):out.append((z,e))
 return out
def mass(c):return sum((F(1,3**e) for z,e in antichain(c)),F(0))
assert 1-mass(active)==Q
# Both approaches to each horizon: forward propagation and independent backward
# continuation DP (only at requested horizons, not an exponential word search).
C0={e:Counter() for e in range(7)}
for line in Path('strata.csv').read_text().splitlines():
 e,a,n=map(int,line.split(','));C0[e][a]=n
assert [sum(c.values()) for c in C0.values()]==[16011,251887,281031,195329,248833,285653,371013]
Dmass={t:[F(sum(c.values()),2**41) for c in C0.values()] for t in range(27,42)}
C={e:c.copy() for e,c in C0.items()};C53=None
for t in range(42,513):
 C={e:Counter({a:c[a]+c[a-1] for a in range(t+1) if 3**a>=2**t and c[a]+c[a-1]}) for e,c in C.items()}
 Dmass[t]=[F(sum(c.values()),2**t) for c in C.values()]
 if t==53:C53={e:c.copy() for e,c in C.items()}
for t in [41,53,100,512]:
 h={a:1 for a in range(t+1) if 3**a>=2**t}
 for d in range(t-1,40,-1):h={a:h.get(a,0)+h.get(a+1,0) for a in range(d+1) if 3**a>=2**d}
 assert Dmass[t]==[F(sum(n*h[a] for a,n in c.items()),2**t) for c in C0.values()]
assert Dmass[100][6]*2**100==12083228764224801145504
# Exact statewise comparison after adding all seven budgets or just 0..5.
base={r['a']:r for r in R['base53_state_rows']};A=range(34,54)
N={a:base.get(a,{}).get('total',0) for a in A};B={a:base.get(a,{}).get('parent',0) for a in A};V={a:F(base.get(a,{}).get('weighted_q','0')) for a in A}
W={a:sum(c[a] for c in C53.values()) for a in A};W6={a:C53[6][a] for a in A}
assert all(0<=W6[a]<=W[a]<=B[a] for a in A)
assert W[53]==W[52]==0
for cutoff in (5,6):
 prev=None
 for a in range(34,53):
  w=sum(C53[e][a] for e in range(cutoff+1));n=N[a]-w;p=B[a]-w;v=V[a]-Q*w
  assert n>p>=0
  r=(v/n,(v-Q*p)/(n-p),F(p,n));assert r[0]<Q and r[1]<Q
  if prev:assert prev[0]<r[0] and prev[1]<r[1] and prev[2]>=r[2]
  else:assert p>0
  prev=r
 assert prev[2]==0
# Independently propagate the old escaped/pending census to depth 512.
scale=lcm(Q.denominator,*(v.denominator for v in V.values()));qQ=int(Q*scale)
S={(a,3):(N[a],int(V[a]*scale),B[a]) for a in range(34,53)}
S[52,2]=(1,qQ,0);S[53,1]=(1,qQ,0)
for d in range(54,513):
 T=defaultdict(lambda:[0,0,0])
 for (a,s),v in S.items():
  for bit in (0,1):
   if 3**(a+bit)<2**d or (s==2 and not bit):continue
   ns=3 if s!=1 else (1 if bit else 2)
   for i in range(3):T[a+bit,ns][i]+=v[i]
 S=dict(T)
n,v,p=(sum((2 if s==3 else 1)*r[i] for (a,s),r in S.items()) for i in range(3))
row512={'theta':str(F(n,2**513)),'B':str(F(p,2**513)),'F':str(F(v,scale*2**513))}
# Earlier exact horizon totals plus new masks; test every finite pre-53 transition.
def thresh(t):
 a=0
 while 3**a<2**t:a+=1
 return a
Frows={};prev={}
for t in list(range(27,54))+[100,512]:
 row=row512 if t==512 else R['horizons'][str(t)];theta=F(row['theta']);b=F(row['B']);v=F(row['F']);ds=Dmass[t];d=sum(ds);s=ds[6]
 for cutoff in (5,6):
  w=sum(ds[:cutoff+1]);q=(v-Q*w)/(theta-w);p=(b-w)/(theta-w)
  if cutoff in prev and t<=53:
   oldq,oldp=prev[cutoff];assert (q>oldq and p<oldp) if thresh(t)>thresh(t-1) else (q==oldq and p==oldp)
  prev[cutoff]=q,p
 Frows[t]={'delta_all':str(d),'delta_six':str(s),'all_over_parent':str(d/b),'six_over_parent':str(s/b),'q_after':str((v-Q*d)/(theta-d)),'parent_after':str((b-d)/(theta-d)),'theta':str(theta),'B':str(b),'F':str(v)}
# Hybrid first-hit comparison for adjacent counts, with K=128 at D=53.
# Independent forward and backward evaluations of the exact same kernel.
K=128;D0=53;Hhit={}
for a in range(34,53):
 b=a+1;live={0:1};good=0
 for l in range(1,K+1):
  nxt=defaultdict(int)
  for j,n in live.items():
   for v in (j,j+1):
    if 3**(a+v)<2**(D0+l):continue
    if 3**(a+v)>=2**l*3**b:good+=n*2**(K-l)
    else:nxt[v]+=n
  live=nxt
 den=3**(b+1)*2**K-2**(D0+K+1)
 num=good*den+sum(n*2*(3**(a+j)-2**(D0+K)) for j,n in live.items())
 @lru_cache(None)
 def back(l,j):
  if 3**(a+j)<2**(D0+l):return 0
  if 3**(a+j)>=2**l*3**b:return den*2**(K-l)
  if l==K:return 2*(3**(a+j)-2**(D0+K))
  return back(l+1,j)+back(l+1,j+1)
 assert den>0 and num==back(0,0)
 Hhit[a]=max(F(num,2**K*den),F(1,8));assert 0<Hhit[a]<=1
# Uniform lower fraction of the OLD parent; 1<=f(a+1)/f(a)<=1/Hhit[a].
def relax(c):
 v=c[53]
 for a in range(52,33,-1):v=c[a]+min(v,v/Hhit[a])
 return v
bounds={}
for name,w in [('all',W),('six',W6)]:
 def test(k):return relax({a:w[a]*10**12-k*B[a] for a in A})
 lo=0;hi=10**12
 while hi-lo>1:
  mid=(lo+hi)//2
  if test(mid)>0:lo=mid
  else:hi=mid
 low=F(lo,10**12);assert test(lo)>0
 upper=max(F(w[a],B[a]) for a in A if B[a])
 earlier=[F(Frows[t][name+'_over_parent']) for t in range(27,53)]
 lower27=min(low,*earlier);lower41=min(low,*earlier[14:]);upper27=max(upper,*earlier)
 bounds[name]={'lower53':str(low),'lower27':str(lower27),'lower41':str(lower41),'upper27':str(upper27),'signed_min_scaled':str(test(lo))}
# Use previous exact martingale bounds to get new all-horizon uniform constants.
u=F(524684700124,10**12);p0=F(600341232,10**12)
for name in bounds:
 for start in (27,41,53):
  ell=F(bounds[name]['lower'+str(start)]);bounds[name]['delta_over_theta_lower'+str(start)]=str(ell*p0)
lo=F(bounds['all']['delta_over_theta_lower41']);u_new=u-(Q-u)*lo/(1-lo)
p_new=(1-F(bounds['all']['upper27']))*p0
assert all(F(Frows[t]['q_after'])<u_new for t in range(27,41))
q512=F(Frows[512]['F'])/F(Frows[512]['theta']);p512=F(Frows[512]['B'])/F(Frows[512]['theta'])
for name in bounds:
 bounds[name]['limit_delta_over_theta_lower']=bounds[name]['delta_over_theta_lower53']
 bounds[name]['limit_delta_over_theta_upper']=str(F(bounds[name]['upper27'])*p512)
# Exact infinite tail series bounds for C110/C113.
def tail(k,s):
 r=2
 while 3**(r+s)<=2**(r+2*s+1+k):r+=1
 e=r+s;m=3**e;z=(1-3**(s+1)*pow(2,-(2*s+1),m))*pow(2,-k,m)%m
 assert (2**k*z-1)%3**(s+1)==0 and (2**k*z-1)%3**(s+2)!=0
 return z,e
S42=sum((F(1,3**tail(0,s)[1]) for s in range(5,47)),F(0));err=F(3,2*3**tail(0,47)[1]);assert S42==F(R['S42']) and err==F(R['S_error'])
assert all(tail(0,s)[1]==tail(2,s-2)[1] for s in range(5,47))
# Later numerical catalogue C114/C115 finite heads and C116 finite head plus
# infinite tail. Absorption/disjointness proofs as in Article I Approach 73.
# Recheck finite head increments exactly in the parent bucket; no density credit
# for C117--C120. C121 incompatible modulo 64.
for k in (6,12):
 z,e=tail(k,0);assert z%9==4
z,e=tail(8,0);w,f=tail(6,1);assert e>=f and z%3**f==w
assert (pow(64,-1,2187),pow(256,-1,2187))==(991,1888)
assert (991,7) in active and (1888,7) in active  # odd C108-11 or 18 on this parent
active_more=list(active);head_delta={};later=[]
for k,ss in [(6,range(1,6)),(8,range(1,6)),(12,range(1,20))]:
 before=mass(active_more)
 for s in ss:
  z,e=tail(k,s);later.append((k,s,z,e));active_more.append((z,e))
 head_delta[k]=mass(active_more)-before
# For each later finite head, check no intersection with the two earlier
# infinite high tails: the valuation of 2^k z-1 determines the only candidate
# unless it vanishes mod the entire modulus. This latter case never occurs here.
for k,s,z,e in later:
 for kk,smin in [(0,5),(2,3)]:
  zz=2**kk*z-1;v=0
  while zz%3==0 and v<e:v+=1;zz//=3
  assert v<e
  if v-1>=smin:
   w,f=tail(kk,v-1);assert (z-w)%3**min(e,f)
# C116 s>=20: no intersection with active finite rules, any earlier finite head,
# or its own finite heads. All such tail residues equal 4096^-1 mod 3^21.
assert max(e for _,e in active)<=21
for z,e in active_more:
 assert (4096*z-1)%3**min(e,21)
# Disjoint C116 infinite tail from C110/C113 follows already at mod81/mod9;
# C110 high tail is 1 mod81, C113 high tail 7 mod9. C116 high is 37 mod81.
assert pow(4096,-1,81)==37 and 37%9==1
assert (303-P)%64
S12=sum((F(1,3**tail(12,s)[1]) for s in range(20,101)),F(0));err12=F(3,2*3**tail(12,101)[1]);H=sum(head_delta.values(),F(0))
parent7lo=Q-2*(S42+err);parent7hi=Q-2*S42
parent121lo=parent7lo-H-S12-err12;parent121hi=parent7hi-H-S12
assert 0<parent121lo<parent121hi<parent7hi<Q
assert parent121lo>u-2*S42 # preserves the relative marginal lower bound even through C121
for t,row in Frows.items():
 for name in ('all','six'):
  delta=F(row['delta_'+name]);row[name+'_v7_gain']=[str(delta*parent7lo),str(delta*parent7hi)];row[name+'_C121_gain']=[str(delta*parent121lo),str(delta*parent121hi)]
out={'horizons':Frows,'base53':[{ 'a':a,'N':N[a],'P':B[a],'W':W[a],'W6':W6[a]} for a in A],'bounds':bounds,'new_upper27':str(u_new),'new_parent_lower27':str(p_new),'parent_factor_v7':[str(parent7lo),str(parent7hi)],'parent_factor_C121':[str(parent121lo),str(parent121hi)],'additional_parent_head_deltas':{str(k):str(v) for k,v in head_delta.items()},'C116_tail_bounds':[str(S12),str(S12+err12)],'new_tail_relative_gain_limit_bounds':[str(2*S42/u_new),str(2*(S42+err)/F(Frows[512]['q_after']))],'later_head_rows':later,'hybrid_adjacent':{str(a):str(v) for a,v in Hhit.items()}}
Path('overlay_results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: disjoint all 1982 parents from 181 projection masks; all finite state order checks; both DP counts; uniform bounds')
for name,b in bounds.items():print(name,{k:float(F(v)) for k,v in b.items() if k!='signed_min_scaled'})
print('new upper >=27',float(u_new),'new parent lower >=27',float(p_new))
print('parent v7 factor',float(parent7lo),'through C121',float(parent121lo),'head deltas',{k:float(v) for k,v in head_delta.items()})
for t in [32,100]:
 print(t,{k:float(F(v[0])) for k,v in Frows[t].items() if 'gain' in k})
