from functools import lru_cache

def v3(n):
 a=0
 while n%3==0:
  n//=3;a+=1
 return a
@lru_cache(None)
def H(x,e,r):
 if r<0:return None
 a=v3(x+1)
 if e==0:
  return (2**r*(x+1)//3**r-1) if r<=a else None
 vals=[]
 for l in range(min(a,r)+1):
  y=2*(2**l*(x+1)//3**l-1)
  z=H(y,e-1,r-l)
  if z is not None: vals.append(z)
 return min(vals) if vals else None
checks=0; bad=[]; transitions=[]
for x in range(1,401):
 for e in range(0,5):
  prev=None
  for r in range(0,23):
   z=H(x,e,r)
   if prev is not None and z is not None:
    checks+=1
    if z>prev:bad.append((x,e,r,prev,z))
   if z is None:break
   prev=z
print('adjacent checks',checks,'violations',bad[:5], 'cache',H.cache_info())
# exact one-even formula
for x in range(1,401):
 a=v3(x+1);u=(x+1)//3**a;D=2**(a+1)*u-1;d=v3(D)
 for r in range(a+d+1):
  if r<=a: z=2**(r+1)*(x+1)//3**r-2
  else: i=r-a;z=2**i*(D//3**i)-1
  assert H(x,1,r)==z,(x,r,z,H(x,1,r))
print('one-even closed form verified for x=1..400')
