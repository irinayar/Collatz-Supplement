from math import gcd

def T(n): return n//2 if n%2==0 else (3*n+1)//2

def audit(j):
    Q=1<<j
    words=[]
    for r in range(1,Q+1):
        x=r;a=0
        for _ in range(j):
            a+=x&1;x=T(x)
        U=Q*x-3**a*r
        words.append((r,a,U))
    primitive=[set() for _ in words]
    high=0; checked=0
    for i,(r,a,U) in enumerate(words):
        for s,b,V in words:
            if b<a: continue
            if b==a:
                if (V-U)%(3**a)==0 and V>U:
                    primitive[i].update((0,1,2))
            elif b==a+1:
                if (V-U)%(3**a)==0:
                    primitive[i].add(((V-U)//(3**a))%3)
    for i,(r,a,U) in enumerate(words):
        for s,b,V in words:
            if b<a+2: continue
            if (V-U)%(3**a): continue
            residue=((V-U)//(3**a))%3
            high+=1
            if residue not in primitive[i]:
                return False,('HIGH',j,r,s,a,b,residue,primitive[i])
    # Check all low n directly against periodic primitive predicate
    small=3**j+3*Q
    seen={}
    for n in range(1,small+1):
        x=n
        for _ in range(j): x=T(x)
        has_partner=x in seen
        seen.setdefault(x,n)
        i=(n-1)%Q
        primitive_hit=n%3 in primitive[i]
        if has_partner != primitive_hit:
            return False,('SMALL',j,n,has_partner,primitive_hit,seen[x])
    return True,(j,high,small,sum(len(x) for x in primitive))

if __name__=='__main__':
    for j in range(1,14):
        ok,info=audit(j)
        print(ok,info,flush=True)
        if not ok:break
