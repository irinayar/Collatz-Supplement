from fractions import Fraction

def odd_path(n,limit=300):
    u=n
    for i in range(limit):
        v=3*u+1;e=(v&-v).bit_length()-1
        nxt=v>>e
        yield u,e,nxt
        if nxt<n or nxt==1: break
        u=nxt

def check(N=30001):
    checked=visits=returns=0
    for n in range(3,N,2):
        H=(n-2)//3
        if H<0:continue
        hist=[]
        for u,e,v in odd_path(n):
            checked+=1
            if n<=u<=n+H and v>=n:
                visits+=1
                assert e==1, (n,u,e)
                assert v>n+H, (n,u,v,H)
            if len(hist)>0 and n<=u<=n+H:
                p,pe,pnext=hist[-1]
                assert pnext==u and pe>=2 and p>=Fraction(4*n-1,3), (n,H,p,pe,u)
                returns+=1
            hist.append((u,e,v))
    print('odd_edges',checked,'low_band_visits',visits,'low_band_returns',returns,'all_pass')
if __name__=='__main__':check()
