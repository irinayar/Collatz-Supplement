from functools import lru_cache
from collections import defaultdict
K=6; B=3*2**K-4
best={}; witness={}
for m in range(1,B):
 n=m;e=r=0
 while e<=K:
  if e==K:
   key=(n,r)
   if m<best.get(key,10**30):best[key]=m;witness[key]=m
  if n%2:n=(3*n+1)//2;r+=1
  else:n//=2;e+=1
@lru_cache(None)
def R(k,x):
 if k==0:
  a=0
  while (x+1)%3**(a+1)==0:a+=1
  return a
 a=0
 while (x+1)%3**(a+1)==0:a+=1
 return max(l+R(k-1,2*(2**l*((x+1)//3**l)-1)) for l in range(a+1))
checks=0;viol=[];boundary=[]
for (x,r),m in best.items():
 if r<R(K,x):
  checks+=1
  if (x,r+1) not in best or best[x,r+1]>=m:viol.append((x,r,m,R(K,x),best.get((x,r+1))))
 else:boundary.append((x,r,m))
print('B',B,'exceptional',len(best),'nonterminal',checks,'terminal',len(boundary),'violations',viol[:10]);print('maxr',max(r for x,r in best),'maxendpoint',max(x for x,r in best));print('first',sorted(best.items())[:8])
assert B == 188
assert len(best) == 168
assert checks == 102
assert len(boundary) == 66
assert not viol
print('PASS: global six-even finite certificate')
