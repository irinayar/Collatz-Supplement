using System.Linq;
using System;
using System.Collections.Generic;
using System.Numerics;
// Valuation reduction test: for x+1=3^a u (3 not| u), a>m, claim H_k(x,r)=H_k(x*,r-a+m) for all r>=a (inf included), x*=3^m 2^(a-m) u -1 (v3(x*+1)=m).
// Also ChatGPT 144115 counterexample, K088 items (a=0 shift, r<=a formula).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    Console.WriteLine($"ChatGPT 144115 check: H_5(224,r), r=0..6: {string.Join(",",new[]{0,1,2,3,4,5,6}.Select(r=>H(224,5,r)))}; H_5(149,4)={H(149,5,4)}");
    for(int k=2;k<=7;k++){ var line=new System.Text.StringBuilder($"k={k}: failures of reduction to valuation m (cases) "); 
      for(int m=1;m<=5;m++){ long cases=0,bad=0; for(int a=m+1;a<=m+4;a++) for(int u=1;u<=120;u++){ if(u%3==0) continue; BigInteger x=B3(a)*B2(0)*u-1, xs=B3(m)*B2(a-m)*u-1;
          for(int r=a;r<=a+12;r++){ cases++; if(H(x,k,r)!=H(xs,k,r-a+m)) bad++; } if(hm.Count>3000000) hm.Clear(); }
        line.Append($"m={m}: {bad}/{cases}; "); hm.Clear(); }
      Console.WriteLine(line.ToString()); }
    long c0=0,b0=0,c1=0,b1=0; for(int x=1;x<=1000;x++){ int a=V3(x+1); BigInteger u=(x+1)/B3(a); for(int r=0;r<=a;r++){ c1++; if(H(x,5,r)!=32*(B2(r)*B3(a-r)*u-1)) b1++; } if(a==0) for(int r=0;r<=14;r++){ c0++; if(H(x,5,r)!=H(2*(BigInteger)x,4,r)) b0++; } }
    Console.WriteLine($"K088 item1 (a=0: H_5(x,r)=H_4(2x,r)) {b0}/{c0} failures; item2 (r<=a: 32(2^r 3^(a-r) u -1)) {b1}/{c1} failures");
  }
}
