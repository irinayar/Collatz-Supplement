using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 151108 (five-even short-branch dominance in terms of q=2^(a-2)u) and of the takeover gap M_4 - S_5 = 8N/27 - 5, N = 64q-7.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    var pat=new SortedDictionary<string,long>(); long bgtM_in_overlap=0, overlapBM=0;
    for(int q=1;q<=6000;q++){ if(q%3==0) continue; BigInteger Q=q; var sb=new System.Text.StringBuilder(); char prev=' ';
      for(int s=2;s<=24;s++){ var S=H(18*Q-2,4,s); var M=H(12*Q-2,4,s-1); var B=H(8*Q-2,4,s-2); BigInteger mn=INF; char arg=' '; if(S!=INF){mn=S;arg='S';} if(M!=INF&&(mn==INF||M<mn)){mn=M;arg='M';} if(B!=INF&&(mn==INF||B<mn)){mn=B;arg='B';} if(M!=INF&&B!=INF){ overlapBM++; if(B<M) bgtM_in_overlap++; }
        if(mn==INF) break; if(arg!=prev){ sb.Append(arg); prev=arg; } }
      string key=$"q mod 3={q%3}: argmin pattern {sb}"; pat[key]=pat.GetValueOrDefault(key)+1; hm.Clear(); }
    foreach(var kv in pat) Console.WriteLine(kv.Key+": "+kv.Value);
    Console.WriteLine($"M and B both finite: {overlapBM} cells, of which B < M: {bgtM_in_overlap}");
  }
}
