using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 142944: x+1=3u (3 not| u), A=6u-2, B=4u-2, C=4u-1, P_r=L_3(A,r), Q_r=L_3(B,r-1), L_4(x,r)=min(P_r,Q_r).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long cases=0,bad=0,gDiv3=0,row1=0,row2=0,row3=0; 
    for(int u=1;u<=6000;u++){ if(u%3!=1) continue; BigInteger A=6*(BigInteger)u-2,Bn=4*(BigInteger)u-2,C=4*(BigInteger)u-1; int c=V3(C); BigInteger v=C/B3(c); BigInteger G=B2(c+1)*v-1;
      var Pr=new BigInteger[60]; var Qr=new BigInteger[60]; for(int r=0;r<60;r++){ Pr[r]=H(A,3,r); Qr[r]=r>=1?H(Bn,3,r-1):INF; }
      cases++; if(G%3==0){ gDiv3++; if(Pr[c+2]!=INF) bad++; if(Qr[c+2]==INF) bad++; hm.Clear(); continue; }
      BigInteger J=2*G+1; int d=V3(J); BigInteger j=J/B3(d); BigInteger E=B2(d+1)*j-1; int f=V3(E); int q=V3(2*J-3); bool ok=true;
      for(int t=1;t<=d+f+2;t++){ BigInteger pf=INF; if(t<=d) pf=B2(t+1)*J/B3(t)-2; else if(t<=d+f) pf=B2(t-d)*E/B3(t-d)-1; if(Pr[c+1+t]!=pf) ok=false; }
      for(int t=1;t<=q+2;t++){ BigInteger qf=INF; if(t<=q) qf=B2(t)*(2*J-3)/B3(t)-1; if(Qr[c+1+t]!=qf) ok=false; }
      if(d>=2){ row1++; if(!(q==1 && d+f>=2)) ok=false; } else if(j%3==1){ row2++; if(!(q==1 && 1+V3(4*j-1)>=2)) ok=false; } else { row3++; if(!(1+V3(2*j-1)>=2 && d+f==1)) ok=false; }
      if(!ok) bad++; hm.Clear(); }
    Console.WriteLine($"u=1 mod 3, u<=6000: cases {cases}, G=0 mod 3: {gDiv3}; G=1 mod 3 table rows d>=2: {row1}, d=1&j=1: {row2}, d=1&j=2: {row3}; failures of late P/Q formulas, last-index table and G=0 claim: {bad}");
  }
}
