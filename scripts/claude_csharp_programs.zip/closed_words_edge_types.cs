using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static readonly string[] Types = { "++", "+-", "-+", "--" };
  static int TI(bool a, bool b) => (a ? 0 : 2) + (b ? 0 : 1) ; // ++:0 +-:1 -+:2 --:3
  static (int,Int128) Pos(Int128 x, bool up) => up ? (0, -x) : (1, x);
  static int Cmp((int,Int128) a, (int,Int128) b) => a.Item1 != b.Item1 ? a.Item1.CompareTo(b.Item1) : a.Item2.CompareTo(b.Item2);
  static bool Cross((int,Int128) a, (int,Int128) b, (int,Int128) c, (int,Int128) d) {
    if (Cmp(a, b) > 0) { var t = a; a = b; b = t; }
    bool cin = Cmp(a, c) < 0 && Cmp(c, b) < 0, din = Cmp(a, d) < 0 && Cmp(d, b) < 0; return cin != din;
  }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    // stats[k]: words, minTotal, per pair-type (10 unordered type pairs): words with >=1 crossing, min count
    var words = new Dictionary<int,long>(); var minTot = new Dictionary<int,long>(); var pairHas = new Dictionary<int,long[]>(); var pairMin = new Dictionary<int,long[]>();
    var minExample = new Dictionary<int,string>();
    var pairName = new string[16]; int[,] pid = new int[4, 4]; int np = 0;
    for (int i = 0; i < 4; i++) for (int j = i; j < 4; j++) { pid[i, j] = pid[j, i] = np; pairName[np] = Types[i] + "/" + Types[j]; np++; }
    long total = 0, skipped = 0; int[] cap = { 0, 1, 2, 5, 6, 8, 9 }; var subMin = new Dictionary<int, long[]>(); var allCnt = new List<(int k, long[] c)>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        // canonical: smallest rotation, aperiodic
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w);
        Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3;
        if (p3 >= p2) continue;
        // letters e_i = bit i of w (1=odd)
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        // U: S^L(x) = (3^A x + U)/2^L with U computed by recursion A_{w1}=3A_w+2^{|w|}
        Int128 U = 0; for (int i = 0; i < L; i++) { if (e[i]) U = 3 * U + ((Int128)1 << i); }
        Int128 D = p2 - p3; // x* = U/D
        // vertices scaled by D*2^L : X_0 = U*2^L ; step: odd (3X + D*2^L)/2 ; even X/2
        Int128 scale = D * p2; Int128[] X = new Int128[L]; X[0] = U * p2; bool bad = false;
        for (int i = 0; i + 1 < L; i++) { X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2; }
        // check closure
        Int128 back = e[L - 1] ? (3 * X[L - 1] + scale) / 2 : X[L - 1] / 2; if (back != X[0]) { bad = true; }
        if (bad) { skipped++; continue; }
        if (X.Distinct().Count() < L) { skipped++; continue; }
        // number of ascent runs (cyclic)
        int k = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) k++;
        if (k < 1) continue;
        // chord types: edge i from vertex i (label e[i]) to vertex i+1 (label e[i+1])
        var cnt = new long[np]; long tot = 0;
        for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) {
          int[] ee = { i, (i + 1) % L, j, (j + 1) % L }; if (ee.Distinct().Count() < 4) continue;
          var a = Pos(X[i], e[i]); var b = Pos(X[(i + 1) % L], e[(i + 1) % L]); var c = Pos(X[j], e[j]); var d = Pos(X[(j + 1) % L], e[(j + 1) % L]);
          if (Cross(a, b, c, d)) { int ti = TI(e[i], e[(i + 1) % L]), tj = TI(e[j], e[(j + 1) % L]); cnt[pid[ti, tj]]++; tot++; }
        }
        total++; allCnt.Add((k, (long[])cnt.Clone()));
        if (!words.ContainsKey(k)) { words[k] = 0; minTot[k] = long.MaxValue; pairHas[k] = new long[np]; pairMin[k] = Enumerable.Repeat(long.MaxValue, np).ToArray(); minExample[k] = ""; }
        words[k]++; if (tot < minTot[k]) { minTot[k] = tot; minExample[k] = Convert.ToString(w, 2).PadLeft(L, (char)48) + $" (L={L},A={A}) types: " + string.Join(", ", Enumerable.Range(0, np).Where(q => cnt[q] > 0).Select(q => pairName[q] + "x" + cnt[q])); }
        for (int q = 0; q < np; q++) { if (cnt[q] > 0) pairHas[k][q]++; if (cnt[q] < pairMin[k][q]) pairMin[k][q] = cnt[q]; }
      }
    }
    Console.WriteLine($"primitive cyclic words with 3^A<2^L, L<={Lmax}, distinct real vertices: {total} (skipped {skipped})");
    foreach (var k in words.Keys.OrderBy(x => x)) {
      Console.WriteLine($"k={k} ascent runs: words {words[k]}, min total crossings {minTot[k]} (e.g. word bits {minExample[k]})");
      for (int q = 0; q < np; q++) Console.WriteLine($"    {pairName[q],-6} words with >=1 crossing {100.0 * pairHas[k][q] / words[k],6:F1}%   min count {pairMin[k][q]}");
    }
    // inclusion-minimal subsets of crossing-capable pair types that always contain a crossing
    int[] capable = { pid[0,0], pid[0,1], pid[0,2], pid[1,2], pid[1,3], pid[2,3], pid[3,3] };
    foreach (int kk in new[] { 2, 3, 4, 5 }) {
      var res = new List<int>();
      for (int mask = 1; mask < (1 << 7); mask++) {
        bool ok = true;
        foreach (var (k, c) in allCnt) { if (k != kk) continue; long s = 0; for (int b = 0; b < 7; b++) if ((mask >> b & 1) == 1) s += c[capable[b]]; if (s == 0) { ok = false; break; } }
        if (ok) res.Add(mask);
      }
      var minimal = res.Where(m => !res.Any(o => o != m && (o & m) == o)).ToList();
      Console.WriteLine($"k={kk}: inclusion-minimal sets of pair types with >=1 crossing in EVERY word: " + string.Join(" | ", minimal.Select(m => string.Join("+", Enumerable.Range(0, 7).Where(b => (m >> b & 1) == 1).Select(b => pairName[capable[b]])))));
    }
  }
}
