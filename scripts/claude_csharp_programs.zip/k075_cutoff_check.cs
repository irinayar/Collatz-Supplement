using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of Codex 114426 (K075): X_j = (y+1)(2/3)^(a-1) - n/2^(e+1); (i) X_j >= 1 implies no smaller origin with fewer odd steps;
// (ii) dynamics: odd next input X unchanged, even next input X' = (X + (2/3)^(a-1))/2; (iii) X_j - (2/3)^(a-1) >= n/2^e > 0.
class P {
  static void Main() {
    long N = 3000; int J = 16; long cases = 0, geq1 = 0, viol = 0, dynBad = 0, lowerBad = 0, posBad = 0;
    var cnt = new int[N + 1]; var val = new long[N + 1]; for (int m = 1; m <= N; m++) val[m] = m;
    // precompute forward state of all origins at each depth incrementally
    var minLowerExists = new bool[N + 1];
    for (long n = 3; n <= N; n++) {
      long z = n; int a = 0; double prevX = 0; int prevA = 0; bool have = false;
      for (int j = 1; j <= J; j++) {
        bool odd = (z & 1) == 1; if (odd) a++; z = odd ? (3 * z + 1) / 2 : z / 2; if (a < 1) continue;
        int e = j - a; long y = z;
        BigInteger lhs = (BigInteger)(y + 1) * BigInteger.Pow(2, a - 1) * BigInteger.Pow(2, e + 1) - (BigInteger)n * BigInteger.Pow(3, a - 1);
        BigInteger one = BigInteger.Pow(3, a - 1) * BigInteger.Pow(2, e + 1);
        bool xge1 = lhs >= one; double X = (double)(y + 1) * Math.Pow(2.0 / 3.0, a - 1) - n / Math.Pow(2, e + 1);
        // (iii) positivity
        if (X - Math.Pow(2.0 / 3.0, a - 1) < n / Math.Pow(2, e) - 1e-9) posBad++;
        // (ii) dynamics
        if (have) { double expect = (a == prevA) ? (X_prev_even(prevX, a)) : prevX; if (Math.Abs(expect - X) > 1e-7 * Math.Max(1, Math.Abs(X))) dynBad++; }
        prevX = X; prevA = a; have = true;
        cases++;
        if (xge1) { geq1++; bool lower = false; for (long m = 1; m < n && !lower; m++) { long w = m; int c = 0; for (int i = 0; i < j; i++) { if ((w & 1) == 1) { c++; w = (3 * w + 1) / 2; } else w /= 2; } if (w == y && c < a) lower = true; } if (lower) viol++; }
      } }
    Console.WriteLine($"K075 check (n in 3..{N}, j<={J}): {cases} source-depth cases with a>=1; X_j>=1 in {geq1}; violations (a smaller origin with FEWER odd steps although X>=1): {viol}; dynamics mismatches {dynBad}; positivity failures {posBad}");
  }
  static double X_prev_even(double X, int a) => (X + Math.Pow(2.0 / 3.0, a - 1)) / 2;
}
