using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of Codex K146 (finite C4 census, odd 3<=n<=65535): C4 = {returns with g<=10} U {returns with at most four resets}.
// Sources u=3 mod 4 up to 87379; walk; at each reset endpoint w: record if (g<=10 || resets<=4), genuine thresholds odd n in [max(3,ceil((3max(u,w)+2)/4)), min(u,w,65535,floor((3z+1)/4))] (z = least proper state; none for g=1).
// Expect 5739 positive-charge intervals; S_C4(n)=sum over records active at n of c/(u+5); max at n=91 with sources 95,107,119 and charges 23/2025, 1/63, 11/837 (sum 17741/439425).
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=65535, srcMax=87379; int recs=0,neg=0; double[] Sx=new double[NMAX+2]; var at91=new List<string>(); int maxSteps=0;
    for(long u=3;u<=srcMax;u+=4){ long x=u; int g=0,resets=0; double G=1.0; var states=new List<long>(); BigInteger Bn=0; int Eacc=0; 
      for(int step=0;step<256;step++){ G*=1.0+1.0/(3.0*x); int e; long nx=A(x,out e); g++; Bn=3*Bn+(BigInteger.One<<Eacc); Eacc+=e; states.Add(nx); x=nx; if(step+1>maxSteps) maxSteps=step+1;
        if(e>=2){ resets++; long w=x; bool inFam=(g<=10||resets<=4);
          if(inFam){ long zz=long.MaxValue; for(int i=0;i<g-1;i++) if(states[i]<zz) zz=states[i]; // proper states u_1..u_{g-1} = states[0..g-2]
            long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(Math.Min(u,w),NMAX); if(g>1) hi=Math.Min(hi,(3*zz+1)/4); if((hi&1)==0) hi--;
            if(lo<=hi){ double rho=G*(1.0+5.0/w)/(1.0+5.0/u); double c=(u+5)*(rho-1); BigInteger cn=Bn+5*((BigInteger.One<<Eacc)-BigInteger.Pow(3,g)); if(cn>0){ recs++; double wgt=c/(u+5); for(long n=lo;n<=hi;n+=2) Sx[n]+=wgt; if(lo<=91&&91<=hi) at91.Add($"u={u}:{wgt:F8}"); } else neg++; } }
          if(w<=u) break; if(g>10&&resets>4) break; } } }
    double best=0; long bn=0; for(long n=3;n<=NMAX;n+=2) if(Sx[n]>best){best=Sx[n];bn=n;}
    Console.WriteLine($"C4 finite census (n<=65535): positive-charge intervals {recs} (negative {neg}); max S_C4 = {best:F9} at n={bn}; claimed 17741/439425={17741.0/439425:F9}; active at 91: {string.Join(", ",at91)}; expected 23/2025={23.0/2025:F8}, 1/63={1.0/63:F8}, 11/837={11.0/837:F8}");
  }
}
