using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of Codex K150 shared-anchor multiplicities: for threshold n (55, 4095, 65535): residual family = positive-charge first returns with g>=11 and >=5 resets; least source per exponent word; greedy slow/fast decomposition (ChatGPT 204556) of each least-source path;
// m(y) = number of least-source residual paths selecting slow state y. Claims: n=55: anchor 91 by sources 63,71; n=4095: anchor 8687 by 4575,5147; n=65535: anchor 109031 by 72687,76575,80671; 132 positive residual profiles at n=65535.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static long T(long v)=> (v&1)==1? (3*v+1)/2 : v/2;
  static bool Slow(long x){ int h=0; while((1L<<h)<x) h++; long v=x; for(int j=1;j<=h;j++){ v=T(v); if(2*v<x) return false; } return true; }
  static void Run(long n){
    long H=(4*n-2)/3; var best=new Dictionary<string,(long u,List<long> inputs)>(); int positive=0;
    for(long u=n;u<=H;u+=2){ if((u&3)!=3) continue; long x=u; int g=0,resets=0; var inputs=new List<long>{u}; var ev=new List<int>(); BigInteger Bn=0; int Ea=0; bool ret=false;
      for(int step=0;step<100000;step++){ int e; long nx=A(x,out e); g++; ev.Add(e); Bn=3*Bn+(BigInteger.One<<Ea); Ea+=e; if(e>=2) resets++; x=nx; if(x<=H){ ret=x>=n; break; } inputs.Add(x); }
      if(!ret) continue; BigInteger cn=Bn+5*((BigInteger.One<<Ea)-BigInteger.Pow(3,g)); if(cn<=0) continue; if(g<11||resets<5) continue;
      string key=string.Join(",",ev); if(!best.ContainsKey(key)) best[key]=(u,inputs); }
    var sel=new Dictionary<long,List<long>>();
    foreach(var kv in best){ var inputs=kv.Value.inputs; int g=inputs.Count; // shortcut states of the segment from source to arrival (arrival excluded from inputs); build state list
      var states=new List<long>(); long z=inputs[0]; // follow shortcut until reaching arrival state
      int oddSeen=0; while(oddSeen<g){ states.Add(z); if((z&1)==1) oddSeen++; z=T(z); }
      int idx=0; while(idx<states.Count){ long x=states[idx]; if((x&1)==0){ idx++; continue; } if(Slow(x)){ if(!sel.ContainsKey(x)) sel[x]=new List<long>(); sel[x].Add(kv.Value.u); idx++; }
        else { int j=idx+1; while(j<states.Count && 2*states[j]>=x) j++; idx=j; while(idx<states.Count && (states[idx]&1)==0) idx++; } } }
    int maxM=0; long argY=0; foreach(var kv in sel) if(kv.Value.Count>maxM){maxM=kv.Value.Count; argY=kv.Key;} if(sel.Count==0){ Console.WriteLine($"n={n}: H={H}, positive residual profiles: {best.Count}; no selected slow anchors"); return; }
    Console.WriteLine($"n={n}: H={H}, positive residual profiles (g>=11, resets>=5): {best.Count}; max multiplicity m(y) = {maxM} at anchor y={argY} from sources {string.Join(",",sel[argY])}; anchors with m>=2: {System.Linq.Enumerable.Count(sel,k=>k.Value.Count>=2)}");
    if(n==55 && sel.ContainsKey(91)) Console.WriteLine($"    anchor 91 selected by {string.Join(",",sel[91])}");
    if(n==4095 && sel.ContainsKey(8687)) Console.WriteLine($"    anchor 8687 selected by {string.Join(",",sel[8687])}");
    if(n==65535 && sel.ContainsKey(109031)) Console.WriteLine($"    anchor 109031 selected by {string.Join(",",sel[109031])}");
  }
  static void Main(){ foreach(long n in new long[]{55,91,255,1023,4095,65535}) Run(n); }
}
