using System;
using System.Collections.Generic;
using System.Numerics;
// Direct DFS of the inverse tree from x with exactly k even edges: min origin per odd count r (no recursion formula).
class P {
  static int EMAX; static BigInteger[] mn; static long nodes;
  static void Dfs(BigInteger z,int ev,int od){ nodes++; if(ev==EMAX){ if(mn[od]==0||z<mn[od]) mn[od]=z; }
    if(ev<EMAX) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    foreach(var (x,k) in new[]{(2L,20),(1L,20),(2L,19),(2L,21),(2L,22)}){ EMAX=k; mn=new BigInteger[80]; nodes=0; Dfs(x,0,0); var sb=new System.Text.StringBuilder();
      int R=-1; for(int r=0;r<80;r++) if(mn[r]!=0) R=r; for(int r=Math.Max(0,k-3);r<=R;r++) sb.Append($"r={r}:{mn[r]} "); Console.WriteLine($"x={x}, k={k}: R={R}, nodes {nodes}; min origins " + sb); }
  }
}
