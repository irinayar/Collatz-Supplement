using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
// Sieved search for cycle minima above 2^e:  n odd is a cycle minimum only if its orbit never drops below n.
// Residue sieve: for n = r mod 2^K the first K accelerated steps are fixed by r: x_K = (3^a n + c)/2^K.  If 3^a < 2^j and nMin*(2^j - 3^a) > c at some j <= K then
// the orbit of EVERY n >= nMin in that class drops below n within j steps (exact inequality, no heuristic).  Only the unresolved classes ("survivors") are simulated.
static class P {
  static int K; static UInt128 nMin; static List<uint> surv = new();
  static void Dfs(int j, ulong r, ulong a3, ulong c, int a) { // class r mod 2^j, x_j = (3^a n + c)/2^j, a3 = 3^a; children: bit j of n
    for (int b = 0; b < 2; b++) {
      ulong r2 = r | ((ulong)b << j); UInt128 val = (UInt128)a3 * r2 + c; int par = (int)((val >> j) & 1);
      ulong a3n = a3, cn = c; int an = a;
      if (par == 1) { a3n = a3 * 3; cn = 3 * c + (1UL << j); an = a + 1; }
      int jn = j + 1; // x_{j+1} = (3^an n + cn)/2^{jn}
      bool resolved = false; if (a3n < (1UL << jn)) { UInt128 d = (UInt128)((1UL << jn) - a3n); if (nMin * d > (UInt128)cn) resolved = true; }
      if (resolved) continue;
      if (jn == K) surv.Add((uint)r2); else Dfs(jn, r2, a3n, cn, an);
    }
  }
  static void Main(string[] args) {
    int e = int.Parse(args[0]); long blocks = long.Parse(args[1]); K = args.Length > 2 ? int.Parse(args[2]) : 32; long startBlockOffset = args.Length > 3 ? long.Parse(args[3]) : 0;
    UInt128 start = ((UInt128)1 << e) + 1; nMin = start;
    var t0 = DateTime.Now; // first step: n odd => x_1 = (3n+1)/2 : j=1, r=1, a=1, c=1
    ulong a3 = 3; if (!((3UL) < 2UL)) { }
    Dfs(1, 1UL, 3UL, 1UL, 1);
    Console.WriteLine($"K={K}: {surv.Count} unresolved odd residue classes mod 2^{K} ({(double)surv.Count / (1L << (K - 1)):P3} of the odd classes) built in {(DateTime.Now - t0).TotalSeconds:F1} s");
    uint[] sv = surv.ToArray(); UInt128 span = (UInt128)1 << K; UInt128 baseStart = (start >> K) << K; baseStart += span * (UInt128)startBlockOffset;
    long maxStop = 0; UInt128 maxStopN = 0; double maxPeak = 0; UInt128 maxPeakN = 0; long survivors = 0; long totalSim = 0; object lk = new object();
    for (long blk = 0; blk < blocks; blk++) {
      UInt128 bs = baseStart + span * (UInt128)blk; int chunks = 256; int per = (sv.Length + chunks - 1) / chunks; long bMaxStop = 0; UInt128 bMaxStopN = 0; double bMaxPeak = 0; UInt128 bMaxPeakN = 0; long bSurv = 0; long bSim = 0;
      Parallel.For(0, chunks, ch => {
        int i0 = ch * per, i1 = Math.Min(sv.Length, (ch + 1) * per); long lMaxStop = 0; UInt128 lMaxStopN = 0; double lMaxPeak = 0; UInt128 lMaxPeakN = 0; long lSurv = 0; long lSim = 0;
        for (int i = i0; i < i1; i++) {
          UInt128 n = bs + sv[i]; if (n < start) continue; UInt128 x = n, peak = n; int steps = 0; bool dropped = false; lSim++;
          while (steps < 1000000) { if ((x & 1) == 0) x >>= 1; else { x = (3 * x + 1) >> 1; if (x > peak) peak = x; } steps++; if (x < n) { dropped = true; break; } }
          if (!dropped) { lSurv++; Console.WriteLine("SURVIVOR " + n); continue; }
          if (steps > lMaxStop) { lMaxStop = steps; lMaxStopN = n; } double pr = (double)peak / (double)n; if (pr > lMaxPeak) { lMaxPeak = pr; lMaxPeakN = n; }
        }
        lock (lk) { bSim += lSim; bSurv += lSurv; if (lMaxStop > bMaxStop) { bMaxStop = lMaxStop; bMaxStopN = lMaxStopN; } if (lMaxPeak > bMaxPeak) { bMaxPeak = lMaxPeak; bMaxPeakN = lMaxPeakN; } }
      });
      totalSim += bSim; survivors += bSurv; if (bMaxStop > maxStop) { maxStop = bMaxStop; maxStopN = bMaxStopN; } if (bMaxPeak > maxPeak) { maxPeak = bMaxPeak; maxPeakN = bMaxPeakN; }
    }
    UInt128 end = baseStart + span * (UInt128)blocks; UInt128 baseE = (UInt128)1 << e;
    Console.WriteLine($"range n in [2^{e}+1, 2^{e} + {(double)(end - baseE):E3}) = {(double)(end - start) / 2:E3} odd values; classes simulated {totalSim:E3}; survivors (no descent within 1e6 steps): {survivors}; longest descent {maxStop} steps at n = 2^{e} + {maxStopN - baseE}; largest peak/n = {maxPeak:E3} at n = 2^{e} + {maxPeakN - baseE}; elapsed {(DateTime.Now - t0).TotalSeconds:F0} s");
  }
}
