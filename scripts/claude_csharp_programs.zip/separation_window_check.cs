using System;
using System.Collections.Generic;
using System.Numerics;
// ChatGPT 221416: separation U_{k,r+1}(x) < L_{k,r}(x) on x=3..150, k=0..9, r=0..8; counts, min gap, multi-origin cases; example (8,2,1); r=0 layer; dual criterion.
class P {
  static BigInteger[,] mn,mx,cnt; static void Dfs(BigInteger z,int ev,int od){ if(od<mn.GetLength(1)){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z; if(z>mx[ev,od]) mx[ev,od]=z; cnt[ev,od]+=1; } if(ev<9) Dfs(2*z,ev+1,od); if(od<9&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long pairs=0,fail=0,multi=0,layer0Bad=0; BigInteger minGap=BigInteger.Parse("1000000000000"); string argGap=""; string ex=""; long crit=0,critBad=0;
    for(long x=3;x<=150;x++){ mn=new BigInteger[10,10]; mx=new BigInteger[10,10]; cnt=new BigInteger[10,10]; Dfs(x,0,0);
      for(int k=0;k<=9;k++) for(int r=0;r<=8;r++){ if(mn[k,r]==0||mn[k,r+1]==0) continue; pairs++; var gap=mn[k,r]-mx[k,r+1]; if(gap<=0) fail++; if(gap<minGap){ minGap=gap; argGap=$"(x={x},k={k},r={r})"; } if(cnt[k,r]>1&&cnt[k,r+1]>1) multi++;
        if(x==8&&k==2&&r==1) ex=$"old [{mn[k,r]},{mx[k,r]}], successor [{mn[k,r+1]},{mx[k,r+1]}], gap {gap}";
        if(r==0&&!(mx[k,1]<mn[k,0])) layer0Bad++;
        // dual criterion: separation iff V_new_min > 3 V_old_max - 2^(k+r) x ; V from origins: V=2^L x - 3^r m
        BigInteger Vold_max=BigInteger.Pow(2,k+r)*x-BigInteger.Pow(3,r)*mn[k,r]; BigInteger Vnew_min=BigInteger.Pow(2,k+r+1)*x-BigInteger.Pow(3,r+1)*mx[k,r+1]; bool sep=gap>0; bool crit2=Vnew_min>3*Vold_max-BigInteger.Pow(2,k+r)*x; crit++; if(sep!=crit2) critBad++; } }
    Console.WriteLine($"x=3..150, k=0..9, r=0..8: pairs with both sets nonempty {pairs} (ChatGPT 4629); separation failures {fail}; min gap L_old-U_new = {minGap} at {argGap}; pairs with >1 origin in both sets {multi} (2968); example (8,2,1): {ex}; r=0 layer failures {layer0Bad}; dual criterion disagreements {critBad}/{crit}");
  }
}
