using System;
using System.Numerics;
// Independent replay of the 21 C108 families (Codex note 164917): for t=0..T,
// n=n0+P t, m=m0+Q t; T^{|target|}(m) must equal T^{|source|}(n), parities along both words must match, m<n.
class P {
  static string[] F = {
"604 729 423 512 - 111011010","433 729 303 512 - 111101010","1321 1458 927 1024 1 1111101100","273 1458 191 1024 1 1111110100",
"1090 2187 1019 2048 - 11011011010","919 2187 859 2048 - 11011101010","1807 4374 1691 4096 1 110111101100","2217 4374 2075 4096 1 110111110100",
"1171 2187 1095 2048 - 11101011010","1000 2187 935 2048 - 11101101010","4075 4374 3815 4096 1 111011101100","111 4374 103 4096 1 111011110100",
"325 2187 303 2048 - 11110101010","1213 4374 1135 4096 1 111101101100","2170 2187 2031 2048 - 11110111000","1623 4374 1519 4096 1 111101110100",
"2221 4374 2079 4096 1 111110101100","991 2187 927 2048 - 11111011000","2631 4374 2463 4096 1 111110110100","205 2187 191 2048 - 11111101000","1845 4374 1727 4096 1 111111010100"};
  static bool Run(BigInteger x, string w, out BigInteger y) {
    y = x;
    foreach (char c in w) {
      bool odd = !y.IsEven;
      if (odd != (c == '1')) return false;
      y = odd ? (3 * y + 1) / 2 : y / 2;
    }
    return true;
  }
  static void Main(string[] a) {
    int T = int.Parse(a[0]); long checks = 0, bad = 0;
    foreach (var f in F) {
      var s = f.Split(' ');
      BigInteger n0 = BigInteger.Parse(s[0]), P = BigInteger.Parse(s[1]), m0 = BigInteger.Parse(s[2]), Q = BigInteger.Parse(s[3]);
      string src = s[4] == "-" ? "" : s[4], tgt = s[5];
      for (int t = 0; t <= T; t++) {
        BigInteger n = n0 + P * t, m = m0 + Q * t, yn, ym;
        checks++;
        bool ok = Run(n, src, out yn) && Run(m, tgt, out ym) && yn == ym && m < n && m >= 1;
        if (!ok) bad++;
      }
    }
    Console.WriteLine($"families {F.Length}, t=0..{T}: checks {checks}, failures {bad}");
  }
}
