using System;
using System.Collections.Generic;
using System.Linq;
// Cluster-level analysis of q | U for flat words.  Unit = primitive cyclic word (q | U is rotation invariant: 2U(b') = 3^{b0}U(b) + b0 D, q | D odd).
// Population per cluster (L,A): all primitive cyclic words without isolated odd step, 3^A < 2^L, distinct vertices.  Flat = values >= 1 and every excursion strictly (P_R, V_L).
static class P {
  class Cl { public long nAll, nFlat; public Dictionary<long, (long all, long flat)> q = new(); public List<long> primes; }
  static List<long> OddPrimeFactors(long d) { var r = new List<long>(); while (d % 2 == 0) d /= 2; for (long p = 3; p * p <= d; p += 2) if (d % p == 0) { r.Add(p); while (d % p == 0) d /= p; } if (d > 1) r.Add(d); return r; }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); var cl = new SortedDictionary<(int, int), Cl>(); long intAll = 0, intFlat = 0;
    for (int L = 4; L <= Lmax; L++) {
      ulong mask = (1UL << L) - 1; Int128 p2 = (Int128)1 << L;
      for (ulong w = 1; w < mask; w++) {
        ulong rl = ((w << 1) | (w >> (L - 1))) & mask, rr = ((w >> 1) | (w << (L - 1))) & mask; if ((w & ~rl & ~rr) != 0) continue;
        int A = System.Numerics.BitOperations.PopCount(w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool canon = true; for (int r = 1; r < L && canon; r++) { ulong rot = ((w << r) | (w >> (L - r))) & mask; if (rot <= w) canon = false; } if (!canon) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        int s0 = -1; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) { s0 = i; break; }
        var f = new bool[L]; for (int i = 0; i < L; i++) f[i] = e[(s0 + i) % L]; e = f;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        Int128 c = X.Min(), H = X.Max(), S = c + H; bool ok = c >= scale;
        for (int i = 0; i < L && ok; i++) if (e[i] && !e[(i + L - 1) % L]) { int r = 0, j = i; while (e[j % L]) { r++; j++; } int a = (j - 1) % L, p = j % L; while (!e[j % L]) j++; int b = (j - 1) % L; if (!(X[a] + X[p] > S && 3 * X[b] < 2 * S)) ok = false; }
        var key = (L, A); if (!cl.TryGetValue(key, out var C)) { C = new Cl(); C.primes = OddPrimeFactors((long)D); cl[key] = C; foreach (var q in C.primes) C.q[q] = (0, 0); }
        C.nAll++; if (ok) C.nFlat++; if (U % D == 0) { intAll++; if (ok) intFlat++; }
        foreach (var q in C.primes) if (U % q == 0) { var t = C.q[q]; C.q[q] = (t.all + 1, t.flat + (ok ? 1 : 0)); }
      }
      Console.Error.WriteLine("done L=" + L);
    }
    Console.WriteLine($"integer fixed points: among all no-isolated-one primitive words {intAll}, among flat words {intFlat}");
    // CMH for flat vs non-flat, strata = (cluster, prime)
    double sumObs = 0, sumExp = 0, sumVar = 0; int strata = 0, usable = 0;
    // all-words vs 1/q
    double aObs = 0, aExp = 0, aVar = 0;
    Console.WriteLine("cluster (L,A): nAll nFlat | prime: hits_all hits_flat  (expected flat hits under independence, p-value approx)");
    foreach (var kv in cl) {
      var C = kv.Value; if (C.primes.Count == 0) continue;
      foreach (var q in C.primes) { var t = C.q[q]; long N = C.nAll, nf = C.nFlat, non = N - nf; strata++;
        aObs += t.all; aExp += (double)N / q; aVar += N * (1.0 / q) * (1 - 1.0 / q);
        if (nf == 0 || non == 0 || N < 2) continue; double hits = t.all; double E = nf * hits / N; double V = nf * (double)non * hits * (N - hits) / ((double)N * N * (N - 1));
        sumObs += t.flat; sumExp += E; sumVar += V; usable++;
        if (nf >= 15) Console.WriteLine($"  ({kv.Key.Item1},{kv.Key.Item2}): {N} {nf} | q={q}: {t.all} {t.flat} (E={E:F1}, sd={Math.Sqrt(V):F1}, z={(V > 0 ? (t.flat - E) / Math.Sqrt(V) : 0):F2})");
      }
    }
    var qa = new SortedDictionary<long, (long n, long h, long nf, long hf, int ncl)>(); foreach (var kv in cl) foreach (var q in kv.Value.primes) { var t = kv.Value.q[q]; var c0 = qa.GetValueOrDefault(q); qa[q] = (c0.n + kv.Value.nAll, c0.h + t.all, c0.nf + kv.Value.nFlat, c0.hf + t.flat, c0.ncl + 1); } Console.WriteLine("pooled by prime q (all no-isolated-one necklaces over clusters whose D is divisible by q): q: words, hits (observed/expected 1/q), flat words, flat hits, clusters"); foreach (var kv in qa.Where(k => k.Key < 200 && k.Value.n > 2000)) Console.WriteLine($"  q={kv.Key}: words {kv.Value.n}, hits {kv.Value.h} (ratio obs/exp {kv.Value.h * (double)kv.Key / kv.Value.n:F3}), flat {kv.Value.nf}, flat hits {kv.Value.hf}, clusters {kv.Value.ncl}");
    Console.WriteLine($"CMH flat vs other no-isolated-one words: strata (cluster,prime) {strata}, usable {usable}: observed flat hits {sumObs}, expected {sumExp:F1}, sd {Math.Sqrt(sumVar):F1}, z = {(sumObs - sumExp) / Math.Sqrt(sumVar):F2}");
    Console.WriteLine($"All no-isolated-one words vs 1/q: observed hits {aObs}, expected {aExp:F1}, sd {Math.Sqrt(aVar):F1}, z = {(aObs - aExp) / Math.Sqrt(aVar):F2}  (rotation orbits as units)");
    Console.WriteLine($"total no-isolated-one primitive necklaces with 3^A<2^L: {cl.Sum(k => k.Value.nAll)}"); Console.WriteLine($"clusters {cl.Count}, clusters with flat words {cl.Count(k => k.Value.nFlat > 0)}, total flat {cl.Sum(k => k.Value.nFlat)}");
  }
}
