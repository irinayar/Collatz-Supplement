using System; using System.Numerics;
// K202 obstruction inequalities: (3^r-1)/2^L+(2000/77)rho^(r+1)+(L+1)2^(1-L) >= rho^L (rho=1923/2000), rho^9/2>3/256, 1/48<rho^8, 2rho^8>7/5, and the k=33 growth value (rho^9/32)(2rho^8)^k.
class P { static void Main(){ BigInteger a=1923, b=2000; int bad=0; long tot=0; double minGap=1e9;
 for(int L=0;L<=300;L++) for(int r=0;r<=700;r++){ // exact: multiply by 77*2^L*b^(r+1) ... use doubles in log domain with exact check for the two-case argument
   double lhs=(Math.Pow(3,Math.Min(r,600))-1)/Math.Pow(2,L); if(r>600) lhs=1e300; double lo=Math.Pow(1923.0/2000,L); double v=lhs+(2000.0/77)*Math.Pow(1923.0/2000,r+1)+(L+1)*Math.Pow(2,1-L); tot++; if(v<lo*(1-1e-12)) bad++; if(v/lo<minGap) minGap=v/lo; }
 Console.WriteLine($"(L,r) grid 0..300 x 0..700: {tot} cases, violations={bad}, min LHS/rho^L={minGap:F4}");
 Console.WriteLine("(2000/77)*rho>1: "+(2000*1923>77*2000)+";  rho^9/2>3/256: "+(BigInteger.Pow(1923,9)*256>2*3*BigInteger.Pow(2000,9))+";  1/48<rho^8: "+(BigInteger.Pow(1923,8)*48>BigInteger.Pow(2000,8))+";  2rho^8>7/5: "+(2*BigInteger.Pow(1923,8)*5>7*BigInteger.Pow(2000,8)));
 double rho=1923.0/2000; foreach(int k in new[]{33,46}) Console.WriteLine($"k={k}: (rho^9/32)(2 rho^8)^k = {Math.Pow(rho,9)/32*Math.Pow(2*Math.Pow(rho,8),k):F6}");
 // alternative reading: sum >= 2^k/16 sources * rho^(8k+9)/2
 Console.WriteLine($"k=33: 2^33/16*rho^(8*33+9)/2 = {Math.Pow(2,33)/16*Math.Pow(rho,8*33+9)/2:F6}");
}}
