using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
// Seam-aware letter-level DP: counts anchored words (first letter 1, last letter 0 = seam is a 0-1 boundary), every maximal run of ones has length >= 2,
// L letters, A ones, with U = sum 2^i 3^{#ones after i} congruent to r mod M (U_{i+1} = 3 U_i + 2^i on a one).
static class P {
  static double[] Count(int L, int A, int M) { // returns counts by residue (as doubles)
    // state arrays [a][v][st]
    var cur = new double[A + 1, M, 3]; cur[0, 0, 0] = 1; int p2 = 1 % M;
    for (int i = 0; i < L; i++) {
      var nxt = new double[A + 1, M, 3];
      for (int a = 0; a <= Math.Min(i, A); a++) for (int v = 0; v < M; v++) for (int st = 0; st < 3; st++) {
        double c = cur[a, v, st]; if (c == 0) continue;
        if (i > 0 && (st == 0 || st == 2)) nxt[a, v, 0] += c;                       // letter 0
        if (a < A) { int nv = (3 * v + p2) % M; nxt[a + 1, nv, st == 0 ? 1 : 2] += c; } // letter 1
      }
      cur = nxt; p2 = p2 * 2 % M;
    }
    var res = new double[M]; for (int v = 0; v < M; v++) res[v] = cur[A, v, 0]; return res;
  }
  static void Main(string[] args) {
    // 1. validation against brute force for small L
    for (int L = 6; L <= 16; L += 5) for (int A = 3; A < L; A += 4) { int M = 7; var dp = Count(L, A, M); var bf = new double[M];
        for (long w = 0; w < (1L << L); w++) { if (((w >> 0) & 1) == 0 || ((w >> (L - 1)) & 1) == 1) continue; if (System.Numerics.BitOperations.PopCount((ulong)w) != A) continue;
          bool ok = true; int run = 0; for (int i = 0; i < L; i++) { if (((w >> i) & 1) == 1) run++; else { if (run == 1) ok = false; run = 0; } } if (!ok) continue;
          long U = 0; for (int i = 0; i < L; i++) if (((w >> i) & 1) == 1) U = (3 * U + (1L << i)) % M; bf[U]++; }
        Console.WriteLine($"validation L={L} A={A} M={M}: DP {string.Join(",", dp.Select(x => (long)x))} brute {string.Join(",", bf.Select(x => (long)x))} {(dp.Select(x => (long)x).SequenceEqual(bf.Select(x => (long)x)) ? "OK" : "MISMATCH")}"); }
    // 2. large L: for each cluster (L,A) with D>0 and small prime q | D: fraction of anchored no-isolated words with q | U
    int Lmax = int.Parse(args[0]); int[] primesList = Enumerable.Range(5, 200).Where(n => n % 2 == 1 && n % 3 != 0 && Enumerable.Range(2, (int)Math.Sqrt(n)).All(d => d < 2 || n % d != 0 || d == n)).ToArray(); var agg = new SortedDictionary<int, (double tot, double hit, int ncl, int zeroUnreach)>();
    for (int L = 20; L <= Lmax; L += 2) for (int A = 2; A < L; A++) {
      BigInteger D = BigInteger.Pow(2, L) - BigInteger.Pow(3, A); if (D <= 0) continue;
      foreach (int q in new[] { 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43 }) { if (!(D % q).IsZero) continue;
        var dp = Count(L, A, q); double tot = dp.Sum(); var t = agg.GetValueOrDefault(q); agg[q] = (t.tot + tot, t.hit + dp[0], t.ncl + 1, t.zeroUnreach + (dp[0] == 0 ? 1 : 0)); }
    }
    Console.WriteLine("excluded classes (no anchored word without isolated 1 has q | U, and D > 0; q prime | D):"); var exl = new List<string>(); for (int L = 4; L <= Lmax; L++) for (int A = 2; A < L; A++) { BigInteger D = BigInteger.Pow(2, L) - BigInteger.Pow(3, A); if (D <= 0) continue; foreach (int q in primesList) { if (!(D % q).IsZero) continue; var dp = Count(L, A, q); double tot = dp.Sum(); if (tot > 0 && dp[0] == 0) exl.Add($"(L={L},A={A},q={q}: words {tot:E2})"); } } Console.WriteLine(exl.Count + " classes: " + string.Join(" ", exl.Take(60))); var big = exl.Where(s => double.Parse(s.Substring(s.IndexOf("words ") + 6).TrimEnd(')')) > 1e4).ToList(); Console.WriteLine("with more than 1e4 words: " + (big.Count == 0 ? "none" : string.Join(" ", big)));
    foreach (var kv in agg) Console.WriteLine($"q={kv.Key}: clusters {kv.Value.ncl} (L even 20..{Lmax}), total anchored words {kv.Value.tot:E3}, with q|U fraction {kv.Value.hit / kv.Value.tot:F4} (1/q = {1.0 / kv.Key:F4}, ratio {kv.Value.hit / kv.Value.tot * kv.Key:F3}); classes with zero residue unreachable: {kv.Value.zeroUnreach}");
  }
}
