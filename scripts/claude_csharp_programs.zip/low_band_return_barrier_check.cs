using System;
// Exhaustive check of ChatGPT 135000 Low-Band Return Barrier for ALL odd u (not only trajectory states): n odd >=3, 0<=H<(n-1)/3, I=[n,n+H].
//  (1) u in I odd, F(u)>=n  =>  v2(3u+1)=1 and F(u)>n+H.   (2) p>=n odd, F(p) in I  =>  v2(3p+1)>=2 and p>=(4n-1)/3.
// Also tightness: largest H for which (1) holds, compared with floor((n-2)/3).
class P {
  static void F(long u,out long f,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} f=x; }
  static void Main(){
    long bad1=0,bad2=0,cases1=0,cases2=0,badTight=0; 
    for(long n=3;n<=60001;n+=2){
      long Hmax=(n-2)/3; // largest integer H with H<(n-1)/3  (n-1 divisible by 2; check below)
      while(3*(Hmax+1)<n-1) Hmax++; while(3*Hmax>=n-1) Hmax--; 
      for(long u=n;u<=n+Hmax;u+=2){ F(u,out long f,out int e); if(f>=n){ cases1++; if(e!=1 || f<=n+Hmax) bad1++; } }
      // (2) p odd from n to 4n
      for(long p=n;p<=4*n;p+=2){ F(p,out long v,out int e); if(v>=n && v<=n+Hmax){ cases2++; if(e<2 || 3*p<4*n-1) bad2++; } }
      // tightness: largest H0 such that for all odd u in [n,n+H0]: F(u)>=n => e==1. Expect floor((4n-2)/3)-n.
      long H0=-1; for(long h=0;h<=n;h++){ long u=n+h; if((u&1)==0){ H0=h; continue; } F(u,out long f,out int e); if(f>=n && e!=1) break; H0=h; }
      long expect=(4*n-2)/3-n; if(H0!=expect && !(H0>expect)) badTight++;
    }
    Console.WriteLine($"cases (1): {cases1}, violations {bad1}; cases (2): {cases2}, violations {bad2}; tightness mismatches {badTight}");
  }
}
