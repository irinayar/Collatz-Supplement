using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 131849: for b >= 3, max numerator over all words (length j, b odd positions) with V = r (mod 27) equals max F_b(q,p,l) over b-3 <= q < p < l < j with
// 9*2^q + 3*2^p + 2^l = r (mod 27), F = 27*2^(q-b+3)*(3^(b-3)-2^(b-3)) + 9*2^q + 3*2^p + 2^l ; empty iff no triple.
class P {
  static void Main() {
    long comps = 0, bad = 0, nonempty = 0, empty = 0, strictVsMod9 = 0;
    for (int j = 3; j <= 16; j++) {
      var best = new Dictionary<(int, int), BigInteger>(); var best9 = new Dictionary<(int, int), BigInteger>();
      for (int w = 0; w < (1 << j); w++) { int b = BitOperations.PopCount((uint)w); if (b < 3) continue; var pos = new int[b]; int c = 0; for (int i = 0; i < j; i++) if (((w >> i) & 1) == 1) pos[c++] = i;
        BigInteger V = 0; for (int t = 0; t < b; t++) V += BigInteger.Pow(2, pos[t]) * BigInteger.Pow(3, b - 1 - t);
        var k27 = (b, (int)(V % 27)); if (!best.TryGetValue(k27, out var cur) || V > cur) best[k27] = V;
        var k9 = (b, (int)(V % 9)); if (!best9.TryGetValue(k9, out var c9) || V > c9) best9[k9] = V; }
      for (int b = 3; b <= j; b++) for (int r = 0; r < 27; r++) {
        BigInteger e = -1; bool any = false;
        for (int q = b - 3; q < j; q++) for (int p = q + 1; p < j; p++) for (int l = p + 1; l < j; l++) {
          int res = (int)((9 * BigInteger.Pow(2, q) + 3 * BigInteger.Pow(2, p) + BigInteger.Pow(2, l)) % 27); if (res != r) continue;
          BigInteger F = 27 * BigInteger.Pow(2, q - b + 3) * (BigInteger.Pow(3, b - 3) - BigInteger.Pow(2, b - 3)) + 9 * BigInteger.Pow(2, q) + 3 * BigInteger.Pow(2, p) + BigInteger.Pow(2, l);
          if (!any || F > e) { e = F; any = true; } }
        bool has = best.TryGetValue((b, r), out var truth); comps++;
        if (has != any || (has && truth != e)) bad++; if (has) { nonempty++; if (best9.TryGetValue((b, r % 9), out var m9) && truth < m9) strictVsMod9++; } else empty++; } }
    Console.WriteLine($"mod-27 last-three-positions maximum vs exhaustive enumeration (j<=16, b>=3, all 27 residues): {comps} cells, nonempty {nonempty}, empty {empty}, mismatches {bad}; nonempty cells strictly below their mod-9 parent maximum: {strictVsMod9}");
  }
}
