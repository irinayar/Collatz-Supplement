using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
// Monte Carlo check of the named-rule densities at depths 32 and 100 (Codex ledger / v6 Approach 68).
// n is a uniform random 128-bit integer. Parity of the first 100 steps depends only on the low bits; we iterate the
// accelerated map on UInt128 (wraparound mod 2^128 keeps >= 28 correct low bits after 100 steps; only parity is used).
// covered_T(n) = crossing within T steps (3^a < 2^i) OR finite-ledger rule OR C08 (1^k00, k=1..98) OR C85 cylinder mod 2^27.
class P {
  static ulong Mix(ref ulong s) { s += 0x9E3779B97F4A7C15UL; ulong z = s; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL; return z ^ (z >> 31); }
  static void Main(string[] a) {
    string root = a[0]; long N = long.Parse(a[1]);
    var inv = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/targets_E16/counting_inventory_updated.json"))).RootElement;
    var rules = new List<(UInt128 r, UInt128 m)>();
    foreach (var z in inv.GetProperty("finite_ledger").EnumerateArray())
      rules.Add((z.GetProperty("residue").GetUInt64(), z.GetProperty("modulus").GetUInt64()));
    var c85 = new bool[1 << 27];
    foreach (var c in JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/v2_audit/parent27_certificates.json"))).RootElement.GetProperty("certificates").EnumerateArray())
      if (c.GetProperty("meeting").ValueKind != JsonValueKind.Null && c.GetProperty("descent").ValueKind == JsonValueKind.Null) c85[c.GetProperty("n").GetInt64()] = true;
    var c08 = new List<(UInt128 r, UInt128 mask)>();
    for (int k = 1; k <= 98; k++) {
      BigInteger m = BigInteger.One << (k + 2), p3 = BigInteger.Pow(3, k), p2 = BigInteger.Pow(2, k);
      BigInteger r = (((-(p3 - p2) * BigInteger.ModPow(p3, (m >> 1) - 1, m)) % m) + m) % m;
      c08.Add(((UInt128)r, (UInt128)(m - 1)));
    }
    int[] minI = new int[101];  // smallest i with 2^i > 3^a
    for (int aa = 0; aa <= 100; aa++) { BigInteger p = BigInteger.Pow(3, aa); int i = 0; while ((BigInteger.One << i) <= p) i++; minI[aa] = i; }
    var rr = rules.ToArray(); var cc = c08.ToArray();
    long unc32 = 0, unc100 = 0, cross32 = 0, cross100 = 0;
    int threads = Environment.ProcessorCount * 4; long per = N / threads;
    Parallel.For(0, threads, ti => {
      ulong seed = 0x1234567UL * (ulong)(ti + 1) + 99991UL; long u32 = 0, u100 = 0, c32 = 0, c100 = 0;
      for (long s = 0; s < per; s++) {
        UInt128 n = ((UInt128)Mix(ref seed) << 64) | Mix(ref seed);
        UInt128 x = n; int ones = 0; int crossAt = 0;
        for (int i = 1; i <= 100; i++) {
          if ((x & 1) == 1) { ones++; x = (x * 3 + 1) >> 1; } else x >>= 1;
          if (i >= minI[ones]) { crossAt = i; break; }
        }
        bool cr32 = crossAt != 0 && crossAt <= 32, cr100 = crossAt != 0;
        if (cr32) c32++; if (cr100) c100++;
        if (cr100 && cr32) continue;           // covered at both depths
        // rule coverage (rules independent of depth)
        bool cov = false;
        for (int q = 0; q < rr.Length && !cov; q++) if (n % rr[q].m == rr[q].r) cov = true;
        if (!cov) for (int q = 0; q < cc.Length; q++) if ((n & cc[q].mask) == cc[q].r) { cov = true; break; }
        if (!cov && c85[(int)(n & ((1UL << 27) - 1))]) cov = true;
        if (!cr32 && !cov) u32++;
        if (!cr100 && !cov) u100++;
      }
      Interlocked.Add(ref unc32, u32); Interlocked.Add(ref unc100, u100); Interlocked.Add(ref cross32, c32); Interlocked.Add(ref cross100, c100);
    });
    long tot = per * threads;
    BigInteger n32 = BigInteger.Parse("7819534701173808307942939"), d32 = BigInteger.Parse("7851540464532429050216448");
    BigInteger n100 = BigInteger.Parse("3314677350650191953815398926478618333333"), d100 = BigInteger.Parse("3315018254095557987741203092073802104832");
    double cl32 = (double)(d32 - n32) / (double)d32, cl100 = (double)(d100 - n100) / (double)d100;
    Console.WriteLine($"samples {tot}");
    Console.WriteLine($"depth 32 : crossing fraction {(double)cross32 / tot:F8} (claimed 0.99037304); uncovered {unc32} => {(double)unc32 / tot:E5} +- {Math.Sqrt(unc32) / tot:E2}; claimed {cl32:E5}");
    Console.WriteLine($"depth 100: crossing fraction {(double)cross100 / tot:F8}; uncovered {unc100} => {(double)unc100 / tot:E5} +- {Math.Sqrt(unc100) / tot:E2}; claimed {cl100:E5}");
  }
}
