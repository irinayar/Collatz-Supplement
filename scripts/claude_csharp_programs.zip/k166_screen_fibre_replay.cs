using System; using System.IO; using System.Collections.Generic; using System.Linq; using System.Numerics; using System.Text.Json;
class P { static void Main(string[] args){
  var doc=JsonDocument.Parse(File.ReadAllText(args[0])).RootElement.GetProperty("saved");
  long prefixes=0,narrow=0,narrowNonDesc=0,narrowHigh=0,paths=0,distinct=0; var seenU=new HashSet<BigInteger>();
  foreach(var p in doc.EnumerateArray()){ paths++; var ue=p.GetProperty("u"); BigInteger u=BigInteger.Parse(ue.ValueKind==JsonValueKind.String?ue.GetString():ue.GetRawText()); seenU.Add(u);
    BigInteger x=u; int j=0,a=0; foreach(var e in p.GetProperty("word").EnumerateArray()) for(int k=0;k<e.GetInt32();k++){ bool odd=!x.IsEven; if(odd)a++; j++; x=odd?(3*x+1)/2:x/2; prefixes++;
        BigInteger two=BigInteger.One<<j, th=BigInteger.Pow(3,a); if(two>th && 32*two<47*th){ narrow++; if(x>=u) narrowNonDesc++; if(u>=(BigInteger.One<<71)) narrowHigh++; } } }
  Console.WriteLine($"screen: paths {paths} (distinct sources {seenU.Count}); prefixes {prefixes}; narrow-strip crossings {narrow}; of which non-descending {narrowNonDesc}; with source >= 2^71: {narrowHigh}");
  var q=new List<(BigInteger u,int j)>{(1,2)}; foreach(long u in new long[]{871,4064460795}) foreach(int j in new[]{8,12,16,20,24}) q.Add((u,j)); q.Add((23207,27)); q.Add((68711,27));
  long nodes=0; int done=0;
  foreach(var (u,J) in q){ BigInteger x=u; int a=0; bool floor=true; for(int i=0;i<J;i++){ floor&=x>=u; bool odd=!x.IsEven; if(odd)a++; x=odd?(3*x+1)/2:x/2; }
    var front=new List<(BigInteger z,int b)>{(x,0)};
    for(int d=0;d<J;d++){ var nx=new List<(BigInteger,int)>(); foreach(var (z,b) in front){ nodes++; nx.Add((2*z,b)); if(z%3==2){ var m=(2*z-1)/3; if(m>0 && !m.IsEven) nx.Add((m,b+1)); } } front=nx; }
    done++; int H=front.Max(t=>t.b); var same=front.Where(t=>t.b==a).Min(t=>t.z); var least=front.Min(t=>t.z); int bl=front.First(t=>t.z==least).b;
    BigInteger two=BigInteger.One<<J, th=BigInteger.Pow(3,a);
    Console.WriteLine($"u={u} j={J}: y={x} a={a} size={front.Count} maxcount={H} least same-count origin={same} global least={least} (count {bl}) floor={floor} crossed={two>th} nondesc={x>=u}"); }
  Console.WriteLine($"fibres completed {done}; expanded nodes {nodes} (claimed 46266)");
}}
