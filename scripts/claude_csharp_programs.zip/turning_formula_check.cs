using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long words = 0, mismatchRho = 0, rhoGtW = 0, sumMismatch = 0; var diffHist = new SortedDictionary<int, long>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2;
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        var delta = new double[L]; bool deg = false; double tot = 0;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; delta[i] = a; tot += a; }
        if (deg) continue;
        // turning angles directly
        double rotSum = 0; for (int i = 0; i < L; i++) { int h = (i + 1) % L, g = (i + 2) % L; double d1x = px[h] - px[i], d1y = py[h] - py[i], d2x = px[g] - px[h], d2y = py[g] - py[h]; rotSum += Math.Atan2(d1x * d2y - d1y * d2x, d1x * d2x + d1y * d2y); }
        // formula: tau_j at vertex j between chord j-1 and chord j = wrap( (d_{j-1}+d_j)/2 + pi*(eps_{j-1}-eps_j) ), eps = [delta<0]
        double fSum = 0;
        for (int j = 0; j < L; j++) {
          double d0 = delta[(j + L - 1) % L], d1 = delta[j]; int e0 = d0 < 0 ? 1 : 0, e1 = d1 < 0 ? 1 : 0;
          double tau = (d0 + d1) / 2 + Math.PI * (e0 - e1); while (tau > Math.PI) tau -= 2 * Math.PI; while (tau <= -Math.PI) tau += 2 * Math.PI; fSum += tau;
        }
        words++;
        int wind = (int)Math.Round(tot / (2 * Math.PI)), rho = (int)Math.Round(rotSum / (2 * Math.PI)), rhoF = (int)Math.Round(fSum / (2 * Math.PI));
        if (Math.Abs(rotSum - fSum) > 1e-6) sumMismatch++;
        if (rho != rhoF) mismatchRho++;
        // predicted: rho = w - A1 + A2 with A1 = #{d0<0<d1, d0+d1>0}, A2 = #{d0>0>d1, d0+d1<0}
        int A1 = 0, A2 = 0; for (int j = 0; j < L; j++) { double d0 = delta[(j + L - 1) % L], d1 = delta[j]; if (d0 < 0 && d1 > 0 && d0 + d1 > 0) A1++; if (d0 > 0 && d1 < 0 && d0 + d1 < 0) A2++; }
        int pred = wind - A1 + A2; if (pred != rho) mismatchRho++;
        if (rho > wind) rhoGtW++;
        diffHist.TryGetValue(wind - rho, out long cc); diffHist[wind - rho] = cc + 1;
      }
    }
    Console.WriteLine($"words {words}; turning index from the direct formula vs from central angles only (mismatching sums): {sumMismatch}; index mismatches vs rho = w - A1 + A2: {mismatchRho}; words with rho > w: {rhoGtW}");
    Console.WriteLine("distribution of w - rho: " + string.Join(", ", diffHist.Select(kv => kv.Key + ":" + kv.Value)));
  }
}
