using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 131632: for b >= 2, the maximum numerator over all length-j words with b odd positions whose numerator is r mod 9 equals
// E9 = max F_b(p,l) over b-2 <= p < l < j with 3*2^p + 2^l = r (mod 9), F_b(p,l) = 9*2^(p-b+2)*(3^(b-2)-2^(b-2)) + 3*2^p + 2^l; empty iff no such pair.
class P {
  static void Main() {
    long comps = 0, bad = 0, nonempty = 0, empty = 0;
    for (int j = 2; j <= 16; j++) {
      var best = new Dictionary<(int, int), BigInteger>();
      for (int w = 0; w < (1 << j); w++) { int b = System.Numerics.BitOperations.PopCount((uint)w); if (b < 2) continue; BigInteger V = 0; int h = 0; int[] pos = new int[b]; int c = 0; for (int i = 0; i < j; i++) if (((w >> i) & 1) == 1) pos[c++] = i;
        for (int t = 0; t < b; t++) V += BigInteger.Pow(2, pos[t]) * BigInteger.Pow(3, b - 1 - t);
        int r = (int)(V % 9); var key = (b, r); if (!best.TryGetValue(key, out var cur) || V > cur) best[key] = V; }
      for (int b = 2; b <= j; b++) for (int r = 0; r < 9; r++) {
        BigInteger e9 = -1; bool any = false;
        for (int p = b - 2; p < j; p++) for (int l = p + 1; l < j; l++) { int res = (int)((3 * BigInteger.Pow(2, p) + BigInteger.Pow(2, l)) % 9); if (res != r) continue;
          BigInteger F = 9 * BigInteger.Pow(2, p - b + 2) * (BigInteger.Pow(3, b - 2) - BigInteger.Pow(2, b - 2)) + 3 * BigInteger.Pow(2, p) + BigInteger.Pow(2, l); if (!any || F > e9) { e9 = F; any = true; } }
        bool has = best.TryGetValue((b, r), out var truth); comps++;
        if (has != any || (has && truth != e9)) bad++; if (has) nonempty++; else empty++; } }
    Console.WriteLine($"mod-9 last-two-positions maximum vs exhaustive enumeration (j<=16, b>=2, all 9 residues): {comps} cells, nonempty {nonempty}, empty {empty}, mismatches {bad}");
  }
}
