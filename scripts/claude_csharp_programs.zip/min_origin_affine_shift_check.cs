using System;
using System.Collections.Generic;
using System.Numerics;
// (1) greedy formula R_e(x)=sum_{i<=e} v3(N_i), N_0=x+1, N_{i+1}=2^{a_i+1}u_i-1 vs exact recursion
// (2) monotonicity of H_k(x,r) in r at larger k and structured/large x; stronger ratio Q(r+1)<=(2/3)Q(r), Q=H+1
// (3) how often the minimising branch is at its own maximum (the only obstruction to the induction proof)
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int),int> rm=new(); static Dictionary<(BigInteger,int,int),BigInteger> hm=new();
  static BigInteger Y(BigInteger x,int a,int l)=>2*(B2(l)*(x+1)/B3(l)-1);
  static int R(BigInteger x,int k){ int a=V3(x+1); if(k==0) return a; if(rm.TryGetValue((x,k),out var v)) return v; int best=-1;
    for(int l=0;l<=a;l++){ int t=l+R(Y(x,a,l),k-1); if(t>best) best=t; } rm[(x,k)]=best; return best; }
  static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var t=H(Y(x,a,l),k-1,r-l); if(t!=INF && (best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static int Greedy(BigInteger x,int e){ BigInteger N=x+1; int s=0; for(int i=0;i<=e;i++){ int a=V3(N); s+=a; BigInteger u=N/B3(a); N=B2(a+1)*u-1; } return s; }
  static long series=0,viol=0,ratioViol=0,eq=0,atMaxMin=0,atMaxBad=0,greedyBad=0,greedyCells=0;
  static void Series(BigInteger x,int k){
    int Rk=R(x,k); series++;
    var h=new BigInteger[Rk+1]; for(int r=0;r<=Rk;r++) h[r]=H(x,k,r);
    for(int r=0;r<Rk;r++){ if(h[r+1]>h[r]) viol++; if(h[r+1]==h[r]) eq++; if(3*(h[r+1]+1)>2*(h[r]+1)) ratioViol++; }
  }
  static void Main(){
    long cells=0,bad=0,fin=0;
    for(int x=1;x<=300;x++) for(int k=0;k<=5;k++) for(int r=0;r<=8;r++) for(int t=1;t<=3;t++){ var h0=H(x,k,r); var h1=H(x+t*(long)Math.Pow(3,r),k,r); cells++; if(h0==INF){ if(h1!=INF) bad++; } else { fin++; if(h1!=h0+t*B2(r+k)) bad++; } }
    Console.WriteLine($"affine shift H_k(x+t 3^r,r)=H_k(x,r)+t 2^(r+k): cells {cells} (x<=300,k<=5,r<=8,t<=3), finite {fin}, failures {bad}");
  }
}
