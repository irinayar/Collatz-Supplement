using System;
// Empirical extension: count first returns by gap g=1..24 (odd n<=20001, all odd u in I=[n,H]); gaps with no slope window (3^g/2^s in (3/4,4/3) for no s): 1,6,11,18,23,30,...
class P {
  static long A(long u){ long x=3*u+1; while((x&1)==0) x>>=1; return x; }
  static void Main(){
    long[] cnt=new long[25]; long[] firstN=new long[25]; long[] firstU=new long[25];
    for(long n=3;n<=20001;n+=2){ long H=(4*n-2)/3;
      for(long u=n;u<=H;u+=2){ long x=u; for(int g=1;g<=24;g++){ x=A(x); if(x<n) break; if(x<=H){ cnt[g]++; if(firstN[g]==0){firstN[g]=n;firstU[g]=u;} break; } } } }
    var sb=new System.Text.StringBuilder(); for(int g=1;g<=24;g++) sb.Append($"g{g}:{cnt[g]} "); Console.WriteLine(sb.ToString());
  }
}
