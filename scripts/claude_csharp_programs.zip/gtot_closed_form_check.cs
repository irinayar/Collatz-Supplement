using System;
using System.Numerics;
// Independent cross-check of the correction-product bound without the DP table: for every odd m<=M follow the whole trajectory to its first arrival at 2 (L accelerated steps, r odd steps) and use the closed form G = 2^(L+1)/(3^r m).
class P {
  static void Main(string[] args){
    long M=long.Parse(args[0]); double best=0; long arg=0; int bestL=0,bestR=0; long cnt=0; double l2=Math.Log2(3.0); var sw=System.Diagnostics.Stopwatch.StartNew(); long maxN=0;
    checked { for(long m=3;m<=M;m+=2){ long n=m; int L=0,r=0; while(n!=2){ if((n&1)==1){ n=(3*n+1)>>1; r++; if(n>maxN) maxN=n; } else n>>=1; L++; if(n==1){ L++; n=2; break; } } // n==1 can only occur via 2? (cannot before 2); safety
        double lg=(L+1)-r*l2-Math.Log2((double)m); double g=Math.Pow(2.0,lg); cnt++; if(g>best){ best=g; arg=m; bestL=L; bestR=r; } } }
    BigInteger num=BigInteger.Pow(2,bestL+1), den=BigInteger.Pow(3,bestR)*arg; Console.WriteLine($"odd m<={M}: {cnt} starts; max G = {best:F10} at m={arg} (L={bestL}, r={bestR}); exact: 2^{bestL+1}/(3^{bestR}*{arg}) = {(double)num/(double)den:F12}; 2*num<3*den: {2*num<3*den}; max value met {maxN}; {sw.ElapsedMilliseconds/1000}s");
  }
}
