using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Checks of ChatGPT "Claude FYI audit and entrance compensation": (A) sharp controls m=31+64t, (B) credited-run constant 2455/61440 at (10,7), (C) m_{2,0}(y)<=2 on actual bands.
class P {
 static bool Credit(BigInteger a, BigInteger b, int s){ BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); return 15*t3*(a-b) > (t3-t2)*b; } // c>0
 // run a prefix: returns list of (start a, s, e, output b) and unit-phase gate info
 static List<(BigInteger a,int s,int e,BigInteger b,BigInteger E,int g)> Runs(BigInteger u,int maxRuns,out BigInteger[] qnd){ var res=new List<(BigInteger,int,int,BigInteger,BigInteger,int)>(); BigInteger x=u, C=0; int E=0,g=0; int s=0; BigInteger a=u; var q=new List<BigInteger>(); 
   while(res.Count<maxRuns){ BigInteger t=3*x+1; int e=0; while(t.IsEven){t>>=1;e++;} C=3*C+(BigInteger.One<<E); E+=e; g++; s++; x=t; if(e>=2){ res.Add((a,s,e,x,E,g)); a=x; s=0; q.Add(C); } if(x==1) break; }
   qnd=q.ToArray(); return res; }
 static void Main(){
  // (A) sharp controls
  Console.WriteLine("(A) controls m=31+64t: y=(2187m+11)/32 for both sources; phases 287/243 and 2539/2187; entrance runs and zero credits");
  for(int t=0;t<4;t++){ BigInteger m=31+64*t; BigInteger n=27*m, H=36*m-1; foreach(var uu in new[]{36*m-1,32*m-1}){ BigInteger[] cs; var runs=Runs(uu,3,out cs); // phase after run k = C_k/3^{g_k}
      string desc=""; bool zero=true; for(int i=0;i<Math.Min(2,runs.Count);i++){ var r=runs[i]; if(Credit(r.a,r.b,r.s)) zero=false; BigInteger p3=BigInteger.Pow(3,r.g); desc+=$" run{i+1}=(s={r.s},e={r.e}) q={cs[i]}/{p3}"; }
      BigInteger yexp=(2187*m+11)/32; Console.WriteLine($" t={t} u={uu}: y(after run2)={runs[1].b} expected {yexp} match={runs[1].b==yexp && (2187*m+11)%32==0};{desc}; zero credit in first two runs={zero}; gate after 2nd run: phase>1 = {cs[1]>BigInteger.Pow(3,runs[1].g)}, after 1st run phase<=1: {cs[0]<=BigInteger.Pow(3,runs[0].g)}"); } }
  // (B) credited-run constant
  BigInteger bestN=0,bestD=1; int bs=0,be=0; var emax=new Dictionary<int,int>{{2,2},{3,2},{4,3},{5,4},{6,4},{7,5},{8,5},{9,6},{10,6},{11,7}};
  for(int s=2;s<=11;s++){ int e=emax[s]+1; BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); // value 1-(1+beta/15)/lambda, beta=(t3-t2)/t3, lambda=2^(s+e-1)/t3
    BigInteger num=BigInteger.Pow(2,s+e-1)*15*t3 - (15*t3+(t3-t2))*t3; BigInteger den=BigInteger.Pow(2,s+e-1)*15*t3; // (lam*15 t3 - (15 t3 + t3 - t2)*... ) careful below
    // value = 1 - ( (15 + beta)/15 ) / lambda = 1 - (15 t3 + t3 - t2)/(15 t3) * t3/2^(s+e-1) = 1 - (16 t3 - t2)/(15*2^(s+e-1))
    BigInteger vn=15*BigInteger.Pow(2,s+e-1) - (16*t3 - t2), vd=15*BigInteger.Pow(2,s+e-1);
    if(bestN==0 || vn*bestD < bestN*vd){ bestN=vn; bestD=vd; bs=s; be=e; } }
  BigInteger g_=BigInteger.GreatestCommonDivisor(bestN,bestD); Console.WriteLine($"(B) min over s=2..11 (credited e=e_s+1) of 1-(1+beta/15)/lambda = {bestN/g_}/{bestD/g_} at (s,e)=({bs},{be}); claimed 2455/61440: {bestN/g_==2455 && bestD/g_==61440}; 2455/61440-1/960 = {2455.0/61440-1.0/960:F5} > 1/26={1.0/26:F5}: {2455.0/61440-1.0/960>1.0/26}; 15/416={15.0/416:F5} > 1/28={1.0/28:F5}");
  // (C) m_{2,0}(y)<=2 on actual bands
  Console.WriteLine("(C) fixed unit gate y: sources with two-run zero-credit short entrance, proper prefix; max multiplicity per y");
  var rnd=new Random(5); var ns=new List<long>{2001,20001,200001}; for(int i=0;i<10;i++) ns.Add(1000+2*rnd.NextInt64(1,150000));
  foreach(long n0 in ns){ long n=n0|1; long H=(4*n-2)/3; var groups=new Dictionary<BigInteger,int>(); int tot=0;
    for(long u=n; u<=H; u+=2){ BigInteger[] cs; var runs=Runs(u,3,out cs); if(runs.Count<2) continue; // find unit gate
      int k=-1; for(int i=0;i<runs.Count;i++){ if(cs[i]>BigInteger.Pow(3,runs[i].g)){k=i;break;} } if(k!=1) continue; // two-run entrance
      if(runs[0].s>11||runs[1].s>11) continue; if(Credit(runs[0].a,runs[0].b,runs[0].s)||Credit(runs[1].a,runs[1].b,runs[1].s)) continue;
      // proper: all odd states after the source before the gate are > H
      bool proper=true; BigInteger x=u; int steps=0; int odd=runs[1].g; for(int i=0;i<odd;i++){ x=(3*x+1)/2; while(x%2==0 && false){} } // placeholder (states checked below)
      BigInteger y=runs[1].b; if(!(y>H)) continue; if(!(runs[0].b>H)) proper=false; if(!proper) continue; // run-boundary states above H (full per-input check omitted: inputs inside a run exceed outputs' predecessors)
      groups.TryGetValue(y,out int c); groups[y]=c+1; tot++; }
    int mx=groups.Count==0?0:groups.Values.Max(); int n2=groups.Values.Count(v=>v>=2); Console.WriteLine($" n={n}: qualifying sources {tot}, distinct gates {groups.Count}, gates with 2 sources {n2}, max multiplicity {mx}"); }
 }}
