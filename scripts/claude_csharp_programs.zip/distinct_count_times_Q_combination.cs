using System;
// Combination: K101/M89 distinct-count bound (sharpened with mod-3 exclusion, exponent 1/9) x large certified small-start constant Q.
// Outside inputs: n distinct odd inputs >=h=H+2; at most one divisible by 3 (<=1/(3h)); the other n-1 are odd non-multiples of 3, J=ceil((n-1)/2) pairs:
//   log G_out <= 1/(3h) + 2/(3h) + (1/9) ln(1+6(J-1)/h)   (six-block integral comparison).
// Safe iff lnQ + that < ln 1.5 (with margin). Compare with the per-input envelope Q*q^r (q=1+1/(3h)).
class P {
  static double Bound(double h,double n){ double J=Math.Ceiling((n-1)/2); return 1.0/(3*h)+2.0/(3*h)+(1.0/9)*Math.Log(1+6*(J-1)/h); }
  static void Main(){
    // (a) brute-force validation of the six-block bound: sum of log f over the n smallest odd non-multiples of 3 >= h, plus the multiple-of-3 term
    foreach(double h in new[]{1001.0,1003,1005,1007,1009,1013}){
      double hh=h; double s=0; long cnt=0; double worst=1e9; long hi=(long)h; if(hi%2==0) hi++;
      for(long u=hi; cnt<5000000; u+=2){ if(u%3==0) continue; s+=Math.Log((3.0*u+1)/(3.0*u)); cnt++; if(cnt%100000==0||cnt<50){ double b=Bound(hh,cnt+1)-1.0/(3*hh); worst=Math.Min(worst,b-s); } }
      Console.WriteLine($"validate h={h}: min slack over n<=5e6 (bound - true sum) = {worst:E3} (must be >0)");
    }
    double lnHalf=Math.Log(1.5);
    foreach(var (H,Q,name) in new[]{ (786429.0,1.2531421444,"786429"), (1572861.0,1.2531421444,"1572861"), (1073741821.0,1.2531421444,"2^30-3"), (4294967293.0,1.324218750860254,"2^32-3 rigorous")}){
      double h=H+2; double lq=Math.Log(Q); double lo=1, hi2=h*100; 
      while(hi2-lo>1){ double mid=Math.Floor((lo+hi2)/2); if(lq+Bound(h,mid)+1e-9<lnHalf) lo=mid; else hi2=mid; }
      double q=1+1.0/(3*h); double env=Math.Floor(0.99*Math.Log(1.5/Q)/Math.Log(q)); // crude per-input envelope count for comparison
      double envExact=Math.Floor(Math.Log(1.5/Q)/Math.Log(q));
      Console.WriteLine($"H={name}: distinct-count bound safe up to n={lo:F0} ({lo/h:F4} h); per-input envelope r_max={envExact:F0} ({envExact/h:F4} h); gain x{lo/envExact:F3}");
    }
  }
}
