using System; using System.Numerics;
// ChatGPT Research_Update section 2: exact comparisons, generating-function identity, v2(a+1)=s on complete runs.
class P { static void Main(){
 Console.WriteLine("(276/125)^7<256: " + (BigInteger.Pow(276,7) < 256*BigInteger.Pow(125,7)));
 Console.WriteLine("(151/125)^35>3^6: " + (BigInteger.Pow(151,35) > 729*BigInteger.Pow(125,35)));
 Console.WriteLine("3*40^8*125^7<39^8*151^7: " + (3*BigInteger.Pow(40,8)*BigInteger.Pow(125,7) < BigInteger.Pow(39,8)*BigInteger.Pow(151,7)));
 // sum_{i>=k} C(i,k) 2^-i = 2 : partial sums with exact rationals to i=400 for k=0..12, report 2 - partial
 foreach (int k in new[]{0,1,5,12}) { BigInteger num=0; BigInteger den=BigInteger.One<<400; BigInteger c=1; // C(i,k) iteratively
   for(int i=k;i<=400;i++){ BigInteger Ci=Binom(i,k); num+=Ci*(BigInteger.One<<(400-i)); }
   double rem=2.0-(double)num/(double)den; Console.WriteLine($"k={k}: 2 - partial(i<=400) = {rem:E2}"); }
 // v2(a+1)=s for complete runs: runs from odd a with s odd inputs then exponent>=2: enumerate a<2^22
 int bad=0,tot=0; for(long a=3;a<(1<<22);a+=2){ long x=a; int s=0; while(true){ long t=3*x+1; int e=System.Numerics.BitOperations.TrailingZeroCount((ulong)t); if(e>=2){ break;} x=t>>1; s++; s=s; if(s>60)break; } s++; // counts odd inputs including terminal one
   int v=System.Numerics.BitOperations.TrailingZeroCount((ulong)(a+1)); tot++; if(v!=s) bad++; }
 Console.WriteLine($"v2(a+1)=s (s odd inputs of the maximal run starting at a, exponents 1,..,1,>=2): bad={bad} of {tot}");
}
 static BigInteger Binom(int n,int k){ BigInteger r=1; for(int i=1;i<=k;i++) r=r*(n-k+i)/i; return r; } }
