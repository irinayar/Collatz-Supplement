using System;
using System.Collections.Generic;
// For non-minimal n at depth K: distribution of  delta = (odd count of the best partner) - (odd count of n) over the first K-1 steps,
// where "best" = minimal odd count among ALL smaller starts with the same T^(K-1) value (and, for comparison, the least partner).
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var val = new long[N + 1]; var cnt = new int[N + 1]; for (int n = 1; n <= N; n++) val[n] = n;
    var idx = new int[N]; 
    for (int K = 2; K <= 13; K++) {
      for (int n = 1; n <= N; n++) { long v = val[n]; if ((v & 1) == 1) { val[n] = (3 * v + 1) / 2; cnt[n]++; } else val[n] = v / 2; }   // now depth K values, K-1 steps
      for (int i = 0; i < N; i++) idx[i] = i + 1;
      Array.Sort(idx, (x, y) => { int c = val[x].CompareTo(val[y]); return c != 0 ? c : x.CompareTo(y); });
      var hBest = new SortedDictionary<int, long>(); var hLeast = new SortedDictionary<int, long>(); long nonmin = 0;
      for (int i = 0; i < N;) {
        int j = i; while (j < N && val[idx[j]] == val[idx[i]]) j++;
        int first = idx[i]; int minCnt = cnt[first];
        for (int t = i + 1; t < j; t++) { int n = idx[t]; nonmin++;
          int d1 = minCnt - cnt[n], d2 = cnt[first] - cnt[n];
          hBest[d1] = hBest.GetValueOrDefault(d1) + 1; hLeast[d2] = hLeast.GetValueOrDefault(d2) + 1;
          if (cnt[n] < minCnt) minCnt = cnt[n]; }
        i = j;
      }
      if (K == 4 || K == 6 || K == 8 || K == 10 || K == 12 || K == 13) {
        Console.Write($"K={K,2}: non-minimal n: {nonmin}. best-partner delta histogram: "); foreach (var kv in hBest) Console.Write($"{kv.Key}:{kv.Value} "); 
        Console.Write(" | least-partner: "); foreach (var kv in hLeast) Console.Write($"{kv.Key}:{kv.Value} "); Console.WriteLine();
      }
    }
  }
}
