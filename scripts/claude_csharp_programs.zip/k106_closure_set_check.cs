using System;
using System.Collections.Generic;
using System.Numerics;
// Check of Codex K106: forward-closed set S of odd run starts (all trajectories of odd seeds 3..1023 under F, plus 1), R_out, B_out, A threshold 284/285.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static Fr Step(long u,out long v){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); v=(long)(w>>e); return new Fr(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    var S=new HashSet<long>(); S.Add(1); long maxS=1;
    for(long seed=3;seed<=1023;seed+=2){ long u=seed; int guard=0; while(u!=1&&guard++<100000){ if(!S.Add(u)) break; if(u>maxS) maxS=u; Step(u,out long v); u=v; } }
    int small=0; foreach(var x in S) if(x<=1023) small++;
    Console.WriteLine($"|S| = {S.Count} (odd run starts reached from seeds 3..1023, plus 1); of which <=1023: {small}, above 1023: {S.Count-small}; largest {maxS}");
    Fr Rout=new Fr(1,1); long argR=0; for(long u=1025;u<=4095;u+=2){ Step(u,out long v); var c=Step(u,out v); if(Fr.Gt(c,Rout)){ Rout=c; argR=u; } }
    Fr t=new Fr(4098,4097); Console.WriteLine($"R_out = {Rout} at u={argR}; Codex 793088/792423; (4098/4097)>=any later? C(u)<1+1/4097 < R_out: {Fr.Gt(Rout,new Fr(4098,4097))}");
    Fr Bout=new Fr(1,1); long a1=0,a2=0; for(long u=1025;u<=4095;u+=2){ if(S.Contains(u)) continue; var c1=Step(u,out long v); if(v<=1023||S.Contains(v)) continue; var c2=Step(v,out long v2); var pr=c1*c2; if(Fr.Gt(pr,Bout)){ Bout=pr; a1=u; a2=v; } }
    Fr tailPair=t*Rout; if(Fr.Gt(tailPair,Bout)){ Console.WriteLine("tail pair bound exceeds finite max!"); Bout=tailPair; }
    Console.WriteLine($"B_out = {Bout} at {a1}->{a2}; Codex 2301440/2298537; R_out<B_out<R_out^2: {Fr.Gt(Bout,Rout)&&Fr.Gt(Rout*Rout,Bout)}");
    Fr Q=new Fr(BigInteger.Pow(2,61),BigInteger.Pow(3,32)*993); Fr three2=new Fr(3,2); int firstA=-1; for(int A=0;A<=2000;A++){ Fr b=Q; for(int i=0;i<A/2;i++) b=b*Bout; if(A%2==1) b=b*Rout; if(Fr.Gt(b,three2)){ firstA=A; break; } }
    Console.WriteLine($"first A with Q_S*B_out^floor(A/2)*R_out^(A mod 2) > 3/2: {firstA} (Codex: 285, safe through 284)");
  }
}
