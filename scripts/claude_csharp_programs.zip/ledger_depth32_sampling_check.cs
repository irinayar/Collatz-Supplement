using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
// Independent sampling check of the depth-32 named-rule density (Codex ledger, v6 Approach 68).
// covered(n) = coefficient crossing within 32 steps (exists i<=32: 3^a_i < 2^i)
//           OR n = r mod m for a finite-ledger rule OR C08 family 1^k00 OR C85 meeting-only cylinder (mod 2^27).
// Sample n in [1, 2^32): complete residue system for all binary conditions of depth <=32;
// ternary-modulus rules are counted within +-1 per rule.
class P {
  static void Main(string[] a) {
    string root = a[0];
    var inv = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/targets_E16/counting_inventory_updated.json"))).RootElement;
    var rules = new List<(ulong r, ulong m)>();
    foreach (var z in inv.GetProperty("finite_ledger").EnumerateArray()) {
      ulong m = z.GetProperty("modulus").GetUInt64(); ulong r = z.GetProperty("residue").GetUInt64(); string id = z.GetProperty("id").GetString(); if (a.Length > 1 && (id.StartsWith("C103") || id.StartsWith("C108"))) continue;
      if (m < (1UL << 33)) rules.Add((r, m));   // larger moduli: density < 1.2e-10 each, no hit in sample range possible beyond r itself
    }
    Console.WriteLine($"finite rules used {rules.Count} of {inv.GetProperty("finite_ledger").GetArrayLength()}");
    var c85 = new bool[1 << 27]; int c85n = 0;
    var certs = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/v2_audit/parent27_certificates.json"))).RootElement.GetProperty("certificates");
    foreach (var c in certs.EnumerateArray()) {
      bool meet = c.GetProperty("meeting").ValueKind != JsonValueKind.Null;
      bool desc = c.GetProperty("descent").ValueKind != JsonValueKind.Null;
      if (meet && !desc) { c85[c.GetProperty("n").GetInt64()] = true; c85n++; }
    }
    Console.WriteLine($"C85 meeting-only cylinders {c85n}");
    // C08: residue -(3^k-2^k)*inv(3^k) mod 2^(k+2), k=1..30
    var c08r = new List<(ulong r, ulong mask)>();
    for (int k = 1; k <= 30; k++) {
      BigInteger m = BigInteger.One << (k + 2), p3 = BigInteger.Pow(3, k), p2 = BigInteger.Pow(2, k);
      BigInteger inv3 = BigInteger.ModPow(p3, (m >> 1) - 1, m);
      BigInteger r = (((-(p3 - p2) * inv3) % m) + m) % m;
      c08r.Add(((ulong)r, (ulong)(m - 1)));
    }
    ulong[] p3t = new ulong[40]; p3t[0] = 1; for (int i = 1; i < 40; i++) p3t[i] = p3t[i - 1] * 3;
    long total = 1L << 32; long uncovered = 0, crossing = 0, byRule = 0, byC08 = 0, byC85 = 0;
    int chunks = 4096; long per = total / chunks;
    var rr = rules.ToArray(); var cc = c08r.ToArray();
    Parallel.For(0, chunks, ci => {
      long lu = 0, lc = 0, lr = 0, l8 = 0, l85 = 0;
      long start = ci * per, end = start + per;
      for (long n = start; n < end; n++) {
        if (n == 0) continue;
        ulong x = (ulong)n; int ones = 0; bool cross = false;
        for (int i = 1; i <= 32; i++) {
          if ((x & 1) == 1) { ones++; x = (3 * x + 1) >> 1; } else x >>= 1;
          if (p3t[ones] < (1UL << i)) { cross = true; break; }
        }
        if (cross) { lc++; continue; }
        ulong un = (ulong)n; bool cov = false;
        for (int q = 0; q < rr.Length && !cov; q++) if (un % rr[q].m == rr[q].r) cov = true;
        if (cov) { lr++; continue; }
        for (int q = 0; q < cc.Length; q++) if ((un & cc[q].mask) == cc[q].r) { cov = true; break; }
        if (cov) { l8++; continue; }
        if (c85[un & ((1UL << 27) - 1)]) { l85++; continue; }
        lu++;
      }
      Interlocked.Add(ref uncovered, lu); Interlocked.Add(ref crossing, lc); Interlocked.Add(ref byRule, lr); Interlocked.Add(ref byC08, l8); Interlocked.Add(ref byC85, l85);
    });
    Console.WriteLine($"n in [1,2^32): crossing {crossing}, +ledger {byRule}, +C08 {byC08}, +C85 {byC85}, uncovered {uncovered}");
    BigInteger num = BigInteger.Parse("7819534701173808307942939"), den = BigInteger.Parse("7851540464532429050216448");
    double claimed = (double)(den - num) / (double)den;
    double got = (double)uncovered / (double)total;
    Console.WriteLine($"uncovered fraction sampled {got:E9}; claimed (1 - 7819534701173808307942939/7851540464532429050216448) {claimed:E9}; diff {got - claimed:E3}");
    Console.WriteLine($"coefficient-crossing fraction sampled {(double)crossing / total:F10}; claimed 4253619813/4294967296 = {4253619813.0 / 4294967296.0:F10}");
  }
}
