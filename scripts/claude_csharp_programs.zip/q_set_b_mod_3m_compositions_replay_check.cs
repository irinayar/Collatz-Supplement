using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Distribution of B = sum_{i<g} 3^(g-1-i) 2^(E_i) modulo 3^m over all compositions e_1+..+e_g=E, e_i>=1 (E_0=0). Also: B never divisible by 3.
class P { static BigInteger[] p2=new BigInteger[80], p3=new BigInteger[40]; static int g,E; static Dictionary<int,long>[] cnt; static int[] mods; static long words=0; static bool never3=true;
 static void Rec(int i,int Ei,BigInteger B){ // i terms placed: B accumulates B_i = 3*B_{i-1}+2^{E_{i-1}}
   if(i==g){ if(Ei==E){ words++; if(B%3==0) never3=false; for(int k=0;k<mods.Length;k++) { int r=(int)(B%mods[k]); if(!cnt[k].ContainsKey(r)) cnt[k][r]=0; cnt[k][r]++; } } return; }
   int rem=g-i-1; for(int e=1;Ei+e+rem<=E;e++){ // term i uses 2^{E_i}: B_{i+1}=3*B_i+2^{E_i}
     Rec(i+1,Ei+e,3*B+p2[Ei]); } }
 static void Main(){ p2[0]=1; for(int i=1;i<80;i++) p2[i]=p2[i-1]*2; foreach(var (gg,EE,ms) in new[]{(12,19,new[]{27,81}),(14,22,new[]{243})}){ g=gg;E=EE; mods=ms; cnt=ms.Select(_=>new Dictionary<int,long>()).ToArray(); words=0; never3=true; Rec(0,0,0);
    Console.WriteLine("g="+g+", E="+E+": words "+words+" (C(E-1,g-1)), B never divisible by 3: "+never3);
    for(int k=0;k<ms.Length;k++){ int m=ms[k]; var units=Enumerable.Range(1,m-1).Where(r=>r%3!=0).ToList(); long mn=units.Min(r=>cnt[k].ContainsKey(r)?cnt[k][r]:0), mx=units.Max(r=>cnt[k].ContainsKey(r)?cnt[k][r]:0); Console.WriteLine("   mod "+m+": unit classes "+units.Count+", mean "+(double)words/units.Count+", min "+mn+", max "+mx+", classes with count 0: "+units.Count(r=>!cnt[k].ContainsKey(r))+", residues divisible by 3 hit: "+cnt[k].Keys.Count(r=>r%3==0)); } } }}
