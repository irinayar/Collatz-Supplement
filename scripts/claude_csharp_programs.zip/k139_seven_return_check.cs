using System;
using System.Collections.Generic;
// Check Codex K139 / ChatGPT 145737: seven-transition first returns.
// (a) exhaustive: all odd u in I=[n,H], odd n<=4001: seven-transition first returns -> tuple in the 30-row table with u mod 4096 = residue, E=11, 2048 w = 2187 u + B.
// (b) rebuild the table: 56 tuples (e1=1,e7>=2,E=11), caps E1<=1,E2<=3,E3<=4,E4<=6,E5<=7,E6<=9 leave 30; B recurrence; residue mod 4096; sum(B-695)=64148.
// (c) E=12: 126 tuples, margin 885 r - B + 2048 > 0 (Codex min 105472).
// (d) small-n envelope: for odd n=3..1021: R(n)/(1-S(n)) with S over classes gap3 (55:44/27,43:48/27 mod 64), gap5 (7 classes mod 512, numerator/243), gap7 (30 classes mod 4096, (B-695)/2187); maximum and location.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static long Bof(int[] ev){ long B=0; int E=0; foreach(int v in ev){ B=3*B+(1L<<E); E+=v; } return B; }
  static long Residue(int[] ev,int mod){ for(long r=1;r<mod;r+=2){ long x=r; bool ok=true; for(int i=0;i<ev.Length;i++){ int e; x=A(x,out e); if(e!=ev[i]){ok=false;break;} } if(ok) return r; } return -1; }
  static void Tuples(int len,int E,List<int[]> outL){ var cur=new int[len]; void Rec(int p,int s){ if(p==len){ if(s==E&&cur[len-1]>=2) outL.Add((int[])cur.Clone()); return; } for(int v=(p==0?1:1);v<=E-s;v++){ if(p==0&&v!=1) continue; cur[p]=v; Rec(p+1,s+v); } } Rec(0,0); }
  static void Main(){
    var t11=new List<int[]>(); Tuples(7,11,t11); var good=new List<(int[] ev,long B,long res)>(); long sumd=0;
    foreach(var ev in t11){ int[] cap={1,3,4,6,7,9}; bool ok=true; int E=0; for(int j=0;j<6;j++){ E+=ev[j]; if(E>cap[j]) ok=false; } if(ok){ long B=Bof(ev); good.Add((ev,B,Residue(ev,4096))); sumd+=B-695; } }
    Console.WriteLine($"(b) E=11 tuples {t11.Count}; surviving the suffix caps {good.Count}; sum(B-695) = {sumd} (expected 64148); first row {string.Join(",",good[0].ev)} B={good[0].B} res={good[0].res}; last {string.Join(",",good[good.Count-1].ev)} B={good[good.Count-1].B} res={good[good.Count-1].res}");
    var t12=new List<int[]>(); Tuples(7,12,t12); long minM=long.MaxValue; foreach(var ev in t12){ long B=Bof(ev); long r=Residue(ev,8192); long m=885*r-B+2048; if(m<minM) minM=m; }
    Console.WriteLine($"(c) E=12 tuples {t12.Count}, minimum margin 885r-B+2048 = {minM} (Codex 105472)");
    var map=new Dictionary<string,(long B,long res)>(); foreach(var g in good) map[string.Join(",",g.ev)]=(g.B,g.res);
    long tot=0,bad=0,badE=0; for(long n=3;n<=4001;n+=2){ long H=(4*n-2)/3; for(long u=n;u<=H;u+=2){ long x=u; var ev=new int[7]; bool ok=true; for(int i=0;i<7;i++){ int e; x=A(x,out e); ev[i]=e; if(i<6 && x<=H){ ok=false; break; } if(x<n){ok=false;break;} } if(!ok) continue; if(x>H) continue; tot++; int E=0; foreach(int v in ev) E+=v; if(E!=11){badE++;continue;} string key=string.Join(",",ev); if(!map.TryGetValue(key,out var t)){bad++;continue;} if(u%4096!=t.res || 2048*x!=2187*u+t.B) bad++; } }
    Console.WriteLine($"(a) seven-transition first returns (odd n<=4001): {tot}; total valuation != 11: {badE}; not in table / residue or formula violations: {bad}");
    // (d)
    var cls3=new List<(long res,long mod,double c)>{(55,64,44.0/27),(43,64,48.0/27)}; long[] r5={95,175,335,295,455,219,379}; long[] n5={276,292,324,316,348,352,384}; var cls5=new List<(long,long,double)>(); for(int i=0;i<7;i++) cls5.Add((r5[i],512,n5[i]/243.0));
    var cls7=new List<(long,long,double)>(); foreach(var g in good) cls7.Add((g.res,4096,(g.B-695)/2187.0));
    var all=new List<(long res,long mod,double c)>(); all.AddRange(cls3); foreach(var c in cls5) all.Add(c); foreach(var c in cls7) all.Add(c);
    double best=0; long bestn=0; double worstS=0;
    for(long n=3;n<=1021;n+=2){ long H=(4*n-2)/3; double S=0; foreach(var (res,mod,c) in all){ long u=n+((res-n)%mod+mod)%mod; for(;u<=H;u+=mod) S+=c/(u+5); }
      double R=(double)(n+5)*H/((double)n*(H+5)); double v=R/(1-S); if(S>worstS) worstS=S; if(v>best){best=v;bestn=n;} }
    Console.WriteLine($"(d) small-n envelope max R/(1-S) = {best:F6} at n={bestn} (claimed 1088640/994117 = {1088640.0/994117:F6} at n=43); max S over n<=1021: {worstS:F5}");
    double alpha=176525.0/6718464, beta=92228.0/2187; double Sb=(alpha*1023+beta)/(1023+5); double Rb=4.0*(1028)/(4*1023+15); Console.WriteLine($"    analytic tail at n=1023: Sbar={Sb:F5}, R={Rb:F5}, bound {Rb/(1-Sb):F5} (< 11/10); alpha={alpha:F6}, beta={beta:F4}, 64148/2187={64148.0/2187:F4}");
  }
}
