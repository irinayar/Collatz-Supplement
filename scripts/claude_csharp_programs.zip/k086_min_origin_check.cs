using System;
using System.Collections.Generic;
using System.Numerics;
// Check of Codex 135519 (K086): exact minimum-origin recursion H_k(x,r), formal-word numerator envelope, origin envelopes, sharpened joint inequality.
class P {
  const long INF=long.MaxValue;
  static int V3(long n){int c=0; while(n%3==0){n/=3;c++;} return c;}
  static long Pw(long b,int e){long r=1; for(int i=0;i<e;i++) r*=b; return r;}
  static Dictionary<(long,int,int),long> memo=new();
  static long H(long x,int k,int r){ int a=V3(x+1);
    if(k==0) return r<=a ? Pw(2,r)*(x+1)/Pw(3,r)-1 : INF;
    var key=(x,k,r); if(memo.TryGetValue(key,out var v)) return v; long best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ long y=Pw(2,l)*(x+1)/Pw(3,l)-1; long t=H(2*y,k-1,r-l); if(t<best) best=t; } memo[key]=best; return best; }
  static int EMAX=6; static long[,] mn;
  static void Dfs(long z,int ev,int od){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z;
    if(ev<EMAX) Dfs(2*z,ev+1,od);
    if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long cells=0,bad=0,envBad=0,jointBad=0,finite=0;
    for(long x=1;x<=3000;x++){ mn=new long[EMAX+1,40]; Dfs(x,0,0); memo.Clear();
      for(int k=0;k<=EMAX;k++) for(int r=0;r<40;r++){ long dfs=mn[k,r]==0?INF:mn[k,r]; long h=H(x,k,r); cells++;
        if(dfs!=h) bad++;
        if(dfs!=INF){ finite++; BigInteger m=dfs;
          // envelopes: ceil(2^k(2^r(x+1)/3^r -1)) <= m <= floor(2^r(2^k x+1)/3^r -1)
          BigInteger num=BigInteger.Pow(2,k)*(BigInteger.Pow(2,r)*(x+1)-BigInteger.Pow(3,r)); BigInteger den=BigInteger.Pow(3,r);
          // m*den >= num   (m >= num/den)
          if(m*den<num) envBad++;
          BigInteger up=BigInteger.Pow(2,r)*(BigInteger.Pow(2,k)*x+1)-den; // m*den <= up
          if(m*den>up) envBad++;
          if(2*BigInteger.Pow(3,r)>BigInteger.Pow(2,r)*(BigInteger.Pow(2,k)*x+1)) jointBad++; } } }
    // formal-word numerator envelope
    long wordBad=0, words=0;
    for(int L=0;L<=16;L++) for(int mask=0;mask<(1<<L);mask++){ int r=0; for(int i=0;i<L;i++) if(((mask>>i)&1)==1) r++; int k=L-r; BigInteger v=0; int h=0; for(int i=0;i<L;i++) if(((mask>>i)&1)==1){ v+=BigInteger.Pow(2,i)*BigInteger.Pow(3,r-1-h); h++; }
      BigInteger lo=BigInteger.Pow(3,r)-BigInteger.Pow(2,r), hi=BigInteger.Pow(2,k)*lo; words++; if(v<lo||v>hi) wordBad++; }
    Console.WriteLine($"(x,k,r) cells {cells} (x<=3000,k<=6,r<40), finite {finite}, minimum-origin mismatches {bad}; origin-envelope violations {envBad}; sharpened-joint violations {jointBad}; formal words {words} (length<=16), numerator-envelope violations {wordBad}");
  }
}
