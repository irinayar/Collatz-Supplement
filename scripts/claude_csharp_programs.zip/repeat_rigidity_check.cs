using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
// (1) Check on real orbits: if two positions j < j' share their first L parity bits then z_j = z_j' mod 2^L   (always true; basis of the repeat lemma).
// (2) Smallest positive integer whose itinerary begins with the Sturmian word of slope alpha: bit length of n_K versus K.
static class P {
  static BigInteger S = BigInteger.Pow(10, 120);
  static BigInteger Atanh(BigInteger num, BigInteger den) { BigInteger x = num * S / den, x2 = x * x / S, term = x, sum = 0; for (int n = 1; term != 0; n += 2) { sum += term / n; term = term * x2 / S; } return sum; }
  static void Main() {
    // (1)
    var rng = new Random(11); long checks = 0, bad = 0;
    for (int t = 0; t < 4000; t++) {
      BigInteger n = new BigInteger(rng.NextInt64(2, 1L << 55)); var z = new List<BigInteger>(); var b = new List<int>(); BigInteger x = n;
      for (int j = 0; j < 160; j++) { z.Add(x); b.Add((int)(x % 2)); x = x.IsEven ? x / 2 : (3 * x + 1) / 2; }
      for (int j = 0; j < 160; j++) for (int j2 = j + 1; j2 < 160; j2++) { int L = 0; while (j2 + L < 160 && b[j + L] == b[j2 + L]) L++; checks++; if (L > 0 && ((z[j] - z[j2]) % BigInteger.Pow(2, L)) != 0) bad++; }
    }
    Console.WriteLine($"(1) congruence z_j = z_j' mod 2^lcp: {checks} pairs, violations {bad}");
    // (2)
    BigInteger ln2 = 2 * Atanh(1, 3), ln3 = 2 * Atanh(2, 4); BigInteger alpha = ln2 * S / ln3;  // log_3 2 scaled by S
    foreach (var (name, a0, rho) in new[] { ("critical slope log_3 2 = 0.6309, rho = 0", alpha, BigInteger.Zero), ("critical slope, rho = 0.3", alpha, S * 3 / 10), ("supercritical slope 0.75, rho = 0.2", S * 3 / 4, S / 5), ("subcritical slope 0.55, rho = 0.2", S * 11 / 20, S / 5) }) {
      Console.Write(name + ": bit length of n_K for K = 50, 100, 200, 400, 800, 1600: ");
      int Kmax = 1600; BigInteger U = 0; int A = 0; var res = new List<string>();
      for (int j = 0; j < Kmax; j++) {
        BigInteger fl1 = ((j + 1) * a0 + rho) / S, fl0 = (j * a0 + rho) / S; int bit = (int)(fl1 - fl0);
        if (bit == 1) { U = 3 * U + BigInteger.Pow(2, j); A++; }
        int K = j + 1; if (K == 50 || K == 100 || K == 200 || K == 400 || K == 800 || K == 1600) { BigInteger mod = BigInteger.Pow(2, K); BigInteger inv = BigInteger.ModPow(BigInteger.Pow(3, A), (mod / 2) - 1, mod); BigInteger nK = ((-U * inv) % mod + mod) % mod; res.Add($"{(int)(BigInteger.Log(nK + 1, 2))}"); }
      }
      Console.WriteLine(string.Join(", ", res));
    }
  }
}
