using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
// Random closed words with fixed (L, A): excursion statistics k, n_1, n_3, n_PL, n_VR, w = -(k - n_PL - n_VR), min value, H/c
static class P {
  static void Main(string[] args) {
    int L = int.Parse(args[0]), A = int.Parse(args[1]), N = int.Parse(args[2]); var rng = new Random(12345);
    BigInteger p2 = BigInteger.One << L, p3 = BigInteger.Pow(3, A), D = p2 - p3; if (D <= 0) { Console.WriteLine("3^A >= 2^L"); return; }
    double eps = (double)(p2 - p3) / (double)p2;
    long used = 0, g1 = 0, flat = 0, bothLR = 0; double sumND = 0, sumAbsW = 0; long lemmaBad = 0, spreadBad = 0; double spreadMax = 0, spreadSum = 0; double qv = (double)p3 / (double)p2; double delta = Math.Log2(1.0 / (0.6 * qv)); int maxAbsW = 0, maxND = 0; double sumK = 0, sumN1 = 0, sumPL = 0, sumVR = 0, sumW = 0, sumRho = 0, sumLogHc = 0, sumMinX = 0;
    var wHist = new SortedDictionary<int, long>();
    for (int it = 0; it < N; it++) {
      var idx = Enumerable.Range(0, L).OrderBy(_ => rng.Next()).Take(A).ToHashSet(); var e = new bool[L]; foreach (var i in idx) e[i] = true;
      // need at least one 0 before... rotate so that word starts at beginning of a run of ones preceded by zero
      int s0 = -1; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) { s0 = i; break; } if (s0 < 0) continue;
      var f = new bool[L]; for (int i = 0; i < L; i++) f[i] = e[(s0 + i) % L]; e = f;
      BigInteger U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + (BigInteger.One << i);
      BigInteger scale = D * p2; var X = new BigInteger[L]; X[0] = U * p2; bool ok = true;
      for (int i = 0; i + 1 < L; i++) { var t = e[i] ? 3 * X[i] + scale : X[i]; X[i + 1] = t / 2; }
      if (X.Distinct().Count() < L) continue;
      BigInteger c = X.Min(), H = X.Max(), S = c + H; used++;
      bool ge1 = X.All(v => v >= scale); if (ge1) g1++;
      int k = 0, n1 = 0, nPL = 0, nVR = 0, both = 0;
      for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) {
        int r = 0, j = i; while (e[j % L]) { r++; j++; } int a = (j - 1) % L, p = j % L; int d = 0; while (!e[j % L]) { d++; j++; } int b = (j - 1) % L;
        k++; if (r == 1) n1++; bool PL = X[a] + X[p] < S; bool VR = 3 * X[b] > 2 * S; if (PL) nPL++; if (VR) nVR++; if (PL && VR) both++; }
      bothLR += both; { double[] gz = new double[L]; double gacc = 0; double zmin = 1e9, zmax = -1e9; for (int i = 0; i < L; i++) { double xv = (double)(X[i] * 1000000000L / scale) / 1e9; double z = Math.Log2(xv) - gacc; zmin = Math.Min(zmin, z); zmax = Math.Max(zmax, z); gacc += e[i] ? Math.Log2(1.5) : -1.0; } double spread = zmax - zmin; spreadMax = Math.Max(spreadMax, spread); spreadSum += spread; if (spread > Math.Log2(1.0 / qv) + 1e-6) spreadBad++; } { double[] gh = new double[L + 1]; for (int i = 0; i < L; i++) gh[i + 1] = gh[i] + (e[i] ? Math.Log2(1.5) : -1.0); double gmax = gh.Take(L).Max(); int nd = 0; for (int i = 0; i < L; i++) if (gh[i] >= gmax - delta) nd++; int aw = k - nPL - nVR; sumND += nd; sumAbsW += aw; if (both == 0 && ge1 && aw > nd) lemmaBad++; maxAbsW = Math.Max(maxAbsW, aw); maxND = Math.Max(maxND, nd); } int w = -(k - nPL - nVR + both * 0); // valid only if no (P_L,V_R) excursion
      if (both == 0) { wHist[w] = wHist.GetValueOrDefault(w) + 1; if (w == -k) flat++; }
      sumK += k; sumN1 += n1; sumPL += nPL; sumVR += nVR; sumW += w; sumRho += -(k - n1); sumLogHc += Math.Log2((double)(H * 1000000 / c) / 1e6); sumMinX += (double)(c * 1000 / scale) / 1000.0;
    }
    Console.WriteLine($"L={L} A={A} eps=1-3^A/2^L={eps:F5} words {used} (values>=1: {g1}); mean k {sumK / used:F2}, n_1 {sumN1 / used:F2} (k/2 = {sumK / used / 2:F2}), mean #low peaks (P_L) {sumPL / used:F2}, mean #high valleys (V_R) {sumVR / used:F2}, excursions with P_L and V_R: {bothLR}");
    Console.WriteLine($"   DISTORTION: max spread of log2(x_j) - g_j = {spreadMax:F3}, mean {spreadSum / used:F3}, bound log2(1/q) = {Math.Log2(1.0 / qv):F3}; violations {spreadBad}");
    Console.WriteLine($"   LEMMA: delta={delta:F3}, mean abs(w) {sumAbsW / used:F3} (max {maxAbsW}), mean N_delta {sumND / used:F3} (max {maxND}), words with abs(w) > N_delta: {lemmaBad}");
    Console.WriteLine($"   mean w {sumW / used:F2}, mean rho {sumRho / used:F2}, mean log2(H/c) {sumLogHc / used:F2}, mean min value c {sumMinX / used:F3}; flat words: {flat}; w histogram: " + string.Join(" ", wHist.Select(t => t.Key + ":" + t.Value)));
  }
}
