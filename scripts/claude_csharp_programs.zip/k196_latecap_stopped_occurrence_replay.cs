using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using System.Text.Json;

// Independent C# replay of the saved-profile checkers: late cap (K196), stopped residual, occurrence budget.
class Run { public int i,j,s,e,ordinal,time; public BigInteger a,b; public F q,qend,delta,psi; }
class Prof { public BigInteger n,H,u,w; public int[] word; public List<BigInteger> odd,shortcut; public List<int> times; public List<F> phases; public int E; public F Q; public List<Run> runs; }

class P {
 static BigInteger P2(int k)=>BigInteger.One<<k;
 static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static F Q(BigInteger a,BigInteger b)=>new F(a,b);
 static int Bits(BigInteger x)=>x.IsZero?0:(int)x.GetBitLength();
 static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
 static BigInteger FloorDiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); if(r!=0 && (r.Sign<0)!=(b.Sign<0)) q-=1; return q; }
 static BigInteger CeilDiv(BigInteger a,BigInteger b)=>-FloorDiv(-a,b);
 static BigInteger Mod(BigInteger a,BigInteger m){ var r=a%m; return r<0?r+m:r; }
 static BigInteger Inv(BigInteger a,BigInteger m){ BigInteger g=m,x=0,x1=1,aa=Mod(a,m); while(aa!=0){ var qq=g/aa; (g,aa)=(aa,g-qq*aa); (x,x1)=(x1,x-qq*x1); } return Mod(x,m); }

 static Dictionary<BigInteger,BigInteger> scCache=new();
 static BigInteger SourceCount(BigInteger n){
  if(scCache.TryGetValue(n,out var got)) return got;
  BigInteger H=(4*n-2)/3; int k=Bits(H-n);
  var powers3=new BigInteger[k+1]; var powersn=new BigInteger[k+1]; var pert=new BigInteger[k+1];
  for(int r=0;r<=k;r++){ powers3[r]=P3(r); powersn[r]=BigInteger.Pow(n,r); pert[r]=BigInteger.Pow(3*n+1,r); }
  var row=new Dictionary<int,BigInteger>{{2,1}}; BigInteger shortc=0;
  for(int j=3;j<=k;j++){
   foreach(var kv in row) if((3*n-k)*P2(j)<3*H*powers3[kv.Key] && n*powers3[kv.Key]<H*P2(j)) shortc+=kv.Value;
   var nx=new Dictionary<int,BigInteger>();
   foreach(var kv in row) for(int bit=0;bit<2;bit++){ int rr=kv.Key+bit; if(P2(j)*powersn[rr]<pert[rr]) nx[rr]=nx.GetValueOrDefault(rr)+kv.Value; }
   row=nx;
  }
  BigInteger newer=shortc; foreach(var v in row.Values) newer+=v;
  row=new Dictionary<int,BigInteger>{{2,1}};
  int hl=Bits(H);
  for(int j=3;j<=hl;j++){
   var nx=new Dictionary<int,BigInteger>();
   foreach(var kv in row) for(int bit=0;bit<2;bit++){ int rr=kv.Key+bit; if(P3(rr)>P2(j-1)) nx[rr]=nx.GetValueOrDefault(rr)+kv.Value; }
   row=nx;
  }
  BigInteger tot=0; foreach(var v in row.Values) tot+=v;
  var res=BigInteger.Min(newer,2*tot); scCache[n]=res; return res;
 }

 static Prof Replay(BigInteger n,BigInteger u,int[] word){
  var H=(4*n-2)/3;
  var odd=new List<BigInteger>{u}; var sh=new List<BigInteger>{u}; var times=new List<int>{0}; var phases=new List<F>{0}; var nums=new List<BigInteger>{0};
  int E=0; BigInteger Nn=0;
  for(int g=1;g<=word.Length;g++){
   int e=word[g-1]; var x=odd[^1]; Chk.A(V2(3*x+1)==e,"valuation");
   var y=(3*x+1)/2; sh.Add(y);
   for(int t=0;t<e-1;t++){ Chk.A(y.IsEven,"even"); y/=2; sh.Add(y); }
   Chk.A(!y.IsEven,"odd"); odd.Add(y);
   Nn=3*Nn+P2(E); E+=e; times.Add(E); nums.Add(Nn); phases.Add(Q(Nn,P3(g)));
   Chk.A(P2(E)*y==P3(g)*u+Nn,"affine");
  }
  int gg=word.Length; var w=odd[^1];
  Chk.A(n<=u&&u<=H&&n<=w&&w<=H,"band");
  for(int i=1;i<gg;i++) Chk.A(odd[i]>H,"proper above H");
  var mod=P2(E+1); var residue=Mod((P2(E)-Nn)*Inv(P3(gg),mod),mod);
  var low=BigInteger.Max(n,CeilDiv(P2(E)*n-Nn,P3(gg)));
  var high=BigInteger.Min(H,FloorDiv(P2(E)*H-Nn,P3(gg)));
  for(int i=1;i<gg;i++) low=BigInteger.Max(low,FloorDiv(P2(times[i])*H-nums[i],P3(i))+1);
  Chk.A(low+Mod(residue-low,mod)==u&&u<=high,"least source");
  var kappa=Q(n-1,n+1);
  var runs=new List<Run>(); int start=0; F fluxSum=0, prod=1;
  for(int end=1;end<=word.Length;end++){
   int e=word[end-1]; if(e<2) continue;
   int s=end-start; var a=odd[start]; var b=odd[end];
   F z=F.Pow(Q(2,3),s), beta=(F)1-z, q=Q(P2(e-1),1)*z, delta=beta/(F)a;
   F flux=Q(1,a)-Q(1,b), psi=F.Max(0,kappa*delta+flux);
   F rho=((F)1+delta)*((F)1+(F)5/(F)b)/((F)1+(F)5/(F)a);
   Chk.A((F)b==((F)a+beta)/q,"run map");
   bool good=rho<=1;
   Chk.A(good==(5*P2(s+e-1)<=4*P3(s)+P2(s)),"good test");
   Chk.A(phases[end]-phases[start]==((F)u+phases[start])*delta,"phase increment");
   runs.Add(new Run{i=start,j=end,a=a,b=b,s=s,e=e,q=phases[start],qend=phases[end],delta=delta,psi=psi,ordinal=runs.Count,time=times[start]});
   fluxSum+=flux; prod*=(F)1+delta; start=end;
  }
  Chk.A(start==gg,"runs cover");
  Chk.A(fluxSum==Q(1,u)-Q(1,w),"flux sum");
  Chk.A(prod==(F)1+phases[^1]/(F)u && prod<Q(47,32),"product");
  return new Prof{n=n,H=H,u=u,w=w,word=word,odd=odd,shortcut=sh,times=times,phases=phases,E=E,Q=phases[^1],runs=runs};
 }

 static List<int> ActualCore(Prof p,BigInteger Pn){
  var n=p.n; int L=Bits(n)-1, m=Bits(n); F B=(F)5+Q(n,100000*Pn); var sel=new List<int>();
  for(int k=0;k<p.runs.Count;k++){
   var r=p.runs[k]; var a=r.a; int ell=Bits(a)-1, t=ell-L;
   BigInteger J=P2(ell)/(2000*Pn*(t+1)*(t+2));
   int pos=r.time+ell;
   if(r.i>0 && p.H<a && a<P2(64*m) && pos<p.E && 64*p.shortcut[pos]>a && r.q>B && p.Q-r.q>B && k>J && p.runs.Count-k>J) sel.Add(k);
  }
  return sel;
 }

 static BigInteger Scale=BigInteger.One<<256;
 static F Up(F x)=>Q(-FloorDiv(-x.n*Scale,x.D),Scale);
 static F Down(F x)=>Q(FloorDiv(x.n*Scale,x.D),Scale);
 static F ExpUp(F z){
  z=Up(z); Chk.A(z>=0&&z<1,"expup range");
  F s=0,t=1; for(int j=0;j<13;j++){ s+=t; t=t*z/(j+1); }
  // t is now z^13/13!
  return s+t/((F)1-z/14);
 }
 static Dictionary<BigInteger,(int L,F v,int S)> bud=new();
 static (int L,F v,int S) Budget(BigInteger n){
  if(bud.TryGetValue(n,out var g)) return g;
  var H=(4*n-2)/3; int L=Bits(H+1)-1; F best=0; int bs=-1;
  F pow=Q(193,200); // (193/200)^(s+1)
  for(int s=0;s<2*L+1;s++){
   F v=Q(P3(s)-1,P2(L))+Q(200,7)*pow+Q(L+1,P2(L-1)); pow=pow*Q(193,200);
   if(bs<0||v<best){best=v;bs=s;}
  }
  var res=(L,best,bs); bud[n]=res; return res;
 }
 static (F Qbar,F b,F v) Caps(BigInteger n,BigInteger u,IEnumerable<BigInteger> xs,F q){
  var (L,v,S)=Budget(n); F used=0, high=0; var lim=P2(L);
  foreach(var x in xs){ var d=Q(FloorDiv(Scale,x),Scale); used+=d; if(x>=lim) high+=d; }
  F b=F.Min(Q(144,125)-used,v-high); Chk.A(b>=0,"b nonneg");
  F bas=Q(15*u,32);
  F expcap=Up((((F)1+q/(F)u)*ExpUp(b/3)-1))*(F)u;
  F lin=Up((q/(F)u+Q(47,32)*b/3))*(F)u;
  return (F.Min(bas,F.Min(expcap,lin)),Up(b),v);
 }
 static Dictionary<BigInteger,(int L,F v,int r)> ibud=new();
 static (int L,F v,int r) Improved(BigInteger n){
  if(ibud.TryGetValue(n,out var g)) return g;
  var H=(4*n-2)/3; int L=Bits(H+1)-1; F best=0; int br=-1; F pow=Q(1923,2000);
  for(int r=0;r<2*L+1;r++){
   F v=Q(P3(r)-1,P2(L))+Q(2000,77)*pow+Q(L+1,P2(L-1)); pow=pow*Q(1923,2000);
   if(br<0||v<best){best=v;br=r;}
  }
  var res=(L,best,br); ibud[n]=res; return res;
 }
 static (F Qb,F b,F old,F bold,int r) NewCap(BigInteger n,BigInteger u,List<BigInteger> xs,F q){
  var (old,metaB,_)=Caps(n,u,xs,q);
  var (L,v,r)=Improved(n); F used=0; var lim=P2(L);
  foreach(var x in xs) if(x>=lim) used+=Down(Q(1,x));
  F b=F.Min(metaB,Up(v-used)); Chk.A(b>=0,"new b nonneg");
  F Qb=F.Min(old,F.Min(Up((((F)1+q/(F)u)*ExpUp(b/3)-1))*(F)u,Up(q/(F)u+Q(47,96)*b)*(F)u));
  return (Qb,b,old,metaB,r);
 }
 static F Potential(BigInteger n,BigInteger u,F B,F q,F Qbar){
  var H=(4*n-2)/3; var a=H+1+Mod(11-H-1,16); F d=Q(5,9*a);
  F C=Q(n-1,n+1)+Q(9*(a+5),5*(9*a+5)); F T=Qbar-B; F lo=F.Max(q,B);
  if(lo>=T) return 0;
  return C*(F.Min(Qbar,T+d*((F)u+T))-lo)/((F)u+lo);
 }

 static BigInteger Big(JsonElement e)=>BigInteger.Parse(e.ValueKind==JsonValueKind.String?e.GetString():e.GetRawText());
 static JsonElement Load(string p)=>JsonDocument.Parse(File.ReadAllText(p)).RootElement;
 static int[] Word(JsonElement e)=>e.EnumerateArray().Select(x=>x.GetInt32()).ToArray();

 static void Main(string[] args){
  string tmp=args[0];
  var seeds=Load(tmp+"/compensation_packet_audit/input/exact_compensation_seeds.json");
  var wanted=new HashSet<(BigInteger,BigInteger)>(Load(tmp+"/singleton_charge_bounds/checks.json").GetProperty("rows").EnumerateArray().Select(r=>(Big(r.GetProperty("n")),Big(r.GetProperty("u")))));
  var fr=Load(tmp+"/unresolved_phase_caps/checks.json").GetProperty("new_unresolved");

  // ---- late cap (K196) ----
  int checks=0,improves=0,charge=0;
  foreach(var gr in seeds.GetProperty("groups").EnumerateArray()){
   var n=Big(gr.GetProperty("n")); var Pn=SourceCount(n); F B=(F)5+Q(n,100000*Pn);
   foreach(var item in gr.GetProperty("sources").EnumerateArray()){
    var u=Big(item.GetProperty("u")); if(!wanted.Contains((n,u))) continue;
    var p=Replay(n,u,Word(item.GetProperty("word")));
    var core=new HashSet<int>(ActualCore(p,Pn));
    var sel=p.runs.Where((r,j)=>core.Contains(j)&&r.s==2&&r.e==2).ToList();
    foreach(var rr in p.runs){
     int g=rr.i; F q=rr.q;
     var xs=p.odd.Take(g).ToList();
     var (Qb,b,Qold,bold,r)=NewCap(n,u,xs,q);
     F actual=0; for(int j=g;j<p.odd.Count-1;j++) actual+=Q(1,p.odd[j]);
     Chk.A(actual<=b && p.Q<=Qb && Qb<=Qold,"cap validity"); checks++; if(b<bold) improves++;
     var a0=p.H+1+Mod(11-p.H-1,16); F d=Q(5,9*a0);
     F gap=B-d*((F)u+Qb-B); F tail=(F)6*gap/((F)2*((F)u+Qb)-gap);
     F entry=F.Max(0,(F)6*(B-q)/((F)(2*u)+B+q)); F res=F.Max(0,b-entry-tail);
     F oldgap=B-d*((F)u+Qold-B); F oldt=(F)6*oldgap/((F)2*((F)u+Qold)-oldgap); F oldres=F.Max(0,bold-entry-oldt);
     Chk.A(res<=oldres,"residual not worse");
     var f=sel.Where(x=>x.i>=g).ToList(); F cst=0; foreach(var x in f) for(int j=x.i;j<x.j;j++) cst+=Q(1,p.odd[j]);
     Chk.A(cst<=res,"future charge within residual"); if(f.Count>0) charge++;
    }
   }
  }
  Console.WriteLine($"late cap: prefix checks {checks} (claimed 321), strict improvements {improves} (claimed 120), cases with future selected runs {charge} (saved 119)");
  Chk.A(checks==321&&improves==120&&charge==119,"late cap counts");
  {
   var n=Big(fr.GetProperty("n")); var u=Big(fr.GetProperty("u")); F q=F.Of(fr.GetProperty("q").GetString());
   var x=u; var xs=new List<BigInteger>(); foreach(var e in Word(fr.GetProperty("word"))){ xs.Add(x); x=(3*x+1)/P2(e); }
   var (Qb,b,Qold,bold,r)=NewCap(n,u,xs,q);
   Console.WriteLine($"fresh unresolved: depth {xs.Count}, u=2^256-1: {u==P2(256)-1}, n=3*2^254+1: {n==3*P2(254)+1}, b ratio {(b/bold).ToDouble():F9} (claimed 0.524294614), phase cap ratio {(Qb/Qold).ToDouble():F9} (claimed 0.519775973)");
   Chk.A(Math.Abs((b/bold).ToDouble()-0.524294614)<2e-9 && Math.Abs((Qb/Qold).ToDouble()-0.519775973)<2e-9,"fresh ratios");
  }
  Chk.A(F.Pow(Q(125993,100000),3)>2,"cube"); Chk.A(Q(8776241853,2500000000)>(F)3*F.Pow(Q(2000,1923),4),"const"); Chk.A(P3(883)<P2(1400),"3^883"); Chk.A(P2(50)*BigInteger.Pow(1923,883)<BigInteger.Pow(2000,883),"tail power");

  // ---- stopped residual ----
  F cap=F.Of("80147532093873483207202441389202356216370417427993932413259609/116072302821007019464487645911519890966854661759054802751324160");
  int controls=0;
  F A=Q(1001,1000);
  for(int n=15;n<256;n+=2){
   int H=(4*n-2)/3, W=H-n; var groups=new Dictionary<string,(int E,F cost,int count)>();
   for(int u=n;u<=H;u+=2){
    BigInteger x=u; int E=0; var word=new List<int>(); bool live=true; F lamq=0;
    for(int g=0;g<2;g++){
     F lam=Q(P2(E),P3(g)); if(lam>A||P2(E+1)>2*W){live=false;break;}
     var z=3*x+1; int e=V2(z); x=z>>e; E+=e; word.Add(e); if(x<=H){live=false;break;}
    }
    if(!live||P2(E+1)>2*W||Q(P2(E),9)>A) continue;
    var key=string.Join(",",word);
    var ent=groups.ContainsKey(key)?groups[key]:(E,(F)0,0); ent.Item3++;
    for(int g=2;g<12;g++){
     if(x<=H||P2(E+1)>2*W||Q(P2(E),P3(g))>A) break;
     ent.Item2+=Q(1,x); var z=3*x+1; int e=V2(z); x=z>>e; E+=e;
    }
    groups[key]=ent;
   }
   foreach(var v in groups.Values){ Chk.A((F)v.count<=Q(W,P2(v.E)),"antichain count"); Chk.A(v.cost<=Q(3*W,n)*Q(1,P2(v.E))*A,"antichain cost"); controls++; }
  }
  var rows=new List<(BigInteger n,F res,F sh,bool bearing,bool past)>();
  var seen=new HashSet<(BigInteger,BigInteger)>(); int profiles=0,allR=0,early=0,late=0,positive=0,occ=0;
  var gEarly=new Dictionary<BigInteger,F>(); var gActual=new Dictionary<BigInteger,F>();
  foreach(var group in seeds.GetProperty("groups").EnumerateArray()){
   var n=Big(group.GetProperty("n")); if(n<P2(71)) continue;
   var Pn=SourceCount(n); F B=(F)5+Q(n,100000*Pn);
   foreach(var item in group.GetProperty("sources").EnumerateArray()){
    var u=Big(item.GetProperty("u")); if(!seen.Add((n,u))) continue;
    var p=Replay(n,u,Word(item.GetProperty("word"))); profiles++; var H=p.H; var W=H-n;
    var core=new HashSet<int>(ActualCore(p,Pn));
    var selected=p.runs.Where((r,j)=>core.Contains(j)&&r.s==2&&r.e==2).ToList();
    foreach(var rr in selected){ allR++; for(int j=rr.i;j<rr.j;j++){ if(P2(p.times[j]+1)<=2*W) early++; else late++; } }
    var counts=new List<BigInteger>(); var lower=n;
    for(int j=0;j<p.word.Length;j++){
     int exp=p.times[j]; F ph=p.phases[j]*(F)P3(j); Chk.A(ph.D.IsOne,"integral numerator"); var num=ph.n; var mod=P2(exp+1);
     if(j>0) lower=BigInteger.Max(lower,FloorDiv(P2(exp)*H-num,P3(j))+1);
     var residue=Mod((P2(exp)-num)*Inv(P3(j),mod),mod); var first=lower+Mod(residue-lower,mod);
     counts.Add(BigInteger.Max(0,FloorDiv(H-first,mod)+1)); Chk.A(counts[^1]>=1,"count>=1");
    }
    var bnd=p.runs.Where(r=>counts[r.i]==1).ToList(); if(bnd.Count==0) continue;
    var r0=bnd[0]; int g=r0.i; F q=p.phases[g];
    var (Qbar,b,_)=Caps(n,u,p.odd.Take(g),q);
    var a0=H+1+Mod(11-H-1,16); F delta=Q(5,9*a0); F gap=B-delta*((F)u+Qbar-B); Chk.A(gap>0,"gap>0");
    F entry=F.Max(0,(F)6*(B-q)/((F)(2*u)+B+q)); F tail=(F)6*gap/((F)2*((F)u+Qbar)-gap); F t=entry+tail; F res=F.Max(0,b-t);
    int cut=p.word.Length; for(int j=g;j<p.word.Length;j++) if(P2(p.times[j]+1)>2*W){cut=j;break;}
    F lateCap=0; if(cut!=p.word.Length) lateCap=Caps(n,u,p.odd.Take(cut),p.phases[cut]).b;
    var xmax=P2(64*Bits(n))-5; F beta=Q(1,xmax)+Q(2,3*xmax+1);
    F sh=F.Max(0,beta+t-lateCap); if(sh>0) positive++;
    F ear=0; for(int j=g;j<cut;j++) ear+=Q(1,p.odd[j]);
    F actualLate=0; for(int j=cut;j<p.odd.Count-1;j++) actualLate+=Q(1,p.odd[j]);
    Chk.A(actualLate<=lateCap,"late cap valid");
    var future=selected.Where(rr=>rr.i>=g).ToList(); bool bearing=future.Count>0; if(bearing)occ++;
    if(bearing){ Chk.A(sh<=ear,"shortfall<=early"); F cst=0; foreach(var rr in future) for(int j=rr.i;j<rr.j;j++) cst+=Q(1,p.odd[j]); Chk.A(cst<=res,"cost<=res"); }
    rows.Add((n,res,sh,bearing,P2(p.times[g]+1)>2*W));
    gEarly[n]=(gEarly.ContainsKey(n)?gEarly[n]:(F)0)+ear;
    if(!gActual.ContainsKey(n)) gActual[n]=0; if(bearing) gActual[n]+=res;
   }
  }
  int strictGroups=0;
  foreach(var grp in rows.GroupBy(r=>r.n)){
   var n=grp.Key; F Acap=Q(3*((4*n-2)/3-n),n)*cap; Chk.A(gEarly[n]<=Acap,"early<=Acap");
   var cands=new List<F>{0}; cands.AddRange(grp.Where(r=>r.sh>0).Select(r=>r.res/r.sh));
   F dual=0; bool first=true;
   foreach(var lam in cands){ F val=lam*Acap; foreach(var r in grp) val+=F.Max(0,r.res-lam*r.sh); if(first||val<dual){dual=val;first=false;} }
   F raw=0; foreach(var r in grp) raw+=r.res;
   Chk.A(gActual[n]<=dual&&dual<=raw,"dual sandwich"); if(dual<raw) strictGroups++;
  }
  bool freshPast=P2(fr.GetProperty("E").GetInt32()+1)>2*(Big(fr.GetProperty("H"))-Big(fr.GetProperty("n")));
  Console.WriteLine($"stopped residual: antichain controls {controls}; high-floor profiles {profiles}; selected R runs {allR}; early inputs {early}; late inputs {late}; singleton frontiers {rows.Count} (past cutoff {rows.Count(r=>r.past)}, occurrence-bearing {occ}); positive shortfalls {positive}; strict group improvements {strictGroups}; fresh past cutoff {freshPast}");
  Chk.A(profiles==18&&allR==41&&early==82&&late==0&&rows.Count==7&&rows.Count(r=>r.past)==3&&occ==0&&positive==0,"stopped counts");

  // ---- occurrence budget ----
  F Cost(BigInteger a)=>Q(1,a)+Q(2,3*a+1);
  var old=Load(tmp+"/singleton_charge_bounds/checks.json").GetProperty("rows").EnumerateArray().ToList();
  int oc=0,pos=0,better=0,countTests=0;
  (F gamma,F beta2,F beta3) Consts(BigInteger n){
   var H=(4*n-2)/3; var a0=H+1+Mod(11-H-1,16); F C=Q(n-1,n+1)+Q(9*(a0+5),5*(9*a0+5)); F gamma=C*Q(5*(3*a0+1),9*(5*a0+1));
   var Am=P2(64*Bits(n))-1; var amax=Am-Mod(Am-11,16);
   F b2=Cost(amax)+Cost(amax-16); return (gamma,b2,b2+Cost(amax-32));
  }
  foreach(var group in seeds.GetProperty("groups").EnumerateArray()){
   var n=Big(group.GetProperty("n"));
   foreach(var item in group.GetProperty("sources").EnumerateArray()){
    var u=Big(item.GetProperty("u")); if(!wanted.Contains((n,u))) continue;
    var p=Replay(n,u,Word(item.GetProperty("word"))); var Pn=SourceCount(n); F B=(F)5+Q(n,100000*Pn);
    var core=new HashSet<int>(ActualCore(p,Pn));
    var selected=p.runs.Where((r,j)=>core.Contains(j)&&r.s==2&&r.e==2).ToList();
    var (gamma,b2,b3)=Consts(n);
    foreach(var r in p.runs){
     int d=r.i; F q=r.q; var (capv,b,_)=Caps(n,u,p.odd.Take(d),q);
     var future=selected.Where(rr=>rr.i>=d).ToList();
     F ch=0; foreach(var rr in future) ch+=rr.psi; F pc=0; foreach(var rr in future) pc+=Cost(rr.a);
     F bound=gamma*b; F v=Potential(n,u,B,q,capv);
     Chk.A(pc<=b&&ch<=gamma*pc&&gamma*pc<=bound,"charge chain"); oc++; if(ch>0){pos++; if(bound<v)better++;}
     if(future.Count>=2){ Chk.A(b2<=pc&&pc<=b,"k=2"); countTests++; }
     if(future.Count>=3){ Chk.A(b3<=pc&&pc<=b,"k=3"); countTests++; }
    }
   }
  }
  var saved=Load(tmp+"/occurrence_budget/checks.json");
  Console.WriteLine($"occurrence budget: charge checks {oc}, positive {pos}, improved {better}, necessity checks {countTests}; saved {saved.GetProperty("charge_checks")},{saved.GetProperty("positive_charge_cases")},{saved.GetProperty("improved_vs_K188_phase_in_positive_cases")},{saved.GetProperty("occurrence_necessity_checks")}");
  Chk.A(oc==saved.GetProperty("charge_checks").GetInt32()&&pos==saved.GetProperty("positive_charge_cases").GetInt32()&&better==saved.GetProperty("improved_vs_K188_phase_in_positive_cases").GetInt32()&&countTests==saved.GetProperty("occurrence_necessity_checks").GetInt32(),"occurrence counts");
  {
   var n=Big(fr.GetProperty("n")); var u=Big(fr.GetProperty("u")); var cps=fr.GetProperty("checkpoints").EnumerateArray().ToList();
   F b=F.Of(cps[^1].GetProperty("b").GetString()); var (gamma,b2,b3)=Consts(n); F nb=gamma*b; F v=F.Of(fr.GetProperty("potential").GetString());
   Chk.A(nb<v,"fresh new bound below phase bound");
   Console.WriteLine($"fresh: new/old charge bound ratio {(nb/v).ToDouble():F9}; k2 excluded {b<b2}; k3 excluded {b<b3}");
  }
  for(int a=11;a<3212;a+=16){ F dlt=Q(5,9*a); Chk.A(dlt/Cost(a)==Q(5*(3*a+1),9*(5*a+1))&&Cost(a+16)<Cost(a),"local ratio"); }
  Console.WriteLine($"checks passed {Chk.pass}, failed {Chk.fail}");
 }
}
