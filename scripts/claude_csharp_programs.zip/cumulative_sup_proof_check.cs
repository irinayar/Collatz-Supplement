using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long words = 0, ge1 = 0, signRuleBad = 0, lrBad = 0, lrBadGe1 = 0, supBad = 0, supBadGe1 = 0; double supAll = -9, supGe1 = -9, wMaxGe1 = -9, wMaxAll = -9;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2, s = c + H;
        bool g1 = x.All(v => v >= 1.0 - 1e-12);
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        var d = new double[L]; bool deg = false;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; d[i] = a; }
        if (deg) continue; words++; if (g1) ge1++;
        // sign rules for cross edges
        for (int i = 0; i < L; i++) { int j = (i + 1) % L;
          if (e[i] && !e[j]) { bool rule = x[i] + x[j] < s; if ((d[i] > 0) != rule) signRuleBad++; }
          if (!e[i] && e[j]) { bool rule = x[i] + x[j] > s; if ((d[i] > 0) != rule) signRuleBad++; }
        }
        // excursion pairs: peak edge i (e[i]&&!e[i+1]) followed in time by the next valley edge (!e[j]&&e[j+1]); both delta>0 forbidden
        for (int i = 0; i < L; i++) { int i1 = (i + 1) % L; if (!(e[i] && !e[i1])) continue; int j = i1; while (!( !e[j] && e[(j + 1) % L])) j = (j + 1) % L; if (d[i] > 0 && d[j] > 0) { lrBad++; if (g1) lrBadGe1++; } }
        // supremum of cumulative winding over all starts and t up to 3L
        double sup = -9; for (int st = 0; st < L; st++) { double cur = 0; for (int t = 1; t <= 3 * L; t++) { cur += d[(st + t - 1) % L]; if (cur > sup) sup = cur; } }
        supAll = Math.Max(supAll, sup / (2 * Math.PI)); if (g1) supGe1 = Math.Max(supGe1, sup / (2 * Math.PI)); if (sup >= 2 * Math.PI) { supBad++; if (g1) supBadGe1++; }
        double tot = d.Sum() / (2 * Math.PI); wMaxAll = Math.Max(wMaxAll, tot); if (g1) wMaxGe1 = Math.Max(wMaxGe1, tot);
      }
    }
    Console.WriteLine($"words {words} (all values >= 1: {ge1}). sign-rule violations (delta>0 iff a+p<c+H for peak edges, iff b+b/2>c+H for valley edges): {signRuleBad}");
    Console.WriteLine($"excursions with peak delta>0 and valley delta>0: {lrBad} (all-values>=1 words: {lrBadGe1})");
    Console.WriteLine($"sup over starts, t<=3L of Phi/2pi: all words {supAll:F6}, all-values>=1 words {supGe1:F6}; windows with Phi>=2pi: {supBad} (values>=1: {supBadGe1}); largest w: {wMaxAll:F3} / {wMaxGe1:F3}");
  }
}
