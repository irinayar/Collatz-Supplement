using System;
using System.Linq;
// Monte Carlo check of the bridge bound: for uniform words with A ones (L,A),
//   E N(delta) <= L * P(max_{0<=t<=L} S_t <= delta)  and the size of both, delta = log2(5/3) + eps'
static class P {
  static void Main(string[] args) {
    int L = int.Parse(args[0]), A = int.Parse(args[1]), T = int.Parse(args[2]); var rng = new Random(2026);
    double th = Math.Log2(1.5), l23 = Math.Log2(3); double eps = L - A * l23; double delta = Math.Log2(5.0 / 3.0) + eps;
    double sumN = 0; long good = 0; var perm = Enumerable.Range(0, L).ToArray(); var e = new bool[L]; double sumN0 = 0;
    for (int it = 0; it < T; it++) {
      for (int i = L - 1; i > 0; i--) { int j = rng.Next(i + 1); (perm[i], perm[j]) = (perm[j], perm[i]); }
      Array.Clear(e); for (int i = 0; i < A; i++) e[perm[i]] = true;
      double[] g = new double[L + 1]; for (int i = 0; i < L; i++) g[i + 1] = g[i] + (e[i] ? th : -1.0);
      double gmax = g.Take(L).Max(); int n = 0, n0 = 0; for (int i = 0; i < L; i++) { if (g[i] >= gmax - delta) n++; if (g[i] >= gmax - 0.737) n0++; }
      sumN += n; sumN0 += n0; double m = 0; for (int t = 0; t <= L; t++) m = Math.Max(m, g[t]); if (m <= delta) good++;
    }
    Console.WriteLine($"L={L} A={A} eps'={eps:F3} delta={delta:F3}: E N(delta)={sumN / T:F2}; L*P(max S <= delta)={(double)L * good / T:F2} ({good} hits of {T}); E N(0.737)={sumN0 / T:F2}");
  }
}
