using System;
using System.Numerics;
using System.Collections.Generic;
// Check of ChatGPT 134921 joint bound 2*(3/2)^R_e(x) <= 2^e (x+1) with exact R_e (Codex K085 recursion; independently validated by DFS in note 134535),
// plus data: tightness and max of R_e(x)-e over x<=20000, e<=12.
class P {
  static int V3(BigInteger n){int c=0; while(n%3==0){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int),int> memo=new();
  static int R(BigInteger x,int k){ int a=V3(x+1); if(k==0) return a; if(memo.TryGetValue((x,k),out var v)) return v; int best=-1;
    for(int l=0;l<=a;l++){ BigInteger y=BigInteger.Pow(2,l)*(x+1)/BigInteger.Pow(3,l)-1; int t=l+R(2*y,k-1); if(t>best) best=t; } memo[(x,k)]=best; return best; }
  static void Main(){
    long cells=0,viol=0,tight=0; double minSlack=1e18; int maxExcess=-99; string ex=""; 
    var perE=new int[13]; var argE=new long[13];
    for(int x=1;x<=20000;x++) for(int e=0;e<=12;e++){ int r=R(x,e); cells++;
      // 2*3^r <= 2^(e+r) (x+1)
      BigInteger lhs=2*BigInteger.Pow(3,r), rhs=BigInteger.Pow(2,e+r)*(x+1);
      if(lhs>rhs) viol++; if(lhs==rhs) tight++;
      double s=Math.Exp(BigInteger.Log(rhs)-BigInteger.Log(lhs)); if(s<minSlack) minSlack=s;
      if(r-e>perE[e]){perE[e]=r-e; argE[e]=x;} if(r-e>maxExcess){maxExcess=r-e;ex=$"x={x},e={e},R={r}";}
      if(memo.Count>2000000) memo.Clear(); }
    Console.WriteLine($"cells {cells}, joint-bound violations {viol}, equality cases {tight}, min ratio rhs/lhs {minSlack:F4}, max (R_e-e) {maxExcess} at {ex}");
    for(int e=0;e<=12;e++) Console.Write($"e={e}:{perE[e]}@{argE[e]} "); Console.WriteLine();
  }
}
