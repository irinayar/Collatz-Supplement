using System;
using System.Collections.Generic;
using System.Numerics;
// Check of the weight w_p=3^g/2^(E+g) used in K151/K154 on real merge groups: (a) Kraft step: for an inverse step into v the admissible exponents e (2^e v = 1 mod 3) give weights 3/2^(e+1) summing to 1 (e odd class) or 1/2 (e even class) -> antichain sum <=1;
// (b) the identity w_p = y/(u G_prefix 2^g) ; (c) the concrete merge groups: n=55 (anchor 91: sources 63,71) and n=65535 (anchor 109031: sources 72687,76575,80671): incoming g,E,w_p, full-return charge b_p (>0), weighted sum sum w_p b_p vs unweighted sum b_p.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Group(long n,long anchor,long[] srcs){
    long H=(4*n-2)/3; double sw=0,sb=0,swb=0; Console.WriteLine($"n={n}, H={H}, anchor {anchor}");
    foreach(long u in srcs){ // incoming prefix u -> anchor
      long x=u; int g=0,E=0; double Gp=1; while(x!=anchor){ int e; Gp*=1+1.0/(3.0*x); x=A(x,out e); g++; E+=e; if(g>10000) throw new Exception("no path"); }
      double w=Math.Exp(g*Math.Log(3)-(E+g)*Math.Log(2));
      // check identity w = y/(u Gprefix 2^g)
      double w2=(double)anchor/((double)u*Gp*Math.Pow(2,g));
      // full return charge b_p from source u to first return into [n,H]
      long y=u; int G2=0; double Gfull=1; while(true){ int e; Gfull*=1+1.0/(3.0*y); y=A(y,out e); G2++; if(y<=H) break; }
      double rho=Gfull*(1+5.0/y)/(1+5.0/u); double b=rho-1;
      Console.WriteLine($"   source {u}: incoming depth g={g}, E={E}, w_p={w:E3} (identity check {w2:E3}), full return length {G2}, arrival {y}, b_p={b:F6}");
      sw+=w; sb+=b; swb+=w*b; }
    Console.WriteLine($"   sum w_p={sw:E3} (<=1: {sw<=1}); sum b_p (unweighted)={sb:F6}; sum w_p b_p (weighted)={swb:E3}");
  }
  static void Main(){
    // (a) Kraft step
    double sOdd=0,sEven=0; for(int e=1;e<=60;e++){ double w=3.0/Math.Pow(2,e+1); if(e%2==1) sOdd+=w; else sEven+=w; } Console.WriteLine($"(a) inverse-step weights 3/2^(e+1): odd exponents sum {sOdd:F6}, even exponents sum {sEven:F6} (each admissible class sums to <=1)");
    Group(55,91,new long[]{63,71});
    Group(65535,109031,new long[]{72687,76575,80671});
  }
}
