using System; using System.Numerics;
// K196 (CollatzThree_v4 Sec.4): V_{L,r}=(3^r-1)/2^L+(2000/77)(1923/2000)^(r+1)+(L+1)2^(1-L); recompute the fresh unresolved source u=2^256-1 caps and the exact inequalities used.
class P { static void Main(){
 Console.WriteLine("(125993/100000)^3>2: "+(BigInteger.Pow(125993,3)>2*BigInteger.Pow(100000,3)));
 Console.WriteLine("8776241853/2500000000 > 3(2000/1923)^4: "+(BigInteger.Parse("8776241853")*BigInteger.Pow(1923,4)>3*2500000000L*BigInteger.Pow(2000,4)));
 Console.WriteLine("3^883<2^1400: "+(BigInteger.Pow(3,883)<BigInteger.Pow(2,1400))+";  2^50*1923^883<2000^883: "+(BigInteger.Pow(2,50)*BigInteger.Pow(1923,883)<BigInteger.Pow(2000,883)));
 int L=256; double best=1e9; int br=-1;
 for(int r=0;r<=2*L;r++){ double v=Math.Exp(r*Math.Log(3)-L*Math.Log(2)) + (2000.0/77)*Math.Exp((r+1)*Math.Log(1923.0/2000)) + (L+1)*Math.Pow(2,1-L); if(v<best){best=v;br=r;} }
 double bOld=0.108675114; // K188 value (S=156)
 double bNew=Math.Min(bOld,best); // observed inputs >= 2^L: reciprocals about 2.6e-77, negligible
 double qOver=Math.Exp(bNew/3)-1, qOldOver=Math.Exp(bOld/3)-1; double lin=47.0*bNew/96;
 Console.WriteLine($"best r={br}, V_L={best:F9}; b_new={bNew:F9}; b ratio={bNew/bOld:F10}");
 Console.WriteLine($"Qbar_new/u=min(exp-form {qOver:F9}, linear {lin:F9}); Qbar ratio vs old exp-form = {Math.Min(qOver,lin)/qOldOver:F10}");
}}
