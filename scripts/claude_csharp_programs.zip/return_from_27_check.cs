using System;
using System.Numerics;
// ChatGPT 181416 finite-certificate item: return from source 27: gap 37, E=59, 15 resets (exponents>=2), arrival 23, least proper state 31; active at n=21 and n=23; not reached from 21 or 23.
// Also its boundary contribution 7*2^56/3^37 - 1.
class P {
  static BigInteger A(BigInteger u,out int e){ BigInteger x=3*u+1; e=0; while(x.IsEven){x/=2;e++;} return x; }
  static void Main(){
    BigInteger u=27; int g=0,E=0,resets=0; BigInteger least=BigInteger.Pow(10,40); var states=new System.Collections.Generic.List<BigInteger>{u};
    for(int i=0;i<200;i++){ int e; u=A(u,out e); g++; E+=e; if(e>=2) resets++; states.Add(u); if(u<=30){ break; } if(u<least) least=u; }
    Console.WriteLine($"from 27: first state <=30 after gap {g}: arrival {u}, total exponent {E}, exponents>=2: {resets}, least proper state {least}");
    foreach(int n in new[]{21,23}){ int H=(4*n-2)/3; Console.WriteLine($"n={n}: H={H}, I=[{n},{H}], 27 in I: {27>=n&&27<=H}, arrival {u} in I: {u>=n&&u<=H}, least proper {least} > H: {least>H}"); }
    // is 27 reached from 21 or 23 (odd-to-odd orbit)? follow orbit of 21 and 23 until 1 and see whether 27 appears; also 23 from 21
    foreach(int n0 in new[]{21,23}){ BigInteger x=n0; bool seen27=false; int steps=0; while(x!=1 && steps<500){ int e; x=A(x,out e); steps++; if(x==27) seen27=true; } Console.WriteLine($"orbit of {n0}: reaches 27: {seen27}"); }
    double c=7*Math.Pow(2,56)/Math.Pow(3,37)-1; Console.WriteLine($"boundary contribution 7*2^56/3^37 - 1 = {c:F6}");
  }
}
