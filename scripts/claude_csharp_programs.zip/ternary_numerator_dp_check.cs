using System;
using System.Collections.Generic;
// Independent check of ChatGPT 092552: recurrence for M_{j,a}(r) = max{U(w) : |w|=j, ones=a, U(w) = r mod 3^a}, and the same-count meeting test.
class P {
  static long Pow3(int a) { long p = 1; for (int i = 0; i < a; i++) p *= 3; return p; }
  static void Main() {
    int J = 12; var M = new Dictionary<(int, long), long>[J + 2, J + 2];   // M[j,a][(a,r)] stored as dict r -> max
    var tab = new Dictionary<long, long>[J + 1, J + 1]; for (int j = 0; j <= J; j++) for (int a = 0; a <= J; a++) tab[j, a] = new Dictionary<long, long>();
    tab[0, 0][0] = 0;
    for (int j = 0; j < J; j++) for (int a = 0; a <= j + 1; a++) {
      long mod = Pow3(a);
      if (a <= j) foreach (var kv in tab[j, a]) { long r = kv.Key % mod; if (!tab[j + 1, a].TryGetValue(r, out var cur) || kv.Value > cur) tab[j + 1, a][r] = kv.Value; }
      if (a >= 1) foreach (var kv in tab[j, a - 1]) { long U = (1L << j) + 3 * kv.Value; long r = U % mod; if (!tab[j + 1, a].TryGetValue(r, out var cur) || U > cur) tab[j + 1, a][r] = U; }
    }
    // M table must be the max of actual U over words per residue; the recurrence above stores only maxima (as in the note). Compare with brute force.
    long eqCount = 0, eqBad = 0;
    for (int j = 0; j <= J; j++) {
      var bf = new Dictionary<(int, long), long>();
      for (int w = 0; w < (1 << j); w++) { int a = 0; long U = 0; int h = 0; var pos = new List<int>(); for (int i = 0; i < j; i++) if (((w >> i) & 1) == 1) { pos.Add(i); a++; }
        for (int k = 0; k < pos.Count; k++) U += (1L << pos[k]) * Pow3(a - 1 - k);
        long r = U % Pow3(a); if (!bf.TryGetValue((a, r), out var c) || U > c) bf[(a, r)] = U; }
      foreach (var kv in bf) { eqCount++; if (!tab[j, kv.Key.Item1].TryGetValue(kv.Key.Item2, out var v) || v != kv.Value) eqBad++; }
      for (int a = 0; a <= j; a++) foreach (var kv in tab[j, a]) { if (!bf.TryGetValue((a, kv.Key), out var v) || v != kv.Value) eqBad++; }
    }
    Console.WriteLine($"Theorem 1 (recurrence vs enumeration), j<=12: {eqCount} (j,a,r) entries compared, mismatches {eqBad}");
    // Theorem 2: same-count meeting test vs forward brute force over all m < n
    long cases = 0, bad = 0, yes = 0;
    for (int j = 1; j <= 10; j++) for (long n = 1; n <= 1500; n++) {
      long z = n; int a = 0; long U = 0; var pos = new List<int>(); for (int i = 0; i < j; i++) { if ((z & 1) == 1) { pos.Add(i); a++; z = (3 * z + 1) / 2; } else z /= 2; }
      for (int k = 0; k < pos.Count; k++) U += (1L << pos[k]) * Pow3(a - 1 - k);
      long y = z, r = ((1L << j) * y) % Pow3(a); bool test = tab[j, a].TryGetValue(r, out var Mv) && Mv > U;
      bool brute = false; for (long m = 1; m < n && !brute; m++) { long w = m; int c = 0; for (int i = 0; i < j; i++) { if ((w & 1) == 1) { c++; w = (3 * w + 1) / 2; } else w /= 2; } if (w == y && c == a) brute = true; }
      cases++; if (test != brute) bad++; if (brute) yes++; }
    Console.WriteLine($"Theorem 2 (same-count meeting iff M > U): {cases} (n<=1500, j<=10) cases, with a same-count smaller partner {yes}, mismatches {bad}");
  }
}
