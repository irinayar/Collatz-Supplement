using System.Numerics;
using System;
using System.Numerics;
// Check of ChatGPT 203708 Thm 1-2: run-start map F on B={odd u: 1025<=u<=1000001}; excursion = maximal segment of run starts in B; exit when next start <=1023 or >H.
class P {
  const long H=1000001; const long LO=1025;
  static long Next(long u,out double lc){ int s=BitOperations.TrailingZeroCount((ulong)(u+1)); long w=Pow3(s)*((u+1)>>s)-1; int e=BitOperations.TrailingZeroCount((ulong)w); long v=w>>e; lc=Math.Log(2)*s+Math.Log((double)w)-s*Math.Log(3)-Math.Log((double)u); return v; }
  static long Pow3(int s){ long r=1; for(int i=0;i<s;i++) r*=3; return r; }
  static void Main(){
    int N=(int)((H-LO)/2+1); var len=new int[N]; var lprod=new double[N]; var wt=new double[N]; var exit=new long[N]; var state=new byte[N]; // 0 unvisited,1 in progress,2 done
    int cyc=0; var stack=new System.Collections.Generic.List<int>();
    for(int i0=0;i0<N;i0++){ if(state[i0]==2) continue; stack.Clear(); int i=i0;
      while(true){ if(state[i]==2) break; if(state[i]==1){ cyc++; break; } state[i]=1; stack.Add(i); long u=LO+2L*i; long v=Next(u,out double lc); if(v>=LO&&v<=H&&(v&1)==1){ i=(int)((v-LO)/2); } else { // exit
            len[stack[stack.Count-1]]=1; lprod[stack[stack.Count-1]]=lc; wt[stack[stack.Count-1]]=Wt(u); exit[stack[stack.Count-1]]=v; state[stack[stack.Count-1]]=2; stack.RemoveAt(stack.Count-1); break; } }
      for(int k=stack.Count-1;k>=0;k--){ int a=stack[k]; long u=LO+2L*a; long v=Next(u,out double lc); int b=(int)((v-LO)/2); len[a]=1+len[b]; lprod[a]=lc+lprod[b]; wt[a]=Wt(u)+wt[b]; exit[a]=exit[b]; state[a]=2; } }
    int maxLen=0; int arg=0; long low=0,high=0; double maxP=0,maxW=0; int argP=0,argW=0;
    for(int i=0;i<N;i++){ if(len[i]>maxLen){maxLen=len[i];arg=i;} if(exit[i]<=1023) low++; else high++; if(lprod[i]>maxP){maxP=lprod[i];argP=i;} if(wt[i]>maxW){maxW=wt[i];argW=i;} }
    Console.WriteLine($"states {N}, cycles inside B: {cyc}; max excursion length {maxLen} from {LO+2L*arg} (exit {exit[arg]}); first exits <=1023: {low}, >H: {high}");
    Console.WriteLine($"max product exp({maxP:F12}) = {Math.Exp(maxP):F13} from {LO+2L*argP} ({len[argP]} runs, exit {exit[argP]}); max shell weight {maxW} from {LO+2L*argW} ({len[argW]} runs, exit {exit[argW]}); 1085/128 = {1085.0/128}");
  }
  static double Wt(long u){ int b=63-BitOperations.LeadingZeroCount((ulong)u); return Math.Pow(2,-(b-10)); }
}
