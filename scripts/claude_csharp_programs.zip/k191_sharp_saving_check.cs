using System; using System.Numerics;
// K191 coefficient: Gamma_{s,e}=[1+beta-lambda]_+/(3 beta), beta=1-(2/3)^s, lambda=2^(s+e-1)/3^s. Check exactly: Gamma_{s,e}<2/3 for e>=2, Gamma_{s,1}=2/3, Gamma_{s,2}=2/3-2^s/(3(3^s-2^s)), and for s<=S, Gamma<=2/3-eps_S, eps_S=2^S/(3(3^S-2^S)).
class P { static (BigInteger n,BigInteger d) Gam(int s,int e){ BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); BigInteger beta_n=t3-t2; // beta=(3^s-2^s)/3^s
   BigInteger lam_n=BigInteger.Pow(2,s+e-1); // lambda=lam_n/3^s ; 1+beta-lambda = (3^s + (3^s-2^s) - lam_n)/3^s
   BigInteger num=t3+(t3-t2)-lam_n; if(num<0) num=0; // Gamma = num/3^s / (3 (3^s-2^s)/3^s) = num/(3(3^s-2^s))
   return (num, 3*(t3-t2)); }
 static void Main(){ bool allLt=true, e1=true, e2form=true; for(int s=1;s<=40;s++){ for(int e=2;e<=12;e++){ var g=Gam(s,e); if(!(3*g.n<2*g.d)) allLt=false; } var g1=Gam(s,1); if(3*g1.n!=2*g1.d) e1=false; var g2=Gam(s,2); BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); // 2/3 - eps = (2*3(3^s-2^s) - 3*... ) check: Gamma_{s,2}*3(3^s-2^s)... compare g2 == 2/3 - 2^s/(3(3^s-2^s))
     // 2/3 - 2^s/(3 D) with D=3^s-2^s  = (2D - 2^s)/(3D); g2 = num/(3D)
     BigInteger D=t3-t2; if(g2.n != 2*D - t2) e2form=false; }
  Console.WriteLine($"Gamma<2/3 for all s<=40, 2<=e<=12: {allLt}; Gamma_(s,1)=2/3: {e1}; Gamma_(s,2)=2/3-2^s/(3(3^s-2^s)): {e2form}");
  bool sup=true; foreach(int S in new[]{1,2,3,5,8,12,20,30}){ BigInteger tS3=BigInteger.Pow(3,S), tS2=BigInteger.Pow(2,S); BigInteger DS=tS3-tS2; // eps_S=2^S/(3 DS); need Gamma_{s,e} <= 2/3-eps_S for s<=S,e>=2
    for(int s=1;s<=S;s++) for(int e=2;e<=12;e++){ var g=Gam(s,e); // g.n/g.d <= (2 DS - 2^S)/(3 DS)  with g.d=3 D_s : g.n*3*DS <= (2 DS - 2^S)*3*D_s
      BigInteger Ds=BigInteger.Pow(3,s)-BigInteger.Pow(2,s); if(!(g.n*3*DS <= (2*DS - tS2)*g.d)) sup=false; } }
  Console.WriteLine($"Gamma_(s,e) <= 2/3 - eps_S for all s<=S (S in 1,2,3,5,8,12,20,30), e in 2..12: {sup}");
  // combined cap comparison at L=256
  double al=Math.Log(2)/Math.Log(3), gm=-(al*Math.Log(al,2)+(1-al)*Math.Log(1-al,2)); double endp=28/(1-gm)*Math.Pow(2,256*(gm-1)); Console.WriteLine($"endpoint cap 28/(1-gamma)2^(L(gamma-1)) at L=256: {endp:F5}; K196 V_(256,156)=0.056978 < 1/16=0.0625 < {endp:F5}: {0.056978<0.0625&&0.0625<endp}");
  double rho=1923.0/2000; Console.WriteLine($"2^(gamma-1) = {Math.Pow(2,gm-1):F6} > rho=1923/2000={rho}: {Math.Pow(2,gm-1)>rho}");
}}
