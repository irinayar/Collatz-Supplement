using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static long S(long n) => (n & 1) == 0 ? n / 2 : (3 * n + 1) / 2;
  static void Main(string[] args) {
    long N = long.Parse(args[0]);
    // per number of peaks k: trajectories, with window pair, total window pairs, min/max total window pairs, adjacent-window check
    var tr = new SortedDictionary<int, long>(); var withW = new Dictionary<int, long>(); var sumW = new Dictionary<int, long>(); var minW = new Dictionary<int, long>();
    long adjacentHits = 0, boundaryEq = 0; var ratioHist = new long[12];
    for (long n0 = 3; n0 <= N; n0++) {
      var xs = new List<long>(); long x = n0; while (true) { xs.Add(x); if (x == 1) break; x = S(x); }
      int m = xs.Count;
      // peak edges: (a -> p) with a odd and p even (p's next step even). valley edges: (b -> mv) with b even, mv odd.
      var peaks = new List<(long a, long p, int i)>(); var valleys = new List<(long b, long mv, int i)>();
      for (int i = 0; i + 2 < m; i++) {
        bool oi = (xs[i] & 1) == 1, oj = (xs[i + 1] & 1) == 1;
        if (oi && !oj) peaks.Add((xs[i], xs[i + 1], i));
        if (!oi && oj) valleys.Add((xs[i], xs[i + 1], i));
      }
      int k = peaks.Count; long W = 0;
      foreach (var pk in peaks) foreach (var vl in valleys) {
        // four distinct endpoints: indices pk.i, pk.i+1, vl.i, vl.i+1
        int[] e = { pk.i, pk.i + 1, vl.i, vl.i + 1 }; if (e.Distinct().Count() < 4) continue;
        double p = pk.p, mv = vl.mv;
        bool win = p / 2 < mv && mv < (2 * p - 1) / 3.0;
        if (win) { W++; if (Math.Abs(pk.i - vl.i) <= 2) adjacentHits++; double r = mv / p; int bin = (int)((r - 0.5) / (1.0 / 6 - 0.0) * 10); if (bin < 0) bin = 0; if (bin > 10) bin = 10; ratioHist[bin]++; }
        if (mv == (2 * p - 1) / 3.0) boundaryEq++;
      }
      tr.TryGetValue(k, out long t); tr[k] = t + 1;
      withW.TryGetValue(k, out long w); withW[k] = w + (W > 0 ? 1 : 0);
      sumW.TryGetValue(k, out long s); sumW[k] = s + W;
      if (!minW.ContainsKey(k) || W < minW[k]) minW[k] = W;
    }
    Console.WriteLine("peaks k | trajectories | with >=1 window pair | mean window pairs | min window pairs");
    foreach (var kv in tr.Where(kv => kv.Key <= 14)) Console.WriteLine($"{kv.Key,6} {kv.Value,13} {100.0 * withW[kv.Key] / kv.Value,12:F1}% {(double)sumW[kv.Key] / kv.Value,18:F2} {minW[kv.Key],10}");
    Console.WriteLine($"window pairs with |index difference|<=2: {adjacentHits}; pairs with valley exactly on the boundary m=(2p-1)/3 and distinct endpoints: {boundaryEq}");
    Console.WriteLine("histogram of m/p over window pairs, bins across (0.5, 0.667): " + string.Join(" ", ratioHist));
  }
}
