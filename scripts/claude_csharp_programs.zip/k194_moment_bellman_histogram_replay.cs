using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using System.Text.Json;
using System.Security.Cryptography;

// Independent C# replay of: K194 moment certificate and phase constants, Bellman C64,
// population constants, inverse-residue histogram (S0, C8).
class P {
 static F Q(BigInteger a,BigInteger b)=>new F(a,b);
 static BigInteger P2(int k)=>BigInteger.One<<k;
 static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static F ExpUpper(F x){ F t=1,s=1; for(int k=1;k<=20;k++){ t=t*x/k; s+=t; } return s+2*t*x/21; }
 static F ExpLower(F x,int terms=48){ F t=1,s=1; for(int k=1;k<=terms;k++){ t=t*x/k; s+=t; } return s; }
 static BigInteger Isqrt(BigInteger v){ if(v<2)return v; BigInteger x=BigInteger.One<<((int)(v.GetBitLength()/2)+1); while(true){ var y=(x+v/x)>>1; if(y>=x)return x; x=y; } }

 static void Main(string[] args){
  string tmp=args[0];
  var path=tmp+"/collatz_three_v4/phase/killed_phase_certificate.json";
  var raw=File.ReadAllBytes(path);
  Console.WriteLine("moment certificate sha256 "+Convert.ToHexString(SHA256.HashData(raw)).ToLower());
  var c=JsonDocument.Parse(raw).RootElement;
  BigInteger D=P2(40), S=BigInteger.Pow(10,10);
  var bounds=c.GetProperty("endpoints").EnumerateArray().Select(e=>(BigInteger)e.GetInt64()).ToArray();
  var values=c.GetProperty("values").EnumerateArray().Select(e=>Q(e.GetInt64(),S)).ToArray();
  int N=values.Length;
  Chk.A(c.GetProperty("denominator").GetInt64()==(long)D && c.GetProperty("value_denominator").GetInt64()==(long)S && bounds.Length==N+1 && bounds[0]==D/1024 && bounds[N]==D,"certificate header");
  for(int i=0;i<N;i++) Chk.A(bounds[i]<bounds[i+1] && values[i]>=1,"monotone endpoints/values");
  BigInteger sc=BigInteger.Pow(10,12);
  Func<F,F> tailUp=x=>(F)100-Q(50*Isqrt(x.n*sc*sc/x.D),sc);
  Func<F,F> tailLo=x=>(F)100-Q(50*(Isqrt(x.n*sc*sc/x.D)+1),sc);
  F env=1000;
  for(int i=0;i<N;i++) env=F.Min(env,tailLo(Q(bounds[i+1],D))-values[i]);
  Chk.A(env>24,"envelope margin >24");
  F minm=1000; long branches=0;
  for(int i=0;i<N;i++){
   BigInteger lo=bounds[i],hi=bounds[i+1];
   F mult=ExpUpper(Q(7*hi,15*D)); F w=0; int e=1;
   while(P2(e)*lo<=3*D){
    BigInteger v0=P2(e)*lo,v1=P2(e)*hi;
    BigInteger k0=(v0+2)/3; int l=0,h=bounds.Length;
    while(l<h){int m=(l+h)/2; if(bounds[m]<k0)l=m+1; else h=m;}
    int a=Math.Max(0,l-1);
    BigInteger k1=v1/3; l=0;h=bounds.Length;
    while(l<h){int m=(l+h)/2; if(bounds[m]<=k1)l=m+1; else h=m;}
    int b=Math.Min(N-1,l-1);
    F best=1;
    if(v0<=3*bounds[0]) best=F.Max(best,tailUp(Q(v0,3*D)));
    if(v1>=3*bounds[0]&&b>=a) for(int j=a;j<=b;j++) best=F.Max(best,values[j]);
    w+=best/(F)P2(e); branches++; e++;
   }
   w+=Q(1,P2(e-1));
   var margin=values[i]-mult*w;
   Chk.A(margin>0,"cell margin "+i);
   minm=F.Min(minm,margin);
  }
  F z0=Q(1000,1001); F J=0;
  for(int i=0;i<N;i++) if(Q(bounds[i],D)<=z0&&z0<=Q(bounds[i+1],D)) J=F.Max(J,values[i]);
  Chk.A(J<Q(33,4)&&J==Q(82262531839,10000000000),"initial moment bound J");
  Chk.A(minm>Q(1,10000000),"minimum margin > 1e-7");
  Console.WriteLine($"cells {N}; branches {branches}; J={J}; min margin {minm.ToDouble():E3}; envelope margin {env.ToDouble():F3}");
  Chk.A(Q(8,1)>Q(49,9)&&Q(2,1)<Q(9,4)&&ExpUpper(Q(7,15*1024))<2&&Q(50,3)>Q(2,32)*(Q(140,3)+Q(175,3)),"small multiplier tail");

  F total=0;
  for(int s=1;s<=8;s++){
   int ss=s;
   Func<int,F> chi=e=>F.Max(0,(F)2-F.Pow(Q(2,3),ss)-Q(P2(ss+e-1),P3(ss)));
   Chk.A(chi(2*s+3)==0,"excluded exponent");
   F m=0; for(int e=2;e<2*s+3;e++) m+=chi(e)/(F)P2(s+e-1);
   total+=m;
  }
  total+=Q(1,128);
  Chk.A(total<Q(8,25),"run mass < 8/25"); Console.WriteLine($"run mass total {total} ; equals 8563637/26873856: {total==Q(8563637,26873856)}"); Chk.A(total<=Q(8563637,26873856),"stated run mass bound");
  Chk.A(F.Max(0,(F)2-F.Pow(Q(2,3),2)-Q(8,9))/8==Q(1,12),"R mass 1/12");
  F theta=Q(1400,1001), eps=Q(1,2000);
  var den=ExpLower((F)5*theta+1-eps); Chk.A(den>2000,"exp lower >2000");
  var sharp=(J-1)/(theta*den);
  Chk.A(sharp<Q(7,4000)&&Q(8,25)*Q(7,4000)==Q(7,12500)&&Q(7,12500)<Q(6761,3904000)&&total*sharp<Q(557,1000000),"phase tail and 557e-6");
  F alpha=Q(4899,3904);
  BigInteger n0=P2(71)+1;
  F cstar=Q(620751769493359576,BigInteger.Parse("1180591620717411303425"));
  var first=cstar*((F)2-(F)4*alpha/3+alpha/(F)(3*n0));
  Chk.A(first>0&&Q(6761,3904000)-Q(557,1000000)-first>Q(1002,1000000),"second-late allowance");
  Func<F,F> lookup=z=>{ F best=0; for(int i=0;i<N;i++) if(Q(bounds[i],D)<=z&&z<=Q(bounds[i+1],D)) best=F.Max(best,values[i]); return best; };
  F Jbar=lookup(Q(32,47)), tau=Q(224,235), th2=Q(200,143);
  Chk.A(Jbar==Q(22718390719,2500000000)&&lookup(Q(1000,1001))==J,"lookups");
  Func<F,F,F> bnd=(t,Jv)=>{ var dy=ExpLower((F)10*t+1-eps,48); var dx=ExpLower((F)2*t,30); Chk.A(eps*dy>1&&dx>2,"bound prerequisites"); return (Jv-1)/(t*dy)*2/(dx-2); };
  var weak=bnd(tau,Jbar); var strong=bnd(th2,J);
  Chk.A(weak<Q(96,1000000)&&Q(2,3)*weak<Q(64,1000000)&&strong<Q(223,1000000000)&&Q(2,3)*strong<Q(149,1000000000),"late wedge bounds");

  F A=Q(1001,1000);
  var rows=new Dictionary<int,BigInteger>{{0,1}};
  F cost=0, prev=A, cap=A, lvl1=0;
  for(int g=0;g<=64;g++){
   F surv=0; foreach(var kv in rows) surv+=Q(kv.Value,P2(kv.Key));
   cap=cost+A*surv; Chk.A(cap<=prev,"monotone cap"); prev=cap;
   if(g==1)lvl1=cap;
   if(g==64)break;
   BigInteger cnt=0; foreach(var v in rows.Values)cnt+=v;
   cost+=Q(cnt,P3(g+1));
   var nx=new Dictionary<int,BigInteger>();
   foreach(var kv in rows){ int e=1; while(1000*P2(kv.Key+e)<=1001*P3(g+1)){ nx[kv.Key+e]=nx.GetValueOrDefault(kv.Key+e)+kv.Value; e++; } }
   rows=nx;
  }
  var C64=F.Of("80147532093873483207202441389202356216370417427993932413259609/116072302821007019464487645911519890966854661759054802751324160");
  Chk.A(lvl1==Q(5003,6000)&&cap==C64&&cap<Q(1381,2000),"C64 Bellman");
  Console.WriteLine($"C64 reproduced: {cap==C64} ({cap.ToDouble():F10})");
  F th=Q(200,143), Jm=Q(82262531839,10000000000);
  Chk.A(ExpLower(th*Q(1507,1000),30)>Jm&&ExpLower(th*Q(753371,500000),30)>Jm,"superseded Jensen");
  F t5=0;
  for(int b=5;b<=10;b++){ var de=ExpLower(th*b+1-eps,48); Chk.A(de>(F)1/eps,"tangent"); var cp=(Jm-1)/(th*de); if(b==5)t5=cp; }
  Chk.A(t5<Q(1746295,1000000000)&&Q(8563637,26873856)*t5<Q(557,1000000)&&Q(1,12)*t5<Q(7,48000),"phase-5 constants");
  F te=Q(750,1001), ze=Q(4501,1001); F poly=1, term=1;
  for(int j=1;j<25;j++){ term=term*ze/j; poly+=term; }
  var rc=(F)1/(te*poly); var ac=Q(5,3)/(te*poly);
  Chk.A(rc<Q(149,10000)&&ac<Q(249,10000)&&Q(249,10000)<Q(116073,3904000),"elementary charge bounds");

  var row=new Dictionary<int,BigInteger>{{2,1}};
  var pop=new List<(int j,int m,BigInteger v)>();
  for(int j=3;j<256;j++){
   var nx=new Dictionary<int,BigInteger>();
   foreach(var kv in row) for(int bit=0;bit<2;bit++){ int r=kv.Key+bit; if(P3(r)>P2(j)) nx[r]=nx.GetValueOrDefault(r)+kv.Value; }
   row=nx;
   if(j>=70){ var n=BigInteger.Max(P2(71)+1,3*P2(j-1)+3); int m=(int)n.GetBitLength(); BigInteger sum=0; foreach(var v in row.Values)sum+=v; pop.Add((j,m,sum)); }
  }
  BigInteger L71v=BigInteger.Parse("2483007077973438304");
  Chk.A(pop.First(t=>t.j==71).v==L71v,"L71");
  Chk.A(pop.OrderByDescending(t=>Q(t.v,P2(t.m))).First().j==71,"max L/2^m at 71");
  Chk.A(pop.OrderByDescending(t=>Q(t.m*t.v,P2(t.m))).First().j==71,"max mL/2^m at 71");
  F L=Q(L71v,P2(72));
  Chk.A((F)2*L*((F)(10*(72+15))+Q(8391,77))*Q(1,P2(15))<Q(33,1048576),"tail15");
  Chk.A((F)2*L*((F)(10*(72+16))+Q(8391,77))*Q(1,P2(16))<Q(13,819200),"tail16");
  Chk.A(L*(F)(20*(72+20)+316)*Q(1,P2(20))<Q(3,2621440),"tail20");
  F xi=cstar*((F)2-Q(4,3)*alpha+alpha/(F)(3*(P2(71)+1)));
  var eta=Q(116073,3904000)-Q(7,250)-Q(557,1000000)-Q(149,1000000000)-xi;
  Chk.A(eta>Q(1002,1000000),"eta");
  Console.WriteLine($"population rows {pop.Count}");

  BigInteger Ac=P3(24), Dc=P2(38), M=P2(305);
  BigInteger A8=BigInteger.Pow(Ac,8);
  BigInteger inv=BigInteger.ModPow(A8%M,(M>>1)-1,M);
  Chk.A((A8*inv)%M==1,"modular inverse");
  var words=new[]{"2233","2323","2332","3223","3232","3322"};
  var Bs=new List<BigInteger>();
  foreach(var w in words){
   var exps=new List<int>(); foreach(var ch in w) exps.AddRange(ch=='2'?new[]{1,2,1,2,2}:new[]{1,2,1,2,1,2,2});
   BigInteger U=0; int E=0; foreach(var e in exps){ U=3*U+P2(E); E+=e; }
   Chk.A(exps.Count==24&&E==38,"word shape"); Bs.Add(U);
  }
  var hist=new Dictionary<(long,int),long>(); long tot=0, even=0;
  var Dp=new BigInteger[8]; for(int j=0;j<8;j++)Dp[j]=BigInteger.Pow(Dc,j);
  BigInteger D8=BigInteger.Pow(Dc,8);
  void Walk(int j,BigInteger U){
   if(j==8){ var a=((D8-U)*inv)%M; if(a<0)a+=M; if(a.IsEven)even++; var k=((long)a.GetBitLength()-1,(int)(a%3)); hist[k]=hist.GetValueOrDefault(k)+1; tot++; return; }
   foreach(var B in Bs) Walk(j+1,Ac*U+Dp[j]*B);
  }
  Walk(0,0);
  F S0=0;
  foreach(var g in hist.GroupBy(k=>k.Key.Item1)){ long cnt=g.Where(x=>x.Key.Item2!=0).Sum(x=>x.Value); S0+=Q(cnt,P2((int)g.Key)); }
  var tri=Enumerable.Range(0,3).Select(r=>hist.Where(x=>x.Key.Item2==r).Sum(x=>x.Value)).ToArray();
  Chk.A(even==0,"all representatives odd");
  Chk.A(tot==1679616&&S0==Q(3330023,P2(302)),"S0");
  Chk.A(tri[0]==560289&&tri[1]==559957&&tri[2]==559370,"residue totals");
  var C8=Q(1814421282246,7551629537)*Q(96*P2(272),258*5000)*(S0+Q(BigInteger.Pow(6,8),P2(305))*Q(239501,30));
  Chk.A(C8==F.Of("7618091890243831687161/272394937772592332800000"),"C8");
  Chk.A(C8+Q(33,1048576)+Q(3,2621440)<Q(7,250),"combined allowance < 7/250");
  Console.WriteLine($"histogram codes {tot}; residue totals {string.Join(",",tri)}; S0*2^302={S0*(F)P2(302)}");
  Console.WriteLine($"checks passed {Chk.pass}, failed {Chk.fail}");
 }
}
