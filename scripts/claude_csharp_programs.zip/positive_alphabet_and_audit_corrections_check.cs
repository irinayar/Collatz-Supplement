using System; using System.Numerics; using System.Collections.Generic;
// Replay: positive-alphabet masses, two-source instance of the multiplicity construction, C-chain finite-range constants, residual arithmetic and the audit's local corrections (ChatGPT 22:08 / 22:10 / 22:32, 2026-11-23).
class P {
 struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator-(F x,F y)=>new F(x.n*y.d-y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static F operator/(F x,F y)=>new F(x.n*y.d,x.d*y.n);
  public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d; public override string ToString()=>n+"/"+d;
  public double D(){ int sh=Math.Max(0,(int)Math.Max(n.GetBitLength(),d.GetBitLength())-900); return (double)(n>>sh)/(double)(d>>sh);} }
 static F Fr(long a,long b)=>new F(a,b);
 static F Pw(F x,int k){ F r=Fr(1,1); for(int i=0;i<k;i++) r=r*x; return r; }
 static BigInteger ModInv(BigInteger a,BigInteger m){ BigInteger x0=1,x1=0,r0=((a%m)+m)%m,r1=m; while(r1!=0){ var q=r0/r1; var t=r0-q*r1; r0=r1; r1=t; var u=x0-q*x1; x0=x1; x1=u; } return ((x0%m)+m)%m; }
 static void Main(){
  F rp=Fr(0,1); var sl=new List<string>();
  for(int s=1;s<=5;s++){ var es=new List<int>(); for(int e=2;e<=40;e++) if(BigInteger.Pow(2,s)+BigInteger.Pow(2,s+e-1)<2*BigInteger.Pow(3,s)) es.Add(e); sl.Add("s="+s+": e in {"+string.Join(",",es)+"}"); foreach(var e in es) rp=rp+new F(1,BigInteger.One<<(s+e-1)); }
  Console.WriteLine(string.Join("; ",sl)); Console.WriteLine("slice mass s<=5: "+rp+" (77/256: "+(rp.n==77&&rp.d==256)+"); +1/32 = "+(rp+Fr(1,32))+" < 85/256: "+((rp+Fr(1,32))<Fr(85,256))+"; 85/256<1/3: "+(Fr(85,256)<Fr(1,3)));
  bool eLeS=true; for(int s=1;s<=60;s++) for(int e=2;e<=200;e++) if(BigInteger.Pow(2,s)+BigInteger.Pow(2,s+e-1)<2*BigInteger.Pow(3,s)) { if(!(s>=2&&e<=s)) eLeS=false; } Console.WriteLine("types with positive chi have s>=2 and e<=s (s<=60,e<=200): "+eLeS);
  F dp=Fr(0,1); for(int s=2;s<=80;s++) dp=dp+Fr(s-1,1)*new F(1,BigInteger.Pow(3,s)); Console.WriteLine("sum_(s=2..80)(s-1)3^-s = "+dp.D().ToString("F15")+" < 1/4: "+(dp<Fr(1,4)));
  var types=new (int s,int e)[]{(2,2),(12,8)};
  foreach(var (s,e) in types){ BigInteger l=BigInteger.Pow(2,s+e-1), t3=BigInteger.Pow(3,s); Console.WriteLine("type ("+s+","+e+"): lambda="+((double)l/(double)t3).ToString("F6")+" in (4/5,1): "+(l*5>t3*4 && l<t3)); }
  BigInteger M3=BigInteger.Pow(3,12); BigInteger y3=(M3-ModInv(BigInteger.Pow(2,7),M3))%M3;
  BigInteger y0=-1; for(int k=0;k<8;k++){ BigInteger c=y3+k*M3; if(c%8==1){y0=c;break;} }
  BigInteger y=y0+BigInteger.Parse("1000000")*M3*8; BigInteger n=(3*y+1)/4; BigInteger H=(4*n-2)/3;
  Console.WriteLine("y mod 8="+(y%8)+", n integer: "+((3*y+1)%4==0)+", H=y-1: "+(H==y-1)+", y mod 3^12 = -2^-7: "+(((y+ModInv(BigInteger.Pow(2,7),M3))%M3)==0));
  bool allok=true;
  foreach(var (s,e) in types){ BigInteger lamN=BigInteger.Pow(2,s+e-1), lamD=BigInteger.Pow(3,s), betaN=lamD-BigInteger.Pow(2,s);
    BigInteger num=lamN*y-betaN; if(num%lamD!=0){allok=false; Console.WriteLine("a not integer"); continue;} BigInteger a=num/lamD; if(a%2==0){allok=false; Console.WriteLine("a even");}
    BigInteger x=a; var states=new List<BigInteger>(); int steps=0; int odd=0; string word="";
    while(true){ states.Add(x); if(x%2==1){ x=(3*x+1)/2; odd++; word+="1"; } else { x/=2; word+="0"; } steps++; if(x>=n && x<=H) break; if(steps>2000||x<n){allok=false; break;} }
    bool aboveH=true; for(int ii=1;ii<states.Count;ii++){ var st=states[ii]; if(st%2==1 && !(st>H)) aboveH=false; }
    string expect=new string('1',s)+new string('0',e-1)+"10"; bool wordok=(word==expect);
    Console.WriteLine("type ("+s+","+e+"): source in band [n,H]: "+(a>=n&&a<=H)+"; n<a<y: "+(a>n&&a<y)+"; steps "+steps+", odd inputs "+odd+", all odd proper states >H: "+aboveH+", endpoint==n: "+(x==n)+", word==1^s 0^(e-1) 1 0: "+wordok+", v2(a+1)==s: "+(((a+1)%BigInteger.Pow(2,s)==0)&&((a+1)%BigInteger.Pow(2,s+1)!=0)));
    if(!(aboveH&&x==n&&wordok&&a>n&&a<y)) allok=false;
    Console.WriteLine("   lowering the source by 2^(s+e+2) lowers y by 8*3^s; y-8*3^s <= H: "+(y-8*BigInteger.Pow(3,s)<=H)); }
  Console.WriteLine("two-source instance all checks: "+allok);
  F cterm=Fr(4,1)/new F(3*y+1,1)-Fr(46,45)*new F(1,y); Console.WriteLine("c_term = 1/n-46/(45y) > 0: "+(cterm.n>0)+"; equals (42y-46)/(45y(3y+1)): "+(cterm.n*(45*y*(3*y+1))==(42*y-46)*cterm.d));
  F cstar=new F(BigInteger.Parse("620751769493359576"),BigInteger.Parse("1180591620717411303425"));
  F rr=Fr(256,243); F b122=Fr(2,1)*cstar/Fr(3*(1L<<32),1)*Fr(50*38+103,1)*Fr(198,13)*(Pw(rr,75)-Fr(1,1));
  F b542=Fr(2,1)*cstar/Fr(3*(1L<<40),1)*Fr(50*39+103,1)*Fr(198,13)*(Pw(rr,77)-Fr(1,1));
  Console.WriteLine("C-chain m+32: "+b122.D().ToString("E15")+" < 122e-9: "+(b122<Fr(122,1000000000))+" (claimed 1.2158874878376682e-7)");
  Console.WriteLine("C-chain m+40: "+b542.D().ToString("E15")+" < 542e-12: "+(b542<Fr(542,1000000000000))+" (claimed 5.413874756792912e-10)");
  F t2=Fr(11399,25200000)-Fr(8,10000000000)-Fr(122,1000000000); Console.WriteLine("11399/25200000-8/1e10-122/1e9 = "+t2+" ; =71224409/157500000000: "+(t2.n==71224409&&t2.d==157500000000)+"; 8/1e10+122/1e9 = "+(Fr(8,10000000000)+Fr(122,1000000000)));
  F wp=Fr(8143,18000000)-Fr(1,21000000); Console.WriteLine("8143/18e6-1/21e6 = "+wp+" (11399/25200000: "+(wp.n==11399&&wp.d==25200000)+")");
  bool dir=true; for(long nn=3;nn<20000000;nn+=2){ long Hh=(4*nn-2)/3; if(!(3*(Hh+1)>=4*nn-1 && 3*(Hh+1)<=4*nn+1)) dir=false; } Console.WriteLine("(4n-1)/3 <= H+1 <= (4n+1)/3 for odd n<2e7: "+dir);
  Console.WriteLine("log(10/9)="+Math.Log(10.0/9).ToString("F6")+" >0.1; (560/3)*2^(-20)="+(560.0/3*Math.Pow(2,-20)).ToString("E6")+" vs 35/196608="+(35.0/196608).ToString("E6"));
  BigInteger n0=(BigInteger.One<<71)+1; F cs=cstar;
  Func<BigInteger,F> Cd=(nv)=>{ BigInteger Hv=(4*nv-2)/3; F H1=new F(Hv+1,1); F lhs=Fr(2,1)*(Fr(5,1)*cs*H1+new F(nv,100000)); F dl=new F(1,nv+5)-H1/new F((Hv+2)*(Hv+5),1); return lhs*dl; };
  F df=Cd(n0+2)-Cd(n0); Console.WriteLine("C_direct(n0+2)-C_direct(n0) > 0: "+(df.n>0)+"  value ~ "+df.D().ToString("E6")+" (claimed 7.438674412340923e-25)");
 }}
