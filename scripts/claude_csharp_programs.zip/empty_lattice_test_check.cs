using System;
using System.Numerics;
// Check of the empty-lattice test of Codex K081: integers V in [L,U] with V = B (mod Q) exist iff NOT (L > U or f > g),
// f = L + ((B-L) mod Q), g = U - ((U-B) mod Q); equivalently for L <= U: exists iff (B-L) mod Q <= U-L. Compare with brute force and with the closed forms.
class P {
  static long Mod(long a, long q) { long r = a % q; return r < 0 ? r + q : r; }
  static void Main() {
    var rnd = new Random(2026); long cases = 0, bad = 0, empty = 0, nonempty = 0, eqEdge = 0;
    for (int it = 0; it < 3000000; it++) {
      long Q = rnd.Next(1, 200); long B = rnd.Next(-5000, 5000); long L = rnd.Next(-3000, 3000); long U = L + rnd.Next(-5, 300);
      bool brute = false; for (long v = L; v <= U && !brute; v++) if (Mod(v - B, Q) == 0) brute = true;
      long f = L + Mod(B - L, Q), g = U - Mod(U - B, Q);
      bool formula = !(L > U || f > g);
      bool formula2 = L <= U && Mod(B - L, Q) <= U - L;
      cases++; if (brute != formula || (L <= U && brute != formula2)) bad++;
      if (brute) nonempty++; else empty++; if (L <= U && Mod(B - L, Q) == U - L) eqEdge++;
    }
    Console.WriteLine($"empty-lattice test vs brute force: {cases} random cases (Q<200, |B|<5000), nonempty {nonempty}, empty {empty}, equality edge (grid point exactly at U, must NOT exclude) {eqEdge}; mismatches {bad}");
  }
}
