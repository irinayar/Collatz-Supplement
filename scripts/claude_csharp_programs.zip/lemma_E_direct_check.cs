using System;
using System.Collections.Generic;
// Direct test of Lemma E: for every origin Y >= 3*2^k-4 with (k,r) ending at x, every origin X' with (k,r+1) is < Y.
class P {
  static int EMAX; static List<long>[,] org; 
  static void Dfs(long z,int ev,int od){ org[ev,od].Add(z); if(ev<EMAX && z<(1L<<56)) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long checks=0,bad=0,vacuous=0;
    for(int k=1;k<=9;k++){ EMAX=k; long B=3L*(1L<<k)-4;
      for(long x=1;x<=3000;x++){ org=new List<long>[k+1,60]; for(int i=0;i<=k;i++) for(int j=0;j<60;j++) org[i,j]=new List<long>(); Dfs(x,0,0);
        for(int r=0;r<59;r++){ var cur=org[k,r]; var nxt=org[k,r+1]; if(nxt.Count==0) continue; long mx=0; foreach(var v in nxt) if(v>mx) mx=v;
          foreach(var Y in cur){ if(Y>=B){ checks++; if(!(mx<Y)) bad++; } else vacuous++; } } } }
    Console.WriteLine("Lemma E direct test (k=1..9, x<=3000): origin pairs checked " + checks + " (Y>=B), failures " + bad + "; origins below B skipped " + vacuous);
  }
}
