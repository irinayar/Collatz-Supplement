using System;
using System.Collections.Generic;
// Check Codex K136: (a) all odd u in I=[n,H], H=floor((4n-2)/3), odd n<=6001: four-transition first returns (v1,v2,v3>H, w in I): valuation tuples (1,1,1,3) u=79 mod 128, (1,1,2,2) u=71 mod 128, (1,2,1,2) u=123 mod 128 only; w formulas; for (1,2,1,2): z=(9u+5)/8 already in I (so it is a composite of two 2-transition returns, not a first return -> such u must NOT appear as first returns).
// (b) rho charges exact; (c) actual no-first-descent chains with gaps in {2,3,4}: G < 32/27 and G = Phi(n)/Phi(u_m) * prod rho (double precision).
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static double Phi(long u)=> 1.0+5.0/u;
  static void Main(){
    long cnt=0,bad=0,t3=0,t4=0,t5=0,compositeSeen=0; 
    for(long n=3;n<=6001;n+=2){ long H=(4*n-2)/3;
      for(long u=n;u<=H;u+=2){ int e1,e2,e3,e4; long v1=A(u,out e1), v2=A(v1,out e2), v3=A(v2,out e3), w=A(v3,out e4);
        if(v1>H&&v2>H&&v3>H&&w>=n&&w<=H){ cnt++; long B; 
          if(e1==1&&e2==1&&e3==1&&e4==3&&u%128==79){B=65;t3++;}
          else if(e1==1&&e2==1&&e3==2&&e4==2&&u%128==71){B=73;t4++;}
          else if(e1==1&&e2==2&&e3==1&&e4==2&&u%128==123){B=85;t5++; if(v2<=H) {} }
          else { bad++; continue; }
          if(64*w!=81*u+B) bad++; if(B==85) compositeSeen++; } } }
    Console.WriteLine($"(a) four-transition first returns {cnt}: (1,1,1,3) {t3}, (1,1,2,2) {t4}, (1,2,1,2) {t5}; other tuples/violations {bad}");
    long chains=0,badG=0,badId=0,gap4=0,gap3=0; double maxG=0;
    for(long n=3;n<=100001;n+=2){ long H=(4*n-2)/3; long x=n; var inputs=new List<long>(); var low=new List<int>(); int r=0;
      for(int step=0;step<4000;step++){ if((x&1)==1){ if(x<=H) low.Add(r); inputs.Add(x); r++; int e; x=A(x,out e); if(x<n) break; } else { x/=2; if(x<n) break; } }
      for(int k=1;k<low.Count;k++){ bool ok=true; for(int i=0;i<k;i++){ int gp=low[i+1]-low[i]; if(gp<2||gp>4) ok=false; } if(!ok) break;
        int idx=low[k]; double G=1; for(int i=0;i<idx;i++) G*=1.0+1.0/(3.0*inputs[i]); chains++; if(G>maxG) maxG=G; if(!(G<32.0/27)) badG++;
        // identity G = Phi(n)/Phi(u_m) * prod rho ; rho for each return computed from its own G-part
        double prod=Phi(n)/Phi(inputs[idx]); for(int i=0;i<k;i++){ long u=inputs[low[i]], w=inputs[low[i+1]]; double g=1; for(int j=low[i];j<low[i+1];j++) g*=1.0+1.0/(3.0*inputs[j]); prod*=g*Phi(w)/Phi(u)/ (1.0); }
        // prod now equals Phi(n)/Phi(u_m) * prod_i g_i Phi(w_i)/Phi(u_i); telescoping => should equal G
        if(Math.Abs(prod-G)/G>1e-9) badId++;
        for(int i=0;i<k;i++){ int gp=low[i+1]-low[i]; if(gp==4) gap4++; if(gp==3) gap3++; } }
    }
    Console.WriteLine($"(c) chains with gaps 2/3/4: {chains} (3-gap steps {gap3}, 4-gap steps {gap4}), max G {maxG:F6} vs 32/27={32.0/27:F6}, violations {badG}, identity mismatches {badId}");
    Console.WriteLine($"rho check (exact fractions): rho_65=1-20/(81(u+5)), rho_73=1-12/(81(u+5)), rho_85=1: derived as 1+(B-85)/(81(u+5)); (1,2,1,2) tuples counted among first returns above: {compositeSeen}");
  }
}
