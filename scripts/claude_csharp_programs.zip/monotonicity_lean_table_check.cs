using System;
// Memory-lean finite monotonicity certificate for fixed k: open-addressing table of (x, r) -> least origin m < 3*2^k-4 (exactly k even steps),
// terminality by successor closure (an origin at (x,r) below B implies ALL origins at (x,r+1) are below B, so (x,r+1) is feasible iff recorded).
class P {
  static long[] kx; static byte[] kr; static long[] val; static int mask; static long count;
  static int Slot(long x,int r){ ulong h=(ulong)x*0x9E3779B97F4A7C15UL ^ ((ulong)(r+1)*0xC2B2AE3D27D4EB4FUL); h^=h>>29; h*=0xBF58476D1CE4E5B9UL; h^=h>>32; return (int)(h&(ulong)mask); }
  static void Insert(long x,int r,long m){ int s=Slot(x,r); while(val[s]!=0){ if(kx[s]==x&&kr[s]==r) return; s=(s+1)&mask; } kx[s]=x; kr[s]=(byte)r; val[s]=m; count++; }
  static long Find(long x,int r){ int s=Slot(x,r); while(val[s]!=0){ if(kx[s]==x&&kr[s]==r) return val[s]; s=(s+1)&mask; } return 0; }
  static void Main(string[] args){
    int k=int.Parse(args[0]); int bits=int.Parse(args[1]); long B=3L*(1L<<k)-4; int size=1<<bits; mask=size-1; kx=new long[size]; kr=new byte[size]; val=new long[size];
    var sw=System.Diagnostics.Stopwatch.StartNew();
    for(long m=1;m<B;m++){ long y=m; int e=0,o=0; while(true){ if(e==k) Insert(y,o,m); if((y&1)==1){ y=(3*y+1)>>1; o++; } else { if(e==k) break; y>>=1; e++; } } }
    long pairs=count, ok=0, term=0, viol=0, violGe3=0; string list="";
    for(int s=0;s<size;s++){ if(val[s]==0) continue; long x=kx[s]; int r=kr[s]; long h=val[s]; long hp=Find(x,r+1);
      if(hp==0) term++; else if(hp<h) ok++; else { viol++; if(x>=3) violGe3++; if(viol<=8) list+=$"(x={x},r={r}:{h}->{hp}) "; } }
    Console.WriteLine($"k={k}: B={B}, exceptional pairs {pairs}, successor smaller {ok}, terminal {term}, violations {viol} (x>=3: {violGe3}) {list} [{sw.ElapsedMilliseconds/1000}s, table 2^{bits}]");
  }
}
