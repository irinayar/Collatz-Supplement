using System;
using System.Collections.Generic;
using System.Numerics;
// Corrected (B): evaluate every reset endpoint (arrival may be BELOW the source, e.g. 27->23) and stop at the first state below the source after evaluating it.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=65535, srcMax=87379; int pos=0, neg=0, maxResets=0, maxPath=0; var keys=new HashSet<string>();
    for(long u=3;u<=srcMax;u+=4){ long x=u; int g=0,resets=0; var states=new List<long>(); var ev=new List<int>(); BigInteger Bn=0; int Eacc=0;
      for(int step=0;step<10000;step++){ int e; long nx=A(x,out e); g++; ev.Add(e); Bn=3*Bn+(BigInteger.One<<Eacc); Eacc+=e; states.Add(nx); x=nx; if(e>=2) resets++; if(step+1>maxPath) maxPath=step+1;
        if(e>=2){ long w=x; long zz=long.MaxValue; for(int i=0;i<g-1;i++) if(states[i]<zz) zz=states[i];
          long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(Math.Min(u,w),NMAX); if(g>1) hi=Math.Min(hi,(3*zz+1)/4); if((hi&1)==0) hi--;
          if(lo<=hi){ BigInteger cn=Bn+5*((BigInteger.One<<Eacc)-BigInteger.Pow(3,g)); if(cn>0){ pos++; if(resets>maxResets) maxResets=resets; keys.Add(string.Join(",",ev)); } else neg++; } }
        if(x<u) break; } }
    Console.WriteLine($"(B corrected) positive intervals {pos} (claimed 6757), non-positive {neg}, max resets among positive records {maxResets} (claimed 32), max path {maxPath} (claimed 85), distinct positive profiles {keys.Count} (claimed 1767)");
  }
}
