using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static double Wrap(double a) { while (a > Math.PI) a -= 2 * Math.PI; while (a <= -Math.PI) a += 2 * Math.PI; return a; }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    double[] bMin = { 99, 99 }, bMax = { -99, -99 }; long[] bigUp = new long[2]; long[] fN = new long[2], fBad = new long[2], cBad = new long[2], fLess = new long[2]; long[,] catN = new long[2, 4], catBad = new long[2, 4], catPos = new long[2, 4]; long words = 0, ge1 = 0, idBad = 0, supBad = 0; double[,] relMin = new double[2, 4], relMax = new double[2, 4]; long[,] relBad = new long[2, 4]; for (int a = 0; a < 2; a++) for (int b = 0; b < 4; b++) { relMin[a, b] = 99; relMax[a, b] = -99; }
    double[] sup = { -99, -99 }, inf = { 99, 99 }, supL = { -99, -99 }, infL = { 99, 99 };
    double[] minRW = { 99, 99 }, maxRW = { -99, -99 }, minRK = { 99, 99 }, maxRK = { -99, -99 };
    var rwHist = new SortedDictionary<int, long>[] { new(), new() }; // rho - w
    var infByK = new SortedDictionary<int, double>[] { new(), new() }; var supByK = new SortedDictionary<int, double>[] { new(), new() };
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2;
        bool g1 = x.All(v => v >= 1.0 - 1e-12); int g = g1 ? 1 : 0;
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        var d = new double[L]; bool deg = false;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; d[i] = a; }
        if (deg) continue; words++; if (g1) ge1++;
        int k = 0; for (int i = 0; i < L; i++) { int j = (i + 1) % L; if (!e[i] && e[j]) k++; }
        // direction angle of chord j and turning at vertex j+1
        var phi = new double[L]; for (int i = 0; i < L; i++) phi[i] = Math.Atan2(py[i], px[i] - m);
        var th = new double[L]; for (int i = 0; i < L; i++) th[i] = phi[i] + d[i] / 2 + (d[i] > 0 ? Math.PI / 2 : -Math.PI / 2);
        var tau = new double[L]; // tau[j] = turning at vertex j = between chord j-1 and chord j
        for (int j = 0; j < L; j++) tau[j] = Wrap(th[j] - th[(j + L - 1) % L]);
        double wt = d.Sum() / (2 * Math.PI), wr = Math.Round(wt); double rho = tau.Sum() / (2 * Math.PI), rr = Math.Round(rho);
        int dd = (int)(rr - wr); rwHist[g][dd] = rwHist[g].GetValueOrDefault(dd) + 1;
        { int minR = 99, minDd = 99; for (int i0 = 0; i0 < L; i0++) { if (e[i0] && !e[(i0 + L - 1) % L]) { int rl = 0, j0 = i0; while (e[j0 % L]) { rl++; j0++; } int dl = 0; while (!e[j0 % L]) { dl++; j0++; } minR = Math.Min(minR, rl); minDd = Math.Min(minDd, dl); } }
          int n1 = 0, nd1a = 0; for (int i0 = 0; i0 < L; i0++) { if (e[i0] && !e[(i0 + L - 1) % L]) { int rl = 0, j0 = i0; while (e[j0 % L]) { rl++; j0++; } if (rl == 1) n1++; } } int ccwTurns = 0; for (int j = 0; j < L; j++) if (tau[j] > 0) ccwTurns++; int gI = g1 ? 1 : 0; fN[gI]++; if ((int)rr + k != n1) fBad[gI]++; if (ccwTurns != n1) cBad[gI]++; if ((int)rr + k < n1) fLess[gI]++; int cat = (minR >= 2 ? 1 : 0) + (minDd >= 2 ? 2 : 0); catN[g1 ? 1 : 0, cat]++; if ((int)rr != -k) catBad[g1 ? 1 : 0, cat]++; if ((int)rr > -k) catPos[g1 ? 1 : 0, cat]++; }
        minRW[g] = Math.Min(minRW[g], rr - wr); maxRW[g] = Math.Max(maxRW[g], rr - wr); minRK[g] = Math.Min(minRK[g], rr + k); maxRK[g] = Math.Max(maxRK[g], rr + k);
        { // lifted direction check
          int s0 = -1; for (int i = 0; i < L; i++) { int j0 = (i + L - 1) % L; if (!e[j0] && e[i]) { s0 = i; break; } }
          double lam = th[s0]; lam = Wrap(lam); double prevTh = th[s0]; int val = 0; int ty0 = 0;
          for (int q = 0; q < 3 * L; q++) { int j = (s0 + q) % L; int jn = (j + 1) % L; if (q > 0) { lam += Wrap(th[j] - th[(j + L - 1) % L]); }
            // type of chord j: 0 asc (odd->odd), 1 peak (odd->even), 2 desc (even->even), 3 valley (even->odd)
            int ty = e[j] ? (e[jn] ? 0 : 1) : (e[jn] ? 3 : 2); double nom = -ty * Math.PI / 2; double rel = lam + 2 * Math.PI * val - nom; int gg = g1 ? 1 : 0;
            relMin[gg, ty] = Math.Min(relMin[gg, ty], rel); relMax[gg, ty] = Math.Max(relMax[gg, ty], rel); if (Math.Abs(rel) >= Math.PI / 2 + 1e-9) relBad[gg, ty]++;
            if (ty == 3) val++; }
        }
        double wsup = -99, winf = 99, wsupL = -99, winfL = 99; int[] tyv = new int[L]; for (int i0 = 0; i0 < L; i0++) { int jn0 = (i0 + 1) % L; tyv[i0] = e[i0] ? (e[jn0] ? 0 : 1) : (e[jn0] ? 3 : 2); }
        for (int st = 0; st < L; st++) {
          double cur = 0, curPhi = 0; int Dd0 = 0; // Theta_s(t) = sum of tau at vertices st+1..st+t-1
          for (int t = 1; t <= 3 * L; t++) {
            if (t >= 2) cur += tau[(st + t - 1) % L];
            curPhi += d[(st + t - 1) % L];
            double u = cur / (2 * Math.PI); if (t >= 2 && tyv[(st + t - 2) % L] == 3 && tyv[(st + t - 1) % L] == 0) Dd0++; { double bandv = u + Dd0; int gq = g1 ? 1 : 0; bMin[gq] = Math.Min(bMin[gq], bandv); bMax[gq] = Math.Max(bMax[gq], bandv); if (t >= 2 && u > 0.75) bigUp[gq]++; }
            wsup = Math.Max(wsup, u); winf = Math.Min(winf, u); if (t <= L) { wsupL = Math.Max(wsupL, u); winfL = Math.Min(winfL, u); }
            // identity Theta = Phi - (d_s + d_last)/2 + pi(eps_s - eps_last) - 2 pi K  with K integer
            if (t >= 2) { double ds = d[st], dl = d[(st + t - 1) % L]; double es = ds < 0 ? 1 : 0, el = dl < 0 ? 1 : 0; double Kr = (curPhi - (ds + dl) / 2 + Math.PI * (es - el) - cur) / (2 * Math.PI); if (Math.Abs(Kr - Math.Round(Kr)) > 1e-6) idBad++; }
          }
        }
        sup[g] = Math.Max(sup[g], wsup); inf[g] = Math.Min(inf[g], winf); supL[g] = Math.Max(supL[g], wsupL); infL[g] = Math.Min(infL[g], winfL);
        supByK[g][k] = Math.Max(supByK[g].GetValueOrDefault(k, -99), wsupL); infByK[g][k] = Math.Min(infByK[g].GetValueOrDefault(k, 99), winfL);
      }
    }
    Console.WriteLine($"words {words} (values>=1: {ge1}); identity Theta = Phi - (d_s+d_l)/2 + pi(eps_s-eps_l) - 2 pi K, K integer: violations {idBad}");
    for (int g = 0; g < 2; g++) for (int ct = 0; ct < 4; ct++) Console.WriteLine($"CAT [{(g == 1 ? "values>=1" : "all")}] r>=2:{ct % 2 == 1} d>=2:{ct / 2 == 1}: words {catN[g, ct]}, rho != -k: {catBad[g, ct]}, rho > -k: {catPos[g, ct]}");
    for (int g = 0; g < 2; g++) Console.WriteLine($"RHO [{(g == 1 ? "values>=1" : "all")}]: words {fN[g]}, rho + k != #(r=1 excursions): {fBad[g]}; #ccw turns != #(r=1): {cBad[g]}; rho+k < #(r=1): {fLess[g]}");
    for (int g = 0; g < 2; g++) Console.WriteLine($"BAND [{(g == 1 ? "values>=1" : "all")}]: Theta/2pi + D in [{bMin[g]:F4}, {bMax[g]:F4}]  (D = number of V->A vertices in window); windows with Theta > 1.5 pi: {bigUp[g]}");
    string[] tn = { "asc", "peak", "desc", "valley" }; for (int g = 0; g < 2; g++) for (int t2 = 0; t2 < 4; t2++) Console.WriteLine($"lift check [{(g == 1 ? "values>=1" : "all")}] {tn[t2]}: (Lambda + 2 pi val - nominal) in [{relMin[g, t2] / Math.PI:F4} pi, {relMax[g, t2] / Math.PI:F4} pi], outside +-pi/2: {relBad[g, t2]}");
    for (int g = 0; g < 2; g++) {
      Console.WriteLine($"[{(g == 1 ? "values>=1" : "all")}] Theta/2pi over t<=3L: sup {sup[g] / 1:F4}, inf {inf[g]:F4}; t<=L: sup {supL[g]:F4}, inf {infL[g]:F4}");
      Console.WriteLine($"   rho - w in [{minRW[g]}, {maxRW[g]}] ; rho + k in [{minRK[g]}, {maxRK[g]}] ; hist of rho-w: " + string.Join(", ", rwHist[g].Select(p => p.Key + ":" + p.Value)));
      Console.WriteLine("   by k (t<=L): sup/inf Theta/2pi: " + string.Join("; ", supByK[g].Where(p => p.Key <= 9).Select(p => $"k{p.Key} [{infByK[g][p.Key]:F2},{p.Value:F2}]")));
    }
  }
}
