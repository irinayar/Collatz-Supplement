using System; using System.Collections.Generic; using System.IO; using System.Linq; using System.Numerics;
class P {
 const int A=41; static readonly UInt128 M=(UInt128)1<<41;
 static UInt128[] p3=new UInt128[60];
 // forward from r: returns (x after 41 steps, odd count) and exclusion flag through j<=jmax
 static bool Excluded(ulong r,int jmax){ UInt128 x=r; int a=0; for(int j=1;j<=jmax;j++){ if((x&1)==1){a++; x=(3*x+1)/2;} else x/=2;
    UInt128 pw=(UInt128)1<<j; if(p3[a]<pw) return true;
    if(x%3==2){ UInt128 m=(2*x-1)/3; if(m<r && 2*p3[a]<3*pw) return true; } } return false; }
 static void Fwd(ulong r,out UInt128 x,out int a){ x=r;a=0; for(int j=1;j<=41;j++){ if((x&1)==1){a++; x=(3*x+1)/2;} else x/=2; } }
 // DFS: find minimum e (0..6) with a word satisfying (C); returns min e or 7 if none. Also reports number of nodes.
 static int best; static ulong R; static int AA;
 static void Dfs(UInt128 z,int b,int e){
   // check (C) at this node
   if(e<best){ UInt128 Q=((UInt128)1<<(b+e))*p3[AA-b]; if(z<R && Q<M && z>0) best=e; }
   if(e<6 && e+1<best){ Dfs(2*z,b,e+1); }
   if(b<AA && z%3==2){ Dfs((2*z-1)/3,b+1,e); }
 }
 static int MinBudget(ulong r,UInt128 x,int a){ best=7; R=r; AA=a; Dfs(x,0,0); return best; }
 static void Main(string[] args){
  p3[0]=1; for(int i=1;i<60;i++)p3[i]=p3[i-1]*3;
  string dir=args[0];
  // R27
  var R27=new HashSet<int>(); for(int i=0;i<16384;i++){ ulong r=103UL+8192UL*(ulong)i; if(!Excluded(r,27)) R27.Add(i&16383); }
  Console.WriteLine("R27 size "+R27.Count+" (claimed 1982)");
  // classification scan
  var cls=File.ReadAllBytes(Path.Combine(dir,"classification.bin")); var cnt=new long[16];
  for(long i=0;i<(1L<<28);i++){ int lb=(i&1)==0? cls[i>>1]&15 : cls[i>>1]>>4; cnt[lb]++; }
  Console.WriteLine("labels: "+string.Join(" ",Enumerable.Range(0,9).Select(l=>l+":"+cnt[l]))+"; members(0..7)="+Enumerable.Range(0,8).Sum(l=>cnt[l]));
  Func<long,int> lab=i=>(i&1)==0? cls[i>>1]&15 : cls[i>>1]>>4;
  // membership sample: every 997th i, plus min-budget cross-check for labels 0..7
  long chk=0,memberBad=0,budgetBad=0,label7=0;
  for(long i=3;i<(1L<<28);i+=997){ ulong r=103UL+8192UL*(ulong)i; bool mem=R27.Contains((int)(i&16383)) && !Excluded(r,41); int l=lab(i); chk++;
     if(mem!=(l<=7)) memberBad++;
     if(mem){ UInt128 x; int a; Fwd(r,out x,out a); int mb=MinBudget(r,x,a); int expect=l==7?7:l; if(mb!=expect) budgetBad++; if(l==7) label7++; } }
  Console.WriteLine($"sampled {chk} masks: membership mismatches {memberBad}; min-budget mismatches {budgetBad}; label-7 sampled {label7}");
  // certificates: verify every row
  long rows=0,bad=0,badWord=0,bad6=0; var byE=new long[8]; UInt128 minGap=UInt128.MaxValue; ulong minR=ulong.MaxValue; var comp=new Dictionary<string,long>();
  using(var sr=new StreamReader(Path.Combine(dir,"certificates.csv"))){ sr.ReadLine(); string ln;
   while((ln=sr.ReadLine())!=null){ var f=ln.Split(','); ulong r=ulong.Parse(f[0]); ulong xr=ulong.Parse(f[1]); int a=int.Parse(f[2]),e=int.Parse(f[3]),b=int.Parse(f[4]); ulong wb=ulong.Parse(f[5]); ulong org=ulong.Parse(f[6]); rows++;
     UInt128 x; int aa; Fwd(r,out x,out aa); if(x!=xr||aa!=a) {bad++; continue;}
     // decode word: inverse steps chronological, low bit first, 1=O,0=E
     UInt128 z=x; int bo=0,ee=0; bool ok=true; int len=b+e; var blocks=new List<int>(); int run=0;
     for(int k=0;k<len;k++){ if(((wb>>k)&1)==1){ if(z%3!=2){ok=false;break;} z=(2*z-1)/3; bo++; if(run>0){blocks.Add(run);run=0;} } else { z=2*z; ee++; run++; } }
     if(run>0) blocks.Add(run);
     if(!ok||bo!=b||ee!=e||z!=org||!(z>0&&z<r)||b>a) {badWord++; continue;}
     UInt128 Q=((UInt128)1<<(b+e))*p3[a-b]; if(!(Q<M)) {badWord++; continue;}
     byE[e]++; int mb=MinBudget(r,x,a); if(mb!=e) bad6++;
     if(e==6){ UInt128 g=M-Q; if(g<minGap) minGap=g; if((ulong)(r-org)<minR) minR=r-org; string key=string.Join(",",blocks); comp[key]=comp.GetValueOrDefault(key)+1; }
   } }
  Console.WriteLine($"certificate rows {rows}; mismatching forward data {bad}; invalid recorded word/conditions {badWord}; min-budget mismatches (DFS) {bad6}");
  Console.WriteLine("rows by e: "+string.Join(" ",Enumerable.Range(0,7).Select(k=>k+":"+byE[k])));
  Console.WriteLine($"six-even: min(r-m)={minR}, min(2^41-Q)={minGap}");
  // compositions of the evens in the WORD blocks (blocks between odd runs)
  foreach(var kv in comp.OrderBy(k=>k.Key)) Console.Write(kv.Key+"="+kv.Value+"; "); Console.WriteLine();
  // depth-100 projector
  var Dm=new BigInteger[130,101]; // D[j][a]
  BigInteger[][] D=new BigInteger[101][]; for(int j=0;j<=100;j++) D[j]=new BigInteger[101];
  for(int aa2=0;aa2<=100;aa2++) D[100][aa2]=1;
  for(int j=99;j>=41;j--) for(int aa2=0;aa2<=100;aa2++){ BigInteger s=0; for(int bb=0;bb<=1;bb++){ if(aa2+bb>100) continue; if(BigInteger.Pow(3,aa2+bb)>BigInteger.Pow(2,j+1)) s+=D[j+1][aa2+bb]; } D[j][aa2]=s; }
  long[] masks={22765,73963,53627,106775,113883}; BigInteger tot=0; for(int k=0;k<5;k++){ tot+=masks[k]*D[41][26+k]; Console.WriteLine($"a={26+k}: D41={D[41][26+k]}"); }
  Console.WriteLine("projector numerator "+tot+" (claimed 12083228764224801145504)");
 }}
