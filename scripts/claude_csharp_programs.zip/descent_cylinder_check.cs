using System;
using System.Numerics;
// Descent cylinder of an integer n: sigma = first time S^sigma(n) < n; the class n' = n mod 2^sigma shares the first sigma parity bits, S^sigma(n') = (3^a n' + c)/2^sigma.
static class P {
  static void Main() {
    foreach (var s in new[] { "4064460795", "18839651253368551", "27", "871", "8088063" }) {
      BigInteger n = BigInteger.Parse(s), x = n; int sigma = 0, a = 0; BigInteger c = 0; BigInteger pow2 = 1;
      while (true) { bool odd = !x.IsEven; if (odd) { x = (3 * x + 1) / 2; c = 3 * c + pow2; a++; } else x /= 2; pow2 *= 2; sigma++; if (x < n) break; }
      BigInteger d = BigInteger.Pow(2, sigma) - BigInteger.Pow(3, a); BigInteger nmin = d > 0 ? c / d + 1 : -1;
      Console.WriteLine($"n = {s}: descent at step {sigma}, odd steps a = {a}, 3^a < 2^sigma: {d > 0}, n_min of the descent cylinder n' = n mod 2^{sigma} (all n' >= n_min in the class descend within {sigma} steps): {nmin}; class density 2^-{sigma}; check S^sigma(n) = (3^a n + c)/2^sigma = {(BigInteger.Pow(3, a) * n + c) / BigInteger.Pow(2, sigma)} (direct: {x})");
    }
  }
}
