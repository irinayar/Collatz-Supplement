using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent replay of the finite certificates of CollatzTwo (staged finite_bands / reset_refinements): band certificates, B_b constants, W at cutoff 999.
class P {
 struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d; public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public static bool operator>=(F x,F y)=>x.n*y.d>=y.n*x.d; public static bool operator<=(F x,F y)=>x.n*y.d<=y.n*x.d; public override string ToString()=>n+"/"+d; }
 static int V2(BigInteger x){ int c=0; while(x%2==0){x>>=1;c++;} return c; }
 static int V2l(long x){ int c=0; while((x&1)==0){x>>=1;c++;} return c; }
 // run map on odd u>1 : returns F(u), s, s+e
 static (BigInteger f,int s,int se) Run(BigInteger u){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*((u+1)>>s)-1; int e=V2(w); return (w>>e,s,s+e); }
 static void Main(){
  // ---- 1. band [1025,1000001]
  long lo=1025, hi=1000001; int exitsLow=0,exitsHigh=0,maxLen=0; long maxLenAt=0; BigInteger bestN=1,bestD=1; long bestAt=0; BigInteger bestWn=0; long bestWat=0; int cnt=0;
  for(long u0=lo;u0<=hi;u0+=2){ cnt++; BigInteger u=u0; int d=0; BigInteger R=0,T=0; BigInteger wsum512=0; // shell weights *512: 2^-(floor(log2 u)-10) *512 = 2^(19-floor(log2 u))... use exact fraction via shift
    BigInteger cur=u; var starts=new List<BigInteger>(); BigInteger z=0; while(true){ if(cur<lo||cur>hi){ z=cur; break; } starts.Add(cur); var (f,s,se)=Run(cur); R+=s; T+=se; d++; cur=f; }
    if(z<lo) exitsLow++; else exitsHigh++; if(d>maxLen){maxLen=d;maxLenAt=u0;}
    // correction 2^T z/(3^R u0)
    BigInteger cn=BigInteger.Pow(2,(int)T)*z, cd=BigInteger.Pow(3,(int)R)*u0; if(cn*bestD>bestN*cd){bestN=cn;bestD=cd;bestAt=u0;}
    // shell sum: sum over starts 2^-(floor(log2 u)-10): times 2^30 to keep integer? floor(log2 u)-10 in 0..9 for u<=1000001 (log2=19) so times 512
    BigInteger ws=0; foreach(var s0 in starts){ int fl=(int)(s0.GetBitLength()-1); ws+=BigInteger.Pow(2,9-(fl-10)); } if(ws>bestWn){bestWn=ws;bestWat=u0;} }
  var g0=BigInteger.GreatestCommonDivisor(bestN,bestD);
  Console.WriteLine("band1: starts "+cnt+" (claimed 499489), exit below "+exitsLow+" above "+exitsHigh+" (claimed 395333 / 104156); max length "+maxLen+" at "+maxLenAt+" (claimed 44 at 926649)");
  Console.WriteLine("  largest correction "+(bestN/g0)+"/"+(bestD/g0)+" at "+bestAt+"; claimed 1197634424202209201486330161312590462976/1194027704281321183001939677510824745641 at 53001: "+((bestN/g0).ToString()=="1197634424202209201486330161312590462976"&&(bestD/g0).ToString()=="1194027704281321183001939677510824745641"));
  Console.WriteLine("  max shell sum*512 = "+bestWn+" at "+bestWat+" -> "+bestWn+"/512 = "+(new F(bestWn,512))+" (claimed 1085/128 = 4340/512 at 251265)");
  // ---- 2. second band [1025,4095]: follow until first run start <=1023
  { int reach=0,maxRuns=0; long maxRunsAt=0; BigInteger maxStart=0; int maxRe=0,none=0; BigInteger bn=1,bd=1; long bat=0;
    for(long u0=1025;u0<=4095;u0+=2){ BigInteger cur=u0; int d=0; BigInteger R=0,T=0; int reentries=0; bool above=false; while(cur>1023){ if(cur>4095) {above=true;} else if(above){reentries++; above=false;} var (f,s,se)=Run(cur); if(cur>maxStart) maxStart=cur; R+=s; T+=se; d++; cur=f; if(d>1000) break; }
      if(cur<=1023){ reach++; if(d>maxRuns){maxRuns=d;maxRunsAt=u0;} if(reentries>maxRe) maxRe=reentries; if(reentries==0) none++; BigInteger cn=BigInteger.Pow(2,(int)T)*cur, cd=BigInteger.Pow(3,(int)R)*u0; if(cn*bd>bn*cd){bn=cn;bd=cd;bat=u0;} } }
    var g=BigInteger.GreatestCommonDivisor(bn,bd);
    Console.WriteLine("band2: starts reaching <=1023: "+reach+"/1536, max runs "+maxRuns+" at "+maxRunsAt+" (claimed 22 at 2553); max run start visited "+maxStart+" (claimed 189175); max re-entries "+maxRe+" (claimed 3), starts with none "+none+" (claimed 1276)");
    Console.WriteLine("  P_B = "+(bn/g)+"/"+(bd/g)+" at "+bat+" ; claimed 68077635217048805400641536/67881243058418505893720211 at 2553: "+((bn/g).ToString()=="68077635217048805400641536"&&(bd/g).ToString()=="67881243058418505893720211")); }
  // ---- 3. B_b constants
  { var claim=new string[]{"1","3076/3075","12328/12321","1216/1215","113600/113481","340864/340443","1116160/1114641"}; Console.Write("B_b: ");
    for(int b=1;b<=6;b++){ BigInteger bn=1,bd=1; long bat=0; for(long u0=1025;u0<=199999;u0+=2){ BigInteger x=u0; BigInteger pn=1,pd=1; bool ok=true; int odds=0; while(odds<b){ if(x<=1023){ok=false;break;} if(x%2==1){ pn=pn*(3*x+1); pd=pd*(3*x); odds++; x=(3*x+1)/2; } else x/=2; } if(!ok) continue; if(pn*bd>bn*pd){bn=pn;bd=pd;bat=u0;} }
      var g=BigInteger.GreatestCommonDivisor(bn,bd); Console.Write("b="+b+": "+(bn/g)+"/"+(bd/g)+" at "+bat+" (claim "+claim[b]+": "+(((bn/g)+"/"+(bd/g))==claim[b])+"); "); } Console.WriteLine(); }
  // ---- 4. W at cutoff 999
  { BigInteger qn=3004, qd=3003; BigInteger bestn=1,bestd=1; long bat=0; int bs=0; int nstarts=0;
    for(long u0=3;u0<=999;u0+=2){ nstarts++; BigInteger x=u0; BigInteger gn=1,gd=1; int s=0; // prefix includes empty: ratio G/q^s
      while(true){ // evaluate current prefix ratio = gn/gd / (qn/qd)^s = gn*qd^s/(gd*qn^s)
        BigInteger rn=gn*BigInteger.Pow(qd,s), rd=gd*BigInteger.Pow(qn,s); if(rn*bestd>bestn*rd){bestn=rn;bestd=rd;bat=u0;bs=s;}
        if(x==2) break; if(x%2==1){ gn*=(3*x+1); gd*=(3*x); s++; x=(3*x+1)/2; } else x/=2; } }
    var g=BigInteger.GreatestCommonDivisor(bestn,bestd); BigInteger wn=bestn/g, wd=bestd/g; Console.WriteLine("W: starts "+nstarts+" (claimed 499), W = "+wn+"/"+wd+" at start "+bat+" with s="+bs+" (claimed 2012030040030012002/1614663884607228009: "+((wn.ToString()=="2012030040030012002")&&(wd.ToString()=="1614663884607228009"))+")");
    // W q^556 < 3/2 <= W q^557
    BigInteger l1n=wn*BigInteger.Pow(qn,556), l1d=wd*BigInteger.Pow(qd,556); BigInteger l2n=wn*BigInteger.Pow(qn,557), l2d=wd*BigInteger.Pow(qd,557);
    Console.WriteLine("W q^556 < 3/2: "+(l1n*2<3*l1d)+"; 3/2 <= W q^557: "+(l2n*2>=3*l2d)); }
 }}
