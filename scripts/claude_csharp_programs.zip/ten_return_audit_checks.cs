using System;
using System.Collections.Generic;
using System.Numerics;
// Audit of Ten_Return_Proof_Audit.md: (a) E=17: 3003 tuples, min margin 39255 r - B + 65536 = 7,307,264 (all positive); (b) E=16: 1287 tuples; retained (witness) set = tuples with 3^j>2^{E_j} for j=1..9 (476), B range, residues min 359 / max 130943,
// min(6487 r - B)=2,228,224, reset table (1,22,116,200,118,19) and coefficient sums; (c) constant A of the 8n theorem and final margins.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Tuples(int len,int E,List<int[]> outL){ var cur=new int[len]; void Rec(int p,int s){ if(p==len){ if(s==E&&cur[len-1]>=2) outL.Add((int[])cur.Clone()); return; } for(int v=1;v<=E-s;v++){ if(p==0&&v!=1) continue; cur[p]=v; Rec(p+1,s+v); } } Rec(0,0); }
  static long Residue(int[] ev,long mod){ for(long r=1;r<mod;r+=2){ long x=r; bool ok=true; for(int i=0;i<ev.Length;i++){ int e; x=A(x,out e); if(e!=ev[i]){ok=false;break;} } if(ok) return r; } return -1; }
  static BigInteger Bof(int[] ev,int upto){ BigInteger B=0; int E=0; for(int i=0;i<upto;i++){ B=3*B+(BigInteger.One<<E); E+=ev[i]; } return B; }
  static void Main(){
    var t17=new List<int[]>(); Tuples(10,17,t17); long minM=long.MaxValue; int neg=0; foreach(var ev in t17){ long r=Residue(ev,262144); long B=(long)Bof(ev,10); long m=39255*r-B+65536; if(m<=0) neg++; if(m<minM) minM=m; }
    Console.WriteLine($"(a) E=17 tuples {t17.Count} (claimed 3003); margins<=0: {neg}; min margin {minM} (claimed 7307264)");
    var t16=new List<int[]>(); Tuples(10,16,t16); int expanding=0; var retained=new List<int[]>(); long M=1L<<17;
    long minR=long.MaxValue,maxR=0,minB=long.MaxValue,maxB=0,minLow=long.MaxValue; var byReset=new int[8]; var sumByReset=new BigInteger[8]; int witness=0; int agree=0, disagree=0;
    foreach(var ev in t16){ bool exp=true; int E=0; for(int j=1;j<=9;j++){ E+=ev[j-1]; if(!(BigInteger.Pow(3,j)>(BigInteger.One<<E))) exp=false; } if(exp) expanding++;
      long r=Residue(ev,M); bool found=false; for(long t=0;t<=50&&!found;t++){ long u=r+M*t; long x=u; long[] v=new long[11]; v[0]=u; bool ok=true; for(int j=1;j<=10;j++){ int e; x=A(x,out e); if(e!=ev[j-1]){ok=false;break;} v[j]=x; } if(!ok) continue; long w=v[10]; long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(u,w); for(int j=1;j<10;j++) hi=Math.Min(hi,(3*v[j]+1)/4); if(lo<=hi) found=true; }
      if(found==exp) agree++; else disagree++;
      if(found){ witness++; long B=(long)Bof(ev,10); minR=Math.Min(minR,r); maxR=Math.Max(maxR,r); minB=Math.Min(minB,B); maxB=Math.Max(maxB,B); minLow=Math.Min(minLow,6487*r-B); int k=0; foreach(int e in ev) if(e>=2) k++; byReset[k]++; sumByReset[k]+= (BigInteger)B+32435; } }
    Console.WriteLine($"(b) E=16 tuples {t16.Count} (1287); expanding-prefix tuples {expanding}; with integer witness {witness} (476); witness==expanding in {agree} of {agree+disagree} tuples");
    Console.WriteLine($"    B range [{minB},{maxB}] (claimed [58025,148813]); residues [{minR},{maxR}] (claimed 359..130943); min(6487 r - B) = {minLow} (claimed 2228224)");
    Console.WriteLine("    resets: "+string.Join(" ",new[]{1,2,3,4,5,6}.Length>0?ResetStr(byReset,sumByReset):""));
    // (c)
    double Acon=11.0/4320+(21*Math.Log(2)+15*Math.Log(3)+31*Math.Log(5))/288; double T1=0; double[] me={1,4.0/3,8.0/3,16.0/3,32.0/3}; for(int e=1;e<=5;e++) T1+=1.0/(9*Math.Pow(2,e))*(Math.Log(20/me[e-1])-1+me[e-1]/20);
    Console.WriteLine($"(c) A = {Acon:F7} (< 71/250 = {71.0/250}); 0.1 + sum_e (1/(9*2^e))(ln(20/m_e)-1+m_e/20) = {0.1+T1:F7}; 71/250+89/(48*118) = {71.0/250+89.0/(48*118):F7} < 0.3 < ln(27/20)={Math.Log(27.0/20):F7}; final 13299/8900={13299.0/8900:F6} < 299/200={299.0/200}; margin {299.0/200-13299.0/8900:E3} vs 13/17800={13.0/17800:E3}; 24325110/16899989 = {24325110.0/16899989:F10}");
  }
  static string ResetStr(int[] c,BigInteger[] s){ var sb=new System.Text.StringBuilder(); for(int k=1;k<=6;k++) sb.Append($"k={k}: {c[k]} profiles, sum(B+32435)={s[k]}/59049; "); return sb.ToString(); }
}
