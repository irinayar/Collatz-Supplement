using System; using System.Linq; using System.Collections.Generic;
// First-gate occupancy across depths: sources at depths g, g' with the same gate state y need 2^e 3^-d in (3/4,4/3) (ratio U0/L0 < 4/3),
// i.e. the points theta_j = frac(j*log2 3) of a block of N consecutive depths must lie in an open arc of length w = log2(4/3).
// Compute, for each N, the maximum number of points of {j*alpha mod 1, j<N} in an open arc of length w, and the smallest margin to the endpoint.
class P { static void Main(){ double alpha=Math.Log(3,2)%1.0, w=Math.Log(4.0/3,2); Console.WriteLine($"alpha={alpha:F12}, w=log2(4/3)={w:F12}");
 foreach (int N in new[]{2,3,4,5,6,7,8,9,10,11,12,13,20,29,41,53,54,60,94}) { var th=Enumerate(N,alpha); int best=0; double margin=1; for(int i=0;i<N;i++){ // open arc starting just after th[i] cannot be ... use arcs [th[i], th[i]+w) and (th[i]-w, th[i]] i.e. maximal windows anchored at points
     int cnt=0; for(int j=0;j<N;j++){ double d=(th[j]-th[i]+1.0)%1.0; if(d<w-1e-9){cnt++;} double gap=Math.Abs(d-w); if(gap>1e-9&&gap<margin) margin=gap; }
     if(cnt>best) best=cnt; }
   Console.WriteLine($"N={N}: max points in an open arc of length w = {best}; min |distance - w| = {margin:E2}"); } }
 static double[] Enumerate(int N,double a){ var t=new double[N]; for(int j=0;j<N;j++) t[j]=(j*a)%1.0; return t; } }
