using System;
class P {
  static int EMAX=6; static long[,] mn;
  static void Dfs(long z,int ev,int od){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z;
    if(ev<EMAX) Dfs(2*z,ev+1,od);
    if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long series=0,mono=0,nonmono=0; string ex=""; long strictUp=0;
    for(long x=1;x<=20000;x++){ mn=new long[EMAX+1,45]; Dfs(x,0,0);
      for(int k=0;k<=EMAX;k++){ int R=-1; for(int r=0;r<45;r++) if(mn[k,r]!=0) R=r; series++;
        bool ok=true; for(int r=0;r<R;r++) if(mn[k,r+1]>mn[k,r]){ ok=false; strictUp++; if(ex=="") ex=$"x={x},k={k},r={r}: H={mn[k,r]}, H(r+1)={mn[k,r+1]}"; }
        if(ok) mono++; else nonmono++; } }
    Console.WriteLine($"series (x<=20000,k<=6) {series}; H_k(x,r) nonincreasing in r over [0,R]: {mono}; not: {nonmono}; increasing steps {strictUp}; first example {ex}");
  }
}
