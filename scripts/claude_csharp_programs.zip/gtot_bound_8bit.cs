using System;
using System.Numerics;
// Rigorous (upward-rounded, 16-bit) bound for Gtot(m) = product over pre-cycle odd states of (1+1/(3u)), all odd m <= M. Even m have the same value as their odd part.
class P {
  static void Main(string[] args){
    long M=long.Parse(args[0]); long N=(M-1)/2+1; var q=new byte[N]; // index i <-> odd m=2i+1 ; m=1 -> 0
    const double SC=512.0; byte maxq=0; long argmax=1; var sw=System.Diagnostics.Stopwatch.StartNew();
    for(long m=3;m<=M;m+=2){ long n=m; double p=1.0; while(n>=m){ if((n&1)==1){ p*=1.0+1.0/(3.0*n); n=(3*n+1)>>1; } else n>>=1; }
      int tz=BitOperations.TrailingZeroCount((ulong)n); n>>=tz; double gn= n==1?0.0 : (double)q[(n-1)/2]/SC; // upper bound of G(n)-1 (quantised upward)
      double g=p*(1.0+gn)*(1.0+1e-12); double qq=Math.Ceiling((g-1.0)*SC); if(qq>255) throw new Exception("overflow");
      q[(m-1)/2]=(byte)qq; if(q[(m-1)/2]>maxq){ maxq=q[(m-1)/2]; argmax=m; } }
    Console.WriteLine($"M={M}: rigorous upper bound max Gtot(m) <= 1 + {maxq}/512 = {1+maxq/SC:F6} (attained near m={argmax}); below 3/2: {1+maxq/SC<1.5}; {sw.ElapsedMilliseconds/1000}s");
  }
}
