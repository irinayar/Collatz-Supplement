using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static long S(long n) => (n & 1) == 0 ? n / 2 : (3 * n + 1) / 2;
  // cyclic position key: upper (sign +) arc: decreasing x then lower (sign -) arc: increasing x, counterclockwise from rightmost point
  static (int,long) Pos(long x, bool up) => up ? (0, -x) : (1, x);
  static int Cmp((int,long) a, (int,long) b) => a.Item1 != b.Item1 ? a.Item1.CompareTo(b.Item1) : a.Item2.CompareTo(b.Item2);
  static bool Interlace((int,long) a, (int,long) b, (int,long) c, (int,long) d) {
    // chords ab and cd cross iff exactly one of c,d lies strictly between a and b in cyclic order
    if (Cmp(a, b) > 0) { var t = a; a = b; b = t; }
    bool cin = Cmp(a, c) < 0 && Cmp(c, b) < 0, din = Cmp(a, d) < 0 && Cmp(d, b) < 0;
    return cin != din;
  }
  static double Cross(double ax, double ay, double bx, double by, double cx, double cy) => (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
  static bool SegCross(double[] p1, double[] p2, double[] p3, double[] p4) {
    double d1 = Cross(p3[0], p3[1], p4[0], p4[1], p1[0], p1[1]), d2 = Cross(p3[0], p3[1], p4[0], p4[1], p2[0], p2[1]);
    double d3 = Cross(p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]), d4 = Cross(p1[0], p1[1], p2[0], p2[1], p4[0], p4[1]);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }
  static void Main() {
    long checkedPairs = 0, geomVsOrder = 0, ruleMismatch = 0, crossings = 0;
    var typeCount = new Dictionary<string,long>(); var typeCross = new Dictionary<string,long>();
    for (long n0 = 3; n0 <= 6000; n0 += 1) {
      var xs = new List<long>(); long x = n0;
      while (true) { xs.Add(x); if (x == 1) break; x = S(x); if (xs.Count > 400) break; }
      if (xs.Last() != 1) continue;
      // all vertices distinct? (trajectory until first 1) yes. last vertex 1 has next step 2 (odd, +) but we do not include chord 1->2
      long H = xs.Max(); double R = H + 1.0;
      int m = xs.Count; var up = xs.Select(v => (v & 1) == 1).ToArray();
      double[][] pt = new double[m][];
      for (int i = 0; i < m; i++) { double h = Math.Sqrt(R * R - (double)xs[i] * xs[i]); pt[i] = new double[] { xs[i], up[i] ? h : -h }; }
      for (int i = 0; i + 1 < m; i++) for (int j = i + 1; j + 1 < m; j++) {
        int[] e = { i, i + 1, j, j + 1 }; if (e.Distinct().Count() < 4) continue;
        checkedPairs++;
        bool geo = SegCross(pt[i], pt[i + 1], pt[j], pt[j + 1]);
        bool ord = Interlace(Pos(xs[i], up[i]), Pos(xs[i + 1], up[i + 1]), Pos(xs[j], up[j]), Pos(xs[j + 1], up[j + 1]));
        if (geo != ord) geomVsOrder++;
        if (ord) crossings++;
        // closed-form rules
        string ti = (up[i] ? "+" : "-") + (up[i + 1] ? "+" : "-"), tj = (up[j] ? "+" : "-") + (up[j + 1] ? "+" : "-");
        string key = string.Compare(ti, tj, StringComparison.Ordinal) <= 0 ? ti + "/" + tj : tj + "/" + ti;
        bool rule; bool known = true;
        // chord described by (start value s, end value t), types: ++ : t=(3s+1)/2 ; -- : t=s/2 ; +- peak: s upper, t=(3s+1)/2 lower ; -+ valley: s lower, t=s/2 upper
        long s1 = xs[i], s2 = xs[j];
        if (ti == "++" && tj == "++") rule = (Math.Min(s1, s2) < Math.Max(s1, s2)) && (Math.Max(s1, s2) < (3 * Math.Min(s1, s2) + 1) / 2.0);
        else if (ti == "--" && tj == "--") rule = Math.Max(s1, s2) < 2 * Math.Min(s1, s2);
        else if (ti == "+-" && tj == "+-") rule = false;
        else if (ti == "-+" && tj == "-+") rule = false;
        else if ((ti == "+-" && tj == "-+") || (ti == "-+" && tj == "+-")) {
          long a = ti == "+-" ? s1 : s2, b = ti == "+-" ? s2 : s1; rule = (3 * a + 1) / 2.0 < b && b < 2.0 * a; }
        else if ((ti == "+-" && tj == "++") || (ti == "++" && tj == "+-")) {
          long a = ti == "+-" ? s1 : s2, xx = ti == "+-" ? s2 : s1; rule = xx < a && a < (3 * xx + 1) / 2.0; }
        else if ((ti == "+-" && tj == "--") || (ti == "--" && tj == "+-")) {
          long a = ti == "+-" ? s1 : s2, y = ti == "+-" ? s2 : s1; double p = (3 * a + 1) / 2.0; rule = y / 2.0 < p && p < y; }
        else if ((ti == "-+" && tj == "++") || (ti == "++" && tj == "-+")) {
          long b = ti == "-+" ? s1 : s2, xx = ti == "-+" ? s2 : s1; double u = b / 2.0; rule = xx < u && u < (3 * xx + 1) / 2.0; }
        else if ((ti == "-+" && tj == "--") || (ti == "--" && tj == "-+")) {
          long b = ti == "-+" ? s1 : s2, y = ti == "-+" ? s2 : s1; rule = y / 2.0 < b && b < y; }
        else if ((ti == "++" && tj == "--") || (ti == "--" && tj == "++")) rule = false;
        else { known = false; rule = ord; }
        if (!known) { Console.WriteLine("unhandled " + ti + "/" + tj); }
        if (rule != ord) ruleMismatch++;
        typeCount.TryGetValue(key, out long c); typeCount[key] = c + 1; if (ord) { typeCross.TryGetValue(key, out long cc); typeCross[key] = cc + 1; }
      }
    }
    Console.WriteLine($"chord pairs with 4 distinct endpoints checked: {checkedPairs}; geometry vs cyclic-order mismatches: {geomVsOrder}; closed-form rule mismatches: {ruleMismatch}; crossing pairs: {crossings}");
    foreach (var kv in typeCount.OrderBy(k => k.Key)) { typeCross.TryGetValue(kv.Key, out long c); Console.WriteLine($"  {kv.Key,-8} pairs {kv.Value,10}  crossing {c,9}"); }
  }
}
