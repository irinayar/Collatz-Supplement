using System;
using System.Collections.Generic;
// Check of Codex 134433 (C119/K084): exact max odd count R_e(x) with exactly e even steps, recursion R_k(x)=max_{0<=l<=a}[l+R_{k-1}(2 y_l)], R_0=v3(x+1), y_l=2^l(x+1)/3^l-1.
// Independent brute force: DFS over the inverse tree (even edge z->2z, odd edge z->(2z-1)/3 if z=2 mod 3), recording all (evens, odds) reachable.
class P {
  static int V3(long n){int c=0; while(n%3==0){n/=3;c++;} return c;}
  static long Pow(long b,int e){long r=1; for(int i=0;i<e;i++) r*=b; return r;}
  static long R(long x,int k){ int a=V3(x+1); if(k==0) return a; long best=-1;
    for(int l=0;l<=a;l++){ long y=Pow(2,l)*(x+1)/Pow(3,l)-1; if(y<1) continue; long v=l+R(2*y,k-1); if(v>best) best=v; } return best; }
  static long R1(long Y){ int A=V3(Y+1); long U=(Y+1)/Pow(3,A); return A+V3(Pow(2,A+1)*U-1); }
  static int EMAX=7; static HashSet<int>[] feas;
  static void Dfs(long z,int ev,int od){ feas[ev].Add(od);
    if(ev<EMAX) Dfs(2*z,ev+1,od);
    if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long cells=0,bad=0,gaps=0,r1bad=0; var gapEx=""; 
    for(long x=1;x<=20000;x++){
      feas=new HashSet<int>[EMAX+1]; for(int i=0;i<=EMAX;i++) feas[i]=new HashSet<int>();
      Dfs(x,0,0);
      for(int e=0;e<=EMAX;e++){ int mx=-1,mn=int.MaxValue; foreach(var r in feas[e]){ if(r>mx) mx=r; if(r<mn) mn=r; }
        cells++; if(mx!=R(x,e)) bad++;
        if(e==1 && mx!=R1(x)) r1bad++;
        if(mx>=0 && feas[e].Count!=mx-mn+1){ gaps++; if(gapEx=="") gapEx=$"x={x},e={e},max={mx},count={feas[e].Count}"; }
        if(mn!=0 && mx>=0 && e>=0) { /* min odd count recorded for info */ } }
    }
    Console.WriteLine($"cells {cells} (x<=20000, e<=7), maximum-odd-count mismatches {bad}, K083 R1 mismatches {r1bad}, cells whose feasible r-set has gaps {gaps} {gapEx}");
  }
}
