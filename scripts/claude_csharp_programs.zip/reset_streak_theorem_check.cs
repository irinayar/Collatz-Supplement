using System;
// Check ChatGPT 112856 Theorem 1: consecutive odd-to-odd transitions with e>=2 (strict descents) from u0 to b>=3:
// G=prod(1+1/(3u_i)) = b/(b-Z), Z=sum (1/3)/prod_{j>=i} d_j, d=2^e/3; and G<b/(b-1)<=3/2.
// Exhaustive over odd u0 < 2^25, all streak prefixes t>=1 with end b>=3. Also max of G*(b-1)/b and max streak.
class P {
  static void Main(){
    long cases=0; int maxT=0; double maxRatio=0, maxG=0, maxIdErr=0; long argR=0;
    for(long u0=3; u0<(1L<<25); u0+=2){
      long u=u0; int t=0; double lg=0; // log of G
      double[] ds=new double[64];
      double G=1.0;
      while(true){
        long x=3*u+1; int e=0; while((x&1)==0){x>>=1;e++;}
        if(e<2) break;
        G*= (3.0*u+1)/(3.0*u); ds[t]=Math.Pow(2,e)/3.0; t++; long b=x;
        if(b<3) break;
        // Z via suffix products
        double Z=0, suf=1.0; for(int i=t-1;i>=0;i--){ suf*=ds[i]; Z+=(1.0/3)/suf; }
        double Gid=b/(b-Z); maxIdErr=Math.Max(maxIdErr,Math.Abs(G-Gid)/G);
        double ratio=G*(b-1.0)/b; if(ratio>maxRatio){maxRatio=ratio;argR=u0;}
        if(G>maxG) maxG=G; cases++; if(t>maxT) maxT=t;
        u=b; if(t>=60) break;
      }
    }
    Console.WriteLine($"cases {cases}, longest streak {maxT}, max G {maxG:F8}, max G*(b-1)/b = {maxRatio:F10} (must be <1) at u0={argR}, max rel identity error {maxIdErr:E2}");
  }
}
