using System;
using System.Numerics;
// ChatGPT 092602: capped prefix lattice for the old count (x=17,k=9,b=6) against explicit successor origins M=507 and M=456.
class P {
  static BigInteger Md(BigInteger a,BigInteger m){ var r=a%m; if(r<0) r+=m; return r; }
  static BigInteger FloorDiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); if(r<0) q-=1; return q; }
  static BigInteger CeilDiv(BigInteger a,BigInteger b)=>-FloorDiv(-a,b);
  static int EM; static BigInteger[] mn,mx; static long[] cnt; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; cnt[od]++; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Lattice(int k,int b,BigInteger x,BigInteger M,int j,out long tails,out BigInteger cands){ int L=k+b; BigInteger B=BigInteger.Pow(2,L)*x; int n=b-j; BigInteger Q=BigInteger.Pow(3,n), p3j=BigInteger.Pow(3,j), p3b=BigInteger.Pow(3,b); BigInteger d=n==0?0:Q-BigInteger.Pow(2,n); long tl=0; BigInteger cd=0; tails=0; cands=0; var t=new int[j];
    void Rec(int idx,int start){ if(idx==j){ BigInteger T=0; for(int i=0;i<j;i++) T+=BigInteger.Pow(3,j-1-i)*BigInteger.Pow(2,t[i]); int tt=j==0?L:t[0]; if(tt<n) return; if(!Md(B-T,p3j).IsZero) return; BigInteger u=n==0?0:BigInteger.Pow(2,tt-n)*d; BigInteger D=Md((B-T)/p3j,Q);
        BigInteger lo=BigInteger.Max(d,CeilDiv(B-T-p3b*M,p3j)), hi=BigInteger.Min(u,FloorDiv(B-T-p3b,p3j)); if(lo>hi) return; BigInteger first=lo+Md(D-lo,Q); BigInteger last=hi-Md(hi-D,Q); if(first>last) return; tl++; cd+=(last-first)/Q+1; return; }
      for(int s=start;s<L;s++){ t[idx]=s; Rec(idx+1,s+1); } }
    Rec(0,0); tails=tl; cands=cd; }
  static void Main(){
    int k=9,b=6; BigInteger x=17; EM=k; mn=new BigInteger[9]; mx=new BigInteger[9]; cnt=new long[9]; Dfs(x,0,0);
    Console.WriteLine($"old (k=9,b=6,x=17): {cnt[b]} origins, min {mn[b]}, max {mx[b]}; successor (b+1=7): {cnt[b+1]} origins, min {mn[b+1]}, max {mx[b+1]} (ChatGPT: 15, 688, 761; 11, 456, 507)");
    foreach(var M in new BigInteger[]{507,456}){ for(int j=0;j<=4;j++){ Lattice(k,b,x,M,j,out long tails,out BigInteger cands); Console.WriteLine($"  M={M}, j={j}: surviving tails {tails}, lattice candidates {cands}"); } }
  }
}
