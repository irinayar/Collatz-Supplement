using System;
using System.Collections.Generic;
using System.Numerics;
// ChatGPT 162455: six-even, x=3u-1, u=2 mod 3. Plus data for u=1 mod 3 (branches P_r=H_5(6u-2,r), Q_r=H_5(4u-2,r-1)).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    // Six-even, x=3u-1, u=1 mod 3: P_r=H_5(6u-2,r), Q_r=H_5(4u-2,r-1). min(P,Q) can fail to decrease only at an END event:
    // branch Y finite at r, infinite at r+1, branch X finite at r and r+1, and Y_r < X_r. Then need X_(r+1) < Y_r.
    long events=0,bad=0,pEnds=0,qEnds=0,needed=0,noContr=0,critBad=0,pLess=0; BigInteger maxGap=0,minY=-1,minMargin=-1; var kinds=new SortedDictionary<string,long>(); var byIdx=new SortedDictionary<string,long>();
    for(int u=1;u<=12000;u+=3){ BigInteger U=u; for(int r=1;r<=60;r++){ var Pv=H(6*U-2,5,r); var Qv=H(4*U-2,5,r-1); var Pn=H(6*U-2,5,r+1); var Qn=H(4*U-2,5,r);
        for(int side=0;side<2;side++){ BigInteger Yr=side==0?Pv:Qv, Yn=side==0?Pn:Qn, Xr=side==0?Qv:Pv, Xn=side==0?Qn:Pn; // Y = ending branch
          if(Yr!=INF&&Yn==INF&&Xr!=INF&&Xn!=INF){ events++; if(side==0) pEnds++; else qEnds++; if(Yr<Xr){ needed++; if(!(Xn<Yr)) bad++; var g=Xr-Yr; if(g>maxGap) maxGap=g; if(minY==-1||Yr<minY) minY=Yr; var mg=Yr-Xn; if(minMargin==-1||mg<minMargin) minMargin=mg;
              string kind="none"; for(int c=0;c<=8;c++) if(3*(Xn+c)==2*(Xr+c)){ kind="c="+c; break; } kinds[kind]=kinds.GetValueOrDefault(kind)+1; if(kind=="none") noContr++;
              BigInteger crit=2*g; // need Y_r > 2g - c
              if(kind!="none"){ int c=int.Parse(kind.Substring(2)); if(!(Yr>crit-c)) critBad++; } string key=(side==0?"P ends":"Q ends")+" at r="+Math.Min(r,8); byIdx[key]=byIdx.GetValueOrDefault(key)+1; } } } }
      if(hm.Count>3000000) hm.Clear(); }
    Console.WriteLine("end events (one branch ends, the other continues): " + events + " (P ends " + pEnds + ", Q ends " + qEnds + "); events where the ending branch is the minimum at its last index (comparison actually needed): " + needed + "; failures X_(r+1) < Y_r: " + bad);
    Console.WriteLine("max gap X_r-Y_r " + maxGap + "; min Y_r " + minY + "; min margin Y_r-X_(r+1) " + minMargin + "; contraction forms 3(Xn+c)=2(Xr+c): " + string.Join(", ",kinds) + "; criterion Y_r>2g-c failures " + critBad);
    Console.WriteLine("by end index: " + string.Join("; ",byIdx));
  }
}
