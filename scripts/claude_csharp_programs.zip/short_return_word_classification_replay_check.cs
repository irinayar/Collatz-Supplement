using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent classification of genuine first-return exponent words by number of odd transitions g (<=12) at threshold n=2^71+1:
// feasible = exists integer u in [n,H] with the exact odd-arrival cylinder, x_g in [n,H], x_j>H for 0<j<g. Charge sign from c(p)=B_g+5(2^E-3^g).
class P { static BigInteger n,H;
 static BigInteger Cdiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); return (r.Sign>0)?q+1:q; } static BigInteger Fdiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); return (r.Sign<0)?q-1:q; }
 static BigInteger ModInv(BigInteger a,BigInteger m){ BigInteger x0=1,x1=0,r0=((a%m)+m)%m,r1=m; while(r1!=0){ var q=r0/r1; var t=r0-q*r1; r0=r1; r1=t; var u=x0-q*x1; x0=x1; x1=u; } return ((x0%m)+m)%m; }
 static int[] cnt=new int[14],pos=new int[14],neu=new int[14],neg=new int[14]; static List<int> cur=new List<int>(); static int G,E;
 static void Check(){ int g=G; var Bj=new BigInteger[g+1]; var Ej=new int[g+1]; Bj[0]=0; for(int j=0;j<g;j++){ Bj[j+1]=3*Bj[j]+BigInteger.Pow(2,Ej[j]); Ej[j+1]=Ej[j]+cur[j]; }
   // linear constraints on u: A_j*u + B_j > H*2^{E_j} for 0<j<g ; n<=u<=H ; n*2^E <= 3^g u + B_g <= H*2^E
   BigInteger lo=n, hi=H; for(int j=1;j<g;j++){ BigInteger A=BigInteger.Pow(3,j), rhs=H*BigInteger.Pow(2,Ej[j])-Bj[j]; // A u > rhs
       lo=BigInteger.Max(lo,Fdiv(rhs,A)+1); }
   BigInteger Ag=BigInteger.Pow(3,g), P=BigInteger.Pow(2,E); lo=BigInteger.Max(lo,Cdiv(n*P-Bj[g],Ag)); hi=BigInteger.Min(hi,Fdiv(H*P-Bj[g],Ag)); if(lo>hi) return;
   BigInteger M=BigInteger.Pow(2,E+1); BigInteger r=(((P-Bj[g])%M+M)%M*ModInv(Ag,M))%M; BigInteger u=lo+(((r-lo)%M)+M)%M; if(u>hi) return;
   cnt[g]++; BigInteger c=Bj[g]+5*(P-Ag); if(c.Sign>0) pos[g]++; else if(c.Sign==0) neu[g]++; else neg[g]++; }
 static void Rec(int i,int Esum){ if(i==G){ if(Esum==E) Check(); return; } int rem=G-i-1; for(int e=1;Esum+e+rem<=E;e++){ cur.Add(e); Rec(i+1,Esum+e); cur.RemoveAt(cur.Count-1);} }
 static void Main(){ n=BigInteger.Pow(2,71)+1; H=(4*n-2)/3; double l23=Math.Log(3)/Math.Log(2);
  for(G=1;G<=12;G++){ int e0=(int)Math.Floor(G*l23)-1, e1=(int)Math.Ceiling(G*l23)+1; for(E=Math.Max(G,e0);E<=e1;E++) Rec(0,0); }
  Console.WriteLine("g: feasible, positive, neutral, negative (n=2^71+1)"); long totalPos=0; for(int g=1;g<=12;g++){ Console.WriteLine(g+": "+cnt[g]+", "+pos[g]+", "+neu[g]+", "+neg[g]); if(g<=10) totalPos+=pos[g]; }
  Console.WriteLine("sum of positive profiles for g<=10: "+totalPos+" (claimed 713 over gaps 3,5,7,8,9,10 = 2,7,30,85,113,476)"); }}
