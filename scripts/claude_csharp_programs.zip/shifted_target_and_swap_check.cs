using System;
using System.Collections.Generic;
using System.Numerics;
// Checks of ChatGPT 220138 / 220618: (1) H_k(4,3)=17*2^(k-4) (k>=4), H_k(5,3)=11*2^(k-3) (k>=3); (2) adjacent-swap lemma; (3) shifted-target experiment on the 56 filter survivors.
class P {
  static BigInteger[,] mn; static int EM; static void Dfs(BigInteger z,int ev,int od,int maxOd){ if(od<=maxOd&&od<mn.GetLength(1)){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z; } if(ev<EM) Dfs(2*z,ev+1,od,maxOd); if(od<maxOd&&z%3==2) Dfs((2*z-1)/3,ev,od+1,maxOd); }
  static BigInteger H(long x,int k,int r){ EM=k; mn=new BigInteger[k+1,r+2]; Dfs(x,0,0,r); return mn[k,r]; }
  static BigInteger Vof(int mask,int len){ BigInteger V=0; for(int i=0;i<len;i++){ if(((mask>>i)&1)==1) V=3*V+BigInteger.Pow(2,i); } return V; } // bit i=1 means O at position i (position 0 = first step)
  static void Main(){
    long bad1=0,c1=0; for(int k=3;k<=14;k++){ if(k>=4){ c1++; if(H(4,k,3)!=17*BigInteger.Pow(2,k-4)) bad1++; } c1++; if(H(5,k,3)!=11*BigInteger.Pow(2,k-3)) bad1++; }
    Console.WriteLine($"(1) H_k(4,3)=17*2^(k-4) (k=4..14), H_k(5,3)=11*2^(k-3) (k=3..14): {c1} cases, failures {bad1}");
    // (2) swap lemma: V(EO)-V(OE) = 2^p 3^t ; and two words feasible for the same x never differ by one adjacent swap
    long sw=0,swBad=0,bothFeas=0; for(int L=2;L<=12;L++) for(int mask=0;mask<(1<<L);mask++) for(int p=0;p+1<L;p++){ bool a=((mask>>p)&1)==1, b=((mask>>(p+1))&1)==1; if(!(a&&!b)) continue; int mask2=mask^(1<<p)^(1<<(p+1)); int t=0; for(int i=p+2;i<L;i++) if(((mask>>i)&1)==1) t++; var d=Vof(mask2,L)-Vof(mask,L); sw++; if(d!=BigInteger.Pow(2,p)*BigInteger.Pow(3,t)) swBad++; int r=0; for(int i=0;i<L;i++) if(((mask>>i)&1)==1) r++; if(r>=1&&(d%BigInteger.Pow(3,r)).IsZero) bothFeas++; }
    Console.WriteLine($"(2) adjacent swap OE->EO: {sw} cases (L<=12), numerator difference != 2^p 3^t in {swBad}; cases with 3^r dividing the difference (would allow both words at one endpoint): {bothFeas}");
    // (3) the 56 survivors
    var dom=new long[7]; for(int r=0;r<=6;r++){ long p=1; for(int i=0;i<=r;i++) p*=3; dom[r]=p+2; }
    var cells=new List<(long x,int k,int r,BigInteger h)>(); 
    for(long x=3;x<=dom[6];x++){ EM=8; var m8=new BigInteger[9,100]; mn=m8; Dfs(x,0,0,99); var mm=mn; for(int r=0;r<=6;r++){ if(x>dom[r]) continue; for(int k=0;k<=8;k++){ var h0=mm[k,r]; var h1=mm[k,r+1]; if(h0==0||h1==0) continue; if(h0%3==2) continue; if(k>=1&&h0>=BigInteger.Pow(2,k+1)-3) continue; cells.Add((x,k,r,h0)); } } }
    long totalCand=0,admissible=0,allWin=0,allPos=0; var hist=new SortedDictionary<int,int>(); long marginBad=0;
    foreach(var (x,k,r,h) in cells){ int Lp=k+r+1; BigInteger mod=BigInteger.Pow(3,r+1); int fav=0; long cand=0;
      for(int mask=0;mask<(1<<Lp);mask++){ int odd=0; for(int i=0;i<Lp;i++) if(((mask>>i)&1)==1) odd++; if(odd!=r+1) continue; cand++; BigInteger V=Vof(mask,Lp); BigInteger num=BigInteger.Pow(2,Lp)*x-V; if(!(num%mod).IsZero) continue; var mp=num/mod; if(mp<=0) continue; admissible++; allPos++; if(mp<h) { allWin++; fav++; } BigInteger Vw=0; }
      totalCand+=cand; if(!hist.ContainsKey(fav)) hist[fav]=0; hist[fav]++; }
    Console.WriteLine($"(3) cells {cells.Count}; candidate words with r+1 odd steps (all positions): {totalCand}; congruence-admissible with positive origin: {admissible}; of which m' < H_k(x,r): {allWin}; histogram of favourable words per cell: " + string.Join(", ",hist));
  }
}
