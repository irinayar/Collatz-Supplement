using System;
using System.Collections.Generic;
// mu(x) = least k with T^k(x) = T^k(x-1), x odd >= 3 (the pair x-1, x coalesces). Theorem-C type partner: n = 2^i x has partner n - 2^i at depth i + mu(x).
class P {
  static long T(long x) => (x & 1) == 1 ? (3 * x + 1) / 2 : x / 2;
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var mu = new int[N + 2];
    for (int x = 3; x <= N; x += 2) { long p = x, q = x - 1; int k = 0; while (p != q && k < 200) { p = T(p); q = T(q); k++; } mu[x] = p == q ? k : 0; }
    long odd = 0, never = 0; var h = new SortedDictionary<int, long>(); for (int x = 3; x <= N; x += 2) { odd++; if (mu[x] == 0) never++; else h[mu[x]] = h.GetValueOrDefault(mu[x]) + 1; }
    Console.WriteLine($"odd x in [3,{N}]: {odd}; mu(x) undefined within 200 steps: {never} ({(double)never / odd:P2})");
    long cum = 0; foreach (var kv in h) { cum += kv.Value; if (kv.Key <= 12 || kv.Key % 10 == 0) Console.WriteLine($"  mu={kv.Key,3}: {kv.Value,8} ({(double)kv.Value / odd:P3} of odd x), cumulative {(double)cum / odd:P2}"); }
    // periodicity test of {mu(x) <= k} among odd x for small k
    foreach (int k in new[] { 3, 4, 5, 6, 7, 8 }) {
      long best = long.MaxValue; int ba = 0, bb = 0;
      for (int ea = 1; ea <= k + 2; ea++) for (int eb = 0; eb <= 3; eb++) { long per = 1L << ea; for (int i = 0; i < eb; i++) per *= 3; if (per >= best || per > N / 4) continue;
        bool ok = true; for (long x = 3; x + per <= N && ok; x += 2) { if (((x & 1) == 1) && ((x + per) & 1) == 1) { bool u = mu[x] != 0 && mu[x] <= k, w = mu[x + per] != 0 && mu[x + per] <= k; if (u != w) ok = false; } }
        if (ok) { best = per; ba = ea; bb = eb; } }
      Console.WriteLine($"  {{mu <= {k}}}: smallest period found 2^{ba}*3^{bb} = {best}");
    }
  }
}
