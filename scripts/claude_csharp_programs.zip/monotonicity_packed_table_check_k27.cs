using System;
using System.Numerics;
// Packed table (key=(x<<7)|r, x<2^57, r<127). Optional extra test of ChatGPT's necessary conditions (args[2]=="props").
class P {
  static ulong[] key; static int[] val; static int mask; static long count; static long overflow;
  static int Slot(ulong k){ ulong h=k*0x9E3779B97F4A7C15UL; h^=h>>29; h*=0xBF58476D1CE4E5B9UL; h^=h>>32; return (int)(h&(ulong)mask); }
  static void Insert(long x,int r,long m){ if(x>=(1L<<57)||r>=126){ overflow++; return; } ulong k=((ulong)x<<7)|(ulong)r; int s=Slot(k); while(val[s]!=0){ if(key[s]==k) return; s=(s+1)&mask; } key[s]=k; val[s]=(int)m; count++; }
  static int Find(long x,int r){ ulong k=((ulong)x<<7)|(ulong)r; int s=Slot(k); while(val[s]!=0){ if(key[s]==k) return val[s]; s=(s+1)&mask; } return 0; }
  static void Main(string[] args){
    int k=int.Parse(args[0]); int bits=int.Parse(args[1]); bool props=args.Length>2; long B=3L*(1L<<k)-4; int size=1<<bits; mask=size-1; key=new ulong[size]; val=new int[size];
    var sw=System.Diagnostics.Stopwatch.StartNew();
    for(long m=1;m<B;m++){ long y=m; int e=0,o=0; while(true){ if(e==k) Insert(y,o,m); if((y&1)==1){ y=(3*y+1)>>1; o++; } else { if(e==k) break; y>>=1; e++; } } }
    long pairs=count, ok=0, term=0, viol=0, violGe3=0, c2=0,c2bad=0,cEarly=0,cEarlyBad=0, cand=0; string list="";
    for(int s=0;s<size;s++){ if(val[s]==0) continue; long x=(long)(key[s]>>7); int r=(int)(key[s]&127); long h=val[s]; long hp=Find(x,r+1);
      if(hp==0) term++; else if(hp<h) ok++; else { viol++; if(x>=3) violGe3++; if(viol<=8) list+=$"(x={x},r={r}:{h}->{hp}) "; }
      if(props&&hp!=0&&x>=3){ if(h%3==2){ c2++; if(!(hp<h)) c2bad++; } bool early=BigInteger.Pow(2,r)*(x+3)>=BigInteger.Pow(3,r+1); if(early){ cEarly++; if(!(hp<h)) cEarlyBad++; } if(h%3!=2&&!early) cand++; } }
    Console.WriteLine($"k={k}: B={B}, exceptional pairs {pairs}, successor smaller {ok}, terminal {term}, violations {viol} (x>=3: {violGe3}) {list} overflow-skipped {overflow} [{sw.ElapsedMilliseconds/1000}s, load {(double)pairs/size:F2}]");
    if(props) Console.WriteLine($"  x>=3 pairs with feasible successor: min origin = 2 mod 3: {c2} (failures {c2bad}); early range 2^r(x+3)>=3^(r+1): {cEarly} (failures {cEarlyBad}); pairs surviving both ChatGPT conditions (potential violations, all of which have smaller successors): {cand}");
  }
}
