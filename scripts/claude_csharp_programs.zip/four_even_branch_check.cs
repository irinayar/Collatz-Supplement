using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 142944: x+1=3u (3 not| u), A=6u-2, B=4u-2, C=4u-1, P_r=L_3(A,r), Q_r=L_3(B,r-1), L_4(x,r)=min(P_r,Q_r).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long t1bad=0,t1n=0,t2bad=0,t2n=0,pairs=0,d4=0,d1=0,dother=0,takeovers=0,takeBad=0,l4bad=0,mono=0; int minPbefore=int.MaxValue; BigInteger minP=-1;
    for(int u=1;u<=6000;u++){ if(u%3==0) continue; BigInteger x=3*(BigInteger)u-1, A=6*(BigInteger)u-2, Bn=4*(BigInteger)u-2, C=4*(BigInteger)u-1;
      var Pr=new BigInteger[40]; var Qr=new BigInteger[40]; for(int r=0;r<40;r++){ Pr[r]=H(A,3,r); Qr[r]=r>=1?H(Bn,3,r-1):INF; }
      // consistency with L_4 recursion
      for(int r=0;r<40;r++){ BigInteger m=INF; if(Pr[r]!=INF) m=Pr[r]; if(Qr[r]!=INF&&(m==INF||Qr[r]<m)) m=Qr[r]; if(m!=H(x,4,r)) l4bad++; }
      if(u%3==2){ t1n++; bool ok=true; for(int r=0;r<40;r++){ if(r!=1&&Qr[r]!=INF) ok=false; }
        if(Qr[1]!=8*C-8) ok=false; if(Pr[1]!=Qr[1]+4) ok=false; if(Pr[2]!=(16*C-10)/3) ok=false; if(!(Qr[1]>Pr[2])) ok=false; if(!ok) t1bad++; }
      else { int c=V3(C); t2n++; bool ok=true; for(int r=1;r<=c+1;r++){ if(Pr[r]==INF||Qr[r]==INF||Pr[r]-Qr[r]!=4) ok=false; } if(!ok) t2bad++; }
      // overlap pairs and takeover
      bool prevB=false; BigInteger lastQ=-1;
      for(int r=1;r<40;r++){ if(Pr[r]!=INF&&Qr[r]!=INF){ pairs++; var d=Pr[r]-Qr[r]; if(d==4) d4++; else if(d==1) d1++; else dother++; }
        BigInteger m=INF; bool isB=false; if(Pr[r]!=INF) m=Pr[r]; if(Qr[r]!=INF&&(m==INF||Qr[r]<m)){ m=Qr[r]; isB=true; }
        if(prevB && !isB && m!=INF){ takeovers++; if(!(m<lastQ)) takeBad++; if(Pr[r]!=INF && (minP==-1||Pr[r]<minP)) minP=Pr[r]; }
        if(isB) lastQ=m; prevB=isB; }
      BigInteger prev=INF; for(int r=0;r<40;r++){ var m=H(x,4,r); if(m==INF) break; if(prev!=INF && !(m<prev)) mono++; prev=m; }
      hm.Clear(); }
    Console.WriteLine($"u<=6000: L_4=min(P,Q) recursion mismatches {l4bad}; Thm1 (u=2 mod 3) cases {t1n}, failures {t1bad}; Thm2 (u=1 mod 3) cases {t2n}, failures {t2bad}; overlap pairs {pairs}: P-Q=4: {d4}, =1: {d1}, other: {dother}; B-to-A takeovers {takeovers}, takeover failures {takeBad}, min P at takeover {minP}; L_4 non-decreasing steps {mono}");
  }
}
