using System;
using System.Collections.Generic;
// Test of the epoch decomposition bound on actual prefixes: odd inputs u_0..u_{r-1} (all >=5), transitions F with valuations e_i.
// bound = (1+1/u_0 if starts with rise) * prod_valleys (1+2/(v-1)) * (1+1/(b-1) if ends with reset streak), with v = output of a reset streak that is followed by rise.
class P {
  static void Main(){
    long cases=0,bad=0; double maxRatio=0; long arg=0; long maxEpochs=0;
    for(long u0=5; u0<(1L<<22); u0+=2){
      if(u0%3==0 && false) continue;
      var us=new List<long>(); var es=new List<int>(); long u=u0;
      while(u>=5 && us.Count<400){ long x=3*u+1; int e=0; while((x&1)==0){x>>=1;e++;} us.Add(u); es.Add(e); u=x; }
      int r=us.Count; // transitions 0..r-1, final output u (<5 or cap)
      if(u>=5) { continue; } // skip truncated
      for(int rr=1; rr<=r; rr++){ // every prefix of rr transitions (output us[rr] or u)
        long outp = rr<r? us[rr] : u; double logG=0; for(int i=0;i<rr;i++) logG+=Math.Log((3.0*us[i]+1)/(3.0*us[i]));
        // decompose
        double logB=0; int i0=0; int ep=0;
        // initial rise
        int j=0; while(j<rr && es[j]==1) j++; if(j>0){ logB+=Math.Log(1+1.0/us[0]); }
        while(j<rr){ // reset streak
          int k=j; while(k<rr && es[k]>=2) k++; // reset streak j..k-1 ends at output of transition k-1 = (k<rr? us[k] : outp)
          long v = (k<rr)? us[k] : outp; 
          int s=0; int m=k; while(m<rr && es[m]==1){ m++; s++; }
          if(s>0){ logB+=Math.Log(1+2.0/(v-1)); ep++; } else { logB+=Math.Log(v/(v-1.0)); }
          j=m; }
        cases++; if(logG>logB+1e-12) bad++; double ratio=logG/logB; if(ratio>maxRatio){maxRatio=ratio;arg=u0;} if(ep>maxEpochs) maxEpochs=ep;
      }
    }
    Console.WriteLine($"prefix cases {cases}, violations {bad}, max logG/logBound {maxRatio:F4} at {arg}, max epochs {maxEpochs}");
  }
}
