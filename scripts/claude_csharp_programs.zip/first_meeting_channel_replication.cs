using System;
using System.Collections.Generic;
// Replication of ChatGPT 111840: first synchronous smaller-origin meeting tau(n) <= 90 for odd n <= 20000 whose source prefix z_0..z_tau stays >= n and distinct.
// Classification by the odd-count difference (partner minus source) over ALL smaller origins meeting at tau: higher (+), same (0), lower (-).
class P {
  static void Main() {
    int N = 20000, JM = 90; var val = new long[N + 1]; var cnt = new int[N + 1]; for (int n = 1; n <= N; n++) val[n] = n; var done = new bool[N + 1]; var idx = new int[N];
    long hi = 0, sameOnly = 0, lowOnly = 0, elig = 0, firstAny = 0, mixedLow = 0; var examples = new List<string>();
    for (int j = 1; j <= JM; j++) {
      for (int n = 1; n <= N; n++) { long v = val[n]; if ((v & 1) == 1) { val[n] = (3 * v + 1) / 2; cnt[n]++; } else val[n] = v / 2; }
      for (int i = 0; i < N; i++) idx[i] = i + 1;
      Array.Sort(idx, (x, y) => { int c = val[x].CompareTo(val[y]); return c != 0 ? c : x.CompareTo(y); });
      for (int i = 0; i < N;) { int e = i; while (e < N && val[idx[e]] == val[idx[i]]) e++;
        for (int t = i + 1; t < e; t++) { int n = idx[t]; if (done[n]) continue; done[n] = true; firstAny++;
          if ((n & 1) == 0) continue;
          // source prefix check: z_0..z_j >= n and distinct
          long z = n; var seen = new HashSet<long> { n }; bool ok = true; for (int s = 1; s <= j; s++) { z = (z & 1) == 1 ? (3 * z + 1) / 2 : z / 2; if (z < n || !seen.Add(z)) { ok = false; break; } }
          if (!ok) continue; elig++;
          bool h = false, same = false, low = false; for (int u = i; u < t; u++) { int d = cnt[idx[u]] - cnt[n]; if (d > 0) h = true; else if (d == 0) same = true; else low = true; }
          if (h) hi++; else if (same) sameOnly++; else if (low) lowOnly++; if (low && (h || same)) mixedLow++;
          if (examples.Count < 3 && !h && same) examples.Add($"(n={n}, j={j}, y={val[n]}, partner {idx[i]})"); } 
        i = e; } }
    Console.WriteLine($"odd n<=20000, tau<=90, source prefix >= n and distinct: eligible first meetings {elig}; with a higher-count partner {hi}; same-count only {sameOnly}; lower-only {lowOnly}; (lower partners also present together with others: {mixedLow}); examples of same-only: {string.Join(" ", examples)}");
  }
}
