using System;
using System.Numerics;
// For x = 2 mod 3: H_k(x,1) = 2^k (2x-1)/3 (all k>=0). Own inverse-tree DFS, odd count capped at 1.
class P {
  static int EMAX; static BigInteger[] mn; static void Dfs(BigInteger z,int ev,int od){ if(ev==EMAX&&od==1){ if(mn[1]==0||z<mn[1]) mn[1]=z; } if(ev<EMAX) Dfs(2*z,ev+1,od); if(od<1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){ long cases=0,bad=0; for(int x=2;x<=3000;x+=3) for(int k=0;k<=10;k++){ EMAX=k; mn=new BigInteger[2]; Dfs(x,0,0); BigInteger want=BigInteger.Pow(2,k)*(2*x-1)/3; cases++; if(mn[1]!=want) bad++; }
    Console.WriteLine($"H_k(x,1) = 2^k (2x-1)/3 for x = 2 mod 3: {cases} cases (x<=3000, k<=10), failures {bad}"); }
}
