using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Elementary necessary condition for a synchronous meeting m<n, T^j(m)=T^j(n), A_j(m)<A_j(n): G_m > 3^(b-a) G_n >= 3.
class P {
 static void Main(){
  // 1. identity y*2^j = m*3^a*G_m : test on fibres
  int bad=0,tested=0; for(int y=1;y<=120;y++){ var cur=new List<(BigInteger x,int a)>{(y,0)}; int j=9; for(int i=0;i<j;i++){ var nx=new List<(BigInteger,int)>(); foreach(var (z,a) in cur){ nx.Add((2*z,a)); if(z%3==2) nx.Add(((2*z-1)/3,a+1)); } cur=nx; }
    foreach(var (m,a) in cur){ // forward orbit with exact G
      BigInteger x=m; BigInteger gn=1,gd=1; int odd=0; for(int i=0;i<j;i++){ if(x%2==1){ gn*=3*x+1; gd*=3*x; odd++; x=(3*x+1)/2; } else x/=2; } tested++; if(x!=y||odd!=a|| (BigInteger)y*BigInteger.Pow(2,j)*gd != m*BigInteger.Pow(3,a)*gn) bad++; } }
  Console.WriteLine("identity 2^j y = m 3^a G_m on all depth-9 fibres of y<=120: tested "+tested+", failures "+bad);
  // 2. minimal a with (10/9) prod_{k<a} (1+1/(3 u_k)) > 3, u_k = k-th odd nonmultiple of 3 that is >=5 : 5,7,11,13,...
  BigInteger pn=10, pd=9; int a1=1; long u=5; int step=0; var seq=new List<long>(); bool found=false; int cnt=1; // cnt = number of inputs used so far (the 3)
  while(!found){ // next u
    do{ u+=2; }while(u%3==0); if(cnt==1) u=5; // first after 3 is 5
    pn*=3*u+1; pd*=3*u; cnt++; var g=BigInteger.GreatestCommonDivisor(pn,pd); if(cnt%256==0){pn/=g;pd/=g;} if(pn>3*pd){ found=true; Console.WriteLine("minimal number of odd inputs a with max product > 3: a = "+cnt+" (last input "+u+")"); // check previous fails
      } if(cnt>200000) break; }
  // double-check with logs
  double lg=Math.Log(10.0/9); long uu=3; int c2=1; long last=0; while(lg<=Math.Log(3.0)){ do{ uu+=2; }while(uu%3==0||uu<5); lg+=Math.Log(1+1.0/(3*uu)); c2++; last=uu; } Console.WriteLine("log check: a = "+c2+" (last input "+last+")");
  // also exact check that a-1 inputs are not enough
  { BigInteger qn=10,qd=9; long v=3; int c=1; while(c<cnt-1){ do{ v+=2; }while(v%3==0||v<5); qn*=3*v+1; qd*=3*v; c++; } Console.WriteLine("with "+(cnt-1)+" inputs the maximal product is <= 3: "+(qn<=3*qd)); }
 }}
