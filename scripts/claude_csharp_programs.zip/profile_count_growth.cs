using System;
using System.Collections.Generic;
// Empirical growth of the number P(n) of distinct first-return words active at threshold n (all returns, positive or not), compared with ChatGPT's theorem scale n^gamma/(ln n)^(3/2), gamma=H2(log2/log3)~0.950.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    double q=Math.Log(2)/Math.Log(3); double gam=-q*Math.Log(q,2)-(1-q)*Math.Log(1-q,2); Console.WriteLine($"gamma=H2(q)={gam:F5}");
    foreach(long n0 in new long[]{1001,2001,4001,8001,16001,32001,65535,131071,262143}){ long n=n0|1; long H=(4*n-2)/3; var seen=new HashSet<ulong>(); long returns=0, sources=0;
      for(long u=n;u<=H;u+=2){ sources++; long x=u; ulong h=1469598103934665603UL; int g=0; bool ret=false; for(int step=0;step<100000;step++){ int e; x=A(x,out e); g++; h=(h^(ulong)e)*1099511628211UL; if(x<=H){ ret=x>=n; break; } }
        if(!ret) continue; returns++; seen.Add(h^((ulong)g<<56)); }
      double pred=Math.Pow(n,gam)/Math.Pow(Math.Log(n),1.5); Console.WriteLine($"n={n}: sources {sources}, with a first return {returns}, distinct words P(n)={seen.Count}, P/(n^gamma/ln^1.5)={seen.Count/pred:F3}, P/sources={(double)seen.Count/sources:F3}");
    }
  }
}
