using System;
using System.Collections.Generic;
// ChatGPT 190057: C4 = {first returns with gap g<=10} U {first returns with at most four resets (exponents>=2)}. Compute for every odd n<=NMAX
//   B_C4(n) = sum over distinct words p in C4 with c(p)>0 of c(p)/(b_p+5)  (b_p = least source),
//   S_C4(n) = sum over EVERY genuine source u whose first-return word is in C4 and c>0 of c/(u+5).
// Claim: exact finite maximum 17741/439425 = 0.040373... at n=91 (genuine B and S sums in the verified range); analytic bound < 9/125 = 0.072.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=65535; double bestB=0,bestS=0; long nB=0,nS=0; double B91=0,S91=0;
    for(long n=3;n<=NMAX;n+=2){ long H=(4*n-2)/3; var seen=new HashSet<ulong>(); double B=0,S=0;
      for(long u=n;u<=H;u+=2){ long x=u; ulong h=1469598103934665603UL; int g=0,resets=0; double G=1.0; bool ret=false;
        for(int step=0;step<100000;step++){ G*=1.0+1.0/(3.0*x); int e; x=A(x,out e); g++; if(e>=2) resets++; h=(h^(ulong)e)*1099511628211UL; if(x<=H){ ret = x>=n; break; } }
        if(!ret) continue; if(!(g<=10 || resets<=4)) continue;
        double rho=G*(1.0+5.0/x)/(1.0+5.0/u); double c=(u+5)*(rho-1); if(c<=0) continue; S+=c/(u+5); ulong key=h^((ulong)g<<56); if(seen.Add(key)) B+=c/(u+5); }
      if(n==91){B91=B;S91=S;} if(B>bestB){bestB=B;nB=n;} if(S>bestS){bestS=S;nS=n;} }
    Console.WriteLine($"odd n<=65535: max B_C4 = {bestB:F9} at n={nB}; max S_C4 = {bestS:F9} at n={nS}; B(91)={B91:F9}, S(91)={S91:F9}; claimed 17741/439425={17741.0/439425:F9}; 9/125={9.0/125}");
  }
}
