using System;
using System.Collections.Generic;
using System.Numerics;
// N_k(N)/N for N = 2^a 3^b: values compared across two N to detect an exact limiting density d_k.
class P {
  static long[] Run(long N, int K) {
    var res = new long[K + 1]; var V = new long[N]; for (long i = 0; i < N; i++) V[i] = i + 1; int cnt = (int)N;
    var hs = new HashSet<long>(cnt);
    for (int k = 1; k <= K; k++) {
      hs.Clear(); int m = 0;
      for (int i = 0; i < cnt; i++) { long x = V[i]; long y = (x & 1) == 1 ? (3 * x + 1) / 2 : x / 2; if (k == 1) { } if (hs.Add(y)) V[m++] = y; }
      // V now holds f(k+1); record size of f(k) before update:
      res[k] = cnt; cnt = m;
    }
    return res;
  }
  static void Main(string[] a) {
    int K = int.Parse(a[0]); long N1 = (1L << 10) * 729, N2 = (1L << 11) * 2187;
    var r1 = Run(N1, K); var r2 = Run(N2, K);
    for (int k = 1; k <= K; k++) {
      var g1 = BigInteger.GreatestCommonDivisor(r1[k], N1); var g2 = BigInteger.GreatestCommonDivisor(r2[k], N2);
      Console.WriteLine($"k={k,2}: N_k/N = {r1[k]}/{N1} = {(BigInteger)r1[k] / g1}/{(BigInteger)N1 / g1}   |   {r2[k]}/{N2} = {(BigInteger)r2[k] / g2}/{(BigInteger)N2 / g2}   {(r1[k] * N2 == r2[k] * N1 ? "EQUAL" : "differ")}");
    }
  }
}
