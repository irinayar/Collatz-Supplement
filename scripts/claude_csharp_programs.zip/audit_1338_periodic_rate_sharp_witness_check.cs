using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
class P {
 static int V2(BigInteger x){int c=0;while(x%2==0){x>>=1;c++;}return c;}
 static void Main(){
  // (a) N/(3H) vs 1/48
  BigInteger n=(BigInteger.One<<71)+1, H=(4*n-2)/3; BigInteger N=BigInteger.Parse("196765270119568550570"); // count a=11 mod 16 in (H,2H]
  BigInteger lo=H+1, hi=2*H; BigInteger cnt=(hi-11)/16-(lo-1-11)/16; Console.WriteLine("count matches claimed: "+(cnt==N));
  // 1/48 - N/(3H) = (3H - 48N)/(144 H)
  BigInteger numr=3*H-48*N, den=144*H; var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(numr),den); Console.WriteLine("1/48 - N/(3H) = "+(numr/g)+"/"+(den/g)+" ; claimed 11/151115727451828646838288: "+((numr/g)==11 && (den/g)==BigInteger.Parse("151115727451828646838288"))+"; N/(3H) > 1/49: "+(N*49>3*H));
  // (b) sharp witness: smallest odd n with j=v2(n+1), N=T^j(n)=2 mod 4, first meeting with a smaller origin at exactly j+6
  int LIM=200000; int maxK=14; var x=new long[LIM+1]; for(int i=0;i<=LIM;i++) x[i]=i; var first=new int[LIM+1]; Array.Fill(first,-1);
  var jj=new int[LIM+1]; for(int m=3;m<=LIM;m+=2){ int j=0; long t=m+1; while(t%2==0){t/=2;j++;} jj[m]=j; }
  for(int k=0;k<=maxK;k++){ if(k>0) for(int i=1;i<=LIM;i++) x[i]=(x[i]%2==0)?x[i]/2:(3*x[i]+1)/2; var mo=new Dictionary<long,int>(LIM); for(int i=1;i<=LIM;i++) if(!mo.ContainsKey(x[i])) mo[x[i]]=i; for(int m=3;m<=LIM;m+=2) if(first[m]==-1 && mo[x[m]]<m) first[m]=k; }
  var wit=new List<string>(); for(int m=3;m<=LIM && wit.Count<4;m+=2){ int j=jj[m]; long Nn=m; for(int i=0;i<j;i++) Nn=(3*Nn+1)/2; if(Nn%4==2 && j+6<=maxK && first[m]==j+6){ // find the smaller origin
        long y=x[m]; wit.Add("n="+m+" (j="+j+", N="+Nn+") first meets a smaller origin at time "+(j+6)); } }
  Console.WriteLine("sharp witnesses (class 1^j01, first meeting at exactly j+6): "+string.Join("; ",wit));
  // (c) corrected periodic rate: (G-1)*min(2^E,3^a)^N bounded?
  var rnd=new Random(3); var words=new List<int[]>{ new[]{1}, new[]{1,1}, new[]{1,2}, new[]{2,1}, new[]{1,1,2}, new[]{2,3}, new[]{3}, new[]{1,3}, new[]{3,1,1}, new[]{1,1,1,2} };
  foreach(var W in words){ int a=W.Length,E=W.Sum(); BigInteger U=0,Pp=1; foreach(int e in W){ U=3*U+Pp; Pp*=BigInteger.Pow(2,e);} // after one repetition: 2^E y' = 3^a y + U
    // for N repetitions: U_N = U*(sum_{i<N} 3^{a i} 2^{E (N-1-i)})
    var res=new List<string>(); bool cycle=(U%(BigInteger.Pow(2,E)-BigInteger.Pow(3,a))==0 && U/(BigInteger.Pow(2,E)-BigInteger.Pow(3,a))>0);
    for(int NN=2;NN<=9;NN++){ BigInteger UN=0; for(int i=0;i<NN;i++) UN+=BigInteger.Pow(3,a*i)*BigInteger.Pow(2,E*(NN-1-i)); UN*=U; int EN=E*NN; BigInteger Mod=BigInteger.Pow(2,EN+1); BigInteger inv=BigInteger.ModPow(BigInteger.Pow(3,a*NN),Mod/2-1,Mod); BigInteger xx=(((BigInteger.Pow(2,EN)-UN)%Mod+Mod)%Mod*inv)%Mod; if(xx==0) xx=Mod; if(xx%2==0) continue;
      // simulate: check valuations and compute G
      BigInteger cur=xx; double lg=0; bool ok=true; var odds=new List<BigInteger>(); for(int r=0;r<NN&&ok;r++) foreach(int e in W){ odds.Add(cur); BigInteger t=3*cur+1; if(V2(t)!=e){ok=false;break;} cur=t>>e; }
      if(!ok){ res.Add("N="+NN+": cylinder mismatch"); continue; }
      BigInteger gn=1,gd=1; foreach(var o in odds){ gn*=3*o+1; gd*=3*o; } double Gm1=(double)((gn-gd))/ (double)gd; if(double.IsNaN(Gm1)) { var q=BigInteger.Divide((gn-gd)*BigInteger.Pow(10,40),gd); Gm1=(double)q/1e40; }
      double mn=Math.Min(Math.Pow(2,E),Math.Pow(3,a)); res.Add("N="+NN+": (G-1)*min^N="+(Gm1*Math.Pow(mn,NN)).ToString("G4")); }
    Console.WriteLine("W=("+string.Join(",",W)+") E="+E+" a="+a+(cycle?" [integer fixed point: cycle]":"")+": "+string.Join("  ",res.Take(8))); }
 }}
