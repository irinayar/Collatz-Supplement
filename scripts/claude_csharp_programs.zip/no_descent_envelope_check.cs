using System;
using System.Numerics;
// Independent check of the no-descent-aware envelope (Codex note 163752):
// for states z_0..z_J all >= n (before first descent), distinct:
//   3^6 n (n+J)^6 q_den^6 <= (3n+1)^6 (n+2J) q_num^6,  q = max_{i<=J} 3^{A_i}/2^i = q_num/q_den
// and also the sharper pointwise claims: z_i^6 <= n^6 q^6 (1+1/(3n))^6 (n+2A-2)/n  (A>=1).
class P {
  static void Main(string[] a) {
    long N = long.Parse(a[0]);
    long prefixes = 0, v1 = 0, v2 = 0, orbits = 0;
    for (long n0 = 2; n0 <= N; n0++) {
      BigInteger n = n0, z = n; BigInteger qn = 1, qd = 1; // q=3^A/2^i max, start 1
      BigInteger p3 = 1, p2 = 1; int A = 0; long i = 0; orbits++;
      while (true) {
        // state z_i with A odd inputs so far; q_J includes index i
        BigInteger cn = p3, cd = p2;
        if (cn * qd > qn * cd) { qn = cn; qd = cd; }
        if (i >= 1 && z >= n) {
          prefixes++;
          long J = i;
          BigInteger lhs = BigInteger.Pow(3, 6) * n * BigInteger.Pow(n + J, 6) * BigInteger.Pow(qd, 6);
          BigInteger rhs = BigInteger.Pow(3 * n + 1, 6) * (n + 2 * J) * BigInteger.Pow(qn, 6);
          if (lhs > rhs) v1++;
          if (A >= 1) {
            // z^6 * 3^6 * 2^(6i) * ... pointwise: z_i^6 <= n^6 (3^A/2^i)^6 (1+1/(3n))^6 (n+2A-2)/n  [uses actual 3^A/2^i]
            BigInteger l2 = BigInteger.Pow(z, 6) * BigInteger.Pow(p2, 6) * BigInteger.Pow(3 * n, 6) * n;
            BigInteger r2 = BigInteger.Pow(n, 6) * BigInteger.Pow(p3, 6) * BigInteger.Pow(3 * n + 1, 6) * (n + 2 * A - 2);
            if (l2 > r2) v2++;
          }
        }
        if (i >= 1 && z < n) break;       // descent: hypothesis ends
        if (z.IsEven) { z /= 2; p2 *= 2; }
        else { z = (3 * z + 1) / 2; p3 *= 3; p2 *= 2; A++; }
        i++;
        if (i > 5000) break;
      }
    }
    Console.WriteLine($"orbits {orbits}, pre-descent prefixes {prefixes}, filter violations {v1}, pointwise-envelope violations {v2}");
  }
}
