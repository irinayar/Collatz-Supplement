using System;
using System.Numerics;
// Check of ChatGPT 210229: H_k(x+tP,r)=H_k(x,r)+3tA, H_k(x+tP,r+1)=H_k(x,r+1)+2tA, P=3^(r+1), A=2^(k+r), hence D shifts by -tA. Own inverse-tree DFS for H.
class P {
  static int EMAX; static BigInteger[] mn; static long nodes;
  static void Dfs(BigInteger z,int ev,int od){ nodes++; if(ev==EMAX){ if(mn[od]==0||z<mn[od]) mn[od]=z; } if(ev<EMAX) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static BigInteger[] Hs(BigInteger x,int k){ EMAX=k; mn=new BigInteger[80]; nodes=0; Dfs(x,0,0); return mn; }
  static void Main(){
    long cells=0,bad=0,feasChange=0,dNeg=0,dTot=0;
    for(int k=0;k<=6;k++){ var cache=new System.Collections.Generic.Dictionary<long,BigInteger[]>(); BigInteger[] H(long x){ if(!cache.TryGetValue(x,out var a)){ a=Hs(x,k); cache[x]=(BigInteger[])a.Clone(); a=cache[x]; } return a; }
      for(int r=0;r<=6;r++){ long Pn=1; for(int i=0;i<r+1;i++) Pn*=3; long A=(1L<<(k+r));
        for(long x=1;x<=300;x++) for(int t=1;t<=2;t++){ long x2=x+t*Pn; var h1=H(x); var h2=H(x2); cells++;
          bool f0=h1[r]!=0, f1=h1[r+1]!=0, g0=h2[r]!=0, g1=h2[r+1]!=0; if(f0!=g0||f1!=g1){ feasChange++; bad++; continue; }
          if(f0) if(h2[r]!=h1[r]+3L*t*A) bad++; if(f1) if(h2[r+1]!=h1[r+1]+2L*t*A) bad++;
          if(f0&&f1){ dTot++; var d1=h1[r+1]-h1[r]; var d2=h2[r+1]-h2[r]; if(d2!=d1-t*A) bad++; if(d2<0) dNeg++; } } } }
    Console.WriteLine($"shift laws, k<=6, r<=6, x<=300, t=1,2: cells {cells}, failures {bad} (feasibility changes {feasChange}); pairs with both counts feasible {dTot}, of which D<0 after the shift {dNeg}");
    // illustrative example k=20, x=2 and x'=2+3^22
    EMAX=20; BigInteger xp=2+BigInteger.Pow(3,22); var a=Hs(2,20); var a2=(BigInteger[])a.Clone(); var b=Hs(xp,20); a=a2; BigInteger A20=BigInteger.Pow(2,41);
    Console.WriteLine($"k=20: H(2,21)={a[21]}, H(2,22)={a[22]}, D={a[22]-a[21]}; x'={xp}: H(x',21)={b[21]} (predicted {a[21]+3*A20}), H(x',22)={b[22]} (predicted {a[22]+2*A20}), D'={b[22]-b[21]} (predicted {a[22]-a[21]-A20})");
  }
}
