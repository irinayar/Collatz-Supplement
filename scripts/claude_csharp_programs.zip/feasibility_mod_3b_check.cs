using System;
using System.Collections.Generic;
// Check Codex K127 lemma: for fixed k,b>=0, feasibility of an origin with exactly k even and b odd steps ending at positive z depends only on z mod 3^b.
class P {
  static Dictionary<(int,int,long),bool> memo=new();
  static bool F(int k,int b,long z){ if(z<=0) return false; if(k==0&&b==0) return true; var key=(k,b,z); if(memo.TryGetValue(key,out var v)) return v;
    bool r=false; if(k>0 && F(k-1,b,2*z)) r=true; if(!r && b>0 && z%3==2 && F(k,b-1,(2*z-1)/3)) r=true; memo[key]=r; return r; }
  static void Main(){
    long checks=0,bad=0,feas=0;
    for(int b=0;b<=4;b++){ long m=1; for(int i=0;i<b;i++) m*=3; for(int k=0;k<=7;k++) for(long z=1;z<=600;z++){ bool f1=F(k,b,z), f2=F(k,b,z+m); checks++; if(f1) feas++; if(f1!=f2){bad++; Console.WriteLine($"FAIL k={k} b={b} z={z}");} } }
    Console.WriteLine($"periodicity checks {checks} (feasible {feas}), violations {bad}");
  }
}
