using System;
using System.Numerics;
using System.Collections.Generic;
// Independent replay of Codex's depth-42 counterexample (n = 251, endpoint 2) to P' and exact periodicity.
class P {
  static (BigInteger, int) Run(BigInteger x, int steps) { int odd = 0; for (int i = 0; i < steps; i++) { if (!x.IsEven) { x = (3 * x + 1) / 2; odd++; } else x /= 2; } return (x, odd); }
  static void Main() {
    int j = 42; BigInteger B = BigInteger.Pow(2, j); var (e251, a251) = Run(251, j); var (e2, a2) = Run(2, j);
    Console.WriteLine($"T^42(251) = {e251} with {a251} odd steps; T^42(2) = {e2} with {a2} odd steps");
    var counts = new SortedDictionary<int, List<int>>();
    for (int m = 1; m < 251; m++) { var (e, c) = Run(m, j); if (e == 2) { if (!counts.ContainsKey(c)) counts[c] = new List<int>(); counts[c].Add(m); } }
    foreach (var kv in counts) Console.WriteLine($"  smaller m with endpoint 2 and {kv.Key} odd steps: {kv.Value.Count}, least {kv.Value[0]}");
    Console.WriteLine($"  partner with 22 or 23 odd steps among m < 251: {(counts.ContainsKey(22) || counts.ContainsKey(23))}");
    BigInteger N = 251 + 3 * B; var (eN, aN) = Run(N, j);
    Console.WriteLine($"N = 251 + 3*2^42 = {N}: T^42(N) = {eN} (2 + 3^23 = {2 + BigInteger.Pow(3, 23)}), odd steps {aN}");
    // direct check that the least-origin claim is consistent: any m' < N with the same endpoint would have odd count 22 or 23 (Codex theorem, n >= B); test the shifted origins
    BigInteger m22 = N - 3 * B, m23 = N - B; var (x22, c22) = Run(m22, j); Console.WriteLine($"shifted origins: N-3B = {m22}: endpoint {x22}, odd {c22}; (these are 251 itself)");
  }
}
