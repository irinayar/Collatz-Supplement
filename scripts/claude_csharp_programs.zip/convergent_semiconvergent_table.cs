using System;
using System.Collections.Generic;
using System.Numerics;
// Convergents AND semiconvergents of log2 3 from above (2^L > 3^A) with the admissibility test c_max = A / (3 ln(2^L/3^A)) >= N.
static class P {
  static BigInteger S = BigInteger.Pow(10, 160);
  static BigInteger Atanh(BigInteger num, BigInteger den) { BigInteger x = num * S / den, x2 = x * x / S, term = x, sum = 0; for (int n = 1; term != 0; n += 2) { sum += term / n; term = term * x2 / S; } return sum; }
  static void Main(string[] args) {
    BigInteger ln2 = 2 * Atanh(1, 3), ln3 = 2 * Atanh(2, 4); // ln3 = 2 atanh(1/2)
    BigInteger a = ln3, b = ln2; var cf = new List<BigInteger>(); for (int i = 0; i < 70; i++) { BigInteger q = a / b; cf.Add(q); var r = a - q * b; a = b; b = r; if (b == 0) break; }
    double[] Ns = { Math.Pow(2, 68), 1e15, 1e12 };
    var found = new List<(BigInteger A, BigInteger L, string kind, double cmax)>();
    BigInteger h0 = 1, h1 = cf[0], k0 = 0, k1 = 1; // h_{-1}=1,k_{-1}=0 ; h_0 = a0, k_0 = 1
    BigInteger hm = h0, km = k0; // previous convergent (n-1)
    BigInteger hn = h1, kn = k1; // current convergent n=0
    for (int n = 0; n < 50; n++) {
      BigInteger an1 = cf[n + 1];
      // semiconvergents between convergent n-1 and n+1: j*conv_n + conv_{n-1}, j = 1..a_{n+1}  (j = a_{n+1} gives convergent n+1)
      BigInteger jMax = an1 > 2000000 ? 2000000 : an1; // very large a_n: sample the beginning only (flagged)
      for (BigInteger j = 1; j <= (an1 > 400 ? 400 : an1); j++) { BigInteger p = j * hn + hm, q = j * kn + km; Test(p, q, j == an1 ? "convergent" : "semiconvergent", ln2, ln3, Ns, found); }
      if (an1 > 400) { BigInteger j = an1; BigInteger p = j * hn + hm, q = j * kn + km; Test(p, q, "convergent", ln2, ln3, Ns, found); }
      BigInteger hNext = an1 * hn + hm, kNext = an1 * kn + km; hm = hn; km = kn; hn = hNext; kn = kNext;
      if (kn > BigInteger.Pow(10, 17)) break;
    }
    foreach (var f in found) Console.WriteLine($"A={f.A}, L={f.L} ({f.kind}): max possible minimum A/(3 ln(2^L/3^A)) = {f.cmax:E3}");
  }
  static void Test(BigInteger p, BigInteger q, string kind, BigInteger ln2, BigInteger ln3, double[] Ns, List<(BigInteger, BigInteger, string, double)> found) {
    BigInteger diff = p * ln2 - q * ln3; if (diff <= 0) return; double epsLog = (double)diff / (double)BigInteger.Pow(10, 160); double cmax = (double)q / (3 * epsLog);
    if (cmax >= 2.9e20 && q < 3000000000000) found.Add((q, p, kind, cmax));
  }
}
