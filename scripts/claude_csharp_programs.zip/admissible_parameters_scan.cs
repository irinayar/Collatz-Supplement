using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
// For thresholds N: all A <= Amax with L = ceil(A log2 3) and  c <= f(A,L) = 1/(3(exp(ln(2^L/3^A)/A) - 1))  >=  N  (necessary for a cycle with minimum c >= N).
// First test d(A) = L - A log2 3 <= A*kappa with kappa = 1/(3 N ln 2) (this is the condition  ln(2^L/3^A) <= A/(3N), slightly stronger than f >= N: we then evaluate f exactly in double).
static class P {
  static BigInteger S = BigInteger.Pow(10, 80);
  static BigInteger Atanh(BigInteger num, BigInteger den) { BigInteger x = num * S / den, x2 = x * x / S, term = x, sum = 0; for (int n = 1; term != 0; n += 2) { sum += term / n; term = term * x2 / S; } return sum; }
  static void Main(string[] args) {
    BigInteger ln2 = 2 * Atanh(1, 3), ln3 = 2 * Atanh(2, 4); BigInteger two128 = BigInteger.Pow(2, 128); BigInteger alphaFrac = (ln3 * two128 / ln2) % two128; UInt128 a128 = (UInt128)alphaFrac;
    string[] names = { "1e2", "1e3", "1e4", "1e6", "1e9", "1e12", "1e15", "1e18", "1e20", "2^68" };
    BigInteger[] Ns = { BigInteger.Pow(10, 2), BigInteger.Pow(10, 3), BigInteger.Pow(10, 4), BigInteger.Pow(10, 6), BigInteger.Pow(10, 9), BigInteger.Pow(10, 12), BigInteger.Pow(10, 15), BigInteger.Pow(10, 18), BigInteger.Pow(10, 20), BigInteger.Pow(2, 68) };
    for (int t = 0; t < Ns.Length; t++) {
      BigInteger K = two128 * S / (3 * Ns[t] * ln2); UInt128 K128 = (UInt128)K; long found = -1; double dfound = 0;
      for (long hi = 1000; found < 0 && hi <= 200000000000; hi *= 4) {
        long lo = hi / 4 + 1; if (hi == 1000) lo = 1; int chunks = 64; long per = (hi - lo + 1 + chunks - 1) / chunks; var hits = new ConcurrentBag<(long A, double d)>();
        Parallel.For(0, chunks, c => { long A0 = lo + c * per, A1 = Math.Min(hi, lo + (c + 1) * per - 1); if (A0 > A1) return; UInt128 frac = (UInt128)((BigInteger)A0 * alphaFrac % two128); UInt128 thr = (UInt128)((BigInteger)A0 * K % two128);
          for (long A = A0; A <= A1; A++) { UInt128 d = (UInt128)0 - frac; if (d != 0 && d < thr) hits.Add((A, (double)d / 3.4028236692093846e38)); frac += a128; thr += K128; } });
        if (!hits.IsEmpty) { var best = hits.OrderBy(h => h.A).First(); found = best.A; dfound = best.d; }
      }
      if (found < 0) { Console.WriteLine($"N = {names[t]}: none up to 2e11"); continue; }
      double Ld = Math.Ceiling(found * Math.Log2(3.0)); // approximate L (double is fine up to ~1e15)
      double epsLog = dfound * Math.Log(2); double f = 1.0 / (3 * (Math.Exp(epsLog / found) - 1));
      Console.WriteLine($"N = {names[t]}: smallest A = {found}, L = about {Ld:F0}, L - A log2 3 = {dfound:E3}, f(A,L) = {f:E3}");
    }
  }
}
