using System;
using System.Collections.Generic;
using System.Numerics;
// Which parameters (A, L) (A odd steps, L steps) remain possible for a cycle if no cycle has an element <= N?
// Exact facts used: prod_{odd j}(1 + 1/(3 x_j)) = 2^L / 3^A, hence with eps = 2^L/3^A - 1:  A/(3 H) <~ eps <= A/(3 c)  (c = min element, H = max odd element)
// so a cycle with minimum c requires c <= A/(3 eps)  [more precisely (1+1/(3c))^A >= 2^L/3^A].
static class P {
  static BigInteger S = BigInteger.Pow(10, 140);
  static BigInteger Atanh(BigInteger num, BigInteger den) { // atanh(num/den) in fixed point
    BigInteger x = num * S / den, x2 = x * x / S, term = x, sum = 0; for (int n = 1; term != 0; n += 2) { sum += term / n; term = term * x2 / S; } return sum; }
  static BigInteger Ln(int a) => 2 * Atanh(a - 1, a + 1);
  static void Main(string[] args) {
    BigInteger ln2 = Ln(2), ln3 = Ln(3); // ln(2) via atanh(1/3) is ok since (2-1)/(2+1)
    // continued fraction of ln3/ln2 = log2 3
    BigInteger a = ln3, b = ln2; var cf = new List<BigInteger>(); for (int i = 0; i < 60; i++) { BigInteger q = a / b; cf.Add(q); var r = a - q * b; a = b; b = r; if (b == 0) break; }
    Console.WriteLine("CF of log2(3): " + string.Join(",", cf.GetRange(0, 40)));
    BigInteger h0 = 1, h1 = cf[0], k0 = 0, k1 = 1; // convergents p/q = L/A
    double N = Math.Pow(2, 68);
    Console.WriteLine("convergents L/A with 2^L > 3^A (from above): A, L, eps = 2^L/3^A - 1, max possible minimum A/(3 eps)");
    for (int i = 1; i < 30; i++) { BigInteger p = cf[i] * h1 + h0, q = cf[i] * k1 + k0; h0 = h1; h1 = p; k0 = k1; k1 = q; // p/q = L/A
      // eps' = L - A log2 3 = (L ln2 - A ln3)/ln2
      BigInteger diff = p * ln2 - q * ln3; // = ln2 * eps'
      if (diff <= 0) continue; // below: 3^A > 2^L, impossible
      double epsLog = (double)diff / (double)S; // = ln(2^L/3^A) = ln(1+eps)
      double eps = Math.Exp(epsLog) - 1; if (epsLog < 1e-12) eps = epsLog; double A = (double)q;
      double maxc = A / (3 * eps);
      Console.WriteLine($"A={q}, L={p}: ln(2^L/3^A) = {epsLog:E3}; max possible min element A/(3 eps) = {maxc:E3}   {(maxc >= N ? "ALLOWED if c > 2^68" : "excluded if c > 2^68")}");
    }
  }
}
