using System;
using System.Numerics;
class P {
  static BigInteger S(BigInteger x)=> x.IsEven? x/2 : (3*x+1)/2;
  static BigInteger Sk(BigInteger x,int k){ for(int i=0;i<k;i++) x=S(x); return x; }
  static string Bits(BigInteger x,int len){ var sb=new System.Text.StringBuilder(); for(int i=0;i<len;i++){ sb.Append(x.IsEven?'0':'1'); x=S(x);} return sb.ToString(); }
  static void Main(){
    int[] c=new int[8]; int firstFail=-1;
    for(int h=0;h<200;h++){
      BigInteger n=585447+5308416*h, m=462575+4194304*h;
      BigInteger a=Sk(n,5), b=Sk(m,11), a15=Sk(n,15), b21=Sk(m,21);
      bool nodesc=true; BigInteger q=n; for(int i=0;i<15;i++){ q=S(q); if(q<n) nodesc=false; }
      bool visits=false; BigInteger p=m; for(int i=0;i<11;i++){ if(p==n) visits=true; p=S(p); }
      if(a!=b) c[0]++; if(a15!=b21) c[1]++; if(!nodesc) c[2]++; if(visits) c[3]++; if(!(m<n)) c[4]++; if(Bits(n,5)!="11101") c[5]++; if(Bits(m,11)!="11110111100") c[6]++; { BigInteger hh=h; if(a!=1481915+13436928*hh || a15!=3164993+28697814*hh) c[7]++; }
      if(a!=b && firstFail<0) firstFail=h; }
    Console.WriteLine("failures by condition [S5=S11, S15=S21, source descent, target visits n, m<n, P bits, Q bits, endpoint formulas]: "+string.Join(",",c)+$"; first h with S5!=S11: {firstFail}");
    BigInteger n1=585447+5308416, m1=462575+4194304; Console.WriteLine($"h=1: S5(n)={Sk(n1,5)} S11(m)={Sk(m1,11)} bits n:{Bits(n1,5)} m:{Bits(m1,11)}; mod: n1 mod 2^16={n1%65536}, m1 mod 2^11={m1%2048}");
    BigInteger n0=585447, m0=462575; Console.WriteLine($"h=0: S5(n)={Sk(n0,5)} S11(m)={Sk(m0,11)} bits n:{Bits(n0,5)} m:{Bits(m0,11)}");
  }
}
