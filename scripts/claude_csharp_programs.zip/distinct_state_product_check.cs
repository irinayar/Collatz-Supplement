using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of the distinct-state product envelope (Codex note 162713):
// before the first repeated state, at every strict height record z_j (A_j>=1):
//   3^(6A) (4n)^6 (2A-1) >= 3^6 (j+1)^6 2^(6j)   (exact integers)
// and P_j <= Q_A (log check).
class P {
  static void Main(string[] a) {
    long N = long.Parse(a[0]);
    long records = 0, viol = 0, prodViol = 0, orbits = 0, states = 0;
    double minSlack = 1e18; BigInteger argMin = 0;
    var starts = new List<BigInteger>();
    for (long n = 1; n <= N; n++) starts.Add(n);
    starts.Add(BigInteger.Parse("4064460795")); starts.Add(BigInteger.Parse("18839651253368551"));
    starts.Add(BigInteger.Parse("2361183272358587138047"));
    foreach (var n in starts) {
      orbits++;
      var seen = new HashSet<BigInteger>();
      BigInteger z = n, mx = 0; int A = 0; double lnP = 0; long j = 0;
      var odds = new List<BigInteger>();
      while (!seen.Contains(z)) {
        seen.Add(z); states++;
        if (j >= 1 && z > mx && A >= 1) {
          records++;
          BigInteger lhs = BigInteger.Pow(3, 6 * A) * BigInteger.Pow(4 * n, 6) * (2 * A - 1);
          BigInteger rhs = BigInteger.Pow(3, 6) * BigInteger.Pow(j + 1, 6) * BigInteger.Pow(2, (int)(6 * j));
          if (lhs < rhs) viol++;
          double sl = (BigInteger.Log(lhs) - BigInteger.Log(rhs)) / 6.0 / Math.Log(3);
          if (sl < minSlack) { minSlack = sl; argMin = n; }
          double lnQ = 0; for (int r = 1; r <= A; r++) lnQ += Math.Log((6.0*r-2)/(6.0*r-3));
          if (lnP > lnQ + 1e-9) prodViol++;
        }
        if (z > mx) mx = z;
        if (!z.IsEven) { lnP += Math.Log(1.0 + 1.0 / (3.0 * (double)z)); A++; z = (3 * z + 1) / 2; }
        else z = z / 2;
        j++;
      }
    }
    Console.WriteLine($"orbits {orbits}, states {states}, records checked {records}, exact-inequality violations {viol}, product-envelope violations {prodViol}");
    Console.WriteLine($"min slack (log_3 units of D_j beyond the bound) {minSlack:F3} at n={argMin}");
  }
}
