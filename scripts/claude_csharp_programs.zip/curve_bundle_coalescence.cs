using System;
using System.Collections.Generic;
// Bundle of curves f_n(k) = T^{k-1}(n), n = 1..N (k = 1 is the start).  V_k = {f_n(k)} (distinct values), N_k = |V_k|.
// Records: N_k/N, maximum value, coalescence count c_k = N_k - N_{k+1}, check c_k = #{odd x in V_k : 3x+1 in V_k},
// largest L with [1,L] subset V_k, and the first k with N_k = 2.
class P {
  static void Main(string[] a) {
    long N = long.Parse(a[0]);
    var V = new List<long>((int)N); for (long n = 1; n <= N; n++) V.Add(n);
    int[] show = {1,2,3,4,5,6,8,10,15,20,30,40,60,80,100,150,200,300,400};
    var hs = new HashSet<long>();
    for (int k = 1; ; k++) {
      long mx = 0; foreach (var x in V) if (x > mx) mx = x;
      hs.Clear(); foreach (var x in V) hs.Add(x);
      long pairs = 0; foreach (var x in V) if ((x & 1) == 1 && hs.Contains(3 * x + 1)) pairs++;
      long L = 0; while (hs.Contains(L + 1)) L++;
      var W = new List<long>(V.Count); var h2 = new HashSet<long>();
      foreach (var x in V) { long y = (x & 1) == 1 ? (3 * x + 1) / 2 : x / 2; if (h2.Add(y)) W.Add(y); }
      long c = V.Count - W.Count;
      if (Array.IndexOf(show, k) >= 0 || V.Count <= 4)
        Console.WriteLine($"k={k,4} N_k={V.Count,9} N_k/N={(double)V.Count / N:F5} max={mx,14} coalesced_next={c,8} pairs(x,3x+1)={pairs,8} [1..L] full, L={L,7} ratio N_{{k+1}}/N_k={(double)W.Count / V.Count:F4}");
      if (c != pairs) Console.WriteLine($"  MISMATCH at k={k}: coalescences {c} vs pair count {pairs}");
      if (V.Count <= 2) break;
      V = W;
    }
  }
}
