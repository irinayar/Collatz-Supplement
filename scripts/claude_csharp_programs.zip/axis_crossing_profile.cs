using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long words = 0, mismatch = 0, negProfile = 0, maxAboveK = 0, degenerate = 0;
    var byK = new SortedDictionary<int, (long cnt, int wmaxMax, int wminMin, long neg)>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        int k = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) k++; if (k < 1) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2;
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        // winding by angle sums
        double sumAng = 0; bool deg = false;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; sumAng += a; }
        if (deg) { degenerate++; continue; }
        int wind = (int)Math.Round(sumAng / (2 * Math.PI));
        // axis crossings of cross edges (upper<->lower): abscissa x0 ; peak edge (upper->lower) counts -1 for clockwise? define W(xi)= #valley x0<=xi - #peak x0<=xi
        var ev = new List<(double x0, int s)>();
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; bool upI = e[i], upJ = e[j]; if (upI == upJ) continue; double ya = Math.Abs(py[i]), yb = Math.Abs(py[j]); double x0 = (px[i] * yb + px[j] * ya) / (ya + yb); ev.Add((x0, upI ? -1 : +1)); }
        // endpoints c and H lie on the axis: treat edges touching them specially: if an endpoint is on the axis (y=0) the 'cross' classification by letters may not be a true crossing; handle by general segment test instead
        // general: count signed crossings of the axis by every edge using signs of y
        int Wc = 0; var ev2 = new List<(double x0, int s)>();
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double y1 = py[i], y2 = py[j]; if ((y1 > 0 && y2 < 0) || (y1 < 0 && y2 > 0)) { double x0 = px[i] + (px[j] - px[i]) * (0 - y1) / (y2 - y1); ev2.Add((x0, y1 > 0 ? -1 : +1)); } }
        // edges through the axis endpoints (c or H) with y=0: ignore for interior points
        ev.Sort((p, q) => p.x0.CompareTo(q.x0)); int cur = 0, mx = 0, mn = 0; int atMid = 0; foreach (var t in ev) { if (t.x0 <= m) atMid += t.s; cur += t.s; mx = Math.Max(mx, cur); mn = Math.Min(mn, cur); }
        int formula = -atMid; // w = -W(m)
        words++; if (formula != wind) mismatch++;
        if (mn < 0) negProfile++; if (mx > k) maxAboveK++;
        byK.TryGetValue(k, out var v); byK[k] = (v.cnt + 1, Math.Max(v.wmaxMax, mx), Math.Min(v.wminMin, mn), v.neg + (mn < 0 ? 1 : 0));
      }
    }
    Console.WriteLine($"words {words} (degenerate skipped {degenerate}); winding from angle sums vs signed axis-crossings left of the centre: mismatches {mismatch}");
    Console.WriteLine($"words whose axis profile W(xi) is negative somewhere: {negProfile}; words with max W > k: {maxAboveK}");
    foreach (var kv in byK.Where(kv => kv.Key <= 8)) Console.WriteLine($"k={kv.Key}: words {kv.Value.cnt}, max over words of max_xi W = {kv.Value.wmaxMax}, min over words of min_xi W = {kv.Value.wminMin}, words with negative profile {kv.Value.neg}");
  }
}
