using System;
using System.Numerics;
static class P {
  static void Main() {
    int sols = 0, windowHits = 0; double minRel = 1e9; int minA = 0;
    for (int A = 1; A <= 3000; A++) {
      BigInteger p3 = BigInteger.Pow(3, A), p2 = BigInteger.Pow(2, A);
      for (int B = 1; B <= 6 * A + 5; B++) {
        BigInteger D = (BigInteger.One << (A + B)) - p3; if (D <= 0) continue;
        if (D > (BigInteger.One << (A + B))) break;
        BigInteger q = (BigInteger.One << B) - 1;            // need x+1 = 2^A (2^B-1)/D integer
        if (D <= q) { windowHits++; }
        if (q % D == 0 && (p3 - p2) % D == 0) { sols++; Console.WriteLine($"solution A={A} B={B} x={(p3 - p2) / D}"); }
        if (D > (BigInteger.One << (B + 2))) break;           // beyond window for this A, larger B only increases D
      }
    }
    Console.WriteLine($"A<=3000: one-ascent-run cycles 1^A 0^B with integer x: {sols}; (A,B) with 1<=D<=2^B-1: {windowHits}");
  }
}
