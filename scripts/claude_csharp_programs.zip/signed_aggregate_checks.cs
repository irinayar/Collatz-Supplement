using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Checks for ChatGPT "Collatz_Signed_Aggregate_and_Global_Bridge" (19:12): (1) first unit-phase gate after 2 or 3 complete runs; (2) fixed unit gate multiplicity maximum over 702 depths (open arc log2(4/3));
// (3) scalar bound F(x)=x*sum_{v>=0, 2^v>=x(v+1)(v+2)} 2^-v <= 2/3; (4) arithmetic: 9911/18e6 = 1/9000+1758/4e6, 8143/18e6 = 1003/1e6 - 9911/18e6, 3^63<2^100, g_p bound, 6n>59.
class P { static void Main(){
 // (1) all odd u up to 3e6 (phase gate by exact rationals with doubles checked against margin)
 long cnt2=0,cnt3=0,other=0,total=0; double minMargin=1;
 for(long u=3; u<=3000001; u+=2){ long x=u; double C=0, lam=1.0; // q = C/3^g as running sum of Lambda/3 ; Lambda_g = 2^E/3^g
   double q=0; int runs=0; int g=0; double Lam=1.0; bool done=false; int steps=0;
   while(steps<400){ long t=3*x+1; int e=0; while((t&1)==0){t>>=1;e++;} q+=Lam/3; Lam=Lam*Math.Pow(2,e)/3; g++; x=t; steps++; if(e>=2){ runs++; if(q>1.0){ if(runs==2)cnt2++; else if(runs==3)cnt3++; else other++; total++; minMargin=Math.Min(minMargin,Math.Abs(q-1.0)); done=true; break; } } if(x==1) break; }
 }
 Console.WriteLine($"(10) first run boundary with phase>1: after 2 runs {cnt2}, after 3 runs {cnt3}, other {other} (total {total}); min |q-1| = {minMargin:E2}");
 // (2) points j*alpha mod 1 for j=0..701 in an open arc of length w
 double al=Math.Log(3,2)%1.0, w=Math.Log(4.0/3,2); int N=702; var th=new double[N]; for(int j=0;j<N;j++) th[j]=(j*al)%1.0; int best=0; double gapmin=1;
 for(int i=0;i<N;i++){ int c=0; for(int j=0;j<N;j++){ double d=(th[j]-th[i]+1.0)%1.0; if(d<w-1e-9) c++; double gp=Math.Abs(d-w); if(gp>1e-9&&gp<gapmin) gapmin=gp; } if(c>best) best=c; }
 Console.WriteLine($"(16) max points among 702 consecutive depths in an open arc of width log2(4/3): {best} (claimed 292); nearest non-tie margin {gapmin:E2}");
 // 22a+min(22,ceil(r/2)) for 702
 Console.WriteLine($"linear capacity 22*13+min(22,ceil(13/2)) = {22*13+Math.Min(22,7)}");
 // (3) F(x)
 double maxF=0, argx=0; for(double lx=-12; lx<=12; lx+=0.0005){ double x=Math.Exp(lx); double s=0; for(int v=0; v<200; v++){ if(Math.Pow(2,v)>=x*(v+1)*(v+2)) s+=Math.Pow(2,-v); } double F=x*s; if(F>maxF){maxF=F;argx=x;} }
 Console.WriteLine($"max over x of F(x) = {maxF:F6} at x={argx:F5} (claimed <= 2/3 = {2.0/3:F6})");
 // (4) arithmetic
 BigInteger a=1*18000000/9000 + (BigInteger)1758*18000000/4000000; Console.WriteLine($"1/9000+1758/(4e6) in 1/18e6 units = {a} (claimed 9911): {a==9911}");
 BigInteger b=1003*18/1 - 9911; Console.WriteLine($"1003/1e6 - 9911/18e6 in 1/18e6 units = {1003L*18-9911} (claimed 8143): {1003L*18-9911==8143}");
 Console.WriteLine($"3^63<2^100: {BigInteger.Pow(3,63)<BigInteger.Pow(2,100)}; 2801375/3969 = {2801375.0/3969:F4} < 706; (1+100/63)*log2(4/3*2^272)+1 = {(1+100.0/63)*(272+Math.Log(4.0/3,2))+1:F4}");
 Console.WriteLine($"5(14n-15)>16(4n-1) iff 6n>59: n=10 -> {5*(14*10-15)>16*(4*10-1)}; n=9 -> {5*(14*9-15)>16*(4*9-1)}");
}}
