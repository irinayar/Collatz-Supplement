using System; using System.Numerics;
// Exact check of the payment-reassignment arithmetic: eta_exact, C_GTR, xi, and the sufficiency chain to Z < Y_* + alpha P/n.
class P { struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator-(F x,F y)=>new F(x.n*y.d-y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static F operator/(F x,F y)=>new F(x.n*y.d,x.d*y.n);
  public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d; public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public override string ToString()=>n+"/"+d;
  public string Dec(int dig){ BigInteger q=n*BigInteger.Pow(10,dig)/d; return q.ToString().PadLeft(dig+1,'0'); } }
 static F Fr(BigInteger a,BigInteger b)=>new F(a,b);
 static void Main(){
  F Ystar=Fr(116073,3904000), alpha=Fr(4899,3904), cstar=Fr(BigInteger.Parse("620751769493359576"),BigInteger.Parse("1180591620717411303425")); BigInteger n0=(BigInteger.One<<71)+1;
  F xi=cstar*(Fr(2,1)-Fr(4,3)*alpha+alpha/(Fr(3,1)*Fr(n0,1)));
  F C8=Fr(BigInteger.Parse("7618091890243831687161"),BigInteger.Parse("272394937772592332800000")); F CG=C8+Fr(33,1048576)+Fr(3,2621440);
  Console.WriteLine("C_GTR = "+CG+" (claimed 7626976231361521447161/272394937772592332800000: "+(CG.n==BigInteger.Parse("7626976231361521447161")&&CG.d==BigInteger.Parse("272394937772592332800000"))+")");
  F eta=Ystar-CG-Fr(557,1000000)-xi-Fr(149,1000000000);
  Console.WriteLine("xi = 0."+xi.Dec(25).Substring(1)+"; eta_exact = 0."+eta.Dec(23).Substring(1)+" (claimed 0.00100311185630820322...); > 1003/10^6: "+(eta>Fr(1003,1000000)));
  Console.WriteLine("2-4*alpha/3 > 0: "+(Fr(2,1)-Fr(4,3)*alpha>Fr(0,1))+" ("+(Fr(2,1)-Fr(4,3)*alpha)+")");
  F tot=CG+Fr(557,1000000)+Fr(149,1000000000)+xi+Fr(8143,18000000)+Fr(9911,18000000); Console.WriteLine("C_GTR+557/10^6+149/10^9+xi+8143/18e6+9911/18e6 < Y_*: "+(tot<Ystar)+" ; margin = "+(Ystar-tot).Dec(25));
  Console.WriteLine("1003/10^6-9911/18e6 = "+(Fr(1003,1000000)-Fr(9911,18000000))+" ; (n-1)/(n+1)>1/15: ok for n>=2^71");
 }}
