using System;
using System.Numerics;
using System.Collections.Generic;
// Independent check of the canonical ternary residue structure (ChatGPT note 174754):
// for each length j, each word w realized by n in 1..2^j (the unique least representative r_w):
//   E_w = T^j(r_w);  U_w built from the word by the affine recursion (no n used);
//   claim: a>0 => 1 <= E_w < 3^a and E_w == U_w * (2^j)^-1 mod 3^a; a=0 => E_w = 1.
// Also count words with R <= j^2 and compare with the note's table.
class P {
  static void Main(string[] args) {
    int Jmax = int.Parse(args[0]); long bad = 0, words = 0;
    for (int j = 1; j <= Jmax; j++) {
      long cnt = 0; var seenWord = new HashSet<long>();
      long lim = 1L << j;
      for (long n = 1; n <= lim; n++) {
        long x = n; int a = 0; long wordbits = 0; BigInteger U = 0;
        for (int i = 0; i < j; i++) {
          if ((x & 1) == 1) { U = 3 * U + (BigInteger)(1L << i); a++; wordbits |= 1L << i; x = (3 * x + 1) / 2; }
          else x /= 2;
        }
        if (!seenWord.Add(wordbits)) { bad++; continue; }   // each word must have exactly one rep in 1..2^j
        words++;
        BigInteger E = x, p3 = BigInteger.Pow(3, a), p2 = BigInteger.Pow(2, j);
        if (a == 0) { if (E != 1) bad++; continue; }
        if (E < 1 || E >= p3) bad++;
        BigInteger inv = BigInteger.ModPow(p2, (p3 / 3) * 2 - 1, p3); // phi(3^a)=2*3^(a-1); inverse = p2^(phi-1)
        BigInteger R = (U * inv) % p3;
        if (R != E) bad++;
        if (R <= (BigInteger)j * j) cnt++;
      }
      if (seenWord.Count != (1L << j)) bad++;
      if (j >= 8) Console.WriteLine($"j={j}: words {seenWord.Count}, R<=j^2 (a>0): {cnt}");
    }
    Console.WriteLine($"words checked {words}, failures {bad}");
  }
}
