using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of ChatGPT 121333 / Codex 121945: the positive rational pseudo-origin words w_a = 00010110 (10)^(a-4) and 0 w_a.
class P {
  static (int, BigInteger) Num(List<int> w) { int b = 0; BigInteger V = 0; var pos = new List<int>(); for (int i = 0; i < w.Count; i++) if (w[i] == 1) { pos.Add(i); b++; } for (int h = 1; h <= b; h++) V += BigInteger.Pow(2, pos[h - 1]) * BigInteger.Pow(3, b - h); return (b, V); }
  static void Main() {
    int bad = 0, tests = 0;
    for (int a = 4; a <= 100; a++) {
      var w = new List<int> { 0, 0, 0, 1, 0, 1, 1, 0 }; for (int k = 0; k < a - 4; k++) { w.Add(1); w.Add(0); }
      int j = 2 * a; var (b, V) = Num(w); BigInteger B = BigInteger.Pow(2, j), p3b = BigInteger.Pow(3, b);
      bool ok = w.Count == j && b == a - 1 && V == B - 8 * BigInteger.Pow(3, a - 3) && (B - V) * 9 == 8 * p3b && V < B && V > B - p3b;
      for (int h = 0; h <= a - 3; h++) if (!((B - V) % BigInteger.Pow(3, h)).IsZero) ok = false;
      if (((B - V) % BigInteger.Pow(3, a - 2)).IsZero) ok = false;          // divisibility fails beyond a-3 (no integer origin)
      // prefixed word 0 w_a at depth J = 2a+1
      var w2 = new List<int> { 0 }; w2.AddRange(w); var (b2, V2) = Num(w2); BigInteger B2 = BigInteger.Pow(2, j + 1), p3b2 = BigInteger.Pow(3, b2);
      if (!(V2 == 2 * V && b2 == b && (B2 - V2) * 9 == 16 * p3b2)) ok = false;
      // genuine source n=2 and n=3 reach endpoint 1 at depth 2a+1 with a odd inputs
      foreach (long src in new long[] { 2, 3 }) { BigInteger x = src; int odd = 0; for (int s = 0; s < j + 1; s++) { if (!x.IsEven) { x = (3 * x + 1) / 2; odd++; } else x /= 2; } if (!(x == 1 && odd == a)) ok = false; }
      tests++; if (!ok) bad++;
    }
    Console.WriteLine($"rational pseudo-origin words, a = 4..100: {tests} tests, failures {bad} (checked: length 2a, b = a-1, V = 2^(2a) - 8*3^(a-3), origin 8/9 and 16/9, congruence mod 3^h for h <= a-3 and failure at h = a-2, sources 2 and 3 reach 1 with a odd steps)");
  }
}
