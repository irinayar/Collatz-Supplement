using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 151108 (five-even short-branch dominance in terms of q=2^(a-2)u) and of the takeover gap M_4 - S_5 = 8N/27 - 5, N = 64q-7.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long sCells=0,sBad=0,dom=0,domBad=0,gap3=0,gap3Bad=0,gap4=0,gap4Bad=0,s2Bad=0,bInf=0,bInfBad=0,mInf=0,mInfBad=0,take=0,takeBad=0,takeFormulaBad=0;
    for(int q=1;q<=6000;q++){ if(q%3==0) continue; BigInteger Q=q, N=64*Q-7;
      var S=new BigInteger[22]; var M=new BigInteger[22]; var B=new BigInteger[22];
      for(int s=2;s<=20;s++){ S[s]=H(18*Q-2,4,s); M[s]=H(12*Q-2,4,s-1); B[s]=H(8*Q-2,4,s-2); }
      if(S[2]!=128*Q-15||M[2]!=128*Q-24||B[2]!=128*Q-32) s2Bad++;
      for(int s=2;s<=20;s++){ BigInteger sf= (N%B3(s-2)==0)? B2(s-1)*N/B3(s-2)-1 : INF; sCells++; if(sf!=S[s]) sBad++;
        if(S[s]!=INF&&(M[s]!=INF||B[s]!=INF)){ dom++; BigInteger mn=INF; if(M[s]!=INF) mn=M[s]; if(B[s]!=INF&&(mn==INF||B[s]<mn)) mn=B[s]; if(!(S[s]>mn)) domBad++; }
        if(S[s]!=INF&&s==3){ gap3++; if(M[3]!=S[3]-7) gap3Bad++; } if(S[s]!=INF&&s==4){ gap4++; if(M[4]!=S[4]-5) gap4Bad++; }
        if(S[s]!=INF&&s>=3){ bInf++; if(B[s]!=INF) bInfBad++; } if(S[s]!=INF&&s>=5){ mInf++; if(M[s]!=INF) mInfBad++; } }
      if(S[5]!=INF){ take++; BigInteger g=M[4]-S[5]; if(!(g>0)) takeBad++; if(27*g!=8*N-135) takeFormulaBad++; }
      hm.Clear(); }
    Console.WriteLine($"q<=6000, s<=20: S formula {sCells} cells, failures {sBad}; s=2 values (128q-15/-24/-32) failures {s2Bad}; dominance {dom} overlaps, failures {domBad}; gap 7 at s=3: {gap3}, bad {gap3Bad}; gap 5 at s=4: {gap4}, bad {gap4Bad}; B infinite for s>=3 when S finite: {bInf}, bad {bInfBad}; M infinite for s>=5 when S finite: {mInf}, bad {mInfBad}; takeover cases (S_5 finite) {take}: M_4>S_5 failures {takeBad}, gap formula (8N/27-5) failures {takeFormulaBad}");
  }
}
