using System;
using System.Numerics;
// Two-range bound: odd m <= M1 stored (byte, upward quantised, scale 512); odd m in (M1, M2] computed on the fly by walking until the state is <= M1.
class P {
  static void Main(string[] args){
    long M1=long.Parse(args[0]), M2=long.Parse(args[1]); long N=(M1-1)/2+1; var q=new byte[N]; const double SC=512.0; byte maxq=0; var sw=System.Diagnostics.Stopwatch.StartNew();
    for(long m=3;m<=M1;m+=2){ long n=m; double p=1.0; while(n>=m){ if((n&1)==1){ p*=1.0+1.0/(3.0*n); n=(3*n+1)>>1; } else n>>=1; }
      int tz=BitOperations.TrailingZeroCount((ulong)n); n>>=tz; double gn= n==1?0.0 : (double)q[(n-1)/2]/SC; double g=p*(1.0+gn)*(1.0+1e-12); double qq=Math.Ceiling((g-1.0)*SC); if(qq>255) throw new Exception("overflow"); q[(m-1)/2]=(byte)qq; if(q[(m-1)/2]>maxq) maxq=q[(m-1)/2]; }
    double maxUp=1+maxq/SC; long arg=0; Console.WriteLine($"stage 1 done: odd m <= {M1}: bound {maxUp:F6} [{sw.ElapsedMilliseconds/1000}s]");
    for(long m=M1+2-((M1+1)%2==0?0:1);m<=M2;m+=2){ if((m&1)==0) continue; long n=m; double p=1.0; while(n>M1){ if((n&1)==1){ p*=1.0+1.0/(3.0*n); n=(3*n+1)>>1; } else n>>=1; }
      int tz=BitOperations.TrailingZeroCount((ulong)n); n>>=tz; double gn= n==1?0.0 : (double)q[(n-1)/2]/SC; double g=p*(1.0+gn)*(1.0+1e-12); if(g>maxUp){ maxUp=g; arg=m; } }
    Console.WriteLine($"all odd m <= {M2}: rigorous upper bound max Gtot <= {maxUp:F6} (largest found at m={arg}); below 3/2: {maxUp<1.5}; total {sw.ElapsedMilliseconds/1000}s");
  }
}
