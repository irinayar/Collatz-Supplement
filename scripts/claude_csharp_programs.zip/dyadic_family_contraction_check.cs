using System;
using System.Numerics;
// ChatGPT 204451 family u_i = 1+2h 3^i 4^(N-i) and ChatGPT 204900 contraction bound q=124659/131200 (runs with s<=5, descending, starts>=4097).
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Eq(Fr a,Fr b)=>a.n*b.d==b.n*a.d; public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static void Main(){
    long fam=0,famBad=0; foreach(int N in new[]{1,2,3,5,8,12,20,30}) foreach(int h in new[]{1,2,5,17}){ BigInteger u0=1+2*h*BigInteger.Pow(4,N); BigInteger cur=u0; Fr G=new Fr(1,1); bool ok=true;
        for(int i=0;i<N;i++){ BigInteger ui=1+2*h*BigInteger.Pow(3,i)*BigInteger.Pow(4,N-i); if(cur!=ui) ok=false; int s=V2(cur+1); BigInteger w=BigInteger.Pow(3,s)*(cur+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger v=w>>e; if(s!=1||e!=1) ok=false; // actual two accelerated steps
          BigInteger t1=(3*cur+1)/2, t2=t1/2; if(t1.IsEven==false||v!=t2) ok=false; G=G*new Fr(3*cur+1,3*cur); cur=v; }
        BigInteger uN=1+2*h*BigInteger.Pow(3,N); if(cur!=uN) ok=false; Fr formula=new Fr(BigInteger.Pow(4,N)*uN,BigInteger.Pow(3,N)*u0); if(!Fr.Eq(G,formula)) ok=false; Fr bound=new Fr(7,6); if(!Fr.Gt(bound,G)) ok=false; fam++; if(!ok) famBad++; }
    Console.WriteLine($"family u_i=1+2h 3^i 4^(N-i): {fam} (N,h) cases, failures {famBad}; example N=30,h=1: all {30} run starts > {1+2*BigInteger.Pow(3,30)}, G-1 = {(double)(Fr_G(30,1))}");
    // contraction lemma
    long cases=0,viol=0; double maxRatio=0; long au=0,av=0; BigInteger qn=124659,qd=131200;
    for(long u=4097;u<=100001;u+=2){ BigInteger U=u; int s=V2(U+1); BigInteger w=BigInteger.Pow(3,s)*(U+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger v=w>>e; if(s<=5&&v<U&&v>=4097){ cases++; if(v*qd>=qn*U) viol++; double r=(double)v/(double)u; if(r>maxRatio){ maxRatio=r; au=u; av=(long)v; } } }
    Console.WriteLine($"contraction lemma: descending runs with s<=5 and next start>=4097, odd u in [4097,100001]: {cases}; violations of v/u<124659/131200: {viol}; largest v/u = {maxRatio:F6} at {au}->{av} (q={(double)qn/(double)qd:F6})");
    double maj=Math.Exp(124659.0/(6541.0*4097)); Console.WriteLine($"exp(124659/(6541*4097)) = {maj:F8} < 1.005: {maj<1.005}; rational 26798477/26673818 = {26798477.0/26673818:F8}");
  }
  static double Fr_G(int N,int h){ double g=1; BigInteger u0=1+2*h*BigInteger.Pow(4,N); BigInteger uN=1+2*h*BigInteger.Pow(3,N); return (double)(BigInteger.Pow(4,N)*uN-BigInteger.Pow(3,N)*u0)/(double)(BigInteger.Pow(3,N)*u0); }
}
