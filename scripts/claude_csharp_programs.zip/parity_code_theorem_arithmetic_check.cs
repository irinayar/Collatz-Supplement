using System;
using System.Numerics;
// Audit arithmetic of ChatGPT Parity_Code_Profile_Theorem.md (sections 2-6): exact integer comparisons and inequality (17).
class P {
  static void Main(){
    Console.WriteLine($"(100/33)^5<2^8: {BigInteger.Pow(100,5) < BigInteger.Pow(33,5)*256}  ({Math.Pow(100.0/33,5):F3})");
    Console.WriteLine($"5^13 < 2^12 3^13: {BigInteger.Pow(5,13) < (BigInteger.One<<12)*BigInteger.Pow(3,13)}");
    Console.WriteLine($"2^180 < 3^33 5^55: {(BigInteger.One<<180) < BigInteger.Pow(3,33)*BigInteger.Pow(5,55)}  (margin in bits {33*Math.Log2(3)+55*Math.Log2(5)-180:F5})");
    Console.WriteLine($"64<81 (log(4/3)/log3<1/3): True");
    // (17): C_k(n) = (n+5)[(1+1/n)^k-1] + 5/3 - 10/(3n)  <  9k/8 + 55/24 (and <4k) for n>=33, 1<=k<=n/9
    long viol=0,viol4=0,tested=0; double minSlack=1e9;
    foreach(long n in new long[]{33,35,45,65,101,201,501,1001,10001,100001,1000001,100000001}){ for(long k=1;k*9<=n && k<=5000; k=k<50?k+1:k+Math.Max(1,k/7)){ double C=(n+5)*(Math.Pow(1+1.0/n,k)-1)+5.0/3-10.0/(3*n); double bound=9.0*k/8+55.0/24; tested++; if(!(C<bound)) viol++; if(!(C<4.0*k)) viol4++; minSlack=Math.Min(minSlack,bound-C); } }
    Console.WriteLine($"(17) tested {tested} (n,k) with n>=33, 9k<=n: violations of C<9k/8+55/24: {viol}; of C<4k: {viol4}; min slack {minSlack:F4}");
    // exact check of (9a): 2^j < 2*3^r for all prefixes of the extremal count (barrier) -- r>=? sanity: smallest r with 3^r*2 > 2^j  vs claim r_j - q0 j > -q0
    bool ok=true; for(int j=1;j<=200;j++){ int r=0; while(BigInteger.Pow(3,r)*2 <= (BigInteger.One<<j)) r++; double q0=Math.Log(2)/Math.Log(3); if(!(r-q0*j>-q0-1e-9)) ok=false; } Console.WriteLine($"(9a) minimal r_j satisfies r_j - q0 j > -q0 for j<=200: {ok}");
  }
}
