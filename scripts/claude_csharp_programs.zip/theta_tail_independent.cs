using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
// Independent computation of the stabilized residual fractions theta_T for the tail classes of the zero-tail families
// (k = 0: n = 1 mod 3^21 ; k = 2: 4n = 1 mod 3^21 ; k = 6: 64n = 1 mod 3^21), with NO assumption that they agree.
// theta_T(class) = fraction of 2-adic space (n uniform) NOT covered by: coefficient crossing within T steps, finite-ledger rules
// compatible with the ternary class (n = a mod 2^L 3^b is compatible iff a = rho mod 3^b, and then restricts n mod 2^L),
// C08 (1^k 00, k<=98), C85 meeting-only cylinders (mod 2^27).  Rules with modulus 2^L, L>60 are ignored (density < 1e-18).
class P {
  static ulong Mix(ref ulong s) { s += 0x9E3779B97F4A7C15UL; ulong z = s; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL; return z ^ (z >> 31); }
  static void Main(string[] a) {
    string root = a[0]; long MC = long.Parse(a[1]);
    var inv = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/targets_E18/counting_inventory_with_C110.json"))).RootElement;
    var rules = new List<(BigInteger r, BigInteger m, int L, int b)>();
    foreach (var z in inv.GetProperty("finite_ledger").EnumerateArray()) {
      BigInteger m = BigInteger.Parse(z.GetProperty("modulus").ToString()), r = BigInteger.Parse(z.GetProperty("residue").ToString()); int L = 0, b = 0; var t = m;
      while (t.IsEven) { t >>= 1; L++; } while ((t % 3).IsZero) { t /= 3; b++; } if (t != 1) throw new Exception("modulus has other prime factor: " + m);
      rules.Add((r, m, L, b)); }
    int B = 21; BigInteger q = BigInteger.Pow(3, B);
    BigInteger[] rho = new BigInteger[3]; int[] ks = { 0, 2, 6 };
    for (int i = 0; i < 3; i++) rho[i] = BigInteger.ModPow(BigInteger.Pow(2, ks[i]), 2 * BigInteger.Pow(3, B - 1) - 1, q); // rho = (2^k)^-1 mod 3^B
    // compatible binary conditions per class: list of (low-bit mask, residue)
    var comp = new List<(ulong mask, ulong res)>[3];
    for (int i = 0; i < 3; i++) { comp[i] = new List<(ulong, ulong)>(); int used = 0;
      foreach (var u in rules) { if (u.L > 60) continue; if (u.b > B) throw new Exception("ternary precision above B"); BigInteger pb = BigInteger.Pow(3, u.b);
        if (((u.r - rho[i]) % pb).IsZero) { comp[i].Add(((1UL << u.L) - 1, (ulong)(u.r % (BigInteger.One << u.L)))); used++; } }
      Console.WriteLine($"class k={ks[i]}: compatible finite rules {used} of {rules.Count}"); }
    var c85 = new bool[1 << 27];
    foreach (var c in JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/v2_audit/parent27_certificates.json"))).RootElement.GetProperty("certificates").EnumerateArray())
      if (c.GetProperty("meeting").ValueKind != JsonValueKind.Null && c.GetProperty("descent").ValueKind == JsonValueKind.Null) c85[c.GetProperty("n").GetInt64()] = true;
    var c08 = new List<(UInt128 r, UInt128 mask)>();
    for (int k = 1; k <= 98; k++) { BigInteger m = BigInteger.One << (k + 2), p3 = BigInteger.Pow(3, k), p2 = BigInteger.Pow(2, k);
      BigInteger r = (((-(p3 - p2) * BigInteger.ModPow(p3, (m >> 1) - 1, m)) % m) + m) % m; c08.Add(((UInt128)r, (UInt128)(m - 1))); }
    int[] minI = new int[101]; for (int aa = 0; aa <= 100; aa++) { BigInteger p = BigInteger.Pow(3, aa); int i = 0; while ((BigInteger.One << i) <= p) i++; minI[aa] = i; }
    var cc = c08.ToArray();
    // ---- T = 32 exhaustive over the low 32 bits
    long[] unc32 = new long[3]; long total32 = 1L << 32; int chunks = 2048; long per = total32 / chunks;
    Parallel.For(0, chunks, ci => {
      long[] l = new long[3];
      for (long n = ci * per; n < (ci + 1) * per; n++) {
        ulong x = (ulong)n; int ones = 0; bool cross = false;
        for (int i = 1; i <= 32; i++) { if ((x & 1) == 1) { ones++; x = (3 * x + 1) >> 1; } else x >>= 1; if (i >= minI[ones]) { cross = true; break; } }
        if (cross) continue;
        ulong un = (ulong)n; bool c8 = false; foreach (var u in cc) if (((UInt128)un & u.mask) == u.r) { c8 = true; break; }
        if (c8) continue; if (c85[un & ((1UL << 27) - 1)]) continue;
        for (int i = 0; i < 3; i++) { bool cov = false; foreach (var u in comp[i]) if ((un & u.mask) == u.res) { cov = true; break; } if (!cov) l[i]++; }
      }
      for (int i = 0; i < 3; i++) Interlocked.Add(ref unc32[i], l[i]);
    });
    BigInteger cl32 = BigInteger.Parse("69604644749247"), dn32 = BigInteger.Parse("9007199254740992");
    Console.WriteLine($"T=32 (exhaustive over 2^32 low-bit patterns): uncovered fraction k=0: {unc32[0]}/2^32 = {(double)unc32[0] / total32:E6}; k=2: {unc32[1]}/2^32 = {(double)unc32[1] / total32:E6}; k=6: {unc32[2]}; claimed theta_32 = {(double)cl32 / (double)dn32:E6}");
    Console.WriteLine($"   k=0 minus k=2 uncovered count: {unc32[0] - unc32[1]}");
    // ---- T = 100 Monte Carlo on random 128-bit n
    long[] unc100 = new long[3]; int thr = Environment.ProcessorCount * 4; long perT = MC / thr;
    Parallel.For(0, thr, ti => {
      ulong seed = 0xABCDEF1UL * (ulong)(ti + 7) + 12345UL; long[] l = new long[3];
      for (long s = 0; s < perT; s++) {
        UInt128 n = ((UInt128)Mix(ref seed) << 64) | Mix(ref seed); UInt128 x = n; int ones = 0; bool cross = false;
        for (int i = 1; i <= 100; i++) { if ((x & 1) == 1) { ones++; x = (x * 3 + 1) >> 1; } else x >>= 1; if (i >= minI[ones]) { cross = true; break; } }
        if (cross) continue; bool c8 = false; foreach (var u in cc) if ((n & u.mask) == u.r) { c8 = true; break; } if (c8) continue;
        ulong un = (ulong)n; if (c85[un & ((1UL << 27) - 1)]) continue;
        for (int i = 0; i < 3; i++) { bool cov = false; foreach (var u in comp[i]) if ((un & u.mask) == u.res) { cov = true; break; } if (!cov) l[i]++; }
      }
      for (int i = 0; i < 3; i++) Interlocked.Add(ref unc100[i], l[i]);
    });
    BigInteger cl100 = BigInteger.Parse("123530673091948493683226661"), dn100 = BigInteger.Parse("633825300114114700748351602688");
    long tot = perT * thr;
    Console.WriteLine($"T=100 (Monte Carlo, {tot} samples): k=0: {unc100[0]} ({(double)unc100[0] / tot:E4} +- {Math.Sqrt(unc100[0]) / tot:E1}); k=2: {unc100[1]} ({(double)unc100[1] / tot:E4} +- {Math.Sqrt(unc100[1]) / tot:E1}); k=6: {unc100[2]}; claimed theta_100 = {(double)cl100 / (double)dn100:E4}");
  }
}
