using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent check of the inverse-fibre / greedy-failure claims (ChatGPT 10:25, 2026-11-24).
class P {
 static List<BigInteger> Fibre(BigInteger y,int j){ var cur=new List<BigInteger>{y}; for(int i=0;i<j;i++){ var nx=new List<BigInteger>(); foreach(var z in cur){ nx.Add(2*z); if(z%3==2) nx.Add((2*z-1)/3); } cur=nx; } return cur; }
 static BigInteger Greedy(BigInteger y,int j){ var z=y; for(int i=0;i<j;i++){ if(z%3==2) z=(2*z-1)/3; else z=2*z; } return z; }
 static BigInteger T(BigInteger x,int j){ for(int i=0;i<j;i++) x=(x%2==0)?x/2:(3*x+1)/2; return x; }
 static void Main(){
  // Theorem 1
  bool t1=true; for(int t=0;t<300;t++){ var f=Fibre(5+9*t,5).OrderBy(v=>v).ToList(); var want=new List<BigInteger>{17+32*t,48+96*t,52+96*t,53+96*t,160+288*t}.OrderBy(v=>v).ToList(); if(!f.SequenceEqual(want)) t1=false; foreach(var x in f) if(T(x,5)!=5+9*t) t1=false; }
  Console.WriteLine("Theorem 1 (A_5(5+9t) = {17+32t,48+96t,52+96t,53+96t,160+288t}), t<300: "+t1);
  // Theorem 2
  bool t2=true; for(int t=0;t<50;t++) for(int j=5;j<=20;j++){ var y=(BigInteger)(5+9*t); var g=Greedy(y,j); var q=BigInteger.Pow(2,j-5)*(17+32*t); if(g!=BigInteger.Pow(2,j-5)*(48+96*t)||!(q<g)||T(q,j)!=y) t2=false; }
  Console.WriteLine("Theorem 2 (greedy = 2^(j-5)(48+96t), strictly above the valid origin 2^(j-5)(17+32t)), t<50, 5<=j<=20: "+t2);
  // Theorem 3: for each j, all y in 1..Y: greedy fails iff ?
  foreach(int j in new[]{1,2,3,4,5,6,7}){ long fails=0, failsNot5=0, tot=0, ok5=0; int Ymax=j<=5? 3*(int)Math.Pow(3,j)*3 : 3000; for(int y=1;y<=Ymax;y++){ var f=Fibre(y,j); var mn=f.Min(); var g=Greedy(y,j); tot++; bool fail=g!=mn; if(fail){fails++; if(y%9!=5) failsNot5++;} if(j==5 && y%9==5 && fail) ok5++; }
    Console.WriteLine("depth "+j+": endpoints 1.."+Ymax+" checked: "+tot+", greedy fails at "+fails+(j==5?" (all of them y=5 mod 9: "+(failsNot5==0)+"; failures at y=5 mod 9: "+ok5+" of "+Enumerable.Range(1,Ymax).Count(y=>y%9==5)+")":"")+(j>5?" (not claimed by the note)":"")); }
 }}
