using System;
using System.Collections.Generic;
using System.Numerics;
// Five-even takeover data: when the longer branches (l=a-1,a) end and only the short branch (l=a-2) continues.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long cls=0,clsTake=0,takeNotCls=0;
    for(int a=2;a<=7;a++){ var pts=new List<(BigInteger u,BigInteger L,BigInteger S)>();
      for(int u=1;u<=2000;u++){ if(u%3==0) continue; bool inCls=((B2(a+4)*u-7)%27==0);
        BigInteger Y0=2*(B2(a-2)*B3(2)*u-1), Y1=2*(B2(a-1)*B3(1)*u-1), Y2=2*(B2(a)*u-1);
        int last=-1; for(int r=a;r<=a+40;r++){ if(H(Y1,4,r-a+1)!=INF||H(Y2,4,r-a)!=INF) last=r; } bool take=false; BigInteger Lm=INF,Sh=INF;
        if(last>=0){ Sh=H(Y0,4,last+1-a+2); if(Sh!=INF){ take=true; foreach(var c in new[]{H(Y1,4,last-a+1),H(Y2,4,last-a)}) if(c!=INF&&(Lm==INF||c<Lm)) Lm=c; } }
        if(inCls){ cls++; if(take) clsTake++; if(take&&last==a+2) pts.Add((u,Lm,Sh)); } else if(take) takeNotCls++;
        if(hm.Count>3000000) hm.Clear(); }
      var p=pts[0]; var q=pts[1]; BigInteger du=q.u-p.u; bool exact=true;
      foreach(var t in pts){ if((t.L-p.L)*du!=(q.L-p.L)*(t.u-p.u)||(t.S-p.S)*du!=(q.S-p.S)*(t.u-p.u)) exact=false; }
      Console.WriteLine("a=" + a + ": class points " + pts.Count + ", slope of longer-branch minimum " + (double)(q.L-p.L)/(double)du + ", of short branch " + (double)(q.S-p.S)/(double)du + ", both affine in u: " + exact + "; 2^(a+7)/27=" + ((double)B2(a+7)/27) + " 2^(a+6)/27=" + ((double)B2(a+6)/27)); }
    Console.WriteLine("class 27 | 2^(a+4)u-7 (a=2..7,u<=2000): " + cls + " values; takeover in " + clsTake + "; takeovers outside the class: " + takeNotCls);
  }
}
