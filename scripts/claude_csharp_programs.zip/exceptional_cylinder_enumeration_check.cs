using System;
using System.Numerics;
// Check ChatGPT 130927: for each L, enumerate all 2^L parity words; exact residue a_L (bit lifting), n0 (least positive), H=floor(2U_L/3^r), B=min_{2^j>3^{r_j}} floor(U_j/(2^j-3^{r_j}));
// exceptional first-descent survivors = {n0+2^L t <= min(H,B)}. Claim: for L=3..14 exactly one word has a nonempty set, its only member n=1; none for L=1,2.
class P {
  static void Main(){
    for(int L=1;L<=16;L++){
      long words=1L<<L; int nonempty=0; long members=0; var firsts=new System.Collections.Generic.List<string>(); long exceptionalCyl=0;
      for(long m=0;m<words;m++){
        int[] b=new int[L]; for(int i=0;i<L;i++) b[i]=(int)((m>>i)&1);
        BigInteger U=0, a=0; int r=0; BigInteger B=-1; // B=-1 means infinity
        // exact residue by lifting: a_{j+1}=a_j+eps*2^j  with eps=(b_j - T^j(a_j)) mod 2, T^j(a_j)=(3^{r_j}a_j+U_j)/2^j
        BigInteger[] Us=new BigInteger[L+1]; int[] rs=new int[L+1]; Us[0]=0; rs[0]=0;
        for(int j=0;j<L;j++){ BigInteger tj=(BigInteger.Pow(3,rs[j])*a+Us[j])/(BigInteger.One<<j); int eps=(int)(((b[j]-(int)(tj%2))%2+2)%2); a+=eps*(BigInteger.One<<j);
          Us[j+1]= b[j]==1? 3*Us[j]+(BigInteger.One<<j) : Us[j]; rs[j+1]=rs[j]+b[j]; }
        U=Us[L]; r=rs[L]; BigInteger n0= a.IsZero? (BigInteger.One<<L) : a;
        BigInteger H=2*U/BigInteger.Pow(3,r);
        for(int j=1;j<=L;j++){ BigInteger d=(BigInteger.One<<j)-BigInteger.Pow(3,rs[j]); if(d>0){ BigInteger f=Us[j]/d; if(B<0||f<B) B=f; } }
        BigInteger lim= (B<0)? H : BigInteger.Min(H,B);
        if(n0<=H) exceptionalCyl++;
        if(n0<=lim){ nonempty++; members+=(long)((lim-n0)/(BigInteger.One<<L))+1; firsts.Add($"n0={n0}"); }
      }
      Console.WriteLine($"L={L}: words with nonempty exceptional first-descent set: {nonempty} (total members {members}); words with exceptional cylinder (n0<=H, no survival imposed): {exceptionalCyl}; {string.Join(",",firsts.GetRange(0,Math.Min(2,firsts.Count)))}");
    }
  }
}
