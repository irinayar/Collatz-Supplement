using System;
using System.Collections.Generic;
// Independent check of Codex's pre-descent affordability theorem (note 090604): for odd n >= 3 with a pre-descent, repetition-free prefix of length j
// (all states z_0..z_j >= n and distinct) and a <= 364 (n-1) odd inputs, every depth-j preimage of y = T^j(n) with MORE than a odd steps is < n.
class P {
  static void Main() {
    long eligible = 0, withHigher = 0, viol = 0, maxFibre = 0; int maxJ = 30;
    for (long n = 3; n <= 4001; n += 2) {
      long z = n; int a = 0; var seen = new HashSet<long> { n };
      for (int j = 1; j <= maxJ; j++) {
        if ((z & 1) == 1) { z = (3 * z + 1) / 2; a++; } else z /= 2;
        if (z < n || !seen.Add(z)) break;                       // descent or repetition: hypotheses end
        if (a > 364 * (n - 1)) break; eligible++;
        // enumerate all depth-j preimages of y = z with their odd counts (inverse tree)
        var cur = new List<(long, int)> { (z, 0) };
        for (int t = 0; t < j; t++) { var nxt = new List<(long, int)>(cur.Count * 2); foreach (var (v, c) in cur) { nxt.Add((2 * v, c)); if (v % 3 == 2) nxt.Add(((2 * v - 1) / 3, c + 1)); } cur = nxt; if (cur.Count > 2000000) break; }
        if (cur.Count > maxFibre) maxFibre = cur.Count;
        bool any = false; foreach (var (v, c) in cur) if (c > a) { any = true; if (v >= n) viol++; }
        if (any) withHigher++;
      }
    }
    Console.WriteLine($"odd n in [3,4001], j <= {maxJ}: eligible pre-descent prefixes {eligible}; prefixes whose fibre has a preimage with more odd steps: {withHigher}; violations (such a preimage >= n): {viol}; largest fibre {maxFibre}");
  }
}
