using System;
using System.Collections.Generic;
using System.Numerics;
// Audit of Four_Reset_Source_Grouping: (T) prefix tree statistics (1420 examined, 197 excluded, 1223 retained, 594 at depth 10), (L) adaptive cover (244 = 1/34/45/164) and long-part cost sum at N=65535 using the formulas (6),(20),(21);
// (S) short part: the 713 positive profiles (gaps 3,5,7,8,9,10 = 2,7,30,85,113,476) rebuilt by integer witness search, and sum of T_p(65535) from (8) (claimed < 0.032661310); total long+short vs 0.071179340245.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static int[] cap={1,3,4,6,8,9,11,13,14,16};
  class Node{ public int[] ev; public int depth,resets; public double cost; public List<Node> kids=new List<Node>(); public bool retained; public double sel; public int selDepthCount; }
  static double N=65535;
  // line data for a prefix/complete word
  static double CostLong(int[] ev){ int j=ev.Length; var Bs=new BigInteger[j+1]; var Es=new int[j+1]; for(int i=0;i<j;i++){ Bs[i+1]=3*Bs[i]+(BigInteger.One<<Es[i]); Es[i+1]=Es[i]+ev[i]; }
    int k=0; foreach(int v in ev) if(v>=2) k++; int m=3-k; double Dj=Math.Pow(2,Es[j])/Math.Pow(3,j), Qj=(double)Bs[j]/Math.Pow(3,j); double Av=Qj+Dj; double M=Math.Pow(2,Es[j]+1);
    // lower lines: u>=n (slope 1, off 0); for each proper prefix i=1..j: slope (4/3)D_i, offset (4/3)D_i+Q_i
    double l=1,del=0; for(int i=1;i<=j;i++){ double Di=Math.Pow(2,Es[i])/Math.Pow(3,i), Qi=(double)Bs[i]/Math.Pow(3,i); double sl=4.0/3*Di, of=4.0/3*Di+Qi; if(sl>l+1e-15||(Math.Abs(sl-l)<1e-15&&of<del)){l=sl;del=of;} }
    double lam=4.0/3-l, gam=M+del-2.0/3; double W=(1+5/N)*(4*N+3*Av)/(4*N+15)*Math.Pow(1+3/(4*N),m)-1; return W*(lam*N+gam)/M; }
  static void Main(){
    // ---- tree
    var root=new Node{ev=new int[0],depth=0}; root.retained=true; var level=new List<Node>{root}; int examined=1,excluded=0,retained=1; var all=new List<Node>();
    for(int d=0;d<10;d++){ var next=new List<Node>();
      foreach(var nd in level){ int E=0; foreach(int v in nd.ev) E+=v; for(int v=1;E+v<=cap[d];v++){ int r=nd.resets+(v>=2?1:0); if(r>3) continue; var ev=new int[d+1]; Array.Copy(nd.ev,ev,d); ev[d]=v; var ch=new Node{ev=ev,depth=d+1,resets=r}; examined++;
          int j=d+1; var Bs=new BigInteger[j+1]; var Es=new int[j+1]; for(int i=0;i<j;i++){ Bs[i+1]=3*Bs[i]+(BigInteger.One<<Es[i]); Es[i+1]=Es[i]+ev[i]; }
          BigInteger Mod=BigInteger.One<<(Es[j]+1); BigInteger a=(((BigInteger.One<<Es[j])-Bs[j])*ModInv(BigInteger.Pow(3,j),Mod))%Mod; if(a<0) a+=Mod; BigInteger u=a; if(u<11) u+=Mod*((11-u+Mod-1)/Mod);
          bool ex=false; for(int i=1;i<=j;i++){ BigInteger dd=(BigInteger.One<<Es[i])-BigInteger.Pow(3,i); if(dd>0){ BigInteger bound=(Bs[i]-1)/dd; if(u>bound) ex=true; } }
          if(ex){ excluded++; } else { ch.retained=true; retained++; nd.kids.Add(ch); next.Add(ch); all.Add(ch); } } }
      level=next; if(d==9) Console.WriteLine($"(T) examined {examined} (claimed 1420), excluded {excluded} (197), retained {retained} (1223), retained at depth 10: {level.Count} (594)"); }
    // ---- cover: bottom-up min over retained nodes depth>=1
    foreach(var nd in all) nd.cost=CostLong(nd.ev);
    void Sel(Node nd){ foreach(var c in nd.kids) Sel(c); if(nd.kids.Count==0 && nd.depth<10){ /* leaf with no retained kids: its own cost only if it must be covered; node itself is a retained prefix with no extensions -> cost own */ }
      double ch=0; foreach(var c in nd.kids) ch+=c.sel; if(nd.depth==10||nd.kids.Count==0){ nd.sel=nd.cost; nd.selDepthCount=1; } else { nd.sel= Math.Min(nd.cost,ch); } }
    // simple recursion computing selected set depth histogram
    var hist=new int[11]; double total=0;
    double Rec(Node nd){ double ch=0; var picks=new List<Node>(); foreach(var c in nd.kids){ ch+=Rec(c); } if(nd.depth==0) return ch; if(nd.kids.Count==0||nd.depth==10) return nd.cost; return Math.Min(nd.cost,ch); }
    // need histogram: do explicit two-pass
    var best=new Dictionary<Node,double>(); var choose=new Dictionary<Node,bool>();
    double Best(Node nd){ if(nd.depth==0){ double t=0; foreach(var c in nd.kids) t+=Best(c); return t; } double ch=0; foreach(var c in nd.kids) ch+=Best(c); double v; if(nd.kids.Count==0||nd.depth==10){ v=nd.cost; choose[nd]=true; } else if(nd.cost<=ch){ v=nd.cost; choose[nd]=true; } else { v=ch; choose[nd]=false; } best[nd]=v; return v; }
    total=Best(root);
    void Count(Node nd,bool covered){ if(nd.depth>0 && !covered && choose[nd]){ hist[nd.depth]++; covered=true; } foreach(var c in nd.kids) Count(c,covered); } Count(root,false);
    Console.WriteLine($"(L) long-part adaptive cover cost at N=65535 = {total:F9} (claimed {3051712763631024651521639811.0/Math.Pow(2,96):F9}); selected cylinders by depth: "+string.Join(" ",new[]{1,2,3,4,5,6,7,8,9,10}.Length>0?HistStr(hist):""));
  }
  static string HistStr(int[] h){ var sb=new System.Text.StringBuilder(); for(int d=1;d<=10;d++) if(h[d]>0) sb.Append($"d{d}:{h[d]} "); return sb.ToString(); }
}
