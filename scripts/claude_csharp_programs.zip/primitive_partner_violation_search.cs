using System;
using System.Collections.Generic;
// Search for violations of P' (non-minimal n whose best partner has odd-count surplus >= 2) at depths up to j = 17, n <= N.
// Report violations (n, j) and the largest n for which a surplus-0/1 partner is missing, compared with 2^j / 12.
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var val = new long[N + 1]; var cnt = new int[N + 1]; for (int n = 1; n <= N; n++) val[n] = n; var idx = new int[N];
    for (int K = 2; K <= 19; K++) {
      for (int n = 1; n <= N; n++) { long v = val[n]; if ((v & 1) == 1) { val[n] = (3 * v + 1) / 2; cnt[n]++; } else val[n] = v / 2; }
      if (K < 12) continue;
      for (int i = 0; i < N; i++) idx[i] = i + 1;
      Array.Sort(idx, (x, y) => { int c = val[x].CompareTo(val[y]); return c != 0 ? c : x.CompareTo(y); });
      long viol = 0; int maxViol = 0, firstViol = 0; long nonmin = 0;
      for (int i = 0; i < N;) { int j = i; while (j < N && val[idx[j]] == val[idx[i]]) j++;
        for (int t = i + 1; t < j; t++) { int n = idx[t]; nonmin++; bool prim = false;
          for (int u = i; u < t && !prim; u++) { int d = cnt[idx[u]] - cnt[n]; if (d == 0 || d == 1) prim = true; }
          if (!prim) { viol++; if (n > maxViol) maxViol = n; if (firstViol == 0 || n < firstViol) firstViol = n; } }
        i = j; }
      Console.WriteLine($"j={K - 1,2}: non-minimal {nonmin,8}; starts WITHOUT a primitive (surplus 0/1) partner: {viol}; smallest {firstViol}, largest {maxViol}; 2^j/12 = {(1L << (K - 1)) / 12.0:F1}");
    }
  }
}
