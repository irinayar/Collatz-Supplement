using System;
using System.Numerics;
using System.Collections.Generic;
// Check ChatGPT 123035: C=517/31 absorbs ALL expanding blocks (e,1^s), e in {2,3,4}; G_total*(1+C/y_final) <= 1+(19+8C)/(27x) <= 128/93.
// (1) exact constants; (2) exact check on random actual words with arbitrary expanding blocks e<=4 (s from s_min up); every prefix: G < 1+4725/(837 x) (that is 1+(19+8C)/(27x) with C=517/31).
// (3) table of C_E=max c over expanding e<=E and the least x (=15 mod 16) with 1+(19+8C_E)/(27x)<3/2.
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger Least(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static (BigInteger,BigInteger) C(int e,int s){ BigInteger a=BigInteger.Pow(3,s+1), d=BigInteger.One<<(s+e), B=BigInteger.Pow(3,s)*(1+(BigInteger.One<<e))-d; return (B,a-d); }
  static void Main(){
    // (1) constants
    for(int e=2;e<=4;e++){ int s=1; while(true){ var (B,g)=C(e,s); if(g>0) { BigInteger gc=BigInteger.GreatestCommonDivisor(B,g); Console.WriteLine($"e={e}: s_min={s}, c={B/gc}/{g/gc} = {(double)B/(double)g:F6}"); break;} s++; } }
    var rng=new Random(777); long words=0,prefixes=0,bad=0;
    int[] smin={0,0,1,3,5};
    for(int t=0;t<3000;t++){
      var w=new List<int>{1,1,1}; int nb=1+rng.Next(8);
      for(int b=0;b<nb;b++){ int e=2+rng.Next(3); int s=smin[e]+rng.Next(4); w.Add(e); for(int j=0;j<s;j++) w.Add(1); }
      BigInteger x=Least(w); if(x<0) continue; words++;
      BigInteger u=x,N=1,Dn=1;
      foreach(int e in w){ N*=(3*u+1); Dn*=(3*u); BigInteger y=3*u+1; while(y.IsEven) y/=2; u=y; prefixes++;
        // G < 1+4725/(837 x)  <=> N*837x < (837x+4725)*Dn
        if(!(N*837*x < (837*x+4725)*Dn)) { bad++; Console.WriteLine($"VIOLATION x={x}"); } }
    }
    Console.WriteLine($"random words {words}, prefixes {prefixes}, violations {bad}");
    // (3) table
    for(int E=2;E<=10;E++){ double cm=0; for(int e=2;e<=E;e++) for(int s=1;s<=400;s++){ var (B,g)=C(e,s); if(g>0){ double c=(double)(B*BigInteger.Pow(10,12)/g)/1e12; if(c>cm) cm=c; } }
      double x0=2*(19+8*cm)/27; long x=(long)Math.Floor(x0)+1; while(x%16!=15) x++; Console.WriteLine($"E={E}: C_E={cm:F3}; need x>{x0:F1}, least x=15 mod 16: {x}"); }
    double Q=Math.Pow(2,61)/(Math.Pow(3,32)*993), h=4194303, xx=1/(3*h), l=xx-xx*xx/2+xx*xx*xx/3; Console.WriteLine($"K122 cutoff H=4194301: {Math.Log(1.5/Q)/l:F4}");
  }
}
