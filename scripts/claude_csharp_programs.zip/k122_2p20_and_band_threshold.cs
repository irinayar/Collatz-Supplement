using System;
using System.Numerics;
// (1) delta odd starts 786431..1048573: max G (double), (2) exact cutoff r at H=1048573 (both boundaries),
// (3) band threshold Lambda(h)=exp(9(ln(1.5/Q)-1/h)) and smallest odd h with Lambda>=5 allowed.
class P {
  static void Main(){
    double l2=Math.Log2(3.0); double best=0; long arg=0; long cnt=0; int maxL=0;
    for(long m=786431;m<=1048573;m+=2){ long n=m; int L=0,r=0; while(n!=2){ if((n&1)==1){ n=(3*n+1)>>1; r++; } else n>>=1; L++; } if(L>maxL) maxL=L; double g=Math.Pow(2.0,(L+1)-r*l2-Math.Log2((double)m)); cnt++; if(g>best){best=g;arg=m;} }
    Console.WriteLine($"delta starts {cnt}: max G={best:F10} at m={arg}; max L to 2 = {maxL}");
    BigInteger c1=3*(BigInteger.Pow(3,32)*993), c2=2*BigInteger.Pow(2,61);
    foreach(int r in new[]{565636,565637}){ bool ok=c2*BigInteger.Pow(3145726,r) < c1*BigInteger.Pow(3145725,r); Console.WriteLine($"H=1048573 r={r}: strict ineq {ok}"); }
    double Q=Math.Pow(2.0,61)/(Math.Pow(3,32)*993); double lg=Math.Log(1.5/Q);
    foreach(double h in new[]{1001.0,1e5+1,524287,1e7+1}) Console.WriteLine($"h={h}: Lambda_max={Math.Exp(9*(lg-1/h)):F5}");
    double h0=1/(lg-Math.Log(5)/9); Console.WriteLine($"Lambda=5 allowed iff 1/h < {lg-Math.Log(5)/9:E6}, i.e. h > {h0:F1}; Q={Q:F10} ln(1.5/Q)={lg:F8}");
  }
}
