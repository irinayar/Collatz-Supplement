using System;
using System.Collections.Concurrent;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
// Search for cycles with minimum element c in a range above 2^68.  A cycle's minimum c is odd and its orbit never goes below c.
// So: for every odd c, iterate S(x) = x/2 or (3x+1)/2 until x < c (descent: c is not a cycle minimum) or until a step limit (survivor: needs deeper look).
// Peak: the maximum value reached before the descent (if c were a cycle minimum its x_max would be >= that peak).
static class P {
  static void Main(string[] args) {
    int ee = args.Length > 2 ? int.Parse(args[2]) : 68; BigInteger start = BigInteger.Pow(2, ee) + 1; long count = long.Parse(args[0]); int stepLimit = args.Length > 1 ? int.Parse(args[1]) : 100000;
    UInt128 c0 = (UInt128)start; int chunks = 256; long per = (count + chunks - 1) / chunks; long maxStop = 0; UInt128 maxStopC = 0; double maxPeakRatio = 0; UInt128 maxPeakC = 0; long survivors = 0; long totalSteps = 0;
    var surv = new ConcurrentBag<UInt128>(); object lk = new object(); long[] hist = new long[64];
    Parallel.For(0, chunks, ch => {
      long i0 = ch * per, i1 = Math.Min(count, (ch + 1) * per); long lMaxStop = 0; UInt128 lMaxStopC = 0; double lMaxPeak = 0; UInt128 lMaxPeakC = 0; long lTot = 0; long[] lh = new long[64];
      for (long i = i0; i < i1; i++) {
        UInt128 c = c0 + (UInt128)(2 * i); UInt128 x = c; UInt128 peak = c; int steps = 0; bool dropped = false;
        while (steps < stepLimit) { if ((x & 1) == 0) x >>= 1; else { x = (3 * x + 1) >> 1; if (x > peak) peak = x; } steps++; if (x < c) { dropped = true; break; } }
        lTot += steps; int b = 0; int s2 = steps; while (s2 > 1) { s2 >>= 1; b++; } lh[b]++;
        if (!dropped) { surv.Add(c); continue; }
        if (steps > lMaxStop) { lMaxStop = steps; lMaxStopC = c; }
        double pr = (double)peak / (double)c; if (pr > lMaxPeak) { lMaxPeak = pr; lMaxPeakC = c; }
      }
      lock (lk) { totalSteps += lTot; if (lMaxStop > maxStop) { maxStop = lMaxStop; maxStopC = lMaxStopC; } if (lMaxPeak > maxPeakRatio) { maxPeakRatio = lMaxPeak; maxPeakC = lMaxPeakC; } for (int k = 0; k < 64; k++) hist[k] += lh[k]; }
    });
    Console.WriteLine($"odd c in [2^68+1, 2^68+{2 * count - 1}] ({count} values): all dropped below c except {surv.Count} survivors after {stepLimit} steps; mean steps {(double)totalSteps / count:F2}; longest descent time {maxStop} steps at c = 2^68 + {(maxStopC - (UInt128)BigInteger.Pow(2, ee))}; largest peak/c = {maxPeakRatio:E3} at c = 2^68 + {(maxPeakC - (UInt128)BigInteger.Pow(2, ee))}");
    Console.WriteLine("descent-time histogram (floor log2 of steps): " + string.Join(" ", System.Linq.Enumerable.Select(System.Linq.Enumerable.Range(0, 20), k => (1 << k) + ":" + hist[k])));
    foreach (var s in surv) Console.WriteLine("survivor: " + s);
  }
}
