using System.Linq;
using System; using System.Collections.Generic;
// Independent brute-force check of the early synchronous-meeting theorem (ChatGPT 10:58, 2026-11-24).
// n odd >1, j=v2(n+1). N=T^j(n). If N%4==0 ("1^j00"): first synchronous meeting with a smaller origin is at k=j+2 and m=n-1 meets there.
// If N%4==2 ("1^j01"): no m<n with T^k(m)=T^k(n) for 0<=k<=j+5.
class P { static void Main(){ int LIM=1500000; var x=new long[LIM+1]; for(int i=0;i<=LIM;i++) x[i]=i; int maxK=30; int[] j=new int[LIM+1]; var is00=new bool[LIM+1]; var cand=new List<int>();
  for(int n=3;n<=LIM;n+=2){ int jj=0; long t=n+1; while(t%2==0){t/=2;jj++;} j[n]=jj; cand.Add(n); }
  // first meeting time per n: smallest k such that exists m<n with T^k(m)=T^k(n); also whether n-1 meets at k=j+2
  var first=new int[LIM+1]; Array.Fill(first,-1); var nm1ok=new bool[LIM+1];
  for(int k=0;k<=maxK;k++){ if(k>0) for(int i=1;i<=LIM;i++) x[i]=(x[i]%2==0)?x[i]/2:(3*x[i]+1)/2; var minOrigin=new Dictionary<long,int>(LIM); for(int i=1;i<=LIM;i++){ if(!minOrigin.ContainsKey(x[i])) minOrigin[x[i]]=i; }
    foreach(int n in cand){ if(first[n]==-1 && minOrigin[x[n]]<n) first[n]=k; if(k==j[n]+2 && n>1 && x[n-1]==x[n]) nm1ok[n]=true; } }
  long c00=0,c01=0,bad00=0,bad01=0,skipped=0; foreach(int n in cand){ int jj=j[n]; // N=T^jj(n)
    long N=n; for(int i=0;i<jj;i++) N=(3*N+1)/2; if(jj+5>maxK){skipped++;continue;}
    if(N%4==0){ c00++; if(first[n]!=jj+2||!nm1ok[n]) bad00++; } else { c01++; if(first[n]!=-1 && first[n]<=jj+5) bad01++; } }
  Console.WriteLine("odd n in 3.."+LIM+": case 00 (N=0 mod 4): "+c00+", violations (first meeting != j+2 or n-1 not meeting at j+2): "+bad00+"; case 01 (N=2 mod 4): "+c01+", violations (a smaller origin meets at some k<=j+5): "+bad01+"; skipped (j+5>"+maxK+"): "+skipped);
  // distribution of first meeting times in case 01 relative to j
  var hist=new SortedDictionary<int,int>(); foreach(int n in cand){ int jj=j[n]; long N=n; for(int i=0;i<jj;i++) N=(3*N+1)/2; if(N%4==2 && jj+9<=maxK){ int d=first[n]==-1? 99 : first[n]-jj; if(!hist.ContainsKey(d)) hist[d]=0; hist[d]++; } }
  Console.WriteLine("case 01: first meeting time minus j: "+string.Join(", ",hist.Select(kv=>(kv.Key==99?"none<=k30":kv.Key.ToString())+":"+kv.Value)));
 }}
