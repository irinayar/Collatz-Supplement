using System;
using System.Collections.Generic;
using System.Numerics;
// Audit of First_Source_Functional report: (A) analytic envelope S3bar(65535) (4.2)-(4.3); (B) finite certificate counts of Section 7 (6757 positive intervals, 1767 distinct positive profiles, max resets 32, max path 85);
// (C) good-length lemma (every 5 consecutive lengths contain a good one, 1<2^E/3^g<5/4) and an explicit instance of the lower-bound construction (k=2,3) verified by literal BigInteger simulation.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static int[] cap9={1,3,4,6,8,9,11,13,14};
  static void Main(){
    // ---- (A)
    double alpha9=15263065.0/483729408, beta9=6544984.0/19683; double N=65535; double S=(alpha9*N+beta9)/(N+5);
    var cands=new List<int[]>(); void Rec(int p,int E,int rs,int[] cur){ if(p==9){ cands.Add((int[])cur.Clone()); return; } for(int v=1;E+v<=cap9[p];v++){ int r=rs+(v>=2?1:0); if(r>2) continue; cur[p]=v; Rec(p+1,E+v,r,cur); } } Rec(0,0,0,new int[9]);
    int kept=0; double sumLong=0; double wd=0;
    foreach(var ev in cands){ BigInteger[] B=new BigInteger[10]; int[] E=new int[10]; for(int j=0;j<9;j++){ B[j+1]=3*B[j]+(BigInteger.One<<E[j]); E[j+1]=E[j]+ev[j]; }
      bool contr=false; for(int j=1;j<=9;j++) if((BigInteger.One<<E[j])>BigInteger.Pow(3,j)) contr=true; if(contr) continue; kept++;
      int k=0; foreach(int v in ev) if(v>=2) k++; int m=2-k; BigInteger M=BigInteger.One<<(E[9]+1);
      double Q=(double)B[9]/Math.Pow(3,9), D=Math.Pow(2,E[9])/Math.Pow(3,9), Av=Q+D; double Cv=(N+5)*((1+Av/N)*Math.Pow(1+1/N,m)-1)+5.0/3-10.0/(3*N); double Mv=(double)M;
      sumLong+=Cv/(N+5)*(N/(3*Mv)+1); wd+=(Av+2-k+5.0/3)/(3*Mv); }
    Console.WriteLine($"(A) retained prefixes {kept}; weighted density sum (A_v+2-k+5/3)/(3M_v) = {wd:E10} (claimed 46244065/1934917632 = {46244065.0/1934917632:E10}); S3bar(65535) = {S+sumLong:F9} (claimed 4480499223596618810067197/66099027624657864118272000 = {4480499223596618810067197.0/66099027624657864118272000.0:F9}); 17/250={17.0/250}");
    // ---- (B)
    long NMAX=65535, srcMax=87379; int pos=0, maxResets=0, maxPath=0; var words=new HashSet<string>();
    for(long u=3;u<=srcMax;u+=4){ long x=u; int g=0,resets=0; var states=new List<long>(); BigInteger Bn=0; int Eacc=0;
      for(int step=0;step<10000;step++){ int e; long nx=A(x,out e); g++; Bn=3*Bn+(BigInteger.One<<Eacc); Eacc+=e; states.Add(nx); x=nx; if(e>=2) resets++; if(step+1>maxPath) maxPath=step+1;
        if(x<u){ break; }
        if(e>=2){ long w=x; long zz=long.MaxValue; for(int i=0;i<g-1;i++) if(states[i]<zz) zz=states[i];
          long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(Math.Min(u,w),NMAX); if(g>1) hi=Math.Min(hi,(3*zz+1)/4); if((hi&1)==0) hi--;
          if(lo<=hi){ BigInteger cn=Bn+5*((BigInteger.One<<Eacc)-BigInteger.Pow(3,g)); if(cn>0){ pos++; if(resets>maxResets) maxResets=resets; } } } } }
    Console.WriteLine($"(B) positive intervals {pos} (claimed 6757), max resets among positive records {maxResets} (claimed 32), max path {maxPath} (claimed 85)");
    // distinct profiles need word keys: recompute with keys
    var keys=new HashSet<string>(); for(long u=3;u<=srcMax;u+=4){ long x=u; int g=0; var ev=new List<int>(); var states=new List<long>(); BigInteger Bn=0; int Eacc=0;
      for(int step=0;step<10000;step++){ int e; long nx=A(x,out e); g++; ev.Add(e); Bn=3*Bn+(BigInteger.One<<Eacc); Eacc+=e; states.Add(nx); x=nx; if(x<u) break;
        if(e>=2){ long w=x; long zz=long.MaxValue; for(int i=0;i<g-1;i++) if(states[i]<zz) zz=states[i];
          long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(Math.Min(u,w),NMAX); if(g>1) hi=Math.Min(hi,(3*zz+1)/4); if((hi&1)==0) hi--;
          if(lo<=hi){ BigInteger cn=Bn+5*((BigInteger.One<<Eacc)-BigInteger.Pow(3,g)); if(cn>0) keys.Add(string.Join(",",ev)); } } } }
    Console.WriteLine($"    distinct positive profiles {keys.Count} (claimed 1767)");
    // ---- (C)
    double al=Math.Log2(3); int badWin=0; int lastGood=0; int maxGapG=0; for(int g=1;g<=2000000;g++){ double f=g*al-Math.Floor(g*al); /* exists E with 1<2^E/3^g<5/4 <=> E-g*al in (0,log2(5/4)) <=> frac(g al) in (1-log2(1.25),1) */ bool good = f>1-Math.Log2(1.25) && f<1; if(good){ maxGapG=Math.Max(maxGapG,g-lastGood); lastGood=g; } }
    Console.WriteLine($"(C) good lengths g<=2e6: max distance between consecutive good lengths = {maxGapG} (claim: every five consecutive contain one, i.e. <=5)");
    foreach(int k in new[]{2,3}){ int g=8*k; while(true){ double f=g*al-Math.Floor(g*al); if(f>1-Math.Log2(1.25)&&f<1) break; g++; }
      int E=(int)Math.Ceiling(g*al); int m=g/(2*k); var rng=new Random(k); var a=new int[k+1]; var h=new int[k+1]; int sa=0,sh=0; for(int i=1;i<k;i++){ a[i]=m+rng.Next(m); h[i]=2+rng.Next(m/2-1); sa+=a[i]; sh+=h[i]; } a[k]=g-sa; h[k]=E-g+k-sh;
      var ev=new List<int>(); for(int i=1;i<=k;i++){ for(int j=0;j<a[i]-1;j++) ev.Add(1); ev.Add(h[i]); } int Etot=0; foreach(int v in ev) Etot+=v;
      BigInteger n=BigInteger.Pow(3,g)*64; if(n.IsEven) n+=1; BigInteger H=(4*n-2)/3; // source in [D n, H-2] in the exact cylinder
      BigInteger Bn=0; int Ea=0; foreach(int v in ev){ Bn=3*Bn+(BigInteger.One<<Ea); Ea+=v; } BigInteger Mod=BigInteger.One<<(Ea+1); BigInteger res=(((BigInteger.One<<Ea)-Bn)*ModInv(BigInteger.Pow(3,g),Mod))%Mod; if(res<0) res+=Mod;
      BigInteger Dn=((BigInteger.One<<Ea)*n+BigInteger.Pow(3,g)-1)/BigInteger.Pow(3,g); BigInteger u=Dn+((res-Dn)%Mod+Mod)%Mod;
      bool inI=u<=H-2; BigInteger x=u; bool ok=true; var proper=true; int resets=0; for(int i=0;i<g;i++){ BigInteger y=3*x+1; int e=0; while(y.IsEven){y/=2;e++;} if(e!=ev[i]){ok=false;break;} if(e>=2) resets++; x=y; if(i<g-1 && x<=H) proper=false; }
      bool arrival= x>=n && x<=H; BigInteger cnum=Bn+5*((BigInteger.One<<Ea)-BigInteger.Pow(3,g)); 
      Console.WriteLine($"    construction k={k}: g={g}, E={E}, runs a={string.Join(",",a[1..])}, h={string.Join(",",h[1..])}; n=64*3^g: source found in [Dn,H-2]: {inI}; valuations match: {ok}; all proper states >H: {proper}; arrival in band: {arrival}; resets {resets}; c>65/81: {(double)cnum/Math.Pow(3,g)>65.0/81}");
    }
  }
}
