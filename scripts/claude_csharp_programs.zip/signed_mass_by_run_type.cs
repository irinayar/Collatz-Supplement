using System;
using System.Collections.Generic;
// Actual positive signed mass psi=[t]_+ (t = kappa*delta + f, kappa=(n-1)/(n+1)) by run type (s,e) over all runs of all genuine returns at one threshold (family = every source).
class P {
  static void Main(string[] args) {
    foreach (string sn in args) {
      long n = long.Parse(sn) | 1; long H = (4 * n - 2) / 3; double kappa = (n - 1.0) / (n + 1.0); var mass = new Dictionary<(int, int), double>(); var cnt = new Dictionary<(int, int), long>(); double tot = 0, totDelta = 0; long ret = 0;
      for (long u = n; u <= H; u += 2) {
        long x = u; int s = 0; long a = u; bool r = false; int steps = 0; var rl = new List<(long a, int s, long b, int e)>();
        while (steps < 100000) { long t = 3 * x + 1; int ev = System.Numerics.BitOperations.TrailingZeroCount((ulong)t); t >>= ev; s++; x = t; steps++;
          if (ev >= 2) { rl.Add((a, s, x, ev)); s = 0; a = x; } if (x < n) break; if (x <= H) { r = true; break; } if (x > (1L << 60)) break; }
        if (!r) continue; ret++;
        foreach (var q in rl) { double z = Math.Pow(2.0 / 3, q.s), delta = (1 - z) / q.a, f = 1.0 / q.a - 1.0 / q.b, t = kappa * delta + f, psi = Math.Max(0, t); totDelta += delta; tot += psi; var k = (Math.Min(q.s, 6), Math.Min(q.e, 6)); mass.TryGetValue(k, out double m0); mass[k] = m0 + psi; cnt.TryGetValue(k, out long c0); cnt[k] = c0 + 1; }
      }
      Console.WriteLine($"n={n}: returns={ret}; total positive signed mass sum psi={tot:E4}, sum delta={totDelta:E4}");
      var keys = new List<(int, int)>(mass.Keys); keys.Sort((p, q) => mass[q].CompareTo(mass[p]));
      for (int i = 0; i < Math.Min(8, keys.Count); i++) Console.WriteLine($"  type (s={keys[i].Item1}, e={keys[i].Item2}{(keys[i].Item1 == 6 || keys[i].Item2 == 6 ? "+" : "")}): runs={cnt[keys[i]]}, sum psi={mass[keys[i]]:E3} ({100 * mass[keys[i]] / tot:F1}% of total)");
    }
  }
}
