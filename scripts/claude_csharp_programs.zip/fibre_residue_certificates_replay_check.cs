using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent replay of two residue-lifting certificates (ChatGPT 10:25 and 10:58, 2026-11-24):
//  (E) the fifth inverse-fibre lemma for N = 2 mod 12 (1944 classes mod 23328) used for the early synchronous-meeting theorem;
//  (G) greedy inverse selection: no failure at depths 1-4, failure at depth 5 exactly on y = 5 mod 9.
class P {
 struct Af { public BigInteger a,b; public Af(BigInteger a_,BigInteger b_){a=a_;b=b_;} }
 static List<Af> Back(Af y,int depth,List<string> words,string w,out bool uniform){ bool uni=true; var res=new List<Af>(); void Rec(Af z,int d,string ww){ if(d==0){ res.Add(z); words?.Add(ww); return; } // E branch
     Rec(new Af(2*z.a,2*z.b),d-1,ww+"0"); // O branch needs z = 2 mod 3 for all t
     if(((z.a%3)+3)%3==0){ if(((z.b%3)+3)%3==2) Rec(new Af((2*z.a)/3,(2*z.b-1)/3),d-1,ww+"1"); } else uni=false; }
   Rec(y,depth,""); uniform=uni; return res; }
 static void Main(){
  // ---- (E)
  BigInteger M=BigInteger.Pow(2,5)*BigInteger.Pow(3,6); long classes=0,totalAnc=0; bool allUniform=true, geM=true, geR=true, tight=true; var n2=new HashSet<int>(); var n1=new HashSet<int>(); long near2=0,near1=0; bool patternOk=true; long minSlopeFail=0;
  var hist=new SortedDictionary<int,int>();
  for(int r=0;r<(int)M;r++){ if(r%12!=2) continue; classes++; // forward 5 steps symbolic
    Af x=new Af(M,r); bool fwdOk=true; for(int i=0;i<5;i++){ if(x.a%2!=0){fwdOk=false;break;} bool odd=((x.b%2)+2)%2==1; if(odd) x=new Af(3*x.a/2,(3*x.b+1)/2); else x=new Af(x.a/2,x.b/2); } if(!fwdOk) allUniform=false;
    var anc=Back(x,5,null,"",out bool uni); if(!uni) allUniform=false; totalAnc+=anc.Count; bool hasN=false; bool has1=false,has2=false;
    foreach(var z in anc){ if(z.a==M&&z.b==r){hasN=true;continue;} if(z.a<M) geM=false; if(z.b<r-2) geR=false; if(z.b<r && z.a!=M) tight=false; if(z.a==M&&z.b==r-1) has1=true; if(z.a==M&&z.b==r-2) has2=true; if(z.a==M && z.b>r-3 && z.b<r && !(z.b==r-1||z.b==r-2)) tight=false; }
    if(!hasN) allUniform=false; int r96=r%96; if(has2) n2.Add(r96); if(has1) n1.Add(r96);
    // pattern: N-2 occurs iff r mod 96 in {26,38,74}; N-1 iff r mod 96 == 38
    bool e2=(r96==26||r96==38||r96==74), e1=(r96==38); if(has2!=e2) patternOk=false; if(has1!=e1) patternOk=false; if(has2) near2++; if(has1) near1++; }
  Console.WriteLine("(E) classes N=2 mod 12 mod 23328: "+classes+" (claimed 1944); all forward parities and reverse branch tests uniform in t: "+allUniform+"; total affine ancestors (incl. N): "+totalAnc+" (claimed 12879 valid ancestors)");
  Console.WriteLine("    every ancestor has slope >= M: "+geM+", intercept >= r-2: "+geR+", (intercept < r => slope == M): "+tight+"; near competitors: N-2 iff N mod 96 in {26,38,74}, N-1 iff N mod 96 = 38 : "+patternOk+" (classes with N-2: "+near2+", with N-1: "+near1+"; residues mod 96 seen: N-2 "+string.Join(",",n2.OrderBy(v=>v))+" ; N-1 "+string.Join(",",n1.OrderBy(v=>v))+")");
  // ---- (G) greedy
  for(int j=1;j<=6;j++){ BigInteger mod=BigInteger.Pow(3,j); long fails=0, failsNot5=0, failFlat=0, tot=0, ok5=0; bool uniAll=true;
    for(int y0=1;y0<=(int)mod;y0++){ tot++; var words=new List<string>(); var anc=Back(new Af(mod,y0),j,words,"",out bool uni); if(!uni) uniAll=false;
      // greedy word: O whenever available -> build by simulation of symbolic path
      Af z=new Af(mod,y0); for(int i=0;i<j;i++){ if(z.a%3==0 && ((z.b%3)+3)%3==2) z=new Af(2*z.a/3,(2*z.b-1)/3); else z=new Af(2*z.a,2*z.b); }
      // greedy least for all t? need a_g<=a_w and b_g<=b_w for all w
      bool least=anc.All(w=>z.a<=w.a && z.b<=w.b); // strictly "for all t>=0 greedy <= w"
      bool failsEveryT = anc.Any(w=>w.a<=z.a && w.b<z.b); // some other origin is strictly smaller for every t>=0
      if(!least){ fails++; if(y0%9!=5) failsNot5++; } if(failsEveryT) failFlat++; if(j==5 && y0%9==5 && failsEveryT) ok5++; }
    Console.WriteLine("(G) depth "+j+": residues y0 mod 3^"+j+": "+tot+", reverse branches uniform: "+uniAll+", classes where greedy is not least for all t: "+fails+(j==5?" (all with y0=5 mod 9: "+(failsNot5==0)+"; of these classes where a smaller origin exists for every t: "+ok5+" of "+(tot/9)+")":"")); }
 }}
