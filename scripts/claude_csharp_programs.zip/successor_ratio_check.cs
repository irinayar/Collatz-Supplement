using System;
using System.Collections.Generic;
// Robustness of monotonicity for x>=3: largest ratio H_k(x,r+1)/H_k(x,r) among exceptional pairs (H<3*2^k-4) with a recorded smaller successor.
class P {
  static void Main(string[] args){
    int K0=int.Parse(args[0]), K=int.Parse(args[1]);
    for(int k=K0;k<=K;k++){ long B=3L*(1L<<k)-4; var best=new Dictionary<(long,int),long>();
      for(long m=1;m<B;m++){ long y=m; int e=0,o=0; for(int step=0;step<10000;step++){ if(e==k){ if(!best.ContainsKey((y,o))) best[(y,o)]=m; } if(e>k) break; if((y&1)==1){ y=(3*y+1)/2; o++; } else { y/=2; e++; } if(e>k) break; } }
      double maxRatio=0; string arg=""; long pairs=0; double sumHigh=0; long above75=0;
      foreach(var kv in best){ long x=kv.Key.Item1; int r=kv.Key.Item2; long h=kv.Value; if(x<3) continue; if(best.TryGetValue((x,r+1),out var hp)&&hp<h){ pairs++; double q=(double)hp/h; if(q>0.75) above75++; if(q>maxRatio){ maxRatio=q; arg=$"x={x} r={r} h={h} h'={hp}"; } } }
      Console.WriteLine($"k={k}: x>=3 pairs with successor {pairs}; max ratio H(r+1)/H(r) = {maxRatio:F4} at {arg}; pairs with ratio > 0.75: {above75}");
    }
  }
}
