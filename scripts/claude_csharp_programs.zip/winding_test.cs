using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    var hist = new SortedDictionary<(int k,int w), long>(); long words = 0, allValleyLeft = 0;
    var radii = new[] { 1.0001, 1.5, 4.0, 100.0 };
    var perR = new Dictionary<double, long>(); foreach (var r in radii) perR[r] = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        int k = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) k++; if (k < 1) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double H = x.Max();
        words++;
        int bestW = 0;
        foreach (double rad in radii) {
          double R = H * rad + (rad == 1.0001 ? 0 : 0) + 1e-9; if (rad == 1.0001) R = H * 1.0001 + 1e-9;
          var ev = new List<(double x0, int s)>();
          for (int i = 0; i < L; i++) {
            bool ui = e[i], uj = e[(i + 1) % L]; if (ui == uj) continue; // cross edge
            double xa = x[i], xb = x[(i + 1) % L]; double ha = Math.Sqrt(Math.Max(R * R - xa * xa, 0)), hb = Math.Sqrt(Math.Max(R * R - xb * xb, 0));
            double x0 = (xa * hb + xb * ha) / (ha + hb);
            // peak edge (upper -> lower): s=-1 ; valley edge (lower -> upper): s=+1
            ev.Add((x0, ui ? -1 : +1));
          }
          ev.Sort((p, q) => p.x0.CompareTo(q.x0)); int cur = 0, mx = 0; foreach (var t in ev) { cur += t.s; mx = Math.Max(mx, cur); }
          if (mx == k) perR[rad]++;
          if (rad == 1.5) { bestW = mx; }
        }
        hist.TryGetValue((k, bestW), out long c); hist[(k, bestW)] = c + 1;
      }
    }
    Console.WriteLine($"words {words}; fraction with max winding about an axis point = k, by circle radius R=rad*H: " + string.Join(", ", radii.Select(r => $"{r}: {100.0 * perR[r] / words:F2}%")));
    Console.WriteLine("(k, max winding at R=1.5H): count");
    foreach (var kv in hist.Where(kv => kv.Key.k <= 6)) Console.WriteLine($"  k={kv.Key.k} maxW={kv.Key.w}: {kv.Value}");
  }
}
