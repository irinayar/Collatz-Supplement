using System;
using System.Collections.Concurrent;
using System.Numerics;
using System.Threading.Tasks;
// Exhaustive scan: all A <= Amax such that, with L = ceil(A log2 3), ln(2^L/3^A) <= A/(3N)  (N = 2^68):  d(A) := L - A*log2(3) <= A * kappa, kappa = 1/(3 N ln 2).
static class P {
  static BigInteger S = BigInteger.Pow(10, 80);
  static BigInteger Atanh(BigInteger num, BigInteger den) { BigInteger x = num * S / den, x2 = x * x / S, term = x, sum = 0; for (int n = 1; term != 0; n += 2) { sum += term / n; term = term * x2 / S; } return sum; }
  static void Main(string[] args) {
    long Amax = long.Parse(args[0]); double Nlog2 = double.Parse(args[1]); // N = 2^Nlog2
    BigInteger ln2 = 2 * Atanh(1, 3), ln3 = 2 * Atanh(2, 4);
    BigInteger two128 = BigInteger.Pow(2, 128);
    BigInteger alphaFrac = (ln3 * two128 / ln2) % two128;               // fractional part of log2 3 scaled by 2^128
    // kappa*2^128 = 2^128/(3 N ln 2); N=2^Nlog2 (Nlog2 integer) ; ln2 = ln2/S
    BigInteger K = two128 * S / (3 * (BigInteger.One << (int)Nlog2) * ln2);
    UInt128 a128 = (UInt128)alphaFrac, K128 = (UInt128)K;
    int chunks = 64; long per = (Amax + chunks - 1) / chunks; var hits = new ConcurrentBag<(long A, double d)>();
    Parallel.For(0, chunks, c => {
      long A0 = c * per + 1, A1 = Math.Min(Amax, (c + 1) * per); if (A0 > A1) return;
      UInt128 frac = (UInt128)((BigInteger)A0 * alphaFrac % two128); UInt128 thr = (UInt128)((BigInteger)A0 * K % two128);
      for (long A = A0; A <= A1; A++) {
        UInt128 d = (UInt128)0 - frac; // distance from frac to the next integer above (= L - A alpha), exact mod 2^128
        if (d != 0 && d < thr) hits.Add((A, (double)d / 3.4028236692093846e38));
        frac += a128; thr += K128;
      }
    });
    var list = new System.Collections.Generic.List<(long A, double d)>(hits); list.Sort((x, y) => x.A.CompareTo(y.A));
    Console.WriteLine($"A <= {Amax}, N = 2^{Nlog2}: {list.Count} admissible A (before removing repetitions)");
    foreach (var h in list) Console.WriteLine($"A={h.A}  L - A log2 3 = {h.d:E3}");
  }
}
