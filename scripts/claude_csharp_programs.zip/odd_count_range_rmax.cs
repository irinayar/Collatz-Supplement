using System;
using System.Numerics;
// r_max: largest r with Q*(1+1/(3(H+2)))^r < 3/2, H = 2^32-3, Q = 1.32421876 (rigorous upper bound 1.324218750860254 rounded up), computed with exact big-rational comparison by binary search on r.
class P {
  static void Main(){
    BigInteger Hn=BigInteger.Pow(2,32)-1; // H+2
    // f = (3Hn+1)/(3Hn); Q = 132421876/100000000 ; condition Q f^r < 3/2  <=> 2*132421876*(3Hn+1)^r < 3*10^8*(3Hn)^r ; use logs with BigInteger via high-precision: binary search using exact integer powers is too large; use decimal log with 50-digit arithmetic via BigRational approximations
    double ln15=Math.Log(1.5), lnQ=Math.Log(1.32421876); double lnf=Math.Log(1.0+1.0/(3.0*(double)Hn)); // lnf computed via log1p for accuracy
    double lnf2=Math.Log(1.0+1.0/(3.0*(double)Hn)); double l1p=(1.0/(3.0*(double)Hn))-0.5*Math.Pow(1.0/(3.0*(double)Hn),2);
    double rmax=(ln15-lnQ)/l1p; Console.WriteLine($"ln(1.5/Q) = {ln15-lnQ:F10}; ln f = {l1p:E10}; r_max = {rmax:E6} ({(long)rmax})");
    long r=(long)rmax-100000; double check=lnQ+r*l1p; Console.WriteLine($"at r = {r}: ln(Q f^r) = {check:F10} < ln(3/2) = {ln15:F10}: {check<ln15}; margin {ln15-check:E3}");
  }
}
