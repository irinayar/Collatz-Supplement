using System;
using System.Collections.Generic;
// K186 return-height horizon on actual returns: for every run start (odd index g>=1, proper state a_g) that is canonically interior (E_g + floor(log2 a_g) < E, E = total exponent),
// check 2^E > 3^g (u+q_g), 3^(N-g) > w (u+q_g)/(u+Q) and 47*3^(N-g) > 32 n (1+q_g/u); report counts and the smallest N-g among interior starts (compare R(n)).
class P {
  static void Main(string[] args) {
    foreach (string sn in args) {
      long n = long.Parse(sn) | 1; long H = (4 * n - 2) / 3; long ret = 0, interior = 0, v1 = 0, v2 = 0, v3 = 0; int minNg = int.MaxValue; int R = 0; while (47.0 * Math.Pow(3, R) <= 32.0 * n) R++;
      for (long u = n; u <= H; u += 2) {
        long x = u; double Z = 1.0, Q = 0.0; bool r = false; int steps = 0; var lst = new List<(long a, int Eg, double q)>(); int E = 0; var starts = new List<int>(); int idx = 0; bool newRun = true; var runStartIdx = new List<int>();
        var Eg = new List<int>(); var ag = new List<long>(); var qg = new List<double>(); Eg.Add(0); ag.Add(u); qg.Add(0.0);
        while (steps < 100000) { long t = 3 * x + 1; int ev = System.Numerics.BitOperations.TrailingZeroCount((ulong)t); t >>= ev; if (newRun) { runStartIdx.Add(idx); newRun = false; }
          Q += Z / 3.0; Z = Z * Math.Pow(2, ev) / 3.0; E += ev; x = t; steps++; idx++; Eg.Add(E); ag.Add(x); qg.Add(Q); if (ev >= 2) newRun = true;
          if (x < n) break; if (x <= H) { r = true; break; } if (x > (1L << 60)) break; }
        if (!r) continue; ret++; int N = steps; double w = x;
        foreach (int g in runStartIdx) { if (g == 0 || g >= N) continue; long a = ag[g]; int ell = 63 - System.Numerics.BitOperations.LeadingZeroCount((ulong)a);
          if (!(Eg[g] + ell < E)) continue; interior++;
          double lhs1 = Math.Pow(2, E), rhs1 = Math.Pow(3, g) * (u + qg[g]); if (!(lhs1 > rhs1)) v1++;
          double l2 = Math.Pow(3, N - g), r2 = w * (u + qg[g]) / (u + Q); if (!(l2 > r2)) v2++;
          if (!(47.0 * Math.Pow(3, N - g) > 32.0 * n * (1 + qg[g] / u))) v3++;
          if (N - g < minNg) minNg = N - g; }
      }
      Console.WriteLine($"n={n}: returns={ret}; interior run starts={interior}; violations: 2^E>3^g(u+q)={v1}, 3^(N-g)>w(u+q)/(u+Q)={v2}, 47*3^(N-g)>32n(1+q/u)={v3}; smallest N-g among interior starts={minNg}; R(n)={R}");
    }
  }
}
