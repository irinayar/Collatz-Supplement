using System;
using System.Collections.Generic;
// Independent check of Codex K144: long (g>9) first returns with at most three resets and positive charge, for odd thresholds 3<=n<=65533 (H<=87376 so sources u<=87375, u=3 mod 4).
// For each source u: walk the odd map; at each reset endpoint w (valuation>=2) with g>9 and resets<=3, thresholds n are the odd integers in
//   max(3,ceil((3max(u,w)+2)/4)) <= n <= min(u,w,floor((3z+1)/4),65533), z = least proper state (states u_1..u_{g-1}).  Expect exactly 131 records with c>0.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=65533; long srcMax=87375; int records=0, recordsAll=0, maxG=0; var gaps=new SortedDictionary<int,int>(); int negCharge=0;
    for(long u=3;u<=srcMax;u+=4){ long x=u; int g=0,resets=0; long z=long.MaxValue; double G=1.0; 
      for(int step=0;step<256;step++){ G*=1.0+1.0/(3.0*x); int e; long nx=A(x,out e); g++; if(g>=2 && false){} if(g>=2){ } 
        // x is current departure/proper state; nx is next state
        if(step>=1 && x<z) z=Math.Min(z,x); // proper states are u_1..u_{g-1}: x at step>=1 is a proper state candidate (before arrival)
        x=nx; if(e>=2){ resets++; if(resets>3) break; long w=x;
          if(g>9){ // z must be min over states u_1..u_{g-1}; recompute precisely below
            long zz=long.MaxValue; long y=u; for(int i=0;i<g;i++){ int ee; y=A(y,out ee); if(i<g-1 && y<zz) zz=y; }
            long lo=Math.Max(3,(3*Math.Max(u,w)+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(Math.Min(u,w),Math.Min((3*zz+1)/4,NMAX)); if((hi&1)==0) hi--;
            if(lo<=hi){ recordsAll++; double rho=G*(1.0+5.0/w)/(1.0+5.0/u); double c=(u+5)*(rho-1); if(c>0){ records++; if(g>maxG) maxG=g; if(!gaps.ContainsKey(g)) gaps[g]=0; gaps[g]++; } else negCharge++; } }
          if(w<=u) break; } }
    }
    Console.WriteLine($"long (g>9, <=3 resets) first-return records over thresholds up to {NMAX}: all {recordsAll}, positive charge {records} (negative charge {negCharge}); longest gap {maxG}; by gap: "+string.Join(" ",gaps));
  }
}
