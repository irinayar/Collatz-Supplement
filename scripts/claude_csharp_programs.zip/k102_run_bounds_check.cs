using System;
using System.Numerics;
// Independent exact check of Codex K102 (maximal high-run identities, R, B, and run-count threshold 75) and ChatGPT 194114 (48 runs).
class P {
  struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static F operator*(F a,F b)=>new F(a.n*b.n,a.d*b.d); public static bool Gt(F a,F b)=>a.n*b.d>b.n*a.d; public static double D(F a)=>(double)a.n/(double)a.d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  // simulate the maximal odd run starting at odd u: returns exact product of correction factors and the state after the run (even), by actual steps
  static F RunSim(BigInteger u,out BigInteger after){ F g=new F(1,1); BigInteger x=u; while(!x.IsEven){ g=g*new F(3*x+1,3*x); x=(3*x+1)/2; } after=x; return g; }
  static F C(BigInteger u,out BigInteger v){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); v=w>>e; return new F(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    long idBad=0,cases=0;
    for(long u=3;u<=200001;u+=2){ BigInteger a; var g1=RunSim(u,out a); BigInteger v; var g2=C(u,out v); cases++; BigInteger w=BigInteger.Pow(3,V2(u+1))*(u+1)/BigInteger.Pow(2,V2(u+1))-1; if(g1.n!=g2.n||g1.d!=g2.d||a!=w) idBad++; }
    Console.WriteLine("run identity C(u)=2^s w/(3^s u), w=3^s(u+1)/2^s-1 vs actual run simulation, odd u<=200001: " + cases + " cases, mismatches " + idBad);
    F R=new F(1,1); long argR=0; for(long u=257;u<=1023;u+=2){ BigInteger v; var c=C(u,out v); if(F.Gt(c,R)){ R=c; argR=u; } }
    Console.WriteLine($"R = max C(u), odd u in [257,1023] = {R.n}/{R.d} at u={argR}; 1+1/1025 < R: {F.Gt(R,new F(1026,1025))}");
    F B=new F(1,1); long a1=0,a2=0; for(long u=257;u<=1023;u+=2){ BigInteger v; var c=C(u,out v); if(v>255){ BigInteger v2; var cv=C(v,out v2); var pr=c*cv; if(F.Gt(pr,B)){ B=pr; a1=u; a2=(long)v; } } }
    F tail=new F(1026,1025)*R; if(F.Gt(tail,B)) { Console.WriteLine("analytic tail bound (1026/1025)*R exceeds the finite maximum!"); B=tail; }
    Console.WriteLine($"B = max adjacent pair product = {B.n}/{B.d} at {a1}->{a2}; B<R^2: {F.Gt(R*R,B)}; Codex: 227840/226719");
    F Q=new F(8192,6561); F three2=new F(3,2);
    for(int h=1;h<=200;h++){ F bound=Q; for(int i=0;i<h/2;i++) bound=bound*B; if(h%2==1) bound=bound*R; if(F.Gt(bound,three2)){ Console.WriteLine($"smallest number of high runs h with Q*B^floor(h/2)*R^(h mod 2) > 3/2: h={h} (Codex: 75)"); break; } }
    // ChatGPT: Q * exp-majorant with t=47/257
    double t=47.0/257; double maj=1+t+t*t/(2*(1-t/3)); Console.WriteLine($"ChatGPT 48-run: Q*[1+t+t^2/(2(1-t/3))] at t=47/257 = {8192.0/6561*maj:F6} (<1.5: {8192.0/6561*maj<1.5}); at t=48/257: {8192.0/6561*(1+48.0/257+Math.Pow(48.0/257,2)/(2*(1-48.0/257/3))):F6}; exact exp(48/257)*Q = {8192.0/6561*Math.Exp(48.0/257):F6}");
  }
}
