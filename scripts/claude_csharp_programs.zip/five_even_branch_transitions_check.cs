using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 151108 (five-even short-branch dominance in terms of q=2^(a-2)u) and of the takeover gap M_4 - S_5 = 8N/27 - 5, N = 64q-7.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    // (1) ChatGPT 151504: the 35 words with 3 odd, 4 even steps, V = 20 mod 27
    var found=new List<string>(); for(int mask=0;mask<128;mask++){ int cnt=0; for(int i=0;i<7;i++) if(((mask>>i)&1)==1) cnt++; if(cnt!=3) continue; BigInteger V=0; int h=0; var sb=new System.Text.StringBuilder(); for(int i=0;i<7;i++){ bool odd=((mask>>i)&1)==1; sb.Append(odd?"1":"0"); if(odd){ V+=B2(i)*B3(2-h); h++; } } if(V%27==20) found.Add(sb.ToString()+" V="+V); }
    Console.WriteLine("words with V=20 mod 27: " + found.Count + " -> " + string.Join(", ",found));
    // (2) which branch is the argmin of H_5 (r>=a) and how it changes: S=H4(18q-2,s), M=H4(12q-2,s-1), B=H4(8q-2,s-2)
    var trans=new SortedDictionary<string,long>(); long series=0; long ends=0;
    for(int q=1;q<=6000;q++){ if(q%3==0) continue; BigInteger Q=q; string prev=""; BigInteger pv=INF; series++;
      for(int s=2;s<=22;s++){ var S=H(18*Q-2,4,s); var M=H(12*Q-2,4,s-1); var B=H(8*Q-2,4,s-2); BigInteger mn=INF; string arg=""; foreach(var (n,v) in new[]{("S",S),("M",M),("B",B)}){ if(v!=INF&&(mn==INF||v<mn)){mn=v;arg=n;} else if(v!=INF&&v==mn) arg+="="+n; }
        if(mn==INF) break; if(prev!=""&&prev!=arg){ string key=prev+"->"+arg; trans[key]=trans.GetValueOrDefault(key)+1; } prev=arg; pv=mn; }
      hm.Clear(); }
    Console.WriteLine("argmin-branch changes along s (q<=6000, s<=22), counts of transitions: " + string.Join("; ",trans) + "   (series " + series + ")");
  }
}
