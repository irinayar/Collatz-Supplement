using System;
using System.Collections.Generic;
using System.Numerics;
// Lower barrier check (Theorem L): for an orbit followed until its first repeated state, at EVERY time N >= 1
// (states z_0..z_{N-1} distinct) we must have, exactly:
//   A_N = 0:  2^N <= n            [z_N = n/2^N >= 1]
//   A_N >= 1: 3^6 * 2^(6N) <= 3^(6 A_N) (4n)^6 (2 A_N - 1)       [from 1 <= z_N <= (4n/3) 3^{D_N} (2A_N-1)^{1/6}]
// Also records the minimum of D_N + (1/6) log_3 N + log_3(4n/3) over all tested (N,n) (should be >= 0 by the theorem; reported as slack).
class P {
  static void Main(string[] a) {
    long N0 = long.Parse(a[0]); long checks = 0, viol = 0; double minSlack = 1e18; BigInteger arg = 0; long argN = 0;
    var starts = new List<BigInteger>();
    for (long n = 1; n <= N0; n++) starts.Add(n);
    starts.Add(BigInteger.Parse("4064460795")); starts.Add(BigInteger.Parse("18839651253368551")); starts.Add(BigInteger.Parse("2361183272358587138047"));
    double ln3 = Math.Log(3), ln2 = Math.Log(2);
    foreach (var n in starts) {
      var seen = new HashSet<BigInteger>(); BigInteger z = n; int A = 0; long j = 0;
      while (true) {
        if (j >= 1) {   // test time N=j: states z_0..z_{j-1} are distinct (we stop right after the first repeated state is reached)
          checks++;
          bool ok;
          if (A == 0) ok = (BigInteger.One << (int)j) <= n;
          else ok = BigInteger.Pow(3, 6) * (BigInteger.One << (int)(6 * j)) <= BigInteger.Pow(3, 6 * A) * BigInteger.Pow(4 * n, 6) * (2 * A - 1);
          if (!ok) viol++;
          double D = A - j * ln2 / ln3;
          double sl = D + Math.Log(j) / ln3 / 6.0 + (BigInteger.Log(4 * n) - Math.Log(3)) / ln3;
          if (sl < minSlack) { minSlack = sl; arg = n; argN = j; }
        }
        if (!seen.Add(z)) break;
        if (!z.IsEven) { z = (3 * z + 1) / 2; A++; } else z /= 2;
        j++;
      }
    }
    Console.WriteLine($"orbits {starts.Count}, checks {checks}, violations {viol}; min over all of D_N + (1/6)log_3 N + log_3(4n/3) = {minSlack:F4} (n={arg}, N={argN})");
  }
}
