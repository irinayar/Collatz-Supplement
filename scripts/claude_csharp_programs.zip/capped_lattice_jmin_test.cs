using System;
using System.Numerics;
// ChatGPT 092602: capped prefix lattice for the old count (x=17,k=9,b=6) against explicit successor origins M=507 and M=456.
class P {
  static BigInteger Md(BigInteger a,BigInteger m){ var r=a%m; if(r<0) r+=m; return r; }
  static BigInteger FloorDiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); if(r<0) q-=1; return q; }
  static BigInteger CeilDiv(BigInteger a,BigInteger b)=>-FloorDiv(-a,b);
  static int EM; static BigInteger[] mn,mx; static long[] cnt; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; cnt[od]++; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Lattice(int k,int b,BigInteger x,BigInteger M,int j,out long tails,out BigInteger cands){ int L=k+b; BigInteger B=BigInteger.Pow(2,L)*x; int n=b-j; BigInteger Q=BigInteger.Pow(3,n), p3j=BigInteger.Pow(3,j), p3b=BigInteger.Pow(3,b); BigInteger d=n==0?0:Q-BigInteger.Pow(2,n); long tl=0; BigInteger cd=0; tails=0; cands=0; var t=new int[j];
    void Rec(int idx,int start){ if(idx==j){ BigInteger T=0; for(int i=0;i<j;i++) T+=BigInteger.Pow(3,j-1-i)*BigInteger.Pow(2,t[i]); int tt=j==0?L:t[0]; if(tt<n) return; if(!Md(B-T,p3j).IsZero) return; BigInteger u=n==0?0:BigInteger.Pow(2,tt-n)*d; BigInteger D=Md((B-T)/p3j,Q);
        BigInteger lo=BigInteger.Max(d,CeilDiv(B-T-p3b*M,p3j)), hi=BigInteger.Min(u,FloorDiv(B-T-p3b,p3j)); if(lo>hi) return; BigInteger first=lo+Md(D-lo,Q); BigInteger last=hi-Md(hi-D,Q); if(first>last) return; tl++; cd+=(last-first)/Q+1; return; }
      for(int s=start;s<L;s++){ t[idx]=s; Rec(idx+1,s+1); } }
    Rec(0,0); tails=tl; cands=cd; }
  static int CeilLog3(int v){ int j=0; long p=1; while(p<v){ p*=3; j++; } return j; }
  static void Main(string[] args){
    int K0=int.Parse(args[0]), K1=int.Parse(args[1]); var sw=System.Diagnostics.Stopwatch.StartNew();
    for(int k=K0;k<=K1;k++){ long Bd=(1L<<(k+1))-3; var xs=new System.Collections.Generic.HashSet<long>();
      for(long m=1;m<Bd;m++){ long y=m; int e=0; while(true){ if(e==k&&y>=3) xs.Add(y); if(e>k) break; if((y&1)==1) y=(3*y+1)>>1; else { if(e==k) break; y>>=1; e++; } } }
      long pairs=0,exceed=0,skipped=0; var hist=new System.Collections.Generic.SortedDictionary<int,int>(); int worstExtra=0; string worst="";
      foreach(long x in xs){ EM=k; mn=new BigInteger[40]; mx=new BigInteger[40]; cnt=new long[40]; Dfs(x,0,0);
        for(int b=0;b<39;b++){ if(mn[b]==0||mn[b+1]==0||b==0) continue; if(mn[b]>=Bd) continue; if(sw.ElapsedMilliseconds>200000){ skipped++; continue; } pairs++; BigInteger M=mn[b+1]; int jmin=-1; for(int j=0;j<=b;j++){ Lattice(k,b,x,M,j,out long tails,out BigInteger cands); if(tails==0){ jmin=j; break; } }
          if(jmin<0) jmin=b+1; if(!hist.ContainsKey(jmin)) hist[jmin]=0; hist[jmin]++; int bound=CeilLog3(k+b+1); if(jmin>bound){ exceed++; if(jmin-bound>worstExtra){ worstExtra=jmin-bound; worst=$"(x={x},k={k},b={b}: j_min={jmin} > ceil(log3(k+b+1))={bound})"; } } } }
      Console.WriteLine($"k={k}: exceptional pairs tested {pairs} (skipped by time {skipped}); j_min histogram: "+string.Join(", ",hist)+$"; pairs with j_min > ceil(log_3(k+b+1)): {exceed} {worst} [{sw.ElapsedMilliseconds/1000}s]"); }
  }
}
