using System;
using System.Collections.Generic;
// Independent checks: ChatGPT 091437 Theorems 1-3 and the H_8 distribution; Codex 091537 family n = 15, 79 mod 192.
class P {
  static long T(long x) => (x & 1) == 1 ? (3 * x + 1) / 2 : x / 2;
  static int H(long y, int j) { // max odd count over depth-j preimages (inverse recursion with memo-free DFS)
    var cur = new List<(long, int)> { (y, 0) };
    for (int t = 0; t < j; t++) { var nxt = new List<(long, int)>(cur.Count * 2); foreach (var (v, c) in cur) { nxt.Add((2 * v, c)); if (v % 3 == 2) nxt.Add(((2 * v - 1) / 3, c + 1)); } cur = nxt; }
    int m = 0; foreach (var (v, c) in cur) if (c > m) m = c; return m;
  }
  static void Main() {
    // Theorem 1 and 2 and the distribution at j = 8
    long per = 0, per_n = 0; var dist = new SortedDictionary<int, int>(); int maxClassBad = 0;
    for (int j = 1; j <= 7; j++) { long p3 = 1; for (int i = 0; i < j; i++) p3 *= 3; for (long y = 1; y <= 400; y++) { per_n++; if (H(y, j) != H(y + p3, j)) per++; bool isMax = H(y, j) == j; bool cls = ((y + 1) % p3) == 0; if (isMax != cls) maxClassBad++; } }
    { int j = 8; long p3 = 6561; for (long y = 1; y <= p3; y++) { int h = H(y, j); dist[h] = dist.GetValueOrDefault(h) + 1; if (h == j && ((y + 1) % p3) != 0) maxClassBad++; } }
    Console.WriteLine($"Thm 1 (period 3^j): {per_n} cases, failures {per}; Thm 2 (H=j iff y=-1 mod 3^j): failures {maxClassBad}; H_8 distribution over y=1..6561: " + string.Join(" ", dist));
    // Theorem 3: surplus persistence D_{j+1} >= D_j >= 0
    long cases = 0, bad = 0;
    for (long n = 1; n <= 250; n++) { long z = n; int a = 0; int prevD = 0; for (int j = 1; j <= 15; j++) { if ((z & 1) == 1) a++; z = T(z); int D = H(z, j) - a; cases++; if (D < 0 || D < prevD) bad++; prevD = D; } }
    Console.WriteLine($"Thm 3 (surplus persistence): {cases} (n,j) cases (n<=250, j<=15), failures {bad}");
    // Codex family
    long fam = 0, fbad = 0, otherHas5 = 0, otherCnt = 0;
    for (long n = 15; n <= 30000; n++) { long r = n % 192;
      if (r == 15 || r == 79) { fam++;
        // first depth with a smaller synchronous partner: brute-force over all m < n by forward iteration only for m = n-1 and check emptiness at depth<=5 via fibre of y
        long z = n, w = n - 1; int firstDepth = 0; for (int j = 1; j <= 6; j++) { z = T(z); w = T(w); if (z == w && firstDepth == 0) firstDepth = j; }
        // no smaller partner at depth <=5: enumerate fibre of y_j and require min = n
        bool noEarly = true; long yy = n; for (int j = 1; j <= 5 && noEarly; j++) { yy = T(yy); var cur = new List<long> { yy }; for (int t = 0; t < j; t++) { var nx = new List<long>(); foreach (var v in cur) { nx.Add(2 * v); if (v % 3 == 2) nx.Add((2 * v - 1) / 3); } cur = nx; } foreach (var v in cur) if (v < n) noEarly = false; }
        long y6 = n; int a6 = 0; for (int j = 0; j < 6; j++) { if ((y6 & 1) == 1) a6++; y6 = T(y6); }
        if (!(firstDepth == 6 && noEarly && a6 == 4 && H(y6, 6) == 4)) fbad++; }
      if (r == 143) { otherCnt++; long y6 = n; for (int j = 0; j < 6; j++) y6 = T(y6); if (H(y6, 6) >= 5) otherHas5++; } }
    Console.WriteLine($"Codex family n = 15, 79 mod 192 (n<=30000): {fam} cases, failures {fbad}; control n = 143 mod 192: {otherHas5} of {otherCnt} have a >=5-odd preimage");
  }
}
