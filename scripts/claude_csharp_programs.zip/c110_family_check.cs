using System;
using System.Numerics;
// Independent check of the C110 family (Codex note 182934):
// w = 1^r (01)^s 0, q = 3^(r+s) > p = 2^(r+2s+1); rho = 1 - 3^(s+1) * inv(2^(2s+1)) mod q.
// For n = rho mod q (n>=1): m = [p(n-1) + 2^r 3^(s+1)]/q - 1 is an integer, 0<m<n, has parity word w, and S^|w|(m) = n.
// Also: least r_s, and v_3(n-1) = s+1 for r = r_s.
class P {
  static BigInteger Inv(BigInteger a, BigInteger m) => BigInteger.ModPow(a % m, EulerPhi3(m) - 1, m);
  static BigInteger EulerPhi3(BigInteger m) { // m = 3^k
    BigInteger k = 0, t = m; while (t > 1) { t /= 3; k++; }
    return 2 * BigInteger.Pow(3, (int)k - 1);
  }
  static void Main(string[] a) {
    int Smax = int.Parse(a[0]); long checks = 0, bad = 0; var table = new System.Text.StringBuilder();
    for (int s = 0; s <= Smax; s++) {
      int rs = 2; while (!(BigInteger.Pow(3, rs + s) > BigInteger.Pow(2, rs + 2 * s + 1))) rs++;
      if (s <= 5) table.Append($"r_{s}={rs} ");
      for (int r = rs; r <= rs + 3; r++) {
        BigInteger q = BigInteger.Pow(3, r + s), p = BigInteger.Pow(2, r + 2 * s + 1);
        if (!(q > p)) { bad++; continue; }
        BigInteger rho = ((1 - BigInteger.Pow(3, s + 1) * Inv(BigInteger.Pow(2, 2 * s + 1), q)) % q + q) % q;
        string w = new string('1', r) + string.Concat(System.Linq.Enumerable.Repeat("01", s)) + "0";
        for (int t = 0; t < 12; t++) {
          BigInteger n = rho + q * t; if (n < 1) continue;
          checks++;
          BigInteger num = p * (n - 1) + BigInteger.Pow(2, r) * BigInteger.Pow(3, s + 1);
          if (!(num % q).IsZero) { bad++; continue; }
          BigInteger m = num / q - 1;
          bool ok = m > 0 && m < n;
          BigInteger x = m;
          foreach (char c in w) { bool odd = !x.IsEven; if (odd != (c == '1')) { ok = false; break; } x = odd ? (3 * x + 1) / 2 : x / 2; }
          if (ok && x != n) ok = false;
          if (r == rs) { BigInteger d = n - 1; int v = 0; if (d.IsZero) ok = false; else { while ((d % 3).IsZero) { d /= 3; v++; } if (v != s + 1) ok = false; } }
          if (!ok) bad++;
        }
      }
    }
    Console.WriteLine($"s=0..{Smax}, r=r_s..r_s+3, 12 values of t each: {checks} checks, failures {bad}; {table}");
  }
}
