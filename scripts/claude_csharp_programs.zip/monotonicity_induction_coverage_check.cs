using System;
using System.Collections.Generic;
using System.Numerics;
// (1) greedy formula R_e(x)=sum_{i<=e} v3(N_i), N_0=x+1, N_{i+1}=2^{a_i+1}u_i-1 vs exact recursion
// (2) monotonicity of H_k(x,r) in r at larger k and structured/large x; stronger ratio Q(r+1)<=(2/3)Q(r), Q=H+1
// (3) how often the minimising branch is at its own maximum (the only obstruction to the induction proof)
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int),int> rm=new(); static Dictionary<(BigInteger,int,int),BigInteger> hm=new();
  static BigInteger Y(BigInteger x,int a,int l)=>2*(B2(l)*(x+1)/B3(l)-1);
  static int R(BigInteger x,int k){ int a=V3(x+1); if(k==0) return a; if(rm.TryGetValue((x,k),out var v)) return v; int best=-1;
    for(int l=0;l<=a;l++){ int t=l+R(Y(x,a,l),k-1); if(t>best) best=t; } rm[(x,k)]=best; return best; }
  static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var t=H(Y(x,a,l),k-1,r-l); if(t!=INF && (best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static int Greedy(BigInteger x,int e){ BigInteger N=x+1; int s=0; for(int i=0;i<=e;i++){ int a=V3(N); s+=a; BigInteger u=N/B3(a); N=B2(a+1)*u-1; } return s; }
  static long series=0,viol=0,ratioViol=0,eq=0,atMaxMin=0,atMaxBad=0,greedyBad=0,greedyCells=0;
  static void Series(BigInteger x,int k){
    int Rk=R(x,k); series++;
    var h=new BigInteger[Rk+1]; for(int r=0;r<=Rk;r++) h[r]=H(x,k,r);
    for(int r=0;r<Rk;r++){ if(h[r+1]>h[r]) viol++; if(h[r+1]==h[r]) eq++; if(3*(h[r+1]+1)>2*(h[r]+1)) ratioViol++; }
  }
  static void Main(){
    long cells=0,covered=0,atTop=0; var dl=new Dictionary<int,long>(); long qViol=0;
    for(int x=1;x<=3000;x++){ for(int k=1;k<=6;k++){ int a=V3(x+1); int Rk=R(x,k);
       for(int r=0;r<Rk;r++){ cells++; BigInteger best=INF; var arg=new List<int>(); 
         for(int l=0;l<=Math.Min(a,r);l++){ var t=H(Y(x,a,l),k-1,r-l); if(t==INF) continue; if(best==INF||t<best){best=t;arg.Clear();arg.Add(l);} else if(t==best) arg.Add(l);} 
         bool anyNotTop=false; foreach(int l in arg){ if(r-l<R(Y(x,a,l),k-1)) anyNotTop=true; }
         if(anyNotTop) covered++; else { atTop++; BigInteger b2=INF; int a2=-1; for(int l=0;l<=Math.Min(a,r+1);l++){ var t=H(Y(x,a,l),k-1,r+1-l); if(t==INF) continue; if(b2==INF||t<b2){b2=t;a2=l;} } int d=a2-arg[0]; dl[d]=dl.GetValueOrDefault(d)+1; } } }
      hm.Clear(); if(rm.Count>2000000) rm.Clear(); }
    Console.WriteLine($"cells {cells}; covered by the easy induction step {covered}; remaining (all minimising branches at their top) {atTop}");
    foreach(var kv in dl) Console.WriteLine($"  next minimiser l' - l* = {kv.Key}: {kv.Value}");
  }
}
