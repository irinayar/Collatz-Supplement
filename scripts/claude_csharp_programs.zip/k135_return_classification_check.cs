using System;
using System.Collections.Generic;
using System.Numerics;
// Check Codex K135 (13:38). (a) all odd u in I=[n,H], H=floor((4n-2)/3): the 3-transition first returns (v1,v2 > H, w=F^3(u) in I) are exactly valuations (1,1,3) with u=55 mod 64 and (1,2,2) with u=43 mod 64; rho formulas exact.
// (b) actual no-first-descent trajectories: chains from n to a low visit u_m using only gaps 2 and 3: G (inputs before u_m) < 32/27, G = Phi(n)/Phi(u_m) * prod rho  (exact rational); and with <=2 further inputs G<3200/2187.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long cnt3=0,bad=0; long[] byType=new long[2];
    for(long n=3;n<=6001;n+=2){ long H=(4*n-2)/3;
      for(long u=n;u<=H;u+=2){ int e1,e2,e3; long v1=A(u,out e1), v2=A(v1,out e2), w=A(v2,out e3);
        if(v1>H && v2>H && w>=n && w<=H){ cnt3++; 
          bool t113=(e1==1&&e2==1&&e3==3&&u%64==55), t122=(e1==1&&e2==2&&e3==2&&u%64==43);
          if(!(t113||t122)) { bad++; continue; } if(t113) byType[0]++; else byType[1]++;
          long B= t113? 19:23; // w=(27u+B)/32, rho=1+(B+25)/(27(u+5))
          if(32*w!=27*u+B) bad++; BigInteger lhs=(BigInteger)32*(w+5)*27*(u+5)*1, rhs=(BigInteger)(27*(u+5)+B+25)*27*(u+5); // rho = d(w+5)/(a(u+5)) = (27(u+5)+B+25)/(27(u+5))
          if(BigInteger.Compare((BigInteger)32*(w+5)*27*(u+5), (BigInteger)(27*(u+5)+B+25)*27*(u+5))!=0) bad++; }
        // also: any u with e-pattern (1,1,3)/(1,2,2) is it a return? not required.
      } }
    Console.WriteLine($"(a) 3-transition first returns found {cnt3} (type113 {byType[0]}, type122 {byType[1]}), violations {bad}");
    long chains=0,badB=0,withReset=0,badTail=0; double maxG=0; long skippedDup=0;
    for(long n=3;n<=100001;n+=2){ long H=(4*n-2)/3; long x=n; var inputs=new List<long>(); var low=new List<int>(); int r=0;
      for(int step=0;step<4000;step++){ if((x&1)==1){ if(x<=H) low.Add(r); inputs.Add(x); r++; int e; long nx=A(x,out e); x=nx; if(x<n) break; } else { x/=2; if(x<n) break; } }
      // chain = prefix up to low visit k such that all gaps among low[0..k] are 2 or 3
      for(int k=0;k<low.Count;k++){ bool ok=true; for(int i=0;i<k;i++){ int gp=low[i+1]-low[i]; if(gp!=2&&gp!=3) ok=false; } if(!ok) break; 
        int idx=low[k]; double G=1; for(int i=0;i<idx;i++) G*=1.0+1.0/(3.0*inputs[i]); chains++; if(G>maxG) maxG=G; if(!(G<32.0/27)) badB++;
        // reset sources distinctness (hypothesis): check distinct departure states of 3-gaps; count skipped if not distinct
        var seen=new HashSet<long>(); bool dup=false; for(int i=0;i<k;i++) if(low[i+1]-low[i]==3){ withReset++; if(!seen.Add(inputs[low[i]])) dup=true; } if(dup) skippedDup++;
        // tail: up to two further inputs after u_m (inputs idx, idx+1) if present
        for(int t=1;t<=2 && idx+t<=inputs.Count;t++){ double G2=G; for(int i=0;i<t;i++) G2*=1.0+1.0/(3.0*inputs[idx+i]); if(!(G2<3200.0/2187)) badTail++; } }
    }
    Console.WriteLine($"(b) chains (gaps 2/3 only) {chains}, max G {maxG:F6} (bound 32/27={32.0/27:F6}), violations {badB}, tail violations {badTail}, 3-gap steps {withReset}, chains with repeated reset source {skippedDup}");
  }
}
