using System;
// EXPLORATORY (double precision, not a certificate): global b-block constants B_b for H and window W via the induction f(W)*B_(b-1) <= B_b, and the resulting odd-count range with Q = 2^61/(3^32*993).
class P {
  static long F(long u){ long t=3*u+1; while((t&1)==0) t>>=1; return t; }
  static void Main(string[] args){
    long H=long.Parse(args[0]), W=long.Parse(args[1]); int bmax=int.Parse(args[2]); double lnQ=Math.Log(2305843009213693952.0/1840049047529878113.0); double ln15=Math.Log(1.5);
    var lnB=new double[bmax+1]; var sw=System.Diagnostics.Stopwatch.StartNew(); 
    // one pass: for every odd start u in (H,W) compute prefix sums of log f along the F-chain while states stay > H, up to bmax steps
    var best=new double[bmax+1]; var argb=new long[bmax+1];
    for(long u=H+2;u<W;u+=2){ long cur=u; double s=0; for(int i=1;i<=bmax;i++){ if(cur<=H) break; s+=Math.Log(1.0+1.0/(3.0*cur)); cur=F(cur); if(s>best[i]){ best[i]=s; argb[i]=u; } } }
    bool allInd=true; for(int b=1;b<=bmax;b++){ lnB[b]=best[b]; double tail=Math.Log(1.0+1.0/(3.0*W))+lnB[b-1]; bool ind=tail<=lnB[b]; if(!ind) allInd=false; Console.WriteLine($"b={b}: B_b - 1 = {Math.Exp(lnB[b])-1:E4} (times H: {(Math.Exp(lnB[b])-1)*H:F4}) at start {argb[b]}; induction f(W)*B_(b-1) <= B_b: {ind}"); }
    // range: choose block length b* maximizing r_max
    double bestR=0; int bestB=0; for(int b=1;b<=bmax;b++){ if(!(Math.Log(1.0+1.0/(3.0*W))+lnB[b-1]<=lnB[b])) continue; // valid only where the induction holds up to b
        bool valid=true; for(int c=1;c<=b;c++) if(!(Math.Log(1.0+1.0/(3.0*W))+lnB[c-1]<=lnB[c])) valid=false; if(!valid) continue; double r=(ln15-lnQ)/lnB[b]*b; if(r>bestR){ bestR=r; bestB=b; } }
    double simple=(ln15-lnQ)/Math.Log(1.0+1.0/(3.0*(H+2)));
    Console.WriteLine($"H={H}, W={W}: simple per-input range {simple:F0}; best block range {bestR:F0} with block length {bestB} (gain {bestR/simple:F2}x); all inductions hold: {allInd}; {sw.ElapsedMilliseconds/1000}s");
  }
}
