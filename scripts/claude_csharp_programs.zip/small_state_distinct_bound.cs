using System;
using System.Numerics;
// ChatGPT 093810 (r<=21 via 16 small distinct odd states + f(37)^5) and the improvement from the larger verified set: every odd u<2^32 reaches 1 (my stopping-time DP), so odd inputs below 2^32 are pairwise distinct;
// G <= prod_{j<r} f(5+2j) for r <= 2^31 (any state >= 2^32 contributes less than the smallest unused small factor). Find the largest r with this product < 3/2.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Lt(Fr a,Fr b)=>a.n*b.d<b.n*a.d; public override string ToString()=>n+"/"+d; }
  static void Main(){
    // (1) ChatGPT's bound
    Fr B=new Fr(1,1); for(int u=5;u<=35;u+=2) B=B*new Fr(3*u+1,3*u); Fr f37=new Fr(112,111); Fr P=B; for(int i=0;i<5;i++) B=B*f37; Console.WriteLine($"(1) P = prod_(u=5,7..35) f(u) = {P} ; B = P*f(37)^5 = {B} = {(double)B.n/(double)B.d:F16}; B<3/2: {Fr.Lt(B,new Fr(3,2))}");
    Console.WriteLine("   P = " + P.n + "/" + P.d + " (ChatGPT: 438649304907776/306436047081885); B numerator " + B.n + " (ChatGPT: 1104357077636685680869376)");
    // (2) forward orbits of the 16 starts reach 1
    int ok=0; for(int u=5;u<=35;u+=2){ BigInteger n=u; int steps=0; while(n!=1&&steps<1000){ n=n.IsEven?n/2:(3*n+1)/2; steps++; } if(n==1) ok++; } Console.WriteLine($"(2) odd u=5..35 whose forward orbit reaches 1: {ok}/16");
    // (3) largest r with prod_{j<r} f(5+2j) < 3/2
    Fr G=new Fr(1,1); int rmax=0; for(int r=1;r<=200;r++){ int u=5+2*(r-1); G=G*new Fr(3*u+1,3*u); if(Fr.Lt(G,new Fr(3,2))) rmax=r; else { Console.WriteLine($"(3) product of the r smallest odd states >= 5: below 3/2 for r <= {rmax}; at r={r} it is {(double)G.n/(double)G.d:F6} >= 3/2 (last factor f({u}))"); break; } }
  }
}
