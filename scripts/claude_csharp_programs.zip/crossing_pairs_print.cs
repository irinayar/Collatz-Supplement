using System;
using System.Collections.Generic;
using System.Linq;
// print the crossing pairs (chord type, excursion index, position) for chosen words (given as run blocks r,d,r,d,...), with values
static class P {
  static void Main(string[] args) {
    foreach (var spec in args) {
      var nums = spec.Split(',').Select(int.Parse).ToList(); var bits = new List<bool>(); var exc = new List<int>(); int ex = 0;
      for (int i = 0; i < nums.Count; i += 2) { for (int j = 0; j < nums[i]; j++) { bits.Add(true); exc.Add(ex); } for (int j = 0; j < nums[i + 1]; j++) { bits.Add(false); exc.Add(ex); } ex++; }
      int L = bits.Count; var e = bits.ToArray(); int A = e.Count(b => b); var p2 = System.Numerics.BigInteger.Pow(2, L); var p3 = System.Numerics.BigInteger.Pow(3, A); if (p3 >= p2) { Console.WriteLine(spec + ": 3^A>=2^L"); continue; }
      System.Numerics.BigInteger U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + (System.Numerics.BigInteger.One << i);
      var D = p2 - p3; var scale = D * p2; var X = new System.Numerics.BigInteger[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = (e[i] ? 3 * X[i] + scale : X[i]) / 2;
      double[] x = X.Select(v => (double)v / (double)scale).ToArray();
      var odd = Enumerable.Range(0, L).Where(i => e[i]).OrderBy(i => X[i]).ToList(); var even = Enumerable.Range(0, L).Where(i => !e[i]).OrderByDescending(i => X[i]).ToList(); var rank = new int[L]; int rk = 0; foreach (var i in odd) rank[i] = rk++; foreach (var i in even) rank[i] = rk++;
      Console.WriteLine($"word {spec}: L={L} A={A}, values " + string.Join(" ", Enumerable.Range(0, L).Select(i => (e[i] ? "o" : "e") + x[i].ToString("F2"))));
      string T(int i) { int j = (i + 1) % L; return e[i] ? (e[j] ? "A" : "P") : (e[j] ? "V" : "D"); }
      for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) { if (j == i + 1 || (i == 0 && j == L - 1)) continue; double pa = rank[i], pb = rank[(i + 1) % L], qa = rank[j], qb = rank[(j + 1) % L]; double lo = Math.Min(pa, pb), hi = Math.Max(pa, pb); bool inA = qa > lo && qa < hi, inB = qb > lo && qb < hi; if (inA != inB) Console.WriteLine($"   {T(i)}[{x[i]:F2}->{x[(i + 1) % L]:F2}](exc {exc[i]}) x {T(j)}[{x[j]:F2}->{x[(j + 1) % L]:F2}](exc {exc[j]})"); }
    }
  }
}
