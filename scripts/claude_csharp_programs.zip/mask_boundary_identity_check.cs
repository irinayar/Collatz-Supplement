using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent check of the mask-boundary identity (A),(B) (ChatGPT 09:28, 2026-11-24) on random odd-to-odd complete-run chains with random masks.
class P {
 struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator-(F x,F y)=>new F(x.n*y.d-y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static F operator/(F x,F y)=>new F(x.n*y.d,x.d*y.n);
  public static bool operator==(F x,F y)=>x.n==y.n&&x.d==y.d; public static bool operator!=(F x,F y)=>!(x==y); public override bool Equals(object o)=>o is F f&&this==f; public override int GetHashCode()=>0; public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d; public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; }
 static F Fr(BigInteger a,BigInteger b)=>new F(a,b);
 static void Main(){ var rnd=new Random(20261124); int okA=0,okB=0,okC=0,tot=0,multi=0;
  for(int it=0;it<3000;it++){ BigInteger a=rnd.Next(1,100000)|1; var st=new List<BigInteger>{a}; var beta=new List<F>(); int N=rnd.Next(1,16);
    for(int j=0;j<N;j++){ BigInteger x=a; int s=0,e=0; while(true){ BigInteger z=3*x+1; int v=0; while(z%2==0){z>>=1;v++;} x=z; s++; e=v; if(v>=2) break; } beta.Add(Fr(BigInteger.Pow(3,s)-BigInteger.Pow(2,s),BigInteger.Pow(3,s))); st.Add(x); a=x; }
    int[] I=new int[N]; for(int j=0;j<N;j++) I[j]=rnd.Next(2); F kappa=Fr(rnd.Next(1,100),rnd.Next(100,200));
    var dl=new F[N]; var f=new F[N]; var t=new F[N]; var c=new F[N]; for(int j=0;j<N;j++){ dl[j]=beta[j]/Fr(st[j],1); f[j]=Fr(1,st[j])-Fr(1,st[j+1]); t[j]=kappa*dl[j]+f[j]; var m=Fr(0,1)-f[j]-dl[j]/Fr(15,1); c[j]=m>Fr(0,1)?m:Fr(0,1); }
    F Z=Fr(0,1); for(int j=0;j<N;j++){ var h=t[j]+c[j]; Z=Z+(Fr(0,1)-c[j])+(I[j]==1?h:Fr(0,1)); }
    F A=Fr(0,1); for(int j=0;j<N;j++) if(I[j]==1) A=A+kappa*dl[j]; A=A+Fr(I[0],st[0])-Fr(I[N-1],st[N]); for(int j=1;j<N;j++) A=A+Fr(I[j]-I[j-1],st[j]); for(int j=0;j<N;j++) if(I[j]==0) A=A-c[j];
    F B=Fr(0,1); for(int j=0;j<N;j++) if(I[j]==1) B=B+kappa*dl[j]; int nb=0; int jj=0; while(jj<N){ if(I[jj]==1){ int k=jj; while(k+1<N&&I[k+1]==1) k++; B=B+Fr(1,st[jj])-Fr(1,st[k+1]); jj=k+1; nb++; } else jj++; } for(int j=0;j<N;j++) if(I[j]==0) B=B-c[j];
    tot++; if(Z==A) okA++; if(Z==B) okB++; if(nb>1) multi++;
    // (C): Z <= kappa*sum delta + sum_q 1/a_{l_q}
    F C=Fr(0,1); for(int j=0;j<N;j++) if(I[j]==1) C=C+kappa*dl[j]; jj=0; while(jj<N){ if(I[jj]==1){ int k=jj; while(k+1<N&&I[k+1]==1) k++; C=C+Fr(1,st[jj]); jj=k+1; } else jj++; } if(!(Z>C)) okC++; }
  Console.WriteLine("random chains: "+tot+" (with several core blocks: "+multi+"); identity (A): "+okA+"/"+tot+"; block form (B): "+okB+"/"+tot+"; bound (C): "+okC+"/"+tot); }}
