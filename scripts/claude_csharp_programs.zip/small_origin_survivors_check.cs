using System;
using System.Numerics;
// ChatGPT 210935: the 56 survivors of the two filters (k<=8, r<=6): difference range, first k, max m, and the necessary inequality 2^(r+k)(x+1) < 3^(r+1)(2^k-1).
class P {
  static BigInteger[,] mn; static void Dfs(BigInteger z,int ev,int od){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z; if(ev<8) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long surv=0,ineqBad=0; BigInteger dMin=BigInteger.Parse("1000000000"), dMax=-BigInteger.Parse("1000000000"), maxM=0; int minK=99; var dom=new long[7]; for(int r=0;r<=6;r++){ long p=1; for(int i=0;i<=r;i++) p*=3; dom[r]=p+2; }
    long lo=0, hi=0; var kc=new long[9]; long xMax=0; string list="";
    for(long x=3;x<=dom[6];x++){ mn=new BigInteger[9,100]; Dfs(x,0,0);
      for(int r=0;r<=6;r++){ if(x>dom[r]) continue; for(int k=0;k<=8;k++){ var h0=mn[k,r]; var h1=mn[k,r+1]; if(h0==0||h1==0) continue; if(h0%3==2) continue; if(k>=1&&h0>=BigInteger.Pow(2,k+1)-3) continue;
          surv++; var D=h1-h0; if(D<dMin) dMin=D; if(D>dMax) dMax=D; if(h0>maxM) maxM=h0; if(k<minK) minK=k; kc[k]++; if(x>xMax) xMax=x;
          if(!(BigInteger.Pow(2,r+k)*(x+1) < BigInteger.Pow(3,r+1)*(BigInteger.Pow(2,k)-1))) ineqBad++; } } }
    Console.WriteLine($"survivors {surv}; difference range [{dMin},{dMax}]; smallest k {minK}; max m {maxM}; largest x {xMax}; necessary inequality fails for {ineqBad}; survivors by k: " + string.Join(",",kc));
  }
}
