using System;
using System.Collections.Generic;
// Monotonicity of min origin H_k(x,r) in r (k up to 9) by plain inverse-tree DFS (no recursion formula), x up to a limit, with time guard.
class P {
  static int EMAX=12; static long[,] mn; static long nodes;
  static void Dfs(long z,int ev,int od){ nodes++; if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z;
    if(ev<EMAX && z<(1L<<58)) Dfs(2*z,ev+1,od);
    if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    var sw=System.Diagnostics.Stopwatch.StartNew(); long series=0,viol=0,eq=0; string ex=""; long lastX=0;
    for(long x=1;x<=4000000;x++){ if(sw.ElapsedMilliseconds>150000) break; mn=new long[EMAX+1,64]; nodes=0; Dfs(x,0,0); lastX=x;
      for(int k=6;k<=EMAX;k++){ int R=-1; for(int r=0;r<64;r++) if(mn[k,r]!=0) R=r; series++; for(int r=0;r<R;r++){ if(mn[k,r+1]>mn[k,r]){ viol++; if(ex=="") ex="x="+x+",k="+k+",r="+r; } if(mn[k,r+1]==mn[k,r]) eq++; } } }
    Console.WriteLine("DFS min-origin monotonicity, k=6..12, x=1.." + lastX + ": series " + series + ", increases " + viol + ", equalities " + eq + " " + ex + " (" + sw.ElapsedMilliseconds/1000 + " s)");
  }
}
