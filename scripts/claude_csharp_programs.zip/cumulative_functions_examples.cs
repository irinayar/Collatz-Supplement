using System;
using System.Linq;
static class P {
  static void Main(string[] args) {
    foreach (string ws in args) {
      int L = ws.Length; bool[] e = ws.Select(ch => ch == '1').ToArray(); int A = e.Count(b => b);
      System.Numerics.BigInteger p2 = System.Numerics.BigInteger.Pow(2, L), p3 = System.Numerics.BigInteger.Pow(3, A);
      if (p3 >= p2) { Console.WriteLine(ws + ": 3^A >= 2^L"); continue; }
      System.Numerics.BigInteger U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + System.Numerics.BigInteger.Pow(2, i);
      double D = (double)(p2 - p3); double x0 = (double)U / D; var x = new double[L]; x[0] = x0;
      for (int i = 0; i + 1 < L; i++) x[i + 1] = e[i] ? (3 * x[i] + 1) / 2 : x[i] / 2;
      double c = x.Min(), H = x.Max(), m = (c + H) / 2;
      var px = new double[L]; var py = new double[L];
      for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (Math.Abs(x[i] - c) < 1e-12 || Math.Abs(x[i] - H) < 1e-12) ? 0 : (e[i] ? yy : -yy); }
      var d = new double[L]; for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; d[i] = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by) / (2 * Math.PI); }
      Console.WriteLine($"word {ws} (cyclic, 1 = odd), L={L}, A={A}, c={c:F4}, H={H:F4}");
      Console.WriteLine("  vertex values: " + string.Join(" ", x.Select(v => v.ToString("F3"))));
      Console.WriteLine("  central angle of chord j (units of 2pi): " + string.Join(" ", d.Select(v => v.ToString("F3"))) + $"  | sum = {d.Sum():F3}");
      for (int s = 0; s < L; s++) { double cur = 0; var cum = new System.Collections.Generic.List<string>(); for (int t = 1; t <= L; t++) { cur += d[(s + t - 1) % L]; cum.Add(cur.ToString("F3")); } Console.WriteLine($"  start {s}: Phi_s(t), t=1..L: " + string.Join(" ", cum)); }
    }
  }
}
