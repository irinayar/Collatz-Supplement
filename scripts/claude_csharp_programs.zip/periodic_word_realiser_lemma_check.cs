using System;
using System.Numerics;
using System.Collections.Generic;
// Lemma P (periodic words): for a valuation word W (a odd inputs, total E, D=2^E-3^a, U from y'=(3^a y+U)/2^E), any odd x whose first N*a transitions
// realise W^N (exact valuations) satisfies 2^(E N) | (D x - U); hence x=U/D (cycle point) or |D x - U| >= 2^(E N), i.e. x >= (2^(EN)-|U|)/|D|.
// Test: all words with a<=4, e_i in 1..4, N=1..5: least positive odd realiser via cylinder, replay, compare with the bound.
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=a%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} if(t0<0)t0+=m; return t0; }
  static void Main(){
    long words=0, viol=0, cycleWords=0, checks=0; 
    var cyc=new List<string>();
    for(int a=1;a<=4;a++){
      int tot=1; for(int i=0;i<a;i++) tot*=4;
      for(int code=0;code<tot;code++){
        var w=new int[a]; int c=code; for(int i=0;i<a;i++){ w[i]=1+c%4; c/=4; }
        int E=0; foreach(var v in w) E+=v;
        BigInteger U=0,Pp=1; foreach(var v in w){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }  // after one rep: 2^E y' = 3^a y + U
        BigInteger D=(BigInteger.One<<E)-BigInteger.Pow(3,a); words++;
        bool intStar = !D.IsZero && (U%D).IsZero && U/D>0; if(intStar){ cycleWords++; cyc.Add(string.Join(",",w)+$" u*={U/D}"); }
        for(int N=1;N<=5;N++){
          var e=new List<int>(); for(int k=0;k<N;k++) e.AddRange(w); int r=e.Count; int EE=E*N;
          BigInteger UU=0,P2=1; foreach(var v in e){ UU=3*UU+P2; P2*=(BigInteger.One<<v); }
          BigInteger M=BigInteger.One<<EE; BigInteger x0=((-UU)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
          // candidate odd starts congruent x0 mod 2^EE: x0 + k*M, lift to also require final state odd (mod 2^(EE+1)); take least positive satisfying replay
          BigInteger best=-1;
          for(int k=0;k<4 && best<0;k++){ BigInteger x=x0+k*M; if(x<=0) continue; if(x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) best=x; }
          if(best<0) continue; checks++;
          BigInteger lhs=BigInteger.Abs(D*best-U); bool divisible=(lhs % (BigInteger.One<<EE)).IsZero; bool star=(D*best==U);
          if(!divisible) { viol++; Console.WriteLine($"DIVISIBILITY FAIL word {string.Join(",",w)} N={N} x={best}"); }
          if(!star && best*BigInteger.Abs(D)+BigInteger.Abs(U) < (BigInteger.One<<EE)) { viol++; Console.WriteLine($"BOUND FAIL word {string.Join(",",w)} N={N} x={best}"); }
        }
      }
    }
    Console.WriteLine($"words {words}, (word,N) realiser checks {checks}, violations {viol}, words with positive integer u*={cycleWords}");
    foreach(var s in cyc) Console.WriteLine("  integer u*: "+s);
  }
}
