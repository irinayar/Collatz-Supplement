using System;
using System.Collections.Generic;
using System.Numerics;
// Short part of the four-reset bound: rebuild the 713 positive profiles (g=3,5,7,8,9,10: 2,7,30,85,113,476) by witness search and sum T_p(N) of eq. (8) at N=65535.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Tuples(int len,int E,List<int[]> outL){ var cur=new int[len]; void Rec(int p,int s){ if(p==len){ if(s==E&&cur[len-1]>=2) outL.Add((int[])cur.Clone()); return; } for(int v=1;v<=E-s;v++){ if(p==0&&v!=1) continue; cur[p]=v; Rec(p+1,s+v); } } Rec(0,0); }
  static long Residue(int[] ev,long mod){ for(long r=1;r<mod;r+=2){ long x=r; bool ok=true; for(int i=0;i<ev.Length;i++){ int e; x=A(x,out e); if(e!=ev[i]){ok=false;break;} } if(ok) return r; } return -1; }
  static void Main(){
    double N=65535; int[] gs={3,5,7,8,9,10}; int[] Es={5,8,11,13,14,16}; double total=0; int count=0; var counts=new List<int>(); int allDecr=0;
    for(int gi=0;gi<gs.Length;gi++){ int g=gs[gi],E=Es[gi]; var tup=new List<int[]>(); Tuples(g,E,tup); long M=1L<<(E+1); int c0=0;
      foreach(var ev in tup){ long r=Residue(ev,M); bool found=false; for(long t=0;t<=100&&!found;t++){ long u=r+M*t; long x=u; long[] v=new long[g+1]; v[0]=u; bool ok=true; for(int j=1;j<=g;j++){ int e; x=A(x,out e); if(e!=ev[j-1]){ok=false;break;} v[j]=x; } if(!ok) continue; long w=v[g]; long mx=Math.Max(u,w); long lo=Math.Max(3,(3*mx+2+3)/4); if((lo&1)==0) lo++; long hi=Math.Min(u,w); for(int j=1;j<g;j++) hi=Math.Min(hi,(3*v[j]+1)/4); if(lo<=hi) found=true; }
        if(!found) continue; BigInteger Bn=0; int Ea=0; var Bs=new BigInteger[g+1]; var Esa=new int[g+1]; for(int i=0;i<g;i++){ Bs[i+1]=3*Bs[i]+(BigInteger.One<<Esa[i]); Esa[i+1]=Esa[i]+ev[i]; }
        BigInteger cn=Bs[g]+5*((BigInteger.One<<E)-BigInteger.Pow(3,g)); if(cn<=0) continue; c0++; double Dg=Math.Pow(2,E)/Math.Pow(3,g), Qg=(double)Bs[g]/Math.Pow(3,g); double c=Qg+5*(Dg-1);
        // lower lines
        double l=1,del=0; double sl=Dg,of=Qg; if(sl>l+1e-15||(Math.Abs(sl-l)<1e-15&&of<del)){l=sl;del=of;}
        for(int i=1;i<g;i++){ double Di=Math.Pow(2,Esa[i])/Math.Pow(3,i), Qi=(double)Bs[i]/Math.Pow(3,i); double s2=4.0/3*Di, o2=4.0/3*Di+Qi; if(s2>l+1e-15||(Math.Abs(s2-l)<1e-15&&o2<del)){l=s2;del=o2;} }
        // upper lines: u<=4n/3-2/3 ; u<=(4/3)D n-((2/3)D+Q)
        double r1=4.0/3, e1=2.0/3, r2=4.0/3*Dg, e2=2.0/3*Dg+Qg; double rr,ee; if(r2<r1-1e-15||(Math.Abs(r2-r1)<1e-15&&e2>e1)){rr=r2;ee=e2;} else {rr=r1;ee=e1;}
        double Mm=(double)M; double T=c*((rr-l)*N+Mm+del-ee)/(Mm*(l*N+5-del)); total+=T; count++; if(!(rr>l)) allDecr++; }
      counts.Add(c0); }
    Console.WriteLine($"positive profiles by gap (3,5,7,8,9,10): {string.Join(",",counts)}; total {count} (claimed 713); sum T_p(65535) = {total:F9} (claimed < 0.032661310); lines with r<=l: {allDecr}; long 0.038518030 + short = {0.038518030+total:F9} (claimed 0.071179340245)");
  }
}
