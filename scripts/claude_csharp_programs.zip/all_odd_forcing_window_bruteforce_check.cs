using System; using System.Numerics; using System.Collections.Generic;
// Independent brute-force test of the all-odd-prefix residue window (ChatGPT forcing barrier, 21:43):
// for odd n with first j shortcut inputs odd, x_j=(3/2)^j(n+1)-1; every positive m reaching x_j in t steps with r odd inputs (r=j+p, p>=1), d=t-r even inputs satisfies
//   1 <= m_p <= rho(s+1)-1-(2^d-1)(2/3)^(j+p),  m_p = m-2^(p+d) floor(n/3^p), s=n mod 3^p, rho=2^(p+d)/3^p   (R)
// and r<=j implies m>=n; and for m<n: r>=j+v_3(n)+1.
class P { static void Main(){
  long M=4000000; int maxT=72;
  var targets=new Dictionary<long,List<(int n,int j)>>();
  for(int n=3;n<=1001;n+=2){ int j=0; while(((n+1)>>j)%2==0) j++; // v2(n+1)
    for(int jj=1;jj<=j;jj++){ BigInteger x=BigInteger.Pow(3,jj)*(n+1)/BigInteger.Pow(2,jj)-1; long xv=(long)x; if(!targets.ContainsKey(xv)) targets[xv]=new List<(int,int)>(); targets[xv].Add((n,jj)); } }
  long maxX=0; foreach(var k in targets.Keys) if(k>maxX) maxX=k;
  var big=new bool[maxX+1]; foreach(var k in targets.Keys) big[k]=true;
  long hits=0, withExtra=0, bad=0, badSmall=0, checkedSmaller=0;
  for(long m=1;m<=M;m++){ long x=m; int r=0; for(int t=0;t<=maxT;t++){
      if(x<=maxX && big[x] && targets.TryGetValue(x,out var lst)){ foreach(var (n,j) in lst){ hits++; int d=t-r;
          if(r<=j){ if(m<n) {bad++; Console.WriteLine($"BAD(4) n={n} j={j} m={m} r={r}");} }
          else { int p=r-j; withExtra++; BigInteger q=BigInteger.Pow(3,p); BigInteger fl=n/q; BigInteger s=n-q*fl; BigInteger mp=m-BigInteger.Pow(2,p+d)*fl;
             // 1<=mp ; mp*3^(j+p) <= 2^(p+d)(s+1)3^j - 3^(j+p) - (2^d-1)2^(j+p)
             BigInteger rhs=BigInteger.Pow(2,p+d)*(s+1)*BigInteger.Pow(3,j)-BigInteger.Pow(3,j+p)-(BigInteger.Pow(2,d)-1)*BigInteger.Pow(2,j+p);
             if(!(mp>=1 && mp*BigInteger.Pow(3,j+p)<=rhs)){ bad++; if(bad<10) Console.WriteLine($"BAD(R) n={n} j={j} m={m} t={t} r={r} mp={mp}"); }
             if(m<n){ checkedSmaller++; int P3=0; int nn=n; while(nn%3==0){P3++; nn/=3;} if(r<j+P3+1){ badSmall++; Console.WriteLine($"BAD(smaller) n={n} j={j} m={m} r={r} P={P3}"); } } } } }
      if(x%2==1){ x=(3*x+1)/2; r++; } else x/=2; if(x>2000000000000L) break; if(x==1 && t>3) break; } }
  Console.WriteLine($"targets {targets.Count} values; hits {hits}; hits with extra odd input {withExtra}; smaller-origin hits {checkedSmaller}; violations of (4)/(R): {bad}; violations of 'smaller origin needs >= j+v3(n)+1 odd': {badSmall}");
}}
