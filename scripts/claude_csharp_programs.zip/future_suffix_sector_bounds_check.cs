using System; using System.Numerics; using System.Collections.Generic;
// Exact replay of the Future Suffix sector arithmetic (ChatGPT 21:41-22:10, 2026-11-23).
class P {
 struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator-(F x,F y)=>new F(x.n*y.d-y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static F operator/(F x,F y)=>new F(x.n*y.d,x.d*y.n);
  public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d;
  public override string ToString()=>$"{n}/{d}";
  public double D(){ int sh=Math.Max(0,(int)Math.Max(n.GetBitLength(),d.GetBitLength())-900); return (double)(n>>sh)/(double)(d>>sh);} }
 static F Fr(long a,long b)=>new F(a,b);
 static F Pw(F x,int k){ F r=Fr(1,1); for(int i=0;i<k;i++) r=r*x; return r; }
 static void Main(){
  // ---- R/C phase table: words in {R,C}^j, j<=7. state (A,V,D). Survive iff every prefix has D<A (coefficient <1).
  // R=(2,2): s=2,e=2 ; C=(5,4): s=5,e=4.  (A,V,D)->(3^s A, 3^s V+(3^s-2^s)D, 2^(s+e-1) D)
  var T=new (int s,int e)[]{(2,2),(5,4)};
  var level=new List<(BigInteger A,BigInteger V,BigInteger D,string w)>{(1,0,1,"")};
  Console.WriteLine("R/C table: prior runs j | survivors | max phase (as exact fraction, decimal) | maximizer");
  for(int j=1;j<=7;j++){
   var nxt=new List<(BigInteger,BigInteger,BigInteger,string)>(); F mx=Fr(0,1); string mw="";
   foreach(var (A,V,D,wd) in level){ for(int t=0;t<2;t++){ var (s,e)=T[t]; BigInteger p3=BigInteger.Pow(3,s),p2=BigInteger.Pow(2,s);
      var A2=p3*A; var V2=p3*V+(p3-p2)*D; var D2=BigInteger.Pow(2,s+e-1)*D; // cut test: first D>A would allow proper height only if u<V/(D-A)<2^71
      if(D2>A2){ var bound=new F(V2,D2-A2); if(!(bound<new F(BigInteger.One<<71,1))){Console.WriteLine("CUT BOUND FAILS "+wd);} continue; }
      if(D2==A2){Console.WriteLine("EQUALITY?!");}
      nxt.Add((A2,V2,D2,wd+(t==0?"R":"C"))); F q=new F(V2,A2); if(mx<q){mx=q;mw=wd+(t==0?"R":"C");} } }
   level=nxt; Console.WriteLine($"{j} | {level.Count} | {mx} ~ {mx.D():F6} | {mw}  (<5: {mx<Fr(5,1)})"); }
  // ---- six-type final bound (19)
  F K0=new F((BigInteger.One<<71)+1,4*(BigInteger.One<<71)-1);
  F rho=Fr(19017,131072), eta=Fr(22690,177147), om=new F(1194665107,BigInteger.Parse("23219011584")), cS=Fr(1043216,177147);
  F D6=new F(4723505,BigInteger.One<<75), D7=new F(BigInteger.Parse("54676993561995995"),BigInteger.One<<98), D8=new F(BigInteger.Parse("129202771513994966674259"),BigInteger.One<<116);
  F s1=K0*om*(D6+D7+D8+Pw(rho,9)/(Fr(1,1)-rho));
  F s2=Fr(6,5)*cS*new F(BigInteger.Pow(6,14),BigInteger.One<<71);
  F s3=om*Fr(224,5)*Fr(128,1)*Pw(eta,14);
  F tot=s1+s2+s3; Console.WriteLine($"six-type terms {s1.D():E12} {s2.D():E12} {s3.D():E12}; total {tot.D():E15}; < 8e-10: {tot<Fr(8,10000000000)}");
  // ---- R/C final bound (20)
  F r=Fr(33,256), d=Fr(28,243), w=Fr(299,6912), cc=Fr(40,27);
  F a1=K0*w*Pw(r,8)/(Fr(1,1)-r), a2=Fr(2,1)*cc*Fr(8192*72,1)/new F(BigInteger.One<<71,1), a3=w*Fr(224,5)*Pw(d,12)/Fr(72*72,1);
  F tot2=a1+a2+a3; Console.WriteLine($"R/C terms {a1.D():E15} {a2.D():E15} {a3.D():E15}; total {tot2.D():E15}; < 1e-9: {tot2<Fr(1,1000000000)}");
  Console.WriteLine("R/C exact sum numerator digits: "+tot2.n.ToString().Length+" / denominator digits "+tot2.d.ToString().Length);
  // ---- C-chain all-threshold constant (5)
  F ce=Fr(33,26)*(Fr(1,1)+new F(1,BigInteger.One<<70))*Fr(853,1)*new F(1,BigInteger.One<<32)*Pw(Fr(9,16),15);
  Console.WriteLine($"C-chain constant {ce.D():E15} (<5e-11: {ce<Fr(5,100000000000)}); exact {ce}");
  Console.WriteLine($"8*256^2={8*256*256} < 9*243^2={9*243*243}: {8*256*256<9*243*243}");
  bool mono=true; for(int k=0;k<100000;k++) if(!(9*(50L*k+153)<16*(50L*k+103))) mono=false; Console.WriteLine("monotone step 9(50k+153)<16(50k+103): "+mono+" (linear: 1377+450k<1648+800k)");
  // threshold k=ceil((m+32)/7) for m=72: 
  Console.WriteLine("k at m=72: "+((72+32+6)/7)+ " ; k at m=272: "+((272+32+6)/7));
  // union
  F u=Fr(8,10000000000)+Fr(5,100000000000); Console.WriteLine($"union 8e-10+5e-11 = {u} = 17/20000000000: {u.n==17 && u.d==20000000000}");
  // R/C inside six-type: R=(2,2), C=(5,4)
  Console.WriteLine("R/C types inside six-type alphabet: yes");
  // output classes e=2..7: -2^(1-e) mod 9
  string cl=""; for(int e=2;e<=7;e++){ BigInteger inv2=5; /*2^-1 mod 9 = 5*/ BigInteger x=BigInteger.ModPow(inv2,e-1,9); x=(9-x)%9; cl+=x+" "; } Console.WriteLine("output classes e=2..7: "+cl);
 }}
