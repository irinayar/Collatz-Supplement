using System;
using System.Numerics;
using System.Collections.Generic;
// Part A: ChatGPT 125300 exact factorisation  prod G_i = (1+c_1/y_1)/(1+c_N/y_{N+1}) * prod_{i<N} (y_{i+1}+c_{i+1})/(y_{i+1}+c_i), exact rationals, on actual words with expanding blocks e in 2..8.
// Part B: window lemma (Codex K131 + my Lemma S): every positive origin m at (k+dk,r+dr) lies in ( slope*G*n - 2^(k+dk)(1-(2/3)^(r+dr)) , slope*G*n ), slope=2^(dk+dr)/3^dr (dr>=1). DP min/max over all inverse words.
class P {
  struct Fr{ public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ if(b<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g>1){a/=g;b/=g;} n=a;d=b; }
    public static Fr operator*(Fr x,Fr y)=>new Fr(x.n*y.n,x.d*y.d); public static Fr operator/(Fr x,Fr y)=>new Fr(x.n*y.d,x.d*y.n); public static Fr operator+(Fr x,Fr y)=>new Fr(x.n*y.d+y.n*x.d,x.d*y.d); public bool Eq(Fr y)=> n==y.n&&d==y.d; }
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger Least(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static (BigInteger,BigInteger) Cc(int e,int s){ BigInteger a=BigInteger.Pow(3,s+1), d=BigInteger.One<<(s+e), B=BigInteger.Pow(3,s)*(1+(BigInteger.One<<e))-d; return (B,a-d); }
  static Dictionary<(int,int,BigInteger),(BigInteger,BigInteger,bool)> memo=new();
  static (BigInteger mn,BigInteger mx,bool ok) Org(int k,int b,BigInteger z){
    if(k<0||b<0) return (0,0,false); if(k==0&&b==0) return (z,z,true); var key=(k,b,z); if(memo.TryGetValue(key,out var v)) return v;
    BigInteger mn=0,mx=0; bool ok=false;
    if(k>0){ var t=Org(k-1,b,2*z); if(t.ok){ ok=true; mn=t.mn; mx=t.mx; } }
    if(b>0 && z%3==2){ var t=Org(k,b-1,(2*z-1)/3); if(t.ok){ if(!ok){ok=true;mn=t.mn;mx=t.mx;} else { if(t.mn<mn) mn=t.mn; if(t.mx>mx) mx=t.mx; } } }
    memo[key]=(mn,mx,ok); return (mn,mx,ok); }
  static void Main(){
    var rng=new Random(31337); int[] smin=new int[9]; for(int e=2;e<=8;e++){ int s=1; while(Cc(e,s).Item2<=0) s++; smin[e]=s; }
    long words=0,badA=0;
    for(int t=0;t<1500;t++){
      var w=new List<int>(); var blocks=new List<(int,int)>(); int nb=1+rng.Next(5);
      for(int b=0;b<nb;b++){ int e=2+rng.Next(7); int s=smin[e]+rng.Next(3); blocks.Add((e,s)); w.Add(e); for(int j=0;j<s;j++) w.Add(1); }
      BigInteger x=Least(w); if(x<0) continue; words++;
      // exact block boundaries
      BigInteger y=x; var ys=new List<BigInteger>{y}; Fr G=new Fr(1,1);
      var cs=new List<Fr>();
      foreach(var (e,s) in blocks){ BigInteger yy=y; for(int i=0;i<s+1;i++){ G=G*new Fr(3*yy+1,3*yy); BigInteger z=3*yy+1; while(z.IsEven) z/=2; yy=z; } var (B,g)=Cc(e,s); cs.Add(new Fr(B,g)); y=yy; ys.Add(y); }
      int N=blocks.Count; Fr rhs=(new Fr(1,1)+cs[0]/new Fr(ys[0],1))/(new Fr(1,1)+cs[N-1]/new Fr(ys[N],1));
      for(int i=0;i<N-1;i++){ Fr yi=new Fr(ys[i+1],1); rhs=rhs*((yi+cs[i+1])/(yi+cs[i])); }
      if(!G.Eq(rhs)) badA++;
    }
    Console.WriteLine($"Part A: words {words}, factorisation identity failures {badA}");
    int[][] prof={ new[]{2,3}, new[]{1,1}, new[]{1,2}, new[]{0,1}, new[]{2,4}, new[]{3,5} };
    long[] n1=new long[prof.Length], feas=new long[prof.Length], bad=new long[prof.Length], tight=new long[prof.Length];
    for(int t=0;t<500;t++){
      BigInteger n=1+2*rng.Next(1<<26); int L=3+rng.Next(10); BigInteger u=n; int k=0,r=0; for(int s=0;s<L;s++){ if(!u.IsEven){u=(3*u+1)/2;r++;} else {u/=2;k++;} }
      if(u<3||r==0) continue; double G=Math.Pow(2,k+r)*(double)u/(Math.Pow(3,r)*(double)n);
      for(int p=0;p<prof.Length;p++){ int dk=prof[p][0],dr=prof[p][1]; if(k+r+dk+dr>22) continue; memo.Clear(); var o=Org(k+dk,r+dr,u); n1[p]++; if(!o.ok) continue; feas[p]++;
        double slope=Math.Pow(2,dk+dr)/Math.Pow(3,dr)*G*(double)n; double lo=slope-Math.Pow(2,k+dk)*(1-Math.Pow(2.0/3,r+dr));
        if(!((double)o.mx<slope*(1+1e-12) && (double)o.mn>lo*(1-1e-12)-1e-6)) bad[p]++; }
    }
    for(int p=0;p<prof.Length;p++) Console.WriteLine($"Part B profile (+{prof[p][0]},+{prof[p][1]}): sources {n1[p]}, feasible {feas[p]}, window violations {bad[p]}");
  }
}
