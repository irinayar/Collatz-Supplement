using System;
using System.Collections.Generic;
using System.Linq;
// Reduction check: delete every single odd vertex v (run of length 1) and join b_{v-1} -> p_v by one lower-arc chord.
// Verify X_orig >= X_red + (number of (ascent chord, wedge chord) crossings) = X_red + 2 * sum c(v),  X_red >= 5(h-1),  X_orig >= X_red + 2 n_1.
static class P {
  static int CountX(List<int> seq, int[] rank) { int n = seq.Count; int x = 0; for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) { if (j == i + 1 || (i == 0 && j == n - 1)) continue; double pa = rank[seq[i]], pb = rank[seq[(i + 1) % n]], qa = rank[seq[j]], qb = rank[seq[(j + 1) % n]]; double lo = Math.Min(pa, pb), hi = Math.Max(pa, pb); bool inA = qa > lo && qa < hi, inB = qb > lo && qb < hi; if (inA != inB) x++; } return x; }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); long stepTot = 0, stepBad = 0; long words = 0, bad1 = 0, bad2 = 0, bad3 = 0, badSum = 0, badAmax = 0, uncovered = 0, equal = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true; for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; } if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L || X.Min() < scale) continue; words++;
        var odd = Enumerable.Range(0, L).Where(i => e[i]).OrderBy(i => X[i]).ToList(); var even = Enumerable.Range(0, L).Where(i => !e[i]).OrderByDescending(i => X[i]).ToList(); var rank = new int[L]; int rk = 0; foreach (var i in odd) rank[i] = rk++; foreach (var i in even) rank[i] = rk++;
        var single = new bool[L]; int n1 = 0, k = 0, h = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) { k++; if (!e[(i + 1) % L]) { single[i] = true; n1++; } else h++; }
        if (k < 2) continue;
        var full = Enumerable.Range(0, L).ToList(); int Xo = CountX(full, rank); var red = full.Where(i => !single[i]).ToList(); int Xr = CountX(red, rank);
        // (ascent chord, wedge chord) crossing pairs and cover counts
        long wedgeA = 0; foreach (int v in Enumerable.Range(0, L).Where(i => single[i])) { int cv = 0; for (int a = 0; a < L; a++) if (e[a] && e[(a + 1) % L] && X[a] < X[v] && X[v] < X[(a + 1) % L]) cv++; wedgeA += 2 * cv; if (cv == 0) uncovered++; }
        { var cur = new List<int>(full); int curX = Xo; foreach (int v in Enumerable.Range(0, L).Where(i => single[i]).ToList()) { int cv = 0; var curSet = new HashSet<int>(cur); for (int a = 0; a < L; a++) if (curSet.Contains(a) && e[a] && e[(a + 1) % L] && X[a] < X[v] && X[v] < X[(a + 1) % L]) cv++; var nxt = cur.Where(i => i != v).ToList(); int nx = CountX(nxt, rank); stepTot++; if (curX < nx + 2 * cv || cv < 1) stepBad++; cur = nxt; curX = nx; } }
 if (Xo < Xr + wedgeA) bad1++; if (Xr < 5 * (h - 1) && h >= 2) bad2++; if (Xo < Xr + 2 * n1) bad3++; if (wedgeA < 2 * n1) badSum++;
        int amax = odd.Last(); if (single[amax]) badAmax++; if (Xo == Xr + 2 * n1) equal++;
      }
    }
    Console.WriteLine($"stepwise deletion of single vertices (one at a time, in index order): steps {stepTot}, violations of X(P) >= X(P-v) + 2c(v) with c(v)>=1: {stepBad}");
    Console.WriteLine($"words (values>=1, k>=2) {words}: X_orig >= X_red + 2*sum c(v) violations {bad1}; X_red >= 5(h-1) (h>=2) violations {bad2}; X_orig >= X_red + 2 n_1 violations {bad3}; sum c(v)*2 < 2 n_1: {badSum}; uncovered single vertices {uncovered}; a_max a single vertex: {badAmax}; equality X_orig = X_red + 2 n_1 in {equal}");
  }
}
