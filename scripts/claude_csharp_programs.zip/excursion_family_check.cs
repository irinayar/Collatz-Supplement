using System;
using System.Numerics;
// ChatGPT 101713: u_i = 3^i 2^(N+2-i) a - 1 (0<=i<=N): consecutive odd inputs with v2(3u_i+1)=1 for i<N, G_N = 1 + (1-(2/3)^N)/u_0 exactly.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Eq(Fr a,Fr b)=>a.n*b.d==b.n*a.d; }
  static void Main(){ long cases=0,bad=0; var Ns=new System.Collections.Generic.List<int>(); for(int N=1;N<=19;N++) Ns.Add(N); Ns.Add(20); Ns.Add(40);
    foreach(int N in Ns) foreach(int a in new[]{1,2,3,4,5,6,7,8,9}){ BigInteger u0=BigInteger.Pow(2,N+2)*a-1; BigInteger cur=u0; Fr G=new Fr(1,1); bool ok=true;
        for(int i=0;i<N;i++){ BigInteger ui=BigInteger.Pow(3,i)*BigInteger.Pow(2,N+2-i)*a-1; if(cur!=ui||cur.IsEven) ok=false; BigInteger t=(3*cur+1); if(!(t/2).IsEven==false) { /* (3u+1)/2 must be odd */ } BigInteger nxt=t/2; if(nxt.IsEven) ok=false; if(nxt<=cur) ok=false; G=G*new Fr(3*cur+1,3*cur); cur=nxt; }
        BigInteger uN=BigInteger.Pow(3,N)*BigInteger.Pow(2,2)*a-1; if(cur!=uN) ok=false;
        Fr formula=new Fr(u0*BigInteger.Pow(3,N)+BigInteger.Pow(3,N)-BigInteger.Pow(2,N),u0*BigInteger.Pow(3,N)); // (u0+1-(2/3)^N)/u0
        if(!Fr.Eq(G,formula)) ok=false; cases++; if(!ok) bad++; }
    Console.WriteLine($"Theorem A/B: {cases} (N,a) cases, failures {bad}"); }
}
