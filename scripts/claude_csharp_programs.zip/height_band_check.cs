using System;
using System.Numerics;
// ChatGPT 105312: for distinct odd inputs in [h,4h] (at most one multiple of 3): log G <= 1/h + ln4/9. (1) numeric maximum of the true sum over all admissible sets (all odd non-multiples of 3 plus the smallest odd multiple of 3 >= h) vs the bound; (2) exact rational check Q/(1-t) < 3/2; (3) widest band factor Lambda for which Q*exp(1/h + ln(Lambda)/9) < 3/2.
class P {
  static void Main(){
    foreach(long h in new long[]{1001,2001,10001,100001,1000001,10000001}){ double s=0; long mult3=0; long hi=4*h; for(long u=h|1;u<=hi;u+=2){ if(u%3==0){ if(mult3==0){ mult3=u; s+=Math.Log(1.0+1.0/(3.0*u)); } } else s+=Math.Log(1.0+1.0/(3.0*u)); }
      Console.WriteLine($"h={h}: max sum of log f over distinct odd inputs in [h,4h] (non-multiples of 3 + smallest multiple) = {s:F6}; bound 1/h+ln4/9 = {1.0/h+Math.Log(4)/9:F6}; bound holds: {s<=1.0/h+Math.Log(4)/9}"); }
    BigInteger qn=BigInteger.Pow(2,61), qd=BigInteger.Pow(3,32)*993; // t = 1/1001 + 7/45 = (45+7*1001)/(45*1001)
    BigInteger tn=45+7*1001, td=45*1001; // Q/(1-t) < 3/2  <=> 2*qn*td < 3*qd*(td-tn)
    Console.WriteLine($"(2) Q/(1-t) < 3/2 exactly: {2*qn*td<3*qd*(td-tn)}; value {(double)qn/(double)qd/(1.0-(double)tn/(double)td):F6}");
    double lnQ=Math.Log((double)qn/(double)qd); foreach(long h in new long[]{1001,100001,10000001}){ double lam=Math.Exp(9*(Math.Log(1.5)-lnQ-1.0/h)); Console.WriteLine($"(3) h={h}: widest band factor with Q*exp(1/h+ln(Lambda)/9)<3/2: Lambda < {lam:F4}"); }
  }
}
