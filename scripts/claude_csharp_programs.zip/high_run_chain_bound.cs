using System;
using System.Numerics;
// Max product M_n of n successive high runs (starts > 255), via the deterministic run map F(u) = next run start, DP over u<=X with the tail bound 1+1/X.
// Sufficient high-run count h: smallest n with Q*M_n > 3/2 (Q=8192/6561), generalising Codex's pair bound B (n=2) and R (n=1).
class P {
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static void Main(string[] args){
    int X=int.Parse(args[0]); int maxN=int.Parse(args[1]); int cnt=(X-257)/2+1; var C=new double[cnt]; var Fn=new int[cnt]; // Fn: -1 terminal (next start <=255), -2 outside (>X), else index
    for(int i=0;i<cnt;i++){ BigInteger u=257+2L*i; int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger v=w>>e; C[i]=Math.Exp(Math.Log(2)*s+BigInteger.Log(w)-s*Math.Log(3)-BigInteger.Log(u));
      if(v<=255) Fn[i]=-1; else if(v>X) Fn[i]=-2; else Fn[i]=(int)((v-257)/2); }
    double tail=1.0+1.0/X; double Q=8192.0/6561; double[] cur=new double[cnt], prev=new double[cnt]; double Mprev=0; for(int i=0;i<cnt;i++){ cur[i]=C[i]; if(cur[i]>Mprev) Mprev=cur[i]; } Mprev=Math.Max(Mprev,tail);
    Console.WriteLine($"X={X}: M_1={Mprev:F6}");
    double M=Mprev; long hits=0; for(int n=2;n<=maxN;n++){ var t=prev; prev=cur; cur=t; double mx=0;
      for(int i=0;i<cnt;i++){ double f=Fn[i]==-1?1.0:(Fn[i]==-2?M:prev[Fn[i]]); double v=C[i]*f; cur[i]=v; if(v>mx) mx=v; }
      M=Math.Max(mx,tail*M); if(n<=6||n%50==0) Console.WriteLine($"n={n}: M_n={M:F6}, Q*M_n={Q*M:F6}"); if(Q*M>1.5){ Console.WriteLine($"FIRST n with Q*M_n > 3/2: n={n} (M_n={M:F6})"); return; } }
    Console.WriteLine($"no n <= {maxN} with Q*M_n > 3/2; M_{maxN}={M:F6}");
  }
}
