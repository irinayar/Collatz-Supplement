using System;
using System.Numerics;
// Audit of the explicit counts used in ChatGPT 193047 Section 5: for n>=33 (odd): P(n) <= 2 sum_r A_{m,r} < 4 n^{21/22} and < (96/(m+1)) n^{21/22}, m=ceil(log2(H+1)).
// We test the PROVED upper count U(n)=2*sum_r A_{m,r} against both explicit majorants for every m=6..400 at the smallest and largest odd n with that m (the ratio is monotone in n within a fixed m since U depends only on m).
class P {
  static void Main(){
    int MM=400; var tot=new BigInteger[MM+1]; var A=new BigInteger[MM+2]; // rolling row over r
    var cur=new BigInteger[MM+2]; cur[2]=1; tot[2]=1; BigInteger[] nxt=new BigInteger[MM+2];
    for(int j=3;j<=MM;j++){ Array.Clear(nxt); for(int r=0;r<=j;r++){ // barrier 3^r>2^(j-1)  <=>  r*log2(3)>j-1 ; use exact big integer compare
          if(BigInteger.Pow(3,r)>(BigInteger.One<<(j-1))){ BigInteger a=cur[r]; if(r>=1) a+=cur[r-1]; nxt[r]=a; } }
      var t=cur; cur=nxt; nxt=t; BigInteger s=0; for(int r=0;r<=j;r++) s+=cur[r]; tot[j]=s; }
    int bad1=0,bad2=0; double worst1=0,worst2=0; int worstM1=0,worstM2=0;
    for(int m=6;m<=MM;m++){ // n range with ceil(log2(H+1))=m: H in [2^(m-1), 2^m -1]; smallest odd n with H>=2^(m-1), also n>=33
      BigInteger Hlo=BigInteger.One<<(m-1); BigInteger nmin=(3*Hlo+2+3)/4; if(nmin.IsEven) nmin+=1; if(nmin<33) nmin=33; // H=floor((4n-2)/3)>=Hlo <=> 4n-2>=3Hlo
      double U=Math.Log(2)+BigInteger.Log(tot[m]); // ln(2*sumA)
      double lnn=BigInteger.Log(nmin); 
      double r1=U-(Math.Log(4)+21.0/22*lnn); double r2=U-(Math.Log(96.0/(m+1))+21.0/22*lnn); // want <0
      if(r1>=0) bad1++; if(r2>=0) bad2++; if(r1>worst1||worst1==0){worst1=r1;worstM1=m;} if(r2>worst2||worst2==0){worst2=r2;worstM2=m;} }
    Console.WriteLine($"m=6..{MM}: violations of U<4 n^(21/22): {bad1}; of U<(96/(m+1)) n^(21/22): {bad2}; max log-slack (negative=OK) first {worst1:F3} at m={worstM1}, second {worst2:F3} at m={worstM2}");
  }
}
