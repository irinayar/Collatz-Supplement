using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static (int,Int128) Pos(Int128 x, bool up, bool axis) => axis ? (2, x) : (up ? (0, -x) : (1, x));
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    // key: (all>1?, k) -> histogram of (winding, rotation, crossings)
    var hist = new SortedDictionary<(bool g1, int k, int w, int rot), (long cnt, long minN, long maxN)>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        int k = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) k++; if (k < 1) continue;
        bool g1 = X.All(v => v > scale);
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2, r2 = (H - c) / 2;
        // points on the circle with diameter [c,H]; c and H on the axis; others up if odd letter (next step ascent), down if even
        var px = new double[L]; var py = new double[L]; var axis = new bool[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; bool isC = X[i] == X.Min(), isH = X[i] == X.Max(); axis[i] = isC || isH; py[i] = axis[i] ? 0 : (e[i] ? yy : -yy); }
        // winding about the centre (m,0): sum of signed central angles of chords (shorter way)
        double sumAng = 0, sumTurn = 0; bool degenerate = false;
        for (int i = 0; i < L; i++) {
          int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j];
          double cross = ax * by - ay * bx, dot = ax * bx + ay * by; double angc = Math.Atan2(cross, dot);
          if (Math.Abs(Math.Abs(angc) - Math.PI) < 1e-9) degenerate = true; sumAng += angc;
          int h = (i + 1) % L, g = (i + 2) % L; double d1x = px[h] - px[i], d1y = py[h] - py[i], d2x = px[g] - px[h], d2y = py[g] - py[h];
          sumTurn += Math.Atan2(d1x * d2y - d1y * d2x, d1x * d2x + d1y * d2y);
        }
        if (degenerate) continue;
        int wind = (int)Math.Round(sumAng / (2 * Math.PI)), rotn = (int)Math.Round(sumTurn / (2 * Math.PI));
        // crossings by cyclic order
        var pos = new (int, Int128)[L]; for (int i = 0; i < L; i++) pos[i] = Pos(X[i], e[i], axis[i]);
        // cyclic order: c, upper increasing x, H, lower decreasing x  -> use angle around the circle
        var ang = new double[L]; for (int i = 0; i < L; i++) ang[i] = Math.Atan2(py[i], px[i] - m);
        long N = 0;
        for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) {
          int[] ee = { i, (i + 1) % L, j, (j + 1) % L }; if (ee.Distinct().Count() < 4) continue;
          double a1 = ang[ee[0]], a2 = ang[ee[1]], b1 = ang[ee[2]], b2 = ang[ee[3]];
          double lo = Math.Min(a1, a2), hi = Math.Max(a1, a2); bool in1 = b1 > lo && b1 < hi, in2 = b2 > lo && b2 < hi; if (in1 != in2) N++;
        }
        var key = (g1, k, wind, rotn); hist.TryGetValue(key, out var v); hist[key] = (v.cnt + 1, v.cnt == 0 ? N : Math.Min(v.minN, N), Math.Max(v.maxN, N));
      }
    }
    Console.WriteLine("all-values>1 | k | winding about centre | rotation index | words | min/max crossings");
    foreach (var kv in hist.Where(kv => kv.Key.k <= 6)) Console.WriteLine($"{kv.Key.g1,5} k={kv.Key.k} w={kv.Key.w,3} rot={kv.Key.rot,3}  words {kv.Value.cnt,7}  crossings {kv.Value.minN}..{kv.Value.maxN}");
  }
}
