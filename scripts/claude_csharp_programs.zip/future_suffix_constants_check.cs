using System; using System.Numerics; using System.Collections.Generic;
// ChatGPT Future Suffix (22:10): constants of the R/C and six-type initial alphabets, plus the C_env expansion and Delta(5) inequality from the 21:46 audit.
class P { struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} } public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public override string ToString()=>$"{n}/{d}"; public double D()=>(double)(n>>Math.Max(0,(int)n.GetBitLength()-900))/(double)(d>>Math.Max(0,(int)n.GetBitLength()-900)); }
 static void Main(){
  var types=new List<(int s,int e)>{(2,2),(4,3),(5,4),(7,5),(9,6),(11,7)};
  F r=new F(0,1), d=new F(0,1), w=new F(0,1), cs=new F(0,1);
  for(int i=0;i<6;i++){ var (s,e)=types[i]; BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); int E=s+e-1; F beta=new F(t3-t2,t3); F lam=new F(BigInteger.One<<(s+e-1),t3); F coef=new F(1,1)+beta+new F(-lam.n,lam.d)*new F(1,1); // 1+beta-lambda
     r=r+new F(1,BigInteger.One<<E); d=d+new F(1,t3); w=w+coef*new F(1,BigInteger.One<<(E+1)); cs=cs+coef;
     if(i==0){ Console.WriteLine($"R/C so far: type (2,2) coef {coef}"); }
     if(i==2){ Console.WriteLine($"R/C (types (2,2),(5,4) only) check below"); } }
  Console.WriteLine($"six-type: r={r} (claimed 19017/131072), d={d} (claimed 22690/177147), w={w} (claimed 1194665107/23219011584), c_Sigma={cs} (claimed 1043216/177147)");
  // R/C only
  F r2=new F(1,8)+new F(1,256), d2=new F(1,9)+new F(1,243); F c_R=new F(2,3), c_C=new F(22,27); F w2=c_R*new F(1,16)+c_C*new F(1,512), cs2=c_R+c_C; Console.WriteLine($"R/C: r={r2} (33/256), d={d2} (28/243), w={w2} (299/6912), c_Sigma={cs2} (40/27)");
  // R/C bound
  double K0=((double)Math.Pow(2,71)+1)/(4*Math.Pow(2,71)-1); double rr=33.0/256, dd=28.0/243, ww=299.0/6912, cc=40.0/27; int m=72; double t1=K0*ww*Math.Pow(rr,8)/(1-rr), t2d=2*cc*8192*72/Math.Pow(2,71), t3d=ww*(224.0/5)*Math.Pow(dd,12)/(72.0*72);
  Console.WriteLine($"R/C initial bound: {t1+t2d+t3d:E11} (claimed 9.46532750875e-10 < 1e-9)");
  // C_env expansion
  BigInteger cn=BigInteger.Parse("620751769493359576"), cdn=BigInteger.Parse("1180591620717411303425"); F cstar=new F(cn,cdn);
  BigInteger n0=(BigInteger.One<<71)+1; F nn=new F(n0,1); F inv=new F(1,n0);
  F env=((new F(5,1)*cstar*(new F(4,3)+new F(1,3)*inv))+new F(1,100000))*(new F(1,2)+new F(4,1)*inv);
  F exp1=new F(10,3)*cstar+new F(1,200000)+ (new F(55,2)*cstar+new F(1,25000))*inv + new F(20,3)*cstar*inv*inv;
  Console.WriteLine($"C_env(2^71+1) = {env.D():F19}; expansion equals product: {env.n*exp1.d==exp1.n*env.d}; < 1758/1e6: {env.D()<0.001758}");
  // Delta(5) < 1/(4n)+2/n^2 for several n: 1/(n+5)-3/(4n+21) < 1/(4n)+2/n^2  <=> 49n^2+433n+840>0 (after clearing); test exactly
  bool ok=true; foreach(var nv in new BigInteger[]{3,11,100,(BigInteger.One<<71)+1,(BigInteger.One<<200)+1}){ BigInteger lhsN=(4*nv+21)-3*(nv+5), lhsD=(nv+5)*(4*nv+21); // 1/(n+5)-3/(4n+21)
     BigInteger rhsN=nv+8, rhsD=4*nv*nv; // 1/(4n)+2/n^2=(n+8)/(4n^2)
     if(!(lhsN*rhsD < rhsN*lhsD)) ok=false; } Console.WriteLine("Delta(5) upper bound inequality holds at sample n: "+ok);
 }}
