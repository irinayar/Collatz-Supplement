using System;
// Terras-model tail of the total phase Q_g of returns: Q = sum over odd inputs (1/3) (x0/x_i) (relative heights; the +1 corrections are O(1/n)).
class P {
  static void Main(string[] args) {
    long N = long.Parse(args[0]); var rng = new Random(777); long ret = 0; long[] c = new long[12];
    for (long i = 0; i < N; i++) {
      double x0 = 1.0 + (1.0 / 3.0) * rng.NextDouble(), x = x0, Q = 0; bool ok = false;
      for (int step = 0; step < 100000; step++) {
        Q += x0 / x / 3.0;
        int e = 1; while (rng.NextDouble() < 0.5) e++; x = 3 * x / Math.Pow(2, e);
        if (x < 1) break; if (x <= 4.0 / 3) { ok = true; break; }
      }
      if (ok) { ret++; for (int T = 1; T <= 11; T++) if (Q > T) c[T]++; }
    }
    Console.Write($"trials={N} returns={ret}: P(Q>T) model for T=1..9:");
    for (int T = 1; T <= 9; T++) Console.Write($" {T}:{(double)c[T] / ret:E2}");
    Console.WriteLine();
    Console.Write("local slopes -ln ratio:"); for (int T = 3; T <= 7; T++) if (c[T + 1] > 0) Console.Write($" {T}->{T + 1}:{Math.Log((double)c[T] / c[T + 1]):F2}"); Console.WriteLine();
  }
}
