using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static (int,Int128) Pos(Int128 x, bool up) => up ? (0, -x) : (1, x);
  static int Cmp((int,Int128) a, (int,Int128) b) => a.Item1 != b.Item1 ? a.Item1.CompareTo(b.Item1) : a.Item2.CompareTo(b.Item2);
  static bool Cross((int,Int128) a, (int,Int128) b, (int,Int128) c, (int,Int128) d) {
    if (Cmp(a, b) > 0) { var t = a; a = b; b = t; }
    bool cin = Cmp(a, c) < 0 && Cmp(c, b) < 0, din = Cmp(a, d) < 0 && Cmp(d, b) < 0; return cin != din;
  }
  static int Find(int[] p, int x) { while (p[x] != x) x = p[x] = p[p[x]]; return x; }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long words = 0, idMismatch = 0, boundViol = 0, boundViolGt1 = 0, notConn = 0, notConnGt1 = 0, gt1 = 0, tightCases = 0, tightGt1=0;
    var minG1 = new SortedDictionary<int, long>(); var exG1 = new Dictionary<int, string>(); var minOp = new Dictionary<int, int>(); long arcArcExtra = 0, ascOnlyNot = 0, descOnlyNot = 0, descOnlyNotGt1 = 0, ascOnlyNotGt1 = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        var val = new List<int>(); for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) val.Add(i);
        int k = val.Count; if (k < 2) continue; words++;
        bool g1 = X.All(v => v > scale); if (g1) gt1++;
        // ascent run i: indices val[i] .. last with e true ; descent run i: next indices until next valley
        var mI = new Int128[k]; var aI = new Int128[k]; var pI = new Int128[k]; var bI = new Int128[k];
        for (int t = 0; t < k; t++) {
          int v = val[t]; int last = v; while (e[(last + 1) % L]) last++; // last ascent vertex index (unwrapped)
          mI[t] = X[v % L]; aI[t] = X[last % L];
          int pk = last + 1; int nxt = val[(t + 1) % k]; if (nxt <= v) nxt += L; // next valley index (unwrapped) ; bottom is nxt-1
          pI[t] = X[pk % L]; bI[t] = X[(nxt - 1) % L];
        }
        int Op = 0, Om = 0; var par = Enumerable.Range(0, k).ToArray(); var parP = Enumerable.Range(0, k).ToArray(); var parM = Enumerable.Range(0, k).ToArray();
        for (int i = 0; i < k; i++) for (int j = i + 1; j < k; j++) {
          bool ovP = !(aI[i] < mI[j] || aI[j] < mI[i]); bool ovM = !(pI[i] < bI[j] || pI[j] < bI[i]);
          if (ovP) { Op++; par[Find(par, i)] = Find(par, j); parP[Find(parP, i)] = Find(parP, j); }
          if (ovM) { Om++; par[Find(par, i)] = Find(par, j); parM[Find(parM, i)] = Find(parM, j); }
        }
        // count crossings by type from the cyclic-order test
        long cPP = 0, cMM = 0, cAll = 0;
        for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) {
          int[] ee = { i, (i + 1) % L, j, (j + 1) % L }; if (ee.Distinct().Count() < 4) continue;
          bool ti1 = e[i], ti2 = e[(i + 1) % L], tj1 = e[j], tj2 = e[(j + 1) % L];
          if (!Cross(Pos(X[i], ti1), Pos(X[(i + 1) % L], ti2), Pos(X[j], tj1), Pos(X[(j + 1) % L], tj2))) continue;
          cAll++;
          bool crossI = ti1 != ti2, crossJ = tj1 != tj2;
          if (crossI != crossJ) { bool arcUp = crossI ? (tj1 && tj2) : (ti1 && ti2); if (arcUp) cPP++; else cMM++; }
        }
        if (cPP != 2 * Op || cMM != 2 * Om) idMismatch++;
        { int cP = Enumerable.Range(0, k).Select(x => Find(parP, x)).Distinct().Count(); int cM = Enumerable.Range(0, k).Select(x => Find(parM, x)).Distinct().Count(); if (cP > 1) ascOnlyNot++; if (cM > 1) { descOnlyNot++; if (g1) descOnlyNotGt1++; } if (cP > 1 && g1) ascOnlyNotGt1++; }
        int comps = Enumerable.Range(0, k).Select(x => Find(par, x)).Distinct().Count();
        if (comps > 1) { notConn++; if (g1) notConnGt1++; }
        if (Op + Om < k - 1) { boundViol++; if (g1) boundViolGt1++; }
        if (cAll < 2 * (k - 1)) { arcArcExtra++; }
        if (g1) { if (!minG1.ContainsKey(k) || cAll < minG1[k]) { minG1[k] = cAll; exG1[k] = Convert.ToString(w, 2).PadLeft(L, (char)48) + $" Op={Op} Om={Om}"; } if (!minOp.ContainsKey(k) || Op < minOp[k]) minOp[k] = Op; }
      }
    }
    Console.WriteLine($"words k>=2: {words} (all values>1: {gt1})");
    Console.WriteLine($"identity cross-edge x ++ edges = 2*O+, cross-edge x -- edges = 2*O- : mismatches {idMismatch}");
    Console.WriteLine($"union overlap graph (ascent ranges or descent ranges overlap) NOT connected: {notConn} words (all-values>1: {notConnGt1})");
    Console.WriteLine($"O+ + O- < k-1: {boundViol} words (all-values>1: {boundViolGt1})");
    Console.WriteLine($"ascent-overlap graph alone not connected: {ascOnlyNot} (all>1: {ascOnlyNotGt1}); descent-overlap graph alone not connected: {descOnlyNot} (all>1: {descOnlyNotGt1})");
    foreach (var kv in minG1) Console.WriteLine($"all-values>1 words, k={kv.Key}: min total crossings {kv.Value} (2(k-1)={2 * (kv.Key - 1)}), min O+ = {minOp[kv.Key]}, e.g. {exG1[kv.Key]}");
    Console.WriteLine($"total crossings < 2(k-1): {arcArcExtra} words");
  }
}
