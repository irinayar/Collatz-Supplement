using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Replay of the cycle-bridge claims (ChatGPT 17:52, 2026-11-23): rotation identity, mechanical-word gcd, numerator bounds, spread criterion, nonbalanced mod-5 control.
class P {
 static BigInteger U(int[] w){ BigInteger u=0; int ones=0; for(int j=w.Length-1;j>=0;j--){ if(w[j]==1){ u+=BigInteger.Pow(2,j)*BigInteger.Pow(3,ones); ones++; } } return u; }
 static int[] Rot(int[] w){ var r=new int[w.Length]; for(int i=0;i<w.Length;i++) r[i]=w[(i+1)%w.Length]; return r; }
 static int[] Mech(int L,int g,int theta0num=0){ var w=new int[L]; for(int j=0;j<L;j++) w[j]=(int)(((long)(j+1)*g)/L-((long)j*g)/L); return w; }
 static bool Balanced(int[] w){ int L=w.Length; for(int len=1;len<L;len++){ int mn=99,mx=-1; for(int a=0;a<L;a++){ int c=0; for(int k=0;k<len;k++) c+=w[(a+k)%L]; mn=Math.Min(mn,c); mx=Math.Max(mx,c);} if(mx-mn>1) return false; } return true; }
 // (A,D,U) monoid mod m
 struct T { public BigInteger A,D,U; }
 static BigInteger M=5;
 static T Cat(T x,T y)=>new T{A=x.A*y.A%M,D=x.D*y.D%M,U=(y.A*x.U+x.D*y.U)%M};
 static T Pow(T x,BigInteger k){ T r=new T{A=1,D=1,U=0}; T b=x; while(k>0){ if(!k.IsEven) r=Cat(r,b); b=Cat(b,b); k>>=1; } return r; }
 // lower mechanical word of (n,p) mod M via continued fraction / Stern-Brocot: returns triple for the word
 static T MechTriple(BigInteger n,BigInteger p){ // Stern-Brocot descent for p/n using left parent (n1,p1)=(1,0) word '0', right parent (n2,p2)=(1,1) word '1'
   T L=new T{A=1,D=2%M,U=0}, R=new T{A=3%M,D=2%M,U=1}; BigInteger n1=1,p1=0,n2=1,p2=1;
   while(true){ BigInteger N=n1+n2, PP=p1+p2; if(N==n && PP==p) return Cat(L,R); // mediant equals target: word = concat(left,right)
     // compare p/n with PP/N
     if(p*N<PP*n){ // target left of mediant: move right parent to mediant; do it k times at once
        // find max k such that target < (p1*k... ) : right parent becomes (n2+k n1,p2+k p1)... but we move towards left: right=mediant repeatedly: right_k = right + k*left
        BigInteger lo=1,hi=n; // largest k with p*(n2+k*n1) < (p2+k*p1)*n   (target strictly left of right_k)
        while(lo<hi){ BigInteger mid=(lo+hi+1)/2; if(p*(n2+mid*n1)<(p2+mid*p1)*n) lo=mid; else hi=mid-1; }
        BigInteger k=lo; R=Cat(Pow(L,k),R); n2=n2+k*n1; p2=p2+k*p1; }
     else { BigInteger lo=1,hi=n; // left_k = left + k*right; largest k with target > left_k i.e. p*(n1+k*n2) > (p1+k*p2)*n
        while(lo<hi){ BigInteger mid=(lo+hi+1)/2; if(p*(n1+mid*n2)>(p1+mid*p2)*n) lo=mid; else hi=mid-1; }
        BigInteger k=lo; L=Cat(L,Pow(R,k)); n1=n1+k*n2; p1=p1+k*p2; } } }
 static void Main(){ Q.Run();
  // 1. rotation identity (3), gcd invariance (5), swap difference, bounds (15)
  var rnd=new Random(7); int rotOk=0,gcdOk=0,tot=0;
  for(int it=0;it<3000;it++){ int L=rnd.Next(3,40); var w=new int[L]; for(int j=0;j<L;j++) w[j]=rnd.Next(2); int g=w.Sum(); if(g==0) continue; BigInteger d=BigInteger.Pow(2,L)-BigInteger.Pow(3,g); if(d<=0) continue; tot++;
     var s=Rot(w); bool ok=2*U(s)==BigInteger.Pow(3,w[0])*U(w)+w[0]*d; if(ok) rotOk++; if(BigInteger.GreatestCommonDivisor(U(s),d)==BigInteger.GreatestCommonDivisor(U(w),d)) gcdOk++; }
  Console.WriteLine("rotation identity (3): "+rotOk+"/"+tot+"; gcd(U(rot),d)=gcd(U,d): "+gcdOk+"/"+tot);
  bool bnd=true,inj=true; for(int l=1;l<=14;l++) for(int k=0;k<=l;k++){ var vals=new HashSet<BigInteger>(); BigInteger lo=BigInteger.Pow(3,k)-BigInteger.Pow(2,k), hi=BigInteger.Pow(2,l-k)*lo; for(int mask=0;mask<(1<<l);mask++){ if(System.Numerics.BitOperations.PopCount((uint)mask)!=k) continue; var w=new int[l]; for(int j=0;j<l;j++) w[j]=(mask>>j)&1; var u=U(w); if(u<lo||u>hi) bnd=false; if(!vals.Add(u)) inj=false; } }
  Console.WriteLine("numerator bounds (15) and injectivity for fixed (l,k), l<=14: "+bnd+" "+inj);
  // 2. mechanical words: gcd(U,2^L-3^g)=1 for coprime (L,g), L<=60 (and d>0)
  int mc=0,mok=0; for(int L=3;L<=60;L++) for(int g=1;g<L;g++){ if(BigInteger.GreatestCommonDivisor(L,g)!=1) continue; BigInteger d=BigInteger.Pow(2,L)-BigInteger.Pow(3,g); if(d<=0) continue; var w=Mech(L,g); mc++; if(BigInteger.GreatestCommonDivisor(U(w),d)==1) mok++; }
  Console.WriteLine("mechanical coprime (L,g), L<=60, d>0: gcd(U,d)=1 in "+mok+"/"+mc);
  // 3. spread criterion: for every word of length <=18 with g>=2, d>0: if R^g G^(g-1) <= 2^g then balanced; coprime: R^g G^(g-1) > 2^(g+1) unless balanced
  long tested=0, viol=0, viol2=0, amb=0; for(int L=3;L<=18;L++) for(int mask=1;mask<(1<<L)-1;mask++){ var w=new int[L]; for(int j=0;j<L;j++) w[j]=(mask>>j)&1; int g=w.Sum(); if(g<2) continue; BigInteger d=BigInteger.Pow(2,L)-BigInteger.Pow(3,g); if(d<=0) continue;
      // odd states x_j = U(rot^j w)/d at positions with w[j]==1
      double mn=double.MaxValue,mx=0; var cur=w; for(int j=0;j<L;j++){ if(w[j]==1){ double x=(double)U(cur)/(double)d; mn=Math.Min(mn,x); mx=Math.Max(mx,x);} cur=Rot(cur);} tested++;
      double Rr=mx/mn; double G=Math.Pow(2,L)/Math.Pow(3,g); double lhs=g*Math.Log(Rr)+(g-1)*Math.Log(G)-g*Math.Log(2); bool bal=Balanced(w);
      if(Math.Abs(lhs)<1e-9) amb++; if(lhs<=0 && !bal) viol++; if(BigInteger.GreatestCommonDivisor(L,g)==1 && !bal){ double lhs2=g*Math.Log(Rr)+(g-1)*Math.Log(G)-(g+1)*Math.Log(2); if(lhs2<=0) viol2++; } }
  Console.WriteLine("spread criterion on all words L<=18 (g>=2,d>0): tested "+tested+", violations of (B): "+viol+", violations of (B') (coprime, nonbalanced): "+viol2+", ambiguous (|lhs|<1e-9): "+amb);
  // 4. nonbalanced high rational control (29): mod-5 numerator
  BigInteger LL=BigInteger.Parse("9009497464537"), gg=BigInteger.Parse("5684360015103"); Console.WriteLine("gcd(L,g)="+BigInteger.GreatestCommonDivisor(LL,gg));
  // check construction against direct expansion for small coprime pairs
  bool cons=true; for(int L=2;L<=60;L++) for(int g=1;g<L;g++){ if(BigInteger.GreatestCommonDivisor(L,g)!=1) continue; var w=Mech(L,g); var t=MechTriple(L,g); if(t.U!=U(w)%M || t.A!=BigInteger.Pow(3,g)%M || t.D!=BigInteger.Pow(2,L)%M) cons=false; }
  Console.WriteLine("Stern-Brocot triple mod 5 agrees with direct expansion for coprime (L,g), L<=60: "+cons);
  T big=MechTriple(LL,gg); BigInteger three=BigInteger.ModPow(3,gg-1,5); BigInteger mod=((big.U-three)%5+5)%5;
  Console.WriteLine("mechanical U mod 5 = "+big.U+" (claimed 3); modified (U-3^(g-1)) mod 5 = "+mod+" (claimed 4); 2^L-3^g mod 5 = "+(((BigInteger.ModPow(2,LL,5)-BigInteger.ModPow(3,gg,5))%5+5)%5)+" (claimed 0); A,D mod 5 = "+big.A+","+big.D);
  // prefix of the mechanical word of (29)
  var sb=new System.Text.StringBuilder(); for(int j=0;j<30;j++){ BigInteger a1=((j+1)*gg)/LL, a0=(j*gg)/LL; sb.Append((int)(a1-a0)); } Console.WriteLine("prefix: "+sb+" (claimed 010110110101101101011011011010)");
 }}
