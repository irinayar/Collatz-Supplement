using System;
// Test of ChatGPT 193047 per-return charge bound: for every genuine first return (source u, arrival w, k>=1 resets) at threshold n:
//   c/(u+5) < R_n(k) = A_n (1+3(k-1)/(H-1))^(1/3) - 1  (< 2k/n),  A_n=(1+5/n)(H+1)/(H+5).   All odd n<=NMAX, every source.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=40001; long tested=0,viol=0,viol2k=0; double maxRatio=0; long arg=0; int kmax=0;
    for(long n=3;n<=NMAX;n+=2){ long H=(4*n-2)/3; double An=(1+5.0/n)*(H+1.0)/(H+5.0);
      for(long u=n;u<=H;u+=2){ long x=u; int g=0,k=0; double G=1.0; bool ret=false;
        for(int step=0;step<100000;step++){ G*=1.0+1.0/(3.0*x); int e; x=A(x,out e); g++; if(e>=2) k++; if(x<=H){ ret=x>=n; break; } }
        if(!ret) continue; double rho=G*(1.0+5.0/x)/(1.0+5.0/u); double cw=rho-1; // = c/(u+5)
        if(cw<=1e-12) continue; tested++; if(k>kmax) kmax=k; double R=An*Math.Pow(1+3.0*(k-1)/(H-1),1.0/3)-1; if(!(cw<R)) viol++; if(!(cw<2.0*k/n)) viol2k++; double ratio=cw/R; if(ratio>maxRatio){maxRatio=ratio;arg=n*1000000+u%1000000;} }
    }
    Console.WriteLine($"odd n<={NMAX}: positive-charge genuine returns tested {tested} (max resets {kmax}); violations of R_n(k): {viol}; violations of 2k/n: {viol2k}; max ratio (c/(u+5))/R_n(k) = {maxRatio:F4}");
  }
}
