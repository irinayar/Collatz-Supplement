using System;
using System.Collections.Generic;
using System.Numerics;
// Second, independent implementation for the finite monotonicity theorem: for each k, collect every endpoint x that has an origin m < 3*2^k-4 with exactly k even steps
// (forward trajectories), then verify strict decrease of the EXACT min origin over the WHOLE feasible range of x by plain inverse-tree DFS (no R_k recursion).
// Endpoints with no such origin satisfy H_k(x,r) >= 3*2^k-4 for all r, so Lemma E covers them.
class P {
  static int EMAX; static BigInteger[] mn; static long nodes;
  static void Dfs(BigInteger z,int ev,int od){ nodes++; if(ev==EMAX){ if(mn[od]==0||z<mn[od]) mn[od]=z; }
    if(ev<EMAX) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(string[] args){
    int K=int.Parse(args[0]); var sw=System.Diagnostics.Stopwatch.StartNew();
    for(int k=1;k<=K;k++){ long B=3L*(1L<<k)-4; var xs=new HashSet<long>();
      for(long m=1;m<B;m++){ long y=m; int e=0; for(int step=0;step<10000;step++){ if(e==k) xs.Add(y); if(e>k) break; if((y&1)==1) y=(3*y+1)/2; else { y/=2; e++; } if(e>k) break; } }
      long viol=0,series=0,totNodes=0; var bad=new List<string>();
      foreach(long x in xs){ EMAX=k; mn=new BigInteger[200]; nodes=0; Dfs(x,0,0); totNodes+=nodes; int R=-1; for(int r=0;r<200;r++) if(mn[r]!=0) R=r; series++;
        for(int r=0;r<R;r++){ if(!(mn[r+1]<mn[r])){ viol++; if(bad.Count<4) bad.Add($"(x={x},r={r}: {mn[r]} -> {mn[r+1]})"); } } }
      Console.WriteLine($"k={k}: B={B}, endpoints with a small origin {xs.Count}, DFS series {series} ({totNodes} nodes), violations {viol} {string.Join(" ",bad)}  [{sw.ElapsedMilliseconds/1000}s]");
      if(sw.ElapsedMilliseconds>200000) break; }
  }
}
