using System;
using System.Numerics;
// Initial-segment bound: runs starting above 4095 before the first run start <= 4095; after entry the total is <= P_B*Q_S = 1.2567677 (ChatGPT 204209, verified).
// M_n = max product of the first n such runs (upward rounded recursion as in the rigorous chain bound); threshold = first n with QPB*M_n >= 3/2 .
class P {
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static double Up(double x)=>Math.BitIncrement(Math.BitIncrement(x));
  static double RatioUp(BigInteger num,BigInteger den){ BigInteger q=(num<<60)/den+1; double d=(double)q/Math.Pow(2,60); return Up(d*(1.0+Math.Pow(2,-50))); }
  static void Main(string[] args){
    int X=int.Parse(args[0]); int N=int.Parse(args[1]); int lo=4097; int cnt=(X-lo)/2+1; var C=new double[cnt]; var Fn=new int[cnt];
    for(int i=0;i<cnt;i++){ BigInteger u=lo+2L*i; int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger v=w>>e; C[i]=RatioUp(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); if(v<4097) Fn[i]=-1; else if(v>X) Fn[i]=-2; else Fn[i]=(int)((v-lo)/2); }
    BigInteger pbn=BigInteger.Parse("156976339249031964457216266903563857163190272"), pbd=BigInteger.Parse("124904816634787122076792904202432760954641843"); double QP=RatioUp(pbn,pbd);
    double tail=RatioUp(X+1,X); double[] cur=new double[cnt], prev=new double[cnt]; double M=tail; for(int i=0;i<cnt;i++){ cur[i]=C[i]; if(cur[i]>M) M=cur[i]; }
    int first=-1; for(int n=1;n<=N;n++){ if(n>1){ var t=prev; prev=cur; cur=t; double mx=0; for(int i=0;i<cnt;i++){ double f=Fn[i]==-1?1.0:(Fn[i]==-2?M:prev[Fn[i]]); double v=Up(C[i]*f); cur[i]=v; if(v>mx) mx=v; } M=Math.Max(mx,Up(tail*M)); }
      double b=Up(QP*M); if(b>=1.5){ first=n; Console.WriteLine($"X={X}: Q_total*M_n >= 3/2 first at n={first} (M_n={M:F6}, bound {b:F6}); excluded for n<{first}, i.e. G>3/2 needs >= {first} initial runs above 4095"); return; }
      if(n==1||n==2||n%500==0) Console.WriteLine($"n={n}: M_n<={M:R}, Q_total*M_n<={b:R}"); }
    Console.WriteLine($"X={X}: no n<={N} reaches 3/2");
  }
}
