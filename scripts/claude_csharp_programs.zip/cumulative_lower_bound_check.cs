using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long bad_cg = 0, words = 0, ge1 = 0, bad_a = 0, bad_b = 0, bad_c = 0, bad_eq = 0, bad_mono = 0, wmk = 0, wmkGe1 = 0;
    double minRatio = 9; double[] minW = new double[2] { 9, 9 };
    var kHist = new SortedDictionary<int, long>(); var kHistG = new SortedDictionary<int, long>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2, S = c + H;
        bool g1 = x.All(v => v >= 1.0 - 1e-12);
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        var d = new double[L]; bool deg = false;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; d[i] = a; }
        if (deg) continue; words++; if (g1) ge1++;
        int k = 0; for (int i = 0; i < L; i++) { int j = (i + 1) % L; if (!e[i] && e[j]) k++; }
        double wt = d.Sum() / (2 * Math.PI); double wr = Math.Round(wt);
        // (c) w = - #excursions of type (P_R, V_L)
        int nRL = 0;
        for (int i = 0; i < L; i++) { int i1 = (i + 1) % L; if (!(e[i] && !e[i1])) continue; int j = i1; while (!(!e[j] && e[(j + 1) % L])) j = (j + 1) % L; if (d[i] < 0 && d[j] < 0) nRL++; }
        if ((int)wr != -nRL) { bad_c++; if (g1) bad_cg++; }
        if (wr + k == 0) { wmk++; if (g1) wmkGe1++; var h = g1 ? kHistG : kHist; h[k] = h.GetValueOrDefault(k) + 1; }
        // monotone phi along each stretch (valley-to-valley)
        double[] phi = new double[L]; for (int i = 0; i < L; i++) phi[i] = Math.Atan2(py[i], px[i] - m);
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; bool valley = !e[i] && e[j]; if (!valley && !(phi[j] < phi[i])) bad_mono++; }
        // windows
        int g = g1 ? 1 : 0;
        for (int st = 0; st < L; st++) {
          double cur = 0;
          for (int t = 1; t <= 3 * L; t++) {
            cur += d[(st + t - 1) % L]; double u = cur / (2 * Math.PI);
            int q = (t - 1) / L;
            // (a) u > (q+1) w - 1
            if (!(u > (q + 1) * wr - 1 + 1e-12)) bad_a++;
            double r = u - (q + 1) * wr; if (r < minW[g]) minW[g] = r;
            // (b) t <= L : u >= -k, equality only at t = L and w = -k
            if (t <= L) { if (u < -k - 1e-9) bad_b++; if (t < L && u <= -k + 1e-9) bad_eq++; }
          }
        }
      }
    }
    Console.WriteLine($"words {words} (values>=1: {ge1})");
    Console.WriteLine($"(c) w = -#(P_R,V_L) excursions: violations {bad_c} (values>=1: {bad_cg})");
    Console.WriteLine($"(mono) phi strictly decreasing along every non-valley edge: violations {bad_mono}");
    Console.WriteLine($"(a) Phi_s(t)/2pi > (q+1)w - 1, q=floor((t-1)/L), t<=3L: violations {bad_a}; min of Phi/2pi-(q+1)w: all {minW[0]:F4}, values>=1 {minW[1]:F4}");
    Console.WriteLine($"(b) t<=L: Phi_s(t) >= -2pi k: violations {bad_b}; equality at t<L: {bad_eq}");
    Console.WriteLine($"words with w = -k: {wmk} (values>=1: {wmkGe1}); by k (all): {string.Join(", ", kHist.Select(p => p.Key + ":" + p.Value))}; by k (values>=1): {string.Join(", ", kHistG.Select(p => p.Key + ":" + p.Value))}");
  }
}
