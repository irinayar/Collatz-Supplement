using System;
using System.Numerics;
// ChatGPT 221944: (a) exact identities for the two envelope gaps; (b) Theorems 1,2 against exact origin sets (x=2 mod 3, x>=5, y=(2x-1)/3, A_r=O_{k-2,r}(4x), B_r=O_{k,r-1}(y)).
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ if(b<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero) g=1; n=a/g; d=b/g; } public static Fr operator-(Fr a,Fr b)=>new Fr(a.n*b.d-b.n*a.d,a.d*b.d); public static Fr operator+(Fr a,Fr b)=>new Fr(a.n*b.d+b.n*a.d,a.d*b.d); public static bool Eq(Fr a,Fr b)=>a.n*b.d==b.n*a.d; }
  static Fr L(int a,int b,BigInteger z)=>new Fr(BigInteger.Pow(2,a+b)*z-BigInteger.Pow(2,a)*(BigInteger.Pow(3,b)-BigInteger.Pow(2,b)),BigInteger.Pow(3,b));
  static Fr U(int a,int b,BigInteger z)=>new Fr(BigInteger.Pow(2,a+b)*z-(BigInteger.Pow(3,b)-BigInteger.Pow(2,b)),BigInteger.Pow(3,b));
  static BigInteger[] mn,mx; static int EM; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long idBad=0,idN=0;
    for(int k=2;k<=30;k+=4) for(int r=1;r<=6;r++) for(int x=5;x<=998;x+=3){ BigInteger X=x, y=(2*X-1)/3; idN++;
      Fr g1=L(k,r-1,y)-U(k-2,r+1,4*X); Fr f1=new Fr(BigInteger.Pow(2,k)*(BigInteger.Pow(2,r)*(X+3)-BigInteger.Pow(3,r+1)),BigInteger.Pow(3,r+1))+new Fr(BigInteger.Pow(3,r+1)-BigInteger.Pow(2,r+1),BigInteger.Pow(3,r+1)); if(!Fr.Eq(g1,f1)) idBad++;
      Fr g2=L(k-2,r,4*X)-U(k,r,y); Fr f2=new Fr(BigInteger.Pow(2,k)*(BigInteger.Pow(2,r)*(4*X+7)-BigInteger.Pow(3,r+1)),4*BigInteger.Pow(3,r+1))+new Fr(BigInteger.Pow(3,r)-BigInteger.Pow(2,r),BigInteger.Pow(3,r)); if(!Fr.Eq(g2,f2)) idBad++; }
    Console.WriteLine($"(a) exact identities for the two envelope gaps: {idN} parameter sets (k=2,6,...,30, r=1..6, x=5,8,...,998), mismatches {idBad}");
    long t1=0,t1bad=0,t2=0,t2bad=0;
    for(int x=5;x<=401;x+=3){ BigInteger X=x, y=(2*X-1)/3; for(int k=2;k<=10;k++){
        EM=k-2; var mnA=new BigInteger[9]; var mxA=new BigInteger[9]; mn=mnA; mx=mxA; Dfs(4*X,0,0); 
        EM=k; var mnB=new BigInteger[9]; var mxB=new BigInteger[9]; mn=mnB; mx=mxB; Dfs(y,0,0); // B_r = O_{k,r-1}(y) = index r-1 of this array
        for(int r=1;r<=2;r++){ if(mxA[r+1]!=0&&mnB[r-1]!=0){ t1++; if(!(mxA[r+1]<mnB[r-1])) t1bad++; } }
        for(int r=1;r<=5;r++){ if(mxB[r]!=0&&mnA[r]!=0){ t2++; if(!(mxB[r]<mnA[r])) t2bad++; } } } }
    Console.WriteLine($"(b) Theorem 1 (max A_(r+1) < min B_r, r=1,2): {t1} comparisons, failures {t1bad}; Theorem 2 (max B_(r+1) < min A_r, r=1..5): {t2} comparisons, failures {t2bad} (x=5..401, x=2 mod 3, k=2..10)");
  }
}
