using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    long peakDrops = 0, peakDropsOk = 0, peakDropsBad = 0; long words = 0, wordsGt1 = 0, violGt1 = 0, violLe1 = 0, le1 = 0, k2plusGt1 = 0, riseTotal = 0, riseOk = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        // valley vertices: e[i] && !e[i-1]
        var val = new List<int>(); for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) val.Add(i);
        int k = val.Count; if (k < 2) continue; words++;
        bool gt1 = X.All(v => v > scale); // all vertex values > 1
        if (!gt1) le1++; else wordsGt1++;
        // for each cyclic valley pair (run i -> run i+1): run i = indices from val[i] while e true
        int rises = 0, okRises = 0;
        for (int t = 0; t < k; t++) {
          int vi = val[t], vn = val[(t + 1) % k];
          Int128 mi = X[vi], mn = X[vn];
          if (mn > mi) {
            rises++;
            // ++ edges of run t: v -> v+1 with e[v] && e[v+1]
            bool cross = false; int v = vi;
            while (e[v % L] && e[(v + 1) % L]) { Int128 x = X[v % L], x2 = X[(v + 1) % L]; if (x < mn && mn < x2) cross = true; v++; if (v - vi > L) break; }
            if (cross) okRises++;
          }
        }
        { for (int t = 0; t < k; t++) { int vi = val[t], vn = val[(t + 1) % k], vnn = val[(t + 2) % k]; int lenNext = 0; { int v = vn; while (e[v % L]) { lenNext++; v++; if (lenNext > L) break; } } int pkT = vi; { int v = vi; while (e[v % L]) v++; pkT = v % L; } int pkN = vn; { int v = vn; while (e[v % L]) v++; pkN = v % L; } if (lenNext >= 2 && X[pkN] < X[pkT]) { peakDrops++; bool cr = false; int j = pkT; while (j % L != (vn + L - 1) % L) { Int128 y = X[j % L], y2 = X[(j + 1) % L]; if (y2 < X[pkN] && X[pkN] < y) cr = true; j++; if (j - pkT > L) break; } if (cr) peakDropsOk++; else if (gt1) peakDropsBad++; } } }
        if (gt1) { k2plusGt1++; riseTotal += rises; riseOk += okRises; if (rises == 0 || okRises < rises) violGt1++; }
        else { if (rises == 0 || okRises < rises) violLe1++; }
      }
    }
    Console.WriteLine($"words with k>=2: {words}; with all vertices > 1: {wordsGt1}; with some vertex <= 1: {le1}");
    Console.WriteLine($"all-vertices>1 words: valley rises {riseTotal}, rises whose valley edge crosses a ++ edge of the previous run {riseOk}; words violating (no rise or a rise without crossing): {violGt1}");
    Console.WriteLine($"peak drops (next ascent run of length>=2, p_next<p): {peakDrops}; with a -- edge of the previous descent run crossing the next peak edge: {peakDropsOk}; failures among words with all vertices>1: {peakDropsBad}");
    Console.WriteLine($"words with a vertex <= 1 violating the statement: {violLe1} of {le1}");
  }
}
