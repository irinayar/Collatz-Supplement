using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Independent C# replay of the two 20 Nov threshold theorems (convergent partner 76,929,449; nonperiodic 586,464,555) from the ChatGPT notes 12:47:30 / 13:41:56.
class P {
 static void Main(){
  int X=89393;
  // 1. finite base: all odd z in 3..X reach 1; F(z)=2^s/(3^o z); max F; max steps
  BigInteger bestN=0,bestD=1; int bestZ=0, maxSteps=0, cnt=0; 
  for(int z=3;z<=X;z+=2){ cnt++; long x=z; int odd=0, steps=0; while(x!=1){ long w=3*x+1; int tw=0; while((w&1)==0){w>>=1;tw++;} x=w; steps+=tw; odd++; if(steps>5000) throw new Exception("no convergence "+z); }
    if(steps>maxSteps) maxSteps=steps; BigInteger fn=BigInteger.One<<steps, fd=BigInteger.Pow(3,odd)*z; if(fn*bestD>bestN*fd){bestN=fn;bestD=fd;bestZ=z;} }
  var g=BigInteger.GreatestCommonDivisor(bestN,bestD); bestN/=g; bestD/=g;
  Console.WriteLine("finite base: odd z in 3.."+X+": "+cnt+" values (claimed 44696), all reach 1; max accelerated hitting time "+maxSteps+" (claimed 221); F_X = "+bestN+"/"+bestD+" at z="+bestZ+" (claimed 2305843009213693952/1840049047529878113 at 993: "+(bestN.ToString()=="2305843009213693952"&&bestD.ToString()=="1840049047529878113"&&bestZ==993)+"); 2^61/(3^32*993) match: "+(bestN==BigInteger.Pow(2,61)&&bestD==BigInteger.Pow(3,32)*993));
  // 2. convergent threshold
  { BigInteger V=X+2; BigInteger cn=3*V+1, cd=3*V; // C=f(V)
    BigInteger num=bestN*cn, den=bestD*cd; // F*C
    BigInteger A=(X+1)*(BigInteger.Pow(3*bestD*cd,9)-BigInteger.Pow(num,9)); BigInteger Bq=6*BigInteger.Pow(num,9); BigInteger R=(A-1)/Bq;
    Console.WriteLine("convergent: R_max = "+R+" (claimed 38464724); B*R < A <= B*(R+1): "+(Bq*R<A && A<=Bq*(R+1))+"; thresholds b>="+(2*R+1)+" (claimed 76929449), a>="+(2*R+2)+", j>="+(2*R+2)); }
  // 3. nonperiodic threshold
  { BigInteger S=3*(X+4)+1, D=3*(X+4); BigInteger Bq=(X+1)*(BigInteger.Pow(3*D,9)-BigInteger.Pow(S,9)); BigInteger Hh=6*BigInteger.Pow(S,9); BigInteger R=(Bq-1)/Hh;
    Console.WriteLine("nonperiodic: S="+S+" D="+D+" R_* = "+R+" (claimed 293232277); H*R<B: "+(Hh*R<Bq)+", H*(R+1)<B: "+(Hh*(R+1)<Bq)+"; A_j(m)>="+(2*R+1)+" (claimed 586464555), A_j(n)>="+(2*R+2));
    BigInteger M=BigInteger.Parse("2075")*BigInteger.Pow(2,60); BigInteger X2=M-3; BigInteger S2=3*(X2+4)+1, D2=3*(X2+4); BigInteger B2=(X2+1)*(BigInteger.Pow(3*D2,9)-BigInteger.Pow(S2,9)); BigInteger H2=6*BigInteger.Pow(S2,9); BigInteger R2=(B2-1)/H2;
    Console.WriteLine("conditional large base M-3 (M=2075*2^60): X mod 6 = "+(X2%6)+", R_* = "+R2+" (claimed 7847581197728220254464664), A_j(m)>="+(2*R2+1)+" (claimed 15695162395456440508929329)"); }
  // 4. pair inequality: identity g'(v) at many points and (f(v)f(v+4))^9 < (v+5)/(v-1)
  { bool idOk=true, cubeOk=true, ineqOk=true; for(int v=6;v<=80;v++){ // diff = (1/(v+5)-1/(v-1))/9 - (3/(3v+1)-1/v) - (3/(3v+13)-1/(v+4)) ; target = -2*cube/(3v(v-1)(v+4)(v+5)(3v+1)(3v+13))
      BigInteger V=v; // work with common denominator
      BigInteger den=9*3*V*(V-1)*(V+4)*(V+5)*(3*V+1)*(3*V+13); // 27 v(v-1)(v+4)(v+5)(3v+1)(3v+13)
      // term1 = (1/(v+5)-1/(v-1))/9 = (-6)/(9 (v+5)(v-1))
      BigInteger t1=-6*(3*V*(V+4)*(3*V+1)*(3*V+13)); // over 9*3*...: (-6/(9(v+5)(v-1))) = -6*3*v(v+4)(3v+1)(3v+13) / den
      // term2 = -(3/(3v+1)-1/v) = -( (3v-(3v+1))/(v(3v+1)) ) = 1/(v(3v+1)) ; over den: 27 (v-1)(v+4)(v+5)(3v+13)
      BigInteger t2=27*(V-1)*(V+4)*(V+5)*(3*V+13);
      // term3 = -(3/(3v+13)-1/(v+4)) = -( (3(v+4)-(3v+13))/((3v+13)(v+4)) ) = 1/((3v+13)(v+4)) ; over den: 27 v(v-1)(v+5)(3v+1)
      BigInteger t3=27*V*(V-1)*(V+5)*(3*V+1);
      BigInteger lhs=t1+t2+t3; BigInteger cube=3*V*V*V-8*V*V-65*V+390; BigInteger rhs=-2*cube*9; // target*den = -2*cube*den/(3v..)= -2*cube*9
      if(lhs!=rhs) idOk=false; BigInteger t=V-5; if(cube!=3*t*t*t+37*t*t+80*t+240) cubeOk=false;
      if(!( BigInteger.Pow((3*V+1)*(3*V+13),9)*(V-1) < BigInteger.Pow(9*V*(V+4),9)*(V+5) )) ineqOk=false; }
    Console.WriteLine("g'(v) identity (rational function, degree <20, checked at 75 points v=6..80): "+idOk+"; cubic = 3t^3+37t^2+80t+240: "+cubeOk+"; pair inequality (f(v)f(v+4))^9 < (v+5)/(v-1) at v=6..80: "+ineqOk); }
  // 5. numerical control of bound (3) on actual convergent prefixes
  { double FX=(double)2305843009213693952/1840049047529878113; double C=268186.0/268185; long viol=0,tot=0; var rnd=new Random(5);
    for(int it=0;it<300000;it++){ long m=rnd.Next(3,3000000); long x=m; double P=1; int b=0; while(x>=3){ if(x%2==1){ P*=1+1.0/(3.0*x); b++; x=(3*x+1)/2; } else x/=2; double bound=FX*C*Math.Pow(1+6.0*Math.Ceiling(b/2.0)/(X+1),1.0/9); tot++; if(P>bound*(1+1e-12)) viol++; if(x<3) break; } }
    Console.WriteLine("bound (3) checked on all prefixes of 300000 random convergent orbits (m<3e6, endpoint>=3): "+tot+" prefixes, violations "+viol); }
 }}
