using System;
using System.Collections.Generic;
// (1) Check Codex K134 on actual no-first-descent prefixes (no distinctness assumption): H=floor((4n-2)/3); low inputs u<=H (u>=n);
//     consecutive low visits are >=2 odd transitions apart; gap exactly 2 => u=11 mod 16, w=(9u+5)/8; every 3 consecutive gaps sum >=7; r >= 2q-1+floor((q-1)/3); pair identity f(u)f(v)=(9u+5)/(9u).
// (2) Correct my own 133309 'sharpness' claim: compare the true maximal width W*(n) with floor((4n-2)/3)-n.
class P {
  static long A(long u){ long x=3*u+1; while((x&1)==0) x>>=1; return x; }
  static void Main(){
    long bad=0,gaps2=0,prefixes=0,tripleTight=0;
    for(long n=3;n<=40001;n+=2){
      long H=(4*n-2)/3; long x=n; var idx=new List<int>(); var vals=new List<long>(); int r=0;
      for(int step=0;step<5000;step++){
        if((x&1)==1){ if(x<=H){ idx.Add(r); vals.Add(x);} r++;
          // prefix with r inputs ends here (successor may be <n). check bound
          int q=idx.Count; prefixes++; if(r < 2*q-1+(q-1)/3) bad++; 
          x=A(x); // next odd state (accelerated even steps folded)
          if(x<n) break; continue; }
        x=x/2; if(x<n) break; }
      for(int i=0;i+1<idx.Count;i++){ int gap=idx[i+1]-idx[i]; if(gap<2) bad++; if(gap==2){ gaps2++; long u=vals[i], w=vals[i+1]; if(u%16!=11 || 8*w!=9*u+5) bad++; } }
      for(int i=0;i+3<idx.Count;i++){ int s3=idx[i+3]-idx[i]; if(s3<7) bad++; else if(s3==7) tripleTight++; }
    }
    Console.WriteLine($"K134 spacing: prefixes {prefixes}, gap-2 visits {gaps2}, triples with total exactly 7: {tripleTight}, violations {bad}");
    // pair identity exact
    long badP=0; for(long u=3;u<200000;u+=2){ if(u%4!=3) continue; long v=(3*u+1)/2; // f(u)f(v) == (9u+5)/(9u):  (3u+1)(3v+1)*9u == (9u+5)*3u*3v
      System.Numerics.BigInteger l=(System.Numerics.BigInteger)(3*u+1)*(3*v+1)*9*u, rr=(System.Numerics.BigInteger)(9*u+5)*3*u*3*v; if(l!=rr) badP++; }
    Console.WriteLine($"pair identity violations (u=3 mod 4, u<2e5): {badP}");
    // (2) true maximal width vs floor((4n-2)/3)-n
    long eq=0,gt=0,lt=0; long exampleGt=-1; 
    for(long n=3;n<=40001;n+=2){ long H0=-1; for(long h=0;h<=2*n;h++){ long u=n+h; if((u&1)==1){ long f=A(u); long xx=3*u+1; int e=0; while((xx&1)==0){xx>>=1;e++;} if(f>=n && e!=1) break; } H0=h; }
      long expect=(4*n-2)/3-n; if(H0==expect) eq++; else if(H0>expect){ gt++; if(exampleGt<0) exampleGt=n; } else lt++; }
    Console.WriteLine($"true max width vs floor((4n-2)/3)-n: equal {eq}, larger {gt}, smaller {lt}; first n with larger width: {exampleGt}");
  }
}
