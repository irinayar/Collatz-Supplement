using System;
using System.Collections.Generic;
// Independent checks: (1) ChatGPT 092659 same-count persistence R_j (integer, = n - min same-count origin, nondecreasing);
// (2) Codex 094800 lower-count cutoff Q(j,a) = 2^e [1-(2/3)^(a-1)]; (3) two-channel criterion under P<3: partner exists iff H>a or M>U.
class P {
  static long Pow3(int a) { long p = 1; for (int i = 0; i < a; i++) p *= 3; return p; }
  static long T(long x) => (x & 1) == 1 ? (3 * x + 1) / 2 : x / 2;
  static int Hmax(long y, int j) { var cur = new List<(long, int)> { (y, 0) }; for (int t = 0; t < j; t++) { var nx = new List<(long, int)>(); foreach (var (v, c) in cur) { nx.Add((2 * v, c)); if (v % 3 == 2) nx.Add(((2 * v - 1) / 3, c + 1)); } cur = nx; } int m = 0; foreach (var (v, c) in cur) if (c > m) m = c; return m; }
  static void Main() {
    int J = 12; var tab = new Dictionary<long, long>[J + 1, J + 1]; for (int j = 0; j <= J; j++) for (int a = 0; a <= J; a++) tab[j, a] = new Dictionary<long, long>(); tab[0, 0][0] = 0;
    for (int j = 0; j < J; j++) for (int a = 0; a <= j + 1; a++) { long mod = Pow3(a);
      if (a <= j) foreach (var kv in tab[j, a]) { long r = kv.Key % mod; if (!tab[j + 1, a].TryGetValue(r, out var c) || kv.Value > c) tab[j + 1, a][r] = kv.Value; }
      if (a >= 1) foreach (var kv in tab[j, a - 1]) { long U = (1L << j) + 3 * kv.Value; long r = U % mod; if (!tab[j + 1, a].TryGetValue(r, out var c) || U > c) tab[j + 1, a][r] = U; } }
    long c1 = 0, b1 = 0, pos = 0, c2 = 0, b2 = 0, el = 0, c3 = 0, b3 = 0, yes3 = 0;
    for (long n = 1; n <= 2000; n++) {
      long z = n; int a = 0; long U = 0; var ps = new List<int>(); long prevR = 0;
      for (int j = 1; j <= J; j++) {
        if ((z & 1) == 1) { ps.Add(j - 1); a++; z = (3 * z + 1) / 2; } else z /= 2;
        U = 0; for (int k = 0; k < ps.Count; k++) U += (1L << ps[k]) * Pow3(a - 1 - k);
        long y = z; long r = ((1L << j) * y) % Pow3(a); long M = tab[j, a][r];
        // brute force over all m < n: partners with fewer / same / more odd steps
        long minSame = n; bool anySmaller = false, fewer = false;
        for (long m = 1; m < n; m++) { long w = m; int c = 0; for (int i = 0; i < j; i++) { if ((w & 1) == 1) { c++; w = (3 * w + 1) / 2; } else w /= 2; }
          if (w == y) { anySmaller = true; if (c == a && m < minSame) minSame = m; if (c < a) fewer = true; } }
        // (1) persistence / R integer
        long G = M - U; c1++; if (G < 0 || G % Pow3(a) != 0) b1++; long R = G / Pow3(a); if (R != n - minSame) b1++; if (R < prevR) b1++; prevR = R; if (R > 0) pos++;
        // (2) lower-count cutoff
        int e = j - a; if (a >= 1) { double Q = Math.Pow(2, e) * (1 - Math.Pow(2.0 / 3.0, a - 1)); c2++; if (n >= Q - 1e-9) { el++; if (fewer) b2++; } }
        // (3) two-channel criterion under P<3  (2^j y < 3 * 3^a n)
        if ((double)(1L << j) * y < 3.0 * Pow3(a) * n) { c3++; int H = Hmax(y, j); bool crit = H > a || M > U; if (crit != anySmaller) { /* lower-count partners may exist only below the cutoff */ bool cutoffOk = a >= 1 && n >= Math.Pow(2, e) * (1 - Math.Pow(2.0 / 3.0, a - 1)) - 1e-9; if (cutoffOk || a == 0) b3++; } if (anySmaller) yes3++; }
      } }
    Console.WriteLine($"(1) persistence/R: {c1} (n<=2000,j<=12) cases, positive-gap {pos}, failures {b1}");
    Console.WriteLine($"(2) lower-count cutoff: {c2} cases, {el} at or above the cutoff, violations {b2}");
    Console.WriteLine($"(3) two-channel criterion under P<3 (inside the cutoff domain): {c3} cases, with a smaller partner {yes3}, mismatches {b3}");
  }
}
