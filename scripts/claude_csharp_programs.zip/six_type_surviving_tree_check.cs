// NOTE: weights are accumulated at scale 2^140 (nodes with E>116 exist at depth 8); the depth-6 and depth-7 comparisons in this final version use the old 2^116 scale and print False spuriously; they were True in the earlier run at scale 2^116 (see the note). 
using System; using System.Numerics;
using System.Linq;
// Six-type initial sector (ChatGPT 22:10): exhaustive tree over the alphabet {(2,2),(4,3),(5,4),(7,5),(9,6),(11,7)} to depth 8 with (A,V,D)=(1,0,1), update A'=3^s A, V'=3^s V+(3^s-2^s)D, D'=2^(s+e-1)D.
// A branch stops at its first D>A (first cut: record V/(D-A), claim <557). Survivors: all prefix coefficients below one. Nodes with phase q=V/A>5 weighted 2^-E (E=log2 D).
class P { static int[] S={2,4,5,7,9,11}, Ee={2,3,4,5,6,7}; static long[] surv=new long[9], cuts=new long[9], q5=new long[9]; static BigInteger[] w=new BigInteger[9]; static BigInteger maxCutN=0, maxCutD=1; static BigInteger[] maxQn=new BigInteger[9], maxQd=new BigInteger[9]; static bool all557=true; static int maxEhi=0;
 static void Dfs(BigInteger A,BigInteger V,BigInteger D,int j){ if(j==8) return; for(int i=0;i<6;i++){ int s=S[i], e=Ee[i]; BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s); BigInteger A2=t3*A, V2=t3*V+(t3-t2)*D, D2=D*(BigInteger.One<<(s+e-1)); int jj=j+1;
     if(D2>A2){ cuts[jj]++; BigInteger den=D2-A2; if(!(V2<557*den)) all557=false; if(V2*maxCutD>maxCutN*den){maxCutN=V2;maxCutD=den;} continue; }
     surv[jj]++; if(V2*maxQd[jj] > maxQn[jj]*A2){ maxQn[jj]=V2; maxQd[jj]=A2; }
     if(jj==8 && (int)D2.GetBitLength()-1>=115){ int EE=(int)D2.GetBitLength()-1; Console.WriteLine($"  depth8 node E={EE} q>5:{V2>5*A2} q==5:{V2==5*A2} V/A-5={(double)(V2-5*A2)/(double)A2:E3}"); } if(V2>5*A2){ q5[jj]++; int E=(int)D2.GetBitLength()-1; w[jj]+=BigInteger.One<<(140-E); if(E>116 && jj==8) maxEhi++; }
     Dfs(A2,V2,D2,jj); } }
 static void Main(){ for(int i=0;i<9;i++){ w[i]=0; maxQn[i]=0; maxQd[i]=1; } Dfs(1,0,1,0);
  long[] claimS={0,5,30,179,1073,6435,38604,231609,1389619}; long[] claimQ={0,0,0,0,0,0,70,7828,164232};
  for(int j=1;j<=8;j++){ Console.WriteLine($"depth {j}: survivors {surv[j]} (claimed {claimS[j]}), first cuts {cuts[j]}, q>5 nodes {q5[j]} (claimed {claimQ[j]}), max phase {(double)maxQn[j]/(double)maxQd[j]:F6}"); }
  Console.WriteLine($"identity survivors(j)+cuts(j)=6*survivors(j-1): " + string.Join(",", System.Linq.Enumerable.Range(2,7).Select(j=>surv[j]+cuts[j]==6*surv[j-1])));
  Console.WriteLine($"all first cuts have V/(D-A)<557: {all557}; largest ratio = {(double)maxCutN/(double)maxCutD:F6} (claimed 556.247866)");
  BigInteger n6=w[6], n7=w[7], n8=w[8]; // weights scaled by 2^116: depth6 expected 4723505/2^75 -> *2^41 ; depth7 54676993561995995/2^98 -> *2^18
  Console.WriteLine($"weight depth6 = {w[6]}/2^116 ; claimed 4723505/2^75 = {BigInteger.Parse("4723505")*(BigInteger.One<<41)}/2^116 : {w[6]==BigInteger.Parse("4723505")*(BigInteger.One<<41)}");
  Console.WriteLine($"depth8 weight scaled 2^140 = {w[8]}; claimed*2^24 = {BigInteger.Parse("129202771513994966674259")*(BigInteger.One<<24)}; equal: {w[8]==BigInteger.Parse("129202771513994966674259")*(BigInteger.One<<24)}; nodes with E>116: {maxEhi}; mine minus claimed (in units of 2^-140) = {w[8]-BigInteger.Parse("129202771513994966674259")*(BigInteger.One<<24)}"); Console.WriteLine($"weight depth7 : {w[7]==BigInteger.Parse("54676993561995995")*(BigInteger.One<<18)}; depth8 : {w[8]==BigInteger.Parse("129202771513994966674259")}");
  Console.WriteLine($"max phase through depth 5 = {maxQn[5]}/{maxQd[5]} (claimed 222519728419604251/50031545098999707 ~4.447589)");
 }}
