using System;
using System.Collections.Generic;
// Independent computation of the first-source functional B(n) of ChatGPT 181416 for odd n<=NMAX:
// for each odd u in I=[n,H], follow the odd map until the first state <=H; if that state is >=n it is a first return with exact valuation word p (sources whose path drops below n have no return).
// Group by word p (hash of exponents); c(p)=(u+5)(G*Phi(w)/Phi(u)-1) (same for all sources of p); B(n)=sum over p with c>0 of c(p)/(b_p+5), b_p = least source. Claim: B(21)=B(23)=0.12018917768648638 (source 27, 37 transitions) and B(n)<0.121 for n<=65535.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long NMAX=65535; double best=0; long bestn=0; double b21=0,b23=0; long maxGap=0; long srcMax=0;
    for(long n=3;n<=NMAX;n+=2){ long H=(4*n-2)/3; var seen=new HashSet<ulong>(); double B=0;
      for(long u=n;u<=H;u+=2){ long x=u; ulong h=1469598103934665603UL; int g=0; double G=1.0; bool ret=false; long cap=100000;
        for(int step=0;step<cap;step++){ G*=1.0+1.0/(3.0*x); int e; x=A(x,out e); g++; h=(h^(ulong)e)*1099511628211UL; if(x<=H){ ret = x>=n; break; } }
        if(!ret) continue; if(g>maxGap) maxGap=g; ulong key=h^((ulong)g<<56); if(!seen.Add(key)) continue;
        double w=x; double rho=G*(1.0+5.0/w)/(1.0+5.0/u); double c=(u+5)*(rho-1); if(c>0) B+=c/(u+5); }
      if(n==21) b21=B; if(n==23) b23=B; if(B>best){best=B;bestn=n;} }
    Console.WriteLine($"n<={NMAX}: max B(n) = {best:F12} at n={bestn}; B(21)={b21:F14}, B(23)={b23:F14} (claimed 0.12018917768648638); longest first-return gap seen {maxGap}");
  }
}
