using System;
using System.Linq;
// Exact census of all primitive closed words (3^A<2^L, distinct vertices): ties (antipodal cross chords), and floating-point reliability
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); long total = 0, tie = 0, totalG = 0, tieG = 0, fpDisagree = 0, notDistinct = 0;
    for (int L = 4; L <= Lmax; L++) {
      ulong mask = (1UL << L) - 1; Int128 p2 = (Int128)1 << L;
      for (ulong w = 1; w < mask; w++) {
        int A = System.Numerics.BitOperations.PopCount(w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool canon = true; for (int r = 1; r < L && canon; r++) { ulong rot = ((w << r) | (w >> (L - r))) & mask; if (rot <= w) canon = false; } if (!canon) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) { notDistinct++; continue; }
        Int128 c = X.Min(), H = X.Max(), S = c + H; bool g1 = c >= scale; bool exactTie = false; bool fpTie = false;
        double dc = (double)c, dH = (double)H;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; if (e[i] && !e[j]) { if (X[i] + X[j] == S) exactTie = true; } if (!e[i] && e[j]) { if (3 * X[i] == 2 * S) exactTie = true; }
          // floating-point central angle as in the earlier programs
          double m = (dc + dH) / 2; double xi = (double)X[i] / (double)scale, xj = (double)X[j] / (double)scale; double cc = c == 0 ? 0 : (double)c / (double)scale, HH = (double)H / (double)scale, mm = (cc + HH) / 2;
          double yi = Math.Sqrt(Math.Max((xi - cc) * (HH - xi), 0)) * (e[i] ? 1 : -1), yj = Math.Sqrt(Math.Max((xj - cc) * (HH - xj), 0)) * (e[j] ? 1 : -1);
          double ang = Math.Atan2((xi - mm) * yj - yi * (xj - mm), (xi - mm) * (xj - mm) + yi * yj); if (Math.Abs(Math.Abs(ang) - Math.PI) < 1e-9) fpTie = true; }
        total++; if (g1) totalG++; if (exactTie) { tie++; if (g1) tieG++; } if (exactTie != fpTie) fpDisagree++;
      }
    }
    Console.WriteLine($"L<={Lmax}: primitive words with distinct vertices {total} (values>=1: {totalG}); words with an exact antipodal cross chord {tie} (values>=1: {tieG}); words where float tie-test (1e-9) disagrees with exact tie: {fpDisagree}; words with repeated vertices (excluded): {notDistinct}");
  }
}
