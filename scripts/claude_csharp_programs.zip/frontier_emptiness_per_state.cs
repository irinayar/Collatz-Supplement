using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text;
using System.Text.Json;
// Per-state output of the frontier emptiness check: canonical index (position in checkpoint stack order = Codex's index), (level,t,z,b), k=t-b,
// exact maximum odd count with exactly k even edges (inverse-tree DFS), status empty / nonempty / unresolved.
class P {
  static int maxOd; static long nodes;
  static void Dfs(BigInteger z,int ev,int od,int k){ if(++nodes>30000000) throw new Exception("cap"); if(ev==k && od>maxOd) maxOd=od; if(ev<k) Dfs(2*z,ev+1,od,k); if(z%3==2) Dfs((2*z-1)/3,ev,od+1,k); }
  static void Main(){
    var root=@"COLLATZ_ROOT\tmp\";
    var states=new List<(int idx,int t,BigInteger z,int b,int level)>(); int idx=0;
    using(var doc=JsonDocument.Parse(File.ReadAllText(root+@"fair_terminal129_batch05\checkpoint.json"))){
      foreach(var lv in doc.RootElement.GetProperty("levels").EnumerateObject()){ int level=int.Parse(lv.Name);
        foreach(var s in lv.Value.GetProperty("stack").EnumerateArray()) states.Add((idx++,s[0].GetInt32(),BigInteger.Parse(s[1].GetRawText()),s[2].GetInt32(),level)); } }
    var remIdx=new Dictionary<int,(int,BigInteger,int)>();
    using(var doc=JsonDocument.Parse(File.ReadAllText(root+@"budgets12_14\remaining_frontier.json"))){
      foreach(var e in doc.RootElement.EnumerateArray()) remIdx[e.GetProperty("index").GetInt32()]=(e.GetProperty("t").GetInt32(),BigInteger.Parse(e.GetProperty("z").GetRawText()),e.GetProperty("b").GetInt32()); }
    int idxMismatch=0; foreach(var kv in remIdx){ var s=states[kv.Key]; if(s.t!=kv.Value.Item1||s.z!=kv.Value.Item2||s.b!=kv.Value.Item3) idxMismatch++; }
    var order=new List<int>(); for(int i=0;i<states.Count;i++) order.Add(i); order.Sort((p,q)=>(states[p].t-states[p].b).CompareTo(states[q].t-states[q].b));
    var res=new Dictionary<int,string>(); var sw=System.Diagnostics.Stopwatch.StartNew(); int empty=0,non=0,unres=0,codexExclEmpty=0,extra=0;
    foreach(int i in order){ var s=states[i]; int k=s.t-s.b; bool isRem=remIdx.ContainsKey(i); string status; int mo=-1; long nd=0;
      if(sw.ElapsedMilliseconds>200000){ status="unresolved"; unres++; }
      else { maxOd=-1; nodes=0; try{ Dfs(s.z,0,0,k); mo=maxOd; nd=nodes; if(maxOd<s.b){ status="empty"; empty++; if(isRem) extra++; else codexExclEmpty++; } else { status="nonempty"; non++; } } catch{ status="unresolved"; unres++; } }
      res[i]=$"{{\"index\":{i},\"level\":{s.level},\"t\":{s.t},\"z\":{s.z},\"b\":{s.b},\"k\":{k},\"codex_status\":\"{(isRem?"pending":"excluded")}\",\"max_odd_count\":{(mo<0?"null":mo.ToString())},\"status\":\"{status}\",\"nodes\":{nd}}}"; }
    var sb=new StringBuilder(); sb.AppendLine("["); for(int i=0;i<states.Count;i++) sb.AppendLine("  "+res[i]+(i<states.Count-1?",":"")); sb.AppendLine("]");
    File.WriteAllText(root+@"collatz_two_arc\frontier_emptiness_claude_results.json",sb.ToString());
    Console.WriteLine($"index/tuple mismatches vs remaining_frontier.json: {idxMismatch}; states {states.Count}: empty {empty} (Codex-excluded {codexExclEmpty}, previously pending {extra}), nonempty {non}, unresolved {unres}");
  }
}
