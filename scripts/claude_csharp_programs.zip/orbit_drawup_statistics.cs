using System;
using System.Threading.Tasks;
// Drawup of the word-walk along actual orbits:  D_eps(n) = max_{i<j} [ X_j - X_i + eps (j - i) ]  over the whole orbit of n (until 1),
// X_j = A_j ln 3 - j ln 2.  Segment contraction (SC) with slope eps holds with constant C = exp(D_eps).  Echo identity: z_j = n e^{X_j} + (1/3) sum_{odd i<j} e^{X_j - X_i}.
static class P {
  static void Main(string[] args) {
    long N = long.Parse(args[0]); double[] eps = { 0.0, 0.02, 0.05, 0.1 }; double[] best = new double[4]; long[] bestN = new long[4]; double[] bestRatio = new double[4]; long[] bestRN = new long[4]; object lk = new object();
    Parallel.For(0, 64, ch => {
      long per = (N + 63) / 64; long a0 = Math.Max(2, ch * per + 1), a1 = Math.Min(N, (ch + 1) * per); double[] lb = new double[4]; long[] lbn = new long[4]; double[] lr = new double[4]; long[] lrn = new long[4];
      for (long n = a0; n <= a1; n++) {
        ulong x = (ulong)n; double X = 0; int j = 0; double[] minZ = { 0, 0, 0, 0 }; double[] dmax = { 0, 0, 0, 0 };
        while (x != 1) { if ((x & 1) == 0) { x >>= 1; X -= 0.6931471805599453; } else { x = (3 * x + 1) >> 1; X += 0.4054651081081644; } j++;
          for (int e = 0; e < 4; e++) { double Z = X + eps[e] * j; double d = Z - minZ[e]; if (d > dmax[e]) dmax[e] = d; if (Z < minZ[e]) minZ[e] = Z; } }
        double ln = Math.Log(n);
        for (int e = 0; e < 4; e++) { if (dmax[e] > lb[e]) { lb[e] = dmax[e]; lbn[e] = n; } double r = dmax[e] / ln; if (r > lr[e]) { lr[e] = r; lrn[e] = n; } }
      }
      lock (lk) for (int e = 0; e < 4; e++) { if (lb[e] > best[e]) { best[e] = lb[e]; bestN[e] = lbn[e]; } if (lr[e] > bestRatio[e]) { bestRatio[e] = lr[e]; bestRN[e] = lrn[e]; } }
    });
    for (int e = 0; e < 4; e++) Console.WriteLine($"eps = {eps[e]}: max drawup D over n <= {N}: {best[e]:F3} at n = {bestN[e]} (ln n = {Math.Log(bestN[e]):F2}); max D/ln n = {bestRatio[e]:F3} at n = {bestRN[e]}");
  }
}
