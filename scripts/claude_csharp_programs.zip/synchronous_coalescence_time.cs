using System;
using System.Collections.Generic;
// Synchronous coalescence time tau(n) = least k such that some smaller start n' < n has T^{k-1}(n') = T^{k-1}(n).
// Only starts that are still minimal (M_k) are tracked: a start whose coincident smaller start is itself non-minimal is
// also coincident with an even smaller minimal start, so this loses nothing.
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]);
    var st = new List<int>(N); var val = new List<long>(N);
    for (int n = 1; n <= N; n++) { st.Add(n); val.Add(n); }
    long sumTau = 0; int maxTau = 0, argMax = 0; var tauHist = new Dictionary<int, int>();
    int[] marks = { 1, 2, 3, 5, 6, 10, 20, 50, 100, 200 };
    for (int k = 1; ; k++) {
      if (Array.IndexOf(marks, k) >= 0 || st.Count <= 2) Console.WriteLine($"k={k,3}: |M_k|={st.Count,8}  |M_k|/N={(double)st.Count / N:F5}");
      if (st.Count <= 2) break;
      var first = new Dictionary<long, int>(st.Count); var st2 = new List<int>(st.Count); var val2 = new List<long>(st.Count);
      for (int i = 0; i < st.Count; i++) {
        long v = val[i];
        if (first.ContainsKey(v)) { int tau = k + 1; sumTau += tau; if (tau > maxTau) { maxTau = tau; argMax = st[i]; } continue; }
        first[v] = st[i];
        long y = (v & 1) == 1 ? (3 * v + 1) / 2 : v / 2; st2.Add(st[i]); val2.Add(y);
      }
      // starts removed at this step become non-minimal at depth k+1 (tau = k+1)
      st = st2; val = val2;
      // dedupe check: after update values may coincide; they are detected at next iteration
    }
    Console.WriteLine($"remaining minimal starts: {string.Join(",", st)};  max tau = {maxTau} at n = {argMax};  mean tau over the {N - 2} starts n>=3: {(double)sumTau / (N - 2):F3}");
  }
}
