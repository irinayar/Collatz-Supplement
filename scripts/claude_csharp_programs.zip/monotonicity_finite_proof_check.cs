using System;
using System.Collections.Generic;
// Finite proof of strict monotonicity of H_k(x,r) in r for fixed k:
// Lemma E: if Y is an origin with (k,r) ending at x and Y >= 3*2^k-4, then every origin X' with (k,r+1) ending at x satisfies X' < Y.
// So only pairs (x,r) with H_k(x,r) < B=3*2^k-4 need checking; they all arise from origins m<B.
class P {
  static int V3(long n){int c=0; while(n%3==0){n/=3;c++;} return c;}
  static long Pw3(int e){long r=1; for(int i=0;i<e;i++) r*=3; return r;}
  static int R(long x,int k){ int a=V3(x+1); if(k==0) return a; int best=-1;
    for(int l=0;l<=a;l++){ long y=((x+1)/Pw3(l)<<l)-1; int t=l+R(2*y,k-1); if(t>best) best=t; } return best; }
  static void Main(string[] args){
    int K=int.Parse(args.Length>0?args[0]:"16");
    for(int k=0;k<=K;k++){ long B=3L*(1L<<k)-4; var best=new Dictionary<(long,int),long>();
      for(long m=1;m<B;m++){ long y=m; int e=0,o=0; for(int step=0;step<10000;step++){ if(e==k){ if(!best.ContainsKey((y,o))) best[(y,o)]=m; }
          if(e>k) break; if((y&1)==1){ y=(3*y+1)/2; o++; } else { y/=2; e++; } if(e>k) break; } }
      long pairs=0,ok=0,top=0,viol=0;
      foreach(var kv in best){ pairs++; long x=kv.Key.Item1; int r=kv.Key.Item2; long h=kv.Value;
        if(best.TryGetValue((x,r+1),out var hp)&&hp<h){ ok++; continue; }
        int Rk=R(x,k); if(r+1>Rk) top++; else { viol++; if(viol<=3) Console.WriteLine($"  candidate violation k={k} x={x} r={r} h={h} R={Rk}"); } }
      Console.WriteLine($"k={k}: B={B}, exceptional pairs (x,r) with H<B: {pairs}, successor smaller found: {ok}, top of series (r=R_k(x)): {top}, violations: {viol}");
    }
  }
}
