using System;
using System.Collections.Generic;
// Independent check of Codex M90/K094 (residue even-cost table d_p) and K098 (first-odd composition): compare with exact integer shortest paths.
class P {
  const int INF=1000000;
  static long[] pw3=new long[12];
  static int[][] d=new int[10][];
  static void BuildTables(int pmax){ d[0]=new int[]{0};
    for(int p=1;p<=pmax;p++){ long M=pw3[p]; var cur=new int[M]; var b=new int[M];
      for(long a=0;a<M;a++){ if(a%3==2){ long z=(2*a-1)/3; b[a]=d[p-1][z%pw3[p-1]]; } else b[a]=INF; }
      for(long a=0;a<M;a++) cur[a]=b[a];
      bool ch=true; while(ch){ ch=false; for(long a=0;a<M;a++){ int v=cur[(2*a)%M]+1; if(v<cur[a]){ cur[a]=v; ch=true; } } }
      d[p]=cur; } }
  // exact: min evens to perform n odd inverse steps from x (cap cmax); 0-1 BFS by layers of even count
  static int Exact(long x,int n,int cmax){
    var layer=new HashSet<(long,int)>(); layer.Add((x,0));
    for(int j=0;j<=cmax;j++){ // closure under odd edges
      var q=new Stack<(long,int)>(layer); while(q.Count>0){ var (z,o)=q.Pop(); if(o==n) return j; if(z%3==2){ var nx=((2*z-1)/3,o+1); if(layer.Add(nx)) q.Push(nx); } }
      foreach(var (z,o) in layer) if(o==n) return j;
      var next=new HashSet<(long,int)>(); foreach(var (z,o) in layer) if(o<n) next.Add((2*z,o)); layer=next; }
    return INF; }
  static int Comp(long x,int q,int p,int k){ // F_(q,p)(x;k), clipped at k+1
    if(q==0) return Math.Min(k+1,d[p][x%pw3[p]]);
    int best=k+1; long z=x; for(int j=0;j<=k;j++){ if(z%3==2){ long y=(2*z-1)/3; int sub=Comp(y,q-1,p,k-j); if(j+sub<best) best=j+sub; } z=2*z; if(z>(1L<<58)) break; } return best; }
  static void Main(){
    pw3[0]=1; for(int i=1;i<12;i++) pw3[i]=pw3[i-1]*3; BuildTables(8);
    long cells=0,bad=0; int maxCost=0;
    for(int p=1;p<=8;p++){ int worst=0; for(long x=1;x<=1500;x++){ int e=Exact(x,p,16); int t=d[p][x%pw3[p]]; if(t>16) t=INF; if(e>16) e=INF; cells++; if(e!=t) bad++; if(t<INF&&t>worst) worst=t; } maxCost=Math.Max(maxCost,worst); }
    Console.WriteLine("M90 table d_p (p=1..8, built by my own fixpoint) vs exact integer shortest even-cost, x<=1500 (costs capped at 16): cells " + cells + ", mismatches " + bad);
    var mx=new List<string>(); for(int p=0;p<=8;p++){ int m=0; foreach(var v in d[p]) if(v<INF&&v>m) m=v; mx.Add(p+":"+m); } Console.WriteLine("max finite cost by precision: " + string.Join(", ",mx) + " (Codex: 0,1,4,6,7,9,10,11,12)");
    long c2=0,b2=0; for(int p=1;p<=5;p++) for(int q=1;q<=2;q++) for(long x=1;x<=800;x++){ int k=16; int f=Comp(x,q,p,k); int e=Exact(x,p+q,k); if(e>k) e=k+1; c2++; if(f!=e) b2++; }
    Console.WriteLine("K098 composition F_(q,p) (q=1,2; p=1..5; clipped at k=16) vs exact shortest path for p+q odd steps, x<=800: cells " + c2 + ", mismatches " + b2);
  }
}
