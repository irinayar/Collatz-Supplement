using System;
using System.Numerics;
// Concrete checks for the audit of "CollatzBounded" (Diedrich, preprints 202502.1495): (1) case (b) claim 'k consecutive odd-even pairs reduce the value by (13/8)^k' vs reality; (2) Theorem 1 with N=a_0 is exactly 'finite stopping time'; (3) cycle identity 2^e=prod(3+1/n_i) forces 1.585 o < e < 1.7 o for cycles with all elements >4, consistent with e>=o (no contradiction).
class P {
  static void Main(){
    BigInteger x0=(BigInteger.One<<21)-1; BigInteger x=x0; Console.WriteLine("(1) x0=2^21-1: value/x0 after 2k plain iterations (odd,even pairs): ");
    for(int k=1;k<=10;k++){ // two plain iterations: odd -> 3x+1 -> (3x+1)/2
      x=3*x+1; x/=2; Console.WriteLine($"   k={k}: ratio {(double)x/(double)x0:F4}  vs claimed reduction factor (13/8)^k={Math.Pow(13.0/8,k):F2}: value is {(x>x0?"LARGER":"smaller")}"); }
    // (2) stopping times
    foreach(long n in new long[]{27,97,871}){ long v=n; int idx=0; while(v>=n || idx==0){ v= (v%2==0)? v/2 : 3*v+1; idx++; if(v<n) break; } Console.WriteLine($"(2) n={n}: first index with a_q<N=a_0: q={idx} (plain Collatz steps)"); }
    // (3) window for cycles
    double lo=Math.Log(3)/Math.Log(2), hi=Math.Log2(3.25); Console.WriteLine($"(3) for a cycle with all elements>4 and o odd terms: 3^o<2^e<(3.25)^o => {lo:F4} o < e < {hi:F4} o ; e>=o is automatic (each odd term is followed by an even one): no contradiction. Example o=100: e in ({lo*100:F1},{hi*100:F1}) integers {Math.Floor(lo*100)+1}..{Math.Ceiling(hi*100)-1}");
    // trivial cycle check: o=1,e=2: 2^2=4=3+1/1
    Console.WriteLine($"    trivial cycle 1->4->2->1: o=1, e=2, 2^e=4 = 3+1/1: {4==3+1}");
    // dichotomy (a)/(b) counterexample: find a start whose first-descent trajectory (staying above start) has max even-run < 6 and max (odd,even)-pair run < 3 although it is long
    int bestLen=0; long bestN=0; int bestEven=0,bestPair=0;
    for(long n=3;n<=200000;n+=2){ long v=n; int len=0,evenRun=0,maxEven=0, pairRun=0,maxPair=0; bool prevOdd=false; int idx=0; var path=new System.Collections.Generic.List<long>(); while(true){ path.Add(v); v=(v%2==0)? v/2 : 3*v+1; idx++; if(v<n||idx>5000) break; }
      // runs on parity pattern
      int run=0; int maxE=0; for(int i=0;i<path.Count;i++){ if(path[i]%2==0){ run++; maxE=Math.Max(maxE,run);} else run=0; }
      // consecutive (odd,even) pairs: pattern O,E,O,E,... : count maximal alternating runs of pairs
      int pr=0,maxP=0; for(int i=0;i+1<path.Count;){ if(path[i]%2==1 && path[i+1]%2==0){ pr++; maxP=Math.Max(maxP,pr); i+=2; } else { pr=0; i++; } }
      if(path.Count>bestLen && maxE<6 && maxP<4){ bestLen=path.Count; bestN=n; bestEven=maxE; bestPair=maxP; } }
    Console.WriteLine($"(4) example of a long first-descent trajectory with max consecutive evens {bestEven} (<6) and max consecutive odd-even pairs {bestPair} (<4): start {bestN}, length {bestLen} iterations (the dichotomy 'k consecutive evens or k consecutive odd-even pairs' gives no argument at these k)");
  }
}
