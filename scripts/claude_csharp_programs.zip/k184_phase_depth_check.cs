using System;
// K184 section 1 on actual returns: for every proper odd input index g (g>=1) with phase q_g (Q after g odd inputs): check q_g < u g/(3u-g) and report the largest ratio q_g/(u g/(3u-g));
// and the smallest odd index g at which the phase exceeds B=5.04 (K184: g >= floor(3uB/(u+B))+1 = 16 for large u). Also the suffix bound d < (u+q_g) r/(3H-r) with d=Q-q_g, r=N-g.
class P {
  static void Main(string[] args) {
    foreach (string sn in args) {
      long n = long.Parse(sn) | 1; long H = (4 * n - 2) / 3; double B = 5.04; long ret = 0, viol = 0, violSuf = 0; double maxRatio = 0, maxRatioSuf = 0; int minGB = int.MaxValue; long minGBu = 0;
      for (long u = n; u <= H; u += 2) {
        long x = u; double Z = 1.0, Q = 0.0; bool r = false; int steps = 0; var qs = new System.Collections.Generic.List<double>(); qs.Add(0);
        while (steps < 100000) { long t = 3 * x + 1; int ev = System.Numerics.BitOperations.TrailingZeroCount((ulong)t); t >>= ev; Q += Z / 3.0; Z = Z * Math.Pow(2, ev) / 3.0; qs.Add(Q); x = t; steps++;
          if (x < n) break; if (x <= H) { r = true; break; } if (x > (1L << 60)) break; }
        if (!r) continue; ret++; int N = steps; double Qt = Q;
        for (int g = 1; g < N; g++) {
          double qg = qs[g]; double bound = (double)u * g / (3.0 * u - g); double ratio = qg / bound; if (ratio > maxRatio) maxRatio = ratio; if (qg >= bound) viol++;
          if (qg > B && g < minGB) { minGB = g; minGBu = u; }
          double d = Qt - qg; int rr = N - g; if (rr < 3.0 * H) { double bs = (u + qg) * rr / (3.0 * H - rr); double rs = d / bs; if (rs > maxRatioSuf) maxRatioSuf = rs; if (d >= bs) violSuf++; }
        }
      }
      Console.WriteLine($"n={n}: returns={ret}; prefix bound q_g<u g/(3u-g): violations={viol}, max ratio={maxRatio:F4}; suffix bound violations={violSuf}, max ratio={maxRatioSuf:F4}; smallest odd index with q_g>5.04: g={(minGB == int.MaxValue ? -1 : minGB)} (u={minGBu})");
    }
  }
}
