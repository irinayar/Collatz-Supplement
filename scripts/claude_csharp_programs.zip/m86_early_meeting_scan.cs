using System;
using System.Collections.Generic;
using System.Linq;
// M86-style incremental forward closure.  C(n-1) = set of all values visited by the orbits of 1..n-1 (accelerated map).
// For each n: walk the orbit of n until the first value that lies in C(n-1); the entry is an "early meeting" if that value is >= n (a smaller integer reaches it)
// and a "descent entry" if it is < n.  Every n whose first entry is a descent has a complete M86 certificate: C(n-1) is forward closed, contains 1..n-1 and is disjoint
// from the pre-descent path of n, so NO smaller integer meets that path at ANY time.
static class P {
  static ulong[] tab; static ulong mask; static long count = 0;
  static bool Has(ulong v) { ulong h = (v * 0x9E3779B97F4A7C15UL) >> 20 & mask; while (true) { ulong t = tab[h]; if (t == v) return true; if (t == 0) return false; h = (h + 1) & mask; } }
  static void Add(ulong v) { ulong h = (v * 0x9E3779B97F4A7C15UL) >> 20 & mask; while (true) { ulong t = tab[h]; if (t == v) return; if (t == 0) { tab[h] = v; count++; return; } h = (h + 1) & mask; } }
  static ulong S(ulong x) => (x & 1) == 0 ? x >> 1 : (3 * x + 1) >> 1;
  static void Main(string[] args) {
    long N = long.Parse(args[0]); int bits = args.Length > 1 ? int.Parse(args[1]) : 26; tab = new ulong[1UL << bits]; mask = (1UL << bits) - 1;
    Add(1); Add(2); // C(1) = {1,2}: orbit of 1 under S is 1 -> 2 -> 1
    long[] bkTot = new long[6], bkEarly = new long[6], bkStep0 = new long[6]; long[] savedSum = new long[6]; long early = 0, noEarly = 0; long[] cum = { 1000, 10000, 100000, 1000000, 10000000, 100000000 }; int ci = 0; var firstNoEarly = new List<long>(); var earlyHist = new SortedDictionary<int, long>(); long maxEarlyStep = 0; long maxDescentStep = 0; long maxDescNoEarlyN = 0;
    long noEarlyThisDecade = 0, thisDecade = 0, decStart = 2;
    for (long n = 2; n <= N; n++) {
      ulong x = (ulong)n; int step = 0; var path = new List<ulong>(); bool earlyMeet = false;
      while (true) { if (Has(x)) { earlyMeet = x >= (ulong)n; break; } path.Add(x); x = S(x); step++; if (step > 100000) throw new Exception("long orbit"); }
      foreach (var v in path) Add(v); int sigma; { ulong y = (ulong)n; sigma = 0; do { y = S(y); sigma++; } while (y >= (ulong)n); } int bk = sigma <= 8 ? 0 : sigma <= 16 ? 1 : sigma <= 32 ? 2 : sigma <= 64 ? 3 : sigma <= 128 ? 4 : 5; bkTot[bk]++; if (earlyMeet) { bkEarly[bk]++; if (step == 0) bkStep0[bk]++; savedSum[bk] += sigma - step; }
      // note: n itself is added (path[0]); values < n are already there
      if (earlyMeet) { early++; int b = step == 0 ? 0 : (int)Math.Floor(Math.Log2(step)); earlyHist[b] = earlyHist.GetValueOrDefault(b) + 1; if (step > maxEarlyStep) maxEarlyStep = step; }
      else { noEarly++; if (firstNoEarly.Count < 40) firstNoEarly.Add(n); if (step > maxDescentStep) { maxDescentStep = step; maxDescNoEarlyN = n; } }
      thisDecade++; if (!earlyMeet) noEarlyThisDecade++;
      if (ci < cum.Length && n == cum[ci]) { Console.WriteLine($"n <= {n}: early smaller meeting before descent exists for {early} of {early + noEarly} ({(double)early / (early + noEarly):P2}); NO early meeting (descent entry only) for {noEarly} ({(double)noEarly / (early + noEarly):P2}); |C| = {count}"); ci++; }
    }
    string[] bn = { "sigma<=8", "9-16", "17-32", "33-64", "65-128", ">128" }; for (int k = 0; k < 6; k++) Console.WriteLine($"descent time {bn[k]}: {bkTot[k]} integers, early smaller meeting exists for {(double)bkEarly[k] / Math.Max(1, bkTot[k]):P2} (of which meeting at step 0 (n in C): {(double)bkStep0[k] / Math.Max(1, bkEarly[k]):P1}; average steps saved {(double)savedSum[k] / Math.Max(1, bkEarly[k]):F1})");
    if (args.Length > 2) { ulong nc = (ulong)(N + 1); bool ok1 = true, ok2 = true, ok3 = true; for (ulong v = 1; v < nc; v++) if (!Has(v)) { ok1 = false; break; } ulong cmax = 0; long cnt = 0; for (long i = 0; i < tab.LongLength; i++) { ulong v = tab[i]; if (v == 0) continue; cnt++; if (v > cmax) cmax = v; if (!Has(S(v))) { ok2 = false; } } var P1 = new List<ulong>(); { ulong y = nc; while (y >= nc) { P1.Add(y); y = S(y); } } foreach (var v in P1) if (Has(v)) ok3 = false; Console.WriteLine($"M86 certificate for n = {nc}: C(n-1) has {cnt} states, max {cmax}; contains 1..n-1: {ok1}; forward closed S(C) in C: {ok2}; pre-descent path ({P1.Count} states, peak {P1.Max()}) disjoint from C: {ok3}"); if (nc <= 40) { var lst = new List<ulong>(); for (long i = 0; i < tab.LongLength; i++) if (tab[i] != 0) lst.Add(tab[i]); lst.Sort(); Console.WriteLine("C(" + (nc - 1) + ") = {" + string.Join(", ", lst) + "}"); Console.WriteLine("pre-descent path of " + nc + ": " + string.Join(" -> ", P1) + " -> " + S(P1[P1.Count - 1]) + " (< " + nc + ")"); } }
    Console.WriteLine("first n with no early meeting at any length (M86-certifiable): " + string.Join(", ", firstNoEarly));
    Console.WriteLine($"longest pre-descent path among no-early-meeting n: {maxDescentStep} steps at n = {maxDescNoEarlyN}; longest time to an early meeting: {maxEarlyStep} steps");
    Console.WriteLine("time-to-early-meeting histogram (floor log2 steps): " + string.Join(" ", earlyHist.Select(kv => (1 << kv.Key) + ":" + kv.Value)));
  }
}
