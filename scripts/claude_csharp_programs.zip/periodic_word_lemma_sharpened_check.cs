using System;
using System.Numerics;
using System.Collections.Generic;
// Sharpened Lemma P': for ANY word W (D=2^E-3^a, U odd), exact realiser x of W^N: 2^(EN+1) | (D x - U); so x=U/D or |D x-U|>=2^(EN+1).
// Test (i) all 340 words a<=4,e<=4, N<=5; (ii) ChatGPT 121127 motifs, N<=8 (check q x + B divisibility by 2^(EN+1), q=3^r-2^E, B=U).
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger Least(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static (bool,bool) Check(int[] w,int N){ // returns (divisibility ok, bound ok)
    int a=w.Length,E=0; foreach(var v in w) E+=v; BigInteger U=0,Pp=1; foreach(var v in w){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger D=(BigInteger.One<<E)-BigInteger.Pow(3,a);
    var e=new List<int>(); for(int k=0;k<N;k++) e.AddRange(w); BigInteger x=Least(e); if(x<0) return (false,false);
    BigInteger t=BigInteger.Abs(D*x-U); BigInteger m=BigInteger.One<<(E*N+1);
    bool dv=(t%m).IsZero; bool bd=(D*x==U)||(t>=m); return (dv,bd); }
  static void Main(){
    long n=0,bad=0;
    for(int a=1;a<=4;a++){ int tot=1; for(int i=0;i<a;i++) tot*=4; for(int code=0;code<tot;code++){ var w=new int[a]; int c=code; for(int i=0;i<a;i++){ w[i]=1+c%4; c/=4; } for(int N=1;N<=5;N++){ var (d,b)=Check(w,N); n++; if(!d||!b){bad++; Console.WriteLine($"FAIL {string.Join(",",w)} N={N}");} } } }
    Console.WriteLine($"(i) words a<=4: {n} (word,N) cases, failures {bad} of 2^(EN+1) | (Dx-U) and size bound");
    long n2=0,bad2=0; var motifs=new int[][]{ new[]{2,1}, new[]{2,1,1}, new[]{2,1,2,1,1}, new[]{2,1,1,2,1}, new[]{1,2,1,1,2,1}, new[]{2,1,2,1,2,1,1,1} };
    foreach(var w in motifs){ for(int N=1;N<=8;N++){ var (d,b)=Check(w,N); n2++; if(!d||!b){bad2++; Console.WriteLine($"FAIL motif {string.Join(",",w)} N={N}");} }
      int E=0; foreach(var v in w) E+=v; BigInteger U=0,Pp=1; foreach(var v in w){ U=3*U+Pp; Pp*=(BigInteger.One<<v);} Console.WriteLine($"  motif ({string.Join(",",w)}): p={BigInteger.Pow(3,w.Length)} d={BigInteger.One<<E} q={BigInteger.Pow(3,w.Length)-(BigInteger.One<<E)} B={U}"); }
    Console.WriteLine($"(ii) ChatGPT motifs: {n2} cases, failures {bad2}");
  }
}
