using System; using System.Numerics;
// K188 unresolved singleton: u=2^256-1, n=3*2^254+1. Rebuild 256 odd transitions exactly, check word/heights, recompute q, reciprocal budget b, caps, optimal S.
class P { static double Dbl(BigInteger a, BigInteger b){ int sh=(int)Math.Max(0,(long)Math.Max(a.GetBitLength(),b.GetBitLength())-900); return (double)(a>>sh)/(double)(b>>sh);} 
 static void Main(){
  BigInteger u=(BigInteger.One<<256)-1, n=3*(BigInteger.One<<254)+1, H=(4*n-2)/3; Console.WriteLine($"H=2^256? {H==(BigInteger.One<<256)}; u in [n,H]? {u>=n&&u<=H}");
  BigInteger x=u, Bn=0; int E=0; var word=new System.Collections.Generic.List<int>(); bool allAbove=true; double sumInv=0; var seen=new System.Collections.Generic.HashSet<BigInteger>(); bool distinct=true;
  for(int i=0;i<256;i++){ if(!seen.Add(x)) distinct=false; sumInv+=1.0/Math.Pow(2,0)*Dbl(1,x); BigInteger t=3*x+1; int e=0; while((t&1)==0){t>>=1;e++;} word.Add(e); Bn=3*Bn+(BigInteger.One<<E); E+=e; x=t; if(x<=H) allAbove=false; }
  int ones=0; foreach(int e in word) if(e==1) ones++; Console.WriteLine($"word: {ones} ones, last exponent {word[255]}; all outputs>H: {allAbove}; inputs distinct: {distinct}; sum 1/x_i = {sumInv:E3}");
  double q=Dbl(Bn,BigInteger.Pow(3,256)); Console.WriteLine($"q (numerator phase B/3^256) = {q:E4}  (compare phase u*(G-1) exact below)");
  int L=(int)(H+1).GetBitLength()-1; Console.WriteLine($"L={L}");
  double uD=Math.Pow(2,256), base1=15.0/32.0, best=1e9; int bestS=-1;
  for(int S=0;S<=2*L;S++){ double B=(Math.Pow(3,Math.Min(S,160))/Math.Pow(2,L)); if(S>160) B=Math.Exp(S*Math.Log(3)-L*Math.Log(2)); B+= (200.0/7)*Math.Pow(193.0/200,S+1) + (L+1)*Math.Pow(2,-(L-1));
    double b=Math.Min(144.0/125-sumInv, B-0.0); double cap1=base1, cap2=q/uD+(47.0/32)*b/3, cap3=Math.Exp(b/3)-1+ (q/uD)*Math.Exp(b/3); double c=Math.Min(cap1,Math.Min(cap2,cap3)); if(c<best){best=c;bestS=S;}
    if(S==156) Console.WriteLine($"S=156: B_L={B:E6}, b={b:E6}, cap/u: min({cap1:F6},{cap2:F6},{cap3:F6}) = {c:F9}, ratio to 15/32 = {c/base1:F12}"); }
  Console.WriteLine($"best S over 0..{2*L} = {bestS}, cap/u={best:F9}, ratio {best/base1:F12}");
 }}
