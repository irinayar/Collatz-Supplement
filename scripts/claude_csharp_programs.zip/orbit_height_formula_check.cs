using System;
using System.Numerics;
// Check: z_j = e^{X_j} (n + (1/3) sum_{odd steps i<j} e^{-X_i}),  X_i = A_i ln 3 - i ln 2   (exact), and the two-sided bound
//   e^{X_j - m_j^o}/3 <= z_j <= e^{X_j} (n + (A_j/3) e^{-m_j^o}),  m_j^o = min over odd-step times i<j of X_i.
static class P {
  static void Main() {
    long bad = 0, checks = 0; double maxRel = 0; var rng = new Random(5); var starts = new System.Collections.Generic.List<BigInteger>();
    foreach (var s in new[] { "27", "871", "8088063", "4064460795", "18839651253368551" }) starts.Add(BigInteger.Parse(s));
    for (int i = 0; i < 200; i++) starts.Add(new BigInteger(rng.NextInt64(2, 1L << 50)));
    foreach (var n in starts) {
      BigInteger z = n; int a = 0; double X = 0; double S = 0; double mo = double.PositiveInfinity; double ln3 = Math.Log(3), ln2 = Math.Log(2); double nd = (double)n;
      for (int j = 0; j < 600 && z != 1; j++) {
        // state before step j: z = z_j, X = X_j, S = (1/3) sum over odd i<j of exp(-X_i) ; odd flag of step j
        double zd = Math.Exp(Math.Log((double)z)); double pred = Math.Exp(X) * (nd + S); double rel = Math.Abs(pred - zd) / zd; if (j > 0) { if (rel > maxRel) maxRel = rel; }
        if (!double.IsInfinity(mo) && j > 0) { double lo = Math.Exp(X - mo) / 3, hi = Math.Exp(X) * (nd + a * 0 + (double)CountOdd(a, j) / 3 * Math.Exp(-mo)); checks++; if (zd < lo * (1 - 1e-9) || zd > hi * (1 + 1e-9)) bad++; }
        bool odd = !z.IsEven; if (odd) { S += Math.Exp(-X) / 3; if (X < mo) mo = X; z = (3 * z + 1) / 2; a++; X += ln3 - ln2; } else { z /= 2; X -= ln2; }
      }
    }
    Console.WriteLine($"{starts.Count} orbits, {checks} two-sided bound checks, violations {bad}; max relative error of the exact formula z_j = e^X_j (n + S_j) in double precision: {maxRel:E2}");
  }
  static int CountOdd(int a, int j) => a;
}
