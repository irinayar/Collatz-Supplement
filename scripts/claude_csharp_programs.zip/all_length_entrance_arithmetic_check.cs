using System; using System.Numerics;
// ChatGPT All-Length Entrance (21:12): arithmetic checks. D=84297/2^34; (13): (1/26){D/4+(1+39*73^2)/(4*2^71-1)}<1/21e6; error term decreasing in k (k^2+2k-1>0);
// 8143/18e6-1/21e6=11399/25.2e6; count of expanding first types (s in 2..272, e>=2, 2^(s+e-1)<3^s) = 21583, times 4 = 86332.
class P { static void Main(){
 // D
 BigInteger[] smin={2,4,6,7,9,11}; BigInteger num=BigInteger.One<<16; // 2^16 base for 1
 BigInteger sum=num; for(int i=0;i<6;i++){ int e=i+2; int ex=(int)smin[i]+e-2; sum+=BigInteger.One<<(16-ex); }
 Console.WriteLine($"1+sum_e 2^-(smin+e-2) = {sum}/65536 ; D = {sum}/2^34 ; claimed 84297: {sum==84297}");
 // (13) exact: (1/26)(D/4 + (1+39*73^2)/(4*2^71-1)) < 1/21e6  <=>  21e6 * (D/4 + R) < 26
 BigInteger Dn=84297, Dd=BigInteger.One<<34; BigInteger Rn=1+39*73*73, Rd=4*(BigInteger.One<<71)-1;
 // D/4 + R = (Dn*Rd + 4*Rn*Dd)/(4*Dd*Rd)
 BigInteger lhsN=21000000*(Dn*Rd+4*Rn*Dd), lhsD=4*Dd*Rd; Console.WriteLine($"(13) holds exactly: {lhsN<26*lhsD}; value (1/26)(...) = {(double)(Dn*Rd+4*Rn*Dd)/(double)(4*Dd*Rd)/26:E6} vs 1/21e6 = {1.0/21e6:E6}");
 // decreasing error term: E(k) = (1+39(k+2)^2)/(4*2^k-1) strictly decreasing for k>=71 (check 71..400 using doubles on logs)
 bool dec=true; for(int k=71;k<400;k++){ double e1=(1+39.0*(k+2)*(k+2))/(4*Math.Pow(2,k)-1), e2=(1+39.0*(k+3)*(k+3))/(4*Math.Pow(2,k+1)-1); if(!(e2<e1)) dec=false; } Console.WriteLine($"error term decreasing k=71..399: {dec}; 2(k+2)^2-(k+3)^2 = k^2+2k-1 >0 at k=71: {71*71+2*71-1}");
 Console.WriteLine($"8143/18e6 - 1/21e6 = {(new BigInteger(8143)*21000000 - new BigInteger(18000000))}/{new BigInteger(18000000)*21000000} ; 11399/25200000 = ({new BigInteger(11399)*18000000*21000000}/{new BigInteger(25200000)*18000000*21000000}) equal: {(new BigInteger(8143)*21000000 - 18000000)*25200000 == new BigInteger(11399)*(new BigInteger(18000000)*21000000)}");
 int cnt=0; for(int s=2;s<=272;s++){ BigInteger t3=BigInteger.Pow(3,s); for(int e=2;e<=2000;e++){ if(BigInteger.One<<(s+e-1) < t3) cnt++; else break; } }
 Console.WriteLine($"expanding first types (s=2..272, e>=2, 2^(s+e-1)<3^s): {cnt} (claimed 21583); x4 = {4*cnt} (claimed 86332)");
 Console.WriteLine($"3^273 < 2^433: {BigInteger.Pow(3,273)<(BigInteger.One<<433)}; H_max bit length of floor((2^274-6)/3) = {(((BigInteger.One<<274)-6)/3).GetBitLength()}");
}}
