using System; using System.Collections.Generic; using System.IO; using System.Linq; using System.Numerics;
class P {
 struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ if(b<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g>1){a/=g;b/=g;} n=a;d=b; }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator-(F x,F y)=>new F(x.n*y.d-y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static F operator/(F x,F y)=>new F(x.n*y.d,x.d*y.n);
  public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d;
  public double D => (double)(x1()) ; double x1(){ int s=Math.Max(0,(int)(d.GetBitLength()-60)); return (double)(n>>s)/(double)(d>>s); } }
 static BigInteger P2(int k)=>BigInteger.One<<k; static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static bool Alive(int a,int j)=>P3(a)>P2(j);
 static Dictionary<int,BigInteger> Step(Dictionary<int,BigInteger> S,int j){ var T=new Dictionary<int,BigInteger>(); foreach(var kv in S) for(int b=0;b<2;b++){ int a=kv.Key+b; if(!Alive(a,j)) continue; T[a]=T.GetValueOrDefault(a)+kv.Value; } return T; }
 static BigInteger Sum(Dictionary<int,BigInteger> S){ BigInteger s=0; foreach(var v in S.Values)s+=v; return s; }
 static bool Excl(ulong r,out int a){ UInt128 x=r; a=0; for(int j=1;j<=27;j++){ if((x&1)==1){a++; x=(3*x+1)/2;} else x/=2; UInt128 pw=(UInt128)1<<j; UInt128 p3=1; for(int q=0;q<a;q++)p3*=3; if(p3<pw) return true; if(x%3==2){ UInt128 m=(2*x-1)/3; if(m<r && 2*p3<3*pw) return true; } } return false; }
 static List<(BigInteger res,int j)> rules=new();
 static F Unc(BigInteger pre,int d){ bool deeper=false; foreach(var (res,j) in rules){ if(j<=d){ if(pre%P3(j)==res) return new F(0,1); } else if(res%P3(d)==pre) deeper=true; } if(!deeper) return new F(1,1); var s=new F(0,1); for(int c=0;c<3;c++) s=s+Unc(pre+c*P3(d),d+1); return s/new F(3,1); }
 static void Main(string[] args){
  string scr=args[0];
  var R27=new List<ulong>(); var base27=new Dictionary<int,BigInteger>(); for(ulong r=103;r<(1UL<<27);r+=8192){ int a; if(!Excl(r,out a)){ R27.Add(r); base27[a]=base27.GetValueOrDefault(a)+1; } }
  // disjointness from the 181 projection cylinders
  var cyl=File.ReadAllLines(scr+"/ovl/projected181.csv").Skip(1).Select(l=>l.Split(',')).Select(f=>(res:BigInteger.Parse(f[0]),e:int.Parse(f[1]))).ToList();
  long hits=0; foreach(var r in R27) foreach(var c in cyl) if((r-c.res)%P2(Math.Min(27,c.e))==0) hits++;
  Console.WriteLine($"R27 {R27.Count}; cylinders {cyl.Count}; parent-child/cylinder overlaps: {hits}");
  // B_t parent words
  var B=new Dictionary<int,Dictionary<int,BigInteger>>(); B[27]=base27; for(int j=28;j<=100;j++) B[j]=Step(B[j-1],j);
  // masks by budget and a
  var mask=new Dictionary<int,long>[8]; for(int e=0;e<8;e++) mask[e]=new();
  foreach(var f in File.ReadLines(scr+"/six_c/certificates.csv").Skip(1).Select(l=>l.Split(','))){ int e=int.Parse(f[3]),a=int.Parse(f[2]); mask[e][a]=mask[e].GetValueOrDefault(a)+1; }
  foreach(var f in File.ReadLines(scr+"/seven_c/direct7.sorted").Skip(1).Select(l=>l.Split(','))){ int a=int.Parse(f[2]); mask[7][a]=mask[7].GetValueOrDefault(a)+1; }
  Func<int[],Dictionary<int,Dictionary<int,BigInteger>>> prop = es => { var M=new Dictionary<int,Dictionary<int,BigInteger>>(); var s=new Dictionary<int,BigInteger>(); foreach(var e in es) foreach(var kv in mask[e]) s[kv.Key]=s.GetValueOrDefault(kv.Key)+kv.Value; M[41]=s; for(int j=42;j<=100;j++) M[j]=Step(M[j-1],j); return M; };
  var W=prop(new[]{0,1,2,3,4,5,6}); var W6=prop(new[]{6}); var J=prop(new[]{7}); var W7=prop(new[]{0,1,2,3,4,5,6,7});
  // kernels at depth 53
  var H=new Dictionary<int,F>(); int D0=53,K=128;
  for(int a=34;a<=52;a++){ var act=new Dictionary<int,BigInteger>{{0,1}}; BigInteger good=0;
    for(int l=1;l<=K;l++){ var nx=new Dictionary<int,BigInteger>(); foreach(var kv in act) for(int v=kv.Key;v<=kv.Key+1;v++){ if(!Alive(a+v,D0+l)) continue; if(P3(v)>=3*P2(l)) good+=kv.Value<<(K-l); else nx[v]=nx.GetValueOrDefault(v)+kv.Value; } act=nx; }
    BigInteger den=P3(a+2)*P2(K)-P2(D0+K+1), tail=0; foreach(var kv in act) tail+=kv.Value*2*(P3(a+kv.Key)-P2(D0+K));
    var h=new F(good*den+tail,P2(K)*den); var e8=new F(1,8); H[a]= h>e8?h:e8; }
  // certify lower bounds and max ratios
  Func<Dictionary<int,BigInteger>,Dictionary<int,BigInteger>,string,string,bool> cert=(num,dn,lb,name)=>{ var parts=lb.Split('.'); var l=new F(BigInteger.Parse(parts[1]),BigInteger.Pow(10,parts[1].Length));
    var R=new F(0,1); for(int a=53;a>=34;a--){ var c=new F(num.GetValueOrDefault(a),1)-l*new F(dn.GetValueOrDefault(a),1); if(a==53) R=c; else { var alt=R/H[a]; R=c+(R<alt?R:alt); } }
    var mx=new F(0,1); foreach(var a in dn.Keys){ if(dn[a]>0){ var q=new F(num.GetValueOrDefault(a),dn[a]); if(q>mx) mx=q; } }
    Console.WriteLine($"{name}: lower {lb} certified={R.n>0}; max statewise ratio {mx.n}/{mx.d} = {mx.D:F9}"); return R.n>0; };
  var Pm=B[53]; var Pw=Pm.ToDictionary(k=>k.Key,k=>k.Value-W[53].GetValueOrDefault(k.Key));
  Console.WriteLine("num states with W>P: "+Pm.Count(k=>W7[53].GetValueOrDefault(k.Key)>k.Value));
  cert(W[53],Pm,"0.135742811275","delta(0-6)/B");
  cert(W6[53],Pm,"0.026700288313","delta6/B");
  cert(J[53],Pm,"0.015440898090","d7/B");
  cert(J[53],Pw,"0.018239227877","d7/(B-w6)");
  cert(W7[53],Pm,"0.168864595980","w7/B");
  // finite depths 27..52 exact ratios
  Func<Dictionary<int,Dictionary<int,BigInteger>>,int,F> mass=(M,t)=> t>=41? new F(Sum(M[t]),P2(t)) : new F(Sum(M[41]),P2(41));
  foreach(var (M,name) in new[]{(W,"delta(0-6)/B"),(W6,"delta6/B"),(J,"d7/B"),(W7,"w7/B")}){ F mn41=new F(10,1), mn27=new F(10,1); for(int t=27;t<=52;t++){ var q=mass(M,t)/new F(Sum(B[t]),P2(t)); if(q<mn27)mn27=q; if(t>=41&&q<mn41)mn41=q; } Console.WriteLine($"{name}: min over t=41..52 {mn41.D:F12}; over 27..52 {mn27.D:F12}"); }
  Console.WriteLine($"depth-100 absolute: delta {Sum(W[100])} d6 {Sum(W6[100])} d7 {Sum(J[100])}");
  // ternary factor Q for the parent
  foreach(var f in File.ReadAllLines(scr+"/ovl/finite_ledger_transcribed.csv").Skip(1).Select(l=>l.Split(','))){ BigInteger res=BigInteger.Parse(f[1]),mod=BigInteger.Parse(f[2]); int i=0,j=0; var m=mod; while(m%2==0){m/=2;i++;} while(m%3==0){m/=3;j++;} if(j==0) continue; if((res-103)%P2(Math.Min(i,13))!=0) continue; rules.Add((res%P3(j),j)); }
  var Q=Unc(0,0); Console.WriteLine($"active mixed rules {rules.Count}; Q = {Q.n}/{Q.d} ; equals 2519180/4782969: {Q.n==2519180&&Q.d==4782969}");
  double S=0; for(int s=5;s<=80;s++){ int r=2; while(!(P3(r+s)>P2(r+2*s+1))) r++; S+=Math.Pow(3,-(r+s)); } Console.WriteLine($"S = {S:E12}; Q-2S = {2519180.0/4782969-2*S:F16}");
 }}
