using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using System.Text.Json;

// Independent C# replay of the first-phase-gate small-band controls and the saved high-floor suffix fixture.
class RunS { public BigInteger a,b; public F p,q,delta,f; public int s,e,g,E; public List<BigInteger> inputs; }

class P {
 static BigInteger P2(int k)=>BigInteger.One<<k;
 static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static F Q(BigInteger a,BigInteger b)=>new F(a,b);
 static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
 static BigInteger FloorDiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); if(r!=0 && (r.Sign<0)!=(b.Sign<0)) q-=1; return q; }

 static (BigInteger u,int e)? Recover(BigInteger n,F B,int g,BigInteger y){
  var H=(4*n-2)/3; F omega=((F)H+B)/(F)(H+1);
  F lower=(F)P3(g)*((F)n+B)/(F)y, upper=(F)P3(g)*((F)H+B+omega)/(F)y;
  int e=Math.Max(0,(int)lower.n.GetBitLength()-(int)lower.D.GetBitLength());
  while((F)P2(e)<=lower) e++;
  while(e>0 && (F)P2(e-1)>lower) e--;
  if(!((F)P2(e)<upper)) return null;
  F T=Q(P2(e)*y,P3(g))-B; F z=(T-1)/2;
  var cz=-FloorDiv(-z.n,z.D); var u=2*cz-1;
  if(n<=u && u<=H && (F)u>T-omega) return (u,e);
  return null;
 }

 static (BigInteger w,List<RunS> runs)? Profile(BigInteger u,BigInteger n,int bound=2000){
  var H=(4*n-2)/3; var x=u; F q=0,lam=1; int g=0,E=0; var runs=new List<RunS>();
  while(g<bound){
   var a=x; F p=q; var begin=new List<BigInteger>(); int sg=g; bool broke=false; int e=0;
   int limit=bound-g;
   for(int t=0;t<limit;t++){
    begin.Add(x); e=V2(3*x+1); q+=lam/3; lam*=Q(P2(e),3); x=(3*x+1)>>e; E+=e; g++;
    if(e>=2){broke=true;break;}
   }
   if(!broke) return null;
   int s=begin.Count; F beta=(F)1-F.Pow(Q(2,3),s); F delta=beta/(F)a; F f=Q(1,a)-Q(1,x);
   Chk.A(q-p==((F)u+p)*delta,"run identity");
   Chk.A(lam*(F)x==(F)u+q,"phase identity");
   runs.Add(new RunS{a=a,b=x,p=p,q=q,s=s,e=e,delta=delta,f=f,inputs=begin,g=g,E=E});
   if(x<=H) return x>=n ? (x,runs) : null;
  }
  return null;
 }

 static BigInteger Big(JsonElement e)=>BigInteger.Parse(e.ValueKind==JsonValueKind.String?e.GetString():e.GetRawText());
 static F Fr(JsonElement e)=>F.Of(e.ValueKind==JsonValueKind.String?e.GetString():e.GetRawText());

 static void Main(string[] args){
  string root=args[0];
  int bounds=0,credits=0,totalCompleted=0;
  foreach(var ni in new int[]{10697,21395,42791}){
   BigInteger n=ni; var H=(4*n-2)/3; F B=(F)5+Q(n,100000*n); F omega=Q(H,H+1)+B/(F)(H+1);
   Chk.A(omega>0&&omega<2,"omega"); Chk.A((F)H+B+omega<(F)2*((F)n+B),"width");
   var gates=new Dictionary<(int,BigInteger),BigInteger>(); int completed=0,paid=0;
   for(var u=n;u<=H;u+=2){
    var pr=Profile(u,n); if(pr==null) continue; completed++; var runs=pr.Value.runs;
    for(int i=0;i<runs.Count;i++){
     var run=runs[i]; if(run.q<=B) continue;
     Chk.A(run.p<=B,"first crossing"); if(run.b<=H) break;
     F q=run.q; int g=run.g,E=run.E; var y=run.b;
     Chk.A(run.a>H&&q>B&&q<B+omega,"gate range");
     Chk.A(Q(P2(E),P3(g))*(F)y==(F)u+q,"gate affine");
     var rec=Recover(n,B,g,y); Chk.A(rec!=null&&rec.Value.u==u&&rec.Value.e==E,"source recovery");
     Chk.A(!gates.ContainsKey((g,y))||gates[(g,y)]==u,"injective"); gates[(g,y)]=u;
     var inputs=runs.Take(i+1).SelectMany(r=>r.inputs).ToList();
     F spent=0; foreach(var x in inputs.Skip(1)) spent+=Q(1,x);
     Chk.A(inputs.Skip(1).All(x=>x>H),"proper high");
     F ceiling=(F)3*(B+omega-Q(1,3))/((F)n+Q(1,3));
     Chk.A(spent<ceiling,"gate spend"); bounds++;
     for(int j=0;j<=i;j++){
      var sel=runs.GetRange(j,i+1-j); var X=sel[0].a; F phase0=sel[0].p;
      F credit=0; foreach(var r in sel) credit+=F.Max(0,-r.f-r.delta/15);
      F debit=Q(1,y)-Q(1,X)-(q-phase0)/((F)15*((F)u+phase0));
      Chk.A(credit>=F.Max(0,debit),"off-core credit"); credits++;
      if(i+1<runs.Count){
       var r=runs[i+1];
       if(r.s==2&&r.e==2){
        F kappa=Q(n-1,n+1); F charge=F.Max(0,kappa*r.delta+r.f); Chk.A(charge<=Q(2,3*y),"next charge");
        if(q-phase0<=(F)5*((F)u+phase0)/(F)y-(F)15*((F)u+phase0)/(F)X){ Chk.A(credit>=charge,"paid"); paid++; }
       }
      }
     }
     break;
    }
   }
   totalCompleted+=completed;
   Console.WriteLine($"band n={n}: completed {completed}, proper first-run gates {gates.Count}, next-R payment segments {paid}");
  }
  Console.WriteLine($"completed profiles total {totalCompleted} (claimed 1900); gate spend controls {bounds} (claimed 1); off-core credit controls {credits} (claimed 19)");
  Chk.A(totalCompleted==1900&&bounds==1&&credits==19,"small band totals");
  Chk.A((F)5+Q(P2(71),100000)<(F)((4*P2(71)-2)/3+2),"generic");

  // ---- fixture ----
  var cert=JsonDocument.Parse(File.ReadAllText(root+"/fixture/near_miss_certificate.json")).RootElement;
  var inp=JsonDocument.Parse(File.ReadAllText(root+"/fixture/near_miss_input.json")).RootElement;
  BigInteger nn=Big(cert.GetProperty("n")), HH=Big(cert.GetProperty("H")), uu=Big(cert.GetProperty("u"));
  BigInteger Pstar=Big(cert.GetProperty("Pstar")); F BB=Fr(cert.GetProperty("B"));
  var word=inp.GetProperty("word").EnumerateArray().Select(x=>x.GetInt32()).ToArray();
  // replay the whole word independently
  { var x=uu; int sh=0; bool ok=true; var states=new List<BigInteger>{uu};
    foreach(var e in word){ if(V2(3*x+1)!=e) ok=false; x=(3*x+1)>>e; sh+=e; states.Add(x); }
    Chk.A(ok,"whole word valuations");
    bool proper=states.Skip(1).Take(states.Count-2).All(t=>t>HH);
    Console.WriteLine($"fixture: n>=2^71 {nn>=P2(71)}; odd transitions {word.Length} (claimed 174); shortcut steps {sh} (claimed 276); genuine first return {uu>=nn&&uu<=HH&&x>=nn&&x<=HH&&proper}");
    Chk.A(word.Length==174&&sh==276&&sh==cert.GetProperty("shortcut_length").GetInt32()&&HH==(4*nn-2)/3&&proper&&x>=nn&&x<=HH,"fixture return"); }
  var gate=cert.GetProperty("first_complete_run_phase_gate");
  int gg=gate.GetProperty("g").GetInt32(), pE=gate.GetProperty("E").GetInt32(); var yy=Big(gate.GetProperty("y"));
  int k=gate.GetProperty("run_index").GetInt32()+1; F lam=Q(P2(pE),P3(gg)); F qg=Fr(gate.GetProperty("crossing_phase"));
  Chk.A(lam*(F)yy==(F)uu+qg&&qg>BB&&yy>HH,"gate");
  var st=new List<BigInteger>{yy}; var times=new List<int>{0}; var phases=new List<F>{0}; var shortcut=new List<BigInteger>{yy}; var w=new List<int>();
  { F mult=1; var x=yy; int el=0; bool done=false;
    for(int it=0;it<2000;it++){
     var z=3*x+1; int e=V2(z); phases.Add(phases[^1]+mult/3); mult*=Q(P2(e),3); w.Add(e);
     x=z/2; shortcut.Add(x);
     for(int t=0;t<e-1;t++){ Chk.A(x.IsEven,"even"); x/=2; shortcut.Add(x); }
     el+=e; times.Add(el); st.Add(x); if(x<=HH){done=true;break;}
    }
    Chk.A(done&&nn<=x&&x<=HH,"suffix returns");
    Chk.A(w.SequenceEqual(word.Skip(gg)),"suffix word");
    Chk.A(el==cert.GetProperty("shortcut_length").GetInt32()-pE,"suffix length");
    Chk.A(st.Take(st.Count-1).All(t=>t>HH),"suffix proper");
    var sruns=new List<(int i,int j,int e)>(); int begin=0; for(int end=1;end<=w.Count;end++) if(w[end-1]>=2){ sruns.Add((begin,end,w[end-1])); begin=end; }
    var orig=cert.GetProperty("all_runs").EnumerateArray().ToList();
    Chk.A(begin==w.Count&&sruns.Count==orig.Count-k,"run count");
    Chk.A(orig.Take(k).All(r=>!r.GetProperty("core").GetBoolean()),"entry off-core");
    F kappa=Q(nn-1,nn+1); int L=(int)nn.GetBitLength()-1, m=(int)nn.GetBitLength();
    F baseline=0, rect=0, direct=0; var selected=new List<int>(); int coreCount=0;
    for(int j=0;j<sruns.Count;j++){
     var (i,end,e)=sruns[j]; var a=st[i]; var b=st[end]; int s=end-i;
     F beta=(F)1-F.Pow(Q(2,3),s); F delta=beta/(F)a; F flux=Q(1,a)-Q(1,b); F signed=kappa*delta+flux; F credit=F.Max(0,-flux-delta/15);
     int ell=(int)a.GetBitLength()-1, shell=ell-L; BigInteger J=P2(ell)/(2000*Pstar*(shell+1)*(shell+2));
     int ep=times[i]+ell;
     bool physical=HH<a&&a<P2(64*m)&&ep<el&&64*shortcut[ep]>a&&sruns.Count-j>J;
     F rem=phases[^1]-phases[i]; Chk.A(rem>0,"remaining phase");
     bool rectangle=lam>BB/rem&&k>J-j; bool member=physical&&rectangle; var exp=orig[k+j];
     Chk.A(member==exp.GetProperty("core").GetBoolean(),"core mask");
     Chk.A(a==Big(exp.GetProperty("a"))&&b==Big(exp.GetProperty("b")),"states");
     Chk.A(signed==Fr(exp.GetProperty("signed_t"))&&credit==Fr(exp.GetProperty("off_core_credit")),"signed/credit");
     Chk.A(qg+lam*phases[i]==Fr(exp.GetProperty("q"))&&lam*rem==Fr(exp.GetProperty("remaining_phase")),"phases");
     Chk.A(signed+credit>=(kappa-Q(1,15))*delta&&(kappa-Q(1,15))*delta>0,"positivity");
     baseline+=credit; if(member){ rect+=signed+credit; direct+=signed; selected.Add(gg+i); coreCount++; } else direct-=credit;
    }
    var coreStarts=cert.GetProperty("core_odd_starts").EnumerateArray().Select(x2=>x2.GetInt32()).ToList();
    Chk.A(selected.SequenceEqual(coreStarts),"core starts");
    F post=-baseline+rect; Chk.A(post==direct,"post score");
    F entry=0; foreach(var r in orig.Take(k)) entry+=Fr(r.GetProperty("off_core_credit"));
    F full=post-entry; Chk.A(full==Fr(cert.GetProperty("original_signed_profile_score")),"full score");
    Console.WriteLine($"fixture suffix runs {sruns.Count} (claimed 63); core runs {coreCount} (claimed 31); full signed score negative: {full<0}");
    Chk.A(sruns.Count==63&&coreCount==31,"fixture counts");
  }
  // ---- late run at odd depth 87: strict canonical interiority ----
  { var x=uu; var odd=new List<BigInteger>{uu}; var tm=new List<int>{0}; var sc=new List<BigInteger>{uu};
    foreach(var e in word){ var y=(3*x+1)/2; sc.Add(y); for(int t=0;t<e-1;t++){y/=2; sc.Add(y);} x=y; odd.Add(x); tm.Add(tm[^1]+e); }
    var a=odd[87]; int ell=(int)a.GetBitLength()-1, pos=tm[87]+ell;
    Console.WriteLine($"depth 87: run starts there {word[86]>=2}; canonical position {pos} of {tm[^1]}; position < end {pos<tm[^1]}");
    Chk.A(!(pos<tm[^1]),"interiority fails at depth 87"); }
  Console.WriteLine($"checks passed {Chk.pass}, failed {Chk.fail}");
 }
}
