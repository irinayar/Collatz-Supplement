using System;
using System.Collections.Generic;
// Residue structure of M_K = {n <= N : n minimal in its fibre of T^(K-1)} (the not-yet-synchronously-certified starts).
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var tau = new int[N + 1];
    var st = new List<int>(N); var val = new List<long>(N); for (int n = 1; n <= N; n++) { st.Add(n); val.Add(n); }
    for (int k = 1; st.Count > 2; k++) {
      var first = new HashSet<long>(st.Count); var st2 = new List<int>(st.Count); var val2 = new List<long>(st.Count);
      for (int i = 0; i < st.Count; i++) { long v = val[i]; if (!first.Add(v)) { tau[st[i]] = k; continue; } st2.Add(st[i]); val2.Add((v & 1) == 1 ? (3 * v + 1) / 2 : v / 2); }
      st = st2; val = val2;
    }
    foreach (int K in new[] { 2, 4, 10, 30, 60 }) {
      var c6 = new long[6]; long tot = 0;
      for (int n = 3; n <= N; n++) if (tau[n] == 0 || tau[n] > K) { c6[n % 6]++; tot++; }
      var all6 = new long[6]; for (int n = 3; n <= N; n++) all6[n % 6]++;
      Console.Write($"K={K,2}: |M_K|={tot,8} ({(double)tot / N:F4} of n); share by n mod 6 [0..5]: ");
      for (int r = 0; r < 6; r++) Console.Write($"{(double)c6[r] / tot:F3} "); Console.WriteLine($"  (density within each class: {string.Join(' ', Array.ConvertAll(new[] { 0, 1, 2, 3, 4, 5 }, r => ((double)c6[r] / all6[r]).ToString("F3")))})");
    }
  }
}
