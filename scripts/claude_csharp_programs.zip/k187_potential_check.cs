using System; using System.Numerics;
// K187 checks with exact rationals (num/den BigInteger): (a) (2,2) run algebra on a=16k+11, (b) psi bracket, (c) C*d <= 2/(3(H+1)) with a0 least a>H, a=11 mod 16, (d) V(x)-V(y)>=C(y-x)/(u+x) random exact.
struct R { public BigInteger p, q; public R(BigInteger a, BigInteger b){ if(b.Sign<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; p=a/g;q=b/g; }
 public static R operator+(R x,R y)=>new R(x.p*y.q+y.p*x.q,x.q*y.q); public static R operator-(R x,R y)=>new R(x.p*y.q-y.p*x.q,x.q*y.q);
 public static R operator*(R x,R y)=>new R(x.p*y.p,x.q*y.q); public static R operator/(R x,R y)=>new R(x.p*y.q,x.q*y.p);
 public static bool operator<=(R x,R y)=>x.p*y.q<=y.p*x.q; public static bool operator>=(R x,R y)=>x.p*y.q>=y.p*x.q; public static bool operator<(R x,R y)=>x.p*y.q<y.p*x.q; public static bool operator>(R x,R y)=>x.p*y.q>y.p*x.q;
 public static implicit operator R(long v)=>new R(v,1); }
class P { static void Main() {
 int bad=0; long cnt=0;
 for (long k=0;k<200000;k++){ long a=16*k+11; long a1=(3*a+1)/2; long t=3*a1+1; long b=t/4; if((3*a+1)%2!=0||a1%2==0||t%4!=0||b%2==0||b!=18*k+13||8*b!=9*a+5) bad++;
   R G=(R)1+(R)1/(R)(3*a); R G2=G*((R)1+(R)1/(R)(3*a1)); R del=new R(5,9*a); if(!(G2-(R)1 - del).p.IsZero) bad++;
   R f=(R)1/(R)a-(R)1/(R)b; R br=(R)9*(R)(a+5)/((R)5*(R)(9*a+5)); if(!((del*br-f).p.IsZero)) bad++; cnt++; }
 Console.WriteLine($"(a,b) run algebra on {cnt} inputs: bad={bad}");
 int badC=0; long cntC=0; BigInteger minMargin=-1; R minM=new R(1000,1);
 foreach (long n0 in new long[]{3,5,7,9,11,13,15,17,19,21,101,1001,12345,1000003,100000003,(1L<<40)+1,(1L<<59)+3}) { long n=n0|1; BigInteger nn=n; BigInteger H=(4*nn-2)/3; BigInteger a0=H+1; while(a0%16!=11) a0++;
   for (int s=0;s<3;s++){ BigInteger a=a0+16*s; R kap=new R(nn-1,nn+1); R d=new R(5,9*a); R C=kap+(R)0+new R(9*(a+5),5*(9*a+5)); R lhs=C*d; R rhs=new R(2,3*(H+1)); cntC++; if(!(lhs<=rhs)) badC++; else { R m=(rhs-lhs)/rhs; if(m<minM) minM=m; } } }
 Console.WriteLine($"(c) C*d<=2/(3(H+1)) on {cntC} cases: violations={badC}; min relative margin={(double)minM.p/(double)minM.q:E3}");
 // kappa=1 would violate:
 { BigInteger H=(4*(BigInteger)1000003-2)/3; BigInteger a=H+1; while(a%16!=11)a++; R C=(R)1+new R(9*(a+5),5*(9*a+5)); R d=new R(5,9*a); Console.WriteLine($"   with kappa=1 (n=1000003): C*d<=2/(3(H+1)) is {(C*d<=new R(2,3*(H+1)))}"); }
 var rnd=new Random(7); int badD=0, tot=0;
 for(int it=0;it<20000;it++){ long u=rnd.Next(1000,1000000)|1; R B=new R(rnd.Next(1,10),1); R Qbar=new R(rnd.Next(11,40)*u,64); long a=16L*rnd.Next(1000,100000)+11; R d=new R(5,9*a); R kap=new R(u-1,u+1); R C=kap+new R(9*(a+5),5*(9*a+5)); R T=Qbar-B; R Z=T+d*((R)u+T); if(Qbar<Z) Z=Qbar;
   R x=B+new R(rnd.Next(1,1000),1000)*(T-B); R dl=d*new R(rnd.Next(1,1000),1000); R y=(R)1; y=(x*((R)1+dl))+dl*(R)u; if(y>Qbar) continue; if(!(x>B&&x<T)) continue; tot++;
   R Vx=C*(Z-x)/((R)u+x); R Vy= y>=T ? (R)0 : C*(Z-y)/((R)u+y); R psi=C*dl; if(!(Vx-Vy>=psi)) badD++; }
 Console.WriteLine($"(d) V(x)-V(y)>=C*delta on {tot} random exact cases: violations={badD}");
}}
