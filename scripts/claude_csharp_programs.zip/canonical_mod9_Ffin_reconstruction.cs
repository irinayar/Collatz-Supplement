using System;
using System.Collections.Generic;
using System.Numerics;
// Independent reconstruction of the finite endpoint bound F_fin of ChatGPT 213648 (Ordered_Mod9_Canonical_Packing_Theorem), approximated with logarithms (the certificate uses exact rounded rationals):
// codes: length-j parity words (first bit odd), prefix barrier 3^{r_i} 2^{j+1-L} > 2^i, L=71, tracking s=r_j<=256 and v_j mod 9 (v_{i+1}=5 v_i even; 5(3 v_i+1) odd); C_{j,s,a};
// rows (s,a): endpoints y=y0+9t in [max(n,3^s+1), 2*3^s-1], y=a mod 9, K_{s,a}; fill slots j ascending (weight A 3^s/2^j descending) against smallest endpoints.  Expect F_fin ~ 1.148177318916576.
class P {
  static void Main(){
    int L=71,J=512,S=256; BigInteger n=BigInteger.One<<L; double A=3.0*Math.Pow(2,L)/(3.0*Math.Pow(2,L)-J);
    int MAXPRE=J-70; // unconstrained prefix length needed: i0=j-70 up to J-70
    // U[i][r][v]: words of length i starting with odd bit, no constraint
    var U=new BigInteger[MAXPRE+1][,]; U[1]=new BigInteger[S+2,9]; U[1][1,5]=1;
    for(int i=2;i<=MAXPRE;i++){ var cur=new BigInteger[S+2,9]; var prev=U[i-1]; for(int r=1;r<=S;r++) for(int v=0;v<9;v++){ var c=prev[r,v]; if(c.IsZero) continue; int ve=(5*v)%9; cur[r,ve]+=c; if(r+1<=S){ int vo=(5*(3*v+1))%9; cur[r+1,vo]+=c; } } U[i]=cur; }
    // rmin(m): minimal r with 3^r > 2^m (m>=1)
    var rmin=new int[80]; for(int m=1;m<80;m++){ int r=0; while(BigInteger.Pow(3,r)<=(BigInteger.One<<m)) r++; rmin[m]=r; }
    // C[j][s,a] for j=71..J
    int nJ=J-L+1; var Cj=new BigInteger[nJ][,];
    for(int j=L;j<=J;j++){ int i0=j-70; if(i0<1) i0=1; var cur=(BigInteger[,])U[Math.Min(i0,MAXPRE)].Clone();
      // note: for j=71, i0=1: the prefix at i0=1 includes constraint check at i=1 (m=1-71+70=0... m=i-j+70)
      for(int i=i0+1;i<=j;i++){ int m=i-j+70; var nxt=new BigInteger[S+2,9]; for(int r=1;r<=S;r++) for(int v=0;v<9;v++){ var c=cur[r,v]; if(c.IsZero) continue; int ve=(5*v)%9; nxt[r,ve]+=c; if(r+1<=S){ int vo=(5*(3*v+1))%9; nxt[r+1,vo]+=c; } }
        // apply barrier at prefix i
        if(m>=1){ int need=rmin[m]; for(int r=1;r<need&&r<=S;r++) for(int v=0;v<9;v++) nxt[r,v]=0; }
        cur=nxt; }
      Cj[j-L]=cur; }
    double total=0; int rowsNotExhausted=0; int rows=0;
    for(int s=45;s<=S;s++){ BigInteger P3=BigInteger.Pow(3,s); BigInteger lo=BigInteger.Max(n,P3+1); BigInteger hi=2*P3-1;
      foreach(int a in new[]{1,2,4,5,7,8}){ BigInteger y0=lo+(((a-lo)%9)+9)%9; BigInteger K=BigInteger.Max(0,1+(hi-y0)/9); if(K.IsZero) continue; rows++; BigInteger rem=K, b=0; double rowSum=0;
        for(int j=L;j<=J && !rem.IsZero;j++){ BigInteger c=Cj[j-L][s,a]; if(c.IsZero) continue; BigInteger d=BigInteger.Min(c,rem); double w=A*Math.Exp(BigInteger.Log(P3)-j*Math.Log(2));
          double q=Math.Exp(BigInteger.Log(9*d)-BigInteger.Log(y0+9*b)); rowSum+=w*Math.Log(1+q)/9; b+=d; rem-=d; }
        if(!rem.IsZero) rowsNotExhausted++; total+=rowSum; } }
    Console.WriteLine($"rows {rows}; rows with unexhausted endpoint capacity: {rowsNotExhausted}; F_fin (log-approximation) = {total:F9} (claimed 1.148177319)");
  }
}
