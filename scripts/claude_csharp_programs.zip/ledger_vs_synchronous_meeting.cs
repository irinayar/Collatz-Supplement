using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Collections.Generic;
// Union test on n <= N: ledger baseline (crossing within 32 steps, finite ledger of the E18+C110 snapshot, C08, C85, C110 classes)
// versus the synchronous smaller-origin meeting rule at depth K (n non-minimal at depth K, i.e. tau(n) <= K).
class P {
  static void Main(string[] a) {
    string root = a[0]; int N = int.Parse(a[1]);
    var inv = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/targets_E18/counting_inventory_with_C110.json"))).RootElement;
    var rl = new List<(BigInteger r, BigInteger m)>();
    foreach (var z in inv.GetProperty("finite_ledger").EnumerateArray()) rl.Add((BigInteger.Parse(z.GetProperty("residue").ToString()), BigInteger.Parse(z.GetProperty("modulus").ToString())));
    for (int s = 0; s <= 80; s++) { int r = 2; while (!(BigInteger.Pow(3, r + s) > BigInteger.Pow(2, r + 2 * s + 1))) r++;
      BigInteger q = BigInteger.Pow(3, r + s); BigInteger inv2 = BigInteger.ModPow(BigInteger.Pow(2, 2 * s + 1), 2 * BigInteger.Pow(3, r + s - 1) - 1, q);
      rl.Add((((1 - BigInteger.Pow(3, s + 1) * inv2) % q + q) % q, q)); }
    var c85 = new bool[1 << 27];
    foreach (var c in JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/v2_audit/parent27_certificates.json"))).RootElement.GetProperty("certificates").EnumerateArray())
      if (c.GetProperty("meeting").ValueKind != JsonValueKind.Null && c.GetProperty("descent").ValueKind == JsonValueKind.Null) c85[c.GetProperty("n").GetInt64()] = true;
    var c08 = new List<(long r, long mask)>();
    for (int k = 1; k <= 30; k++) { BigInteger m = BigInteger.One << (k + 2), p3 = BigInteger.Pow(3, k), p2 = BigInteger.Pow(2, k);
      BigInteger r = (((-(p3 - p2) * BigInteger.ModPow(p3, (m >> 1) - 1, m)) % m) + m) % m; c08.Add(((long)r, (long)(m - 1))); }
    ulong[] p3t = new ulong[40]; p3t[0] = 1; for (int i = 1; i < 40; i++) p3t[i] = p3t[i - 1] * 3;
    var rr = rl.ToArray();
    bool Covered(long n) {
      ulong x = (ulong)n; int ones = 0;
      for (int i = 1; i <= 32; i++) { if ((x & 1) == 1) { ones++; x = (3 * x + 1) >> 1; } else x >>= 1; if (p3t[ones] < (1UL << i)) return true; }
      foreach (var u in rr) if (n % u.m == u.r) return true;
      foreach (var u in c08) if ((n & u.mask) == u.r) return true;
      return c85[n & ((1L << 27) - 1)];
    }
    // tau[n]: iteration at which n becomes non-minimal (0 = never)
    var tau = new int[N + 1];
    var st = new List<int>(N); var val = new List<long>(N); for (int n = 1; n <= N; n++) { st.Add(n); val.Add(n); }
    for (int k = 1; st.Count > 2; k++) {
      var first = new HashSet<long>(st.Count); var st2 = new List<int>(st.Count); var val2 = new List<long>(st.Count);
      for (int i = 0; i < st.Count; i++) { long v = val[i]; if (!first.Add(v)) { tau[st[i]] = k; continue; } st2.Add(st[i]); val2.Add((v & 1) == 1 ? (3 * v + 1) / 2 : v / 2); }
      st = st2; val = val2;
    }
    int[] Ks = { 5, 10, 20, 32, 50, 100, 200 };
    long unc = 0; var rem = new long[Ks.Length];
    for (int n = 3; n <= N; n++) if (!Covered(n)) { unc++; for (int i = 0; i < Ks.Length; i++) if (tau[n] == 0 || tau[n] > Ks[i]) rem[i]++; }
    Console.WriteLine($"n in [3,{N}]: uncovered by ledger baseline (depth 32): {unc} ({(double)unc / N:E3} of n)");
    for (int i = 0; i < Ks.Length; i++) Console.WriteLine($"  also not synchronously certified by depth K={Ks[i],3}: {rem[i],7}  ({(double)rem[i] / N:E3} of all n)");
    long all = 0; for (int n = 3; n <= N; n++) if (tau[n] == 0 || tau[n] > 100) all++;
    Console.WriteLine($"for comparison, among all n the share not synchronously certified at depth 100: {(double)all / N:E3}");
  }
}
