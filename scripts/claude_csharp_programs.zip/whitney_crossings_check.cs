using System;
using System.Collections.Generic;
using System.Linq;
// Whitney formula for the chord polygon: rho = mu + sum_{crossings} eps, base point near vertex s on the outgoing chord.
// Chords cross iff their endpoints interleave on the circle (all vertices lie on the circle).  Also collects crossing counts.
static class P {
  static double Wrap(double a) { while (a > Math.PI) a -= 2 * Math.PI; while (a <= -Math.PI) a += 2 * Math.PI; return a; }
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); long words = 0, ok1 = 0, ok2 = 0, bad = 0, triple = 0; var xc = new SortedDictionary<int, long>(); var byKX = new SortedDictionary<(int, int), long>();
    long wholeBad = 0, lbViol = 0, lbEq = 0, parBad = 0; var exHist = new SortedDictionary<int, long>(); var kx = new SortedDictionary<(int,int), (long n, int minX, int maxX)>(); var xByRho = new SortedDictionary<int, (long n, int minX, int maxX)>();
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true; for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; } if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue; if (X.Min() < scale) continue;   // values >= 1 only (turning hypotheses)
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2;
        var px = new double[L]; var py = new double[L]; var phi = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); phi[i] = Math.Atan2(py[i], px[i] - m); }
        // circular position: clockwise rank = decreasing phi ; use angle in [0,2pi) measured clockwise from c
        var pos = new double[L]; for (int i = 0; i < L; i++) { double a = Math.PI - phi[i]; if (a < 0) a += 2 * Math.PI; if (a >= 2 * Math.PI) a -= 2 * Math.PI; pos[i] = a; }
        var dx = new double[L]; var dy = new double[L]; for (int i = 0; i < L; i++) { int j = (i + 1) % L; dx[i] = px[j] - px[i]; dy[i] = py[j] - py[i]; }
        var th = new double[L]; for (int i = 0; i < L; i++) th[i] = Math.Atan2(dy[i], dx[i]); var tau = new double[L]; for (int j = 0; j < L; j++) tau[j] = Wrap(th[j] - th[(j + L - 1) % L]);
        double rho = tau.Sum() / (2 * Math.PI); int rr = (int)Math.Round(rho);
        // crossings: chords i (i->i+1) and j (j->j+1), non adjacent (cyclically), interleaved
        var cr = new List<(int i, int j)>(); bool[,] cx = new bool[L, L];
        for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) { if (j == i + 1 || (i == 0 && j == L - 1)) continue; int a1 = i, a2 = (i + 1) % L, b1 = j, b2 = (j + 1) % L; double pa = pos[a1], pb = pos[a2], qa = pos[b1], qb = pos[b2]; double lo = Math.Min(pa, pb), hi = Math.Max(pa, pb);
          bool inA = qa > lo && qa < hi, inB = qb > lo && qb < hi; if (inA != inB) { cr.Add((i, j)); cx[i, j] = true; } }
        int X0 = cr.Count; words++; xc[X0] = xc.GetValueOrDefault(X0) + 1; var t0 = xByRho.GetValueOrDefault(rr); xByRho[rr] = (t0.n + 1, t0.n == 0 ? X0 : Math.Min(t0.minX, X0), t0.n == 0 ? X0 : Math.Max(t0.maxX, X0));
        { int kk = 0, nr1 = 0; for (int i0 = 0; i0 < L; i0++) if (e[i0] && !e[(i0 + L - 1) % L]) { int rl = 0, j0 = i0; while (e[j0 % L]) { rl++; j0++; } kk++; if (rl == 1) nr1++; } int hh = kk - nr1; int lbX = 2 * kk + 3 * hh - 5; if (X0 < lbX) lbViol++; if (X0 == lbX) lbEq++; if ((X0 - lbX) % 2 != 0) parBad++; var exH = exHist; exH[X0 - lbX] = exH.GetValueOrDefault(X0 - lbX) + 1; var key = (kk, nr1); var tk = kx.GetValueOrDefault(key); kx[key] = (tk.n + 1, tk.n == 0 ? X0 : Math.Min(tk.minX, X0), tk.n == 0 ? X0 : Math.Max(tk.maxX, X0)); }
        bool all1 = true, all2 = true;
        for (int s = 0; s < L; s++) {
          int mu = tau[s] > 0 ? 1 : -1; double S = 0;
          foreach (var (i, j) in cr) { int fi = (i - s + L) % L, fj = (j - s + L) % L; int first = fi < fj ? i : j, second = fi < fj ? j : i; double cz = dx[first] * dy[second] - dy[first] * dx[second]; S += cz > 0 ? 1 : -1; }
          if (rr != mu + (int)S) all1 = false; if (rr != mu - (int)S) all2 = false;
        }
        if (all1) ok1++; if (all2) ok2++; if (!all1 && !all2) bad++;
      }
    }
    Console.WriteLine($"words (values>=1) {words}: Whitney rho = mu + S holds for all base vertices in {ok1} words; rho = mu - S in {ok2}; neither {bad}");
    Console.WriteLine("crossing number histogram: " + string.Join(" ", xc.Take(25).Select(t => t.Key + ":" + t.Value)));
    Console.WriteLine("by (k, number of runs of length 1): (words, min X, max X): " + string.Join(" ", kx.Select(t => $"k{t.Key.Item1}n1={t.Key.Item2}:({t.Value.n},{t.Value.minX},{t.Value.maxX})")));
    Console.WriteLine($"crossing lower bound X >= 2k + 3h - 5 (h = number of runs of length >= 2): violations {lbViol}, equality in {lbEq} of {words} words, parity violations {parBad}; excess histogram: " + string.Join(" ", exHist.Take(14).Select(t => t.Key + ":" + t.Value)));
    Console.WriteLine("by rho: (n words, min crossings, max crossings): " + string.Join(" ", xByRho.Select(t => $"rho{t.Key}:({t.Value.n},{t.Value.minX},{t.Value.maxX})")));
  }
}
