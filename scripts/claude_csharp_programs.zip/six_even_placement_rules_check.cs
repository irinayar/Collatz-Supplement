using System; using System.Collections.Generic; using System.IO; using System.Linq;
class P { static void Main(string[] a){
  var cnt=new Dictionary<string,long>(); long rows=0,viol=0;
  using var sr=new StreamReader(Path.Combine(a[0],"certificates.csv")); sr.ReadLine(); string ln;
  while((ln=sr.ReadLine())!=null){ var f=ln.Split(','); int e=int.Parse(f[3]),b=int.Parse(f[4]); ulong wb=ulong.Parse(f[5]); UInt128 z=ulong.Parse(f[1]); rows++;
    if(e<1) continue; int len=b+e;
    // parse into runs: sequence of (odd run p, even block d), final odd run
    var offs=new List<int>(); var blocks=new List<int>(); int k=0; bool bad=false;
    while(k<len){ // odd run starting at z
      UInt128 zin=z; int p=0; while(k<len && ((wb>>k)&1)==1){ z=(2*z-1)/3; p++; k++; }
      if(k>=len){ break; }
      int d=0; while(k<len && ((wb>>k)&1)==0){ z=2*z; d++; k++; }
      int v=0; UInt128 t=zin+1; while(t%3==0){t/=3;v++;}
      offs.Add(v-p); blocks.Add(d);
      if(k>=len){ bad=true; break; } // word may not end with E
    }
    if(bad||blocks.Count==0||blocks[^1]!=1) viol++;
    for(int i=0;i<blocks.Count;i++){ int d=blocks[i],o=offs[i]; bool ok = (d==1||d==3||d==5)? o==0 : d==2? o==1 : d==4? (o==1||o==2) : false; if(!ok) viol++; }
    if(e==6){ string key=string.Join(",",blocks)+" | "+string.Join(",",offs); cnt[key]=cnt.GetValueOrDefault(key)+1; }
  }
  Console.WriteLine($"rows {rows}; structural violations (final block !=1, or placement rule broken) {viol}");
  foreach(var kv in cnt.OrderBy(x=>x.Key)) Console.WriteLine(kv.Key+" = "+kv.Value);
}}
