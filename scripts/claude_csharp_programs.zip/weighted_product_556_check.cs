using System;
using System.Numerics;
// (1) ChatGPT 095740: W = max over the 499 odd starts u in [3,999] and all prefixes of G_s / q^s, q = 3004/3003; thresholds r=556/557.
// (2) lemma: a multiple of 3 can only be the FIRST odd input of a trajectory (so odd input 3 cannot occur late); test for all starts m <= 2*10^6 along their full trajectories.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static void Main(){
    Fr W=new Fr(1,1); int argS=0; long arg=0; BigInteger q1=3004, q0=3003;
    for(long u=3;u<=999;u+=2){ BigInteger n=u; Fr G=new Fr(1,1); int s=0; Fr qs=new Fr(1,1); bool first=true; while(n!=2){ if(!n.IsEven){ G=G*new Fr(3*n+1,3*n); qs=qs*new Fr(q1,q0); n=(3*n+1)/2; s++; } else n/=2; // ratio G/q^s after each step
        Fr ratio=new Fr(G.n*qs.d,G.d*qs.n); if(Fr.Gt(ratio,W)){ W=ratio; arg=u; argS=s; } if(n==1){ break; } } }
    Console.WriteLine($"(1) W = {W} (ChatGPT 2012030040030012002/1614663884607228009), attained at start {arg} with s={argS} odd steps");
    BigInteger a=BigInteger.Pow(3004,556), b=BigInteger.Pow(3003,556), a2=BigInteger.Pow(3004,557), b2=BigInteger.Pow(3003,557);
    Console.WriteLine($"   2*Wn*3004^556 < 3*Wd*3003^556: {2*W.n*a<3*W.d*b}; 2*Wn*3004^557 > 3*Wd*3003^557: {2*W.n*a2>3*W.d*b2}");
    long viol=0,cases=0; for(long m=1;m<=2000000;m++){ long n=m; bool seenOdd=false; while(n>2){ if((n&1)==1){ if(n%3==0&&seenOdd) viol++; seenOdd=true; n=(3*n+1)>>1; } else n>>=1; } cases++; }
    Console.WriteLine($"(2) multiples of 3 appearing as a LATER odd input: {viol} (over {cases} full trajectories)");
  }
}
