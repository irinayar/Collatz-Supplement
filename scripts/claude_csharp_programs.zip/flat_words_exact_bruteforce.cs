using System;
using System.Collections.Generic;
using System.Linq;
// Exact brute force (no pruning): all primitive cyclic words with no isolated odd step, 3^A<2^L, distinct vertices, all values >= 1,
// every excursion strictly (P_R, V_L): X_a + X_p > S and 3 X_b < 2 S (exact Int128 arithmetic, scaled by D*2^L).
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); var kByL = new SortedDictionary<int, int>(); var kHist = new SortedDictionary<int, long>(); long gcdPos = 0, intCnt = 0, t21 = 0; var minDep = new SortedDictionary<int, double>(); var clus = new SortedDictionary<(int, int), (int, int, int)>(); int[] pr = { 5, 7, 11, 13, 17, 19, 23 }; long[] opp = new long[7], hit = new long[7]; var cnt = new SortedDictionary<int, long>(); long total = 0;
    for (int L = 4; L <= Lmax; L++) {
      ulong mask = (1UL << L) - 1; Int128 p2 = (Int128)1 << L; long found = 0;
      for (ulong w = 1; w < mask; w++) {
        ulong rl = ((w << 1) | (w >> (L - 1))) & mask, rr = ((w >> 1) | (w << (L - 1))) & mask;
        if ((w & ~rl & ~rr) != 0) continue;                       // an isolated 1 exists
        int A = System.Numerics.BitOperations.PopCount(w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { ulong rot = ((w << r) | (w >> (L - r))) & mask; if (rot <= w) canon = false; }
        if (!canon) continue;
        // start at the beginning of a run of ones preceded by 0: rotate so that bit0=1 and previous (bit L-1)=0
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        int s0 = -1; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) { s0 = i; break; }
        var f = new bool[L]; for (int i = 0; i < L; i++) f[i] = e[(s0 + i) % L]; e = f;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        Int128 c = X.Min(), H = X.Max(), S = c + H; bool ok = c >= scale; if (!ok) continue;
        for (int i = 0; i < L && ok; i++) if (e[i] && !e[(i + L - 1) % L]) {
          int r = 0, j = i; while (e[j % L]) { r++; j++; } int a = (j - 1) % L, p = j % L; while (!e[j % L]) j++; int b = (j - 1) % L;
          if (!(X[a] + X[p] > S && 3 * X[b] < 2 * S)) ok = false; }
        if (ok) { found++; { double dep = Math.Log2((double)H / (double)c); int kq = 0; for (int i = 0; i < L; i++) if (!e[i] && e[(i + 1) % L]) kq++; if (!minDep.ContainsKey(kq) || dep < minDep[kq]) minDep[kq] = dep; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) { int r2 = 0, j2 = i; while (e[j2 % L]) { r2++; j2++; } int d2 = 0; while (!e[j2 % L]) { d2++; j2++; } if (r2 == 2 && d2 == 1) t21++; } } int kk = 0; for (int i = 0; i < L; i++) if (!e[i] && e[(i + 1) % L]) kk++; kByL[L] = Math.Max(kByL.GetValueOrDefault(L), kk); kHist[kk] = kHist.GetValueOrDefault(kk) + 1; Int128 g0 = U, g1 = D; while (g1 != 0) { var t = g0 % g1; g0 = g1; t = t; g1 = t; } if (g0 > 1) gcdPos++; if (U % D == 0) intCnt++; { var key = (L, A); var cur = clus.GetValueOrDefault(key); clus[key] = (cur.Item1 + 1, cur.Item2 + ((U % 5 == 0) ? 1 : 0), cur.Item3 + ((U % 13 == 0) ? 1 : 0)); } for (int ip = 0; ip < pr.Length; ip++) if (D % pr[ip] == 0) { opp[ip]++; if (U % pr[ip] == 0) hit[ip]++; } }
      }
      cnt[L] = found; total += found; Console.WriteLine($"L={L}: flat words (values>=1) {found}");
    }
    Console.WriteLine("total " + total); Console.WriteLine("min log2(H/c) by k: " + string.Join(" ", minDep.Select(t => $"k{t.Key}:{t.Value:F3}")) + $"; excursion type (2,1) occurrences: {t21}"); foreach (var kv in clus) { Int128 DD = ((Int128)1 << kv.Key.Item1); Int128 p3x = 1; for (int i = 0; i < kv.Key.Item2; i++) p3x *= 3; DD -= p3x; if (DD % 5 == 0 || DD % 13 == 0) Console.WriteLine($"  cluster (L={kv.Key.Item1},A={kv.Key.Item2}): words {kv.Value.Item1}; 5|D:{DD % 5 == 0} words with 5|U {kv.Value.Item2}; 13|D:{DD % 13 == 0} words with 13|U {kv.Value.Item3}"); } Console.WriteLine("max k by L: " + string.Join(" ", kByL.Select(t => $"L{t.Key}:{t.Value}"))); Console.WriteLine("count by k: " + string.Join(" ", kHist.Select(t => $"k{t.Key}:{t.Value}"))); Console.WriteLine($"gcd(U,D)>1 in {gcdPos} of {total}; integer fixed points {intCnt}"); for (int ip = 0; ip < pr.Length; ip++) Console.WriteLine($"  prime {pr[ip]}: D divisible in {opp[ip]}, divides U in {hit[ip]} (expected {1.0 / pr[ip]:F3}, observed {(opp[ip] > 0 ? (double)hit[ip] / opp[ip] : 0):F3})");
  }
}
