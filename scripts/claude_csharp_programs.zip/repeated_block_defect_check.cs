using System;
using System.Numerics;
// Check of the repeated-block defect identity (ChatGPT 122814, Codex 124215): for a word w (length L, a odd steps, numerator U) followed by x for k complete blocks,
// B^k (x - S^{kL}(x)) = D * S_k with D = (B - A) x - U, S_k = sum_{i<k} B^{k-1-i} A^i (odd), hence B^k | D and, if D != 0, k L <= v2(D).
class P {
  static BigInteger T(BigInteger x) => x.IsEven ? x / 2 : (3 * x + 1) / 2;
  static void Main() {
    long cases = 0, bad = 0, withK = 0, dz = 0, kmaxSeen = 0;
    for (int L = 1; L <= 9; L++) for (int w = 0; w < (1 << L); w++) {
      int a = 0; BigInteger U = 0; var pos = new System.Collections.Generic.List<int>(); for (int i = 0; i < L; i++) if (((w >> i) & 1) == 1) { pos.Add(i); a++; }
      for (int h = 1; h <= a; h++) U += BigInteger.Pow(2, pos[h - 1]) * BigInteger.Pow(3, a - h);
      BigInteger A = BigInteger.Pow(3, a), B = BigInteger.Pow(2, L);
      for (long x0 = 1; x0 <= 700; x0++) {
        BigInteger x = x0, y = x0; int k = 0;
        while (k < 40) { // does y follow w for one more complete block?
          BigInteger z = y; bool ok = true; for (int i = 0; i < L; i++) { int bit = z.IsEven ? 0 : 1; if (bit != ((w >> i) & 1)) { ok = false; break; } z = T(z); }
          if (!ok) break; y = z; k++; }
        if (k == 0) continue; withK++; if (k > kmaxSeen) kmaxSeen = k;
        BigInteger D = (B - A) * x - U; 
        for (int kk = 1; kk <= k; kk++) {
          BigInteger yy = x; for (int s = 0; s < kk * L; s++) yy = T(yy);
          BigInteger Sk = 0; for (int i = 0; i < kk; i++) Sk += BigInteger.Pow(B, kk - 1 - i) * BigInteger.Pow(A, i);
          cases++; if (BigInteger.Pow(B, kk) * (x - yy) != D * Sk) bad++; if ((Sk % 2).IsZero) bad++; if (!(D % BigInteger.Pow(B, kk)).IsZero) bad++;
          if (!D.IsZero) { int v2 = 0; BigInteger d = BigInteger.Abs(D); while (d.IsEven) { d /= 2; v2++; } if ((long)kk * L > v2) bad++; } }
        if (D.IsZero) dz++;
      } }
    Console.WriteLine($"repeated-block defect identity: L<=9, all words, x<=700: {withK} (word, x) pairs with k>=1 complete block; {cases} identity/divisibility/v2-bound checks; D = 0 (cycle closure) in {dz}; largest k seen {kmaxSeen}; failures {bad}");
  }
}
