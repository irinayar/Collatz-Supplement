using System;
using System.Collections.Generic;
// Check Codex K137 / ChatGPT 142500 five-transition first returns.
// (a) all odd u in I=[n,H], H=floor((4n-2)/3), odd n<=4001: five-transition first returns (4 intermediates > H, w in I): valuations in the 7 listed classes with u mod 512 as listed, 256 w = 243 u + B; excluded tuples (1,1,3,1,2),(1,2,2,1,2),(1,3,1,1,2) never occur.
// (b) actual chains with gaps in {2,3,4,5}: G < 32/27 and telescoping identity; (c) analytic constants of the theorem.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static double Phi(long u)=> 1.0+5.0/u;
  static void Main(){
    var table=new Dictionary<string,(long B,long res)>{{"1,1,1,1,4",(211,95)},{"1,1,1,2,3",(227,175)},{"1,1,1,3,2",(259,335)},{"1,1,2,1,3",(251,295)},{"1,1,2,2,2",(283,455)},{"1,2,1,1,3",(287,219)},{"1,2,1,2,2",(319,379)}};
    var cnt=new Dictionary<string,long>(); long total=0,bad=0,excluded=0;
    for(long n=3;n<=4001;n+=2){ long H=(4*n-2)/3;
      for(long u=n;u<=H;u+=2){ long x=u; var ev=new int[5]; var st=new long[6]; st[0]=u; bool ok=true; for(int i=0;i<5;i++){ int e; x=A(x,out e); ev[i]=e; st[i+1]=x; }
        long w=st[5]; if(!(w>=n&&w<=H)) continue; for(int i=1;i<=4;i++) if(st[i]<=H) ok=false; if(!ok) continue; 
        total++; string key=string.Join(",",ev);
        if(key=="1,1,3,1,2"||key=="1,2,2,1,2"||key=="1,3,1,1,2") excluded++;
        if(!table.TryGetValue(key,out var t)){ bad++; continue; } if(u%512!=t.res || 256*w!=243*u+t.B) bad++;
        if(!cnt.ContainsKey(key)) cnt[key]=0; cnt[key]++; }
    }
    Console.WriteLine($"(a) five-transition first returns {total}; classes: "+string.Join(" ",cnt)+$"; excluded tuples seen {excluded}; violations {bad}");
    long chains=0,badG=0,badId=0,g5=0; double maxG=0;
    for(long n=3;n<=100001;n+=2){ long H=(4*n-2)/3; long x=n; var inputs=new List<long>(); var low=new List<int>(); int r=0;
      for(int step=0;step<4000;step++){ if((x&1)==1){ if(x<=H) low.Add(r); inputs.Add(x); r++; int e; x=A(x,out e); if(x<n) break; } else { x/=2; if(x<n) break; } }
      for(int k=1;k<low.Count;k++){ bool ok=true; for(int i=0;i<k;i++){ int gp=low[i+1]-low[i]; if(gp<2||gp>5) ok=false; } if(!ok) break;
        int idx=low[k]; double G=1; for(int i=0;i<idx;i++) G*=1.0+1.0/(3.0*inputs[i]); chains++; if(G>maxG) maxG=G; if(!(G<32.0/27)) badG++;
        double prod=Phi(n)/Phi(inputs[idx]); for(int i=0;i<k;i++){ long u=inputs[low[i]], w=inputs[low[i+1]]; double g=1; for(int j=low[i];j<low[i+1];j++) g*=1.0+1.0/(3.0*inputs[j]); prod*=g*Phi(w)/Phi(u); }
        if(Math.Abs(prod-G)/G>1e-9) badId++; for(int i=0;i<k;i++) if(low[i+1]-low[i]==5) g5++; } }
    Console.WriteLine($"(b) chains gaps 2..5: {chains} (five-gap steps {g5}), max G {maxG:F6}, violations {badG}, identity mismatches {badId}");
    // (c) analytic constants
    double R=528.0/523, S=25.0/972+1184.0/(81*132); Console.WriteLine($"(c) n>=127: R={R:F6}, S={S:F6}, bound {R/(1-S):F6} (Codex 5645376/4828859={5645376.0/4828859:F6}), 32/27={32.0/27:F6}; n=35..125: {(160.0/155)/(1-416.0/(81*40)):F6} (12960/10943={12960.0/10943:F6})");
    // max over n in [35,125] (odd) of R_n/(1-S_n) with S_n=416/(81(n+5)), R_n=4(n+5)/(4n+15)
    double worst=0; for(long n=35;n<=125;n+=2){ double Rn=4.0*(n+5)/(4*n+15), Sn=416.0/(81*(n+5)); worst=Math.Max(worst,Rn/(1-Sn)); } Console.WriteLine($"    worst over odd n in [35,125] of R_n/(1-S_n): {worst:F6}");
  }
}
