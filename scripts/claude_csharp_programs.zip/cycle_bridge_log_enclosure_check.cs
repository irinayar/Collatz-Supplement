using System; using System.Numerics;
static class Q {
 static readonly BigInteger S=BigInteger.Pow(10,80);
 static BigInteger Ln(int a){ BigInteger z=S*(a-1)/(a+1); BigInteger z2=z*z/S, t=z, sum=0; for(int k=0;k<400;k++){ sum+=t/(2*k+1); t=t*z2/S; } return 2*sum; }
 public static void Run(){
  BigInteger ln2=Ln(2), ln3=Ln(3);
  foreach(var (L,g,claimG,claimX,div) in new[]{(BigInteger.Parse("217976794617"),BigInteger.Parse("137528045312"),"8e-13..9e-13","25506277914380652835190",6),(BigInteger.Parse("9009497464537"),BigInteger.Parse("5684360015103"),"1.8e-12..1.9e-12","254232972991967702313505",12)}){
   BigInteger gam=L*ln2-g*ln3; // scaled by S
   // Lambda-1 = e^gam-1
   BigInteger term=gam, em1=0; for(int k=1;k<60;k++){ em1+=term; term=term*gam/S/(k+1); }
   BigInteger bound=g*S/(div*em1); // g/(div*(Lambda-1)) as integer
   Console.WriteLine("(L,g)=("+L+","+g+"): gamma = "+((double)gam/(double)S).ToString("E10")+" (claimed "+claimG+"); Lambda-1 = "+((double)em1/(double)S).ToString("E10")+"; g/("+div+"(Lambda-1)) = "+bound+" > claimed "+claimX+": "+(bound>BigInteger.Parse(claimX))+"; claimed > 2e23 (second only): "+(BigInteger.Parse(claimX)>BigInteger.Parse("200000000000000000000000"))); }
 }}
