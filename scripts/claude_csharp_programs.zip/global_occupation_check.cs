using System; using System.Collections.Generic; using System.Linq; using System.Numerics;
// Global_Proof_Attempt (ChatGPT 18:02): (a) constants gamma=h2(log_3 2), A<8/25, closure arithmetic, (b) test inequality (2) W_S(2^L) <= L + sum_r min(C(L,r), W_S(2*3^r)) on actual distinct-state Collatz segments.
class P { static int W(long[] sorted, long H){ int best=0; int j=0; for(int i=0;i<sorted.Length;i++){ while(sorted[i]-sorted[j]>=H) j++; best=Math.Max(best,i-j+1);} return best; }
 static void Main(){ double al=Math.Log(2)/Math.Log(3), g=-(al*Math.Log(al,2)+(1-al)*Math.Log(1-al,2)); Console.WriteLine($"alpha={al:F12} gamma={g:F15} (>0.9: {g>0.9})");
  double A=Math.Pow(4.0/27,g)/(1-Math.Pow(3,-g)); double z=al/(1-al); Console.WriteLine($"A={A:F6} (<8/25=0.32: {A<0.32}); z={z:F6} in (1,2): {z>1&&z<2}; z^3={z*z*z:F4} <8; 12*8/25+8=296/25={12*8.0/25+8:F2}<12; 14*8/25+9={14*8.0/25+9:F2}<14");
  Console.WriteLine($"z^3 z^(-alpha L)(1+z)^L = z^3 2^(gamma L): check (1+z)=1/(1-al)={1/(1-al):F6}, z^(-al)(1+z) = {Math.Pow(z,-al)/(1-al):F6}, 2^gamma={Math.Pow(2,g):F6}");
  long[] starts={27,97,871,6171,77031,837799,1117065,8400511,63728127,670617279}; int bad=0, tests=0;
  foreach(long s0 in starts){ var seen=new HashSet<long>(); long x=s0; var lst=new List<long>(); while(seen.Add(x)){ lst.Add(x); if(x==1) break; x = (x%2==1)?(3*x+1)/2:x/2; }
   var states=lst.Where(v=>v>2).ToArray(); Array.Sort(states); // distinct states of the segment (exclude the cycle states 1,2)
   var cache=new Dictionary<int,int>(); for(int r=0;r<=14;r++) cache[r]=W(states,2L*(long)Math.Pow(3,r));
   for(int L=1; L<=14; L++){ int lhs=W(states,1L<<L); double rhs=L; for(int r=0;r<=L;r++){ double binom=1; for(int i=1;i<=r;i++) binom=binom*(L-r+i)/i; rhs+=Math.Min(binom, cache[r]); } tests++; if(lhs>rhs+1e-9){bad++; Console.WriteLine($"violation start {s0} L={L}: {lhs} > {rhs}");} }
   Console.WriteLine($"start {s0}: segment of {states.Length} distinct states, max count in 2^L windows L=4,8,12: {W(states,16)},{W(states,256)},{W(states,4096)}"); }
  Console.WriteLine($"inequality (2) tested on {tests} (segment,L) pairs: violations={bad}");
 }}
