using System;
using System.Numerics;
using System.Collections.Generic;
// Check of repeat rigidity for 2-adic RATIONALS x = k0/q (q odd, k0 any integer):
// states k_j/q with k_{j+1} = k_j/2 (k even) or (3 k_j + q)/2 (k odd), parity = k_j mod 2.
// Claim: if the next L parities agree at times i != i' then 2^L | k_i - k_i'; so distinct states satisfy 2^lcp <= |k_i - k_i'|.
class P {
  static void Main(string[] a) {
    int trials = int.Parse(a[0]), len = int.Parse(a[1]); var rnd = new Random(12345);
    long pairs = 0, viol = 0, distinctPairs = 0, sizeViol = 0;
    for (int t = 0; t < trials; t++) {
      BigInteger q = 2 * rnd.Next(0, 500) + 1; BigInteger k0 = rnd.Next(-2000000, 2000000);
      var k = new BigInteger[len + 80]; var w = new int[len + 80]; k[0] = k0;
      for (int j = 0; j < len + 79; j++) {
        if (!k[j].IsEven) { w[j] = 1; k[j + 1] = (3 * k[j] + q) / 2; } else { w[j] = 0; k[j + 1] = k[j] / 2; }
      }
      for (int i = 0; i < len; i++) for (int i2 = i + 1; i2 < len; i2++) {
        int l = 0; while (l < 79 && w[i + l] == w[i2 + l]) l++;
        pairs++;
        BigInteger d = BigInteger.Abs(k[i] - k[i2]);
        if (!(d % (BigInteger.One << l)).IsZero) viol++;
        if (d != 0) { distinctPairs++; if (d < (BigInteger.One << l)) sizeViol++; }
      }
    }
    Console.WriteLine($"rational starts {trials}, pairs {pairs}, congruence violations {viol}, distinct-state pairs {distinctPairs}, size violations (|diff| < 2^lcp) {sizeViol}");
  }
}
