using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 204209: run-start trajectories from B={odd 1025..4095} until the first start <=1023.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static Fr Step(BigInteger u,out BigInteger v){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); v=w>>e; return new Fr(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    int none=0,some=0,maxRet=0,maxTrans=0; BigInteger maxVal=0; long argVal=0,argTrans=0; Fr best=new Fr(1,1); long argBest=0; var retStarts=new List<long>(); long repeats=0;
    for(long u0=1025;u0<=4095;u0+=2){ BigInteger cur=u0; int trans=0,ret=0; Fr prod=new Fr(1,1); var seen=new HashSet<BigInteger>(); BigInteger pk=cur;
      while(cur>1023){ if(!seen.Add(cur)){ repeats++; break; } var c=Step(cur,out BigInteger v); prod=prod*c; trans++; if(cur>4095&&v>=1025&&v<=4095) ret++; cur=v; if(cur>pk) pk=cur; }
      if(ret==0) none++; else some++; if(ret>maxRet){ maxRet=ret; retStarts.Clear(); } if(ret==maxRet&&ret>0) retStarts.Add(u0);
      if(trans>maxTrans){ maxTrans=trans; argTrans=u0; } if(pk>maxVal){ maxVal=pk; argVal=u0; } if(Fr.Gt(prod,best)){ best=prod; argBest=u0; } }
    Console.WriteLine($"starts {none+some}; no return {none}; >=1 return {some}; max returns {maxRet} at starts {string.Join(",",retStarts)}; max run transitions {maxTrans} (start {argTrans}); max run-start value {maxVal} (start {argVal}); repeated states {repeats}");
    Fr Q=new Fr(BigInteger.Pow(2,61),BigInteger.Pow(3,32)*993); Fr PQ=best*Q; Console.WriteLine($"P_B = {best} = {(double)best.n/(double)best.d:F13} at start {argBest}; P_B*Q_S = {PQ} < 3/2: {Fr.Gt(new Fr(3,2),PQ)}; value {(double)PQ.n/(double)PQ.d:F10}");
  }
}
