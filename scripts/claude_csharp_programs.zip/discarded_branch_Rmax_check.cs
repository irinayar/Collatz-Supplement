using System;
using System.Collections.Generic;
using System.Numerics;
// Rmax_j(s): maximum odd count R_j(Y) over the endpoints Y = 2(2^l 3^s u - 1) (l<=8, u<=200, 3 not| u) that appear as discarded last-run branches (s=a-l>=2).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int),int> rm=new();
  static int R(BigInteger x,int k){ int a=V3(x+1); if(k==0) return a; if(rm.TryGetValue((x,k),out var v)) return v; int best=-1;
    for(int l=0;l<=a;l++){ BigInteger y=B2(l)*(x+1)/B3(l)-1; int t=l+R(2*y,k-1); if(t>best) best=t; } rm[(x,k)]=best; return best; }
  static void Main(){
    Console.WriteLine("j: max R_j(Y) over the family, by s=2..7 (and overall); witness (l,s,u) of overall max");
    for(int j=1;j<=10;j++){ var line=new System.Text.StringBuilder($"j={j}: "); int overall=-1; string w="";
      for(int s=2;s<=7;s++){ int mx=-1; for(int l=0;l<=8;l++) for(int u=1;u<=200;u++){ if(u%3==0) continue; BigInteger Y=2*(B2(l)*B3(s)*u-1); int r=R(Y,j); if(r>mx) mx=r; if(r>overall){overall=r; w=$"({l},{s},{u})";} } line.Append($"s={s}:{mx} "); if(rm.Count>3000000) rm.Clear(); }
      line.Append($"| overall {overall} at {w}"); Console.WriteLine(line.ToString()); rm.Clear(); }
  }
}
