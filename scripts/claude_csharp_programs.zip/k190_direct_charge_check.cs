using System; using System.Numerics;
// K190: exact check of c(a)=1/a+2/(3a+1), delta/c ratio, psi_R(a)<=gamma*c(a) for all proper a>=a0 (a=11 mod 16), and the unresolved-singleton ratio gamma*b / V.
struct R { public BigInteger p, q; public R(BigInteger a, BigInteger b){ if(b.Sign<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; p=a/g;q=b/g; }
 public static R operator+(R x,R y)=>new R(x.p*y.q+y.p*x.q,x.q*y.q); public static R operator-(R x,R y)=>new R(x.p*y.q-y.p*x.q,x.q*y.q);
 public static R operator*(R x,R y)=>new R(x.p*y.p,x.q*y.q); public static R operator/(R x,R y)=>new R(x.p*y.q,x.q*y.p);
 public static bool operator<=(R x,R y)=>x.p*y.q<=y.p*x.q; public static bool operator>=(R x,R y)=>x.p*y.q>=y.p*x.q;
 public static implicit operator R(long v)=>new R(v,1); public double D()=>(double)(p>>Math.Max(0,(int)p.GetBitLength()-900))/(double)(q>>Math.Max(0,(int)p.GetBitLength()-900)); }
class P { static void Main(){
 int bad=0,tot=0; int badIdent=0;
 foreach (long n0 in new long[]{3,5,9,101,1001,100003,(1L<<30)+1,(1L<<59)+3}) { BigInteger n=n0|1; BigInteger H=(4*n-2)/3; BigInteger a0=H+1; while(a0%16!=11)a0++; R kap=new R(n-1,n+1);
   R C=kap+new R(9*(a0+5),5*(9*a0+5)); R gam=C*new R(5*(3*a0+1),9*(5*a0+1));
   for(int s=0;s<400;s++){ BigInteger a=a0+16*s; R d=new R(5,9*a); R br=kap+new R(9*(a+5),5*(9*a+5)); R psi=d*br; BigInteger a1=(3*a+1)/2; R cc=new R(1,a)+new R(1,a1); R cf=new R(5*a+1,a*(3*a+1)); if(!((cc-cf).p.IsZero)) badIdent++; tot++; if(!(psi<=gam*cf)) bad++; } }
 Console.WriteLine($"psi_R<=gamma*c on {tot} (n,a) cases: violations={bad}; identity c(a) mismatches={badIdent}");
 // unresolved singleton
 BigInteger N=3*(BigInteger.One<<254)+1; BigInteger HH=(4*N-2)/3; BigInteger A0=HH+1; while(A0%16!=11)A0++; R K=new R(N-1,N+1); R CC=K+new R(9*(A0+5),5*(9*A0+5)); R G=CC*new R(5*(3*A0+1),9*(5*A0+1));
 double b=0.1086751; // from K188 check at S=156
 double bb=0; { double L=256; double S=156; bb=Math.Exp(S*Math.Log(3)-L*Math.Log(2)) + (200.0/7)*Math.Pow(193.0/200,S+1) + (L+1)*Math.Pow(2,-(L-1)); }
 double capOverU=Math.Exp(bb/3)-1; double V=CC.D()*capOverU; double direct=G.D()*bb;
 Console.WriteLine($"C={CC.D():F9}, gamma={G.D():F9}, b={bb:F9}; V~C*cap/u={V:F9}; gamma*b={direct:F9}; ratio={direct/V:F12}");
}}
