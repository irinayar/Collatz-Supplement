using System;
using System.Numerics;
using System.Collections.Generic;
// Extension test (my corollary of ChatGPT 123035): all expanding blocks (e,1^s) with e<=7 absorbed by C_7 = max c over expanding e<=7 (exact rational);
// then G < 1+(19+8C)/(27x) for every prefix, provided x>=111 (x=15 mod 16). Exact BigInteger test on random actual words with x>=111.
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger Least(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static (BigInteger,BigInteger) Cc(int e,int s){ BigInteger a=BigInteger.Pow(3,s+1), d=BigInteger.One<<(s+e), B=BigInteger.Pow(3,s)*(1+(BigInteger.One<<e))-d; return (B,a-d); }
  static void Main(){
    int Emax=7; int[] smin=new int[Emax+1]; BigInteger Cn=0,Cd=1;
    for(int e=2;e<=Emax;e++){ int s=1; while(Cc(e,s).Item2<=0) s++; smin[e]=s; var (B,g)=Cc(e,s); if(B*Cd>Cn*g){Cn=B;Cd=g;} }
    BigInteger gcd=BigInteger.GreatestCommonDivisor(Cn,Cd); Cn/=gcd; Cd/=gcd; Console.WriteLine($"C_7 = {Cn}/{Cd} = {(double)Cn/(double)Cd:F5}; s_min = {string.Join(",",smin[2..])}");
    var rng=new Random(4242); long words=0,prefixes=0,bad=0,skipped=0;
    for(int t=0;t<4000;t++){
      var w=new List<int>{1,1,1}; int nb=1+rng.Next(6);
      for(int b=0;b<nb;b++){ int e=2+rng.Next(Emax-1); int s=smin[e]+rng.Next(3); w.Add(e); for(int j=0;j<s;j++) w.Add(1); }
      BigInteger x=Least(w); if(x<0) continue; 
      if(x<111){ int E=0; foreach(var v in w) E+=v; x+= BigInteger.One<<(E+1); } // another realiser of the same word (cylinder modulus 2^(E+1))
      // verify replay of exact valuations for x
      { BigInteger u2=x; bool ok=true; foreach(int e in w){ BigInteger y=3*u2+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e){ok=false;break;} u2=y;} if(!ok){skipped++;continue;} }
      words++; BigInteger u=x,N=1,Dn=1;
      foreach(int e in w){ N*=(3*u+1); Dn*=(3*u); BigInteger y=3*u+1; while(y.IsEven) y/=2; u=y; prefixes++;
        // G < 1 + (19+8C)/(27x) = 1 + (19 Cd + 8 Cn)/(27 Cd x)
        BigInteger num=19*Cd+8*Cn, den=27*Cd*x; if(!(N*den < (den+num)*Dn)){ bad++; Console.WriteLine($"VIOLATION x={x}"); } }
    }
    Console.WriteLine($"words {words} (skipped {skipped}), prefixes {prefixes}, violations {bad}; also bound<3/2 needs x>={2*(19*(double)Cd+8*(double)Cn)/(27*(double)Cd):F1}");
  }
}
