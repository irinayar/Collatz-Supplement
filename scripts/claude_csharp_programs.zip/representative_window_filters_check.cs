using System;
using System.Numerics;
// Check of ChatGPT 210605: representatives x in [3, 3^(r+1)+2], 0<=k<=8, 0<=r<=6; counts of comparisons by filter; max difference.
class P {
  static BigInteger[,] mn; static void Dfs(BigInteger z,int ev,int od){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z; if(ev<8) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    long total=0,mod3=0,env=0,exact=0,viol=0,r0=0,r1=0,r2x=0,budgetPairs=0; BigInteger maxD=BigInteger.MinusOne*1000000000; string argMax=""; string ex=""; long hOnly=0;
    var dom=new long[7]; for(int r=0;r<=6;r++){ long p=1; for(int i=0;i<=r;i++) p*=3; dom[r]=p+2; }
    // per (k,r) pairs counts
    for(long x=3;x<=dom[6];x++){ mn=new BigInteger[9,100]; Dfs(x,0,0);
      for(int r=0;r<=6;r++){ if(x>dom[r]) continue; for(int k=0;k<=8;k++){ var h0=mn[k,r]; var h1=mn[k,r+1]; if(h1!=0&&h0==0) hOnly++; if(h0==0||h1==0) continue; total++;
          var D=h1-h0; if(D>=0) viol++; if(D>maxD){ maxD=D; argMax=$"(x={x},k={k},r={r}): {h0}->{h1}"; }
          if(h0%3==2) mod3++; else if(k>=1&&h0>=BigInteger.Pow(2,k+1)-3) env++; else { exact++; int m=(int)(h0%3); if(m==0) r0++; else if(m==1) r1++; else r2x++; if(x==4&&k==4&&r==2) ex=$"H(4;4,2)={h0}, H(4;4,3)={h1}"; } } } }
    Console.WriteLine($"comparisons with both H finite: {total}; mod-3 predecessor filter: {mod3}; envelope filter: {env}; exact direct: {exact} (H = 0 mod 3: {r0}, 1 mod 3: {r1}); violations (D>=0): {viol}; successor-only feasible: {hOnly}; max D = {maxD} at {argMax}; {ex}");
    Console.WriteLine($"resolved by the two filters: {mod3+env}/{total} = {100.0*(mod3+env)/total:F2}%");
  }
}
