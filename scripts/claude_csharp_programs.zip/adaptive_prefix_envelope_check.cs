using System;
using System.Numerics;
// ChatGPT 223136: adaptive ternary tail + prefix residue envelope (P_low,P_high). Containment of exact origin extrema; example x=11,k=6,r=4.
class P {
  static BigInteger Md(BigInteger a,BigInteger m){ var r=a%m; if(r<0) r+=m; return r; }
  static BigInteger[] mn,mx; static int EM; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  // envelope of O_{a,b}(z) with j specified tail positions (j=0: coarse); returns false if no admissible tail
  static bool Env(int a,int b,BigInteger z,int j,out BigInteger lo,out BigInteger hi){ int L=a+b; BigInteger rhs=BigInteger.Pow(2,L)*z, den=BigInteger.Pow(3,b); bool any=false; BigInteger LO=0,HI=0; lo=0; hi=0;
    if(j==0){ BigInteger D=BigInteger.Pow(3,b)-BigInteger.Pow(2,b); lo=CeilDiv(rhs-BigInteger.Pow(2,a)*D,den); hi=FloorDiv(rhs-D,den); if(lo<1) lo=1; return hi>=lo; }
    int n=b-j; BigInteger p3j=BigInteger.Pow(3,j), p3n=BigInteger.Pow(3,n); var t=new int[j];
    void Rec(int idx,int start){ if(idx==j){ BigInteger T=0; for(int i=0;i<j;i++) T+=BigInteger.Pow(3,j-1-i)*BigInteger.Pow(2,t[i]); if(!Md(T-rhs,p3j).IsZero) return; int tt=t[0]; if(tt<n) return; BigInteger Pmin=n==0?0:p3n-BigInteger.Pow(2,n), Pmax=n==0?0:BigInteger.Pow(2,tt-n)*(p3n-BigInteger.Pow(2,n));
        BigInteger Pl,Ph; if(n==0){ Pl=0; Ph=0; } else { BigInteger Dd=Md((rhs-T)/p3j,p3n); Pl=Pmin+Md(Dd-Pmin,p3n); Ph=Pmax-Md(Pmax-Dd,p3n); if(Pl>Ph) return; }
        BigInteger l=CeilDiv(rhs-T-p3j*Ph,den), h=FloorDiv(rhs-T-p3j*Pl,den); if(l<1) l=1; if(h<l) return; if(!any){ LO=l; HI=h; any=true; } else { if(l<LO) LO=l; if(h>HI) HI=h; } return; }
      for(int s=start;s<L;s++){ t[idx]=s; Rec(idx+1,s+1); } }
    Rec(0,0); lo=LO; hi=HI; return any; }
  static BigInteger FloorDiv(BigInteger a,BigInteger b){ var q=BigInteger.DivRem(a,b,out var r); if(r<0) q-=1; return q; }
  static BigInteger CeilDiv(BigInteger a,BigInteger b)=>-FloorDiv(-a,b);
  static void Main(){
    long cases=0,bad=0,emptyOK=0;
    for(int a=0;a<=6;a++) for(int b=1;b<=6;b++) for(int z=3;z<=44;z++){ EM=a; mn=new BigInteger[b+1]; mx=new BigInteger[b+1]; Dfs(z,0,0);
      for(int j=1;j<=Math.Min(3,b);j++){ bool has=Env(a,b,z,j,out var lo,out var hi); if(mn[b]==0){ emptyOK++; continue; } cases++; if(!has||lo>mn[b]||hi<mx[b]) bad++; } }
    Console.WriteLine($"containment (refined P_low/P_high envelopes) a<=6, b<=6, z=3..44, j=1..3: {cases} nonempty cases, violations {bad}");
    int k=6,r=4; BigInteger x=11,y=7; EM=k-2; mn=new BigInteger[8]; mx=new BigInteger[8]; Dfs(4*x,0,0); var mxA=(BigInteger[])mx.Clone(); EM=k; mn=new BigInteger[8]; mx=new BigInteger[8]; Dfs(y,0,0); var mnB=(BigInteger[])mn.Clone();
    Env(k-2,r+1,4*x,0,out var aLo0,out var aHi0); Env(k,r-1,y,0,out var bLo0,out var bHi0); Env(k-2,r+1,4*x,1,out var aLo1,out var aHi1); Env(k,r-1,y,1,out var bLo1,out var bHi1);
    Console.WriteLine($"example x=11,k=6,r=4: j=0: A_5 in [{aLo0},{aHi0}], B_4 in [{bLo0},{bHi0}], gap >= {bLo0-aHi0}; j=1: A_5 in [{aLo1},{aHi1}], B_4 in [{bLo1},{bHi1}], gap >= {bLo1-aHi1}; exact max A_5={mxA[r+1]}, min B_4={mnB[r-1]}, gap {mnB[r-1]-mxA[r+1]}");
  }
}
