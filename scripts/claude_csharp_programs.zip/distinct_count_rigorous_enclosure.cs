using System;
using System.Numerics;
// Rigorous (directed-rounding, exact BigInteger) version of the distinct-count x Q separation range.
// Claim tested: for n>=2 distinct outside odd inputs >=h=H+2 (at most one divisible by 3, the other n-1 non-multiples of 3, J=ceil((n-1)/2)>=1 full-block capacities):
//   log G_out <= 1/h + (1/9) ln(1+6(J-1)/h);   G<=Q*G_out<3/2  <=>  ln(y) < 9(ln(1.5/Q) - 1/h),  y=1+6(J-1)/h.
// ln via 2*atanh(z), z=(x-1)/(x+1): partial sum <= ln x <= partial sum + 2 z^(2N+1)/((2N+1)(1-z^2)); fixed point scale 2^300, floor for lower, ceil for upper.
class P {
  static BigInteger SC=BigInteger.One<<300;
  static BigInteger CeilDiv(BigInteger a,BigInteger b){ BigInteger q=BigInteger.DivRem(a,b,out var r); return r.IsZero?q:q+1; } // a,b>0
  static BigInteger Ln(BigInteger xn,BigInteger xd,bool upper,int N){
    BigInteger zp=xn-xd, zq=xn+xd; BigInteger sum=0; BigInteger pp=BigInteger.One, qq=BigInteger.One; 
    for(int i=0;i<N;i++){ BigInteger a=SC*2*zp*pp, b=(2*i+1)*zq*qq; sum+= upper?CeilDiv(a,b):a/b; pp*=zp*zp; qq*=zq*zq; }
    if(upper){ // tail: 2 z^(2N+1)/((2N+1)(1-z^2)) , pp/qq = z^(2N) ; z^(2N+1)=zp*pp/(zq*qq); 1/(1-z^2)=zq^2/(zq^2-zp^2)
      BigInteger num=SC*2*zp*pp*zq*zq, den=(2*N+1)*zq*qq*(zq*zq-zp*zp); sum+=CeilDiv(num,den)+1; }
    else sum-=0; return sum; }
  static bool Safe(BigInteger H,BigInteger Qn,BigInteger Qd,BigInteger J){
    BigInteger h=H+2;
    // x=1.5/Q = 3*Qd/(2*Qn)
    BigInteger lowX=Ln(3*Qd,2*Qn,false,60); 
    BigInteger yn=h+6*(J-1), yd=h; BigInteger upY=Ln(yn,yd,true,120);
    BigInteger oneOverH=CeilDiv(SC,h);
    return upY < 9*(lowX-oneOverH);
  }
  static void Main(){
    BigInteger Qn=BigInteger.Pow(2,61), Qd=BigInteger.Pow(3,32)*993;
    foreach(long Hl in new long[]{786429,1572861,2097149,1073741821}){
      BigInteger H=Hl; BigInteger lo=1, hi=100*(H+2)/6; 
      if(!Safe(H,Qn,Qd,lo)){Console.WriteLine("J=1 unsafe?");continue;}
      while(hi-lo>1){ BigInteger mid=(lo+hi)/2; if(Safe(H,Qn,Qd,mid)) lo=mid; else hi=mid; }
      BigInteger nmax=2*lo+1; Console.WriteLine($"H={Hl}: rigorous safe up to n={nmax} (J={lo}); n/h={(double)nmax/(Hl+2):F5}; J+1 unsafe: {!Safe(H,Qn,Qd,lo+1)}");
    }
  }
}
