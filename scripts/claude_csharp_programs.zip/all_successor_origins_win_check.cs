using System;
using System.Collections.Generic;
using System.Numerics;
// ChatGPT 220618 test 1: does EVERY origin at (x,k,r+1) lie below the least origin at (x,k,r) ("all successor words win") for exceptional endpoints, x>=3, beyond the 56-cell window?
class P {
  static int EMAX; static BigInteger[] mn,mx; static void Dfs(BigInteger z,int ev,int od){ if(ev==EMAX){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; } if(ev<EMAX) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(string[] args){
    int K=int.Parse(args[0]); var sw=System.Diagnostics.Stopwatch.StartNew();
    for(int k=(args.Length>1?int.Parse(args[1]):4);k<=K;k++){ long B=(1L<<(k+1))-3; var xs=new HashSet<long>();
      for(long m=1;m<B;m++){ long y=m; int e=0; while(true){ if(e==k&&y>=3) xs.Add(y); if(e>k) break; if((y&1)==1) y=(3*y+1)>>1; else { if(e==k) break; y>>=1; e++; } } }
      long pairs=0,fails=0; string ex="";
      foreach(long x in xs){ EMAX=k; mn=new BigInteger[200]; mx=new BigInteger[200]; Dfs(x,0,0); int R=-1; for(int r=0;r<200;r++) if(mn[r]!=0) R=r;
        for(int r=0;r<R;r++){ if(mn[r]>=B) continue; pairs++; if(!(mx[r+1]<mn[r])){ fails++; if(ex=="") ex=$"(x={x},r={r}: least origin {mn[r]}, largest origin at r+1 {mx[r+1]})"; } } }
      Console.WriteLine($"k={k}: endpoints {xs.Count}, exceptional pairs (least origin < 2^(k+1)-3, successor feasible) {pairs}; pairs where some r+1 origin is >= least origin at r: {fails} {ex} [{sw.ElapsedMilliseconds/1000}s]");
      if(sw.ElapsedMilliseconds>260000) break; }
  }
}
