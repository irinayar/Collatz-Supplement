using System;
using System.Collections.Generic;
// Independent check of Codex K133 (13:24): prefixes with all iterates >= n and DISTINCT odd inputs u_0=n,...,u_{r-1}:
//  (a) low-band occupancy: #{i: n<=u_i<=H} <= 2 + #{u in [n,H]: u = 7 or 11 mod 12}, H=floor((4n-2)/3)
//  (b) G <= B_r(n) = f(n) * max( prod_{i<=r-1} f(g_i), f(b) prod_{i<=r-2} f(g_i) ), g_i = i-th element of E_n={u>n odd, 3∤u, A(u)>=n}, b = least odd u>n, 3∤u, not in E_n.
//  (c) relaxed crossing thresholds: least r with B_r(n)>=3/2 for n=3,7,31 (Codex: 17, 82, 508).
class P {
  static long A(long u){ long x=3*u+1; while((x&1)==0) x>>=1; return x; }
  static double f(long u)=> 1.0+1.0/(3.0*u);
  static void Main(){
    long chk=0, badA=0, badB=0, strict=0; int maxr=0;
    int RMAX=140;
    for(long n=3;n<=20001;n+=2){
      // E_n first RMAX-1 elements and b
      var g=new List<long>(); long b=-1; for(long u=n+2; (g.Count<RMAX || b<0) && u<n+100000; u+=2){ if(u%3==0) continue; if(A(u)>=n){ if(g.Count<RMAX) g.Add(u);} else if(b<0) b=u; }
      double[] pre=new double[g.Count+1]; pre[0]=1; for(int i=0;i<g.Count;i++) pre[i+1]=pre[i]*f(g[i]);
      long H=(4*n-2)/3; long lowAllowed=0; for(long u=n;u<=H;u++) if(u%12==7||u%12==11) lowAllowed++;
      // trajectory prefix until first descent
      long x=n; var inputs=new List<long>(); var set=new HashSet<long>(); bool distinct=true; double G=1;
      for(int step=0;step<2000;step++){
        if((x&1)==1){ // odd input
          inputs.Add(x); if(!set.Add(x)) distinct=false; G*=f(x); int r=inputs.Count;
          // prefix may stop after this input: need all iterates >= n up to and including x (x>=n ok); next state may be < n (last-input exception)
          if(distinct){ chk++; if(r>maxr) maxr=r;
            // (a)
            long cnt=0; foreach(var u in inputs) if(u>=n && u<=H) cnt++; if(cnt>2+lowAllowed) badA++;
            // (b)
            double Bv; if(r==1) Bv=f(n); else { double o1=pre[Math.Min(r-1,g.Count)]; double o2= b>0 && r>=2 ? f(b)*pre[Math.Min(r-2,g.Count)] : 0; Bv=f(n)*Math.Max(o1,o2); }
            if(G>Bv*(1+1e-12)) badB++; else if(G<Bv*(1-1e-9)) strict++; }
        }
        x = (x&1)==1 ? (3*x+1)/2 : x/2; if(x<n) break; }
    }
    Console.WriteLine($"odd n<=20001, no-descent prefixes with distinct inputs: {chk} (max odd count {maxr}); occupancy violations {badA}; B_r bound violations {badB}; strictly below B_r: {strict}");
    foreach(long n in new long[]{3,7,31}){
      var g=new List<long>(); long b=-1; for(long u=n+2; (g.Count<2000 || b<0); u+=2){ if(u%3==0) continue; if(A(u)>=n){ if(g.Count<2000) g.Add(u);} else if(b<0) b=u; }
      double[] pre=new double[g.Count+1]; pre[0]=1; for(int i=0;i<g.Count;i++) pre[i+1]=pre[i]*f(g[i]);
      int thr=-1; for(int r=1;r<=1500;r++){ double Bv; if(r==1) Bv=f(n); else { double o1=pre[r-1]; double o2= b>0? f(b)*pre[r-2]:0; Bv=f(n)*Math.Max(o1,o2); } if(Bv>=1.5){thr=r;break;} }
      // old mod-3 packing: f(n) * product of the smallest r-1 odd 3∤u > n
      var old=new List<long>(); for(long u=n+2; old.Count<2000; u+=2) if(u%3!=0) old.Add(u); double po=f(n); int thr2=-1; if(po>=1.5) thr2=1; for(int r=2;r<=1500 && thr2<0;r++){ po*=f(old[r-2]); if(po>=1.5) thr2=r; }
      Console.WriteLine($"n={n}: least r with B_r(n)>=3/2: {thr} (old mod-3 packing bound: {thr2}); b={b}");
    }
  }
}
