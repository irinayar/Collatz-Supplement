using System;
using System.Numerics;
class P {
  static void Main(){
    double l2=Math.Log2(3.0); double best=0; long arg=0; long cnt=0; int maxL=0;
    for(long m=1048575;m<=1310717;m+=2){ long n=m; int L=0,r=0; while(n!=2){ if((n&1)==1){ n=(3*n+1)>>1; r++; } else n>>=1; L++; } if(L>maxL) maxL=L; double g=Math.Pow(2.0,(L+1)-r*l2-Math.Log2((double)m)); cnt++; if(g>best){best=g;arg=m;} }
    Console.WriteLine($"delta starts {cnt}: max G={best:F10} at m={arg}; max L to 2 = {maxL}");
    BigInteger c1=3*(BigInteger.Pow(3,32)*993), c2=2*BigInteger.Pow(2,61);
    foreach(int r in new[]{707045,707046}){ bool ok=c2*BigInteger.Pow(3932158,r) < c1*BigInteger.Pow(3932157,r); Console.WriteLine($"H=1310717 r={r}: strict ineq {ok}"); }
  }
}
