using System; using System.Numerics;
// ChatGPT Signed Aggregate (19:12) eq. (26): C_bin = sup 2 B P_C Delta_sigma <= 0.0017576573360909415 < 1758/10^6 with P_C/(H+1)<=c_*, B P_C <= 5 P_C + n/1e5, Delta_sigma decreasing in B (take B=5), n>=2^71+1.
class P { static double Q(BigInteger a, BigInteger b){ int sh=(int)Math.Max(0,Math.Max(a.GetBitLength(),b.GetBitLength())-900); return (double)(a>>sh)/(double)(b>>sh); }
 static void Main(){ BigInteger cn=BigInteger.Parse("620751769493359576"), cd=BigInteger.Parse("1180591620717411303425"); double cstar=Q(cn,cd); Console.WriteLine($"c_* = {cstar:E12} (=P_C/(H+1) cap)");
  foreach(int ex in new[]{71,72,100,200,271}){ BigInteger n=(BigInteger.One<<ex)+1; BigInteger H=(4*n-2)/3; // exact rational with B=5: omega=(H+5)/(H+1)
   // Delta = 1/(n+5) - 1/(H+5+omega) ; H+5+omega = ((H+5)(H+1) + (H+5))/(H+1) = (H+5)(H+2)/(H+1)
   BigInteger dn=(H+5)*(H+2) - (n+5)*(H+1); BigInteger dd=(n+5)*(H+5)*(H+2); // Delta = ((H+5)(H+2)/(H+1) - (n+5)) / ((n+5)(H+5)(H+2)/(H+1)) = dn/dd with (H+1) cancelling
   // numerator of 2(5 cstar (H+1) + n/1e5): use exact c_* fraction
   BigInteger sn=2*(5*cn*(H+1)*100000 + n*cd); BigInteger sd=cd*100000; // 2*(5 c*(H+1) + n/1e5) = sn/sd
   double C=Q(sn*dn, sd*dd); Console.WriteLine($"n=2^{ex}+1: C_bin(B=5 bound) = {C:F16}   < 1758/1e6 = {C<0.001758}");
  }
  Console.WriteLine("claimed C_bin = 0.0017576573360909415");
 }}
