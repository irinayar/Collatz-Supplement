using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 200243: band [257,1023] excursion maximum M and thresholds for G <= Q M^J (1026/1025)^A.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static Fr Step(long u,out long v){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger vv=w>>e; v=(long)(vv>long.MaxValue/2?long.MaxValue/2:vv); return new Fr(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    var memo=new Dictionary<long,Fr>(); var next=new Dictionary<long,long>(); bool cycle=false;
    Fr E(long u){ if(memo.TryGetValue(u,out var r)) return r; var path=new List<long>(); long cur=u; var seen=new HashSet<long>(); 
      while(true){ if(memo.ContainsKey(cur)) break; if(!seen.Add(cur)){ cycle=true; break; } path.Add(cur); var c=Step(cur,out long v); next[cur]=v; if(!(v>=257&&v<=1023)){ memo[cur]=c; path.RemoveAt(path.Count-1); break; } cur=v; }
      for(int i=path.Count-1;i>=0;i--){ long a=path[i]; var c=Step(a,out long v); memo[a]=c*memo[v]; } return memo[u]; }
    Fr M=new Fr(1,1); long arg=0; for(long u=257;u<=1023;u+=2){ var e=E(u); if(Fr.Gt(e,M)){ M=e; arg=u; } }
    var chain=new List<string>(); long x=arg; while(true){ chain.Add(x.ToString()); Step(x,out long v); if(v>=257&&v<=1023) x=v; else { chain.Add(v+"(out)"); break; } }
    Console.WriteLine($"cycle detected in band: {cycle}; M = {M} = {(double)M.n/(double)M.d:F10} at u={arg}; chain {string.Join(" -> ",chain)}");
    Fr Q=new Fr(8192,6561), tail=new Fr(1026,1025), three2=new Fr(3,2);
    Console.WriteLine("Q*M < 3/2: " + Fr.Gt(three2,Q*M) + "; Q*M = " + Q*M);
    foreach(int J in new[]{1,2,3,5,10}){ Fr b=Q; for(int j=0;j<J;j++) b=b*M; int A=0; while(!Fr.Gt(b,three2)){ b=b*tail; A++; } Console.WriteLine($"J={J}: bound first exceeds 3/2 at A={A} (safe for A<={A-1})"); }
  }
}
