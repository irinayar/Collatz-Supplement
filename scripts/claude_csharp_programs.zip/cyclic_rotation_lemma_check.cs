using System;
// Audit of Ordered_Parity_Profile_Theorem Section 6 cyclic-rotation lemma: words of length N, increments +3 (bit 1) and -5 (bit 0), total T=8s-5N>0:
// the number of cyclic rotations whose prefix sums are ALL strictly positive is at most T.  Exhaustive for N<=18.  Also check (11)-style count bound: #strictly positive words with s ones <= (T/N) C(N,s).
class P {
  static void Main(){
    long violations=0, words=0; int maxGood=0; long cntBad=0;
    for(int N=3;N<=18;N++){ long[] pos=new long[N+1]; long[] tot=new long[N+1];
      for(long w=0;w<(1L<<N);w++){ int s=System.Numerics.BitOperations.PopCount((ulong)w); int T=8*s-5*N; if(T<=0) continue; words++;
        int good=0; for(int rot=0;rot<N;rot++){ int sum=0; bool ok=true; for(int i=0;i<N;i++){ int bit=(int)((w>>((rot+i)%N))&1); sum+= bit==1?3:-5; if(sum<=0){ok=false;break;} } if(ok) good++; }
        if(good>T) violations++; if(good>maxGood) maxGood=good;
        if((w&1)==1 || true){ } 
        // strictly positive WORD itself (rotation 0)
        { int sum=0; bool ok=true; for(int i=0;i<N;i++){ int bit=(int)((w>>i)&1); sum+= bit==1?3:-5; if(sum<=0){ok=false;break;} } if(ok){ pos[s]++; } } tot[s]++; }
      for(int s=0;s<=N;s++){ int T=8*s-5*N; if(T<=0) continue; double bound=(double)T/N*tot[s]; if(pos[s]>bound+1e-9) cntBad++; } }
    Console.WriteLine($"N=3..18, words with T>0: {words}; rotation-count violations (good>T): {violations}; counting-bound violations: {cntBad}; max good rotations seen {maxGood}");
  }
}
