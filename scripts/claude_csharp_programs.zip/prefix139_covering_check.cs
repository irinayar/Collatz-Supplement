using System;
using System.Collections.Generic;
using System.Numerics;
// Independent check of Codex K143 / ChatGPT 181416 prefix covering: 9-transition prefixes (e_1..e_9), e_i>=1, cumulative caps E_j<=(1,3,4,6,8,9,11,13,14), at most two resets (e_i>=2):
// expect 163 candidates; 24 have a contracting prefix (2^{E_j}>3^j) that already fails (2^E-3^j)u>=B_j at the least cylinder representative u>=11 (min margin 1024); 139 survivors with 3^j>2^{E_j} at every prefix,
// pairwise disjoint cylinders (mod 2^{E_9+1}), counts by reset number 1,22,116 and densities 1/1024, 199/32768, 449/32768 (total 85/4096).
class P {
  static int[] cap={1,3,4,6,8,9,11,13,14};
  static List<int[]> cands=new List<int[]>();
  static void Rec(int p,int E,int resets,int[] cur){ if(p==9){ cands.Add((int[])cur.Clone()); return; } for(int v=1;E+v<=cap[p];v++){ int r=resets+(v>=2?1:0); if(r>2) continue; cur[p]=v; Rec(p+1,E+v,r,cur); } }
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static void Main(){
    Rec(0,0,0,new int[9]); Console.WriteLine($"candidates with caps and <=2 resets: {cands.Count}");
    int contracting=0,failAll=0; BigInteger minMargin=BigInteger.Pow(10,30); var surv=new List<(int[] ev,BigInteger a,BigInteger M,int resets)>();
    foreach(var ev in cands){ BigInteger[] B=new BigInteger[10]; int[] E=new int[10]; B[0]=0; E[0]=0; for(int j=0;j<9;j++){ B[j+1]=3*B[j]+(BigInteger.One<<E[j]); E[j+1]=E[j]+ev[j]; }
      BigInteger M=BigInteger.One<<(E[9]+1); BigInteger a=(((BigInteger.One<<E[9])-B[9])*ModInv(BigInteger.Pow(3,9),M))%M; if(a<0) a+=M; // least positive rep >= 11
      BigInteger u=a; if(u<11){ u+= M*((11-u+M-1)/M); }
      int resets=0; foreach(int v in ev) if(v>=2) resets++;
      bool contr=false; bool failed=false; BigInteger worst=BigInteger.Pow(10,30);
      for(int j=1;j<=9;j++){ BigInteger d=(BigInteger.One<<E[j])-BigInteger.Pow(3,j); if(d>0){ contr=true; BigInteger margin=d*u-B[j]; if(margin>=0){ failed=true; if(margin<worst) worst=margin; } } }
      if(contr){ contracting++; if(failed){ failAll++; if(worst<minMargin) minMargin=worst; } else Console.WriteLine("contracting but NOT failing at least rep: "+string.Join(",",ev)); }
      else surv.Add((ev,a,M,resets)); }
    Console.WriteLine($"candidates with a contracting prefix: {contracting}; of these failing at the least representative: {failAll}; minimum margin {minMargin}; survivors {surv.Count}");
    int[] byReset=new int[3]; BigInteger[] dens=new BigInteger[3]; // density numerators over 2^15=32768
    BigInteger den=BigInteger.One<<20; BigInteger[] num=new BigInteger[3]; foreach(var s in surv){ byReset[s.resets]++; num[s.resets]+= den/s.M; }
    Console.WriteLine($"survivors by reset count: {byReset[0]},{byReset[1]},{byReset[2]}; densities (x 32768): {(double)num[0]*32768/(double)den:F4}, {(double)num[1]*32768/(double)den:F4}, {(double)num[2]*32768/(double)den:F4}; total {(double)(num[0]+num[1]+num[2])/(double)den:F8} (85/4096={85.0/4096:F8})");
    long overlap=0; for(int i=0;i<surv.Count;i++) for(int k=i+1;k<surv.Count;k++){ BigInteger g=BigInteger.GreatestCommonDivisor(surv[i].M,surv[k].M); if(((surv[i].a-surv[k].a)%g+g)%g==0) overlap++; }
    Console.WriteLine($"overlapping pairs of survivor cylinders: {overlap}");
  }
}
