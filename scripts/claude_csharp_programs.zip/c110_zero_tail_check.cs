using System;
using System.Numerics;
// Independent check of ChatGPT's zero-tail lift of C110 (note 191711):
// w = 1^r (01)^s 0^(k+1); q = 3^(r+s) > p_k = 2^(r+2s+1+k); U = q + p_0 - 2^r 3^(s+1);
// n with p_k n = U mod q  =>  m = (p_k n - U)/q is a positive integer < n with parity word w and T^|w|(m) = n.
// Also v_3(2^k n - 1) = s+1 for r = r_{s,k}.
class P {
  static BigInteger Inv(BigInteger a, BigInteger q, int e) => BigInteger.ModPow(a % q, 2 * BigInteger.Pow(3, e - 1) - 1, q);
  static void Main(string[] a) {
    int Smax = int.Parse(a[0]), Kmax = int.Parse(a[1]); long checks = 0, bad = 0;
    for (int k = 0; k <= Kmax; k++) for (int s = 0; s <= Smax; s++) {
      int rs = 2; while (!(BigInteger.Pow(3, rs + s) > BigInteger.Pow(2, rs + 2 * s + 1 + k))) rs++;
      for (int r = rs; r <= rs + 2; r++) {
        int e = r + s; BigInteger q = BigInteger.Pow(3, e), pk = BigInteger.Pow(2, r + 2 * s + 1 + k), p0 = BigInteger.Pow(2, r + 2 * s + 1);
        BigInteger U = q + p0 - BigInteger.Pow(2, r) * BigInteger.Pow(3, s + 1);
        BigInteger n0 = ((U % q) * Inv(pk, q, e)) % q;
        string w = new string('1', r) + string.Concat(System.Linq.Enumerable.Repeat("01", s)) + new string('0', k + 1);
        for (int t = 0; t < 8; t++) {
          BigInteger n = n0 + q * t; if (n < 1) continue; checks++;
          BigInteger num = pk * n - U; bool ok = (num % q).IsZero;
          if (ok) {
            BigInteger m = num / q; ok = m > 0 && m < n; BigInteger x = m;
            foreach (char c in w) { bool odd = !x.IsEven; if (odd != (c == '1')) { ok = false; break; } x = odd ? (3 * x + 1) / 2 : x / 2; }
            if (ok && x != n) ok = false;
          }
          if (ok && r == rs) { BigInteger d = (BigInteger.Pow(2, k) * n - 1); int v = 0; if (d.IsZero) ok = false; else while ((d % 3).IsZero) { d /= 3; v++; } if (v != s + 1) ok = false; }
          if (!ok) bad++;
        }
      }
    }
    Console.WriteLine($"k=0..{Kmax}, s=0..{Smax}, r=r_(s,k)..+2, 8 values of t: {checks} checks, failures {bad}");
  }
}
