using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Replay of the all-length entrance proofs (ChatGPT 20:59 / 21:00, 2026-11-23): toll certificate, 1/120 exclusions, toll-limit family, cap-13 ingredients, genuine triple.
class P {
 static BigInteger P2(int k)=>BigInteger.One<<k; static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static BigInteger ModInv(BigInteger a,BigInteger m){ BigInteger x0=1,x1=0,r0=((a%m)+m)%m,r1=m; while(r1!=0){ var q=r0/r1; var t=r0-q*r1; r0=r1; r1=t; var u=x0-q*x1; x0=x1; x1=u; } return ((x0%m)+m)%m; }
 static int V3(BigInteger x){ int c=0; while(x%3==0){x/=3;c++;} return c; }
 static int V2(BigInteger x){ int c=0; while(x%2==0){x/=2;c++;} return c; }
 // odd-transition exponents of the shortcut orbit from odd x until the count of odd inputs reaches g
 static List<int> Exps(BigInteger x,int g,out BigInteger end,List<BigInteger> oddStates){ var ex=new List<int>(); for(int i=0;i<g;i++){ oddStates.Add(x); BigInteger t=3*x+1; int v=V2(t); ex.Add(v); x=t>>v; } end=x; return ex; }
 static void Main(){
  BigInteger tol=P2(71);
  // ---- A: toll certificate for s<=705
  BigInteger bestN=0,bestD=1; int bestS=0,bestE=0; var mu=new Dictionary<int,(BigInteger n,BigInteger d,int e)>();
  for(int s=1;s<=705;s++){ int e=2; while(!(15*P2(s+e-1)>16*P3(s)-P2(s))) e++; BigInteger num=15*P2(s+e-1)-(16*P3(s)-P2(s)), den=15*P2(s+e-1); mu[s]=(num,den,e); if(bestS==0||num*bestD<bestN*den){bestN=num;bestD=den;bestS=s;bestE=e;} }
  Console.WriteLine("min mu_s over s<=705 at s="+bestS+", e+="+bestE+", mu="+((double)bestN/(double)bestD).ToString("E10")+" (claimed s=352,e=207, 6.261817670023883e-5)");
  // (8): mu - 16/(15 2^71) > 1/15970
  BigInteger l8n=bestN*15*tol-16*bestD, l8d=bestD*15*tol; Console.WriteLine("(8) mu_352-16/(15*2^71) > 1/15970: "+(l8n*15970>l8d));
  // four types for s<=432 with mu_s - 16/(15 2^71) <= 1/120
  var four=new List<string>(); for(int s=1;s<=432;s++){ var (n,d,e)=mu[s]; BigInteger a=n*15*tol-16*d, b=d*15*tol; if(a*120<=b) four.Add("("+s+","+e+")"); } Console.WriteLine("types s<=432 with mu_s-16/(15*2^71)<=1/120: "+string.Join(" ",four)+" (claimed (193,114)(246,145)(299,176)(352,207))");
  // ---- B: 21583 first types and 86332 residues
  var first=new List<(int s,int e)>(); for(int s=2;s<=272;s++) for(int e=2;e<=2000;e++){ if(P2(s+e-1)<P3(s)) first.Add((s,e)); else break; }
  Console.WriteLine("expanding first types 2<=s1<=272, e1>=2: "+first.Count+" (claimed 21583); 3^273<2^433: "+(P3(273)<P2(433))+"; 2^274-6 over 3 = Hmax");
  BigInteger Hmax=(P2(274)-6)/3; var second=new (int s,int e)[]{(193,114),(246,145),(299,176),(352,207)};
  int total=0; bool allAbove=true; var minBits=new Dictionary<(int,int),(int bits,(int,int) ft)>(); int simOk=0, simTried=0; var rnd=new Random(1);
  foreach(var (s2,e2) in second){ BigInteger minr=-1; (int,int) mf=(0,0); foreach(var (s1,e1) in first){ int g=s1+s2; int E=g+e1+e2-2; BigInteger U=P3(g)+P2(s1)*P3(s2)*(P2(e1-1)-1)-P2(g+e1-1); BigInteger M=P2(E+1); BigInteger r=(((P2(E)-U)*ModInv(P3(g),M))%M+M)%M; total++; if(!(r>Hmax)) allAbove=false; if(minr<0||r<minr){minr=r;mf=(s1,e1);}
        if(simTried<100 && rnd.Next(200)==0){ simTried++; // simulate from u=r: first two complete runs must have the prescribed word and the identity 2^E y = 3^g u + U must hold
          BigInteger x=r; var os=new List<BigInteger>(); var ex=Exps(x,g,out var y,os); var want=new List<int>(); for(int i=0;i<s1-1;i++) want.Add(1); want.Add(e1); for(int i=0;i<s2-1;i++) want.Add(1); want.Add(e2); bool ok=ex.SequenceEqual(want) && (P2(E)*y==P3(g)*r+U) && (y%2==1); if(ok) simOk++; } }
    minBits[(s2,e2)]=((int)minr.GetBitLength(),mf); Console.WriteLine("second type ("+s2+","+e2+"): minimum residue bit length "+minr.GetBitLength()+" at first type ("+mf.Item1+","+mf.Item2+")  (claimed "+(s2==193?"310 (3,2)":s2==246?"392 (2,2)":s2==299?"478 (2,2)":"562 (4,3)")+")"); }
  Console.WriteLine("residue checks "+total+" (claimed 86332); all residues > Hmax: "+allAbove+"; simulated cylinder identity on "+simOk+"/"+simTried+" random cases");
  // ---- C: toll-limit family at (s,e)=(140,83)
  { int s=140,e=83,k=e-1; BigInteger lamN=P2(s+e-1), lamD=P3(s); Console.WriteLine("lambda=2^"+(s+e-1)+"/3^"+s+" = "+((double)lamN/(double)lamD).ToString("F6")+" in (16/15,9/8): "+(lamN*15>lamD*16 && lamN*8<lamD*9));
    BigInteger m1=P2(k+1), m2=9; BigInteger d1=((1+P2(k))%m1*ModInv(P3(s),m1))%m1; BigInteger d2=(5*ModInv(P2(s),9))%9; // d = d1 mod 2^(k+1), d = d2 mod 9
    BigInteger dd=d1; while(dd%9!=d2) dd+=m1; BigInteger a=P2(s)*dd-1; BigInteger ynum=P3(s)*dd-1; bool yint=ynum%P2(k)==0; BigInteger y=ynum/P2(k); BigInteger un=8*a-5; bool uint_=un%9==0; BigInteger u=un/9; BigInteger n=3*(u+1)/4; BigInteger H=(4*n-2)/3;
    Console.WriteLine("d odd: "+(dd%2==1)+", y integer: "+yint+", u integer: "+uint_+", n odd integer: "+(((u+1)%4==0)&&(n%2==1))+", H==u: "+(H==u)+", n bits "+n.GetBitLength()+" in [2^71,2^272): "+(n>=P2(71)&&n<P2(272)));
    var os=new List<BigInteger>(); var ex1=Exps(u,2,out var a1,os); bool p1=(a1==a)&&ex1.SequenceEqual(new List<int>{1,2}); var os2=new List<BigInteger>(); var ex2=Exps(a,s,out var y2,os2); var want=new List<int>(); for(int i=0;i<s-1;i++) want.Add(1); want.Add(e); bool p2=y2==y&&ex2.SequenceEqual(want);
    bool aboveH=true; foreach(var st in os.Skip(1)) if(!(st>H)) aboveH=false; foreach(var st in os2) if(!(st>H)) aboveH=false; if(!(y>H)) aboveH=false;
    Console.WriteLine("run u->a word (1,2): "+p1+"; run a->y word (1^(s-1),e): "+p2+"; source in band: "+(u>=n&&u<=H)+"; all proper odd states above H: "+aboveH);
    // yC = 1 - A_s y / a ; A_s=(16-(2/3)^s)/15  -> yC = 1 - (16*3^s-2^s)/(15*3^s) * y / a
    BigInteger cn=15*P3(s)*a-(16*P3(s)-P2(s))*y, cd=15*P3(s)*a; Console.WriteLine("0 < y*C_pre < mu_140: "+(cn>0)+" "+(cn*mu[140].d<mu[140].n*cd)+"; y*C_pre = "+((double)cn/(double)cd).ToString("E6")+", mu_140="+((double)mu[140].n/(double)mu[140].d).ToString("E6")+" < 1/119: "+(mu[140].n*119<mu[140].d)); }
  // ---- D: cap-13 ingredients
  Console.WriteLine("2^432>3^272: "+(P2(432)>P3(272))+"; 45*2^1119>64*3^705: "+(45*P2(1119)>64*P3(705)));
  bool v3ok=true; for(int d=2;d<=3000;d+=2){ if(V3(P2(d)-1)!=1+V3(d)) v3ok=false; } Console.WriteLine("v3(2^d-1)=1+v3(d) for even d<=3000: "+v3ok);
  Console.WriteLine("(7): 2*3^(6-1) = "+2*243+" >= 486; low/high exponents differ <=412 and even => v3(2^d-1)<=1+v3(412)...: max over even d<=412 of 1+v3(d) = "+Enumerable.Range(1,206).Select(i=>1+V3(2*i)).Max());
  Console.WriteLine("capacity: 2+2+1+1+1="+(2+2+1+1+1)+"; low branch 2+2+1+1="+(2+2+1+1)+"; total "+(7+6));
  // ---- F: category-B cylinder (second terminal exponent >= 8)
  { int okc=0,tot=0; int[] smin={2,4,6,7,9,11}; for(int ei=0;ei<6;ei++){ int e1=ei+2; for(int s=smin[ei];s<=smin[ei]+3;s++) for(int t=12;t<=15;t++){ BigInteger M=P2(s+e1-1+t+7); BigInteger bracket=P2(s)+P2(s+e1-1)*((P2(t)*ModInv(P3(t),M))%M-1); BigInteger r=((bracket%M)*ModInv(P3(s),M)-1)%M; r=(r%M+M)%M; tot++;
        BigInteger x=r; var os=new List<BigInteger>(); var ex=Exps(x,s,out var a,os); bool f1=ex.Take(s-1).All(v=>v==1)&&ex[s-1]==e1; var os2=new List<BigInteger>(); var ex2=Exps(a,t,out var b,os2); bool f2=ex2.Take(t-1).All(v=>v==1)&&ex2[t-1]>=8; if(f1&&f2) okc++; } }
    Console.WriteLine("category-B cylinder: first run (s,e1), second run length t with e2>=8 for "+okc+"/"+tot+" cases"); }
  // ---- E: genuine triple at t=0
  { BigInteger x0=BigInteger.Parse("28009605141906478718048996165356834617404527592341581343158040277364583"); BigInteger n0s=BigInteger.Parse("18712102675213256858854804053331583249479200898139854059156166224122323");
    Console.WriteLine("x0 odd: "+(x0%2==1)+"; 2^55 x0+1 = 0 mod 3^95: "+((P2(55)*x0+1)%P3(95)==0)+"; x0 = 7 mod 32: "+(x0%32==7)+"; v3(2x0+1)="+V3(2*x0+1));
    BigInteger u=4*(2*x0+1)/9-1, v=32*(2*x0+1)/81-1, w=P2(95)*(P2(55)*x0+1)/P3(95)-1; bool ints=(4*(2*x0+1))%9==0&&(32*(2*x0+1))%81==0&&(P2(95)*(P2(55)*x0+1))%P3(95)==0; BigInteger yn=27*x0+19; bool yint=yn%16==0; BigInteger y=yn/16;
    BigInteger zn=P3(49)*(y+1)-P2(49); bool zint=zn%P2(79)==0; BigInteger z=zn/P2(79); BigInteger n=z-4; BigInteger H=(4*n-2)/3;
    Console.WriteLine("integers: "+ints+" "+yint+" "+zint+"; n==claimed n0: "+(n==n0s)+"; n bits "+n.GetBitLength()+"; n odd: "+(n%2==1)+"; 2^71<n<2^272: "+(n>P2(71)&&n<P2(272)));
    Console.WriteLine("u,v,w in [n,H]: "+(u>=n&&u<=H)+" "+(v>=n&&v<=H)+" "+(w>=n&&w<=H)+"; x0>H: "+(x0>H)+"; y>H: "+(y>H));
    var words=new (string name,BigInteger src,int[] want)[]{("u",u,new[]{1,2,1,1,2}),("v",v,new[]{1,1,1,1,3,1,2}),("w",w,Enumerable.Repeat(1,94).Concat(new[]{56,1,1,2}).ToArray())};
    foreach(var (name,src,want) in words){ var os=new List<BigInteger>(); var ex=Exps(src,want.Length,out var yy,os); bool word=ex.SequenceEqual(want); bool above=true; foreach(var st in os.Skip(1)) if(!(st>H)) above=false; if(!(yy>H)) above=false;
      // continuation (1^48,31) from y to z
      var os2=new List<BigInteger>(); var want2=Enumerable.Repeat(1,48).Concat(new[]{31}).ToArray(); var ex2=Exps(yy,49,out var zz,os2); bool cont=ex2.SequenceEqual(want2)&&zz==z; bool above2=true; foreach(var st in os2) if(!(st>H)) above2=false;
      int g=want.Length+49; int E=want.Sum()+79; Console.WriteLine(name+": word ok "+word+", reaches y "+(yy==y)+", proper odd states >H "+above+", continuation reaches z=n+4 "+cont+" with proper states >H "+above2+", (g,E)=("+g+","+E+"), z in band "+(z>=n&&z<=H)); }
    // slopes
    Console.WriteLine("2/3 < 3^52/2^83 < 2^150/3^95 < 3/4: "+(P3(52)*3>P2(83)*2 ? "R>2/3 ":"")+(P3(52)*P3(95)<P2(83)*P2(150) ? "R<A ":"")+(P2(150)*4<P3(95)*3 ? "A<3/4":""));
    // exact credits of the six entrance runs are zero: check c=0 for each complete run with a=input, b=output
    bool credit0=true; foreach(var (name,src,want) in words){ BigInteger x=src; int i=0; while(i<want.Length){ int s=1; while(want[i+s-1]==1) s++; int e=want[i+s-1]; BigInteger a=x; var os=new List<BigInteger>(); var ex=Exps(a,s,out var b,os); // credit positive iff 1/b > (1+beta/15)/a  <=> 15*3^s*a > (16*3^s-2^s)*b
        if(15*P3(s)*a>(16*P3(s)-P2(s))*b) credit0=false; x=b; i+=s; } }
    Console.WriteLine("all six entrance runs of the three words have zero credit: "+credit0); }
 }}
