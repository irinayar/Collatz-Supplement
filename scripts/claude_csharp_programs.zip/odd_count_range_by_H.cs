using System;
class P { static void Main(){ double Q=1.25314215; // >= exact 2^61/(3^32*993)=1.2531421444 (maximum of Gtot over odd m<=H for every H>=993, closed-form run to 2^30)
  foreach(int e in new[]{12,16,18,20,22,24,26,28,30}){ double H=Math.Pow(2,e)-3; double x=1.0/(3.0*(H+2)); double lnf=x-0.5*x*x; double rmax=(Math.Log(1.5)-Math.Log(Q))/lnf; Console.WriteLine($"H=2^{e}-3: r_max = {rmax:E3} ({(long)rmax})"); } } }
