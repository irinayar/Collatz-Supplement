using System; using System.Collections.Generic; using System.IO; using System.Linq; using System.Numerics;
class P {
 static readonly UInt128 M=(UInt128)1<<41; static UInt128[] p3=new UInt128[60];
 static void Fwd(ulong r,out UInt128 x,out int a){ x=r;a=0; for(int j=1;j<=41;j++){ if((x&1)==1){a++; x=(3*x+1)/2;} else x/=2; } }
 static int best; static ulong R; static int AA; const int E=7;
 static void Dfs(UInt128 z,int b,int e){ if(e<best){ UInt128 Q=((UInt128)1<<(b+e))*p3[AA-b]; if(z<R && Q<M && z>0) best=e; }
   if(e<E && e+1<best) Dfs(2*z,b,e+1); if(b<AA && z%3==2) Dfs((2*z-1)/3,b+1,e); }
 static int MinBudget(ulong r,UInt128 x,int a){ best=E+1; R=r; AA=a; Dfs(x,0,0); return best; }
 // all passing words: record (block composition | offsets) of each
 static List<string> all; 
 static string Shape(UInt128 x,List<int> w){ UInt128 z=x; int k=0; var bl=new List<int>(); var off=new List<int>(); while(k<w.Count){ UInt128 zin=z; int p=0; while(k<w.Count&&w[k]==1){z=(2*z-1)/3;p++;k++;} if(k>=w.Count)break; int d=0; while(k<w.Count&&w[k]==0){z=2*z;d++;k++;} int v=0; UInt128 t=zin+1; while(t%3==0){t/=3;v++;} bl.Add(d); off.Add(v-p);} return string.Join(",",bl)+"|"+string.Join(",",off); }
 static void All(UInt128 x,UInt128 z,int b,int e,List<int> w){ UInt128 Q=((UInt128)1<<(b+e))*p3[AA-b]; if(z<R&&Q<M&&z>0) all.Add(Shape(x,w));
   if(e<E){ w.Add(0); All(x,2*z,b,e+1,w); w.RemoveAt(w.Count-1);} if(b<AA&&z%3==2){ w.Add(1); All(x,(2*z-1)/3,b+1,e,w); w.RemoveAt(w.Count-1);} }
 static void Main(string[] args){
  p3[0]=1; for(int i=1;i<60;i++)p3[i]=p3[i-1]*3;
  var oldc=File.ReadAllBytes(Path.Combine(args[0],"classification.bin")); var neu=File.ReadAllBytes(Path.Combine(args[1],"direct7.bin"));
  var cnt=new long[16]; var trans=new Dictionary<(int,int),long>();
  for(long i=0;i<(1L<<28);i++){ int o=(i&1)==0?oldc[i>>1]&15:oldc[i>>1]>>4; int n=(i&1)==0?neu[i>>1]&15:neu[i>>1]>>4; cnt[n]++; var k=(o,n); trans[k]=trans.GetValueOrDefault(k)+1; }
  Console.WriteLine("new labels: "+string.Join(" ",Enumerable.Range(0,16).Where(l=>cnt[l]>0).Select(l=>l+":"+cnt[l])));
  Console.WriteLine("old->new pairs: "+string.Join(" ",trans.Where(kv=>kv.Key.Item1!=kv.Key.Item2).Select(kv=>$"{kv.Key.Item1}->{kv.Key.Item2}:{kv.Value}")));
  int unres=trans.Where(kv=>kv.Key.Item1==7&&kv.Key.Item2!=7).Select(kv=>kv.Key.Item2).DefaultIfEmpty(-1).First();
  int newUn=cnt.Select((c,l)=>(c,l)).Where(t=>t.c==8879971).Select(t=>t.l).DefaultIfEmpty(-1).First();
  // sample unresolved masks: no certificate with e<=7
  long s=0,sb=0,idx=0; for(long i=0;i<(1L<<28);i++){ int n=(i&1)==0?neu[i>>1]&15:neu[i>>1]>>4; if(n==newUn){ if(idx++%200==0){ ulong r=103UL+8192UL*(ulong)i; UInt128 x;int a; Fwd(r,out x,out a); s++; if(MinBudget(r,x,a)<=7) sb++; } } }
  Console.WriteLine($"unresolved label {newUn}; sampled {s}; with a certificate e<=7: {sb}");
  long rows=0,badF=0,badW=0,badMin=0,off3=0,off3other=0; var byA=new Dictionary<int,long>(); ulong minR=ulong.MaxValue; UInt128 minG=UInt128.MaxValue; var shapes=new Dictionary<string,long>();
  foreach(var ln in File.ReadLines(Path.Combine(args[1],"direct7.sorted")).Skip(1)){ var f=ln.Split(','); ulong r=ulong.Parse(f[0]),xr=ulong.Parse(f[1]); int a=int.Parse(f[2]),e=int.Parse(f[3]),b=int.Parse(f[4]); ulong wb=ulong.Parse(f[5]),org=ulong.Parse(f[6]); rows++;
    UInt128 x;int aa; Fwd(r,out x,out aa); if(x!=xr||aa!=a||e!=7){badF++;continue;}
    UInt128 z=x; int bo=0,ee=0; bool ok=true; var w=new List<int>(); for(int k=0;k<b+e;k++){ int bit=(int)((wb>>k)&1); w.Add(bit); if(bit==1){ if(z%3!=2){ok=false;break;} z=(2*z-1)/3; bo++; } else { z*=2; ee++; } }
    UInt128 Q=((UInt128)1<<(b+e))*p3[a-b]; if(!ok||bo!=b||ee!=e||z!=org||!(z>0&&z<r)||b>a||!(Q<M)){badW++;continue;}
    if(MinBudget(r,x,a)!=7) badMin++;
    byA[a]=byA.GetValueOrDefault(a)+1; if(r-org<minR)minR=r-org; if(M-Q<minG)minG=M-Q;
    var sh=Shape(x,w); shapes[sh]=shapes.GetValueOrDefault(sh)+1;
    if(sh=="6,1|3,0"){ off3++; all=new List<string>(); R=r; AA=a; All(x,x,0,0,new List<int>()); if(all.Any(t=>t!="6,1|3,0")) off3other++; } }
  Console.WriteLine($"rows {rows}; bad forward {badF}; bad word/conditions {badW}; minimum budget != 7: {badMin}");
  Console.WriteLine("by a: "+string.Join(" ",byA.OrderBy(k=>k.Key).Select(k=>k.Key+":"+k.Value)));
  Console.WriteLine($"min(r-m)={minR}; min(2^41-Q)={minG}; (6,1) offset-3 rows {off3}, of which have another passing shape: {off3other}");
  Console.WriteLine($"distinct shapes {shapes.Count}; last block not 1: {shapes.Keys.Count(k=>!k.Split('|')[0].EndsWith("1"))}; placement violations: "+shapes.Keys.Sum(k=>{var bl=k.Split('|')[0].Split(',').Select(int.Parse).ToArray(); var of=k.Split('|')[1].Split(',').Select(int.Parse).ToArray(); int v=0; for(int i=0;i<bl.Length;i++){int d=bl[i],o=of[i]; bool g=(d==1||d==3||d==5)?o==0: d==2?o==1: d==4?(o==1||o==2): d==6?(o>=1&&o<=3):false; if(!g)v++;} return v;}));
  // projectors
  var D=new BigInteger[101][]; for(int j=0;j<=100;j++) D[j]=new BigInteger[102]; for(int q=0;q<=100;q++) D[100][q]=1;
  for(int j=99;j>=41;j--) for(int q=0;q<=100;q++){ BigInteger t=0; for(int bb=0;bb<=1;bb++){ if(q+bb>100)continue; if(BigInteger.Pow(3,q+bb)>BigInteger.Pow(2,j+1)) t+=D[j+1][q+bb]; } D[j][q]=t; }
  BigInteger d7=0; foreach(var kv in byA) d7+=kv.Value*D[41][kv.Key];
  BigInteger d06=0; foreach(var ln in File.ReadLines(Path.Combine(args[0],"certificates.csv")).Skip(1)){ var f=ln.Split(','); d06+=D[41][int.Parse(f[2])]; }
  Console.WriteLine("d7(100) numerator "+d7+" ; budgets0-6 numerator "+d06);
 }}
