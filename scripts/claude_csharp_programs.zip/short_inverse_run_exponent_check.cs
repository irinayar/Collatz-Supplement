using System; using System.Numerics; using System.Collections.Generic;
using System.Linq;
// Global_Proof packet, short inverse-run theorem: complete run (s odd inputs, terminal exponent e>=2) from a to output b: a+1 = 2^s (2^(e-1) b + 1)/3^s.
// Claim: if a>=3, s<=11 and the optimized credit is zero then 2<=e<=7. Zero credit <=> NOT (15*3^s*(a-b) > (3^s-2^s)*b). Check exactly: for each s=1..11, e=2..16, all odd b<=BMAX with integral odd a>=3.
class P { static void Main(){ long BMAX=3000000; int[] emax=new int[12]; long cnt=0; var viol=new List<string>();
 for(int s=1;s<=11;s++){ BigInteger t3=BigInteger.Pow(3,s), t2=BigInteger.Pow(2,s);
  for(int e=2;e<=16;e++){ BigInteger p=BigInteger.One<<(e-1); long found=0;
   for(long b=1;b<=BMAX;b+=2){ BigInteger num=t2*(p*b+1); if(!(num%t3).IsZero) continue; BigInteger a1=num/t3; BigInteger a=a1-1; if(a<3||a.IsEven) continue;
     // verify the run: a -> s odd inputs with exponent 1 then exponent e gives b : check directly
     BigInteger x=a; bool ok=true; for(int i=0;i<s;i++){ if(x.IsEven){ok=false;break;} BigInteger y=3*x+1; int ee=0; while(y.IsEven){y>>=1;ee++;} if(i<s-1){ if(ee!=1){ok=false;break;} } else { if(ee!=e){ok=false;break;} } x=y; }
     if(!ok||x!=b) continue; found++; cnt++;
     bool pos = 15*t3*(a-b) > (t3-t2)*b; if(!pos){ if(e>emax[s]) emax[s]=e; if(e>7) viol.Add($"s={s} e={e} b={b} a={a}"); } }
  }}
 Console.WriteLine("runs checked: "+cnt+"; max e with zero credit per s=1..11: " + string.Join(" ", System.Linq.Enumerable.Range(1,11).Select(s=>$"s{s}:{emax[s]}")));
 Console.WriteLine("violations of e<=7: " + viol.Count + (viol.Count>0?" e.g. "+viol[0]:""));
 // mod 9 uniqueness for s>=2: 2^(e-1) b = -1 mod 9 has a unique solution e in 2..7 for each b coprime to 3
 int uniq=0; for(int b=1;b<9;b++){ if(b%3==0) continue; int c=0; for(int e=2;e<=7;e++){ if(((1<<(e-1))*b+1)%9==0) c++; } if(c==1) uniq++; } Console.WriteLine("b mod 9 (6 classes coprime to 3) with exactly one admissible e in 2..7: "+uniq);
}}
