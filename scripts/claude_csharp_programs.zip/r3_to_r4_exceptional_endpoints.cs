using System;
using System.Numerics;
// r=3 -> 4 for the endpoints outside ChatGPT's early-range condition (x<3(3/2)^3-3=7.125, x not mult of 3): x=4,5,7. Separation (max origin at r=4 < min origin at r=3) for k=0..40, own DFS.
class P {
  static int EM; static BigInteger[] mn,mx; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    foreach(int x in new[]{4,5,7}){ long ks=0,fails=0; BigInteger minGapRatioNum=0; string worst=""; double minRatio=1e9;
      for(int k=0;k<=40;k++){ EM=k; mn=new BigInteger[5]; mx=new BigInteger[5]; Dfs(x,0,0); if(mn[3]==0||mn[4]==0) continue; ks++; if(!(mx[4]<mn[3])) fails++; double ratio=(double)mn[3]/(double)mx[4]; if(ratio<minRatio){ minRatio=ratio; worst=$"k={k}"; } }
      Console.WriteLine($"x={x}: k with both counts feasible {ks} (k<=40); separation failures {fails}; smallest ratio min origin(r=3)/max origin(r=4) = {minRatio:F4} at {worst}"); }
  }
}
