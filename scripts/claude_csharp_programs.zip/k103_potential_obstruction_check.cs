using System;
using System.Numerics;
// Exact check of Codex K103: telescoping identity C(u)=F(u)/F(v)*(v+1)/(v+2^-e), F(u)=(u+1)/u; and the reciprocal-family obstruction table.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ if(b<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero) g=1; n=a/g; d=b/g; }
    public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Lt(Fr a,Fr b)=>a.n*b.d<b.n*a.d; public static bool Eq(Fr a,Fr b)=>a.n*b.d==b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static void Step(BigInteger u,out Fr c,out BigInteger v,out int s,out int e){ s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; e=V2(w); v=w>>e; c=new Fr(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    long bad=0,cases=0;
    for(long uu=3;uu<=100001;uu+=2){ BigInteger u=uu; Step(u,out var c,out var v,out int s,out int e); // identity: C = (u+1)/u * v/(v+1) * (v+1)/(v+2^-e) = (u+1)/u * v/(v+2^-e)
      Fr rhs=new Fr((u+1)*v*BigInteger.Pow(2,e), u*(v*BigInteger.Pow(2,e)+1)); cases++; if(!Fr.Eq(c,rhs)) bad++; }
    Console.WriteLine("telescoping identity C(u)=F(u)/F(v)*(v+1)/(v+2^-e), odd u<=100001: " + cases + " cases, mismatches " + bad);
    // single-transition constraints for F_c(u)=1+c/u : 1-b+c(a-1)<=0, a=2^(s+e)/3^s, b=(2/3)^s ; check 287->1093 and 311->263
    foreach(long uu in new long[]{287,311}){ Step(uu,out var c,out var v,out int s,out int e); Fr a=new Fr(BigInteger.Pow(2,s+e),BigInteger.Pow(3,s)); Fr b=new Fr(BigInteger.Pow(2,s),BigInteger.Pow(3,s)); Console.WriteLine($"u={uu}->{v}: s={s}, e={e}, a={a}, b={b}; condition 1-b+c(a-1)<=0 gives c {(Fr.Lt(new Fr(1,1),a)?"<=":">=")} {new Fr(-(b.d-b.n)*a.d,b.d*(a.n-a.d))}"); }
    foreach(int L in new[]{1,2,4}){ Fr lower=new Fr(-1000000000,1), upper=new Fr(1000000000,1); int elig=0; bool haveL=false, haveU=false; long wl=0,wu=0;
      for(long u0=257;u0<=1023;u0+=2){ BigInteger u=u0; Fr G=new Fr(1,1); bool ok=true; BigInteger cur=u; for(int i=0;i<L;i++){ Step(cur,out var c,out var v,out _,out _); G=G*c; cur=v; if(cur<=255){ ok=false; break; } }
        if(!ok) continue; elig++; BigInteger vv=cur; Fr a=new Fr(G.n*u,G.d*vv); // a = G u / v ; need (a v - u) + c (a-1) <= 0, a v - u = u(G-1)
        Fr avu=new Fr(u*(G.n-G.d),G.d); Fr am1=new Fr(a.n-a.d,a.d);
        if(Fr.Lt(am1,new Fr(0,1))){ Fr lb=new Fr(avu.n*am1.d, avu.d*(-am1.n)); if(!haveL||Fr.Lt(lower,lb)){ lower=lb; haveL=true; wl=u0; } } // c >= avu/(1-a)
        else if(Fr.Lt(new Fr(0,1),am1)){ Fr ub=new Fr(-avu.n*am1.d, avu.d*am1.n); if(!haveU||Fr.Lt(ub,upper)){ upper=ub; haveU=true; wu=u0; } } }
      Console.WriteLine($"block length {L}: eligible starts {elig}; necessary c lower bound {lower} (start {wl}), upper bound {upper} (start {wu}); incompatible: {Fr.Lt(upper,lower)}");
    }
    Console.WriteLine("Codex table: L=1: 5 / -211/13; L=2: 4591/139 / -439/13; L=4: 3049555/7153 / -359051/6487; eligible 253, 166, 77");
  }
}
