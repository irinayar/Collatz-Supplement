using System; using System.Numerics; using System.Collections.Generic;
class P { static void Main(){
  int G0=4,G1=705; var pt=new List<(int g,BigInteger num,BigInteger den)>();
  for(int g=G0;g<=G1;g++){ var t=BigInteger.Pow(3,g); int k=(int)(t.GetBitLength()-1); pt.Add((g,t,BigInteger.One<<k)); } // t/2^k in [1,2)
  int best=0,bg=0; int ties=0;
  foreach(var i in pt){ int c=0; foreach(var j in pt){ BigInteger num=j.num*i.den, den=j.den*i.num; if(num<den) num*=2; // r in [1,2)
        if(3*num<4*den) c++; else if(3*num==4*den) ties++; }
    if(c>best){best=c;bg=i.g;} }
  Console.WriteLine($"points {pt.Count}; max number in an open arc of length log2(4/3): {best} (first attained starting at g={bg}); exact endpoint coincidences seen {ties}");
  // depth bound arithmetic
  Console.WriteLine($"3^63<2^100: {BigInteger.Pow(3,63)<(BigInteger.One<<100)}; (4/3)^12<2^5: {BigInteger.Pow(4,12)<32*BigInteger.Pow(3,12)}; 76229/108 = {76229.0/108}");
}}
