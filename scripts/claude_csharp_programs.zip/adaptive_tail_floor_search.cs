using System;
using System.Numerics;
// Using ChatGPT's own certified expression U^bd_J (17) (exact recurrence counts, band tail 1089/2^23 beyond 512): find the smallest floor J for which U^bd_J < ln(3/2) (G<3/2 via G<=exp(sum)) and < 1/3 (via e^t<1/(1-t)) etc.
class P {
  static void Main(){
    int MAXL=520; var tot=new BigInteger[MAXL+2]; var prev=new BigInteger[MAXL+3]; prev[1]=1; tot[1]=1;
    for(int j=2;j<=MAXL;j++){ var cur=new BigInteger[MAXL+3]; for(int r=1;r<=j;r++){ if(BigInteger.Pow(3,r+1)>(BigInteger.One<<j)){ BigInteger a=prev[r]; if(r>=1) a+=prev[r-1]; cur[r]=a; } } prev=cur; BigInteger s=0; for(int r=0;r<=j;r++) s+=cur[r]; tot[j]=s; }
    double[] termL=new double[MAXL]; for(int l=1;l<=511;l++) termL[l]=Math.Exp(BigInteger.Log(tot[l+1])-l*Math.Log(2))*(2.0*l+7)/3;
    double target=Math.Log(1.5); int jLn=-1, jThird=-1, j13=-1; Console.WriteLine($"ln(3/2)={target:F6}");
    foreach(int J in new[]{16,20,24,28,32,40,48,64,80,96,112,128,144,160,172,173}){ double U=4.0*(J+2)/(3*Math.Pow(2,J)); for(int l=J;l<=511;l++) U+=termL[l]; U+=1089.0/Math.Pow(2,23); Console.WriteLine($"J={J}: U^bd_J = {U:F6}"); }
    for(int J=12;J<=200;J++){ double U=4.0*(J+2)/(3*Math.Pow(2,J)); for(int l=J;l<=511;l++) U+=termL[l]; U+=1089.0/Math.Pow(2,23); if(jLn<0&&U<target) jLn=J; if(jThird<0&&U<1.0/3) jThird=J; if(j13<0&&U<0.26) j13=J; }
    Console.WriteLine($"smallest J with U^bd_J < ln(3/2): {jLn}; < 1/3: {jThird}; < 13/50: {j13}");
    // also: how large is the constant tail 1089/2^23? and what if the band tail beyond 512 used a true recurrence sum (just the 1089/2^23 term is 1.3e-4)
    Console.WriteLine($"tail const 1089/2^23 = {1089.0/Math.Pow(2,23):E3}");
  }
}
