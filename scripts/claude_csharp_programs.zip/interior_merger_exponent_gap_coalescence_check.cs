using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Replay: exponent-gap theorem (table + brute force), interior-merger family, 31-core fixture geometry (ChatGPT 17:50 / 18:02, 2026-11-23).
class P {
 static BigInteger P2(int k)=>BigInteger.One<<k; static BigInteger P3(int k)=>BigInteger.Pow(3,k);
 static int V2(BigInteger x){ int c=0; while(x%2==0){x>>=1;c++;} return c; }
 // follow odd-transition exponents from odd x for the given list; returns end and records odd inputs
 static BigInteger Apply(BigInteger x,int[] ex,List<BigInteger> odds,out bool ok){ ok=true; foreach(int e in ex){ odds?.Add(x); BigInteger t=3*x+1; if(V2(t)!=e){ok=false;} x=t>>e; } return x; }
 // orbit from odd x until it returns to [n,H]; returns exponent list, odd inputs (excluding the source)
 static (List<int> ex,List<BigInteger> odds,BigInteger end) Return(BigInteger x,BigInteger n,BigInteger H){ var ex=new List<int>(); var odds=new List<BigInteger>(); BigInteger cur=x; while(true){ odds.Add(cur); BigInteger t=3*cur+1; int e=V2(t); ex.Add(e); cur=t>>e; if(cur>=n&&cur<=H) break; if(ex.Count>5000) break; } return (ex,odds,cur); }
 // complete runs of an exponent list: (s,e) pairs
 static List<(int s,int e)> Runs(IEnumerable<int> ex){ var r=new List<(int,int)>(); int s=0; foreach(int e in ex){ s++; if(e>=2){ r.Add((s,e)); s=0; } } return r; }
 static void Main(){
  // ---- A: table (8)
  BigInteger n0=P2(71)+1, H0=(4*n0-2)/3; Console.Write("min length difference l for s=1..8 at n=2^71+1: ");
  for(int s=1;s<=8;s++){ int ds=2*(int)BigInteger.Pow(3,s-1); int l=1; while(!(n0*P2(ds+l)<(H0+1)*P3(l))) l++; Console.Write("("+s+":d="+ds+",l="+l+",longer>="+(s+l)+") "); } Console.WriteLine();
  // brute force of Theorem 2 on small bands
  long pairs=0,bad=0; for(int n=3;n<=1501;n+=2){ BigInteger N=n, H=(4*N-2)/3; var byOut=new Dictionary<BigInteger,List<(BigInteger a,int s,int e)>>();
    for(BigInteger a=N+((N%2==0)?1:0); a<=H; a+=2){ int s=V2(a+1); BigInteger K=P3(s)*((a+1)>>s); BigInteger Km=K-1; if(Km==0) continue; int e=V2(Km)+1; if(e<2) continue; BigInteger b=Km>>(e-1); if(b%2==0) continue; if(!byOut.ContainsKey(b)) byOut[b]=new List<(BigInteger,int,int)>(); byOut[b].Add((a,s,e)); }
    foreach(var kv in byOut){ var l=kv.Value; for(int i=0;i<l.Count;i++) for(int j=i+1;j<l.Count;j++){ pairs++; var p=l[i]; var q=l[j]; if(p.s>q.s||(p.s==q.s&&p.e>q.e)){var tmp=p;p=q;q=tmp;} // p shorter
          bool ok = (p.s!=q.s) && q.e>p.e && (q.e-p.e)>=2*(int)BigInteger.Pow(3,p.s-1) && (N*P2(2*(int)BigInteger.Pow(3,p.s-1)+(q.s-p.s))<(H+1)*P3(q.s-p.s)); if(!ok) bad++; } } }
  Console.WriteLine("Theorem 2 brute force: collisions in bands of odd n<=1501 with two distinct runs into one output: "+pairs+", violating (7),(8): "+bad);
  // ---- C: interior-merger family
  int[] A={1,2,1,1,1,3,1,2}, B={1,1,2}, V={1,2,1,2,3};
  var tests=new List<BigInteger>{0,1,2,3,7,100,123456789,BigInteger.Parse("750300000000000000")}; // last chosen so n is large
  BigInteger big=(BigInteger.Parse("2392312122059241105199")-118639)/3188646; Console.WriteLine("t for the claimed control n=2392312122059241105199: "+big+" integer: "+((BigInteger.Parse("2392312122059241105199")-118639)%3188646==0));
  tests.Add(big); int allOk=0;
  foreach(var t in tests){ BigInteger u=156059+4194304*t, v=148135+3981312*t, y=249979+6718464*t, w=118643+3188646*t, n=w-4, H=158184+4251528*t; bool Hok=(H==(4*n-2)/3);
    var oa=new List<BigInteger>(); var xa=Apply(u,A,oa,out bool okA); var oa2=new List<BigInteger>(); var wa=Apply(xa,V,oa2,out bool okAV); var ob=new List<BigInteger>(); var xb=Apply(v,B,ob,out bool okB); var ob2=new List<BigInteger>(); var wb=Apply(xb,V,ob2,out bool okBV);
    bool band=u>=n&&u<=H&&v>=n&&v<=H&&w>=n&&w<=H; bool above=oa.Skip(1).Concat(oa2).Concat(ob.Skip(1)).Concat(ob2).All(s=>s>H);
    bool least=(w-2*P3(13)<n)&&(w-2*P3(8)<n); bool ok=Hok&&okA&&okAV&&okB&&okBV&&xa==y&&xb==y&&wa==w&&wb==w&&n%2==1&&band&&above&&least; if(ok) allOk++;
    if(t<=3||t==big) Console.WriteLine("t="+t+": n odd="+(n%2==1)+" H ok="+Hok+" words exact "+(okA&&okAV&&okB&&okBV)+" reach y,w "+(xa==y&&xb==y&&wa==w&&wb==w)+" band "+band+" proper states>H "+above+" least-source "+least+(t==big?" n>2075*2^60: "+(n>2075*P2(60)):"")); }
  Console.WriteLine("family checks passed for "+allOk+"/"+tests.Count+" parameters");
  // phases and credits
  Func<int[],BigInteger[]> Ph=(ex)=>{ BigInteger num=0,den=1; BigInteger E=0; // Q = sum_j 2^{E_j}/3^{j+1}
      BigInteger q_n=0, q_d=1; int Ej=0; for(int j=0;j<ex.Length;j++){ BigInteger tn=P2(Ej), td=P3(j+1); q_n=q_n*td+tn*q_d; q_d=q_d*td; Ej+=ex[j]; var g=BigInteger.GreatestCommonDivisor(q_n,q_d); q_n/=g; q_d/=g; } return new[]{q_n,q_d}; };
  var qav=Ph(A.Concat(V).ToArray()); var qbv=Ph(B.Concat(V).ToArray()); Console.WriteLine("Q_AV = "+qav[0]+"/"+qav[1]+" (claimed 3951679/1594323), Q_BV = "+qbv[0]+"/"+qbv[1]+" (claimed 9721/6561)");
  // incoming runs have zero credit: lambda <= (1+beta/a)(1+beta/15) (check via 15*3^s*a <= (16*3^s-2^s)*b  <=> credit zero)
  BigInteger tt=0; { BigInteger u=156059, v=148135; bool z=true; foreach(var (src,ex) in new[]{(u,A.Take(2).ToArray()),(BigInteger.Zero,new int[0])}){}
    BigInteger x=u; int pos=0; foreach(var (s,e) in Runs(A)){ var seg=A.Skip(pos).Take(s).ToArray(); var os=new List<BigInteger>(); var xe=Apply(x,seg,os,out bool o); if(15*P3(s)*x>(16*P3(s)-P2(s))*xe) z=false; x=xe; pos+=s; if(x==249979) break; }
    x=v; pos=0; foreach(var (s,e) in Runs(B)){ var seg=B.Skip(pos).Take(s).ToArray(); var os=new List<BigInteger>(); var xe=Apply(x,seg,os,out bool o); if(15*P3(s)*x>(16*P3(s)-P2(s))*xe) z=false; x=xe; pos+=s; }
    Console.WriteLine("incoming runs of both prefixes ((2,2),(4,3),(2,2) and (3,2)) have zero credit at t=0: "+z+"; run types A: "+string.Join(" ",Runs(A).Select(r=>"("+r.s+","+r.e+")"))+" B: "+string.Join(" ",Runs(B).Select(r=>"("+r.s+","+r.e+")"))); }
  // small example 411, 391 -> 661
  { var o1=new List<BigInteger>(); var x1=Apply(411,new[]{1,2,1,1,1,3,1,2},o1,out bool k1); var o2=new List<BigInteger>(); var x2=Apply(391,new[]{1,1,2},o2,out bool k2); Console.WriteLine("411 -> "+x1+" ("+k1+"), 391 -> "+x2+" ("+k2+"); odd inputs of 411 path: "+string.Join(",",o1)+"; of 391: "+string.Join(",",o2)); }
  // ---- D: 31-core fixture geometry
  { BigInteger n=BigInteger.Parse("379283455055006348091611351977328444642239"); BigInteger H=(4*n-2)/3; BigInteger u=BigInteger.Parse("505711273406675130788815135969771259522983"), v=BigInteger.Parse("473569587534005792343618380642931659580735"), y=BigInteger.Parse("758566910110012696183222703954656889284475"), w=BigInteger.Parse("435233337021757997534559614113553093329423");
    Console.WriteLine("H matches claimed: "+(H==BigInteger.Parse("505711273406675130788815135969771259522984"))+"; u=H-1: "+(u==H-1)+"; n bits "+n.GetBitLength());
    var ru=Return(u,n,H); var rv=Return(v,n,H); Console.WriteLine("u: odd transitions "+ru.ex.Count+", E="+ru.ex.Sum()+" (claimed 174, 276), ends at w: "+(ru.end==w)+", proper states>H: "+ru.odds.Skip(1).All(s=>s>H)); Console.WriteLine("v: odd transitions "+rv.ex.Count+", E="+rv.ex.Sum()+" (claimed 181, 287), ends at w: "+(rv.end==w)+", proper states>H: "+rv.odds.Skip(1).All(s=>s>H));
    Console.WriteLine("v word prefix: "+string.Join(",",rv.ex.Take(9))+" (claimed 1,1,1,1,1,3,1,3,...); u word starts: "+string.Join(",",ru.ex.Take(3)));
    int iu=ru.odds.IndexOf(y), iv=rv.odds.IndexOf(y); Console.WriteLine("y is an odd input of u at index "+iu+" and of v at index "+iv+" (claimed 1 and 8 odd transitions); tails equal after y: "+(iu>=0&&iv>=0&&ru.ex.Skip(iu).SequenceEqual(rv.ex.Skip(iv))));
    // complete runs after y, shared
    var runsTail=Runs(ru.ex.Skip(iu)); Console.WriteLine("complete runs from y to the end (shared by both): "+runsTail.Count+" (the last may be a partial run if the final exponent is 1: "+(ru.ex.Last()>=2)+"); the 31 shared core runs are a subset");
    // full-word least-source residues
    foreach(var (name,src,ex) in new[]{("u",u,ru.ex),("v",v,rv.ex)}){ int g=ex.Count, E=ex.Sum(); BigInteger C=0; int Ei=0; for(int i=0;i<g;i++){ C+=P3(g-1-i)*P2(Ei); Ei+=ex[i]; } BigInteger M=P2(E+1); BigInteger inv=BigInteger.ModPow(P3(g),M/2-1,M); BigInteger a=(((P2(E)-C)%M+M)%M*inv)%M; // ModPow exponent phi(2^(E+1))-1 = 2^E-1
      BigInteger phi=M/2; inv=BigInteger.ModPow(P3(g),phi-1,M); a=(((P2(E)-C)%M+M)%M*inv)%M; Console.WriteLine(name+": full-word residue equals source: "+(a==src)+"; a-2^(E+1)<n: "+(src-M<n)+", a+2^(E+1)>H: "+(src+M>H)+"; 2^E x end check: "+(P2(E)*w==P3(g)*src+C)); }
    // transfer consequence: canonical horizon implies 2^(E+1) > 2H for these words
    Console.WriteLine("2^(E+1) > 2H for u: "+(P2(277)>2*H)+" and for v: "+(P2(288)>2*H)); }
 }}
