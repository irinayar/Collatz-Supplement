using System;
using System.Numerics;
// Check of ChatGPT 134158: valuation classification of two-even words 1^i 0 1^j 0 1^k and the bound r <= a+d+v3(2^(d+1)(D/3^d)-1).
class P {
  static int V3(BigInteger n){ if(n<0) n=-n; int c=0; while(n%3==0){n/=3;c++;} return c; }
  static BigInteger B(long b,int e)=>BigInteger.Pow(b,e);
  static long Pw(long b,int e){long r=1; for(int i=0;i<e;i++) r*=b; return r;}
  static int V3l(long n){int c=0; while(n%3==0){n/=3;c++;} return c;}
  static long R(long x,int k){ int a=V3l(x+1); if(k==0) return a; long best=-1;
    for(int l=0;l<=a;l++){ long y=Pw(2,l)*(x+1)/Pw(3,l)-1; if(y<1) continue; long v=l+R(2*y,k-1); if(v>best) best=v; } return best; }
  static void Main(){
    long cases=0,bad=0,boundBad=0,maxEq=0,xs=0,strictLess=0;
    for(int x=1;x<=2000;x++){
      int a=V3(x+1); BigInteger u=(x+1)/B(3,a); BigInteger D=B(2,a+1)*u-1; int d=V3(D);
      BigInteger Dp=D/B(3,d); int bound=a+d+V3(B(2,d+1)*Dp-1);
      int maxr=-1;
      for(int r=0;r<=26;r++) for(int i=0;i<=r;i++) for(int j=0;i+j<=r;j++){ int k=r-i-j;
        BigInteger N=B(2,r+2)*(x+1)-B(2,i)*B(3,k)*(B(3,j)+B(2,j+1));
        bool act = N%B(3,r)==0;
        bool pred;
        if(j>=1) pred = (k==a) && (i+j <= V3(B(2,j+1)*D-B(3,j)));
        else pred = (a>=r && i<=1) || (a<r && a==k+1 && i-1<=d);
        if(r<=14){ cases++; if(act!=pred) bad++; }
        if(act){ if(r>maxr) maxr=r; if(r>bound) boundBad++; } }
      xs++; if(maxr==bound) maxEq++; else strictLess++;
      if(maxr!=R(x,2)) bad+=1000000; }
    Console.WriteLine($"classification cases (r<=14, x<=2000): {cases}; classification/R2 failures {bad}; bound violations {boundBad}; endpoints with max r == bound: {maxEq}/{xs}, bound strictly above max: {strictLess}");
  }
}
