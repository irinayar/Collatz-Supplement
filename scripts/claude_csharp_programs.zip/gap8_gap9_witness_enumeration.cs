using System;
using System.Collections.Generic;
using System.Numerics;
// Independent integer-witness enumeration of gap-g first-return profiles (g=8,9): for each exponent tuple (1,e2..e_{g-1},e_g>=2) with total E (g=8: E=13; g=9: E=14),
// residue u0 mod 2^(E+1); for u=u0+M t (t<=T) compute v_j, and the odd threshold range n in [lo,hi]: lo=max(3,ceil((3max(u,w)+2)/4)), hi=min(u,w,min_j floor((3v_j+1)/4)).
// A tuple 'has a witness' if some t gives an odd n in [lo,hi]. Compare with Codex K140/K141 / ChatGPT: 85 (g=8) and 113 (g=9).
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Tuples(int len,int E,List<int[]> outL){ var cur=new int[len]; void Rec(int p,int s){ if(p==len){ if(s==E&&cur[len-1]>=2) outL.Add((int[])cur.Clone()); return; } for(int v=1;v<=E-s;v++){ if(p==0&&v!=1) continue; cur[p]=v; Rec(p+1,s+v); } } Rec(0,0); }
  static long Residue(int[] ev,long mod){ for(long r=1;r<mod;r+=2){ long x=r; bool ok=true; for(int i=0;i<ev.Length;i++){ int e; x=A(x,out e); if(e!=ev[i]){ok=false;break;} } if(ok) return r; } return -1; }
  static void Run(int g,int E,long T){
    var tup=new List<int[]>(); Tuples(g,E,tup); long M=1L<<(E+1); int withW=0; long maxFirstU=0; long sumB=0; var firstRows=new List<string>();
    foreach(var ev in tup){ long r=Residue(ev,M); bool found=false; long fu=0;
      for(long t=0;t<=T && !found;t++){ long u=r+M*t; long x=u; long lo=3, hi=u; long[] v=new long[g+1]; v[0]=u; bool ok=true; for(int j=1;j<=g;j++){ int e; x=A(x,out e); if(e!=ev[j-1]){ok=false;break;} v[j]=x; }
        if(!ok) continue; long w=v[g]; long mx=Math.Max(u,w); lo=Math.Max(3,(3*mx+2+3)/4); hi=Math.Min(u,w); for(int j=1;j<g;j++) hi=Math.Min(hi,(3*v[j]+1)/4);
        if((lo&1)==0) lo++; if(lo<=hi){ found=true; fu=u; } }
      if(found){ withW++; if(fu>maxFirstU) maxFirstU=fu; long Bq=0; int Eq=0; foreach(int vv in ev){ Bq=3*Bq+(1L<<Eq); Eq+=vv; } sumB+=Bq; } }
    Console.WriteLine($"gap {g}, E={E}: tuples {tup.Count}; tuples with an integer first-return witness for u=r+{M}t, t<={T}: {withW}; largest least-witness u = {maxFirstU}; sum of B over retained = {sumB}; sum c(p)=sum(B+5(2^E-3^g))/3^g = {(sumB+(long)withW*5*((1L<<E)-(long)Math.Pow(3,g)))}/{(long)Math.Pow(3,g)} ");
  }
  static void Main(){ Run(8,13,3000); Run(9,14,1500); }
}
