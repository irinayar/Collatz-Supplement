using System;
using System.Numerics;
// Independent check of Codex 133324 (one-even / all-odd prefix theorem) and ChatGPT 133741 (two-even formula, height bound).
// For every endpoint x<=300, r<=12, e<=4 and EVERY placement of e even steps among r+e positions: brute-force origin m=(2^L x - V)/3^r from odd-position sum,
// test integrality, positivity, and confirm by forward simulation that m realises the word. Compare with closed forms.
class P {
  static BigInteger V(int[] w){ int r=0; foreach(var s in w) r+=s; BigInteger v=0; int h=0; for(int i=0;i<w.Length;i++) if(w[i]==1){ v+=BigInteger.Pow(2,i)*BigInteger.Pow(3,r-1-h); h++; } return v; }
  static int V3(BigInteger n){ int c=0; while(n%3==0){n/=3;c++;} return c; }
  static void Main(){
    long cases=0, bad=0, heightViol=0, e0=0,e1=0,e2=0, ident=0;
    for(int x=1;x<=300;x++) for(int r=0;r<=12;r++) for(int e=0;e<=4;e++){
      int L=r+e; if(L>16) continue;
      int a=V3(x+1); BigInteger D=BigInteger.Pow(2,a+1)*((x+1)/BigInteger.Pow(3,a))-1;
      int cnt=0; var found=new System.Collections.Generic.List<(int[],BigInteger)>();
      for(int mask=0;mask<(1<<L);mask++){ if(BitOperations.PopCount((uint)mask)!=e) continue; // mask bit = even step
        var w=new int[L]; for(int i=0;i<L;i++) w[i]=((mask>>i)&1)==1?0:1;
        BigInteger num=BigInteger.Pow(2,L)*x-V(w); BigInteger den=BigInteger.Pow(3,r);
        if(num%den!=0) continue; BigInteger m=num/den; if(m<1) continue;
        // forward simulation
        BigInteger y=m; bool ok=true; for(int i=0;i<L;i++){ bool odd=!y.IsEven; if(odd!=(w[i]==1)){ok=false;break;} y= odd? (3*y+1)/2 : y/2; }
        cases++; if(!ok||y!=x) bad++;
        found.Add((w,m)); }
      if(found.Count>0 && BigInteger.Pow(3,r) > BigInteger.Pow(2,e)*x*BigInteger.Pow(2,r)) heightViol++; // (3/2)^r <= 2^e x must hold
      if(e==0){ e0++; bool pred = r<=a; BigInteger m0=BigInteger.Pow(2,r)*(x+1)/BigInteger.Pow(3,r)-1; bool exp = pred && m0>=1;
        if(exp!=(found.Count==1) || (exp&&found.Count==1&&found[0].Item2!=m0) || found.Count>1) bad++; }
      if(e==1){ e1++; bool pred; BigInteger mm=0;
        if(r<=a){ pred=true; mm=BigInteger.Pow(2,r+1)*(x+1)/BigInteger.Pow(3,r)-2; }
        else { int i=r-a; pred = V3(D)>=i; if(pred) mm=BigInteger.Pow(2,i)*(D/BigInteger.Pow(3,i))-1; }
        bool exp=pred&&mm>=1; if(exp!=(found.Count==1)||(exp&&found[0].Item2!=mm)||found.Count>1) bad++;
        if(found.Count>0 && r> a+V3(D)) bad++; }
      if(e==2){ e2++; var set=new System.Collections.Generic.List<BigInteger>();
        for(int i=0;i<=r;i++) for(int j=0;i+j<=r;j++){ int k=r-i-j;
          BigInteger t=BigInteger.Pow(2,r+2)*(x+1)-BigInteger.Pow(2,i)*BigInteger.Pow(3,j+k)-BigInteger.Pow(2,i+j+1)*BigInteger.Pow(3,k);
          if(t%BigInteger.Pow(3,r)!=0) continue; BigInteger m=(BigInteger.Pow(2,r+2)*x-(BigInteger.Pow(3,r)-BigInteger.Pow(2,r+2)+BigInteger.Pow(2,i)*BigInteger.Pow(3,j+k)+BigInteger.Pow(2,i+j+1)*BigInteger.Pow(3,k)))/BigInteger.Pow(3,r);
          if(m>=1) set.Add(m); }
        // compare multiset of origins
        var f2=new System.Collections.Generic.List<BigInteger>(); foreach(var t in found) f2.Add(t.Item2); f2.Sort(); set.Sort();
        if(f2.Count!=set.Count) bad++; else for(int q=0;q<f2.Count;q++) if(f2[q]!=set[q]) bad++; }
    }
    // identity V(i,j,k) vs odd-position sum
    for(int r=0;r<=15;r++) for(int i=0;i<=r;i++) for(int j=0;i+j<=r;j++){ int k=r-i-j; var w=new System.Collections.Generic.List<int>(); for(int t=0;t<i;t++) w.Add(1); w.Add(0); for(int t=0;t<j;t++) w.Add(1); w.Add(0); for(int t=0;t<k;t++) w.Add(1);
      BigInteger f=BigInteger.Pow(3,r)-BigInteger.Pow(2,r+2)+BigInteger.Pow(2,i)*BigInteger.Pow(3,j+k)+BigInteger.Pow(2,i+j+1)*BigInteger.Pow(3,k); ident++; if(f!=V(w.ToArray())) bad++; }
    Console.WriteLine($"positive-origin word cases {cases}, e=0 cells {e0}, e=1 cells {e1}, e=2 cells {e2}, two-even V identities {ident}, height-bound violations {heightViol}, failures {bad}");
  }
}
