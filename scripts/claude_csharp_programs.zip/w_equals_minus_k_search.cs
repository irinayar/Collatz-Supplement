using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
// Search for closed words of the full-circle picture in which EVERY excursion is of type (P_R, V_L):
//   a_i + p_i > c + H   and   3 b_i / 2 < c + H     (exact big-integer test)
// The word is prod 1^{r_i} 0^{d_i}; DFS over (r_i,d_i) with a log-height pruning (window width Wd on the peaks).
static class P {
  static void BaselineRun(int Lb) { double sum = 0; long n = 0, ng = 0; long[] h = new long[60], o = new long[60]; for (int L = 4; L <= Lb; L++) for (long w = 1; w < (1L << L) - 1; w++) { bool canon = true; for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; } if (!canon) continue; int A = System.Numerics.BitOperations.PopCount((ulong)w); long p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; long p2 = 1L << L; if (p3 >= p2) continue; long D = p2 - p3; long U = 0; for (int i = 0; i < L; i++) if (((w >> i) & 1) == 1) U = 3 * U + (1L << i); long a = U, b = D; while (b != 0) { long t = a % b; a = b; b = t; } n++; sum += Math.Log(a) / Math.Log(D == 1 ? 2 : D); if (a > 1) ng++; for (int ip = 0; ip < smallPr.Length; ip++) if (D % smallPr[ip] == 0) { o[ip]++; if (U % smallPr[ip] == 0) h[ip]++; } } Console.WriteLine($"BASELINE (all words L<={Lb}, 3^A<2^L): words {n}, mean log_D gcd {sum / n:F4}, gcd>1: {ng}"); for (int ip = 0; ip < smallPr.Length; ip++) Console.WriteLine($"  prime {smallPr[ip]}: observed {(o[ip] > 0 ? (double)h[ip] / o[ip] : 0):F3} over {o[ip]}"); }
  static int Lmax, Rmax = 10, Dmax = 8; static double Wd; static double TH = Math.Log2(1.5);
  static List<int> R = new(), Dd = new();
  static long cand = 0, found = 0, foundG = 0; static SortedDictionary<(int, bool), long> byK = new();
  static Dictionary<string, string> examples = new();
  static SortedDictionary<(int,int),long> typ = new(); static SortedDictionary<int,int> maxKL = new(); static SortedDictionary<int,long> cntL = new(); static SortedDictionary<int,double> minDepth = new(); static long intFound = 0; static double sumFrac = 0; static long nFlat = 0, nG1 = 0; static long[] hit = new long[60], opp = new long[60]; static int[] smallPr = {5,7,11,13,17,19,23,29,31,37,41,43,47,53}; static List<string> intList = new(); static int bestK = 0; static string bestWord = "";
  static void Main(string[] args) {
    Lmax = int.Parse(args[0]); Wd = double.Parse(args[1]); if (args.Length > 2) Rmax = int.Parse(args[2]); if (args.Length > 3) Dmax = int.Parse(args[3]);
    Dfs(0, 0, 0.0, 0.0, 0.0, 0);
    Console.WriteLine($"FLAT gcd stats: words {nFlat}, mean log_D(gcd(U,D)) {sumFrac / Math.Max(1, nFlat):F4}, words with gcd>1: {nG1}"); for (int ip = 0; ip < smallPr.Length; ip++) Console.WriteLine($"  prime {smallPr[ip]}: D divisible in {opp[ip]} words, q divides U in {hit[ip]} (expected fraction {1.0 / smallPr[ip]:F3}, observed {(opp[ip] > 0 ? (double)hit[ip] / opp[ip] : 0):F3})"); BaselineRun(22); Console.WriteLine("flat words (values>=1) by L: " + string.Join(" ", cntL.Select(t => $"{t.Key}:{t.Value}"))); Console.WriteLine("min log2(H/c) by k: " + string.Join(" ", minDepth.Select(t => $"k{t.Key}:{t.Value:F3}"))); Console.WriteLine($"integer fixed points among flat words: {intFound} " + string.Join("; ", intList)); Console.WriteLine($"candidates tested {cand}; words with all excursions (P_R,V_L): {found} (values>=1: {foundG})");
    foreach (var kv in byK) Console.WriteLine($"  k={kv.Key.Item1} values>=1={kv.Key.Item2}: {kv.Value}");
    foreach (var kv in examples) Console.WriteLine(kv.Key + " : " + kv.Value); Console.WriteLine("types (r,d) in values>=1 words: " + string.Join(" ", typ.Where(t => t.Value > 0).Select(t => $"({t.Key.Item1},{t.Key.Item2}):{t.Value}"))); Console.WriteLine("max k by L (values>=1): " + string.Join(" ", maxKL.Select(t => $"L{t.Key}:{t.Value}")));
  }
  // cur = ell of the last peak; mn, mx = min and max of peak heights so far
  static void Dfs(int L, int A, double cur, double mn, double mx, int k) {
    if (k >= 1) { // try to close the cycle with the current sequence
      if (Math.Pow(3, A) < Math.Pow(2, L) && L >= 3) Check(L, A);
    }
    for (int r = 1; r <= Rmax; r++) for (int d = 1; d <= Dmax; d++) {
      if (L + r + d > Lmax) break;
      double nc;
      if (k == 0) nc = 0.0; else nc = cur - Dd[k - 1] + r * TH;
      double nmn = Math.Min(mn, nc), nmx = Math.Max(mx, nc);
      if (k > 0 && nmx - nmn > Wd) continue;
      R.Add(r); Dd.Add(d);
      // the descent d_k enters the NEXT peak height; prune lazily in the next call
      Dfs(L + r + d, A + r, nc, nmn, nmx, k + 1);
      R.RemoveAt(R.Count - 1); Dd.RemoveAt(Dd.Count - 1);
    }
  }
  static bool Canonical(int k) {
    for (int s = 1; s < k; s++) {
      int cmp = 0;
      for (int i = 0; i < k && cmp == 0; i++) { int a = R[i], b = R[(i + s) % k]; if (a != b) cmp = a < b ? -1 : 1; else { a = Dd[i]; b = Dd[(i + s) % k]; if (a != b) cmp = a < b ? -1 : 1; } }
      if (cmp > 0) return false; if (cmp == 0) return false; // not minimal or periodic
    }
    return true;
  }
  static void Check(int L, int A) {
    int k = R.Count; if (!Canonical(k)) return; cand++;
    // wrap-around window check on the approximate heights (closing peak back to p_0 with the full cycle drift)
    var e = new bool[L]; int pos = 0; var aIdx = new int[k]; var bIdx = new int[k];
    for (int i = 0; i < k; i++) { for (int j = 0; j < R[i]; j++) e[pos++] = true; aIdx[i] = pos - 1; for (int j = 0; j < Dd[i]; j++) e[pos++] = false; bIdx[i] = pos - 1; }
    BigInteger p2 = BigInteger.One << L, p3 = BigInteger.Pow(3, A), D = p2 - p3, scale = D * p2, U = 0;
    for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + (BigInteger.One << i);
    var X = new BigInteger[L]; X[0] = U * p2;
    for (int i = 0; i + 1 < L; i++) { var t = e[i] ? 3 * X[i] + scale : X[i]; if (!t.IsEven) return; X[i + 1] = t / 2; }
    var last = e[L - 1] ? 3 * X[L - 1] + scale : X[L - 1]; if (last != 2 * X[0]) { Console.WriteLine("closure failure"); return; }
    if (X.Distinct().Count() < L) return;
    BigInteger c = X.Min(), H = X.Max(), S = c + H;
    for (int i = 0; i < k; i++) {
      int a = aIdx[i], p = (a + 1) % L, b = bIdx[i];
      var sum = X[a] + X[p]; if (sum <= S) return; // need strict P_R
      if (3 * X[b] >= 2 * S) return;              // need strict V_L
    }
    bool g1 = X.All(v => v >= scale); if (g1) { cntL[L] = cntL.GetValueOrDefault(L) + 1; double dep = Math.Log2((double)(H * 1000000 / c) / 1e6); if (!minDepth.ContainsKey(k) || dep < minDepth[k]) minDepth[k] = dep; { var gg = BigInteger.GreatestCommonDivisor(U, D); sumFrac += BigInteger.Log(gg, 2) / BigInteger.Log(D, 2); nFlat++; if (gg > 1) nG1++; for (int ip = 0; ip < smallPr.Length; ip++) if ((D % smallPr[ip]).IsZero) { opp[ip]++; if ((U % smallPr[ip]).IsZero) hit[ip]++; } } if ((U % D).IsZero) { intFound++; intList.Add($"L={L} A={A} k={k} x*={U / D}"); } } if (g1) { for (int i = 0; i < k; i++) typ[(R[i], Dd[i])] = typ.GetValueOrDefault((R[i], Dd[i])) + 1; maxKL[L] = Math.Max(maxKL.GetValueOrDefault(L), k); }
    found++; if (g1) foundG++;
    byK[(k, g1)] = byK.GetValueOrDefault((k, g1)) + 1;
    string key = $"example k={k} g1={g1}"; string w = string.Join(" ", Enumerable.Range(0, k).Select(i => $"({R[i]},{Dd[i]})")) + $" L={L} A={A}";
    if (!examples.ContainsKey(key) || w.Length > examples[key].Length) examples[key] = w;
  }
}
static class Dummy { }
