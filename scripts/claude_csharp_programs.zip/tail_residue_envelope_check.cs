using System;
using System.Collections.Generic;
using System.Numerics;
// ChatGPT 222306: tail-residue envelopes. (1) containment of exact origin extrema, a=0..6,b=1..6,z=3..44, j=1..3; (2) example AB (k,r,x)=(6,6,11).
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ if(b<0){a=-a;b=-b;} var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero) g=1; n=a/g; d=b/g; } public static Fr operator-(Fr a,Fr b)=>new Fr(a.n*b.d-b.n*a.d,a.d*b.d); public static bool Lt(Fr a,Fr b)=>a.n*b.d<b.n*a.d; public static bool Le(Fr a,Fr b)=>a.n*b.d<=b.n*a.d; public override string ToString()=>n+"/"+d; }
  static BigInteger[] mn,mx; static int EM; static void Dfs(BigInteger z,int ev,int od){ if(ev==EM&&od<mn.Length){ if(mn[od]==0||z<mn[od]) mn[od]=z; if(z>mx[od]) mx[od]=z; } if(ev<EM) Dfs(2*z,ev+1,od); if(od<mn.Length-1&&z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static bool Env(int a,int b,BigInteger z,int j,out Fr lo,out Fr hi){ Fr LO=new Fr(0,1), HI=new Fr(0,1); lo=LO; hi=HI; int L=a+b; bool any=false; BigInteger p3j=BigInteger.Pow(3,j), q3=BigInteger.Pow(3,b-j)-BigInteger.Pow(2,b-j), rhs=BigInteger.Pow(2,L)*z, den=BigInteger.Pow(3,b); int q=b-j;
    var t=new int[j]; bool Rec(int idx,int start){ if(idx==j){ BigInteger T=0; for(int i=0;i<j;i++) T+=BigInteger.Pow(3,j-1-i)*BigInteger.Pow(2,t[i]); if(!((T-rhs)%p3j).IsZero) return true; int p=t[0]; if(p<q) return true; var l=new Fr(rhs-T-p3j*BigInteger.Pow(2,p-q)*q3,den); var h=new Fr(rhs-T-p3j*q3,den); if(!any){ LO=l; HI=h; any=true; } else { if(Fr.Lt(l,LO)) LO=l; if(Fr.Lt(HI,h)) HI=h; } return true; } for(int s=start;s<L;s++){ t[idx]=s; Rec(idx+1,s+1); } return true; }
    Rec(0,0); lo=LO; hi=HI; return any; }
  static void Main(){
    long cases=0,bad=0,empty=0;
    for(int a=0;a<=6;a++) for(int b=1;b<=6;b++) for(int z=3;z<=44;z++){ EM=a; mn=new BigInteger[b+1]; mx=new BigInteger[b+1]; Dfs(z,0,0); if(mn[b]==0) continue;
        for(int j=1;j<=Math.Min(3,b);j++){ cases++; if(!Env(a,b,z,j,out var lo,out var hi)){ bad++; continue; } if(!(Fr.Le(lo,new Fr(mn[b],1))&&Fr.Le(new Fr(mx[b],1),hi))) bad++; } }
    Console.WriteLine($"(1) containment of exact origin extrema in the tail-residue envelope: {cases} cases (a<=6, b<=6, z=3..44, j=1..3), violations {bad}");
    int k=6,r=6; BigInteger x=11,y=7; EM=k-2; mn=new BigInteger[10]; mx=new BigInteger[10]; Dfs(4*x,0,0); var mxA=(BigInteger[])mx.Clone(); var mnA=(BigInteger[])mn.Clone(); EM=k; mn=new BigInteger[10]; mx=new BigInteger[10]; Dfs(y,0,0); var mnB=(BigInteger[])mn.Clone();
    Console.WriteLine($"(2) example AB (6,6,11): actual min B_6 = {mnB[r-1]}, max A_7 = {mxA[r+1]}, actual gap {mnB[r-1]-mxA[r+1]} (ChatGPT: 18)");
    for(int j=1;j<=3;j++){ Env(k,r-1,y,j,out var loB,out var hiB); Env(k-2,r+1,4*x,j,out var loA,out var hiA); Console.WriteLine($"   j={j}: lower(B_6) - upper(A_7) = {loB-hiA}"); }
  }
}
