using System;
using System.Numerics;
// Exact DP: distribution of U mod q over ALL indexed words with L letters and A ones (U = sum_{odd i} 2^i 3^{#odd after i}),
// for q | D = 2^L - 3^A, to compare with 1/q.
static class P {
  static void Main(string[] args) {
    foreach (int q in new[] { 5, 7, 11, 13 }) {
      Console.Write($"q={q}: ");
      for (int L = 16; L <= 40; L += 1) for (int A = 1; A < L; A++) {
        BigInteger D = BigInteger.Pow(2, L) - BigInteger.Pow(3, A); if (D <= 0 || (D % q) != 0) continue;
        var dp = new BigInteger[A + 1, q]; dp[0, 0] = 1; int[] pw2 = new int[L]; pw2[0] = 1 % q; for (int i = 1; i < L; i++) pw2[i] = pw2[i - 1] * 2 % q;
        for (int i = 0; i < L; i++) { var nd = new BigInteger[A + 1, q]; for (int a = 0; a <= A; a++) for (int r = 0; r < q; r++) { var v = dp[a, r]; if (v.IsZero) continue; nd[a, r] += v; if (a < A) nd[a + 1, (3 * r + pw2[i]) % q] += v; } dp = nd; }
        BigInteger tot = 0; for (int r = 0; r < q; r++) tot += dp[A, r]; double frac = (double)(dp[A, 0] * 100000 / tot) / 100000.0;
        if (L % 4 == 0 || q != 5) { if (L >= 24 && L <= 32 && A * 3 > L) Console.Write($"(L={L},A={A}): {frac:F4}  "); }
      }
      Console.WriteLine();
    }
  }
}
