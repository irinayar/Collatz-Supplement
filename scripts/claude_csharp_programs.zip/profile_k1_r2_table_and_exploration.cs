using System;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
// (1) Reproduce ChatGPT 124314 table: source valuations (1,1,2,1,1,2,1,3,1,1,1), n=61159+65536 t, t=0..8, profile (k+1,r+2)=(5,13): exact minimum origin by DP over all inverse words.
// (2) Exploration: for random odd n and L accelerated steps (all words), is the (k+1,r+2) layer nonempty only when n mod 9 in {2,4,8} (three-step ancestors 101,110,011)?
class P {
  static Dictionary<(int,int,BigInteger),(BigInteger,bool)> memo=new();
  static (BigInteger mn,bool ok) Min(int k,int b,BigInteger z){
    if(k<0||b<0) return (0,false); if(k==0&&b==0) return (z,true); var key=(k,b,z); if(memo.TryGetValue(key,out var v)) return v;
    bool ok=false; BigInteger mn=0;
    if(k>0){ var t=Min(k-1,b,2*z); if(t.ok){ok=true;mn=t.mn;} }
    if(b>0 && z%3==2){ var t=Min(k,b-1,(2*z-1)/3); if(t.ok){ if(!ok||t.mn<mn){mn=t.mn;} ok=true; } }
    memo[key]=(mn,ok); return (mn,ok); }
  static void Main(){
    int[] val={1,1,2,1,1,2,1,3,1,1,1};
    for(int t=0;t<9;t++){
      BigInteger n=61159+65536*t, u=n; int k=0,r=0;
      foreach(int e in val){ BigInteger y=3*u+1; int ee=0; while(y.IsEven){y/=2;ee++;} if(ee!=e) throw new Exception("valuation mismatch"); r++; k+=e-1; u=y; }
      memo.Clear(); var o=Min(k+1,r+2,u); Console.WriteLine($"t={t} n mod 9={(int)(n%9)} counts (k,r)=({k},{r}) z={u} min origin at ({k+1},{r+2}) = {(o.ok?o.mn.ToString():"none")}{(o.ok?$" (8n-c)/9 c={(8*n-o.mn*9)}":"")}");
    }
    var rng=new Random(2024); long tot=0; long[] byMod=new long[9], feasMod=new long[9]; long feasOther=0; long otherMinSmaller=0; var examples=new List<string>();
    for(int i=0;i<6000;i++){
      BigInteger n=1+2*rng.Next(1<<28); int L=4+rng.Next(11); BigInteger u=n; int k=0,r=0; for(int s=0;s<L;s++){ if(!u.IsEven){u=(3*u+1)/2;r++;} else {u/=2;k++;} }
      if(u<3||r==0) continue; memo.Clear(); var o=Min(k+1,r+2,u); int m9=(int)(n%9); tot++; byMod[m9]++; if(o.ok){ feasMod[m9]++; if(m9!=2&&m9!=4&&m9!=8){ feasOther++; if(o.mn<n) otherMinSmaller++; if(examples.Count<4) examples.Add($"n={n} L={L} (k,r)=({k},{r}) z={u} min={o.mn}"); } }
    }
    Console.WriteLine($"random sources {tot}; feasible (k+1,r+2) by n mod 9: "+string.Join(" ", Enumerable.Range(0,9).Select(m=>$"{m}:{feasMod[m]}/{byMod[m]}")));
    Console.WriteLine($"feasible with n mod 9 not in {{2,4,8}}: {feasOther} (of which min origin < n: {otherMinSmaller}); examples: {string.Join("; ",examples)}");
  }
}
