using System; using System.Numerics; using System.Collections.Generic; using System.Linq;
// Checks of First_Gate_Across_Depths (ChatGPT 2026-11-23 16:12): (1) (D3) forbidden depth differences, (2) (D5) 3 z_(i+22) >= 4 z_(i) for the 53 normalized powers of 3 (exact),
// (3) the high-floor collision: replay the two sources, first proper complete-run phase gate (phase > B), depth, valuation sum, state y, termination, proper states > H, distinctness, phases.
class P { static int FL2(BigInteger x){ return (int)x.GetBitLength()-1; }
 static int Cmp(BigInteger a,BigInteger b,BigInteger c,BigInteger d){ return (a*d).CompareTo(c*b); } // a/b vs c/d
 static void Main(){
  // (1) forbidden depth differences h in 1..100: no integer d with 3/4 < 2^d/3^h < 4/3  <=>  3*3^h < 4*2^d and 3*2^d < 4*3^h
  var forb=new List<int>(); for(int h=1;h<=100;h++){ BigInteger t=BigInteger.Pow(3,h); bool ok=false; for(int d=0; d<=200; d++){ BigInteger p=BigInteger.One<<d; if(3*t<4*p && 3*p<4*t){ok=true;break;} } if(!ok) forb.Add(h); }
  Console.WriteLine("forbidden depth differences up to 100: " + string.Join(",",forb));
  // (2) normalized powers: z_j = 3^j / 2^floor(log2 3^j) as fractions (num=3^j, den=2^fl), sort, circular
  int N=53; var z=new List<(BigInteger n,BigInteger d)>(); for(int j=0;j<N;j++){ BigInteger t=BigInteger.Pow(3,j); z.Add((t,BigInteger.One<<FL2(t))); }
  z.Sort((a,b)=>(a.n*b.d).CompareTo(b.n*a.d)); bool allok=true; for(int i=0;i<N;i++){ int k=i+22; (BigInteger n,BigInteger d) zk = k<N ? z[k] : (z[k-N].n*2, z[k-N].d); // z_(i+22) with wrap factor 2
    // 3*z_(i+22) >= 4*z_(i): 3*zk.n/zk.d >= 4*z[i].n/z[i].d
    if(!( (3*zk.n*z[i].d) >= (4*z[i].n*zk.d) )) allok=false; }
  Console.WriteLine("(D5) 3 z_(i+22) >= 4 z_(i) for all i=0..52: " + allok);
  // also check 21 fails somewhere (sharpness): exists i with 3 z_(i+21) < 4 z_(i)
  bool sharp=false; for(int i=0;i<N;i++){ int k=i+21; (BigInteger n,BigInteger d) zk = k<N ? z[k] : (z[k-N].n*2, z[k-N].d); if(3*zk.n*z[i].d < 4*z[i].n*zk.d) sharp=true; } Console.WriteLine("sharp (some 22 points fit in an arc, i.e. 3 z_(i+21) < 4 z_(i) for some i): "+sharp);
  // (3) collision example
  BigInteger n0=BigInteger.Parse("189229648740392342924458476107735901007"), H0=BigInteger.Parse("252306198320523123899277968143647868008");
  Console.WriteLine("H = floor((4n-2)/3): " + ((4*n0-2)/3==H0));
  BigInteger Bn=BigInteger.Parse("3747260002627742358876645883996703401007"), Bd=BigInteger.Parse("711606070777470003190437481577793500000");
  foreach (string us in new[]{"210018023334016707918801515524337076127","252306198320523123899277968143647868007"}){ BigInteger u=BigInteger.Parse(us); BigInteger x=u, C=0; int E=0, g=0; var inputs=new HashSet<BigInteger>{u}; bool proper=true, distinct=true; BigInteger minProper=BigInteger.Zero; bool haveGate=false; BigInteger y=0; int gE=0,gg=0, runs=0; int runsBefore=0; BigInteger prevQn=0, prevQd=1; double qPrev=0,qGate=0; int totalOdd=0, totalSteps=0; BigInteger wEnd=0; bool ended=false; 
   while(true){ // odd step from state x (odd)
     BigInteger t=3*x+1; int e=0; while(t.IsEven){t>>=1;e++;} C=3*C+(BigInteger.One<<E); E+=e; g++; totalSteps+=e; x=t; // now x is the new state (odd), q = C/3^g
     if(e>=2){ runs++; // run ends; phase boundary
       BigInteger p3=BigInteger.Pow(3,g); if(!haveGate && Cmp(C,p3,Bn,Bd)>0){ haveGate=true; y=x; gE=E; gg=g; runsBefore=runs; qGate=(double)(C*BigInteger.Pow(10,15)/p3)/1e15; } else if(!haveGate){ qPrev=(double)(C*BigInteger.Pow(10,15)/p3)/1e15; } }
     if(x<=H0){ ended=true; wEnd=x; break; }
     if(!inputs.Add(x)) distinct=false; if(minProper.IsZero||x<minProper) minProper=x; if(g>5000) break; }
   Console.WriteLine($"u={us.Substring(0,12)}...: gate depth g={gg}, valuation sum E={gE}, runs through gate={runsBefore}, y={y}; odd length={g}, shortcut steps={E-0+ (g)} (E+g? see next), ended in band={ended && wEnd>=n0}, w={wEnd}, min proper={minProper} (>H: {minProper>H0}), distinct inputs: {distinct}, phase before/at gate {qPrev:F9}/{qGate:F9}");
  }
  BigInteger yExp=BigInteger.Parse("432477686064197331184095318752098181147"); Console.WriteLine("expected y = " + yExp);
}}
