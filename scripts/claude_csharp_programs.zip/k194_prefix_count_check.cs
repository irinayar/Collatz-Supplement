using System; using System.Collections.Generic; using System.Numerics;
// K194 checks: (1) prefix count lemma on small bands: #sources with a given exponent word (first g odd transitions, outputs x_1..x_g > H) is <= W*2^-E whenever 2^(E+1) <= 2W.
// (2) Q_i/u < i/(3u-i) exactly on actual trajectories at 2^71..2^90 with all inputs > H.
class P { static void Main(string[] a) {
 foreach (string sn in a) { long n = long.Parse(sn) | 1; long H = (4 * n - 2) / 3; long W = H - n; var cnt = new Dictionary<string,int>(); long viol = 0, groups = 0; int maxratioNum = 0; double maxRatio = 0;
  for (long u = n; u <= H; u += 2) { long x = u; var sb = new System.Text.StringBuilder(); int E = 0;
   for (int g = 1; g <= 60; g++) { long t = 3 * x + 1; int e = System.Numerics.BitOperations.TrailingZeroCount((ulong)t); t >>= e; E += e; x = t; if (x <= H) break; sb.Append(e).Append(','); if ((2.0 * Math.Pow(2, E)) <= 2.0 * W) { string key = sb.ToString(); cnt.TryGetValue(key, out int c); cnt[key] = c + 1; } else break; } }
  foreach (var kv in cnt) { int E = 0; foreach (var s in kv.Key.Split(',', StringSplitOptions.RemoveEmptyEntries)) E += int.Parse(s); groups++; double bound = W * Math.Pow(2, -E); double r = kv.Value / bound; if (r > maxRatio) maxRatio = r; if (kv.Value > bound + 1e-9) viol++; }
  Console.WriteLine($"n={n} W={W}: prefix classes={groups}, violations of count<=W*2^-E: {viol}; max count/(W 2^-E)={maxRatio:F3}"); }
 var rnd = new Random(5); long bad = 0, tot = 0; int maxI = 0;
 for (int it = 0; it < 3000; it++) { int bits = 71 + rnd.Next(0, 20); BigInteger n = (BigInteger.One << bits) + rnd.NextInt64() * 2 + 1; BigInteger H = (4 * n - 2) / 3; BigInteger u = n + 2 * (BigInteger)(rnd.NextInt64() % 1000000007); if (u > H) u = n; if (u.IsEven) u += 1; BigInteger x = u, Bq = 0; int E = 0;
  for (int i = 1; i <= 400; i++) { BigInteger t = 3 * x + 1; int e = 0; while (t.IsEven) { t >>= 1; e++; } Bq = 3 * Bq + (BigInteger.One << E); E += e; x = t; if (x <= H) break;
   // Q_i = Bq / 3^i ; check Q_i/u < i/(3u-i)  <=>  Bq*(3u-i) < i*u*3^i
   BigInteger p3 = BigInteger.Pow(3, i); tot++; if (!(Bq * (3 * u - i) < i * u * p3)) bad++; if (i > maxI) maxI = i; } }
 Console.WriteLine($"(2) Q_i/u < i/(3u-i) on {tot} (trajectory, i) pairs (inputs all > H, up to i<={maxI}): violations={bad}");
}}
