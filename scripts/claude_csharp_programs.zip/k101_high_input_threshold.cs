using System;
using System.Numerics;
// Smallest number A of distinct high odd inputs (> H, at most one divisible by 3: the least such) whose product P_A times the tail bound Q exceeds 3/2.
class P {
  static long Amin(long H,double Q,out double lastP){ double lp=0; long A=0; bool usedMult=false; double target=Math.Log(1.5)-Math.Log(Q); long u=H+1; if((u&1)==0) u++; lastP=1;
    while(true){ bool m3=(u%3==0); if(m3&&usedMult){ u+=2; continue; } if(m3) usedMult=true; lp+=Math.Log(1.0+1.0/(3.0*u)); A++; if(lp>target){ lastP=Math.Exp(lp); return A; } u+=2; } }
  static void Main(){
    double lp; long a=Amin(255,8192.0/6561.0,out lp); Console.WriteLine($"H=255, Q=8192/6561: A_min={a} (Codex K101: 355), P_A={lp:F6}");
    foreach(long H in new long[]{1000,100000,10000000,100000000}){ a=Amin(H,1.2531422,out lp); Console.WriteLine($"H={H}, Q=1.2531422: A_min={a} (A_min/H = {(double)a/H:F4}), P_A*Q={lp*1.2531422:F6}"); }
    // exact check of the maximiser: G(993)=2^61/(3^32*993) and the rational bound 3/2
    BigInteger num=BigInteger.Pow(2,61), den=BigInteger.Pow(3,32)*993; Console.WriteLine($"G(993) = 2^61/(3^32*993) = {num}/{den} = {(double)num/(double)den:F10}; 2*num<3*den: {2*num<3*den}");
  }
}
