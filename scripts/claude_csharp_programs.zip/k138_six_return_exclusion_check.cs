using System;
using System.Collections.Generic;
using System.Numerics;
// Check Codex K138 / ChatGPT 142500-Six_Return_Exclusion: no six-transition first return.
// (a) exhaustive: all odd u in I=[n,H], odd n<=20001: count g-transition first returns for g=2..9 (g=6 must be 0);
// (b) Codex residue table: 35 tuples (1,b,c,d,e,f), s=10: B via recurrence, unique residue r mod 2048, margin 39r-B+512 > 0 for all (min 4864);
// (c) ChatGPT: Bmax(E)=1040*2^(E-9)+405 for E=7..17 (maximum over tuples with e1=1,e6>=2, total E) and the E=10, u<=50 enumeration (unique u=39).
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static void Main(){
    long[] cnt=new long[12];
    for(long n=3;n<=20001;n+=2){ long H=(4*n-2)/3;
      for(long u=n;u<=H;u+=2){ long x=u; for(int g=1;g<=9;g++){ int e; x=A(x,out e); if(x<n) break; if(x>=n && x<=H){ cnt[g]++; break; } if(x<n) break; } } }
    // note: loop stops at first return (first re-entry into I), intermediates >H by construction (we break when entering I or dropping below n)
    { var sb=new System.Text.StringBuilder(); for(int g=1;g<=9;g++) sb.Append($"g{g}:{cnt[g]} "); Console.WriteLine("(a) first returns by gap g (odd n<=20001): "+sb); }
    // (b) table
    var tuples=new List<int[]>(); int minM=int.MaxValue; int allpos=0; int ntup=0;
    for(int b=1;b<=5;b++) for(int c=1;c<=5;c++) for(int d=1;d<=5;d++) for(int e=1;e<=5;e++) for(int f=2;f<=6;f++){ if(1+b+c+d+e+f!=10) continue; ntup++;
      var ev=new[]{1,b,c,d,e,f}; BigInteger Bn=0; int E=0; foreach(int v in ev){ Bn=3*Bn+(BigInteger.One<<E); E+=v; } // B_{j+1}=3B_j+2^{E_j}
      long Bl=(long)Bn; long res=-1; for(long r=1;r<2048;r+=2){ long x=r; bool ok=true; for(int i=0;i<6;i++){ int ee; x=A(x,out ee); if(ee!=ev[i]){ok=false;break;} } if(ok){res=r;break;} }
      long margin=39*res-Bl+512; if(margin<=0) allpos++; if(margin<minM) minM=(int)margin; if(ntup<=3||margin==4864) Console.WriteLine($"   tuple {string.Join(",",ev)}: B={Bl}, residue {res}, margin {margin}"); }
    Console.WriteLine($"(b) tuples with s=10: {ntup}; margins <=0: {allpos}; minimum margin {minM}");
    // (c) Bmax
    bool bmaxOk=true; for(int E=7;E<=17;E++){ BigInteger best=-1; // enumerate tuples e1=1, e2..e5>=1, e6>=2 with total E
      void Rec(int pos,int sum,List<int> cur){ if(pos==6){ if(sum==E && cur[5]>=2){ BigInteger Bn=0; int Ee=0; foreach(int v in cur){ Bn=3*Bn+(BigInteger.One<<Ee); Ee+=v; } if(Bn>best) best=Bn; } return; }
        int lo= pos==0?1:1; int hi=E-sum; for(int v=lo;v<=hi;v++){ if(pos==0&&v!=1) continue; cur.Add(v); Rec(pos+1,sum+v,cur); cur.RemoveAt(cur.Count-1); } }
      Rec(0,0,new List<int>()); bool match = (best*512 == 1040*BigInteger.Pow(2,E)+405*512); if(!match) bmaxOk=false; Console.WriteLine($"   E={E}: max B = {best}; formula 1040*2^(E-9)+405 = {((double)1040*Math.Pow(2,E-9)+405)} match={match}"); }
    Console.WriteLine($"(c) Bmax formula all E=7..17: {bmaxOk}");
    var list=new List<string>(); for(long u=3;u<=49;u+=2){ long x=u; int tot=0; var st=new List<long>{u}; var ev=new List<int>(); for(int i=0;i<6;i++){ int e; x=A(x,out e); tot+=e; st.Add(x); ev.Add(e);} if(tot==10 && ev[0]==1 && ev[5]>=2) list.Add($"u={u} val=({string.Join(",",ev)}) states {string.Join("->",st)}"); }
    Console.WriteLine("    odd u<=49 with six valuations summing to 10, e1=1,e6>=2: "+(list.Count==0?"none":string.Join(" ; ",list)));
  }
}
