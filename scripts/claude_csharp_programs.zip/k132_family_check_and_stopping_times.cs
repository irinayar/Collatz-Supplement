using System;
using System.Collections.Generic;
// Check Codex K132: P=111101 (S^6(n)=(243n+227)/64), Q=111101111100 (S^12(m)=(19683m+22547)/4096); n=303+5184h, m=239+4096h, common endpoint 1154+19683h; m<n; target never visits n in its 12-step prefix.
// Then: stopping-time statistics (steps until value<n) of family members vs baseline odd numbers in the same size range.
class P {
  static ulong S(ulong x)=> (x&1)==0? x>>1 : (3*x+1)>>1;
  static string Bits(ulong x,int len){ var sb=new System.Text.StringBuilder(); for(int i=0;i<len;i++){ sb.Append((x&1)==0?'0':'1'); x=S(x);} return sb.ToString(); }
  static int Stop(ulong n){ ulong x=n; int st=0; while(x>=n){ x=S(x); st++; if(st>100000) break; } return st; }
  static void Main(){
    int bad=0; 
    for(ulong h=0;h<20000;h++){ ulong n=303+5184*h, m=239+4096*h; ulong a=n; for(int i=0;i<6;i++) a=S(a); ulong b=m; for(int i=0;i<12;i++) b=S(b);
      bool visits=false; ulong p=m; for(int i=0;i<12;i++){ if(p==n) visits=true; p=S(p); }
      if(a!=b || a!=1154+19683*h || Bits(n,6)!="111101" || Bits(m,12)!="111101111100" || !(m<n) || visits) bad++; }
    Console.WriteLine($"K132 family h<20000: failures {bad}");
    int N=2000000; int[] cnt=new int[6]; int[] th={30,40,60,100,200}; int maxst=0; ulong argmax=0;
    for(ulong h=0;h<(ulong)N;h++){ ulong n=303+5184*h; int st=Stop(n); if(st>maxst){maxst=st;argmax=n;} for(int i=0;i<5;i++) if(st>th[i]) cnt[i]++; }
    Console.WriteLine($"family members n=303+5184h, h<{N} (n up to {303+5184UL*(ulong)N}): stopping time >30: {cnt[0]}, >40: {cnt[1]}, >60: {cnt[2]}, >100: {cnt[3]}, >200: {cnt[4]}; max {maxst} at n={argmax}");
    // baseline: odd n = 1 mod 2 with n up to same bound, sampled with same count, residues mod 5184 random odd
    var rng=new Random(7); int[] cb=new int[6]; int mb=0; for(int i=0;i<N;i++){ ulong n=(ulong)(2*rng.NextInt64(1,(long)(303+5184UL*(ulong)N)/2))+1; int st=Stop(n); if(st>mb) mb=st; for(int j=0;j<5;j++) if(st>th[j]) cb[j]++; }
    Console.WriteLine($"baseline random odd n same range, {N} samples: >30: {cb[0]}, >40: {cb[1]}, >60: {cb[2]}, >100: {cb[3]}, >200: {cb[4]}; max {mb}");
    // family 585447+5308416h for comparison (h<200000)
    int[] cc=new int[6]; int mc=0; for(ulong h=0;h<200000;h++){ ulong n=585447+5308416*h; int st=Stop(n); if(st>mc) mc=st; for(int j=0;j<5;j++) if(st>th[j]) cc[j]++; }
    Console.WriteLine($"ChatGPT family 585447+5308416h, h<200000: >30: {cc[0]}, >40: {cc[1]}, >60: {cc[2]}, >100: {cc[3]}, >200: {cc[4]}; max {mc}");
  }
}
