using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]);
    // per k : count, range of w, max over words of (max_s of max_t Phi_s)/2pi, min over ... ; also per k the max over words of oscillation over all starts
    var agg = new SortedDictionary<int, (long cnt, double maxUp, double maxDown, double maxOsc, double minOscMax, long mono)>();
    long words = 0, singleStartNeg = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true;
        for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; }
        if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2;
        for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L) continue;
        int k = 0; for (int i = 0; i < L; i++) if (e[i] && !e[(i + L - 1) % L]) k++; if (k < 1) continue;
        double[] x = X.Select(v => (double)v / (double)scale).ToArray(); double c = x.Min(), H = x.Max(), m = (c + H) / 2;
        var px = new double[L]; var py = new double[L];
        for (int i = 0; i < L; i++) { double yy = Math.Sqrt(Math.Max((x[i] - c) * (H - x[i]), 0)); px[i] = x[i]; py[i] = (x[i] == c || x[i] == H) ? 0 : (e[i] ? yy : -yy); }
        var delta = new double[L]; bool deg = false; double tot = 0;
        for (int i = 0; i < L; i++) { int j = (i + 1) % L; double ax = px[i] - m, ay = py[i], bx = px[j] - m, by = py[j]; double a = Math.Atan2(ax * by - ay * bx, ax * bx + ay * by); if (Math.Abs(Math.Abs(a) - Math.PI) < 1e-9) deg = true; delta[i] = a; tot += a; }
        if (deg) continue; words++;
        double twoPi = 2 * Math.PI; int wind = (int)Math.Round(tot / twoPi);
        double up = double.MinValue, down = double.MaxValue, osc = 0, oscMaxStartMin = double.MaxValue; // up: max_s max_t Phi_s(t); down: min_s min_t Phi_s(t)
        bool allNonPos = true;
        for (int s = 0; s < L; s++) {
          double cur = 0, mx = 0, mn = 0;
          for (int t = 1; t <= L; t++) { cur += delta[(s + t - 1) % L]; mx = Math.Max(mx, cur); mn = Math.Min(mn, cur); }
          up = Math.Max(up, mx / twoPi); down = Math.Min(down, mn / twoPi); double o = (mx - mn) / twoPi; osc = Math.Max(osc, o); oscMaxStartMin = Math.Min(oscMaxStartMin, o);
          if (mx > 1e-9) allNonPos = false;
        }
        agg.TryGetValue(k, out var v);
        agg[k] = (v.cnt + 1, Math.Max(v.cnt == 0 ? up : v.maxUp, up), Math.Min(v.cnt == 0 ? down : v.maxDown, down), Math.Max(v.maxOsc, osc), v.cnt == 0 ? oscMaxStartMin : Math.Min(v.minOscMax, oscMaxStartMin), v.mono + (allNonPos ? 1 : 0));
      }
    }
    Console.WriteLine($"words {words}. Cumulative winding Phi_s(t), t in [0,L], started at every vertex s (units of 2pi).");
    Console.WriteLine("k : words | max over words and starts of max_t Phi (>0 means a counterclockwise excursion) | min over words/starts of min_t Phi | max oscillation (max-min) over starts | words in which Phi_s <= 0 for every start and time");
    foreach (var kv in agg.Where(kv => kv.Key <= 9)) Console.WriteLine($"k={kv.Key}: {kv.Value.cnt,6} | {kv.Value.maxUp,6:F3} | {kv.Value.maxDown,7:F3} | {kv.Value.maxOsc,6:F3} | {kv.Value.mono}");
  }
}
