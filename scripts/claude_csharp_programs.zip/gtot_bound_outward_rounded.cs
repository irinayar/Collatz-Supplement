using System;
using System.Numerics;
// Rigorous version: every floating operation is outward-rounded (upper bounds), 64-bit arithmetic is overflow-checked, byte table stores upward-rounded (G-1)*512.
class P {
  static double FacUp(long n){ double dn=(double)n; double d=Math.BitDecrement(Math.BitDecrement(3.0*dn)); if(d<=0) throw new Exception("d"); double r=Math.BitIncrement(1.0/d); return Math.BitIncrement(1.0+r); } // >= 1+1/(3n)
  static void Main(string[] args){
    long M1=long.Parse(args[0]), M2=long.Parse(args[1]); long N=(M1-1)/2+1; var q=new byte[N]; const double SC=512.0; byte maxq=0; var sw=System.Diagnostics.Stopwatch.StartNew(); long maxN=0; int maxOdd=0; double maxUp=0;
    checked {
    for(long m=3;m<=M1;m+=2){ long n=m; double p=1.0; int od=0; while(n>=m){ if((n&1)==1){ p=Math.BitIncrement(p*FacUp(n)); n=(3*n+1)>>1; od++; if(n>maxN) maxN=n; } else n>>=1; } if(od>maxOdd) maxOdd=od;
      int tz=BitOperations.TrailingZeroCount((ulong)n); n>>=tz; double gn= n==1?0.0 : (double)q[(n-1)/2]/SC;
      double g=Math.BitIncrement(p*Math.BitIncrement(1.0+gn)); double qq=Math.Ceiling(Math.BitIncrement((g-1.0)*SC)); if(qq>255) throw new Exception("overflow"); q[(m-1)/2]=(byte)qq; if(q[(m-1)/2]>maxq) maxq=q[(m-1)/2]; }
    maxUp=1+maxq/SC; Console.WriteLine($"stage 1: odd m <= {M1}: bound {maxUp:F6}; max trajectory value {maxN}; max odd steps per walk {maxOdd} [{sw.ElapsedMilliseconds/1000}s]");
    for(long m=M1+2;m<=M2;m+=2){ long n=m; double p=1.0; while(n>M1){ if((n&1)==1){ p=Math.BitIncrement(p*FacUp(n)); n=(3*n+1)>>1; if(n>maxN) maxN=n; } else n>>=1; }
      int tz=BitOperations.TrailingZeroCount((ulong)n); n>>=tz; double gn= n==1?0.0 : (double)q[(n-1)/2]/SC; double g=Math.BitIncrement(p*Math.BitIncrement(1.0+gn)); if(g>maxUp) maxUp=g; }
    }
    Console.WriteLine($"all odd m <= {M2}: rigorous upper bound max Gtot <= {maxUp:R}; below 3/2: {maxUp<1.5}; max trajectory value {maxN} (< 2^53: {maxN<(1L<<53)}); total {sw.ElapsedMilliseconds/1000}s");
  }
}
