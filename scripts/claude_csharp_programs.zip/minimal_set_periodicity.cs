using System;
using System.Collections.Generic;
// Test: indicator of M_K (n minimal in its fibre of T^(K-1)) is periodic with period 3*2^(K-1); report the largest n violating it.
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var tau = new int[N + 1];
    var st = new List<int>(N); var val = new List<long>(N); for (int n = 1; n <= N; n++) { st.Add(n); val.Add(n); }
    for (int k = 1; st.Count > 2 && k <= 19; k++) {
      var first = new HashSet<long>(st.Count); var st2 = new List<int>(st.Count); var val2 = new List<long>(st.Count);
      for (int i = 0; i < st.Count; i++) { long v = val[i]; if (!first.Add(v)) { tau[st[i]] = k; continue; } st2.Add(st[i]); val2.Add((v & 1) == 1 ? (3 * v + 1) / 2 : v / 2); }
      st = st2; val = val2;
    }
    for (int K = 2; K <= 17; K++) { if (K <= 6) { var comp = new List<long>(); long pp = 3L << (K - 1); for (long r = 0; r < pp; r++) { int n = (int)(r + 5 * pp); if (!(tau[n] == 0 || tau[n] > K)) comp.Add(r); } Console.WriteLine($"  K={K}: NON-members mod {pp}: {string.Join(",", comp)}"); }
      long p = 3L << (K - 1); bool IsM(int n) => tau[n] == 0 || tau[n] > K;
      int maxViol = 0; long viol = 0; long members = 0;
      for (int n = 1; n + p <= N; n++) if (IsM(n) != IsM((int)(n + p))) { viol++; maxViol = n; }
      for (int n = (int)(N - p) + 1; n <= N; n++) if (IsM(n)) members++;   // one full period near the top
      Console.WriteLine($"K={K,2}: period 3*2^{K - 1} = {p,6}; violations n<->n+p: {viol,6}, largest violating n = {maxViol,8} (n/p = {(double)maxViol / p:F2}); members in one period near N: {members} / {p}  (d_K = {(double)members / p:F5})");
    }
  }
}
