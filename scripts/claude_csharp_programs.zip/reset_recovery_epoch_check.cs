using System;
// Check ChatGPT 114751: t>=1 transitions with e>=2 from u0 to v>=3, then s>=1 transitions with e=1 from v.
// G over all t+s odd inputs < (v+1-(2/3)^s)/(v-1); 2^(s+1) | v+1; v%3!=0; s>=2 => G<1+1/(2^s-1); s=1 => v>=7, G<=11/9.
// All sub-prefixes (t' <= maximal streak, s' <= maximal rise) are tested. Exhaustive over odd u0 < 2^24.
class P {
  static void Main(){
    long cases=0, bad=0; double maxG=0; int maxS=0,maxT=0; double maxSlack=1e9; 
    for(long u0=3; u0<(1L<<24); u0+=2){
      long u=u0; int t=0; double G=1.0; long[] vs=new long[80]; double[] Gs=new double[80];
      while(t<70){ long x=3*u+1; int e=0; while((x&1)==0){x>>=1;e++;} if(e<2) break; G*=(3.0*u+1)/(3.0*u); t++; u=x; vs[t]=u; Gs[t]=G; }
      for(int tp=1;tp<=t;tp++){ long v=vs[tp]; if(v<3) continue; double G0=Gs[tp]; long w=v; double Gr=G0; 
        for(int s=1;s<=60;s++){ long x=3*w+1; if((x&1)!=0) break; /* need e>=1 always true; require e==1 exactly */ if(((x>>1)&1)==0) break; Gr*=(3.0*w+1)/(3.0*w); w=x>>1; // e==1
          double bound=(v+1-Math.Pow(2.0/3,s))/(v-1.0); cases++; if(!(Gr<bound)) bad++; maxSlack=Math.Min(maxSlack,bound-Gr);
          if(((v+1)%(1L<<Math.Min(s+1,62)))!=0) bad++; if(v%3==0) bad++;
          if(s>=2 && !(Gr<1+1.0/(Math.Pow(2,s)-1))) bad++; if(s==1 && (v<7 || Gr>11.0/9)) bad++;
          if(Gr>maxG) maxG=Gr; if(s>maxS) maxS=s; if(tp>maxT) maxT=tp; }
      }
    }
    Console.WriteLine($"cases {cases}, violations {bad}, max G {maxG:F8}, max s {maxS}, max t {maxT}, min slack {maxSlack:E3}");
    double Q=Math.Pow(2,61)/(Math.Pow(3,32)*993), h=2359295; Console.WriteLine($"H=2359293 cutoff float: {Math.Log(1.5/Q)/Math.Log(1+1/(3*h)):F3}; 7/6*Q={7.0/6*Q:F8}");
  }
}
