using System;
// Survivors of both sufficient filters (x>=3, successor feasible, least origin m != 2 mod 3, m <= 2^(k+1)-4) for larger k, all odd counts r: count, largest endpoint x, largest r, difference range.
class P {
  static long[] kx; static byte[] kr; static long[] val; static int mask; static long count;
  static int Slot(long x,int r){ ulong h=(ulong)x*0x9E3779B97F4A7C15UL ^ ((ulong)(r+1)*0xC2B2AE3D27D4EB4FUL); h^=h>>29; h*=0xBF58476D1CE4E5B9UL; h^=h>>32; return (int)(h&(ulong)mask); }
  static void Insert(long x,int r,long m){ int s=Slot(x,r); while(val[s]!=0){ if(kx[s]==x&&kr[s]==r) return; s=(s+1)&mask; } kx[s]=x; kr[s]=(byte)r; val[s]=m; count++; }
  static long Find(long x,int r){ int s=Slot(x,r); while(val[s]!=0){ if(kx[s]==x&&kr[s]==r) return val[s]; s=(s+1)&mask; } return 0; }
  static void Main(string[] args){
    foreach(var ks in args){ int k=int.Parse(ks); long B=(1L<<(k+1))-3; int bits=k<=20?22:(k<=23?24:25); int size=1<<bits; mask=size-1; kx=new long[size]; kr=new byte[size]; val=new long[size]; count=0;
      for(long m=1;m<B;m++){ long y=m; int e=0,o=0; while(true){ if(e==k) Insert(y,o,m); if((y&1)==1){ y=(3*y+1)>>1; o++; } else { if(e==k) break; y>>=1; e++; } } }
      long surv=0,all=0,viol=0; long xMax=0; int rMax=0; long dMin=long.MaxValue,dMax=long.MinValue; long mMax=0; long s0=0,s1=0;
      for(int s=0;s<size;s++){ if(val[s]==0) continue; long x=kx[s]; int r=kr[s]; long h=val[s]; if(x<3) continue; long hp=Find(x,r+1); if(hp==0) continue; all++; if(hp>=h) viol++;
        if(h%3==2) continue; if(h>B-1) continue; surv++; if(h%3==0) s0++; else s1++; if(x>xMax) xMax=x; if(r>rMax) rMax=r; long D=hp-h; if(D<dMin) dMin=D; if(D>dMax) dMax=D; if(h>mMax) mMax=h; }
      Console.WriteLine($"k={k}: x>=3 pairs with feasible successor {all}, violations {viol}; filter survivors {surv} (m=0 mod 3: {s0}, 1 mod 3: {s1}); largest x {xMax}, largest r {rMax}, largest m {mMax}; difference range [{dMin},{dMax}]"); }
  }
}
