using System;
using System.Collections.Generic;
using System.Numerics;
// Five-even, valuation-one case x=3u-1, u=1 mod 3, v3(G)=0 i.e. w=2 mod 3: P_s=H_3(6w-1,s), Q_s=H_4(3w-1,s), s>=1; min(P,Q)=H_5 tail.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    var pat=new SortedDictionary<string,long>(); long overlap=0,qLess=0,pLess=0,mono=0,series=0,take=0; var gaps=new SortedDictionary<int,long>(); var lastIdx=new SortedDictionary<string,long>();
    for(int w=2;w<=6000;w+=3){ BigInteger W=w; var sb=new System.Text.StringBuilder(); char prev=' '; BigInteger prevMin=INF; series++; int lastP=0,lastQ=0;
      for(int s=1;s<=30;s++){ var Pv=H(6*W-1,3,s); var Qv=H(3*W-1,4,s); if(Pv!=INF) lastP=s; if(Qv!=INF) lastQ=s; BigInteger mn=INF; char arg=' ';
        if(Pv!=INF){mn=Pv;arg='P';} if(Qv!=INF&&(mn==INF||Qv<mn)){mn=Qv;arg='Q';} if(Pv!=INF&&Qv!=INF){ overlap++; if(Qv<Pv) qLess++; else if(Pv<Qv) pLess++; if(Pv-Qv>=0){ int g=(int)(Pv-Qv); gaps[g]=gaps.GetValueOrDefault(g)+1; } }
        if(mn==INF) break; if(prevMin!=INF&&!(mn<prevMin)) mono++; if(arg!=prev){ sb.Append(arg); prev=arg; } prevMin=mn; }
      pat[sb.ToString()]=pat.GetValueOrDefault(sb.ToString())+1; string li=$"lastP={Math.Min(lastP,6)} lastQ={Math.Min(lastQ,8)}"; lastIdx[li]=lastIdx.GetValueOrDefault(li)+1; hm.Clear(); }
    Console.WriteLine($"w=2 mod 3, w<=6000: {series} endpoints; argmin patterns: "+string.Join("; ",pat));
    Console.WriteLine($"overlap cells {overlap}: Q<P {qLess}, P<Q {pLess}; min(P,Q) non-decreasing steps {mono}; P-Q values: "+string.Join(", ",gaps));
    Console.WriteLine("end indices: "+string.Join("; ",lastIdx));
  }
}
