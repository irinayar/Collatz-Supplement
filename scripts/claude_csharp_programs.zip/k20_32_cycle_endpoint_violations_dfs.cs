using System;
using System.Collections.Generic;
using System.Numerics;
// Exact violation lists at the endpoints x=1,2 for k=20..32 by plain inverse-tree DFS (exactly k even edges), independent of the origin enumeration.
class P {
  static int EMAX; static BigInteger[] mn; static long nodes;
  static void Dfs(BigInteger z,int ev,int od){ nodes++; if(ev==EMAX){ if(mn[od]==0||z<mn[od]) mn[od]=z; }
    if(ev<EMAX) Dfs(2*z,ev+1,od); if(z%3==2) Dfs((2*z-1)/3,ev,od+1); }
  static void Main(){
    var sw=System.Diagnostics.Stopwatch.StartNew();
    for(int k=20;k<=32;k++){ foreach(long x in new[]{1L,2L}){ if(sw.ElapsedMilliseconds>170000){ Console.WriteLine("time limit at k="+k); return; } EMAX=k; mn=new BigInteger[120]; nodes=0; Dfs(x,0,0); int R=-1; for(int r=0;r<120;r++) if(mn[r]!=0) R=r;
        var v=new List<string>(); for(int r=0;r<R;r++) if(mn[r+1]>=mn[r]) v.Add($"({r}: {mn[r]}->{mn[r+1]})"); Console.WriteLine($"k={k} x={x}: R={R}, increases {v.Count}: {string.Join(" ",v)}  [{nodes} nodes]"); } }
  }
}
