using System;
using System.Numerics;
// Check of ChatGPT 195434: triple-run maximum T=59703296/59344245 at 335->425->319->911; threshold 91 from Q*T^floor(h/3)*[1,R,B].
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public override string ToString()=>n+"/"+d; }
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static Fr Step(BigInteger u,out BigInteger v){ int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); v=w>>e; return new Fr(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); }
  static void Main(){
    Fr best=new Fr(1,1); long arg=0; int elig=0; string chain="";
    for(long u0=257;u0<=1023;u0+=2){ BigInteger v1; var c1=Step(u0,out v1); if(v1<=255) continue; BigInteger v2; var c2=Step(v1,out v2); if(v2<=255) continue; elig++; BigInteger v3; var c3=Step(v2,out v3); var pr=c1*c2*c3; if(Fr.Gt(pr,best)){ best=pr; arg=u0; chain=$"{u0} -> {v1} -> {v2} -> {v3}"; } }
    Fr T=new Fr(59703296,59344245); Fr tail=new Fr(1026,1025); Console.WriteLine($"triple maximum over odd u in [257,1023] with F(u),F(F(u)) > 255: eligible {elig}, max = {best} at chain {chain}; equals ChatGPT's T: {best.n==T.n&&best.d==T.d}");
    Fr R=new Fr(69952,69741), B=new Fr(227840,226719); Console.WriteLine("(1026/1025)*B < T: " + Fr.Gt(T,tail*B));
    Fr Q=new Fr(8192,6561); Fr three2=new Fr(3,2); int firstFail=-1; for(int h=0;h<=200;h++){ Fr bound=Q; for(int i=0;i<h/3;i++) bound=bound*T; if(h%3==1) bound=bound*R; if(h%3==2) bound=bound*B; if(Fr.Gt(bound,three2)){ firstFail=h; break; } }
    Console.WriteLine($"smallest h with Q*T^floor(h/3)*[1,R,B][h mod 3] > 3/2: {firstFail} (ChatGPT: 91, i.e. valid for h<=90)");
  }
}
