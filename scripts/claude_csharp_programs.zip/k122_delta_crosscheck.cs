using System;
using System.Numerics;
// Cross-check of Codex K122 continued: odd starts 524287..786429: maximum G (and where), maximum accelerated length L, maximum visited state; and the exact integer cutoff at H=786429, q=2359294/2359293.
class P {
  static void Main(){
    double l2=Math.Log2(3.0); double best=0; long arg=0; int maxL=0; long maxState=0; long cnt=0; int bestL=0,bestR=0;
    for(long m=524287;m<=786429;m+=2){ long n=m; int L=0,r=0; while(n!=2){ if((n&1)==1){ n=(3*n+1)>>1; r++; if(n>maxState) maxState=n; } else n>>=1; L++; } if(L>maxL) maxL=L; double lg=(L+1)-r*l2-Math.Log2((double)m); double g=Math.Pow(2.0,lg); cnt++; if(g>best){ best=g; arg=m; bestL=L; bestR=r; } }
    Console.WriteLine($"delta odd starts {cnt}: max G = {best:F10} at m={arg} (L={bestL}, r={bestR}); max accelerated length to 2: {maxL} (Codex: 319, counted to 1); max visited odd-step state {maxState} (Codex: 18997161173)");
    BigInteger a=BigInteger.Pow(2,61)*2, b=BigInteger.Pow(3,32)*993*3; // inequality: 2*2^61*q1^r < 3*(3^32*993)*q0^r
    foreach(int r in new[]{424226,424227}){ BigInteger lhs=2*BigInteger.Pow(2,61)*BigInteger.Pow(2359294,r), rhs=3*(BigInteger.Pow(3,32)*993)*BigInteger.Pow(2359293,r); Console.WriteLine($"r={r}: Q*q^r < 3/2 exactly: {lhs<rhs}"); }
  }
}
