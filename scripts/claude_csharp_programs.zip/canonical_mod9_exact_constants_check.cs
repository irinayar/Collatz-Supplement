using System;
using System.Numerics;
// Exact arithmetic checks for ChatGPT 213648 theorem: (6) power comparisons r=1..512; (2*3^44 < 2^71 < 2*3^45); r<193/200 constant; final sum < 144/125; E10(48/125) exact fraction and < 47/32; the 367/250 cap check.
class P {
  static BigInteger Gcd(BigInteger a,BigInteger b)=>BigInteger.GreatestCommonDivisor(a,b);
  static void Main(){
    BigInteger n=BigInteger.One<<71; bool ok=true; for(int r=1;r<=512;r++){ BigInteger p3=BigInteger.Pow(3,r); int bl=(int)p3.GetBitLength(); // floor(log2 3^r)+1 = bit length
      if(!(BigInteger.Pow(3*n+1,r) < BigInteger.Pow(n,r)*(BigInteger.One<<bl))) ok=false; }
    Console.WriteLine($"(6) (3n+1)^r < n^r 2^(floor(log2 3^r)+1) for all r=1..512: {ok}");
    Console.WriteLine($"2*3^44<2^71<2*3^45: {2*BigInteger.Pow(3,44)<n && n<2*BigInteger.Pow(3,45)}");
    // r<193/200 : r^3 = 3/(2 sqrt2 -1)^2  <  (193/200)^3 ; (2 sqrt2-1)^2 = 9-4 sqrt2 ; 3/(9-4sqrt2) < (193/200)^3  <=> 3*200^3 < 193^3 (9-4 sqrt2) <=> 4 sqrt2*193^3 < 9*193^3-3*200^3 ; square both sides (rhs positive?)
    BigInteger a=BigInteger.Pow(193,3), b=BigInteger.Pow(200,3); BigInteger rhs=9*a-3*b; bool rOk = rhs>0 && 32*a*a < rhs*rhs; Console.WriteLine($"r<193/200 (exact): {rOk}");
    // final sum
    BigInteger num=BigInteger.Parse("90967979218314767609676800115"); BigInteger den=BigInteger.One<<96;
    double Ffin=(double)num/(double)den; double Fodd=200.0/7*Math.Pow(193.0/200,257); double Fb=72.0/Math.Pow(2,70);
    Console.WriteLine($"F_fin={Ffin:F15}  F_odd={Fodd:F15}  F_bdry={Fb:E3}  sum={Ffin+Fodd+Fb:F15}  144/125={144.0/125}");
    // exact: sum < 144/125 ?  F_odd bound: (200/7)(193/200)^257 as exact rational
    BigInteger fo_n=200*BigInteger.Pow(193,257), fo_d=7*BigInteger.Pow(200,257);
    // lhs = num/den + fo_n/fo_d + 72/2^70 ; compare with 144/125 via common denominator
    BigInteger D=den*fo_d; BigInteger L=num*fo_d + fo_n*den + 72*(BigInteger.One<<26)*fo_d; // 72/2^70 = 72*2^26/2^96
    Console.WriteLine($"exact: F_fin+F_odd+F_bdry < 144/125: {L*125 < 144*D}");
    // E10 exact
    BigInteger xn=48, xd=125; BigInteger fact=1; BigInteger sn=0, sd=1; // sum x^k/k! as fraction
    BigInteger Nn=0, Nd=1; for(int k=0;k<=10;k++){ if(k>0) fact*=k; BigInteger tn=BigInteger.Pow(xn,k), td=BigInteger.Pow(xd,k)*fact; Nn=Nn*td+tn*Nd; Nd=Nd*td; BigInteger g=Gcd(Nn,Nd); Nn/=g; Nd/=g; }
    // tail: (x^11/11!)/(1-x/12) = x^11/11! * 12/(12-x) = x^11*12*125/(11!*(12*125-48)) 
    BigInteger tailN=BigInteger.Pow(xn,11)*12*125, tailD=BigInteger.Pow(xd,11)*39916800*(12*125-48);
    BigInteger EN=Nn*tailD+tailN*Nd, ED=Nd*tailD; BigInteger gg=Gcd(EN,ED); EN/=gg; ED/=gg;
    Console.WriteLine($"E10(48/125) = {EN}/{ED}; claimed 318482310514689786049226261/216928310692310333251953125: {EN==BigInteger.Parse("318482310514689786049226261") && ED==BigInteger.Parse("216928310692310333251953125")}; < 47/32: {EN*32<47*ED}; value {(double)EN/(double)ED:F8}");
    // 367/250 cap: x*=575597/1500000 ; E10(x*)(1+5/(4*2^71)) < 367/250
    BigInteger xn2=575597, xd2=1500000; fact=1; Nn=0; Nd=1; for(int k=0;k<=10;k++){ if(k>0) fact*=k; BigInteger tn=BigInteger.Pow(xn2,k), td=BigInteger.Pow(xd2,k)*fact; Nn=Nn*td+tn*Nd; Nd=Nd*td; BigInteger g=Gcd(Nn,Nd); Nn/=g; Nd/=g; }
    BigInteger tN=BigInteger.Pow(xn2,11)*12*xd2, tD=BigInteger.Pow(xd2,11)*39916800*(12*xd2-xn2); BigInteger EN2=Nn*tD+tN*Nd, ED2=Nd*tD;
    BigInteger fac_n=4*n+5, fac_d=4*n; Console.WriteLine($"E10(x*)(1+5/(4 2^71)) < 367/250: {EN2*fac_n*250 < 367*ED2*fac_d}; value {(double)EN2/(double)ED2:F8}");
  }
}
