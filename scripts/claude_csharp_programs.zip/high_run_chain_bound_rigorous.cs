using System;
using System.Numerics;
// Rigorous (upward-rounded) version of the high-run chain recursion M_n; certifies Q*M_n < 3/2 for n < n0.
class P {
  static int V2(BigInteger x){ int c=0; while(x.IsEven){x>>=1;c++;} return c; }
  static double Up(double x)=>Math.BitIncrement(Math.BitIncrement(x));
  static double RatioUp(BigInteger num,BigInteger den){ BigInteger q=(num<<60)/den+1; double d=(double)q/Math.Pow(2,60); return Up(d*(1.0+Math.Pow(2,-50))); }
  static void Main(string[] args){
    int X=int.Parse(args[0]); int N=int.Parse(args[1]); int cnt=(X-257)/2+1; var C=new double[cnt]; var Fn=new int[cnt];
    for(int i=0;i<cnt;i++){ BigInteger u=257+2L*i; int s=V2(u+1); BigInteger w=BigInteger.Pow(3,s)*(u+1)/BigInteger.Pow(2,s)-1; int e=V2(w); BigInteger v=w>>e; C[i]=RatioUp(BigInteger.Pow(2,s)*w,BigInteger.Pow(3,s)*u); if(v<=255) Fn[i]=-1; else if(v>X) Fn[i]=-2; else Fn[i]=(int)((v-257)/2); }
    double tail=RatioUp(X+1,X); double Q=RatioUp(8192,6561); double[] cur=new double[cnt], prev=new double[cnt]; double M=tail; for(int i=0;i<cnt;i++){ cur[i]=C[i]; if(cur[i]>M) M=cur[i]; }
    for(int n=2;n<=N;n++){ var t=prev; prev=cur; cur=t; double mx=0; for(int i=0;i<cnt;i++){ double f=Fn[i]==-1?1.0:(Fn[i]==-2?M:prev[Fn[i]]); double v=Up(C[i]*f); cur[i]=v; if(v>mx) mx=v; } M=Math.Max(mx,Up(tail*M)); }
    double bound=Up(Q*M); Console.WriteLine($"X={X}: after n={N} steps (upward rounding everywhere) M_n <= {M:R}, Q*M_n <= {bound:R}; certificate Q*M_n < 3/2: {bound<1.5}; margin {1.5-bound:E3}");
  }
}
