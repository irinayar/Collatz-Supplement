using System; using System.Numerics; using System.Linq; using System.Collections.Generic;
// crude cycle inequality N0 (2^b - 3^a) <= 2^(b-a) (3^a - 2^a) with b the least integer with 2^b > 3^a; compare with the certified base 2^71.
class P { static void Main(){ BigInteger B71=BigInteger.Pow(2,71); var excl=new List<int>(); var notExcl=new List<int>();
  for(int a=1;a<=1500;a++){ BigInteger p3=BigInteger.Pow(3,a); int b=(int)p3.GetBitLength(); if(BigInteger.Pow(2,b)<=p3) b++; BigInteger d=BigInteger.Pow(2,b)-p3; BigInteger num=BigInteger.Pow(2,b-a)*(p3-BigInteger.Pow(2,a)); // N0 <= num/d ; excluded iff num/d < 2^71  <=> num < 2^71 d
    if(num<B71*d) excl.Add(a); else notExcl.Add(a); }
  Console.WriteLine("a<=1500: bound < 2^71 (cycle with a odd steps excluded by the crude inequality alone) for "+excl.Count+" values; largest such a = "+excl.Max()+"; smallest a not excluded = "+notExcl.Min());
  var big=excl.Where(a=>a>115).ToList(); Console.WriteLine("excluded a > 115: "+big.Count+" values: "+string.Join(",",big.Take(20))+(big.Count>20?"...":"")); Console.WriteLine("all a<=115 excluded: "+Enumerable.Range(1,115).All(a=>excl.Contains(a)));
 }}
