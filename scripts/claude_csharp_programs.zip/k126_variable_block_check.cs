using System;
using System.Numerics;
using System.Collections.Generic;
// Independent exact check of K126 + ChatGPT 122804 extension: x with valuations (1,1,1) then random blocks (e,1^s), admissible = (2,s>=1),(3,s>=4),(4,s>=8).
// For every prefix (every transition) check G < 1+25/(9x) exactly (BigInteger cross-multiplication), plus defect identity sign classification for e<=12,s<=60.
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger Least(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static void Main(){
    // sign classification of defect numerator B+7(d-a)
    bool classOk=true; 
    for(int e=2;e<=12;e++) for(int s=1;s<=60;s++){ BigInteger a=BigInteger.Pow(3,s+1), d=BigInteger.One<<(s+e), B=BigInteger.Pow(3,s)*(1+(BigInteger.One<<e))-d; bool nonpos=(B+7*(d-a))<=0; bool claim=(e==2)||(e==3&&s>=4)||(e==4&&s>=8); if(nonpos!=claim){ classOk=false; Console.WriteLine($"class mismatch e={e} s={s}"); } }
    Console.WriteLine($"defect sign classification (e<=12, s<=60) matches ChatGPT: {classOk}");
    var rng=new Random(12345); long words=0,prefixes=0,bad=0; BigInteger maxNum=0;
    double worst=0;
    for(int t=0;t<3000;t++){
      var w=new List<int>{1,1,1}; int nb=1+rng.Next(8);
      for(int b=0;b<nb;b++){ int e=2+rng.Next(3); int s= e==2? 1+rng.Next(6) : e==3? 4+rng.Next(5) : 8+rng.Next(5); w.Add(e); for(int j=0;j<s;j++) w.Add(1); }
      BigInteger x=Least(w); if(x<0) continue; words++;
      if(x<15){ bad++; Console.WriteLine("x<15?"); }
      BigInteger u=x, N=1, Dn=1; // product numerator/denominator
      foreach(int e in w){ N*=(3*u+1); Dn*=(3*u); BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} u=y; prefixes++;
        if(!(N*9*x < (9*x+25)*Dn)) { bad++; Console.WriteLine($"VIOLATION x={x}"); }
        double ratio=(double)(N*BigInteger.Pow(10,12)/Dn)/1e12; double bound=1+25.0/(9*(double)x); if(x<(BigInteger)1e15) worst=Math.Max(worst,(ratio-1)/(bound-1)); }
    }
    Console.WriteLine($"random admissible words {words}, prefixes {prefixes}, violations {bad}; max (G-1)/(25/(9x)) over x<1e15 = {worst:F4}");
  }
}
