using System;
using System.Collections.Generic;
using System.Numerics;
// Five-even, valuation-one case x=3u-1, u=1 mod 3, v3(G)=0 i.e. w=2 mod 3: P_s=H_3(6w-1,s), Q_s=H_4(3w-1,s), s>=1; min(P,Q)=H_5 tail.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    // K089 identity: min(M_s,B_s) = H_5(6q-1,s-1), M_s=H_4(12q-2,s-1), B_s=H_4(8q-2,s-2)
    long id=0,idBad=0;
    for(int q=1;q<=3000;q++){ if(q%3==0) continue; BigInteger Q=q; for(int s=2;s<=14;s++){ var M=H(12*Q-2,4,s-1); var B=H(8*Q-2,4,s-2); BigInteger mn=INF; if(M!=INF) mn=M; if(B!=INF&&(mn==INF||B<mn)) mn=B; id++; if(mn!=H(6*Q-1,5,s-1)) idBad++; } hm.Clear(); }
    Console.WriteLine("K089 identity min(M_s,B_s)=H_5(6q-1,s-1): " + id + " cells, failures " + idBad);
    // K090 (v3(G)=1): x=3u-1,u=1 mod 3, w with G=4w-1, v3(G)=1; P_s=H_3(6w-1,s), Q_s=H_4(3w-1,s); claimed P-Q = 8,9,7,5 at s=1..4 where P finite; strict decrease
    long cells=0,gapBad=0,mono=0,take=0,takeBad=0,series=0;
    for(int w=1;w<=9000;w++){ if(w%3==0) continue; BigInteger G=4*(BigInteger)w-1; if(V3(G)!=1) continue; BigInteger W=w; series++; BigInteger prev=INF;
      for(int s=1;s<=30;s++){ var Pv=H(6*W-1,3,s); var Qv=H(3*W-1,4,s); BigInteger mn=INF; if(Pv!=INF) mn=Pv; if(Qv!=INF&&(mn==INF||Qv<mn)) mn=Qv; if(mn==INF) break; if(prev!=INF&&!(mn<prev)) mono++; prev=mn;
        if(Pv!=INF&&s<=4){ cells++; int want=s==1?8:s==2?9:s==3?7:5; if(Qv==INF||Pv-Qv!=want) gapBad++; }
        var Pn=H(6*W-1,3,s+1); var Qn=H(3*W-1,4,s+1); if(Qv!=INF&&Qn==INF&&Pn!=INF){ take++; if(!(Qv>Pn)) takeBad++; } }
      hm.Clear(); }
    Console.WriteLine("K090 class v3(G)=1, w<=9000: " + series + " endpoints; gap cells (s<=4, P finite) " + cells + ", failures vs 8,9,7,5: " + gapBad + "; monotonicity violations " + mono + "; takeovers " + take + ", failures " + takeBad);
  }
}
