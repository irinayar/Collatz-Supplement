using System;
using System.Numerics;
// Audit of ChatGPT 215710: inverse-position identity m/2^k = 8x/27 - (4/27)2^-a - (2/9)2^-b - (1/3)2^-c, and H_k(4,3)=17*2^(k-4), H_k(5,3)=11*2^(k-3), H_k(4,4)<=11*2^(k-4), H_k(5,4)<=7*2^(k-3).
class P {
  static bool Inv(BigInteger x,int k,int a,int b,int c,out BigInteger m){ // reverse path: a evens, odd inverse, (b-a) evens, odd, (c-b) evens, odd, (k-c) evens
    m=0; BigInteger z=x; int[] gaps={a,b-a,c-b}; foreach(int g in gaps){ z*=BigInteger.Pow(2,g); if((2*z-1)%3!=0) return false; BigInteger w=(2*z-1)/3; if(w<1||w.IsEven) return false; z=w; } m=z*BigInteger.Pow(2,k-c); return true; }
  static void Main(){
    long words=0,idBad=0; for(int x=3;x<=40;x++) for(int k=3;k<=12;k++) for(int a=0;a<=k;a++) for(int b=a;b<=k;b++) for(int c=b;c<=k;c++){ if(!Inv(x,k,a,b,c,out var m)) continue; words++; 
        // formula: m/2^k = 8x/27 - 4/27 2^-a - 2/9 2^-b - 1/3 2^-c  <=> 27*2^(a+b+c) * m = 2^k*(8x*2^(a+b+c) - 4*2^(b+c) - 6*2^(a+c) - 9*2^(a+b))
        BigInteger lhs=27*BigInteger.Pow(2,a+b+c)*m, rhs=BigInteger.Pow(2,k)*(8*x*BigInteger.Pow(2,a+b+c)-4*BigInteger.Pow(2,b+c)-6*BigInteger.Pow(2,a+c)-9*BigInteger.Pow(2,a+b)); if(lhs!=rhs) idBad++; }
    Console.WriteLine($"identity (1): {words} valid three-odd words (x=3..40, k=3..12, any a<=b<=c), mismatches {idBad}");
    long bad=0,cases=0; foreach(int x in new[]{4,5}) for(int k=3;k<=40;k++){ BigInteger best=-1; BigInteger best4=-1; for(int a=0;a<=k;a++) for(int b=a;b<=k;b++) for(int c=b;c<=k;c++) if(Inv(x,k,a,b,c,out var m)&&(best<0||m<best)) best=m;
        if(x==4&&k>=4){ cases++; if(best!=17*BigInteger.Pow(2,k-4)) bad++; } if(x==5){ cases++; if(best!=11*BigInteger.Pow(2,k-3)) bad++; } }
    Console.WriteLine($"minimum over ALL (a,b,c) for x=4 (k=4..40) and x=5 (k=3..40): {cases} cases, failures of 17*2^(k-4) / 11*2^(k-3): {bad}");
    // four-odd competitors: forward replay
    long comp=0,compBad=0; foreach(var (x,start,od,ev) in new[]{(4,11,4,4),(5,7,4,3)}) for(int k=ev;k<=30;k++){ BigInteger cur=start*BigInteger.Pow(2,k-ev); int e=0,o=0; while(cur!=x){ if(cur.IsEven){cur/=2;e++;} else {cur=(3*cur+1)/2;o++; } if(e>k+5) break; } comp++; if(e!=k||o!=od) compBad++; }
    Console.WriteLine($"four-odd competitors (11*2^(k-4)->4 with 4 odd, 7*2^(k-3)->5 with 4 odd) forward replay: {comp} cases, failures {compBad}");
  }
}
