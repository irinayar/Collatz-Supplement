using System;
using System.Numerics;
using System.Collections.Generic;
// Check Codex K125: valuations (1,1,1) then W^N, W = concatenation of blocks (2,1^s_i). Affine map of W: y -> (A y + B)/D (unreduced); 
// claim: cylinder 27*delta*x + 19*delta + 8*B == 0 mod 16*D^N (delta=A-D); least x = unique residue in [1,16 D^N-1]; compare with independently built least realiser (valuation cylinder, exact replay).
class P {
  static BigInteger ModInv(BigInteger a, BigInteger m){ BigInteger r0=m,r1=((a%m)+m)%m,t0=0,t1=1; while(r1!=0){ var q=r0/r1; (r0,r1)=(r1,r0-q*r1); (t0,t1)=(t1,t0-q*t1);} return ((t0%m)+m)%m; }
  static BigInteger LeastRealiser(List<int> e){
    int r=e.Count, E=0; foreach(var v in e) E+=v; BigInteger U=0,Pp=1; foreach(var v in e){ U=3*U+Pp; Pp*=(BigInteger.One<<v); }
    BigInteger M=BigInteger.One<<E; BigInteger x0=((-U)%M+M)%M; x0=(x0*ModInv(BigInteger.Pow(3,r),M))%M;
    for(int k=0;k<4;k++){ BigInteger x=x0+k*M; if(x<=0||x.IsEven) continue; BigInteger u=x; bool ok=true; for(int i=0;i<r;i++){ BigInteger y=3*u+1; int vv=0; while(y.IsEven){y/=2;vv++;} if(vv!=e[i]){ok=false;break;} u=y; } if(ok) return x; }
    return -1; }
  static void Main(){
    long checks=0,bad=0; 
    var pats=new List<int[]>();
    for(int s1=1;s1<=3;s1++){ pats.Add(new[]{s1}); for(int s2=1;s2<=3;s2++){ pats.Add(new[]{s1,s2}); for(int s3=1;s3<=3;s3++) pats.Add(new[]{s1,s2,s3}); } }
    foreach(var s in pats){
      BigInteger A=1,B=0,D=1; var W=new List<int>();
      foreach(int si in s){ BigInteger a=BigInteger.Pow(3,si+1), b=5*BigInteger.Pow(3,si)-(BigInteger.One<<(si+2)), d=BigInteger.One<<(si+2); A=a*A; B=a*B+b*D; D=d*D; W.Add(2); for(int j=0;j<si;j++) W.Add(1); }
      BigInteger delta=A-D;
      for(int N=1;N<=12;N++){
        var e=new List<int>{1,1,1}; for(int n=0;n<N;n++) e.AddRange(W);
        BigInteger x=LeastRealiser(e); BigInteger M=16*BigInteger.Pow(D,N);
        BigInteger xf=((-(19*delta+8*B))%M+M)%M*ModInv(27*delta,M)%M; if(xf==0) xf=M;
        BigInteger bound=(M-19*delta-8*B)/(27*delta);
        checks++; if(x!=xf || x<bound || ((27*delta*x+19*delta+8*B)%M)!=0) { bad++; Console.WriteLine($"MISMATCH s=({string.Join(",",s)}) N={N} x={x} formula={xf}"); }
      }
    }
    // concrete example (1,2): A=243,B=421,D=128
    BigInteger A2=1,B2=0,D2=1; foreach(int si in new[]{1,2}){ BigInteger a=BigInteger.Pow(3,si+1), b=5*BigInteger.Pow(3,si)-(BigInteger.One<<(si+2)), d=BigInteger.One<<(si+2); A2=a*A2; B2=a*B2+b*D2; D2=d*D2; }
    Console.WriteLine($"patterns {pats.Count}, cylinders checked {checks}, mismatches {bad}; example (1,2): A={A2} B={B2} D={D2} delta={A2-D2}");
    // K124 recurrence x_{N+2}=64 x_N+175
    var xs=new List<BigInteger>(); for(int N=1;N<=12;N++){ var e=new List<int>{1,1,1}; for(int n=0;n<N;n++){e.Add(2);e.Add(1);} xs.Add(LeastRealiser(e)); }
    bool rec=true; for(int i=0;i+2<xs.Count;i++) if(xs[i+2]!=64*xs[i]+175) rec=false; Console.WriteLine($"K124 recurrence x_(N+2)=64 x_N+175 for N=1..10: {rec}");
  }
}
