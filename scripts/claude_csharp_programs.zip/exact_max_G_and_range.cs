using System;
using System.Numerics;
// Exact maximum of G(m)=2^(L+1)/(3^r m) over odd 3<=m<=H via integer trajectories to the first arrival at 2. A double filter (margin 1e-9 >> floating error 1e-12) selects candidates; candidates are compared exactly with BigInteger cross-multiplication.
// Then the odd-count range: all prefixes with r <= r_safe satisfy G < 3/2, with Q = exact maximum, f = 1+1/(3(H+2)); r_safe = floor(0.99 * ln(1.5/Q) * 3(H+2)) (uses (1+1/N)^r <= exp(r/N), margin 1%).
class P {
  static void Main(string[] args){
    long H=long.Parse(args[0]); var sw=System.Diagnostics.Stopwatch.StartNew(); double l2=Math.Log2(3.0); double bestLg=-1; long bestM=0; int bestL=0,bestR=0; long cand=0;
    var p2=new BigInteger[2000]; var p3=new BigInteger[2000]; p2[0]=1; p3[0]=1; for(int i=1;i<2000;i++){ p2[i]=p2[i-1]*2; p3[i]=p3[i-1]*3; }
    BigInteger bn=0,bd=1; // best G = bn/bd (exact)
    checked{ for(long m=3;m<=H;m+=2){ long n=m; int L=0,r=0; while(n!=2){ if((n&1)==1){ n=(3*n+1)>>1; r++; } else n>>=1; L++; }
        double lg=(L+1)-r*l2-Math.Log2((double)m); if(lg<bestLg-1e-9) continue; cand++; BigInteger num=p2[L+1], den=p3[r]*m; if(bn.IsZero||num*bd>bn*den){ bn=num; bd=den; bestLg=lg; bestM=m; bestL=L; bestR=r; } } }
    BigInteger g=BigInteger.GreatestCommonDivisor(bn,bd); BigInteger qn=bn/g, qd=bd/g; double Q=(double)qn/(double)qd;
    Console.WriteLine($"H={H}: exact maximum of G over odd 3<=m<=H is {qn}/{qd} = {Q:F12} at m={bestM} (L={bestL}, r={bestR}); 2*Qn<3*Qd: {2*qn<3*qd}; candidates compared exactly {cand}; {sw.ElapsedMilliseconds/1000}s");
    double N=3.0*(H+2); double rmax=Math.Log(1.5/Q)*N; Console.WriteLine($"   f=1+1/{(long)N}; ln(1.5/Q)={Math.Log(1.5/Q):F10}; r_max (real) = {rmax:E4}; r_safe = {(long)(0.99*rmax)} (margin 1% on the exponent)");
  }
}
