using System;
using System.IO;
using System.Numerics;
using System.Text.Json;
using System.Collections.Generic;
// Bounded marginal test (n <= LIMIT) of the zero-tail families 1^r(01)^s 0^(k+1), k=1,2,3,4, against the E18+C110 ledger:
// baseline covered(n) = coefficient crossing within 32 steps OR finite-ledger rule OR C08 OR C85 meeting-only cylinder OR C110 class (s<=80).
class P {
  static void Main(string[] a) {
    string root = a[0]; long LIMIT = long.Parse(a[1]);
    var inv = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/targets_E18/counting_inventory_with_C110.json"))).RootElement;
    var rules = new List<(BigInteger r, BigInteger m)>();
    foreach (var z in inv.GetProperty("finite_ledger").EnumerateArray()) rules.Add((BigInteger.Parse(z.GetProperty("residue").ToString()), BigInteger.Parse(z.GetProperty("modulus").ToString())));
    var c85 = new bool[1 << 27];
    foreach (var c in JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "tmp/v2_audit/parent27_certificates.json"))).RootElement.GetProperty("certificates").EnumerateArray())
      if (c.GetProperty("meeting").ValueKind != JsonValueKind.Null && c.GetProperty("descent").ValueKind == JsonValueKind.Null) c85[c.GetProperty("n").GetInt64()] = true;
    var c08 = new List<(long r, long mask)>();
    for (int k = 1; k <= 30; k++) { BigInteger m = BigInteger.One << (k + 2), p3 = BigInteger.Pow(3, k), p2 = BigInteger.Pow(2, k);
      BigInteger r = (((-(p3 - p2) * BigInteger.ModPow(p3, (m >> 1) - 1, m)) % m) + m) % m; c08.Add(((long)r, (long)(m - 1))); }
    var c110 = new List<(BigInteger r, BigInteger m)>();
    for (int s = 0; s <= 80; s++) { int r = 2; while (!(BigInteger.Pow(3, r + s) > BigInteger.Pow(2, r + 2 * s + 1))) r++;
      BigInteger q = BigInteger.Pow(3, r + s); BigInteger inv2 = BigInteger.ModPow(BigInteger.Pow(2, 2 * s + 1), 2 * BigInteger.Pow(3, r + s - 1) - 1, q);
      c110.Add((((1 - BigInteger.Pow(3, s + 1) * inv2) % q + q) % q, q)); }
    var rl = rules.ToArray(); var cl = c110.ToArray();
    ulong[] p3t = new ulong[40]; p3t[0] = 1; for (int i = 1; i < 40; i++) p3t[i] = p3t[i - 1] * 3;
    bool Covered(long n) {
      ulong x = (ulong)n; int ones = 0;
      for (int i = 1; i <= 32; i++) { if ((x & 1) == 1) { ones++; x = (3 * x + 1) >> 1; } else x >>= 1; if (p3t[ones] < (1UL << i)) return true; }
      foreach (var u in rl) if (n % u.m == u.r) return true;
      foreach (var u in c08) if ((n & u.mask) == u.r) return true;
      if (c85[n & ((1L << 27) - 1)]) return true;
      foreach (var u in cl) if (n % u.m == u.r) return true;
      return false;
    }
    for (int k = 1; k <= 4; k++) {
      long members = 0, unc = 0; var perS = new List<string>();
      for (int s = 0; s <= 12; s++) {
        int r = 2; while (!(BigInteger.Pow(3, r + s) > BigInteger.Pow(2, r + 2 * s + 1 + k))) r++;
        BigInteger q = BigInteger.Pow(3, r + s), pk = BigInteger.Pow(2, r + 2 * s + 1 + k), p0 = BigInteger.Pow(2, r + 2 * s + 1);
        BigInteger U = q + p0 - BigInteger.Pow(2, r) * BigInteger.Pow(3, s + 1);
        BigInteger n0 = ((U % q) * BigInteger.ModPow(pk, 2 * BigInteger.Pow(3, r + s - 1) - 1, q)) % q;
        if (n0 > LIMIT) continue; long ms = 0, us = 0;
        for (BigInteger n = n0 < 1 ? q : n0; n <= LIMIT; n += q) { ms++; if (!Covered((long)n)) us++; }
        members += ms; unc += us; if (ms > 0) perS.Add($"s{s}:{us}/{ms}");
      }
      Console.WriteLine($"k={k}: family members <= {LIMIT} (s=0..12): {members}, uncovered by baseline: {unc}   [{string.Join(' ', perS)}]");
    }
  }
}
