using System;
using System.Collections.Generic;
using System.Numerics;
// Audit of ChatGPT 204556 Adaptive_Tail_Research: (a) exact recurrence (11) C_{j,r}=1[3^{r+1}>2^j](C_{j-1,r}+C_{j-1,r-1}), C_{1,1}=1, counts C_{l+1} for band l; (b) count bound (15) C_{l+1}<48/(l+3) 2^{21 l/22} (l>=6);
// (c) U^bd_J = 4(J+2)/(3*2^J) + sum_{l=J}^{511} C_{l+1}(2l+7)/(3*2^l) + 1089/2^23 for J=172,173 (claimed 0.2597336857 < 13/50 and 0.2691371220 > 4/15); (d) actual slow-source counts vs C for small bands;
// (e) greedy charging theorem (1) tested on actual trajectories; (f) the n=55 overlap: sources 63 and 71 return to 61 (gaps 34,32; resets 12,13) and both select slow state 91.
class P {
  static long A(long u,out int e){ long x=3*u+1; e=0; while((x&1)==0){x>>=1;e++;} return x; }
  static long T(long v)=> (v&1)==1? (3*v+1)/2 : v/2;
  static bool Slow(long x){ int h=0; while((1L<<h)<x) h++; // ceil(log2 x)
    long v=x; for(int j=1;j<=h;j++){ v=T(v); if(2*v<x) return false; } return true; }
  static void Main(){
    int MAXL=520; var C=new BigInteger[MAXL+2]; var prev=new BigInteger[MAXL+3]; prev[1]=1; var tot=new BigInteger[MAXL+2]; tot[1]=1;
    for(int j=2;j<=MAXL;j++){ var cur=new BigInteger[MAXL+3]; for(int r=1;r<=j;r++){ if(BigInteger.Pow(3,r+1)>(BigInteger.One<<j)){ BigInteger a=prev[r]; if(r>=1) a+=prev[r-1]; cur[r]=a; } } prev=cur; BigInteger s=0; for(int r=0;r<=j;r++) s+=cur[r]; tot[j]=s; }
    // (b)
    int bad15=0; for(int l=6;l<=511;l++){ double lhs=BigInteger.Log(tot[l+1]); double rhs=Math.Log(48.0/(l+3))+21.0*l/22*Math.Log(2); if(!(lhs<rhs)) bad15++; }
    Console.WriteLine($"(b) bound (15) C_(l+1) < 48/(l+3) 2^(21l/22) for l=6..511: violations {bad15}");
    // (c)
    foreach(int J in new[]{172,173}){ double U=4.0*(J+2)/(3*Math.Pow(2,J)); for(int l=J;l<=511;l++){ double c=Math.Exp(BigInteger.Log(tot[l+1])-l*Math.Log(2)); U+=c*(2.0*l+7)/3; } U+=1089.0/Math.Pow(2,23); Console.WriteLine($"(c) U^bd_{J} = {U:F15}   (13/50={13.0/50}, 4/15={4.0/15:F6})"); }
    // (d) actual slow sources per band vs recurrence bound
    for(int l=3;l<=22;l++){ long cnt=0; for(long x=(1L<<l)+1; x<=(1L<<(l+1)); x+=2){ if(x<3) continue; if(Slow(x)) cnt++; } if(l<=12||l==16||l==20||l==22) Console.WriteLine($"(d) band l={l}: actual slow odd sources in (2^l,2^(l+1)] = {cnt}; recurrence bound C_(l+1) = {tot[l+1]}"); }
    // (e) test (1) on actual long trajectories: odd inputs of the segment from start s until first value < s ... use segments starting at random large s, until first descent below n=s, length cap
    var rng=new Random(5); int viol=0; long tested=0; double maxRatio=0;
    for(int t=0;t<20000;t++){ long s=1+2*rng.NextInt64(1<<28); if(s<3) continue; long n=s; var inputs=new List<long>(); long v=s; int steps=0; while(v>=n && steps<5000){ if((v&1)==1) inputs.Add(v); v=T(v); steps++; }
      // greedy decomposition on the odd inputs list with shortcut-state tracking: simulate directly along the actual trajectory
      double lhs=0; foreach(long x in inputs) lhs+=1.0/(3.0*x);
      double charge=4.0*(Math.Log2(n)+2)/(3.0*n); // D(n)
      long cur=s; int pos=0; // process: walk trajectory; at each odd input decide slow/fast
      double slowCharge=0; long y=s; int stepsLeft=steps; 
      // reconstruct sequence of shortcut states
      var states=new List<long>(); long z=s; for(int i=0;i<steps+1 && z>=n;i++){ states.Add(z); z=T(z);} 
      int idx=0; while(idx<states.Count){ long x=states[idx]; if((x&1)==0){ idx++; continue; }
        if(Slow(x) && SlowOnPath(states,idx,x)){ slowCharge+=(2*Math.Log2(x)+7)/(3.0*x); idx++; }
        else { // fast: skip to first odd output below half its start
          int j=idx+1; while(j<states.Count && 2*states[j]>=x) j++; // first state below half
          idx=j; while(idx<states.Count && (states[idx]&1)==0) idx++; } }
      double rhs=charge+slowCharge; tested++; if(lhs>rhs*(1+1e-12)) viol++; maxRatio=Math.Max(maxRatio,lhs/rhs); }
    Console.WriteLine($"(e) theorem (1) on {tested} actual first-descent segments (random starts < 2^28): violations {viol}; max ratio lhs/rhs {maxRatio:F4}");
    // (f)
    long n0=55, H=(4*n0-2)/3; Console.WriteLine($"(f) n=55, H={H}");
    foreach(long u0 in new long[]{63,71}){ long x=u0; int g=0,resets=0; long minProper=long.MaxValue; var list=new List<long>{u0}; while(true){ int e; x=A(x,out e); g++; if(e>=2) resets++; list.Add(x); if(x<=H) break; if(x<minProper) minProper=x; }
      Console.WriteLine($"    source {u0}: arrival {x} (in band: {x>=n0&&x<=H}), gap {g}, resets {resets}, min proper state {minProper}, contains 91: {list.Contains(91)}"); }
    long v2=91; var tr=new List<long>{v2}; for(int j=1;j<=7;j++){ v2=T(v2); tr.Add(v2);} Console.WriteLine($"    shortcut trace from 91: {string.Join(",",tr)}; all >= 45.5: {tr.TrueForAll(q=>2*q>=91)}; Slow(91)={Slow(91)}");
  }
  static bool SlowOnPath(List<long> st,int idx,long x){ return true; }
}
