using System;
using System.Collections.Generic;
using System.Linq;
// For non-minimal n at depth K: among partners m < n with b in {a, a+1}, take the largest m (smallest delta = n - m); histogram of delta / 2^v2(n)
// (Theorem C covers delta = 2^v2(n)).  Also share of non-minimal n having some partner with delta = 2^v2(n).
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var val = new long[N + 1]; var cnt = new int[N + 1]; for (int n = 1; n <= N; n++) val[n] = n; var idx = new int[N];
    for (int K = 2; K <= 12; K++) {
      for (int n = 1; n <= N; n++) { long v = val[n]; if ((v & 1) == 1) { val[n] = (3 * v + 1) / 2; cnt[n]++; } else val[n] = v / 2; }
      if (K != 6 && K != 9 && K != 12) continue;
      for (int i = 0; i < N; i++) idx[i] = i + 1;
      Array.Sort(idx, (x, y) => { int c = val[x].CompareTo(val[y]); return c != 0 ? c : x.CompareTo(y); });
      var hist = new Dictionary<string, long>(); long nonmin = 0, withC = 0;
      for (int i = 0; i < N;) { int j = i; while (j < N && val[idx[j]] == val[idx[i]]) j++;
        for (int t = i + 1; t < j; t++) { int n = idx[t]; nonmin++; long v2 = n & -n; long bestDelta = long.MaxValue; bool hasC = false;
          for (int u = i; u < t; u++) { int m = idx[u]; int d = cnt[m] - cnt[n]; if (d == 0 || d == 1) { long delta = n - m; if (delta < bestDelta) bestDelta = delta; if (delta == v2) hasC = true; } }
          if (hasC) withC++;
          string key = bestDelta == long.MaxValue ? "none" : (bestDelta % v2 == 0 ? (bestDelta / v2).ToString() : "not-a-multiple");
          hist[key] = hist.GetValueOrDefault(key) + 1; }
        i = j; }
      var top = hist.OrderByDescending(kv => kv.Value).Take(8).Select(kv => $"{kv.Key}:{kv.Value}");
      Console.WriteLine($"K={K}: non-minimal {nonmin}; with a partner at delta=2^v2(n) (Theorem C type): {withC} ({(double)withC / nonmin:P1}); smallest-delta primitive partner, delta/2^v2(n): {string.Join(' ', top)}");
    }
  }
}
