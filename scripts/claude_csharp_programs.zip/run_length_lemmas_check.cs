using System;
using System.Collections.Generic;
// Lemmas used by the uniform long-run tail: for every maximal run (s odd inputs from a, final exponent e>=2): v2(a+1) = s exactly; run starts within one return are distinct;
// and the distribution of s among runs (long runs are rare: P(s>=k) ~ 2^-k).
class P {
  static void Main(string[] args) {
    foreach (string sn in args) {
      long n = long.Parse(sn) | 1; long H = (4 * n - 2) / 3; long runs = 0, bad = 0, dup = 0, ret = 0; long[] cs = new long[40]; int maxS = 0; long maxSu = 0;
      for (long u = n; u <= H; u += 2) {
        long x = u; int s = 0; long a = u; bool r = false; int steps = 0; var starts = new HashSet<long>(); var rl = new List<(long a, int s)>();
        while (steps < 100000) { long t = 3 * x + 1; int ev = System.Numerics.BitOperations.TrailingZeroCount((ulong)t); t >>= ev; s++; x = t; steps++;
          if (ev >= 2) { rl.Add((a, s)); s = 0; a = x; } if (x < n) break; if (x <= H) { r = true; break; } if (x > (1L << 60)) break; }
        if (!r) continue; ret++;
        foreach (var q in rl) { runs++; int v2 = System.Numerics.BitOperations.TrailingZeroCount((ulong)(q.a + 1)); if (v2 != q.s) bad++; if (!starts.Add(q.a)) dup++; cs[Math.Min(q.s, 39)]++; if (q.s > maxS) { maxS = q.s; maxSu = u; } }
      }
      string line = $"n={n}: returns={ret}, runs={runs}; v2(a+1)!=s: {bad}; repeated run starts within a return: {dup}; longest run s={maxS} (u={maxSu}); P(s>=k): ";
      long cum = 0; for (int k = 39; k >= 1; k--) { cum += cs[k]; if (k <= 8) line += $"{k}:{(double)cum / runs:E2} "; }
      Console.WriteLine(line);
    }
  }
}
