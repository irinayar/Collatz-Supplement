using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
// Rigorous exhaustive enumeration of FLAT run compositions for each cluster (L,A), plus exact D | U test.
// Block sequence (r_i >= 2, d_i >= 1), sum r = A, sum (r+d) = L, starting at a run of ones (seam-free representation).
// Rigorous pruning: for a flat word all peaks satisfy (3S+1)/5 <= p_i <= H < S, so |log2 p_i/p_j| < log2(5/3); by the exact distortion lemma
// (|log2(x_j/x_j') - (g_j - g_j')| <= eps' = L - A log2 3 for 0 <= j,j' < L) the peak heights g_{p_i} of the word-walk span at most W = log2(5/3) + eps'.
static class P {
  static int L, A; static double W, TH = Math.Log2(1.5), L23 = Math.Log2(3);
  static List<int> R = new(), Dd = new(); static long nodes = 0, cands = 0, flat = 0, intFix = 0; static long[] byK = new long[40];
  static BigInteger D;
  static void Main(string[] args) {
    int Lmin = int.Parse(args[0]), Lmax = int.Parse(args[1]); bool verbose = args.Length > 2;
    for (L = Lmin; L <= Lmax; L++) {
      long flatL = 0, candL = 0, nodesL = 0; int clusters = 0;
      for (A = 2; A < L; A++) {
        BigInteger p2 = BigInteger.One << L, p3 = BigInteger.Pow(3, A); if (p3 >= p2) continue; D = p2 - p3; double eps = L - A * L23; W = Math.Log2(5.0 / 3.0) + eps;
        if (A < 2 || L - A < 1) continue; nodes = 0; cands = 0; flat = 0; R.Clear(); Dd.Clear();
        Dfs(0, 0, 0.0, 1e9, -1e9);
        flatL += flat; candL += cands; nodesL += nodes; if (flat > 0) clusters++;
        if (verbose && flat > 0) Console.WriteLine($"   (L={L},A={A}) eps'={eps:F3}: candidates {cands}, flat {flat}, nodes {nodes}");
      }
      Console.WriteLine($"L={L}: flat words {flatL} (candidates passing window {candL}, DFS nodes {nodesL}); integer fixed points so far {intFix}");
    }
    Console.WriteLine("flat words by number of excursions k: " + string.Join(" ", byK.Select((v, i) => (v, i)).Where(t => t.v > 0).Select(t => $"k{t.i}:{t.v}")));
  }
  // lUsed, aUsed: letters and ones so far; hPeak: g at the last peak vertex; mn, mx: min/max of peak heights so far; blocks appended in R/Dd
  static void Dfs(int lUsed, int aUsed, double hPrevAfterDesc, double mn, double mx) {
    nodes++;
    int k = R.Count;
    for (int r = 2; aUsed + r <= A; r++) {
      for (int d = 1; lUsed + r + d <= L; d++) {
        // peak vertex index = lUsed + r (before the d zeros); height g = (aUsed + r) log2 3 - (lUsed + r)
        double g = (aUsed + r) * L23 - (lUsed + r);
        double nmn = Math.Min(mn, g), nmx = Math.Max(mx, g); if (nmx - nmn > W + 1e-9) continue;
        int la = lUsed + r + d, aa = aUsed + r;
        int aRem = A - aa, zRem = (L - A) - (la - aa);
        if (aRem == 0 && zRem != 0) continue; if (aRem != 0 && (aRem < 2 || zRem < 1)) continue; if (zRem < 0) continue;
        R.Add(r); Dd.Add(d);
        if (aRem == 0 && zRem == 0) Check(); else Dfs(la, aa, 0, nmn, nmx);
        R.RemoveAt(R.Count - 1); Dd.RemoveAt(Dd.Count - 1);
      }
    }
  }
  static bool Canonical(int k) {
    for (int s = 1; s < k; s++) { int cmp = 0; for (int i = 0; i < k && cmp == 0; i++) { int a = R[i], b = R[(i + s) % k]; if (a != b) cmp = a < b ? -1 : 1; else { a = Dd[i]; b = Dd[(i + s) % k]; if (a != b) cmp = a < b ? -1 : 1; } } if (cmp >= 0) return false; }
    return true;
  }
  static void Check() {
    int k = R.Count; if (!Canonical(k)) return; cands++;
    var e = new bool[L]; int pos = 0; var aIdx = new int[k]; var bIdx = new int[k];
    for (int i = 0; i < k; i++) { for (int j = 0; j < R[i]; j++) e[pos++] = true; aIdx[i] = pos - 1; for (int j = 0; j < Dd[i]; j++) e[pos++] = false; bIdx[i] = pos - 1; }
    BigInteger U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + (BigInteger.One << i);
    BigInteger scale = D * (BigInteger.One << L); var X = new BigInteger[L]; X[0] = U * (BigInteger.One << L);
    for (int i = 0; i + 1 < L; i++) X[i + 1] = (e[i] ? 3 * X[i] + scale : X[i]) / 2;
    if (X.Distinct().Count() < L) return; BigInteger c = X.Min(), H = X.Max(), S = c + H; if (c < scale) return;
    for (int i = 0; i < k; i++) { int a = aIdx[i], p = (a + 1) % L, b = bIdx[i]; if (!(X[a] + X[p] > S && 3 * X[b] < 2 * S)) return; }
    flat++; byK[Math.Min(k, 39)]++; if ((U % D).IsZero) { intFix++; Console.WriteLine($"INTEGER FIXED POINT? L={L} A={A} word k={k}: U/D={U / D}"); }
  }
}
