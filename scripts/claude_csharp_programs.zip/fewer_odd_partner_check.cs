using System;
// Check of Codex's bound: a smaller partner with FEWER odd steps (b < a) can exist only for n < 2^j (j = K-1 steps).
class P {
  static void Main(string[] a) {
    int N = int.Parse(a[0]); var val = new long[N + 1]; var cnt = new int[N + 1]; for (int n = 1; n <= N; n++) val[n] = n; var idx = new int[N];
    for (int K = 2; K <= 14; K++) {
      for (int n = 1; n <= N; n++) { long v = val[n]; if ((v & 1) == 1) { val[n] = (3 * v + 1) / 2; cnt[n]++; } else val[n] = v / 2; }
      for (int i = 0; i < N; i++) idx[i] = i + 1;
      Array.Sort(idx, (x, y) => { int c = val[x].CompareTo(val[y]); return c != 0 ? c : x.CompareTo(y); });
      int maxFewer = 0; long fewer = 0;
      for (int i = 0; i < N;) { int j = i; while (j < N && val[idx[j]] == val[idx[i]]) j++; int minCnt = cnt[idx[i]];
        for (int t = i + 1; t < j; t++) { int n = idx[t]; if (minCnt < cnt[n]) { fewer++; if (n > maxFewer) maxFewer = n; } if (cnt[n] < minCnt) minCnt = cnt[n]; } i = j; }
      Console.WriteLine($"K={K,2} (j={K - 1}): starts with a smaller partner of FEWER odd steps: {fewer}; largest such n = {maxFewer}; 2^j = {1 << (K - 1)}; bound holds: {maxFewer < (1 << (K - 1)) || fewer == 0}");
    }
  }
}
