using System; using System.Numerics;
// Exact constants of the conditional closing bridge (ChatGPT 18:56, 2026-11-23).
class P { struct F { public BigInteger n,d; public F(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(BigInteger.Abs(a),b); if(g.IsZero)g=1; n=a/g; d=b/g; if(d.Sign<0){n=-n;d=-d;} }
  public static F operator+(F x,F y)=>new F(x.n*y.d+y.n*x.d,x.d*y.d); public static F operator*(F x,F y)=>new F(x.n*y.n,x.d*y.d); public static bool operator<(F x,F y)=>x.n*y.d<y.n*x.d; public static bool operator>(F x,F y)=>x.n*y.d>y.n*x.d; public override string ToString()=>n+"/"+d; }
 static F Fr(long a,long b)=>new F(a,b);
 static void Main(){
  F a=Fr(3000,2797)*Fr(4899,3904); Console.WriteLine("3000/2797*4899/3904 = "+a+" (claimed 1837125/1364936: "+(a.n==1837125&&a.d==1364936)+")");
  F w=Fr(3000,2797)*Fr(116073,3904000)+Fr(8850,170617); Console.WriteLine("(3): "+w+" = 327/3904: "+(w.n==327&&w.d==3904));
  F b=Fr(488,375)*Fr(327,3904)+Fr(59,1000); Console.WriteLine("(4) at W_C=327/3904: "+b+" = 21/125: "+(b.n==21&&b.d==125));
  Console.WriteLine("(5): 21/125+9/125 = "+(Fr(21,125)+Fr(9,125))+"; (8): 6/25+111/2500 = "+(Fr(6,25)+Fr(111,2500)));
  // e^(711/2500) < 4/3 : series enclosure: sum_{k<=K} x^k/k! + x^(K+1)/(K+1)! * 1/(1-x/(K+2))
  F x=Fr(711,2500); F sum=Fr(1,1), term=Fr(1,1); int K=20; for(int k=1;k<=K;k++){ term=term*x*Fr(1,k); sum=sum+term; } F tail=term*x*Fr(1,K+1)*Fr(1,1); // upper bound of tail <= term*x/(K+1) /(1-x/(K+2))
  F upper=sum+tail*Fr(1,1)*new F(1,1)*new F(K+2, K+2)*Fr(1,1)*(new F(1,1)); // loose: multiply by 1/(1-x/(K+2)) <= 1.01
  upper=sum+tail*Fr(101,100); Console.WriteLine("e^(711/2500) <= "+(double)upper.n/(double)upper.d+" < 4/3: "+(upper<Fr(4,3)));
  // 2 e^{-711/2500} > 3/2 and ~1.50493: e^{-x} >= 1 - x + x^2/2 - x^3/6 (alternating, lower bound with odd truncation)
  F lowE=Fr(1,1)+Fr(-711,2500)+Fr(711,2500)*Fr(711,2500)*Fr(1,2)+Fr(-1,6)*Fr(711,2500)*Fr(711,2500)*Fr(711,2500); F r=Fr(2,1)*lowE; Console.WriteLine("2*e^(-711/2500) >= "+(double)r.n/(double)r.d+" > 3/2: "+(r>Fr(3,2)));
  // (19): (2/3)(4/3)=8/9 ; 8/9 (n+5) < 9/10 n for n>=2^71+1
  BigInteger n=(BigInteger.One<<71)+1; Console.WriteLine("(19): 80(n+5) < 81 n at n=2^71+1: "+(80*(n+5)<81*n)+"; 2/3*367/250 = "+Fr(2,3)*Fr(367,250)+" = 367/375");
  Console.WriteLine("L ln2 - r ln3 < 711/2500 => 3^r/2^L > e^(-711/2500) > 3/4 ? e^(-0.2844)="+Math.Exp(-0.2844).ToString("F5")+" > 0.75: "+(Math.Exp(-0.2844)>0.75)+"; 2e^{-711/2500}="+(2*Math.Exp(-0.2844)).ToString("F10"));
 }}
