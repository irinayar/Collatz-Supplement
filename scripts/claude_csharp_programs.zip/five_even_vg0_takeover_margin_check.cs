using System;
using System.Collections.Generic;
using System.Numerics;
// Five-even, valuation-one case x=3u-1, u=1 mod 3, v3(G)=0 i.e. w=2 mod 3: P_s=H_3(6w-1,s), Q_s=H_4(3w-1,s), s>=1; min(P,Q)=H_5 tail.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long take=0,bad=0,contrBad=0; BigInteger minGap=-1, minP=-1; var byS=new SortedDictionary<int,long>(); var kinds=new SortedDictionary<string,long>();
    for(int w=2;w<=6000;w+=3){ BigInteger W=w; for(int s=1;s<=30;s++){ var Pv=H(6*W-1,3,s); var Qv=H(3*W-1,4,s); var Pn=H(6*W-1,3,s+1); var Qn=H(3*W-1,4,s+1);
        if(Qv!=INF&&Qn==INF&&Pn!=INF){ take++; byS[s]=byS.GetValueOrDefault(s)+1; var g=Qv-Pn; if(!(g>0)) bad++; if(minGap==-1||g<minGap) minGap=g; if(minP==-1||Pv<minP) minP=Pv;
          string kind="none"; for(int c=0;c<=8;c++){ if(3*(Pn+c)==2*(Pv+c)){ kind="c="+c; break; } } kinds[kind]=kinds.GetValueOrDefault(kind)+1; if(!(3*Pn<=2*Pv)) contrBad++; } } hm.Clear(); }
    Console.WriteLine("Q ends and P continues: " + take + " takeovers; failures of P_(s+1)<Q_s: " + bad + "; min gap " + minGap + "; min P_s at takeover " + minP + "; failures of P_(s+1)<=2P_s/3: " + contrBad);
    Console.WriteLine("takeover index s_Q: " + string.Join(", ",byS) + "; P step form 3(P_next+c)=2(P+c): " + string.Join(", ",kinds));
  }
}
