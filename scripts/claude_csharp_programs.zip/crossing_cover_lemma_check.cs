using System;
using System.Collections.Generic;
using System.Linq;
// Verify the covering-count lemma for the upper arc:
//  c(u) = #{ascent chords (a,a') with a < u < a'} = #heads<=u - #tails<u - 1  for every odd vertex u,
//  every tail except the maximal odd vertex and every head except the minimum c is covered (c>=1), and
//  AP = sum over tails c, AV = sum over heads c, AA = sum over chord starts c  (counted by brute-force interleaving of endpoints).
static class P {
  static void Main(string[] args) {
    int Lmax = int.Parse(args[0]); long words = 0, formulaBad = 0, lemmaBad = 0, apBad = 0, avBad = 0, aaBad = 0, ineqBad = 0;
    for (int L = 4; L <= Lmax; L++) {
      Int128 p2 = (Int128)1 << L;
      for (long w = 1; w < (1L << L) - 1; w++) {
        bool canon = true; for (int r = 1; r < L && canon; r++) { long rot = ((w << r) | (w >> (L - r))) & ((1L << L) - 1); if (rot <= w) canon = false; } if (!canon) continue;
        int A = System.Numerics.BitOperations.PopCount((ulong)w); Int128 p3 = 1; for (int i = 0; i < A; i++) p3 *= 3; if (p3 >= p2) continue;
        bool[] e = new bool[L]; for (int i = 0; i < L; i++) e[i] = ((w >> i) & 1) == 1;
        Int128 U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + ((Int128)1 << i);
        Int128 D = p2 - p3, scale = D * p2; var X = new Int128[L]; X[0] = U * p2; for (int i = 0; i + 1 < L; i++) X[i + 1] = e[i] ? (3 * X[i] + scale) / 2 : X[i] / 2;
        if (X.Distinct().Count() < L || X.Min() < scale) continue; words++;
        var odd = Enumerable.Range(0, L).Where(i => e[i]).ToList(); int k = 0, h = 0;
        bool Head(int i) => !e[(i + L - 1) % L]; bool Tail(int i) => !e[(i + 1) % L];
        for (int i = 0; i < L; i++) if (e[i] && Head(i)) { int r = 0, j = i; while (e[j % L]) { r++; j++; } k++; if (r >= 2) h++; }
        // cover counts
        Func<int, int> cover = u => odd.Count(a => !Tail(a) && X[a] < X[u] && X[u] < X[(a + 1) % L]);
        Func<int, int> formula = u => odd.Count(a => Head(a) && X[a] <= X[u]) - odd.Count(a => Tail(a) && X[a] < X[u]) - 1;
        int uMax = odd.OrderByDescending(i => X[i]).First(), uMin = odd.OrderBy(i => X[i]).First();
        long ap = 0, av = 0, aa = 0;
        foreach (var u in odd) { int cv = cover(u); if (cv != formula(u)) formulaBad++; if (Tail(u)) { ap += cv; if (cv == 0 && u != uMax) lemmaBad++; } if (Head(u)) { av += cv; if (cv == 0 && u != uMin) lemmaBad++; } if (!Tail(u)) aa += cv; }
        // brute-force crossings of chord types by interleaving of endpoint ranks
        var oddSorted = odd.OrderBy(i => X[i]).ToList(); var rank = new int[L]; for (int q = 0; q < oddSorted.Count; q++) rank[oddSorted[q]] = q; int evenBase = oddSorted.Count; var evenSorted = Enumerable.Range(0, L).Where(i => !e[i]).OrderByDescending(i => X[i]).ToList(); for (int q = 0; q < evenSorted.Count; q++) rank[evenSorted[q]] = evenBase + q;
        long ap2 = 0, av2 = 0, aa2 = 0;
        for (int i = 0; i < L; i++) for (int j = i + 1; j < L; j++) { if (j == i + 1 || (i == 0 && j == L - 1)) continue; double pa = rank[i], pb = rank[(i + 1) % L], qa = rank[j], qb = rank[(j + 1) % L]; double lo = Math.Min(pa, pb), hi = Math.Max(pa, pb); bool inA = qa > lo && qa < hi, inB = qb > lo && qb < hi; if (inA == inB) continue;
          string t1 = e[i] ? (e[(i + 1) % L] ? "A" : "P") : (e[(i + 1) % L] ? "V" : "D"), t2 = e[j] ? (e[(j + 1) % L] ? "A" : "P") : (e[(j + 1) % L] ? "V" : "D"); string key = string.Compare(t1, t2) <= 0 ? t1 + t2 : t2 + t1;
          if (key == "AP") ap2++; else if (key == "AV") av2++; else if (key == "AA") aa2++; }
        if (ap != ap2) apBad++; if (av != av2) avBad++; if (aa != aa2) aaBad++;
        if (ap < k - 1 || av < k - 1 || aa < h - 1 || ap + av + aa < 2 * k + h - 3) ineqBad++;
      }
    }
    Console.WriteLine($"words (values>=1) {words}: formula c(u)=heads<=u - tails<u - 1 violations {formulaBad}; uncovered tails/heads other than a_max / c: {lemmaBad}; AP via covers != brute force {apBad}, AV {avBad}, AA {aaBad}; AP>=k-1, AV>=k-1, AA>=h-1, AP+AV+AA>=2k+h-3 violations {ineqBad}");
  }
}
