using System; using System.Numerics; using System.Collections.Generic;
// Zero-entry-credit gate example (ChatGPT, Zero_Entry_Credit_Gate.md): replay the profile with exact integers.
class P { static void Main(){
 BigInteger n=BigInteger.Parse("254980286039903385919345163621024477417072911"), u=BigInteger.Parse("339973714719871181225793551494699303222763879"), w0=BigInteger.Parse("319698234985890129278678153687356418300645471"), Pst=BigInteger.Parse("3061039095080021003991398899074708937957"), y0=BigInteger.Parse("478547038884135474924175305130007818518610015");
 BigInteger H=(4*n-2)/3; // B = 5 + n/(100000 P*) as exact rational Bn/Bd
 BigInteger Bn=5*100000*Pst+n, Bd=100000*Pst; Console.WriteLine("B ~ " + (double)(Bn*BigInteger.Pow(10,12)/Bd)/1e12);
 BigInteger x=u, C=0; int E=0,g=0; bool allProper=true, distinct=true; var seen=new HashSet<BigInteger>{u}; bool gate=false; int gateG=0,gateE=0; BigInteger gateY=0, gateC=0; BigInteger runStart=u; int runLen=0; int runs=0; int stepsTotal=0; var creditsPos=0; bool anyCreditBeforeGate=false; BigInteger endW=0;
 var runStarts=new List<(BigInteger a,int s,int e,BigInteger b)>();
 while(true){ BigInteger t=3*x+1; int e=0; while(t.IsEven){t>>=1;e++;} C=3*C+(BigInteger.One<<E); E+=e; g++; stepsTotal+=e; runLen++;
   if(e>=2){ runStarts.Add((runStart,runLen,e,t)); runs++; runStart=t; runLen=0; if(!gate){ BigInteger p3=BigInteger.Pow(3,g); if(C*Bd>Bn*p3){ gate=true; gateG=g; gateE=E; gateY=t; gateC=C; } } }
   x=t; if(x<=H){ endW=x; break; } if(!seen.Add(x)) distinct=false; if(x<=H) allProper=false; if(g>2000) break; }
 Console.WriteLine($"odd transitions={g}, shortcut steps={stepsTotal}, endpoint matches: {endW==w0}, endpoint in [n,H]: {endW>=n&&endW<=H}, distinct inputs: {distinct}");
 Console.WriteLine($"gate depth={gateG} (claimed 47), E={gateE} (claimed 74), y matches: {gateY==y0}, runs through gate={runStarts.FindIndex(r=>r.b==gateY)+1}");
 Console.WriteLine($"phase numerator C_g = {gateC}; claimed 160515429349586557615987: {gateC==BigInteger.Parse("160515429349586557615987")}; 3^47 = {BigInteger.Pow(3,47)}");
 // credits of runs through the gate: c>0 iff 15*3^s*(a-b) > (3^s-2^s)*b
 int idx=0; bool zero=true; var types=new List<string>(); foreach(var r in runStarts){ BigInteger a=r.a,b=r.b; BigInteger t3=BigInteger.Pow(3,r.s), t2=BigInteger.Pow(2,r.s); bool pos = 15*t3*(a-b) > (t3-t2)*b; types.Add($"({r.s},{r.e})"+(pos?"+":"")); idx++; if(b==gateY) break; if(pos) zero=false; }
 Console.WriteLine("run types through the gate: " + string.Join(" ",types) + "; all credits zero up to and including the gate run: " + zero);
 Console.WriteLine("C-type inequality 13/243 < 211/3645: " + (13*3645 < 211*243));
}}
