using System;
using System.Numerics;
// Check: U = sum over maximal odd runs (start position s, length r, number of odd letters after the run n) of 3^n 2^s (3^r - 2^r)
static class P {
  static void Main() {
    var rng = new Random(7); long bad = 0, tested = 0;
    for (int it = 0; it < 20000; it++) {
      int L = rng.Next(4, 80); var e = new bool[L]; for (int i = 0; i < L; i++) e[i] = rng.Next(2) == 1;
      BigInteger U = 0; for (int i = 0; i < L; i++) if (e[i]) U = 3 * U + (BigInteger.One << i);
      BigInteger V = 0; int A = 0; for (int i = 0; i < L; i++) if (e[i]) A++;
      int after = A; int pos = 0;
      while (pos < L) { if (!e[pos]) { pos++; continue; } int s = pos, r = 0; while (pos < L && e[pos]) { r++; pos++; } after -= r; V += BigInteger.Pow(3, after) * (BigInteger.One << s) * (BigInteger.Pow(3, r) - BigInteger.Pow(2, r)); }
      tested++; if (U != V) bad++;
    }
    Console.WriteLine($"run-formula identity: tested {tested} random linear words, mismatches {bad}");
  }
}
