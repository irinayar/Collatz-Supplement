using System;
using System.Numerics;
// ChatGPT 102807: global b-block constants B_b (H=1023), induction for large starts, Q, and the cutoff r<=792 of G <= Q * B_6^floor(r/6) * B_(r mod 6). Own exact-fraction implementation.
class P {
  struct Fr { public BigInteger n,d; public Fr(BigInteger a,BigInteger b){ var g=BigInteger.GreatestCommonDivisor(a,b); n=a/g; d=b/g; } public static Fr operator*(Fr a,Fr b)=>new Fr(a.n*b.n,a.d*b.d); public static bool Gt(Fr a,Fr b)=>a.n*b.d>b.n*a.d; public static bool Ge(Fr a,Fr b)=>a.n*b.d>=b.n*a.d; public override string ToString()=>n+"/"+d; }
  static long F(long u){ long t=3*u+1; while((t&1)==0) t>>=1; return t; }
  static void Main(){
    const long H=1023, W=200001; var B=new Fr[7]; B[0]=new Fr(1,1); var arg=new long[7];
    for(int b=1;b<=6;b++){ Fr best=new Fr(1,1); long am=0;
      for(long u=H+2;u<W;u+=2){ long cur=u; Fr prod=new Fr(1,1); bool ok=true; for(int i=0;i<b;i++){ if(cur<=H){ ok=false; break; } prod=prod*new Fr(3*cur+1,3*cur); cur=F(cur); } if(!ok) continue; if(Fr.Gt(prod,best)){ best=prod; am=u; } }
      Fr tail=new Fr(3*W+1,3*W)*B[b-1]; bool induct=!Fr.Gt(tail,best); B[b]=best; arg[b]=am; Console.WriteLine($"B_{b} = {best} at start {am}; induction f(200001)*B_{b-1} <= B_{b}: {induct}"); }
    BigInteger qn=BigInteger.Pow(2,61), qd=BigInteger.Pow(3,32)*993; Fr Q=new Fr(qn,qd); long q0=0; for(long u=3;u<=H;u+=2){ BigInteger n=u; Fr G=new Fr(1,1); Fr bestU=new Fr(1,1); while(n!=2&&n!=1){ if(!n.IsEven){ G=G*new Fr(3*n+1,3*n); n=(3*n+1)/2; if(Fr.Gt(G,bestU)) bestU=G; } else n/=2; } if(Fr.Gt(bestU,new Fr(Q.n,Q.d))){ q0=u; } }
    Console.WriteLine($"Q = {Q} exceeded by some start <=1023: {q0!=0}");
    Fr three2=new Fr(3,2); int firstBad=-1; for(int r=0;r<=2000;r++){ int blocks=r/6, rem=r%6; Fr C=new Fr(1,1); for(int i=0;i<blocks;i++) C=C*B[6]; C=C*B[rem]; Fr bound=Q*C; if(Fr.Ge(bound,three2)){ firstBad=r; break; } }
    Console.WriteLine($"first r with Q*B_6^floor(r/6)*B_(r mod 6) >= 3/2: {firstBad} (ChatGPT: safe through 792, fails at 793)");
  }
}
