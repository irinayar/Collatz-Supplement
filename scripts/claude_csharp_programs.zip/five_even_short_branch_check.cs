using System;
using System.Collections.Generic;
using System.Numerics;
// Check of ChatGPT 150434: five-even branches l=a-2 (short), a-1, a of H_5(x,r), x+1=3^a u, a>=2, r>=a.
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long fcells=0,fbad=0,bcells=0,bbad=0,soleShort=0,overlap=0,shortWins=0,ties=0,mono=0,series=0,l5bad=0;
    for(int a=2;a<=8;a++) for(int u=1;u<=1500;u++){ if(u%3==0) continue; if(a>=7&&u>400) continue; BigInteger x=B3(a)*u-1;
      BigInteger Y=9*B2(a-1)*u-2; BigInteger T=3*B2(a)*u-1; BigInteger D=16*T-5; int vD=V3(D);
      BigInteger Ya1=2*(B2(a-1)*B3(1)*u-1), Ya=2*(B2(a)*u-1);
      // boundary comparison at r=a
      var m0=H(Y,4,2); var m1=H(Ya1,4,1); var m2=H(Ya,4,0); bcells++; if(m0!=B2(a+5)*u-15||m1!=B2(a+5)*u-24||m2!=B2(a+5)*u-32) bbad++;
      for(int s=0;s<=vD+3;s++){ BigInteger f= s==0?24*T-8 : s==1?16*T-8 : s<=1+vD? B2(s-1)*D/B3(s-1)-1 : INF; fcells++; if(H(Y,4,s)!=f) fbad++; }
      BigInteger prev=INF; for(int r=0;r<=a+16;r++){ var h5=H(x,5,r); if(h5==INF) break; if(prev!=INF&&!(h5<prev)) mono++; prev=h5; }
      series++;
      for(int r=a;r<=a+16;r++){ var s0=H(Y,4,r-a+2); var s1=H(Ya1,4,r-a+1); var s2=H(Ya,4,r-a); // ell=a-2,a-1,a: counts r-(a-2), r-(a-1), r-a
        var h5=H(x,5,r); BigInteger direct=INF; foreach(var c in new[]{s0,s1,s2}) if(c!=INF&&(direct==INF||c<direct)) direct=c; if(direct!=h5) l5bad++;
        bool longer=(s1!=INF)||(s2!=INF); if(s0!=INF){ if(longer){ overlap++; BigInteger ml=INF; if(s1!=INF) ml=s1; if(s2!=INF&&(ml==INF||s2<ml)) ml=s2; if(s0<ml) shortWins++; else if(s0==ml) ties++; } else soleShort++; } }
      if(hm.Count>3000000) hm.Clear(); }
    Console.WriteLine($"short-branch H_4(Y,s) formula: {fcells} cells, failures {fbad}; boundary minima at r=a (2^(a+5)u-15/-24/-32): {bcells} cases, failures {bbad}; H_5 = min of the three branches (r>=a): failures {l5bad}; five-even strict monotonicity: {series} series, violations {mono}; overlap cases (short and a longer branch feasible) {overlap}: short smaller {shortWins}, ties {ties}; short sole survivor {soleShort}");
  }
}
