using System;
using System.Collections.Generic;
// Check of Codex 132034 (K082): for h = 4, the seven rows (e, z mod 81, suffix v): every length-(b+e) word with b odd symbols and numerator V = 2^(b+e) z (mod 81)
// is the single word 1^(b-4) v (and its numerator is 3^b + 2^(b-4) (V_v - 81)).  Brute force over all words for each b.
class P {
  static ulong Pow(ulong a, int n) { ulong r = 1; for (int i = 0; i < n; i++) r *= a; return r; }
  static ulong Num(string w) { int b = 0; foreach (char c in w) if (c == '1') b++; ulong V = 0; int h = 0; for (int i = 0; i < w.Length; i++) if (w[i] == '1') { h++; V += Pow(2, i) * Pow(3, b - h); } return V; }
  static void Main() {
    var rows = new (int e, int z, string v)[] { (1, 40, "11110"), (4, 67, "10100110"), (5, 7, "110101000"), (5, 31, "101010010"), (6, 16, "1011100000"), (6, 25, "1101100000"), (6, 61, "1010101000") };
    long checks = 0, bad = 0;
    foreach (var (e, z, v) in rows) {
      ulong Vv = Num(v); long A = (long)Vv - 81;
      for (int b = 4; b <= 22; b++) {
        int t = b + e; double comb = 1; for (int i = 0; i < e; i++) comb = comb * (t - i) / (i + 1); if (comb > 2.2e6) break;
        ulong B81 = Pow(2, 0) * 1; ulong pw = 1; for (int i = 0; i < t; i++) pw = (pw * 2) % 81; B81 = (pw * (ulong)z) % 81;
        var match = new List<string>(); var idx = new int[e];
        // enumerate all choices of e even positions among t (combinations)
        for (int i = 0; i < e; i++) idx[i] = i;
        while (true) {
          var chars = new char[t]; for (int i = 0; i < t; i++) chars[i] = '1'; for (int i = 0; i < e; i++) chars[idx[i]] = '0'; var w = new string(chars);
          if (Num(w) % 81 == B81) match.Add(w);
          int k = e - 1; while (k >= 0 && idx[k] == t - e + k) k--; if (k < 0) break; idx[k]++; for (int j = k + 1; j < e; j++) idx[j] = idx[j - 1] + 1; }
        string expect = new string('1', b - 4) + v; checks++;
        bool ok = match.Count == 1 && match[0] == expect && (long)Num(expect) == (long)Pow(3, b) + (long)Pow(2, b - 4) * A;
        if (!ok) bad++;
      } }
    Console.WriteLine($"K082 singleton classification: {rows.Length} rows, {checks} (row, b) cases (b = 4..22 while C(b+e,e) <= 2.2e6), each by exhaustive enumeration of all words; failures {bad}");
  }
}
