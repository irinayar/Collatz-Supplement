using System;
// Terras-type model of the first-return statistics (n -> infinity): odd-to-odd map x' = 3x/2^e, P(e=k)=2^-k, start x0 ~ U[1,4/3] (units of n);
// stop when x' < 1 (fail) or x' in [1,4/3] (return). Estimates P(return), W = (1/6) E[sum over runs (1-(2/3)^s)/a ; return], runs per return.
class P {
  static void Main(string[] args) {
    long N = long.Parse(args[0]); var rng = new Random(12345); long ret = 0; double W = 0; long runsTot = 0;
    for (long i = 0; i < N; i++) {
      double x = 1.0 + (1.0 / 3.0) * rng.NextDouble(); int s = 0; double a = x; double w = 0; int runs = 0; bool ok = false;
      for (int step = 0; step < 100000; step++) {
        int e = 1; while (rng.NextDouble() < 0.5) e++; s++; double xn = 3 * x / Math.Pow(2, e);
        if (e >= 2) { double z = Math.Pow(2.0 / 3, s); w += (1 - z) / a; runs++; s = 0; a = xn; }
        x = xn; if (x < 1) break; if (x <= 4.0 / 3) { ok = true; break; }
      }
      if (ok) { ret++; W += w; runsTot += runs; }
    }
    Console.WriteLine($"trials={N}: P(return)={(double)ret / N:F4}; W=(1/6)E[sum delta;return]={W / N / 6:F5}; runs per return={(double)runsTot / ret:F3}");
  }
}
