using System;
using System.Collections.Generic;
using System.Linq;
static class P {
  static long S(long n) => (n & 1) == 0 ? n / 2 : (3 * n + 1) / 2;
  static void Main() {
    var st = new SortedDictionary<int, (long cnt, double wmin, double wmax, double rmin, double rmax)>();
    long N = 20000;
    for (long n0 = 3; n0 <= N; n0++) {
      var xs = new List<long> { n0 }; long x = n0; while (x != 1) { x = S(x); xs.Add(x); }
      int m = xs.Count; long c = 1, H = xs.Max(); if (H == c) continue;
      double mid = (c + H) / 2.0;
      var px = new double[m]; var py = new double[m];
      for (int i = 0; i < m; i++) { double yy = Math.Sqrt(Math.Max((double)(xs[i] - c) * (H - xs[i]), 0)); px[i] = xs[i]; py[i] = (xs[i] == c || xs[i] == H) ? 0 : ((xs[i] & 1) == 1 ? yy : -yy); }
      double W = 0, R = 0; int k = 0;
      for (int i = 0; i + 1 < m; i++) {
        double ax = px[i] - mid, ay = py[i], bx = px[i + 1] - mid, by = py[i + 1];
        W += Math.Atan2(ax * by - ay * bx, ax * bx + ay * by);
        if (i + 2 < m) { double d1x = px[i + 1] - px[i], d1y = py[i + 1] - py[i], d2x = px[i + 2] - px[i + 1], d2y = py[i + 2] - py[i + 1]; R += Math.Atan2(d1x * d2y - d1y * d2x, d1x * d2x + d1y * d2y); }
        if ((xs[i] & 1) == 1 && (xs[i + 1] & 1) == 0) k++;
      }
      W /= 2 * Math.PI; R /= 2 * Math.PI;
      st.TryGetValue(k, out var v); st[k] = v.cnt == 0 ? (1, W, W, R, R) : (v.cnt + 1, Math.Min(v.wmin, W), Math.Max(v.wmax, W), Math.Min(v.rmin, R), Math.Max(v.rmax, R));
    }
    Console.WriteLine("open trajectory of n down to 1; circle with diameter [1, max]; k = number of peaks");
    foreach (var kv in st.Where(kv => kv.Key <= 14)) Console.WriteLine($"k={kv.Key,2}: trajectories {kv.Value.cnt,6}  winding {kv.Value.wmin,7:F2} .. {kv.Value.wmax,7:F2}   rotation {kv.Value.rmin,7:F2} .. {kv.Value.rmax,7:F2}");
  }
}
