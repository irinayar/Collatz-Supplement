using System;
using System.Collections.Generic;
using System.Numerics;
// ChatGPT 162455: six-even, x=3u-1, u=2 mod 3. Plus data for u=1 mod 3 (branches P_r=H_5(6u-2,r), Q_r=H_5(4u-2,r-1)).
class P {
  static BigInteger B3(int e)=>BigInteger.Pow(3,e); static BigInteger B2(int e)=>BigInteger.Pow(2,e);
  static int V3(BigInteger n){int c=0; while((n%3).IsZero){n/=3;c++;} return c;}
  static Dictionary<(BigInteger,int,int),BigInteger> hm=new(); static BigInteger INF=BigInteger.MinusOne;
  static BigInteger H(BigInteger x,int k,int r){ if(r<0) return INF; int a=V3(x+1);
    if(k==0) return r<=a ? B2(r)*(x+1)/B3(r)-1 : INF;
    if(hm.TryGetValue((x,k,r),out var v)) return v; BigInteger best=INF;
    for(int l=0;l<=Math.Min(a,r);l++){ var y=B2(l)*(x+1)/B3(l)-1; var t=H(2*y,k-1,r-l); if(t!=INF&&(best==INF||t<best)) best=t; } hm[(x,k,r)]=best; return best; }
  static void Main(){
    long c2=0,bad2=0,mono2=0; 
    for(int u=2;u<=6000;u+=3){ BigInteger U=u, x=3*U-1; c2++; bool ok=true;
      if(H(x,6,0)!=192*U-64) ok=false;
      var Q1=H(4*U-2,5,0); var Pn1=H(6*U-2,5,1); var P2=H(6*U-2,5,2);
      if(H(4*U-2,5,1)!=INF) ok=false; // R_5(B)=0 : Q_2 is H_5(B,1)
      if(Q1!=128*U-64) ok=false; if(Pn1!=128*U-48) ok=false; if(P2!=(256*U-104)/3) ok=false; if(!(Pn1-Q1==16)) ok=false; if(!(Q1>P2)) ok=false;
      BigInteger prev=INF; for(int r=0;r<=40;r++){ var h=H(x,6,r); if(h==INF) break; if(prev!=INF&&!(h<prev)) mono2++; prev=h; }
      if(!ok) bad2++; if(hm.Count>3000000) hm.Clear(); }
    Console.WriteLine("u=2 mod 3, u<=6000: " + c2 + " endpoints, failures of ChatGPT's formulas/inequalities " + bad2 + ", monotonicity violations " + mono2);
    long overlap=0,qLess=0,pLess=0,mono1=0,take=0,takeBad=0,n1=0; var pat=new SortedDictionary<string,long>(); var gaps=new SortedDictionary<string,long>();
    for(int u=1;u<=3000;u+=3){ BigInteger U=u; n1++; string sb=""; BigInteger prev=INF; char last=' ';
      for(int r=1;r<=40;r++){ var Pv=H(6*U-2,5,r); var Qv=H(4*U-2,5,r-1); var Pn=H(6*U-2,5,r+1); var Qn=H(4*U-2,5,r); BigInteger mn=INF; char arg=' '; if(Pv!=INF){mn=Pv;arg='P';} if(Qv!=INF&&(mn==INF||Qv<mn)){mn=Qv;arg='Q';}
        if(mn==INF) break; if(prev!=INF&&!(mn<prev)) mono1++; prev=mn; if(arg!=last){ sb+=arg; last=arg; }
        if(Pv!=INF&&Qv!=INF){ overlap++; if(Qv<Pv) qLess++; else if(Pv<Qv) pLess++; string g=(r<=3?"r="+r+":":"r>=4:")+(Pv-Qv); gaps[g]=gaps.GetValueOrDefault(g)+1; }
        if(Qv!=INF&&Qn==INF&&Pn!=INF){ take++; if(!(Qv>Pn)) takeBad++; } }
      pat[sb]=pat.GetValueOrDefault(sb)+1; hm.Clear(); }
    Console.WriteLine("u=1 mod 3, u<=3000: " + n1 + " endpoints; argmin patterns (r>=1): " + string.Join("; ",pat) + "; overlap cells " + overlap + ": Q<P " + qLess + ", P<Q " + pLess + "; monotonicity violations " + mono1 + "; takeovers " + take + ", failures " + takeBad);
    Console.WriteLine("P-Q by index: " + string.Join(", ",gaps));
  }
}
