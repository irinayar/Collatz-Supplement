using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text.Json;
// Independent inverse-tree DFS (no recursion formula): for each saved-frontier state (t,z,b), k=t-b, find the maximum odd count over all inverse paths from z with exactly k even edges.
// State is empty (no origin at all with b odd and k even steps) iff max < b.
class P {
  static int maxOd; static long nodes;
  static void Dfs(BigInteger z,int ev,int od,int k){ if(++nodes>30000000) throw new Exception("cap"); if(ev==k && od>maxOd) maxOd=od; if(ev<k) Dfs(2*z,ev+1,od,k); if(z%3==2) Dfs((2*z-1)/3,ev,od+1,k); }
  static void Main(){
    var root=@"COLLATZ_ROOT\tmp\";
    var states=new List<(int t,BigInteger z,int b,int level)>();
    using(var doc=JsonDocument.Parse(File.ReadAllText(root+@"fair_terminal129_batch05\checkpoint.json"))){
      foreach(var lv in doc.RootElement.GetProperty("levels").EnumerateObject()){ int level=int.Parse(lv.Name);
        foreach(var s in lv.Value.GetProperty("stack").EnumerateArray()) states.Add((s[0].GetInt32(),BigInteger.Parse(s[1].GetRawText()),s[2].GetInt32(),level)); } }
    var remaining=new HashSet<(int,BigInteger,int)>();
    using(var doc=JsonDocument.Parse(File.ReadAllText(root+@"budgets12_14\remaining_frontier.json"))){
      foreach(var e in doc.RootElement.EnumerateArray()) remaining.Add((e.GetProperty("t").GetInt32(),BigInteger.Parse(e.GetProperty("z").GetRawText()),e.GetProperty("b").GetInt32())); }
    states.Sort((p,q)=>(p.t-p.b).CompareTo(q.t-q.b));
    var sw=System.Diagnostics.Stopwatch.StartNew(); int exclEmpty=0,exclNon=0,remEmpty=0,remNon=0,unfinished=0; int maxKdone=0; long totNodes=0; var extraByK=new SortedDictionary<int,int>(); var nonEmptyList=new List<string>();
    foreach(var s in states){ int k=s.t-s.b; if(sw.ElapsedMilliseconds>200000){ unfinished++; continue; } maxOd=-1; nodes=0; bool isRem=remaining.Contains((s.t,s.z,s.b));
      try{ Dfs(s.z,0,0,k); }catch{ unfinished++; continue; } totNodes+=nodes; if(k>maxKdone) maxKdone=k;
      bool empty=maxOd<s.b; if(empty&&!isRem) exclEmpty++; else if(!empty&&!isRem) exclNon++; else if(empty&&isRem){ remEmpty++; extraByK[k]=extraByK.GetValueOrDefault(k)+1; } else { remNon++; nonEmptyList.Add($"t={s.t} b={s.b} k={k} maxOdd={maxOd}"); } }
    Console.WriteLine($"states 366; DFS-resolved {366-unfinished} (largest k {maxKdone}, total nodes {totNodes}); unfinished {unfinished}");
    Console.WriteLine($"Codex-excluded & empty {exclEmpty}, excluded & nonempty {exclNon}; REMAINING & empty (extra exclusions) {remEmpty}; remaining & nonempty {remNon}");
    foreach(var kv in extraByK) Console.Write($"k={kv.Key}:{kv.Value} "); Console.WriteLine();
    foreach(var l in nonEmptyList) Console.WriteLine("  nonempty: "+l);
  }
}
