using System;
using System.Numerics;
// Check Codex K147 / ChatGPT: all-prefix barrier 3^{r_j} > 2^{j-1} for binary codes starting 11; recurrence A_{j,r}=1[3^r>2^{j-1}](A_{j-1,r}+A_{j-1,r-1}), A_{2,2}=1; P(n) <= 2 sum_r A_{m,r}, m=ceil(log2(H+1)).
// (a) brute-force count of binary words of length m starting 11 with all prefix barriers vs recurrence (m=3..20); (b) bound 2*sum A_{m,r} vs measured number of distinct first-return words P(n) at n=1001,4001,16001,65535,262143.
class P {
  static BigInteger[] Rec(int m){ BigInteger[,] A=new BigInteger[m+1,m+2]; A[2,2]=1; for(int j=3;j<=m;j++) for(int r=0;r<=j;r++){ if(BigInteger.Pow(3,r)>BigInteger.One<<(j-1)){ BigInteger a=A[j-1,r]; if(r>=1) a+=A[j-1,r-1]; A[j,r]=a; } } var tot=new BigInteger[m+1]; for(int j=2;j<=m;j++){ BigInteger s=0; for(int r=0;r<=j;r++) s+=A[j,r]; tot[j]=s; } return tot; }
  static void Main(){
    var tot=Rec(20); bool ok=true;
    for(int m=3;m<=20;m++){ long cnt=0; for(long w=0; w<(1L<<m); w++){ // bits b_0..b_{m-1}; require b0=b1=1
        if((w&3)!=3) continue; int r=0; bool good=true; for(int j=1;j<=m;j++){ r+= (int)((w>>(j-1))&1); if(!(BigInteger.Pow(3,r)>BigInteger.One<<(j-1))){good=false;break;} } if(good) cnt++; }
      if(cnt!=(long)tot[m]) ok=false; if(m==10||m==16||m==20) Console.WriteLine($"m={m}: brute-force codes {cnt}, recurrence {tot[m]}, total possible 2^{m-2}={1L<<(m-2)}"); }
    Console.WriteLine($"recurrence == brute force for all m=3..20: {ok}");
    foreach(var (n,meas) in new[]{(1001L,11),(4001L,29),(16001L,89),(65535L,300),(262143L,1007)}){ long H=(4*n-2)/3; int m=0; while((1L<<m)<H+1) m++; Console.WriteLine($"n={n}: H={H}, m={m}, bound 2*sum A = {2*tot[m]}, measured distinct first-return words P(n)={meas}, ratio measured/bound={meas/(double)(2*tot[m]):F3}"); }
  }
}
