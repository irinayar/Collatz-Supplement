using System;
using System.Numerics;
using System.Collections.Generic;
// Profile slope lemma: for a source n at (k,r) ending at z with product G, every positive origin m at (k+dk,r+dr) satisfies m < 2^(dk+dr) 3^(-dr) G n (dr>=1).
// So m<n whenever G < 3^dr / 2^(dk+dr). Test on actual sources from the K126/K129 admissible families (and on random odd n), small lengths:
// enumerate ALL origins at the endpoint by DP over (k',b',z) returning (min,max); check max < factor*G*n and report feasibility / smaller-origin counts.
class P {
  static Dictionary<(int,int,BigInteger),(BigInteger,BigInteger,bool)> memo=new();
  static (BigInteger mn,BigInteger mx,bool ok) Org(int k,int b,BigInteger z){
    if(k==0&&b==0) return (z,z,true); var key=(k,b,z); if(memo.TryGetValue(key,out var v)) return v;
    BigInteger mn=0,mx=0; bool ok=false;
    if(k>0){ var t=Org(k-1,b,2*z); if(t.ok){ ok=true; mn=t.mn; mx=t.mx; } }
    if(b>0 && z%3==2){ var t=Org(k,b-1,(2*z-1)/3); if(t.ok){ if(!ok){ok=true;mn=t.mn;mx=t.mx;} else { if(t.mn<mn) mn=t.mn; if(t.mx>mx) mx=t.mx; } } }
    memo[key]=(mn,mx,ok); return (mn,mx,ok); }
  static void Main(){
    var rng=new Random(99); long srcs=0; long[] cnt=new long[3], feas=new long[3], smaller=new long[3], viol=new long[3], condSmaller=new long[3], condTotal=new long[3];
    int[][] prof={ new[]{1,2}, new[]{2,4}, new[]{0,1} };
    for(int t=0;t<400;t++){
      // random actual source: odd n, follow r odd inputs to z (z odd state after last input), keep L small
      BigInteger n= rng.Next(2)==0 ? BigInteger.Parse((15+16*rng.Next(1<<20)).ToString()) : BigInteger.Parse((1+2*rng.Next(1<<24)).ToString());
      int nin=3+rng.Next(5); BigInteger u=n; int r=0,k=0; double G=1; bool ok=true;
      for(int i=0;i<nin;i++){ BigInteger y=3*u+1; int e=0; while(y.IsEven){y/=2;e++;} G*=(double)(3*u+1)/(double)(3*u); r++; k+=e-1; u=y; }
      BigInteger z=u; if(z<3) continue; int L=k+r; if(L>16) continue; srcs++;
      for(int p=0;p<3;p++){ int dk=prof[p][0],dr=prof[p][1]; if(L+dk+dr>22) continue; memo.Clear(); var o=Org(k+dk,r+dr,z); cnt[p]++;
        double factor=Math.Pow(2,dk+dr)/Math.Pow(3,dr); if(o.ok){ feas[p]++; if(o.mn<n) smaller[p]++; if(!( (double)o.mx < factor*G*(double)n*(1+1e-12))) viol[p]++; }
        if(G*factor<1){ condTotal[p]++; if(o.ok && o.mx<n) condSmaller[p]++; if(o.ok && !(o.mx<n)) viol[p]+=1000; } }
    }
    for(int p=0;p<3;p++) Console.WriteLine($"profile (+{prof[p][0]} even,+{prof[p][1]} odd): sources tested {cnt[p]}, feasible {feas[p]}, with some smaller origin {smaller[p]}, bound violations {viol[p]}; cases G*factor<1: {condTotal[p]} (feasible among them all-smaller: {condSmaller[p]})");
  }
}
