using System;
using System.Numerics;
// Epoch-count version of separation (conditional on distinct valleys): outside segment above H decomposes uniquely as
// [initial rise] (reset streak + rise)^m [final reset streak]; with ChatGPT 112856/114751 each epoch costs < 1+2/(v_j-1), initial rise < 1+1/u0, final reset < 1+1/(b-1).
// Valleys v_j are outputs of odd steps (not multiples of 3), distinct, >=h=H+2. Six-block bound over m=2J values:
//   sum 2/(v-1) <= 4/(h-1) + (2/3) ln(1+6(J-1)/(h-1)).  Total: lnQ + 2/h + 1/(h-1) + that < ln 1.5 (use 7/(h-1) for all the 1/h-type terms: 2/h+1/(h-1)+4/(h-1) <= 7/(h-1)).
// Rigorous enclosure as before (2^300 fixed point, directed rounding).
class P {
  static BigInteger SC=BigInteger.One<<300;
  static BigInteger CeilDiv(BigInteger a,BigInteger b){ BigInteger q=BigInteger.DivRem(a,b,out var r); return r.IsZero?q:q+1; }
  static BigInteger Ln(BigInteger xn,BigInteger xd,bool upper,int N){
    BigInteger zp=xn-xd, zq=xn+xd; BigInteger sum=0, pp=1, qq=1;
    for(int i=0;i<N;i++){ BigInteger a=SC*2*zp*pp, b=(2*i+1)*zq*qq; sum+= upper?CeilDiv(a,b):a/b; pp*=zp*zp; qq*=zq*zq; }
    if(upper){ BigInteger num=SC*2*zp*pp*zq*zq, den=(2*N+1)*zq*qq*(zq*zq-zp*zp); sum+=CeilDiv(num,den)+1; }
    return sum; }
  static bool Safe(BigInteger H,BigInteger Qn,BigInteger Qd,BigInteger J){
    BigInteger h=H+2; BigInteger lowX=Ln(3*Qd,2*Qn,false,60);
    BigInteger upY=Ln(h-1+6*(J-1),h-1,true,120); // ln(1+6(J-1)/(h-1))
    BigInteger over=CeilDiv(7*SC,h-1);
    // need (2/3) upY < lowX - over  <=>  2*upY < 3*(lowX-over)
    return 2*upY < 3*(lowX-over);
  }
  static void Main(){
    BigInteger Qn=BigInteger.Pow(2,61), Qd=BigInteger.Pow(3,32)*993;
    foreach(long Hl in new long[]{786429,2097149,2883581,1073741821}){
      BigInteger H=Hl, lo=1, hi=100*(H+2)/6;
      if(!Safe(H,Qn,Qd,lo)){Console.WriteLine("J=1 unsafe");continue;}
      while(hi-lo>1){ var mid=(lo+hi)/2; if(Safe(H,Qn,Qd,mid)) lo=mid; else hi=mid; }
      Console.WriteLine($"H={Hl}: epochs m<={2*lo} safe (m/h={(double)(2*lo)/(Hl+2):F5}); J+1 unsafe={!Safe(H,Qn,Qd,lo+1)}");
    }
  }
}
