using System;
using System.Numerics;
// Small-endpoint window of ChatGPT's early-range condition: pairs (x,r) with x not divisible by 3 and 2^r(x+3) < 3^(r+1). For each, track H_k(x,r)/2^k over k<=KMAX:
// H_(k+1) <= 2 H_k always (prepend an even step); does it stabilise (exact doubling), and what is the margin h/u with u=(2/3)^(r+1) x = lim U(k,r+1,x)/2^k ?
class P {
  static int KM=17; static BigInteger[,] mn,mx; static void Dfs(BigInteger z,int ev,int od,int rmax){ if(od<=rmax){ if(mn[ev,od]==0||z<mn[ev,od]) mn[ev,od]=z; if(z>mx[ev,od]) mx[ev,od]=z; } if(ev<KM) Dfs(2*z,ev+1,od,rmax); if(od<rmax&&z%3==2) Dfs((2*z-1)/3,ev,od+1,rmax); }
  static void Main(){
    long pairs=0,stab=0,sepFail=0; double minMargin=1e9; string argM=""; int maxK0=0; string notStab="";
    for(int r=0;r<=8;r++){ BigInteger lim=3*BigInteger.Pow(3,r); // 3^(r+1)
      for(int x=3;x<=60;x++){ if(x%3==0) continue; if(!(BigInteger.Pow(2,r)*(x+3)<lim)) continue; mn=new BigInteger[KM+1,r+2]; mx=new BigInteger[KM+1,r+2]; Dfs(x,0,0,r+1);
        bool any=false; int k0=-1; for(int k=0;k<=KM;k++){ if(mn[k,r]==0) continue; any=true; }
        if(!any) continue; pairs++;
        // exact doubling from k0 to KM
        int firstStable=-1; for(int k=KM-1;k>=0;k--){ if(mn[k,r]!=0&&mn[k+1,r]==2*mn[k,r]) firstStable=k; else break; }
        // separation for every k<=KM
        for(int k=0;k<=KM;k++){ if(mn[k,r]!=0&&mn[k,r+1]!=0&&!(mx[k,r+1]<mn[k,r])) sepFail++; }
        if(firstStable>=0&&firstStable<=KM-4){ stab++; if(firstStable>maxK0) maxK0=firstStable; double h=(double)mn[KM,r]/Math.Pow(2,KM); double u=Math.Pow(2.0/3,r+1)*x; double mg=h/u; if(mg<minMargin){ minMargin=mg; argM=$"(x={x},r={r}): h={h:F4}, u={u:F4}"; } }
        else if(notStab.Length<200) notStab+=$"(x={x},r={r}) "; } }
    Console.WriteLine($"window pairs (x not mult of 3, 2^r(x+3) < 3^(r+1), r<=8, x<=60) with a feasible origin: {pairs}; separation failures for k<={KM}: {sepFail}; pairs with exact doubling H_(k+1)=2H_k on [k0, {KM}] for some k0 <= {KM-4}: {stab} (largest k0 {maxK0}); smallest margin h/u = {minMargin:F4} at {argM}; not stabilised: {notStab}");
  }
}
