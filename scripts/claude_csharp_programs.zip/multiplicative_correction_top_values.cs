using System;
using System.Collections.Generic;
using System.Linq;
// Top values of G(m)=prod over pre-cycle odd states (u>=3) of (1+1/(3u)), m<=N; and exact details for the maximiser.
class P {
  static void Main(string[] args){
    long N=long.Parse(args[0]); var G=new double[N+1]; G[1]=1; G[2]=1;
    for(long m=3;m<=N;m++){ long n=m; double p=1; while(n>=m){ if((n&1)==1){ p*=1.0+1.0/(3.0*n); n=(3*n+1)>>1; } else n>>=1; } G[m]=p*G[n]; }
    var idx=Enumerable.Range(3,(int)N-2).OrderByDescending(i=>G[i]).Take(12).ToList();
    Console.WriteLine("top G(m), m<=" + N + ": " + string.Join("; ",idx.Select(i=>i+":"+G[i].ToString("F7"))));
    long x=993; double g=1; int odd=0,steps=0; var oddStates=new List<long>(); while(x>=3){ if((x&1)==1){ g*=1.0+1.0/(3.0*x); odd++; oddStates.Add(x); x=(3*x+1)/2; } else x/=2; steps++; }
    Console.WriteLine("m=993: pre-cycle steps " + steps + ", odd states " + odd + ", G=" + g.ToString("F10") + "; smallest odd states: " + string.Join(",",oddStates.OrderBy(v=>v).Take(8)));
  }
}
