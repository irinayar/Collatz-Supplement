using System;
using System.Collections.Generic;
using System.Linq;
// Check of ChatGPT's fixed-count ternary period (note 091834): the set of numerators V of depth-j inverse words with exactly a odd steps
// (V = 2^j y - 3^a m for each preimage m of y with a odd steps) is the same for y and y + 3^a; hence Vmax(j,y,a) is 3^a-periodic in y.
class P {
  static SortedDictionary<int, SortedSet<long>> Words(long y, int j) {
    var cur = new List<(long, int)> { (y, 0) };
    for (int t = 0; t < j; t++) { var nxt = new List<(long, int)>(); foreach (var (v, c) in cur) { nxt.Add((2 * v, c)); if (v % 3 == 2) nxt.Add(((2 * v - 1) / 3, c + 1)); } cur = nxt; }
    var d = new SortedDictionary<int, SortedSet<long>>();
    foreach (var (m, c) in cur) { long p3 = 1; for (int i = 0; i < c; i++) p3 *= 3; long V = (1L << j) * y - p3 * m; if (!d.ContainsKey(c)) d[c] = new SortedSet<long>(); d[c].Add(V); }
    return d;
  }
  static void Main() {
    long cases = 0, bad = 0, nonempty = 0;
    for (int j = 1; j <= 10; j++) for (int a = 0; a <= j; a++) { long p3 = 1; for (int i = 0; i < a; i++) p3 *= 3; for (long y = 1; y <= 120; y++) {
        var w1 = Words(y, j); var w2 = Words(y + p3, j); w1.TryGetValue(a, out var s1); w2.TryGetValue(a, out var s2);
        cases++; bool e1 = s1 == null || s1.Count == 0, e2 = s2 == null || s2.Count == 0; if (!e1) nonempty++;
        if (e1 != e2 || (!e1 && !s1.SetEquals(s2))) bad++; } }
    Console.WriteLine($"fixed-count ternary shift W(j,y+3^a,a) = W(j,y,a): {cases} cases (j<=10, all a, y<=120), nonempty feasible-word sets {nonempty}, failures {bad}");
  }
}
