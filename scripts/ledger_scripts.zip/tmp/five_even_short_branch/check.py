from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_short_branch');D.mkdir(exist_ok=True);cells=cases=0;examples=[]
for a in range(2,7):
 for u in range(1,301):
  if u%3==0:continue
  x=3**a*u-1;Y=9*2**(a-1)*u-2;T=3*2**a*u-1;defect=16*T-5
  for s in range(R(Y,4)+2):
   expected=24*T-8 if s==0 else 16*T-8 if s==1 else 2**(s-1)*(defect//3**(s-1))-1 if s<=1+a3(defect) else None
   assert H(Y,s,4)==expected;cells+=1
  assert [H(2*(2**l*((x+1)//3**l)-1),a-l,4) for l in (a-2,a-1,a)]==[2**(a+5)*u-d for d in (15,24,32)]
for u in range(1,3001,3):
 C=4*u-1;c=a3(C);v=C//3**c;w=2**(c-1)*v;G=4*w-1
 if G%9:continue
 x=3*u-1;A=6*u-2;B=4*u-2
 assert R(6*w-1,3)==2
 assert H(6*w-1,1,3)==8*G and H(6*w-1,2,3)==16*G//3+1
 assert H(3*w-1,1,4)==8*G-8 and H(3*w-1,2,4)==16*G//3-8
 assert R(3*w-1,4)>=3
 for r in range(1,c+2):assert H(A,r,4)-H(B,r-1,4)==8
 for r in range(c+1,R(x,5)+2):
  assert H(A,r,4)==H(6*w-1,r-c,3) and H(B,r-1,4)==H(3*w-1,r-c,4)
 vals=[H(x,r,5) for r in range(R(x,5)+1)]
 assert all(a>b for a,b in zip(vals,vals[1:]));cases+=1
 if len(examples)<5:examples.append(dict(u=u,x=x,c=c,G=G))
assert [H(224,r,5) for r in range(7)]==[7168,4768,3168,2116,1410,943,None]
z=943
for bit in '1111010000':
 assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
assert z==224 and H(149,4,5) is None
out=dict(short_formula_cells=cells,new_subfamily_cases=cases,examples=examples,counterexample_replayed=True,seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
