from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/cutoff_compare12');a=json.loads((D/'k5/results.json').read_text());b=json.loads((D/'k6/results.json').read_text());proof=json.loads((D/'k5/proof.json').read_text());six=[z for z in proof if z['k']==6 and z['rule']=='union']
for z in six:assert z['r']>R(z['x'],6)
at=json.loads((D/'k5/attempts.json').read_text());bt=json.loads((D/'k6/attempts.json').read_text());assert [z['index'] for z in at]==[z['index'] for z in bt]
s5=(D/'k5/check.py').read_text().replace('/k5','/kX').replace('if k<=5:','if k<=X:').replace('terminal_cutoff=5','terminal_cutoff=X')
s6=(D/'k6/check.py').read_text().replace('/k6','/kX').replace('if k<=6:','if k<=X:').replace('terminal_cutoff=6','terminal_cutoff=X');assert s5==s6
assert a['calls']==b['calls']==22044 and a['attempted_roots']==b['attempted_roots']==44
out=dict(common_source_verified=True,total_calls=44088,fixed_baseline_six_even_union_states=len(six),all_fixed_states_excluded_by_six_cutoff=True,terminal_calls=[a['fresh_leaf_count'],b['fresh_leaf_count']],seconds=[a['seconds'],b['seconds']],new_proof_nodes=[a['new_proof_nodes'],b['new_proof_nodes']],root_exclusions=[a['new_excluded'],b['new_excluded']],found=[a['found'],b['found']])
(D/'comparison.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
