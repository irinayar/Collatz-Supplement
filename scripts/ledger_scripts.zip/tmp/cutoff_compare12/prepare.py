from pathlib import Path
base=Path('tmp/precision12_continue01/check.py').read_text(encoding='utf-8-sig')
for cutoff in (5,6):
 p=base.replace("D=Path('tmp/precision12_continue01')",f"D=Path('tmp/cutoff_compare12/k{cutoff}')")
 p=p.replace("tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())","""for n in json.loads(Path('tmp/precision12_continue01/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())""")
 p=p.replace('calls-local_start>1000','calls-local_start>500').replace('per_root_budget=1000',f'per_root_budget=500,terminal_cutoff={cutoff}')
 p=p.replace('if k<=5:',f'if k<={cutoff}:').replace("'five_empty'","'cutoff_empty'").replace("startswith('five_')","startswith('cutoff_')")
 d=Path(f'tmp/cutoff_compare12/k{cutoff}');d.mkdir(parents=True,exist_ok=True);(d/'check.py').write_text(p,encoding='utf8')
p=Path('tmp/cutoff_compare12/k5/check.py').read_text();exec(compile(p,'matched_cutoff5','exec'))
