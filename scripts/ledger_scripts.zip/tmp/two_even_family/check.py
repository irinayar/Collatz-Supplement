from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,time
from functools import lru_cache
D=Path('tmp/two_even_family');start=time.monotonic()
def val3(x):
 a=0
 while x%3==0:a+=1;x//=3
 return a,x
@lru_cache(maxsize=50000)
def candidates(x,r,k):
 if r<0:return ()
 a,u=val3(x+1)
 if k==0:
  if r>a:return ()
  m=2**r*((x+1)//3**r)-1;return ((m,'1'*r),) if m>0 else ()
 if k==1:
  i=max(0,r-a)
  if i==0:m=2**(r+1)*((x+1)//3**r)-2
  else:
   dd=2**(a+1)*u-1
   if dd%3**i:return ()
   m=2**i*(dd//3**i)-1
  return ((m,'1'*i+'0'+'1'*(r-i)),) if m>0 else ()
 out=[]
 for ell in range(min(a,r)+1):
  xx=2**ell*((x+1)//3**ell)-1;Y=2*xx
  out.extend((m,w+'0'+'1'*ell) for m,w in candidates(Y,r-ell,1))
 return tuple(out)
def bound(x,k):
 a,u=val3(x+1)
 if k==0:return a
 if k==1:return a+val3(2**(a+1)*u-1)[0]
 return max(ell+bound(2*(2**ell*((x+1)//3**ell)-1),1) for ell in range(a+1))
# Independent exhaustive triples using the note's affine formula.
checks=wordcases=0
for x in range(1,201):
 for r in range(13):
  actual=[]
  for i in range(r+1):
   for j in range(r-i+1):
    ell=r-i-j;V=3**r-2**(r+2)+2**i*3**(j+ell)+2**(i+j+1)*3**ell;num=2**(r+2)*x-V;wordcases+=1
    if num%3**r==0 and num//3**r>0:actual.append((num//3**r,'1'*i+'0'+'1'*j+'0'+'1'*ell))
  assert sorted(actual)==sorted(candidates(x,r,2));checks+=1
 R=bound(x,2);assert candidates(x,R,2) and not candidates(x,R+1,2)
# independent finite suffix catalogue, same h4/e<=8 domain as prior comparison
catalog={};families=[]
for e in range(9):
 by={}
 for d in range(e+1):
  for rest in itertools.combinations(range(1,4+d),3):
   pos=(0,)+rest;w=''.join('1' if i in pos else '0' for i in range(4+d));V=sum(2**v*3**(3-i) for i,v in enumerate(pos));rr=V*pow(2,-len(w),81)%81;by.setdefault(rr,[]).append(dict(word=w,V=V,d=d,k=e-d))
 catalog[e]=by
 for rr,ss in by.items():
  if max(v['k'] for v in ss)==2:families.append(dict(e=e,residue=rr,suffixes=ss))
c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());N=4064460795;frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']];records=[]
old=json.loads(Path('tmp/integer_height_envelope/lattice_results.json').read_text());oldcuts={v['index'] for v in old['bounds'] if v['excluded']};oldcuts|={v['index'] for v in json.loads(Path('tmp/multisuffix_family/results.json').read_text())['additional_exclusions']}
for index,q in enumerate(frontier):
 e=q['t']-q['b'];r=q['b']-4
 if e not in catalog or r<0:continue
 ss=catalog[e].get(q['z']%81,[])
 if not ss or max(v['k'] for v in ss)>2:continue
 hits=[];branches=[]
 for v in ss:
  num=2**len(v['word'])*q['z']-v['V'];assert num%81==0;x=num//81;assert x>0
  rr=bound(x,v['k']);branches.append(dict(suffix=v,endpoint=x,max_prefix_odds=rr))
  for m,w in candidates(x,r,v['k']):
   if m<N:
    xx=m;word=w+v['word']
    for bit in word:
     assert xx%2==int(bit);xx=(3*xx+1)//2 if xx%2 else xx//2
    assert xx==q['z'];hits.append(dict(m=m,word=word))
 records.append(dict(index=index,**q,e=e,prefix_odds=r,branches=branches,candidates=hits,excluded=not hits))
extra=[q for q in records if q['excluded'] and q['index'] not in oldcuts]
res=dict(prefix_cases=checks,brute_word_cases=wordcases,attained_max_checks=200,families=families,frontier_records=records,additional_exclusions=extra,seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(dict(prefix_cases=checks,wordcases=wordcases,new_family_rows=len(families),frontier_matches=len(records),extra=[{k:q[k] for k in ['index','level','t','z','b','prefix_odds']} for q in extra],witnesses=sum(len(q['candidates']) for q in records),seconds=res['seconds'])),flush=True);os._exit(0)
