from pathlib import Path
O=Path.cwd();src=(O/'tmp/k6_tail/audit.py').read_text()
src=src.replace('family.__defaults__=(6,)','family.__defaults__=(8,)')
a=src.index('f0=family(0)');b=src.index('result=',a)
src=src[:a]+'''f0=family(0);assert f0['q']%4782969==0 and f0['rho']%4782969==1877689
rows=[family(s) for s in range(101)]
assert all(f['rho']%9==7 for f in rows[1:])
assert (2048*rows[1]['rho']+1)%19683==0
assert ((4*rows[1]['rho'])-(1-27*pow(32,-1,19683)))%19683!=0
assert (4*rows[2]['rho'])%81==46 and all((4*f['rho'])%81==19 for f in rows[3:])
'''+src[b:]
src=src.replace("'s0_C110_containment':[4,9]","'s0_C114_containment':[1877689,4782969]")
src=src.replace('limiting ternary class 4n=1','limiting ternary class256n=1')
src=src.replace("if (64*z['residue']-1)%p3==0:","if (256*z['residue']-1)%p3==0:").replace('rho=pow(64,-1,q)','rho=pow(256,-1,q)')
src=src.replace('tmp/k2_tail/coverage_extension.json','tmp/k6_tail/coverage_extension.json').replace('increment_vs_C113_ledger','increment_vs_C114_ledger')
(O/'tmp/k8_tail/audit.py').write_text(src)
