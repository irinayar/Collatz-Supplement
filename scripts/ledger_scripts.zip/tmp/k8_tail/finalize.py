from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,hashlib
O=Path.cwd();D=O/'tmp/k8_tail';r=json.loads((D/'results.json').read_text());inv=json.loads((O/'tmp/targets_E18/counting_inventory_updated.json').read_text())
rule=next(z for z in inv['finite_ledger'] if z['id']=='C108-11');assert rule['residue']==4075 and rule['modulus']==4374
assert (256*4075-1)%2187==0
for f in r['families'][6:]:assert f['q']%2187==0 and f['rho']%2187==1888
for T,v in r['depths'].items():
 assert v['theta']=='0' and all(x=='0' for x in v['head_marginals'][6:])
 assert all(x!='0' for x in v['head_marginals'][1:6])
base=O/'tmp/k6_tail/coverage_extension.json'
certificate={'lemma':'For all s>=6, n=1888 mod2187; even n descends in1, odd n=4075mod4374 isC108-11.','rule':rule,'s0_contained_in_C114':[1877689,4782969],'depth_min':1,'analytic_new_class_indices':[1,2,3,4,5]}
(D/'tail_containment.json').write_text(json.dumps(certificate,indent=2))
(D/'coverage_extension.json').write_text(json.dumps({'base':'tmp/k6_tail/coverage_extension.json','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'class':'C115','scope':'Five k8 classes s1..5; s0 coveredC114, all s>=6 covered by even descent orC108-11. Conditional-rule density.','families':r['families'][1:6],'depths':r['depths']},indent=2))
print('all-s tail containment and exact five-class extension saved',flush=True);os._exit(0)
