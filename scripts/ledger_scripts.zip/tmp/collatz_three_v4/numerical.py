from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))

import runpy,sys,json
from fractions import Fraction as F
D=Path('tmp/collatz_three_v4')
sys.argv=['late','--certificate',str(D/'phase/killed_phase_certificate.json'),'--output',str(D/'phase/late_checks.json')]
runpy.run_path(str(D/'phase/verify_late_wedge_audit.py'),run_name='__main__')
row={2:1};rows=[]
for j in range(3,256):
 nxt={}
 for r,c in row.items():
  for bit in (0,1):
   rr=r+bit
   if 3**rr>2**j:nxt[rr]=nxt.get(rr,0)+c
 row=nxt
 if j>=70:
  n=max(2**71+1,3*2**(j-1)+3);m=n.bit_length();rows.append((j,m,sum(row.values())))
assert next(v for j,m,v in rows if j==71)==2483007077973438304
assert max(rows,key=lambda t:F(t[2],2**t[1]))[0]==71
assert max(rows,key=lambda t:F(t[1]*t[2],2**t[1]))[0]==71
L=F(2483007077973438304,2**72)
assert 2*L*(10*(72+15)+F(8391,77))*F(1,2**15)<F(33,1048576)
assert 2*L*(10*(72+16)+F(8391,77))*F(1,2**16)<F(13,819200)
assert L*(20*(72+20)+316)*F(1,2**20)<F(3,2621440)
cstar=F(620751769493359576,1180591620717411303425);alpha=F(4899,3904);xi=cstar*(2-F(4,3)*alpha+alpha/(3*(2**71+1)))
eta=F(116073,3904000)-F(7,250)-F(557,10**6)-F(149,10**9)-xi
assert eta>F(1002,10**6)
(D/'population_checks.json').write_text(json.dumps({'status':'PASS','rows':len(rows),'max_width':71,'eta':str(eta)},indent=2))
print('population rows',len(rows),'PASS',flush=True);os._exit(0)
