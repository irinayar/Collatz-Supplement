from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))

import runpy,sys
sys.argv=['verify_phase_frontier.py','--output','tmp/collatz_three_v4/phase/checks.json']
runpy.run_path('tmp/collatz_three_v4/phase/verify_phase_frontier.py',run_name='__main__')
os._exit(0)
