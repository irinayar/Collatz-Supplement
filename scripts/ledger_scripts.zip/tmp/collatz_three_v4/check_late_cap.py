from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time,re,runpy,hashlib
from fractions import Fraction as F
sys.set_int_max_str_digits(50000)

D=Path('tmp/collatz_three_v4');start=time.monotonic()
src=Path('tmp/unresolved_phase_caps/check.py').read_text();exec(src[src.index('from fractions import'):src.index("I=Path('tmp/compensation")])
@lru_cache(None)
def improved_budget(n):
 H=(4*n-2)//3;L=(H+1).bit_length()-1
 return L,min((F(3**r-1,2**L)+F(2000,77)*F(1923,2000)**(r+1)+F(L+1,2**(L-1)),r) for r in range(2*L+1))
def newcap(n,u,xs,q):
 old,meta=caps(n,u,xs,q);L,(v,r)=improved_budget(n)
 used=sum((down(F(1,x)) for x in xs if x>=2**L),F(0))
 b=min(F(meta['b']),up(v-used));assert b>=0
 Q=min(old,up(((1+q/u)*expup(b/3)-1))*u,up(q/u+F(47,96)*b)*u)
 return Q,b,old,F(meta['b']),r
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
wanted={(int(r['n']),int(r['u'])) for r in json.loads(Path('tmp/singleton_charge_bounds/checks.json').read_text())['rows']}
rows=[];checks=improves=chargechecks=zero_to_positive=0
for gr in json.loads((I/'exact_compensation_seeds.json').read_text())['groups']:
 n=int(gr['n']);P=source_count(n);B=5+F(n,100000*P)
 for item in gr['sources']:
  u=int(item['u'])
  if (n,u) not in wanted:continue
  p=replay(n,item);core=set(actual_core(p,P));sel=[r for j,r in enumerate(p['runs']) if j in core and (r['s'],r['e'])==(2,2)]
  for rr in p['runs']:
   g=rr['i'];q=rr['q'];Q,b,Qold,bold,r=newcap(n,u,p['odd'][:g],q);actual=sum((F(1,x) for x in p['odd'][g:-1]),F(0));assert actual<=b and p['Q']<=Q<=Qold;checks+=1;improves+=b<bold
   a0=p['H']+1+(11-p['H']-1)%16;d=F(5,9*a0);gap=B-d*(u+Q-B);tail=6*gap/(2*(u+Q)-gap);entry=max(F(0),6*(B-q)/(2*u+B+q));res=max(F(0),b-entry-tail)
   oldgap=B-d*(u+Qold-B);oldt=6*oldgap/(2*(u+Qold)-oldgap);oldres=max(F(0),bold-entry-oldt);assert res<=oldres
   f=[x for x in sel if x['i']>=g];c=sum((F(1,p['odd'][j]) for x in f for j in range(x['i'],x['j'])),F(0));assert c<=res;chargechecks+=bool(f)
  rows.append({'n':str(n),'u':str(u),'ratio_at_last_boundary':float(b/bold),'new_split':r})
f=json.loads(Path('tmp/unresolved_phase_caps/checks.json').read_text())['new_unresolved'];n=int(f['n']);u=int(f['u']);q=F(f['q']);x=u;xs=[]
for e in f['word']:xs.append(x);x=(3*x+1)//2**e
Q,b,Qold,bold,r=newcap(n,u,xs,q);B=F(f['B']);H=int(f['H']);a0=H+1+(11-H-1)%16;gap=B-F(5,9*a0)*(u+Q-B);t=max(F(0),6*(B-q)/(2*u+B+q))+6*gap/(2*(u+Q)-gap)
fresh={'n':str(n),'u':str(u),'depth_unchanged':256,'b':str(b),'old_b':str(bold),'Qbar':str(Q),'b_ratio':float(b/bold),'Qbar_ratio':float(Q/Qold),'new_split':r,'shortfall_positive':t>b,'actual_future_computed':False}
assert (F(125993,100000))**3>2
assert F(8776241853,2500000000)>3*F(2000,1923)**4
assert 3**883<2**1400 and 2**50*1923**883<2000**883
out={'status':'PASS','prefix_checks':checks,'strict_cap_improvements':improves,'actual_future_R_cases':chargechecks,'rows':rows,'fresh':fresh,'seconds':time.monotonic()-start,'limits':'1GiB/120s','scope':'Prefix-only height-cap refinement; no aggregate late-singleton closure.'}
(D/'late_cap_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['rows','fresh']}));print(json.dumps({k:v for k,v in fresh.items() if k not in ['n','u','b','old_b','Qbar']}),flush=True);os._exit(0)
