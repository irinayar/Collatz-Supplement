#!/usr/bin/env python3
"""Exact certificate for the Collatz core contribution before modulus resolution.

Standard library only.  Run from any directory:
    python /absolute/path/verify_phase_frontier.py

The companion JSON stores a rational piecewise-constant supersolution.  Its
construction used floating-point iteration; this verifier uses only integer
arithmetic and fractions.Fraction for every assertion.  The output theorem is
about the explicitly identified nonsingleton sector, not all central charge.
"""

from __future__ import annotations

if not __debug__:
    raise SystemExit("Run this verifier without -O or -OO; exact certificate assertions must remain enabled.")

import argparse
from bisect import bisect_left, bisect_right
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
import json
import time


HERE = Path(__file__).resolve().parent


def exp_upper(x: F) -> F:
    """Rigorous Taylor upper bound, restricted to 0 <= x <= 1/2.

    After term 20, successive ratios are <= 1/44, so twice term 21
    bounds the entire remaining tail strictly whenever x > 0.
    """
    assert 0 <= x <= F(1, 2)
    term = total = F(1)
    for k in range(1, 21):
        term *= x / k
        total += term
    return total + 2 * term * x / 21


def exp_lower(x: F, terms: int = 48) -> F:
    assert x >= 0 and terms >= 0
    term = total = F(1)
    for k in range(1, terms + 1):
        term *= x / k
        total += term
    return total


def sqrt_floor_scaled(x: F, scale: int = 10**12) -> int:
    """floor(scale*sqrt(x)), exact."""
    assert x >= 0
    return isqrt(x.numerator * scale**2 // x.denominator)


def tail_upper(x: F) -> F:
    # F_tail(x) = 100 - 50 sqrt(x), a decreasing function.
    scale = 10**12
    return 100 - F(50 * sqrt_floor_scaled(x, scale), scale)


def tail_lower(x: F) -> F:
    scale = 10**12
    return 100 - F(50 * (sqrt_floor_scaled(x, scale) + 1), scale)


def verify_small_multiplier_tail() -> dict:
    """Check the rational inequalities used in the analytic tail proof.

    rho=(1+sqrt(2))/sqrt(3)>4/3 and beta=(2+sqrt(2))/3<7/6.
    For z<=1/1024, the drift is positive if
       50*(rho-1) >= exp(7z/15)*sqrt(z)*(100*7/15 + 50*beta).
    The strict rational bounds below are more than sufficient.
    """
    # rho > 4/3: 2 sqrt(2)>7/3, checked by squaring positives.
    assert 8 > F(49, 9)
    # beta < 7/6: sqrt(2)<3/2.
    assert 2 < F(9, 4)
    assert exp_upper(F(7, 15 * 1024)) < 2
    lhs = F(50, 3)
    rhs = F(2, 32) * (F(140, 3) + F(175, 3))
    assert lhs > rhs
    return {"lower_drift_coefficient": str(lhs),
            "upper_loss_coefficient": str(rhs)}


def verify_supersolution(path: Path) -> dict:
    raw = path.read_bytes()
    cert = json.loads(raw)
    D = cert["denominator"]
    S = cert["value_denominator"]
    bounds = cert["endpoints"]
    values = [F(v, S) for v in cert["values"]]
    N = len(values)
    assert D == 2**40 and S == 10**10
    assert (cert["tail_C"], cert["tail_d"],
            cert["tail_cut_denominator"]) == (100, 50, 1024)
    assert (cert["tilt_numerator"], cert["tilt_denominator"]) == (7, 5)
    assert len(bounds) == N + 1
    assert bounds[0] == D // 1024 and bounds[-1] == D
    assert all(isinstance(b, int) for b in bounds)
    assert all(bounds[i] < bounds[i + 1] for i in range(N))
    assert all(v >= 1 for v in values)

    # Global domination by the envelope needed for the analytic tail.
    envelope_margin = min(tail_lower(F(bounds[i + 1], D)) - values[i]
                          for i in range(N))
    assert envelope_margin > 0

    minimum_margin = None
    branches = 0
    for i in range(N):
        lo, hi = bounds[i], bounds[i + 1]
        multiplier = exp_upper(F(7 * hi, 15 * D))
        weighted = F(0)
        e = 1
        # e beyond this range is killed for the entire incoming interval.
        while (1 << e) * lo <= 3 * D:
            v0, v1 = (1 << e) * lo, (1 << e) * hi
            # The transformed closed interval is [v0/(3D),v1/(3D)].
            # Include both neighboring cells on a grid boundary.  Including
            # any extra boundary cell enlarges the upper bound safely.
            a = max(0, bisect_left(bounds, (v0 + 2) // 3) - 1)
            b = min(N - 1, bisect_right(bounds, v1 // 3) - 1)
            candidates = [F(1)]  # a killed branch has boundary value 1
            if v0 <= 3 * bounds[0]:
                candidates.append(tail_upper(F(v0, 3 * D)))
            if v1 >= 3 * bounds[0] and b >= a:
                candidates.extend(values[a:b + 1])
            weighted += max(candidates) / (1 << e)
            branches += 1
            e += 1
        # Sum_{j=e}^infinity 2^-j = 2^{-(e-1)}.
        weighted += F(1, 1 << (e - 1))
        margin = values[i] - multiplier * weighted
        assert margin > 0, (i, str(margin))
        if minimum_margin is None or margin < minimum_margin:
            minimum_margin = margin

    # Enlarged multiplier barrier A=1001/1000.  The physical walk starts
    # lambda=1, hence z=1000/1001.  Cover either cell if it is an endpoint.
    z0 = F(1000, 1001)
    initial_cells = [i for i in range(N)
                     if F(bounds[i], D) <= z0 <= F(bounds[i + 1], D)]
    assert initial_cells
    initial_bound = max(values[i] for i in initial_cells)
    assert initial_bound < F(33, 4)
    return {
        "sha256": sha256(raw).hexdigest(),
        "intervals": N, "branches_checked": branches,
        "initial_cells": initial_cells,
        "initial_mgf_bound": str(initial_bound),
        "initial_mgf_simple_bound": "33/4",
        "minimum_supersolution_margin_lower": str(F(1, 10**7)),
        "minimum_supersolution_margin_exceeds_reported":
            minimum_margin > F(1, 10**7),
        "envelope_margin_lower": str(F(24)),
        "envelope_margin_exceeds_reported": envelope_margin > 24,
    }


def positive_run_coefficient(s: int, e: int) -> F:
    assert s >= 1 and e >= 2
    return max(F(0), 2 - F(2, 3)**s - F(2**(s + e - 1), 3**s))


def verify_run_mass() -> dict:
    # For s<=8, e>2s+2 is certainly nonpositive.  Check the first excluded
    # e explicitly; positivity decreases as e increases.
    masses = []
    for s in range(1, 9):
        assert positive_run_coefficient(s, 2 * s + 3) == 0
        masses.append(sum((positive_run_coefficient(s, e) /
                           2**(s + e - 1) for e in range(2, 2*s + 3)), F(0)))
    # For all s>8, chi<=2 and sum_{e>=2}2^{-(s+e-1)}=2^-s.
    tail = F(1, 128)
    upper = sum(masses, F(0)) + tail
    assert upper < F(8, 25)
    assert positive_run_coefficient(2, 2) / 8 == F(1, 12)
    return {"masses_s_1_through_8": list(map(str, masses)),
            "tail_upper": str(tail), "total_upper": str(upper),
            "simple_upper": "8/25", "R_mass": "1/12"}


def verify_final_constants(initial_mgf_bound: F, run_mass_upper: F) -> dict:
    theta = F(1400, 1001)  # (7/5)/A with A=1001/1000
    # The tangent e^y >= e^(1-epsilon)*(y+epsilon), together with
    # epsilon*exp(theta*B+1-epsilon)>=1, implies
    # (Q-B)+ <= (exp(theta*Q)-1)/(theta*exp(theta*B+1-epsilon)).
    epsilon = F(1, 2000)
    exp_argument = 5 * theta + 1 - epsilon
    exp_denominator = exp_lower(exp_argument)
    assert exp_denominator > 2000
    # Keep the exact initial MGF for the strongest numerical comparison.
    sharp_phase_tail = (initial_mgf_bound - 1) / (theta * exp_denominator)
    assert sharp_phase_tail < F(7, 4000)
    bulk_all = F(8, 25) * F(7, 4000)
    bulk_R = F(1, 12) * F(7, 4000)
    residual = F(6761, 3904000)
    assert bulk_all == F(7, 12500) < residual
    assert bulk_R == F(7, 48000)
    sharp_bulk = run_mass_upper * sharp_phase_tail
    sharp_bulk_simple = F(557, 10**6)
    assert sharp_bulk < sharp_bulk_simple
    # Optional further reduction using the previously established canonical
    # source-count theorem, not proved by this verifier.
    alpha = F(4899, 3904)
    n0 = 2**71 + 1
    cstar = F(620751769493359576, 1180591620717411303425)
    first_late_excess = cstar * (2 - 4*alpha/3 + alpha/(3*n0))
    second_late_allowance = residual - sharp_bulk_simple - first_late_excess
    assert first_late_excess > 0
    assert second_late_allowance > F(1002, 10**6)
    return {"physical_tilt": str(theta),
            "positive_part_tangent_epsilon": str(epsilon),
            "tangent_exponential_lower_exceeds": "2000",
            "phase_excess_simple_upper": "7/4000",
            "all_positive_core_before_width_resolution_coarse_upper": str(bulk_all),
            "all_positive_core_before_width_resolution_sharp_upper": str(sharp_bulk_simple),
            "R_core_before_width_resolution_upper": str(bulk_R),
            "old_short_core_constant": str(residual),
            "remaining_constant_if_partitioned_disjointly":
                str(residual - sharp_bulk_simple),
            "first_late_excess_using_imported_canonical_count":
                str(first_late_excess),
            "second_and_later_late_signed_allowance":
                str(second_late_allowance),
            "simpler_second_and_later_late_signed_allowance": "1002/1000000"}


def verify_elementary_source_inequalities() -> dict:
    # Uniform high-floor multiplier enlargement: if M<=H-n then
    # E+1<=log2(H-n)<log2(n), and every earlier g<=log2(n).
    # For n>=2^71, log2(n)<n/2^64, so q_g/u<1/(3*2^64-1).
    error = F(1, 3 * 2**64 - 1)
    assert error < F(1, 1000)
    # The induction m+1<=2^{m-64} starts here and persists upon doubling.
    assert 72 <= 2**7
    # One elementary exact count check, not the proof of the general count.
    for M in [2, 4, 8, 16, 64, 256]:
        for L in range(1, 9):
            for width in [0, 1, M-1, M, M+1, 3*M+5]:
                H = L + width
                for residue in range(M):
                    first = L + (residue-L) % M
                    c = max(0, 1 + (H-first)//M)
                    if c >= 2:
                        assert M <= width
                        assert c <= 2 * F(width, M)
                    if M <= width:
                        assert c <= 2 * F(width, M)
    return {"multiplier_error_upper": str(error),
            "multiplier_barrier": "1001/1000"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path,
                        default=HERE / "killed_phase_certificate.json")
    parser.add_argument("--output", type=Path,
                        default=HERE / "phase_frontier_verification.json")
    args = parser.parse_args()
    start = time.monotonic()
    tail = verify_small_multiplier_tail()
    supersolution = verify_supersolution(args.certificate)
    run_mass = verify_run_mass()
    result = {
        "status": "exact certificate verified",
        "scope": "all positive original-core occurrences whose complete run-ending prefix modulus is at most H-n; this includes some already-singleton exact height/phase cylinders",
        "small_multiplier_tail": tail,
        "supersolution": supersolution,
        "run_mass": run_mass,
        "constants": verify_final_constants(F(supersolution["initial_mgf_bound"]),
                                            F(run_mass["total_upper"])),
        "source_inequalities": verify_elementary_source_inequalities(),
        "unresolved": ["runs completed after prefix modulus exceeds H-n",
                       "after the imported canonical count pays the first such positive uncovered core occurrence per profile: second and later such positive occurrences",
                       "their signed aggregate after all original negative core parts and off-core credits are retained"],
    }
    assert result["supersolution"]["minimum_supersolution_margin_exceeds_reported"]
    assert result["supersolution"]["envelope_margin_exceeds_reported"]
    result["elapsed_seconds_informational"] = round(time.monotonic()-start, 3)
    text = json.dumps(result, indent=2)
    args.output.write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
