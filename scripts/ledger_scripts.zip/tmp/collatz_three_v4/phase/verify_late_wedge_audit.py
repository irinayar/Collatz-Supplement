#!/usr/bin/env python3
"""Independent exact arithmetic audit of the late phase/modulus sector."""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Run without -O or -OO.")


def exp_lower(x,degree):
    total=term=F(1)
    for k in range(1,degree+1):
        term*=x/k
        total+=term
    return total


def lookup(data,z):
    D=data['denominator']; V=data['value_denominator']
    cells=[i for i in range(len(data['values']))
           if F(data['endpoints'][i],D)<=z<=F(data['endpoints'][i+1],D)]
    assert cells
    return cells,max(F(data['values'][i],V) for i in cells)


def bound(theta,J):
    eta=F(1,2000)
    dy=exp_lower(10*theta+1-eta,48)
    dx=exp_lower(2*theta,30)
    assert eta*dy>1 and dx>2
    return (J-1)/(theta*dy)*2/(dx-2)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--certificate',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path('late_wedge_audit_certificate.json'))
    args=parser.parse_args()
    digest=hashlib.sha256(args.certificate.read_bytes()).hexdigest()
    assert digest=='c3273a03d5e5108be6ff0f4c8d60effab46f40a02cee175d89082800b7c89d63'
    data=json.loads(args.certificate.read_text())
    weak_cells,Jbar=lookup(data,F(32,47))
    strong_cells,J=lookup(data,F(1000,1001))
    assert weak_cells==[3355] and Jbar==F(22718390719,2500000000)
    assert J==F(82262531839,10**10)
    Abar,tau=F(47,32),F(224,235)
    A,theta=F(1001,1000),F(200,143)
    assert tau*Abar==theta*A==F(7,5)
    assert exp_lower(7*tau+1-F(1,2000),48)>2000
    assert F(192,145)<2
    assert 1+F(1,3*2**63-1)<A
    weak,strong=bound(tau,Jbar),bound(theta,J)
    assert weak<F(96,10**6)
    assert F(2,3)*weak<F(64,10**6)
    assert strong<F(223,10**9)
    assert F(2,3)*strong<F(149,10**9)
    result={'status':'PASS','imported_exponential_certificate_sha256':digest,
            'weak_lookup':{'cells':weak_cells,'value':str(Jbar),'physical_tilt':str(tau)},
            'strong_lookup':{'cells':strong_cells,'value':str(J),'physical_tilt':str(theta)},
            'original_reciprocal_bound_exact_upper':str(weak),
            'improved_reciprocal_bound_exact_upper':str(strong),
            'improved_simple_reciprocal_upper':'223/1000000000',
            'improved_simple_whole_run_upper':'149/1000000000',
            'automatic_exponent_cap':'E < (192 log2(W)-975)/145 < 2 log2(n)',
            'scope':'Genuine completed first-return profiles; layer d>=1, q>10+2d. Whole-run bound requires all its odd inputs in the sector.',
            'unresolved':'Outside-wedge actual aggregate; arbitrary repeated departures and unfinished run charges.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','automatic_exponent_cap',
          'improved_simple_reciprocal_upper','improved_simple_whole_run_upper')},indent=2))


if __name__=='__main__':
    main()
