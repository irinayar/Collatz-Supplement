from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))

from fractions import Fraction as F
from collections import Counter
import json,time
start=time.monotonic();A=3**24;D=2**38;M=2**305;inv=pow(A**8,-1,M);words=['2233','2323','2332','3223','3232','3322'];Bs=[]
for word in words:
 exps=sum(([1,2,1,2,2] if c=='2' else [1,2,1,2,1,2,2] for c in word),[]);U=E=0
 for e in exps:U=3*U+2**E;E+=e
 assert len(exps)==24 and E==38;Bs.append(U)
h=Counter();minimum=M;total=0
powers=[D**j for j in range(8)]
def walk(j,U):
 global minimum,total
 if j==8:
  a=((D**8-U)*inv)%M;assert a%2
  h[a.bit_length()-1,a%3]+=1;minimum=min(minimum,a);total+=1;return
 for B in Bs:walk(j+1,A*U+powers[j]*B)
walk(0,0)
S=sum((F(c,2**b) for (b,r),c in h.items() if r),F(0));assert total==6**8 and S==F(3330023,2**302)
assert [sum(c for (b,r),c in h.items() if r==j) for j in range(3)]==[560289,559957,559370]
C=F(1814421282246,7551629537)*F(96*2**272,258*5000)*(S+F(6**8,2**305)*F(239501,30))
assert C==F(7618091890243831687161,272394937772592332800000)
out={'status':'PASS','codes':total,'S0':str(S),'C8':str(C),'minimum':str(minimum),'histogram':[[b,r,c] for (b,r),c in sorted(h.items())],'seconds':time.monotonic()-start,'limits':'1GiB/120s'}
Path('tmp/collatz_three_v4/histogram_checks.json').write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='histogram'},flush=True);os._exit(0)
