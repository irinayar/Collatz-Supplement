from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import sys,json,hashlib
from fractions import Fraction as F
D=Path('tmp/uniform_aggregate_audit');I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,actual_core,source_count,v2
coef=F(192*9709*128,220*127);assert coef<8600
old=F(17,327680);new=F(8600,2**28);assert new<old
# Independent finite-width count recurrence and rational maxima.
counts={2:1};maxrow=(F(0),0)
for k in range(3,256):
 nxt={}
 for r,c in counts.items():
  for j in (r,r+1):
   if 3**j>2**k:nxt[j]=nxt.get(j,0)+c
 counts=nxt
 if k>=70:
  n=max(2**71+1,3*2**(k-1)+3);m=n.bit_length();value=F(2*sum(counts.values()),2**m-1)*(1+F(441*m,10));maxrow=max(maxrow,(value,k));assert value<F(17,5)
assert maxrow[1]==71
examples=[]
for m in [72,128,257,285,286,512,1000,4096]:
 h=(21*m+21)//22;assert h==m-m//22
 S=min(m+16,h+28);examples.append(dict(m=m,old=m+16,new=S,removed_extra_lengths=m+16-S))
seed=json.loads((I/'exact_compensation_seeds.json').read_text());rows=[];profile_count=run_count=core_count=newly_paid=0
for group in seed['groups']:
 n=int(group['n']);P=source_count(n) if n>=2**71 else None
 for item in group['sources']:
  p=replay(n,item);profile_count+=1;m=n.bit_length();S=min(m+16,(21*m+21)//22+28);core=actual_core(p,P) if P is not None else []
  before=F(0);after=F(0)
  for index,r in enumerate(p['runs']):
   run_count+=1;a=r['a'];s=r['s'];e=r['e'];assert v2(a+1)==s
   E=0;num=0
   for ee in [1]*(s-1)+[e]:num=3*num+2**E;E+=ee
   modulus=2**(s+e);res=((2**E-num)*pow(3**s,-1,modulus))%modulus;assert a%modulus==res
   if index in core:
    core_count+=1
    if s>=m+16:before+=r['psi']
    if s>=S:after+=r['psi']
    if S<=s<m+16:newly_paid+=1
  if P is not None:
   assert after<=old
   if m>=286:assert after<=new
  # Signed split keeps negative long-core and all off-core credits.
  t=[p['kappa']*r['delta']+r['flux'] for r in p['runs']]
  credits=sum((max(F(0),-r['flux']-r['delta']/15) for j,r in enumerate(p['runs']) if j not in core),F(0))
  Z=sum((t[j] for j in core),F(0))-credits
  residual=sum((t[j] if p['runs'][j]['s']<S else -max(F(0),-t[j]) for j in core),F(0))-credits
  assert Z==residual+after
  rows.append(dict(n=str(n),u=str(p['u']),high_floor=P is not None,core_runs=len(core),cutoff=S,tail=str(after),signed_residual_sign=(residual>0)-(residual<0)))
# The bare (s,e)=(2,2) lattice relaxation already has excessive capacity in one octave.
n=2**71+1;H=(4*n-2)//3;first=H+1+((11-(H+1))%16);last=2*H;N=max(0,(last-first)//16+1)
# For each candidate a <=2H, theta/a >= (2/3)/(2H); the upper-envelope budget cannot be made small by this relaxation.
lattice_lower=F(N,3*H);assert lattice_lower>F(1,49)
result=dict(status='PASS',shifted_coefficient=str(coef),coefficient_below_8600=True,analytic_signed_tail='8600*2^(-K) at s>=ceil(21*m/22)+K, n>=2^256',K28=str(new),old_K16=str(old),improved_margin=str(old-new),examples=examples,finite_max=str(maxrow[0]),profiles=profile_count,runs=run_count,core_occurrences=core_count,newly_paid_saved_occurrences=newly_paid,rows=rows,short_type_lattice=dict(s=2,e=2,residue=11,modulus=16,octave_candidates=N,reciprocal_majorant_capacity_lower=str(lattice_lower)),scope='No uniform shorter-run aggregate bound; no new witness or density claim.')
(D/'shifted_tail_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True);os._exit(0)

