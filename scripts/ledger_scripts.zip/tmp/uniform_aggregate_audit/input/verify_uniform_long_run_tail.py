#!/usr/bin/env python3
"""Exact certificate for the actual long-run aggregate tail.

Standalone standard library. Global source injection/count facts are imports;
the finite count recurrence and all new numerical inequalities are rebuilt.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("Assertions must remain enabled.")


def v2(x):
    assert x > 0
    return (x & -x).bit_length() - 1


def finite_envelopes():
    row = {2: 1}
    saved = []
    for k in range(3, 256):
        new = {}
        for r, count in row.items():
            for bit in (0, 1):
                rr = r + bit
                if 3**rr > 2**k:
                    new[rr] = new.get(rr, 0) + count
        row = new
        if k < 70:
            continue
        n = max(2**71 + 1, 3 * 2**(k-1) + 3)
        m = n.bit_length()
        long_count = sum(row.values())
        coefficient = F(2*long_count, 2**m-1) * (1 + F(441*m, 10))
        assert coefficient < F(17, 5)
        full_moment = F(long_count, 2**m) * F(28672*m*m+832*m, 5)
        assert full_moment < 16000
        saved.append({"width": k, "minimum_n": str(n), "minimum_m": m,
                      "long_count": str(long_count),
                      "uniform_scaled_signed_tail_bound": str(coefficient),
                      "full_normalized_dyadic_moment_bound": str(full_moment)})
    assert len(saved) == 186
    maximum = max(saved, key=lambda x: F(x["uniform_scaled_signed_tail_bound"]))
    assert maximum["width"] == 71 and maximum["minimum_m"] == 72
    assert maximum["long_count"] == "2483007077973438304"
    exact = F(maximum["uniform_scaled_signed_tail_bound"])
    assert exact == F(327241787595818868928, 97974408358291394475)
    assert F(17, 5)-exact == F(5871200822371872287, 97974408358291394475)
    moment_maximum = max(saved, key=lambda x: F(x["full_normalized_dyadic_moment_bound"]))
    assert moment_maximum["width"] == 71
    assert F(moment_maximum["full_normalized_dyadic_moment_bound"]) == F(22534918706003872677687,1441151880758558720)
    return saved, maximum


def progression_controls():
    controls = []
    for S in (1, 2, 7, 16, 72, 88):
        M = 2**S
        for d in (0, 1, 2, 5, 10):
            N = 2**d
            reciprocal = sum((F(1, M*j-1) for j in range(1, N+1)), F(0))
            harmonic = sum((F(1, j) for j in range(1, N+1)), F(0))
            rational = (1+F(7*d, 10))/(M-1)
            assert reciprocal <= harmonic/(M-1) <= rational
            controls.append({"S": S, "dyadic_count_exponent": d,
                             "terms": N, "rational_bound": str(rational)})
    return controls


def local_run_controls():
    n = 2**71 + 1
    H = (4*n-2)//3
    m = n.bit_length()
    kappa = F(n-1, n+1)
    controls = []
    total = 0
    for s in (72, 73, 84, 88, 120, 160, 256, 511, 1024):
        a = 2**s-1
        assert a > H and a < 2**(64*m)
        assert v2(a+1) == s
        x = a
        exponents = []
        for j in range(s):
            e = v2(3*x+1)
            assert (e == 1) if j < s-1 else (e >= 2)
            exponents.append(e)
            x = (3*x+1)//2**e
            total += 1
        b = x
        z = F(2, 3)**s
        delta = (1-z)/a
        flux = F(1, a)-F(1, b)
        signed = kappa*delta+flux
        assert flux <= delta and 0 < delta < F(1, a)
        assert max(F(0), signed) <= F(2, a)
        E = sum(exponents)
        numerator = 3**s-2**s
        assert 2**E*b == 3**s*a+numerator
        modulus = 2**(E+1)
        residue = ((2**E-numerator)*pow(3**s, -1, modulus)) % modulus
        assert a % modulus == residue
        for K in (0, 4, 12, 16, 32):
            if s >= m+K:
                assert (a+1) % 2**(m+K) == 0
        controls.append({"s": s, "terminal_exponent": exponents[-1],
                         "actual_odd_transitions": s,
                         "start_bitlength": a.bit_length(),
                         "start_is_least_local_residue": a == residue,
                         "signed_positive": signed > 0,
                         "scope": "actual local complete run; full core membership not asserted"})
    return controls, total


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("uniform_long_run_tail_certificate.json"))
    args = parser.parse_args()
    exp_lower = F(1)+F(7,10)+F(49,200)+F(343,6000)+F(2401,240000)
    assert exp_lower > 2
    assert 3000**22 < 2**256
    analytic = 2*96*F(441,10)/3000
    assert analytic == F(1764,625) < F(17,5)
    assert 258**22 < 2*257**22
    full_moment_tail = F(96*28672*257,5*3000)
    assert full_moment_tail == F(29474816,625) < 50000
    rows, maximum = finite_envelopes()
    progressions = progression_controls()
    runs, transitions = local_run_controls()
    budgets = []
    for K in (0,4,8,12,16,20,32):
        signed = F(17,5*2**K)
        weighted = signed/2
        original = F(488,375)*F(3000,2797)*signed
        budgets.append({"K":K,"signed_tail":str(signed),
                        "actual_delta_tail":str(weighted),
                        "original_charge_increment_via_signed_bound":str(original)})
        if K == 16:
            assert signed == F(17,327680) and original < F(1,10000)
    result = {"status":"PASS","finite_rows":rows,"finite_maximum":maximum,
              "analytic_scaled_signed_tail_bound":str(analytic),
              "uniform_scaled_signed_tail_bound":"17/5",
              "excess_run_length_moment_bound":"17/5",
              "three_halves_excess_length_moment_scaled_bound":"34/5",
              "full_normalized_dyadic_moment_bound":"50000",
              "full_normalized_dyadic_moment_analytic_tail_bound":str(full_moment_tail),
              "rational_log2_upper":"7/10","exponential_series_lower":str(exp_lower),
              "cutoff_budgets":budgets,"reciprocal_progression_controls":progressions,
              "actual_local_run_controls":runs,"local_odd_transitions_replayed":transitions,
              "scope":{"actual_aggregate_long_run_tail_proved":True,
                       "all_original_profile_multiplicities_retained":True,
                       "all_off_core_and_negative_long_core_credits_retained":True,
                       "global_source_count_and_core_height_theorems_imported":True,
                       "local_controls_claimed_as_actual_cores":False,
                       "unrestricted_short_run_occupation_bound_proved":False,
                       "unrestricted_21_over_125_bound_proved":False}}
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":"PASS","finite_rows":len(rows),
                      "progression_controls":len(progressions),"local_runs":len(runs),
                      "actual_odd_transitions":transitions,
                      "uniform_signed_tail":"(17/5)*2^(-K)",
                      "K16_signed_tail":"17/327680",
                      "unrestricted_bound_proved":False}))


if __name__ == "__main__":
    main()
