#!/usr/bin/env python3
"""Exact genuine-return controls for the endpoint-potential obstruction.

These controls do not falsify the actual-core aggregate target: all of their
unchanged cores are proved empty by necessary core predicates. No census.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

if not __debug__:
    raise RuntimeError("Assertions must remain enabled.")
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

HERE = Path(__file__).resolve().parent


def ceil_fraction(x):
    return -((-x.numerator) // x.denominator)


def mechanical_word(N, extra_final=False):
    E = U = 0
    data = [(F(1), F(0), 0, 0)]
    word = []
    for j in range(1, N+1):
        A = 3**j
        nextE = A.bit_length()-1 + (extra_final and j == N)
        word.append(nextE-E)
        U = 3*U + (1 << E)
        E = nextE
        data.append((F(A,1 << E), F(U,A), E, U))
    M = 1 << (E+1)
    residue = (((1 << E)-U)*pow(3**N,-1,M)) % M
    assert residue > 0 and residue % 4 == 3
    assert word[0:2] == [1,2] and word[-1] >= 2
    return word, data, M, residue


def replay(a, word):
    odds = [a]
    shortcut = [a]
    x = a
    for e in word:
        y = 3*x+1
        assert (y & -y).bit_length()-1 == e
        y //= 2
        shortcut.append(y)
        for _ in range(e-1):
            assert y % 2 == 0
            y //= 2
            shortcut.append(y)
        assert y % 2
        odds.append(y)
        x = y
    return odds, shortcut


def charges(n, a, odds, word, data):
    kappa = F(n-1,n+1)
    runs = []
    start = 0
    for end,e in enumerate(word,1):
        if e < 2:
            continue
        s = end-start
        u,v = odds[start],odds[end]
        delta = (1-F(2,3)**s)/u
        f = F(1,u)-F(1,v)
        t = kappa*delta+f
        assert f <= delta
        assert data[end][1]-data[start][1] == (a+data[start][1])*delta
        runs.append({"start":start,"end":end,"s":s,"delta":delta,"f":f,"t":t})
        start = end
    assert start == len(word)
    assert all(r["s"] in (1,2) for r in runs)
    W = sum((r["delta"] for r in runs),F(0))
    T = sum((r["t"] for r in runs),F(0))
    whole_charge = (1+data[-1][1]/a)*(1+F(5,odds[-1]))/(1+F(5,a))-1
    assert whole_charge > 0
    assert 1+data[-1][1]/a < F(47,32)
    # Artificial all-proper selection is explicitly NOT the original core.
    artificial = sum((r["t"] for r in runs[1:]),F(0))
    assert runs[0]["s"] == 2 and runs[0]["f"] > 0
    actual_empty_Z = -sum((max(F(0),-r["f"]-r["delta"]/15) for r in runs),F(0))
    assert actual_empty_Z < 0
    for r in runs:
        credit = max(F(0),-r["f"]-r["delta"]/15)
        assert 0 <= r["t"]+credit <= (kappa+1)*r["delta"]
    return runs, {
        "runs":len(runs),
        "proper_runs":len(runs)-1,
        "normalized_whole_signed_sum":str(a*T),
        "normalized_artificial_all_proper_Z":str(a*artificial),
        "normalized_actual_empty_core_Z":str(a*actual_empty_Z),
        "whole_phi5_charge_positive":whole_charge > 0,
        "Q":str(data[-1][1]),
        "W":str(W),
    }


def record_control(N):
    word,data,M,residue = mechanical_word(N)
    RN,qN,EN,_ = data[-1]
    assert all(RN < data[j][0] for j in range(1,N))
    lower = max(1 << 73,2*M,N)
    for j in range(1,N):
        Rj,qj,_,_ = data[j]
        threshold = (RN*qN-Rj*qj+8)/(Rj-RN)
        lower = max(lower,ceil_fraction(threshold)+1)
    a = lower+(residue-lower)%M
    odds,shortcut = replay(a,word)
    proper_min = min(odds[1:-1])
    n = (3*proper_min+1)//4
    if n % 2 == 0:
        n -= 1
    H = (4*n-2)//3
    assert n >= 1 << 71 and n % 2
    assert n <= a < odds[-1] <= H < proper_min
    assert 1 <= proper_min-H <= 3
    assert len(set(shortcut[:-1])) == EN
    jmin = odds.index(proper_min)
    # The previous candidate in this complete valuation cylinder fails a
    # proper-state constraint; all earlier candidates fail it as well.
    previous_j = data[jmin][0]*(a-M+data[jmin][1])
    assert previous_j <= H and a-M > 0
    assert a >= 2*M and a >= N
    for j in range(N):
        assert data[j][2]+odds[j].bit_length()-1 >= EN
    runs,result = charges(n,a,odds,word,data)
    T = F(result["normalized_whole_signed_sum"])
    Z = F(result["normalized_artificial_all_proper_Z"])
    kappa = F(n-1,n+1)
    assert qN > F(N,6) and qN <= F(N,3)
    assert T > kappa*N/8
    assert Z > kappa*N/8-F(10,9)
    boundary_controls = []
    for boundary_size in (0,1,2,4,8):
        removed = set(range(min(boundary_size,len(runs))))
        removed.update(range(max(0,len(runs)-boundary_size),len(runs)))
        resource = sum((r["t"] for i,r in enumerate(runs) if i not in removed),F(0))
        resource -= sum((max(F(0),-runs[i]["f"]-runs[i]["delta"]/15) for i in removed),F(0))
        assert a*resource > kappa*N/8-2*len(removed)
        boundary_controls.append({"removed_runs":len(removed),"normalized_Z":str(a*resource)})
    if N == 665:
        assert Z > 56
    result.update({
        "kind":"record-low completed first return",
        "odd_transitions":N,"shortcut_steps":EN,"a":str(a),"n":str(n),"H":str(H),
        "source_modulus":str(M),"least_positive_residue":str(residue),
        "least_admissible_source_verified":True,
        "actual_core_runs":0,
        "artificial_fixed_boundary_controls":boundary_controls,
        "empty_core_reason":"all canonical endpoints fail strict interiority",
        "scope":"The growing all-proper functional is an artificial selection, not the actual core.",
    })
    return result


def final_extra_control(base):
    N = base
    while True:
        A = 3**N
        E = A.bit_length()-1
        if 2*A > 3*(1 << E):
            break
        N += 1
    word,data,M,a = mechanical_word(N,extra_final=True)
    odds,shortcut = replay(a,word)
    n = (3*a+5)//4
    if n % 2 == 0:
        n += 1
    H = (4*n-2)//3
    E = data[-1][2]
    assert n >= 1 << 71 and n % 2
    assert n <= odds[-1] < a <= H < min(odds[1:-1])
    assert a < M and len(set(shortcut[:-1])) == E
    runs,result = charges(n,a,odds,word,data)
    candidates = []
    for r in runs[1:]:
        j = r["start"]
        qj = data[j][1]
        assert qj <= F(j,3)
        interior = data[j][2]+odds[j].bit_length()-1 < E
        assert interior == (3**j*(a+qj) < 1 << E)
        if qj > 5 and interior:
            candidates.append(j)
    assert not candidates
    # This single inequality certifies the same emptiness for the complete
    # mechanical family whenever it holds, not just for these seven tests.
    assert a*3**16 >= 1 << E
    result.update({
        "kind":"final-extra-exponent completed first return",
        "odd_transitions":N,"shortcut_steps":E,"a":str(a),"n":str(n),"H":str(H),
        "least_admissible_source_verified":True,
        "source_equals_least_positive_residue":True,
        "source_bits":a.bit_length(),"E_minus_source_bits":E-a.bit_length(),
        "actual_core_runs":0,
        "empty_core_reason":"canonical interiority and incoming phase > 5 cannot both hold",
        "necessary_core_small_residue_threshold":str(F(1 << E,3**16)),
    })
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=HERE/"endpoint_potential_obstruction_certificate.json")
    args = parser.parse_args()
    records = [record_control(N) for N in (12,53,359,665)]
    extra = [final_extra_control(N) for N in (100,125,150,175,200,225,250)]
    certificate = {
        "status":"PASS",
        "records":records,"final_extra_controls":extra,
        "exact_integer_valuation_and_least_source_checks":True,
        "all_constructed_profiles_have_actual_empty_core":True,
        "core_bearing_counterexample_claimed":False,
        "unrestricted_aggregate_target_proved":False,
        "verifier_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    args.output.write_text(json.dumps(certificate,indent=2)+"\n")
    print(json.dumps({
        "status":"PASS","genuine_profiles":len(records)+len(extra),
        "actual_nonempty_cores":0,
        "record_controls":[{"N":r["odd_transitions"],"proper_runs":r["proper_runs"],
            "a_times_all_proper_Z_display":float(F(r["normalized_artificial_all_proper_Z"]))} for r in records],
        "final_extra_N":[r["odd_transitions"] for r in extra],
        "uniform_aggregate_bound_proved":False,
    }))


if __name__ == "__main__":
    main()
