from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
from fractions import Fraction as F
import json
D=Path('tmp/larger_bound_audit_21m');calls=0
@lru_cache(maxsize=50000)
def possible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return(x+1)%3**r==0 and 2**r*(x+1)//3**r-1>0
 y=x
 for ell in range(r+1):
  if possible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
qs=json.loads((D/'profile_queries.json').read_text());normalized=set()
for q in qs:
 if q['status']=='empty_layer_exact':assert not possible(q['x'],q['k']+2,q['r']+4)
 if q['status']=='certified_witness':
  z=q['m'];seen=[]
  for bit in q['target_word']:seen.append(z);assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
  assert z==q['x'] and (q['n'] in seen)==q['visits_source'] and q['m']<q['n']
  p=q['convergence_path'];assert p[0]==q['m'] and p[-1]==1
  for a,b in zip(p,p[1:]):assert b==((3*a+1)//2 if a%2 else a//2)
  if not q['visits_source']:
   c=q['common_suffix_length'];normalized.add((q['word'][:-c] if c else q['word'],q['target_word'][:-c] if c else q['target_word']))
def affine(w):
 a=1;b=0;d=1
 for bit in w:
  if bit=='1':a,b=3*a,3*b+d
  d*=2
 return a,b,d
assert normalized=={('111101','111101111100')}
P,Q=next(iter(normalized));a,b,d=affine(P);A,B,Dd=affine(Q)
# Check the claimed family symbolically (constant and slope), plus exact parity cylinders.
n0,pstep,m0,qstep=303,5184,239,4096
assert Dd*(a*n0+b)==d*(A*m0+B) and Dd*a*pstep==d*A*qstep
for h in range(8):
 n=n0+pstep*h;m=m0+qstep*h;z=n
 for bit in P:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
 y=m
 for bit in Q:assert y!=n and y%2==int(bit);y=(3*y+1)//2 if bit=='1' else y//2
 assert y==z and m<n
# Exact non-ancestry for every h: solve each affine prefix equality.
for j in range(len(Q)):
 aa,bb,dd=affine(Q[:j]);c=aa*m0+bb-dd*n0;s=aa*qstep-dd*pstep
 assert not(c==0 and s==0)
 if s:assert not((-c)%s==0 and (-c)//s>=0)
ledger=json.loads(Path('tmp/targets_E18/counting_inventory_with_C110.json').read_text());contained=[v['id'] for v in ledger['finite_ledger'] if pstep%v['modulus']==0 and (n0-v['residue'])%v['modulus']==0]
# Check ChatGPT's distinct normalized family, finite witness certificate and affine identities.
cp='11101';cq='11110111100';n=585447;m=462575
z=n
for bit in cp:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
y=m
for bit in cq:assert y!=n and y%2==int(bit);y=(3*y+1)//2 if bit=='1' else y//2
assert y==z==1481915
steps=0;y=m
while y!=1 and steps<10000:y=(3*y+1)//2 if y%2 else y//2;steps+=1
assert y==1
out={'empty_checked':295,'independent_states':calls,'witnesses_checked':14,'normalized_pair':[P,Q],'family':{'n0':n0,'P':pstep,'m0':m0,'Q':qstep},'single_finite_ledger_containments':contained,'full_CRT_deduplication_complete':False,'ChatGPT_example_convergence_steps':steps};(D/'independent_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
