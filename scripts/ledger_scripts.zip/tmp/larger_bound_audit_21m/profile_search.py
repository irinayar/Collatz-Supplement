from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21m');calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return x,''
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:return a[0],a[1]+'1'
 if k:
  a=inv(2*x,k-1,r)
  if a:return a[0],a[1]+'0'
 return None
old=json.loads(Path('tmp/larger_bound_audit_21h/k126_target_queries.json').read_text());patterns={q['word']:q for q in old};records=[]
for w,q in sorted(patterns.items(),key=lambda pair:(len(pair[0]),pair[0])):
 M=2**(len(w)+1);n0=q['n']-q['lift']*M;x0=q['x']-2*3**q['r']*q['lift']
 for t in range(81):
  n=n0+M*t;z=x0+2*3**q['r']*t
  status='covered_C61' if n%3==2 else 'covered_C110' if n%9==4 else 'pending'
  records.append({'word':w,'n':n,'x':z,'k':q['k'],'r':q['r'],'M':M,'lift':t,'status':status})
for q in records:
 if q['status']!='pending':continue
 try:a=inv(q['x'],q['k']+2,q['r']+4)
 except Budget:break
 if a:
  m,w=a;assert 0<m<q['n'];z=m;states=[m]
  for bit in w:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2;states.append(z)
  assert z==q['x'];c=0
  while c<min(len(w),len(q['word'])) and w[-1-c]==q['word'][-1-c]:c+=1
  path=[m];z=m
  while z!=1 and len(path)<10000:z=(3*z+1)//2 if z%2 else z//2;path.append(z)
  assert z==1;q.update(status='certified_witness',m=m,target_word=w,common_suffix_length=c,visits_source=q['n'] in states[:-1],convergence_path=path,height_threshold_h=0)
 else:q['status']='empty_layer_exact'
 (D/'profile_queries.json').write_text(json.dumps(records,indent=2))
(D/'profile_queries.json').write_text(json.dumps(records,indent=2));(D/'remaining_queries.json').write_text(json.dumps([q for q in records if q['status']=='pending'],indent=2));out={'patterns':len(patterns),'rows':len(records),'nodes':calls,'statuses':{s:sum(q['status']==s for q in records) for s in sorted({q['status'] for q in records})},'nonancestor_witnesses':sum(q['status']=='certified_witness' and not q['visits_source'] for q in records)};(D/'target_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
