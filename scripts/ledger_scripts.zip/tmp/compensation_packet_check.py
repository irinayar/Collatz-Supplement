from pathlib import Path
prefix=Path('tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0]
exec(prefix.replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import zipfile,runpy,sys,json,hashlib,time
start=time.time();folder=Path('tmp/compensation_packet_audit');folder.mkdir(exist_ok=True);inp=folder/'input';inp.mkdir(exist_ok=True)
z=zipfile.ZipFile('packet/Collatz_Aggregate_Compensation.zip');review=[]
for info in z.infolist():
 if not info.filename.startswith('aggregate_compensation_work/') or not info.filename.endswith(('.py','.json')):continue
 assert info.file_size<2000000
 name=Path(info.filename).name;data=z.read(info);(inp/name).write_bytes(data);review.append(dict(member=info.filename,sha256=hashlib.sha256(data).hexdigest()))
sys.path.insert(0,str(inp.resolve()));results=[]
for script,cert in [('verify_six_note_homogeneous_audit.py','six_note_homogeneous_audit_certificate.json'),('verify_exact_signed_compensation.py','exact_signed_compensation_certificate.json'),('verify_source_cylinder_carleson.py','source_cylinder_carleson_certificate.json')]:
 target=folder/cert
 if not target.exists():
  sys.argv=[str(inp/script),'--output',str(target.resolve())];runpy.run_path(str(inp/script),run_name='__main__')
 assert json.loads(target.read_bytes())==json.loads((inp/cert).read_bytes())
 assert target.read_bytes().replace(bytes([13,10]),bytes([10]))==(inp/cert).read_bytes()
 results.append(dict(script=script,newline_normalized_identical=True,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
report=dict(status='PASS',archive_sha256=hashlib.sha256(Path('packet/Collatz_Aggregate_Compensation.zip').read_bytes()).hexdigest(),results=results,extracted=review,seconds=time.time()-start)
(folder/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(status='PASS',checks=len(results),seconds=report['seconds'])),flush=True);os._exit(0)

