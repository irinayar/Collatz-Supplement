from pathlib import Path
p=Path('tmp/five_even_height_application/check.py').read_text(encoding='utf-8-sig')
p=p.replace("D=Path('tmp/five_even_height_application')","D=Path('tmp/feasible_five_height')")
p=p.replace("f=json.loads(Path('tmp/claude_reconcile_batch02/remaining_frontier.json').read_text())","""f=json.loads(Path('tmp/five_even_height_application/remaining_frontier.json').read_text())
claimed=json.loads(Path('tmp/collatz_two_arc/frontier_emptiness_claude_results.json').read_text())
selected=[q for q in f if claimed[q['index']]['status']=='unresolved']
assert len(selected)==44""")
p=p.replace("proof={};leaves={};results=[];calls=0;found=None","""for n in json.loads(Path('tmp/five_even_height_application/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
proof={};leaves={};results=[];calls=0;found=None;attempts=[];local_start=0;local_leaves=0""")
p=p.replace("if len(leaves)>=500 or time.monotonic()-start>30:raise Cap()","if len(leaves)>=500 or len(leaves)-local_leaves>=10 or time.monotonic()-start>30:raise Cap()")
p=p.replace("if calls>50000 or time.monotonic()-start>30:raise Cap()","if calls>50000 or calls-local_start>1000 or time.monotonic()-start>30:raise Cap()")
p=p.replace("if z['all_counts_too_high']:proof[key]=dict(rule='five_height');return True\n  if z['requested_min'] is None:proof[key]=dict(rule='five_empty');return True","if z['requested_min'] is None:proof[key]=dict(rule='five_empty');return True\n  if z['all_counts_too_high']:proof[key]=dict(rule='five_height');return True")
p=p.replace('range(min(a,r)+1)','range(min(a,r),-1,-1)').replace('range(min(a3(x+1),r)+1)','range(min(a3(x+1),r),-1,-1)')
a=p.index('# Bounded profile');b=p.index('# Independent inverse-edge enumeration')
p=p[:a]+'''samples=[]
for q in selected:
 if calls>=50000 or time.monotonic()-start>30:break
 local_start=calls;local_leaves=len(leaves)
 try:excluded=reject(q['z'],q['b'],q['t']-q['b'])
 except Cap:
  attempts.append(dict(index=q['index'],status='pending',calls=calls-local_start,leaves=len(leaves)-local_leaves));continue
 results.append(dict(**q,excluded=excluded));attempts.append(dict(index=q['index'],status='excluded' if excluded else 'candidate',calls=calls-local_start,leaves=len(leaves)-local_leaves))
 (D/'progress.json').write_text(json.dumps(dict(results=results,attempts=attempts,calls=calls)),encoding='utf8')
 if not excluded:break
''' +p[b:]
p=p.replace('total_target_excluded=109+len(excluded)','total_target_excluded=110+len(excluded)')
p=p.replace('old_sample_count=len(samples)','attempted_roots=len(attempts),feasible_leaves=sum(z["requested_min"] is not None for z in leaves.values()),old_sample_count=len(samples)')
p=p.replace("[('results',out),","[('attempts',attempts),('results',out),")
Path('tmp/feasible_five_height/check.py').write_text(p,encoding='utf8');exec(compile(p,'bounded_probe','exec'))
