from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
D=Path('tmp/feasible_five_height');N=4064460795;y=7821397930;L=129;b=82
U=(2**L*y-(3**b-2**b))//3**b
z=N;ones=0
for i in range(26):ones+=z%2;z=(3*z+1)//2 if z%2 else z//2
assert z==y and ones==17 and 0<U<N
f=json.loads(Path('tmp/five_even_height_application/remaining_frontier.json').read_text());assert all(82<=q['level']<=92 for q in f)
rows=[dict(odd_count=b,upper_origin=(2**L*y-(3**b-2**b))//3**b) for b in range(82,93)]
assert all(q['upper_origin']<N for q in rows)
out=dict(source=N,endpoint=y,total_length=L,min_odd_count=82,upper_origin=U,strict_margin=N-U,source_meeting_steps=26,source_meeting_odds=ones,rows=rows)
(D/'height_obstruction.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
