from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
from collections import Counter
D=Path('tmp/feasible_five_height');D.mkdir(exist_ok=True)
c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());counts=Counter();candidates={}
for level,v in c['levels'].items():
 for t,z,b in v['seen']:
  if t-b==5:
   counts['saved_five_nodes']+=1;candidates.setdefault((z,b),dict(level=int(level),t=t,z=z,b=b))
chosen=sorted(candidates.values(),key=lambda q:(q['b'],q['z']))[:500];records=[]
for q in chosen:
 z=q['z'];r=q['b'];top=R(z,5);at=H(z,r,5);records.append(dict(**q,R=top,H=at))
 counts['tested']+=1;counts['feasible' if at is not None else 'empty']+=1
 if at is not None:counts['height_excluded' if at>=4064460795 else 'smaller_candidate']+=1
(D/'seen_profile.json').write_text(json.dumps(dict(counts=dict(counts),records=records),indent=2),encoding='utf8');print(dict(counts),flush=True);os._exit(0)
