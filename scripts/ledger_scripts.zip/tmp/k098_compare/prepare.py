from pathlib import Path
base=Path('tmp/precision12_continue02/check.py').read_text(encoding='utf-8-sig')
for variant in ('baseline','composed'):
 p=base.replace("D=Path('tmp/precision12_continue02')",f"D=Path('tmp/k098_compare/{variant}')")
 p=p.replace("tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())","""for n in json.loads(Path('tmp/precision12_continue02/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
for n in json.loads(Path('tmp/composed_residue_cost/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())""")
 p=p.replace('class Cap(Exception):pass',f'''enabled={variant=='composed'}
work=composition_calls=0;local_work=0;verifying=False
class Cap(Exception):pass
def charge():
 global work
 if verifying:return
 work+=1
 if work-local_work>500 or work>22500 or time.monotonic()-start>30:raise Cap()
def composed(x,q,p,k):
 global composition_calls
 if not verifying:composition_calls+=1
 charge()
 if q==0:return min(k+1,tables[p][x%3**p])
 if x%3==0:return k+1
 best=k+1;j=0;z=x
 while j<best:
  if z%3==2:best=min(best,j+composed((2*z-1)//3,q-1,p,best-j-1))
  z*=2;j+=1
 return best''')
 p=p.replace('if calls>50000 or calls-local_start>1000 or time.monotonic()-start>30:raise Cap()','charge()')
 p=p.replace(' if k<=5:\n'," if enabled and r>=14 and k>5:\n  bound=composed(x,2,12,k)\n  if bound>k:proof[key]=dict(rule='composed_residue',q=2,p=12,bound=bound);return True\n if k<=5:\n")
 p=p.replace(' if calls>=50000 or time.monotonic()-start>30:break',' if work>=22500 or time.monotonic()-start>30:break')
 p=p.replace(' local_start=calls;local_leaves=len(leaves)',' local_start=calls;local_work=work;local_leaves=len(leaves)')
 p=p.replace('calls=calls-local_start,leaves=', 'calls=calls-local_start,work=work-local_work,leaves=')
 p=p.replace('# Independent inverse-edge enumeration','verifying=True\n# Independent inverse-edge enumeration')
 p=p.replace(" elif rule=='residue_even_cost':"," elif rule=='composed_residue':\n  assert r>=14 and composed(x,2,12,k)==n['bound']>k\n elif rule=='residue_even_cost':")
 p=p.replace('out=dict(precision=12,per_root_budget=1000,','out=dict(variant="'+variant+'",work_units=work,composition_calls=composition_calls,precision=12,per_root_work_budget=500,')
 d=Path('tmp/k098_compare')/variant;d.mkdir(parents=True,exist_ok=True);(d/'check.py').write_text(p,encoding='utf8')
p=Path('tmp/k098_compare/baseline/check.py').read_text();exec(compile(p,'baseline','exec'))
