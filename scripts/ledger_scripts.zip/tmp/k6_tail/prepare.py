from pathlib import Path
p=Path.cwd();src=(p/'tmp/k2_tail/audit.py').read_text()
src=src.replace("B=max(","family.__defaults__=(6,)\nB=max(",1)
a=src.index('f0=family(0)');b=src.index('result=',a)
src=src[:a]+'''f0=family(0);assert f0['rho']%9==4
rows=[family(s) for s in range(101)]
assert all(f['rho']%9==1 for f in rows[1:])
assert (512*rows[1]['rho']+1)%729==0
assert (rows[1]['rho']-(1-27*pow(32,-1,729)))%729!=0
assert rows[2]['rho']%81==46 and all(f['rho']%81==19 for f in rows[3:])
'''+src[b:]
src=src.replace("'s0_C110_containment':[10,81]","'s0_C110_containment':[4,9]")
src=src.replace("if (4*z['residue']-1)%p3==0:","if (64*z['residue']-1)%p3==0:")
src=src.replace("rho=pow(4,-1,q)","rho=pow(64,-1,q)")
src=src.replace("assert vals[3]+vals[4]==F(old['depths'][str(T)]['increment'])","assert all(v>=0 for v in vals)")
src=src.replace("base=json.loads((D/'counting_inventory_with_C110.json').read_text())","base={'expected':json.loads((root/'tmp/k2_tail/coverage_extension.json').read_text())['depths']}")
src=src.replace("'increment_beyond_C112_lower':str(lo-vals[3]-vals[4]),","")
src=src.replace("'increment_vs_E18_C110_lower'","'increment_vs_C113_ledger_lower'").replace("'increment_vs_E18_C110_upper'","'increment_vs_C113_ledger_upper'")
src=src.replace("D/'counting_inventory_with_C110.json',root/", "root/'tmp/k2_tail/coverage_extension.json',D/'counting_inventory_with_C110.json',root/")
(p/'tmp/k6_tail/audit.py').write_text(src)
print('prepared bounded k6 exact accounting')
