from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,hashlib
O=Path.cwd();D=O/'tmp/k6_tail';inv=json.loads((O/'tmp/targets_E18/counting_inventory_with_C110.json').read_text());cert=json.loads((O/inv['C85']['file']).read_text())['certificates'];c85=[(z['n'],2**27) for z in cert if z['meeting'] is not None and z['descent'] is None];out={}
for k in [0,2,6]:
 raw=[];compatible=[]
 for z in inv['finite_ledger']:
  mod=z['modulus'];b=mod&-mod;t=mod//b
  if (2**k*z['residue']-1)%t==0:raw.append((z['residue']%b,b));compatible.append(z)
 raw+=c85;keep=[]
 for a,m in sorted(set(raw),key=lambda z:z[1]):
  if not any(m%q==0 and a%q==b for b,q in keep):keep.append((a,m))
 out[str(k)]={'compatible_finite_rules':compatible,'canonical_disjoint_binary_union':keep}
out['k0_equals_k2']=out['0']['canonical_disjoint_binary_union']==out['2']['canonical_disjoint_binary_union'];assert out['k0_equals_k2']
assert out['6']['canonical_disjoint_binary_union']==[(0,1)]
# All s>=6 are contained in C108-18, stronger than a numerical zero tail.
r=json.loads((D/'results.json').read_text());assert (64*991-1)%2187==0
assert all(f['q']%2187==0 and f['rho']%2187==991 for f in r['families'][6:])
for T,v in r['depths'].items():assert all(x=='0' for x in v['head_marginals'][6:]) and v['theta']=='0'
(D/'projection_certificate.json').write_text(json.dumps(out,indent=2));extension={'base':'tmp/k2_tail/coverage_extension.json','base_sha256':hashlib.sha256((O/'tmp/k2_tail/coverage_extension.json').read_bytes()).hexdigest(),'class':'C114','scope':'Only k6 s1..5 add; s0 subsetC110; all s>=6 subsetC108-18; conditional-rule density','families':r['families'][1:6],'depths':r['depths']};(D/'coverage_extension.json').write_text(json.dumps(extension,indent=2))
print('canonical binary unions equal k0/k2:',out['k0_equals_k2'],'sizes',[len(out[str(k)]['canonical_disjoint_binary_union']) for k in [0,2,6]],flush=True);os._exit(0)
