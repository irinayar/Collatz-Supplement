from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_reduction');D.mkdir(exist_ok=True);checks=series=0
for x in range(1,1001):
 a=a3(x+1);u=(x+1)//3**a
 vals=[H(x,r,5) for r in range(R(x,5)+1)]
 assert all(vals[i]>vals[i+1] for i in range(len(vals)-1));series+=1
 if a>=2:
  star=9*2**(a-2)*u-1;assert a3(star+1)==2
  for r in range(R(x,5)+2):
   assert H(x,r,5)==(32*(2**r*3**(a-r)*u-1) if r<a else H(star,r-a+2,5));checks+=1
  for l in range(a-2):assert R(2*(2**l*((x+1)//3**l)-1),4)==2
sub=0
for u in range(2,3001,3):
 x=3*u-1;C=4*u-1;A=6*u-2;B=4*u-2
 assert R(B,4)==0
 assert H(A,1,4)-H(B,0,4)==8
 assert H(A,2,4)==(32*C-20)//3
 assert H(B,0,4)-H(A,2,4)==(16*C-28)//3>0;sub+=1
out=dict(reduction_cells=checks,subfamily_cases=sub,global_monotonicity_series_tested_not_proved=series,seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
