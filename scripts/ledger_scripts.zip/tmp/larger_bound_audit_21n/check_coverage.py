from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('rows=[family')[0])
from math import gcd
z=(303,5184);assert z[0]%3==0 and z[1]%3==0
# Complete later coverage additions are ancestor words with odd inputs ending at n,
# so their source n is nonzero modulo3; no overlap with this progression.
assert gcd(5184,8192)==64 and 303%64!=103%64
assert all(ns['crt'](z,ns['c08'](k)) is None for k in range(1,100))
left=[z]
for w0 in ns['base']:left=[y for x in left for y in ns['subtract'](x,w0)]
res={'family':z,'finite_ledger_entries':len(ns['inv']['finite_ledger']),'remaining_disjoint_cylinders':left,'disjoint_C08':True,'disjoint_C85':True,'depths':{}}
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear()
 v=ns['gain']([z],ns['residual'])
 @lru_cache(None)
 def measure(z):
  r,mod=z;L=(mod&-mod).bit_length()-1;x=r;a=0
  for i in range(1,min(L,T)+1):
   bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
   if 3**a<2**i:return F()
  if L>=T:return F(1,mod)
  dp={a:1}
  for i in range(L+1,T+1):
   nxt={}
   for aa,num in dp.items():
    for bit in [0,1]:
     if 3**(aa+bit)>=2**i:nxt[aa+bit]=nxt.get(aa+bit,0)+num
   dp=nxt
  return F(sum(dp.values()),mod*2**(T-L))
 independent=sum((measure(x) for x in left),F());assert independent==F(v['net'])
 base=json.loads((root/'tmp/k12_bridge/coverage_extension.json').read_text())['depths'][str(T)]
 lo=F(base['combined_lower'])+independent;hi=F(base['combined_upper'])+independent
 def rounded(x):
  y=x*100*10**10+F(1,2);return y.numerator//y.denominator
 assert rounded(lo)==rounded(hi);rr=rounded(lo)
 res['depths'][str(T)]={'increment':str(independent),'old_lower':base['combined_lower'],'old_upper':base['combined_upper'],'new_lower':str(lo),'new_upper':str(hi),'rounded_percent_10dp':f'{rr//10**10}.{rr%10**10:010d}','independent_methods_agree':True,'accounting':v}
 (out/'coverage_checkpoint.json').write_text(json.dumps(res,indent=2));print(T,res['depths'][str(T)]['increment'],res['depths'][str(T)]['rounded_percent_10dp'],flush=True)
res['input_hashes']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'tmp/k12_bridge/coverage_extension.json',root/'tmp/targets_E18/counting_inventory_updated.json',root/'tmp/targets_E18/account_total.py',root/'tmp/k2_overlap/audit.py']}
(out/'coverage_result.json').write_text(json.dumps(res,indent=2));print('residual cylinders',len(left),flush=True);os._exit(0)
