from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
D=Path('tmp/claude244_reconcile');D.mkdir(exist_ok=True);start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads(Path('tmp/budgets12_14/remaining_frontier.json').read_text());proof={};results=[];counter=0
class Cap(Exception):pass
def impossible(x,r,k):
 global counter
 key=(x,r,k)
 if key in proof:return True
 counter+=1
 if counter>100000 or time.monotonic()-start>40:raise Cap()
 if r==0:return False
 if x%3==0:proof[key]=dict(rule='multiple3');return True
 if 2*3**r>2**r*(2**k*x+1):proof[key]=dict(rule='height');return True
 a=0;u=x+1
 while u%3==0:a+=1;u//=3
 if k==0:
  if r>a:proof[key]=dict(rule='allodd');return True
  return False
 children=[]
 for l in range(min(a,r)+1):
  y=2*(2**l*((x+1)//3**l)-1)
  if not impossible(y,r-l,k-1):return False
  children.append((y,r-l,k-1))
 proof[key]=dict(rule='union',children=children);return True
# Only Claude's fully specified complete-budget groups; avoid guessing partial k38/39 identities.
selected=sorted([q for q in f if q['t']-q['b']<=37],key=lambda q:(q['t']-q['b'],q['index']))
for q in selected:
 try:ex=impossible(q['z'],q['b'],q['t']-q['b'])
 except Cap:break
 results.append(dict(**q,excluded=ex))
 (D/'progress.json').write_text(json.dumps(dict(results=results,counter=counter)),encoding='utf8')
# Independent certificate replay: no recursive search, verify every stored inference.
for (x,r,k),node in proof.items():
 assert x>0 and r>0 and k>=0
 if node['rule']=='multiple3':assert x%3==0
 elif node['rule']=='height':assert 2*3**r>2**r*(2**k*x+1)
 else:
  a=0;u=x+1
  while u%3==0:a+=1;u//=3
  if node['rule']=='allodd':assert k==0 and r>a
  else:
   expected=[(2*(2**l*((x+1)//3**l)-1),r-l,k-1) for l in range(min(a,r)+1)]
   assert k>0 and [tuple(z) for z in node['children']]==expected and all(z in proof for z in expected)
for q in results:
 if q['excluded']:assert (q['z'],q['b'],q['t']-q['b']) in proof
excluded={q['index'] for q in results if q['excluded']};remaining=[q for q in f if q['index'] not in excluded]
seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');assert sha(seed)==json.loads(Path('tmp/budgets12_14/results.json').read_text())['checkpoint_sha256']
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert sha(Path(p))==h
(D/'proof.json').write_text(json.dumps([dict(x=x,r=r,k=k,**node) for (x,r,k),node in proof.items()]),encoding='utf8')
out=dict(selected=len(selected),completed=len(results),new_excluded=len(excluded),total_excluded=77+len(excluded),remaining=len(remaining),proof_nodes=len(proof),calls=counter,seconds=time.monotonic()-start,results=results,seed_sha256=sha(seed),v10_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');(D/'remaining_frontier.json').write_text(json.dumps(remaining,indent=2),encoding='utf8');print({k:v for k,v in out.items() if k!='results'},flush=True);os._exit(0)
