from pathlib import Path
p=Path(__file__).parent
exec((p/'audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json,hashlib
r=json.loads((p/'results.json').read_text());base=json.loads((p.parent/'targets_E18/counting_inventory_with_C110.json').read_text());ans={'base_file':'tmp/targets_E18/counting_inventory_with_C110.json','base_sha256':r['input_sha256']['counting_inventory_with_C110.json'],'added_class':'C112','families':r['families'],'scope':'Two k=2 progressions only, exact marginal after E18+C110, C08, C85 and depth-dependent coefficient stopping. Conditional-rule density, not convergence percentage. C111 not added.','depths':{}}
for T,row in r['depths'].items():
 inc=F(row['increment']);lo=F(base['expected'][T]['combined_lower'])+inc;hi=F(base['expected'][T]['combined_upper'])+inc
 def rnd(x):
  y=x*100*10**10+F(1,2);return y.numerator//y.denominator
 a,b=rnd(lo),rnd(hi);assert a==b
 pct=f'{a//10**10}.{a%10**10:010d}'
 ans['depths'][T]={'increment':str(inc),'combined_lower':str(lo),'combined_upper':str(hi),'rounded_percent_10dp':pct};print(T,pct,flush=True)
# Recheck stored full trajectories and absence of all finite baseline hits.
for z in r['starts']:
 assert not z['finite_hits'] and not z['C08'] and not z['C85'] and not z['C110'] and z['first_coefficient_crossing']>32
 for key in ['path','smaller_origin_to_one']:
  for a,b in zip(z[key],z[key][1:]):assert b==((3*a+1)//2 if a%2 else a//2)
 assert z['smaller_origin_to_one'][-1]==1
(p/'coverage_extension.json').write_text(json.dumps(ans,indent=2));os._exit(0)
