import ctypes as c, ctypes.wintypes as w, os, threading
# Enforced Windows job process-memory and CPU-time limits, plus wall timer.
class BASIC(c.Structure):
 _fields_=[('p',c.c_int64),('j',c.c_int64),('flags',w.DWORD),('min',c.c_size_t),('max',c.c_size_t),('active',w.DWORD),('aff',c.c_size_t),('priority',w.DWORD),('sched',w.DWORD)]
class IO(c.Structure):
 _fields_=[(x,c.c_uint64) for x in ['r','w','o','rb','wb','ob']]
class EXT(c.Structure):
 _fields_=[('basic',BASIC),('io',IO),('process',c.c_size_t),('job',c.c_size_t),('peakprocess',c.c_size_t),('peakjob',c.c_size_t)]
k=c.WinDLL('kernel32',use_last_error=True);k.CreateJobObjectW.restype=w.HANDLE;k.CreateJobObjectW.argtypes=[c.c_void_p,w.LPCWSTR];k.SetInformationJobObject.argtypes=[w.HANDLE,c.c_int,c.c_void_p,w.DWORD];k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.GetCurrentProcess.restype=w.HANDLE
job=k.CreateJobObjectW(None,None); lim=EXT();lim.basic.flags=0x100|2;lim.process=1024**3;lim.basic.p=55*10**7
assert k.SetInformationJobObject(job,9,c.byref(lim),c.sizeof(lim)),c.get_last_error()
assert k.AssignProcessToJobObject(job,k.GetCurrentProcess()),c.get_last_error()
threading.Timer(55,lambda:os._exit(124)).start()
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,hashlib,time
start=time.time();root=Path(__file__).resolve().parents[2];D=root/'tmp/targets_E18';out=Path(__file__).parent
src=(D/'account_total.py').read_text().split('results={}')[0].replace('tmp/targets_E16/counting_inventory_updated.json','tmp/targets_E18/counting_inventory_updated.json')
# Avoid irrelevant E16/E18 catalogue subtraction, retain the checked accounting kernel.
a=src.index('# New union is made disjoint');b=src.index('terms={}',a);src=src[:a]+src[b:]
ns={'__file__':str(D/'account_total.py')};exec(src,ns)
def family(s,k=2):
 r=2
 while 3**(r+s)<=2**(r+2*s+1+k):r+=1
 q=3**(r+s);p=2**(r+2*s+1+k);u=q+p//2**k-2**r*3**(s+1);rho=u*pow(p,-1,q)%q
 return dict(s=s,r=r,q=q,p=p,U=u,rho=rho,word='1'*r+'01'*s+'0'*(k+1))
rows=[family(s) for s in [3,4]];results={'families':rows,'starts':[],'depths':{},'limits':'Windows job 1 GiB process memory, 55 CPU seconds, 55-second wall timer'}
for n,s in [(2802175,3),(12013819,3),(7781407,4)]:
 f=family(s);assert n%f['q']==f['rho'];m=(f['p']*n-f['U'])//f['q'];x=m;path=[x]
 for bit in f['word']:
  assert x%2==int(bit);x=(3*x+1)//2 if x%2 else x//2;path.append(x)
 assert x==n and 0<m<n
 hits=[z['id'] for z in ns['inv']['finite_ledger'] if n%z['modulus']==z['residue']]
 c85=any(n%q==r for r,q in ns['c85']);xx=n;ones=0;cross=None;desc=None
 for i in range(1,101):
  ones+=xx%2;xx=(3*xx+1)//2 if xx%2 else xx//2
  if cross is None and 3**ones<2**i:cross=i
  if desc is None and xx<n:desc=i
 # C08 actual initial odd run followed by two even inputs.
 xx=n;run=0
 while xx%2:run+=1;xx=(3*xx+1)//2
 c08=run>=1 and xx%4==0
 # For these classes n=7 mod9, v3(n-1)=1: only C110 s=0 possible, residue4 mod9.
 assert n%9==7
 xx=m;cert=[xx]
 for i in range(2000):
  if xx==1:break
  xx=(3*xx+1)//2 if xx%2 else xx//2;cert.append(xx)
 assert xx==1
 results['starts'].append(dict(n=n,s=s,m=m,path=path,finite_hits=hits,C08=c08,C85=c85,C110=False,first_coefficient_crossing=cross,first_descent=desc,smaller_origin_to_one=cert))
(out/'checkpoint.json').write_text(json.dumps(results,indent=2))
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear();vals=[]
 for f in rows:
  z=(f['rho'],f['q']);assert z[0]%9==7
  v=ns['gain']([z],ns['residual'])
  # Independently subtract finite ledger into disjoint cylinders; forward DP replaces recursive tail.
  left=[z]
  for w0 in ns['base']:left=[y for x in left for y in ns['subtract'](x,w0)]
  @lru_cache(None)
  def measure(z):
   r,mod=z;L=(mod&-mod).bit_length()-1;x=r;a=0
   for i in range(1,min(L,T)+1):
    bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
    if 3**a<2**i:return F()
   if L>=T:return F(1,mod)
   dp={a:1}
   for i in range(L+1,T+1):
    nxt={}
    for aa,num in dp.items():
     for bit in [0,1]:
      if 3**(aa+bit)>=2**i:nxt[aa+bit]=nxt.get(aa+bit,0)+num
    dp=nxt
   return F(sum(dp.values()),mod*2**(T-L))
  check=ns['gain'](left,measure);assert check==v,(check,v)
  vals.append(dict(s=f['s'],accounting=v,disjoint_residual_count=len(left),independent_match=True))
 total=sum((F(v['accounting']['net']) for v in vals),F());results['depths'][str(T)]={'families':vals,'increment':str(total)}
 (out/'checkpoint.json').write_text(json.dumps(results,indent=2));print(T,str(total),flush=True)
results['elapsed_seconds']=time.time()-start
results['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [D/'counting_inventory_updated.json',D/'counting_inventory_with_C110.json',D/'account_total.py']}
(out/'results.json').write_text(json.dumps(results,indent=2));print('starts',[(z['n'],z['m'],z['first_coefficient_crossing']) for z in results['starts']],flush=True)
os._exit(0)
