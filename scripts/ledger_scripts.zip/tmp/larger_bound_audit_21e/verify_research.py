from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
import json
D=Path('tmp/larger_bound_audit_21e');calls=0
@lru_cache(maxsize=50000)
def least(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:
  a=3**r
  return 2**r*(x+1)//a-1 if (x+1)%a==0 else None
 y=x;options=[]
 for ell in range(r+1):
  a=least(2*y,k-1,r-ell)
  if a is not None and a>0:options.append(a)
  if y%3!=2:break
  y=(2*y-1)//3
 return min(options) if options else None
qs=json.loads((D/'different_even_queries.json').read_text())
for q in qs:
 assert least(q['x'],q['k']+1,q['r']+1)==q['m']==(4*q['n']-1)//3
 assert q['target_word']=='10'+q['source_word']
checks=[]
for N in range(1,65):
 modulus=2**(3*N+4);a=8 if N%2 else 1;m=(a*modulus-25)//9
 assert m==(-25*pow(9,-1,modulus))%modulus and 0<m<modulus
 for x in [m,m+modulus]:
  y=x
  for e in [1,1,1]+[2,1]*N:
   z=3*y+1;v=(z&-z).bit_length()-1;assert v==e;y=z>>v;assert y>x
 checks.append({'N':N,'least_start':m,'modulus':modulus})
out={'target_queries':len(qs),'independent_states':calls,'all_minima_confirmed':True,'cylinder_N_checked':[1,64],'representatives_per_cylinder':2}
(D/'independent_checks.json').write_text(json.dumps(out,indent=2));(D/'short_recovery_cylinders.json').write_text(json.dumps(checks,indent=2));print(json.dumps(out),flush=True);os._exit(0)
