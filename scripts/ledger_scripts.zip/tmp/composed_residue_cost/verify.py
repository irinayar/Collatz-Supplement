from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/composed_residue_cost');rows=json.loads((D/'sample_bounds.json').read_text());selected=sorted([q for q in rows if q['additional']],key=lambda q:q['k'])[:32];out=[]
for q in selected:
 tr=tree(q['x'],q['k']);assert max(tr)<14;out.append(dict(x=q['x'],k=q['k'],max_feasible_odds=max(tr)))
(D/'independent_composition_checks.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(dict(independent_extra_cuts=len(out),seconds=time.monotonic()-start),flush=True);os._exit(0)
