from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from collections import Counter
D=Path('tmp/composed_residue_cost');D.mkdir(exist_ok=True);start=time.monotonic();tab=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text());N=4064460795
front=json.loads(Path('tmp/five_even_height_application/remaining_frontier.json').read_text());reported=json.loads(Path('tmp/collatz_two_arc/frontier_emptiness_claude_results.json').read_text());roots=sorted([q for q in front if reported[q['index']]['status']=='unresolved'],key=lambda q:(q['t']-q['b'],q['index']))
work=0
class Cap(Exception):pass
def composition(x,q,p,k):
 global work
 work+=1
 if work>45000 or time.monotonic()-start>30:raise Cap()
 if q==0:return min(k+1,tab[p][x%3**p])
 if x%3==0:return k+1
 best=k+1;j=0;z=x
 while j<best:
  if z%3==2:best=min(best,j+composition((2*z-1)//3,q-1,p,best-j-1))
  z*=2;j+=1
 return best
rootbounds=[]
for q in roots:
 x=q['z'];k=q['t']-q['b'];base=tab[12][x%3**12]
 assert composition(x,2,10,k)==min(base,k+1)
 refined=composition(x,2,12,k);assert refined>=min(base,k+1)
 rootbounds.append(dict(index=q['index'],z=x,k=k,r=q['b'],d12=base,d14_clipped=refined,excluded=refined>k))
# Fixed baseline union-state sample: no root-credit for already-proved descendants.
saved=json.loads(Path('tmp/precision12_continue02/proof.json').read_text());sample=[z for z in saved if z['rule']=='union' and z['r']>=14][:200];sample_rows=[]
for z in sample:
 x,k=z['x'],z['k'];d12=tab[12][x%3**12];d14=composition(x,2,12,k)
 assert composition(x,2,10,k)==min(k+1,d12)
 sample_rows.append(dict(x=x,r=z['r'],k=k,d12=d12,d14_clipped=d14,additional=d12<=k<d14))
# Reuse every verified negative cache. Preserve dependencies in the manifest.
paths=['tmp/claude_reconcile_batch02/proof.json','tmp/five_even_height_application/proof.json','tmp/feasible_five_height/proof.json','tmp/exact_feasibility_44_batch01/proof.json','tmp/residue_feasibility_44/proof.json','tmp/residue_precision_compare/p10/proof.json','tmp/residue_precision_compare/p12/proof.json','tmp/precision12_continue01/proof.json','tmp/cutoff_compare12/k5/proof.json','tmp/cutoff_compare12/k6/proof.json','tmp/precision12_continue02/proof.json']
old=set()
for path in paths:
 for z in json.loads(Path(path).read_text()):old.add((z['x'],z['r'],z['k']))
proof={};attempts=[];calls=0;local=0;found=None
# Return a positive origin on success, None only after a complete exclusion.
def solve(x,r,k):
 global calls
 key=(x,r,k)
 if key in old or key in proof:return None
 calls+=1
 if calls-local>500 or calls>22500 or time.monotonic()-start>35:raise Cap()
 p=min(12,r)
 if tab[p][x%3**p]>k:proof[key]=dict(rule='residue_cost',p=p);return None
 if r<=12:
  y=x;left=k;t=r
  while t:
   a=y%3**t;cost=tab[t][a]
   if y%3==2 and tab[t-1][((2*y-1)//3)%3**(t-1)]==cost:y=(2*y-1)//3;t-=1
   else:assert left>0;y*=2;left-=1
  return y*2**left
 # Enumerate every possible number of evens preceding the first inverse odd.
 children=[];z=x
 for j in range(k+1):
  if z%3==2:
   child=((2*z-1)//3,r-1,k-j);ans=solve(*child)
   if ans is not None:return ans
   children.append(child)
  z*=2
 proof[key]=dict(rule='first_odd_union',children=children);return None
for q in roots:
 local=calls
 try:ans=solve(q['z'],q['b'],q['t']-q['b'])
 except Cap:attempts.append(dict(index=q['index'],status='pending',calls=calls-local));continue
 if ans is None:attempts.append(dict(index=q['index'],status='excluded',calls=calls-local))
 else:
  m=ans;z=m;odd=0
  for i in range(q['t']):odd+=z%2;z=(3*z+1)//2 if z%2 else z//2
  assert z==q['z'] and odd==q['b'] and 0<m<N
  for i in range(129-q['t']):z=(3*z+1)//2 if z%2 else z//2
  assert z==7821397930
  z=m;steps=0
  while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
  found=dict(index=q['index'],m=m,converged=z==1,steps=steps);attempts.append(dict(index=q['index'],status='candidate'));break
 (D/'progress.json').write_text(json.dumps(attempts),encoding='utf8')
# Independent local certificate replay of all complete new negative subproofs.
for (x,r,k),z in proof.items():
 if z['rule']=='residue_cost':assert z['p']==min(12,r) and tab[z['p']][x%3**z['p']]>k
 else:
  expected=[((2**(j+1)*x-1)//3,r-1,k-j) for j in range(k+1) if (2**j*x)%3==2]
  assert [tuple(t) for t in z['children']]==expected and all(t in old or t in proof for t in expected)
out=dict(representative=rootbounds[0],root_count=len(roots),root_bounds_improved=sum(z['d14_clipped']>z['d12'] for z in rootbounds),root_cuts=[z['index'] for z in rootbounds if z['excluded']],fixed_sample=len(sample_rows),additional_sample_cuts=sum(z['additional'] for z in sample_rows),composition_calls=work,search_calls=calls,new_proof_nodes=len(proof),attempt_status=dict(Counter(z['status'] for z in attempts)),found=found,seconds=time.monotonic()-start)
for name,data in [('results',out),('root_bounds',rootbounds),('sample_bounds',sample_rows),('attempts',attempts),('proof',[dict(x=x,r=r,k=k,**z) for (x,r,k),z in proof.items()]),('dependencies',paths)]: (D/(name+'.json')).write_text(json.dumps(data,indent=2),encoding='utf8')
for path,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
print(out,flush=True);os._exit(0)
