#!/usr/bin/env python3
"""Exact controls for first-run phase gates and off-core descent credits.

The finite profiles are small-band controls of identities and injectivity,
not examples of unresolved high-floor core contributions.
"""
from collections import Counter
from fractions import Fraction as F
import json
from pathlib import Path


def val2(x):
    return (x & -x).bit_length() - 1


def recover_gate_source(n, B, g, y):
    """A necessary integer candidate, not a guarantee of an actual prefix."""
    H = (4*n-2)//3
    omega = (H+B)/(H+1)
    lower = 3**g*(n+B)/y
    upper = 3**g*(H+B+omega)/y
    e = max(0,lower.numerator.bit_length()-lower.denominator.bit_length())
    while 2**e <= lower:
        e += 1
    while e > 0 and 2**(e-1) > lower:
        e -= 1
    if not 2**e < upper:
        return None
    T = F(2**e*y,3**g)-B
    z = (T-1)/2
    ceil_z = -((-z.numerator)//z.denominator)
    u = 2*ceil_z-1
    if n <= u <= H and u > T-omega:
        return u,e
    return None


def profile(u, n, bound=2000):
    H = (4*n-2)//3
    x, q, lam, g, E = u, F(0), F(1), 0, 0
    runs = []
    while g < bound:
        a, p, begin, start_g, start_E = x, q, [], g, E
        for _ in range(bound-g):
            begin.append(x)
            e = val2(3*x+1)
            q += lam/3
            lam *= F(2**e, 3)
            x = (3*x+1)//2**e
            E += e
            g += 1
            if e >= 2:
                break
        else:
            return None
        s = len(begin)
        beta = 1-F(2,3)**s
        delta = beta/a
        f = F(1,a)-F(1,x)
        assert q-p == (u+p)*delta
        assert lam*x == u+q
        runs.append(dict(a=a,b=x,p=p,q=q,s=s,e=e,delta=delta,f=f,
                         inputs=begin,g=g,E=E,start_g=start_g,start_E=start_E))
        if x <= H:
            return dict(u=u,n=n,H=H,w=x,runs=runs) if x >= n else None
    return None


def main():
    if not __debug__:
        raise RuntimeError("Run without -O.")
    records, statistics = [], []
    bounds_checked = credits_checked = 0
    for n in [10697, 21395, 42791]:
        H = (4*n-2)//3
        # A specified admissible gate parameter; no claim that this is the
        # original prescribed source-count functional for these small bands.
        Pstar = n
        B = F(5) + F(n,100000*Pstar)
        omega = F(H,1)/(H+1)+B/(H+1)
        assert 0 < omega < 2
        assert H+B+omega < 2*(n+B)
        gates, completed, next_R_paid = {}, 0, 0
        for u in range(n,H+1,2):
            p = profile(u,n)
            if p is None:
                continue
            completed += 1
            for i, run in enumerate(p['runs']):
                if run['q'] <= B:
                    continue
                # First complete-run phase crossing. Terminal gate does
                # not become a proper future-contribution candidate.
                assert run['p'] <= B
                if run['b'] <= H:
                    break
                q, g, E, y = run['q'],run['g'],run['E'],run['b']
                assert run['a'] > H
                assert B < q < B+omega
                assert F(2**E,3**g)*y == u+q
                assert recover_gate_source(n,B,g,y) == (u,E)
                key = (g,y)
                assert key not in gates or gates[key] == u
                gates[key] = u
                inputs = [x for r in p['runs'][:i+1] for x in r['inputs']]
                high_spent = sum((F(1,x) for x in inputs[1:]),F(0))
                # All noninitial inputs are proper high states.
                assert all(x > H for x in inputs[1:])
                ceiling = 3*(B+omega-F(1,3))/(n+F(1,3))
                assert high_spent < ceiling
                bounds_checked += 1
                if len(records) < 12:
                    records.append(dict(n=n,u=u,g=g,E=E,y=y,
                                        phase=str(q),ceiling=str(ceiling),
                                        high_spent=str(high_spent)))
                # Every run before this gate has start phase <= B and
                # therefore is off-core under the necessary original gate.
                for j in range(i+1):
                    selected = p['runs'][j:i+1]
                    X, phase0 = selected[0]['a'],selected[0]['p']
                    credit = sum((max(F(0),-r['f']-r['delta']/15)
                                  for r in selected),F(0))
                    debit = F(1,y)-F(1,X)-(q-phase0)/(15*(u+phase0))
                    assert credit >= max(F(0),debit)
                    credits_checked += 1
                    if i+1 < len(p['runs']):
                        r = p['runs'][i+1]
                        if (r['s'],r['e']) == (2,2):
                            kappa = F(n-1,n+1)
                            charge = max(F(0),kappa*r['delta']+r['f'])
                            assert charge <= F(2,3*y)
                            if q-phase0 <= F(5*(u+phase0),y)-F(15*(u+phase0),X):
                                assert credit >= charge
                                next_R_paid += 1
                break
        statistics.append(dict(n=n,H=H,completed=completed,
                               proper_first_run_gates=len(gates),
                               certified_next_R_payment_segments=next_R_paid))
    # Generic exact algebra controls supplement the actual-profile checks.
    assert F(5) + F(2**71,100000) < (4*2**71-2)//3+2
    report = dict(
        passed=True,
        scope="Small-band first-gate and credit controls; no late-core or uniform aggregate claim.",
        bands=statistics,first_gate_spend_controls=bounds_checked,
        off_core_credit_controls=credits_checked,examples=records,
    )
    Path(__file__).with_name('first_gate_certificate.json').write_text(
        json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
