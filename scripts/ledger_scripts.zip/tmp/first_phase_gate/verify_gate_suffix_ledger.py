#!/usr/bin/env python3
"""Exact first-gate suffix-mask and signed-ledger control on the saved profile.

This replays the physical suffix independently and compares a factorized
core mask with the full original-mask certificate. It proves no aggregate
bound and does not posit additional source copies.
"""
from fractions import Fraction as F
from pathlib import Path
import json


def main():
    if not __debug__:
        raise RuntimeError("Run without -O.")
    root = Path(__file__).resolve().parent
    cert = json.loads((root / "fixture" / "near_miss_certificate.json").read_text())
    original = json.loads((root / "fixture" / "near_miss_input.json").read_text())
    n, H, u = (int(cert[key]) for key in ("n", "H", "u"))
    Pstar = int(cert["Pstar"])
    B = F(cert["B"])
    gate = cert["first_complete_run_phase_gate"]
    g, prefix_E, y = gate["g"], gate["E"], int(gate["y"])
    k = gate["run_index"] + 1
    lam = F(2**prefix_E, 3**g)
    q_gate = F(gate["crossing_phase"])
    assert lam*y == u+q_gate and q_gate > B and y > H

    # Reconstruct the actual physical suffix from y until its first odd
    # state at or below H. No future exponent is prescribed here.
    states, times, phases, shortcut, word = [y], [0], [F(0)], [y], []
    multiplier = F(1)
    x, elapsed = y, 0
    for _ in range(2000):
        z = 3*x+1
        exponent = (z & -z).bit_length()-1
        phases.append(phases[-1] + multiplier/3)
        multiplier *= F(2**exponent, 3)
        word.append(exponent)
        x = z//2
        shortcut.append(x)
        for _ in range(exponent-1):
            assert x % 2 == 0
            x //= 2
            shortcut.append(x)
        elapsed += exponent
        states.append(x)
        times.append(elapsed)
        if x <= H:
            break
    else:
        raise RuntimeError("Saved suffix did not finish within the replay guard.")
    assert n <= x <= H
    assert word == original["word"][g:]
    assert elapsed == cert["shortcut_length"] - prefix_E
    assert all(x > H for x in states[:-1])

    suffix_runs, begin = [], 0
    for end, exponent in enumerate(word, 1):
        if exponent >= 2:
            suffix_runs.append((begin, end, exponent))
            begin = end
    assert begin == len(word)
    assert len(suffix_runs) == len(cert["all_runs"])-k
    original_runs = cert["all_runs"]
    assert not any(row["core"] for row in original_runs[:k])
    kappa = F(n-1, n+1)
    L, m = n.bit_length()-1, n.bit_length()
    baseline_credit = F(0)
    rectangle_weight = F(0)
    direct_post_score = F(0)
    selected = []
    controls = []
    for j, (i, end, exponent) in enumerate(suffix_runs):
        a, b = states[i], states[end]
        s = end-i
        beta = 1-F(2, 3)**s
        delta = beta/a
        flux = F(1, a)-F(1, b)
        signed = kappa*delta+flux
        credit = max(F(0), -flux-delta/15)
        ell = a.bit_length()-1
        shell = ell-L
        J = 2**ell//(2000*Pstar*(shell+1)*(shell+2))
        endpoint = times[i]+ell
        physical = (H < a < 2**(64*m)
                    and endpoint < elapsed
                    and 64*shortcut[endpoint] > a
                    and len(suffix_runs)-j > J)
        remaining_phase = phases[-1]-phases[i]
        assert remaining_phase > 0
        rectangle = lam > B/remaining_phase and k > J-j
        member = bool(physical and rectangle)
        expected = original_runs[k+j]
        assert member == expected["core"]
        assert a == int(expected["a"]) and b == int(expected["b"])
        assert signed == F(expected["signed_t"])
        assert credit == F(expected["off_core_credit"])
        assert q_gate+lam*phases[i] == F(expected["q"])
        assert lam*remaining_phase == F(expected["remaining_phase"])
        assert signed+credit >= (kappa-F(1, 15))*delta > 0
        baseline_credit += credit
        if member:
            rectangle_weight += signed+credit
            direct_post_score += signed
            selected.append(g+i)
        else:
            direct_post_score -= credit
        controls.append({
            "suffix_run": j, "physical_predicate": bool(physical),
            "rectangle_predicate": bool(rectangle), "core": member,
        })
    assert selected == cert["core_odd_starts"]
    post_score = -baseline_credit+rectangle_weight
    assert post_score == direct_post_score
    entry_credit = sum((F(row["off_core_credit"])
                        for row in original_runs[:k]), F(0))
    full_score = post_score-entry_credit
    assert full_score == F(cert["original_signed_profile_score"])
    result = {
        "status": "PASS",
        "scope": "One original high-floor profile; factorized suffix core mask and exact signed ledger.",
        "suffix_runs_checked": len(suffix_runs),
        "original_core_runs_recovered": len(selected),
        "gate_depth": g, "gate_exponent": prefix_E,
        "entry_reset_count": k,
        "entry_credit": str(entry_credit),
        "post_score": str(post_score),
        "whole_profile_score": str(full_score),
        "multiplicity_claim": "No additional source is fabricated; the multi-source identity is proved algebraically.",
        "all_depth_bound_proved": False,
        "controls": controls,
    }
    (root / "gate_suffix_ledger_certificate.json").write_text(
        json.dumps(result, indent=2)+"\n"
    )
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("entry_credit", "post_score", "whole_profile_score", "controls")},
                     indent=2))


if __name__ == "__main__":
    main()
