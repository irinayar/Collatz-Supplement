from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json,time
D=Path('tmp/tail_transition');start=time.monotonic();data=json.loads(Path('tmp/odd_count_separation/closure.json').read_text());S={int(u) for u in data['H']}
def f(u):return F(3*u+1,3*u)
def nxt(u):
 v=(3*u+1)//2
 while v%2==0:v//=2
 return v
# Independent reproduction of weighted999 certificate.
def weighted(seeds,q):
 W=F(1);arg=None
 for u in seeds:
  v=u;g=F(1);s=0
  while v!=1:
   assert s<1000;g*=f(v);v=nxt(v);s+=1
   if g/q**s>W:W=g/q**s;arg=(u,s)
 return W,arg
w999,arg999=weighted(range(3,1000,2),F(3004,3003));assert w999==F(2012030040030012002,1614663884607228009)
a=f(1025);pairs=[]
for u in range(1025,8193,2):
 if u in S:continue
 v=nxt(u)
 if v not in S:pairs.append((f(u)*f(v),u,v))
beta,u,v=max(pairs);large=f(8193)*a;assert large<=beta<a*a
# Full finite suffix profiles, normalized for the parity of total odd count.
We=Wo=F(1);arge=argo=None;profiles=[]
for u0 in sorted(S-{1}):
 u1=u0;g=F(1);s=0
 while True:
  bpow=beta**(s//2)
  ce=g/bpow if s%2==0 else a*g/(bpow*beta)
  co=a*g/bpow if s%2==0 else g/bpow
  if ce>We:We=ce;arge=(u0,s)
  if co>Wo:Wo=co;argo=(u0,s)
  profiles.append((u0,s,str(g)))
  if u1==1:break
  g*=f(u1);u1=nxt(u1);s+=1;assert s<1000
# include no-entry case: even beta^h, odd alpha beta^h
We=max(We,F(1));Wo=max(Wo,a)
def bound(r):return beta**(r//2)*(Wo if r%2 else We)
R=0
while bound(R+1)<F(3,2):R+=1
assert all(bound(r)<F(3,2) for r in range(R+1))
# Replay actual prefixes and paired-outside bound including concrete suffix.
checks=0
for m in range(3,4096,2):
 u0=m;G=F(1);r=0
 while u0!=1:
  G*=f(u0);u0=nxt(u0);r+=1;assert r<1000
  assert G<=bound(r)
  if r<=R:assert G<F(3,2)
  checks+=1
out={'weighted999':str(w999),'weighted999_arg':arg999,'alpha':str(a),'beta':str(beta),'pair_max':[u,v],'large_u_bound':str(large),'We':str(We),'Wo':str(Wo),'arg_even':arge,'arg_odd':argo,'R':R,'bound_R':str(bound(R)),'bound_next':str(bound(R+1)),'profile_count':len(profiles),'pair_cells':len(pairs),'trajectory_prefixes':checks,'seconds':time.monotonic()-start}
(D/'results.json').write_text(json.dumps(out,indent=2));(D/'profiles.json').write_text(json.dumps(profiles));(D/'pair_certificate.json').write_text(json.dumps([[str(z),u,v] for z,u,v in pairs]));print(json.dumps({k:v for k,v in out.items() if k not in ['bound_R','bound_next']},indent=2),flush=True);os._exit(0)
