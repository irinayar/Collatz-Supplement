from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
D=Path('tmp/integer_height_envelope');start=time.monotonic();N=4064460795;J=129;H=4;tables=[[{0:(0,0)}]]
for j in range(1,J+1):
 new=[{} for _ in range(j+1)]
 for b,layer in enumerate(tables[-1]):
  for lo,hi in layer.values():
   for bb,L,U in [(b,lo,hi),(b+1,3*lo+2**(j-1),3*hi+2**(j-1))]:
    r=L%3**min(H,bb);assert r==U%3**min(H,bb);prev=new[bb].get(r);new[bb][r]=(min(L,prev[0]),max(U,prev[1])) if prev else (L,U)
 tables.append(new)
# Full word enumeration verifies both extrema, including absence of other cells.
checks=0
for t in range(1,11):
 brute=[{} for _ in range(t+1)]
 for w in range(2**t):
  V=b=0
  for k in range(t):
   if w>>k&1:V=3*V+2**k;b+=1
  r=V%3**min(H,b);old=brute[b].get(r);brute[b][r]=(min(V,old[0]),max(V,old[1])) if old else (V,V)
 assert brute==tables[t];checks+=sum(map(len,brute))
c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']];cuts=[];rows=[]
for i,q in enumerate(frontier):
 t,z,b=q['t'],q['z'],q['b'];B=2**t*z;Q=3**b;bounds=tables[t][b].get(B%3**min(H,b)) if 0<=b<=t else None
 if bounds is None:cuts.append(i);continue
 lo,hi=bounds;L=max(lo,B-Q*(N-1));U=min(hi,B-Q);first=L+(B-L)%Q;last=U-(U-B)%Q
 if first>last:cuts.append(i)
 rows.append(dict(index=i,numerator_min=lo,numerator_max=hi,height_intersection_lower=L,height_intersection_upper=U,full_modulus=Q,endpoint_numerator=B,first=first,last=last,origin_lower=(B-last)//Q,origin_upper=(B-first)//Q,excluded=first>last))
r=json.loads((D/'results.json').read_text());baseline={q['index'] for q in r['results'][-1]['cuts']};res=dict(extrema_cells_verified=checks,frontier=len(frontier),excluded=len(cuts),additional_over_baseline=sorted(set(cuts)-baseline),bounds=rows,seconds=time.monotonic()-start)
(D/'lattice_results.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k!='bounds'}),flush=True);os._exit(0)
