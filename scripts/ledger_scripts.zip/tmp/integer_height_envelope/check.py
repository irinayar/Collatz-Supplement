from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
D=Path('tmp/integer_height_envelope');start=time.monotonic();seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');c=json.loads(seed.read_text());N=4064460795;J=129
frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']]
def build(n,M,J):
 first={r:(r if r else M,n-1-(n-1-r)%M) for r in range(M)};first={r:p for r,p in first.items() if p[0]<=p[1]};allrows=[[first]]
 for j in range(1,J+1):
  new=[{} for _ in range(j+1)]
  for b,layer in enumerate(allrows[-1]):
   for lo,hi in layer.values():
    for bit in [0,1]:
     low=lo+((bit-lo)%2)*M;high=hi-((hi-bit)%2)*M
     if low>high:continue
     low=(3*low+1)//2 if bit else low//2;high=(3*high+1)//2 if bit else high//2;bb=b+bit;r=low%M
     prev=new[bb].get(r);new[bb][r]=(min(low,prev[0]),max(high,prev[1])) if prev else (low,high)
  allrows.append(new)
 return allrows
# independent forward containment on small origins for several moduli
checks=0
for smallN in [2,17,80]:
 for M in [1,3,9,27]:
  tab=build(smallN,M,10)
  for m in range(1,smallN):
   x=m;b=0
   for t in range(11):
    lo,hi=tab[t][b][x%M];assert lo<=x<=hi;checks+=1
    bit=x%2;b+=bit;x=(3*x+1)//2 if bit else x//2
results=[]
for h in [0,2,3,4]:
 M=3**h;tab=build(N,M,J);cuts=[];survivors=[]
 for i,q in enumerate(frontier):
  t,z,b=q['t'],q['z'],q['b'];bounds=tab[t][b].get(z%M) if 0<=b<=t else None
  if bounds is None or not(bounds[0]<=z<=bounds[1]):cuts.append(dict(index=i,**q,bounds=bounds))
  else:survivors.append(i)
 results.append(dict(h=h,modulus=M,excluded=len(cuts),cuts=cuts,survivors=survivors));print('precision',h,'frontier',len(frontier),'excluded',len(cuts),flush=True)
 (D/'checkpoint.json').write_text(json.dumps(dict(completed_h=h,seconds=time.monotonic()-start)))
 del tab
res=dict(origin_bound=N,source_nodes=c['nodes'],frontier_states=len(frontier),forward_checks=checks,results=results,seed_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(res,indent=2));print('seconds',res['seconds'],'checks',checks,flush=True);os._exit(0)
