from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from functools import lru_cache
D=Path('tmp/integer_height_envelope');start=time.monotonic();n=4064460795;J=129;H=4;tables=[[{0:0}]]
for j in range(1,J+1):
 new=[{} for _ in range(j+1)]
 for b,layer in enumerate(tables[-1]):
  for V in layer.values():
   for bb,Z in [(b,V),(b+1,3*V+2**(j-1))]:
    r=Z%3**min(H,bb);new[bb][r]=max(new[bb].get(r,-1),Z)
 tables.append(new)
r=json.loads((D/'results.json').read_text());c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']];oldcuts=[]
for i,q in enumerate(frontier):
 t,z,b=q['t'],q['z'],q['b']
 if b<0 or b>t:oldcuts.append(i);continue
 E=2**t*z-3**b*(n-1);top=2**(t-b)*(3**b-2**b);M=tables[t][b].get(2**t*z%3**min(4,b));cut=M is None or M<E
 if (2**t*z-top)%3**b and (b==t or b>=1 and top-3**(b-1)*2**(t-b-1)<E):cut=True
 if cut:oldcuts.append(i)
newcuts={q['index'] for q in r['results'][-1]['cuts']};extra=sorted(newcuts-set(oldcuts));combined=set(oldcuts)|newcuts
counts={lev:dict(total=sum(q['level']==lev for q in frontier),remaining=sum(q['level']==lev and i not in combined for i,q in enumerate(frontier))) for lev in range(82,93)}
res=dict(old_exclusions=len(oldcuts),new_exclusions=len(newcuts),additional_over_existing=len(extra),additional_states=[frontier[i] for i in extra],combined_exclusions=len(combined),per_level=counts)
(D/'comparison.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
