from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
import json,hashlib
D=Path('tmp/integer_height_envelope');r=json.loads((D/'lattice_results.json').read_text());seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');c=json.loads(seed.read_text());f=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']]
@lru_cache(maxsize=100000)
def extrema(t,b,h,res):
 if b<0 or b>t:return None
 h=min(h,b);res%=3**h
 if h==0:return (3**b-2**b,2**(t-b)*(3**b-2**b))
 choices=[]
 if b<t:
  z=extrema(t-1,b,h,res)
  if z:choices.append(z)
 p=2**(t-1)
 if b and (res-p)%3==0:
  z=extrema(t-1,b-1,h-1,(res-p)//3)
  if z:choices.append((3*z[0]+p,3*z[1]+p))
 return (min(z[0] for z in choices),max(z[1] for z in choices)) if choices else None
cert=[]
for row in r['bounds']:
 if row['index'] not in r['additional_over_baseline']:continue
 q=f[row['index']];B=2**q['t']*q['z'];Q=3**q['b'];ex=extrema(q['t'],q['b'],4,B%3**min(4,q['b']))
 assert ex==(row['numerator_min'],row['numerator_max'])
 L=row['height_intersection_lower'];U=row['height_intersection_upper'];assert L<=U and (B-L)%Q>U-L
 cert.append(dict(state=q,certificate=row))
assert len(cert)==10
for name,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
assert hashlib.sha256(seed.read_bytes()).hexdigest()==json.loads((D/'results.json').read_text())['seed_sha256']
(D/'certificates.json').write_text(json.dumps(dict(verified=True,independent_recurrence=True,certificates=cert,search_checkpoint_unchanged=True,v9_unchanged=True),indent=2));print('10 full-modulus gap certificates independently checked; checkpoint and v9 unchanged',flush=True);os._exit(0)
