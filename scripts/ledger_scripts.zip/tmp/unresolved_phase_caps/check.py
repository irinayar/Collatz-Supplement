from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time,hashlib
from fractions import Fraction as F
from math import factorial
from functools import lru_cache
start=time.monotonic();scale=2**256
@lru_cache(None)
def budget(n):
 H=(4*n-2)//3;L=(H+1).bit_length()-1
 v,S=min((F(3**s-1,2**L)+F(200,7)*F(193,200)**(s+1)+F(L+1,2**(L-1)),s) for s in range(2*L+1))
 return L,v,S
up=lambda x:F(-((-x.numerator*scale)//x.denominator),scale)
down=lambda x:F((x.numerator*scale)//x.denominator,scale)
def expup(z):
 z=up(z);assert 0<=z<1
 return sum((z**j/factorial(j) for j in range(13)),F(0))+z**13/F(factorial(13))/(1-z/14)
def caps(n,u,odd_inputs,q):
 L,v,S=budget(n)
 # Lower rounding makes subtraction safe even for very long exact prefixes.
 used=sum((down(F(1,x)) for x in odd_inputs),F(0));high=sum((down(F(1,x)) for x in odd_inputs if x>=2**L),F(0))
 b=min(F(144,125)-used,v-high);assert b>=0
 base=F(15*u,32);expcap=up(((1+q/u)*expup(b/3)-1))*u
 lin=up((q/u+F(47,32)*b/3))*u
 return min(base,expcap,lin),dict(S=S,L=L,b=str(up(b)),relative=float(min(base,expcap,lin)/base))
def potential(n,u,B,q,Qbar):
 H=(4*n-2)//3;a=H+1+(11-H-1)%16;d=F(5,9*a);C=F(n-1,n+1)+F(9*(a+5),5*(9*a+5));T=Qbar-B;lo=max(q,B)
 if lo>=T:return F(0)
 return C*(min(Qbar,T+d*(u+T))-lo)/(u+lo)
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count
old=json.loads(Path('tmp/singleton_charge_bounds/checks.json').read_text());wanted={(int(r['n']),int(r['u'])):r['resolution'] for r in old['rows']};rows=[];tests=improvements=0
for group in json.loads((I/'exact_compensation_seeds.json').read_text())['groups']:
 n=int(group['n'])
 for item in group['sources']:
  u=int(item['u'])
  if (n,u) not in wanted:continue
  p=replay(n,item);B=5+F(n,100000*source_count(n));running=F(15*u,32);samples=[]
  for d in sorted(set([wanted[n,u],min(wanted[n,u]+4,len(item['word'])-1)])):
   # Bound function sees ONLY prefix inputs and phase, never the final Q.
   bound,meta=caps(n,u,p['odd'][:d],p['phases'][d]);running=min(running,bound);assert p['Q']<=running;tests+=1;improvements+=running<F(15*u,32)
   v=potential(n,u,B,p['phases'][d],running);vold=potential(n,u,B,p['phases'][d],F(15*u,32));assert v<=vold
   samples.append(dict(depth=d,cap=str(running),ratio=meta['relative'],potential_ratio=float(v/vold) if vold else None,terminal_phase_used_in_bound=False))
  rows.append(dict(n=str(n),u=str(u),samples=samples))
# A new unresolved source, not taken from any completed trajectory certificate.
u=2**256-1;n=3*2**254+1;H=(4*n-2)//3;x=u;E=num=0;word=[];odd=[u];shortcut=[u];lo=n;resolution=None;checkpoints=[]
for g in range(1,257):
 z=3*x+1;e=(z&-z).bit_length()-1;num=3*num+2**E;E+=e;word.append(e)
 y=z//2;shortcut.append(y)
 for _ in range(e-1):y//=2;shortcut.append(y)
 x=y;odd.append(x);assert x>H
 q=F(num,3**g);lo=max(lo,(2**E*H-num)//3**g+1,(32*q.numerator)//(15*q.denominator)+1);M=2**(E+1);r=(2**E-num)*pow(3**g,-1,M)%M;f=lo+(r-lo)%M;c=max(0,(H-f)//M+1);assert c>=1 and (u-f)%M==0
 if c==1 and resolution is None:resolution=g;assert f==u
 if g in [254,256]:
  cap,meta=caps(n,u,odd[:-1],q);checkpoints.append(dict(depth=g,q=str(q),cap=str(cap),**meta))
assert resolution is not None and len(set(shortcut[:-1]))==len(shortcut[:-1])
assert word[:-1]==[1]*255 and word[-1]==11
# B is not needed to certify the eventual-phase cap. We deliberately do not compute future return.
P=source_count(n);B=5+F(n,100000*P);newpot=potential(n,u,B,q,F(checkpoints[-1]['cap']));oldpot=potential(n,u,B,q,F(15*u,32));assert newpot<=oldpot
fresh=dict(B=str(B),potential=str(newpot),old_potential=str(oldpot),potential_ratio=float(newpot/oldpot),observed_R_runs=0,n=str(n),u=str(u),H=str(H),word=word,depth=256,current=str(x),E=E,q=str(q),resolution_depth=resolution,checkpoints=checkpoints,status='UNRESOLVED: no return in the computed prefix; future not computed',terminal_phase_used=False)
result=dict(status='PASS',saved_checks=tests,saved_improvements=improvements,rows=rows,new_unresolved=fresh,runtime_seconds=time.monotonic()-start,limits='1GiB/120sec',scope='K164/K187 composition; conditional caps for any genuine completion, not proof of return or small aggregate.')
Path('tmp/unresolved_phase_caps/checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(status='PASS',saved_checks=tests,saved_improvements=improvements,saved_ratios=[r['samples'][0]['ratio'] for r in rows],fresh_resolution=resolution,fresh_ratio=checkpoints[-1]['relative'],fresh_S=checkpoints[-1]['S'],seconds=result['runtime_seconds'])),flush=True);os._exit(0)

