from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from functools import lru_cache
D=Path('tmp/fair_terminal129_batch04');start=time.monotonic();n=4064460795;J=129;H=4;tables=[[{0:0}]]
for j in range(1,J+1):
 new=[{} for _ in range(j+1)]
 for b,layer in enumerate(tables[-1]):
  for V in layer.values():
   for bb,Z in [(b,V),(b+1,3*V+2**(j-1))]:
    r=Z%3**min(H,bb);new[bb][r]=max(new[bb].get(r,-1),Z)
 tables.append(new)
work=0
@lru_cache(maxsize=100000)
def R(t,b,h,r):
 global work
 work+=1
 if work>500000:raise RuntimeError('precision work cap')
 if b<0 or b>t:return -1
 h=min(h,b);r%=3**h
 if h<=4:return tables[t][b].get(r,-1) if h==min(4,b) else max((V for rr,V in tables[t][b].items() if rr%3**h==r),default=-1)
 best=R(t-1,b,h,r) if b<t else -1
 p=2**(t-1)
 if b and (r-p)%3==0:
  V=R(t-1,b-1,h-1,((r-p)//3)%3**(h-1))
  if V>=0:best=max(best,3*V+p)
 return best
old=json.loads((D/'seed_results.json').read_text());c=json.loads((D/'seed_checkpoint.json').read_text());y=old['y'];a=old['a'];nodes=c['nodes'];seed_nodes=nodes;assert seed_nodes==150000;node_limit=seed_nodes+100000
gap_prunes=old['gap_prunes'];prunes={int(k):v for k,v in old['prunes'].items()};quantum=128;found=None;found_level=None;status='running';turns=c['turns'];levels={int(b):dict(stack=[tuple(v) for v in z['stack']],seen={tuple(v) for v in z['seen']},nodes=z['nodes'],status=z['status']) for b,z in c['levels'].items()}
assert [b for b,z in levels.items() if z['stack']]==list(range(92,81,-1))
order=list(range(92,81,-1));last=turns[-1];partial=last['nodes'] if last['nodes']<128 and levels[last['level']]['stack'] else 0
idx=order.index(last['level']);idx=(idx if partial else (idx+1)%len(order));order=order[idx:]+order[:idx];first=True;last_saved=nodes
seed_hash=hashlib.sha256((D/'seed_checkpoint.json').read_bytes()).hexdigest()
def checkpoint():
 global last_saved
 data=dict(status=status,nodes=nodes,seed_nodes=seed_nodes,node_limit=node_limit,seed_hash=seed_hash,precision_work=work,turns=turns,levels={b:dict(stack=z['stack'],seen=sorted(z['seen']),nodes=z['nodes'],status=z['status']) for b,z in levels.items()},found=found,found_level=found_level)
 (D/'checkpoint.next.json').write_text(json.dumps(data));(D/'checkpoint.next.json').replace(D/'checkpoint.json');last_saved=nodes
def visit(t,z,b):
 global gap_prunes
 if b<0 or b>t:return None,[]
 T=2**t*z-3**b*n;top=2**(t-b)*(3**b-2**b)
 if (2**t*z-top)%3**b:
  if b==t:gap_prunes+=1;return None,[]
  if b>=1 and top-3**(b-1)*2**(t-b-1)<T+3**b:gap_prunes+=1;return None,[]
 for h in prunes:
  if h>4:continue
  if h>6 and t>20:continue
  if h>8 and t>16:continue
  M=R(t,b,h,2**t*z%3**min(h,b))
  if M<0 or M<T+3**b:prunes[h]+=1;return None,[]
  if (2**t*z-M)%3**b==0:
   m=(2**t*z-M)//3**b
   if 0<m<n:return m,[]
  if h>=b:break
 if t==0:return (z if b==0 and 0<z<n else None),[]
 children=[(t-1,2*z,b)]
 if b and z%3==2:children.append((t-1,(2*z-1)//3,b-1))
 return None,children
while nodes<node_limit and found is None:
 live=False
 for level in order:
  state=levels[level]
  if not state['stack']:continue
  live=True;used=0;limit=quantum-partial if first else quantum;first=False
  while state['stack'] and used<limit and nodes<node_limit:
   key=state['stack'].pop();nodes+=1;used+=1;state['nodes']+=1
   if key in state['seen']:continue
   m,children=visit(*key);state['seen'].add(key)
   if m is not None:found=m;found_level=level;break
   state['stack'].extend(children)
  state['status']='witness' if found is not None else ('pending' if state['stack'] else 'exhausted')
  turns.append(dict(level=level,nodes=used,total=nodes,status=state['status']))
  if nodes-last_saved>=2048:checkpoint()
  if found is not None or nodes>=node_limit:break
 if not live:break
status='witness' if found is not None else ('node cap' if nodes>=node_limit else 'exhausted');checkpoint()
res=dict(n=n,j=J,source_depth=26,y=y,a=a,status=status,m=found,level=found_level,nodes=nodes,new_nodes=nodes-seed_nodes,seed_nodes=seed_nodes,prunes=prunes,gap_prunes=gap_prunes,completed_levels=[b for b,z in levels.items() if z['status']=='exhausted'],pending_levels=[b for b,z in levels.items() if z['status']=='pending'],fallback_seconds=time.monotonic()-start)
if found is not None:
 x=found;path=[x];bc=0
 for k in range(J):
  bc+=x%2;x=(3*x+1)//2 if x%2 else x//2;path.append(x)
 assert x==y and bc==found_level and 0<found<n
 res['witness_path']=path;x=found;path=[x]
 for k in range(10000):
  if x==1:break
  x=(3*x+1)//2 if x%2 else x//2;path.append(x)
 res['to_one']=path;res['certified_to_one']=x==1
(D/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['witness_path','to_one','completed_levels']}),flush=True);os._exit(0)
