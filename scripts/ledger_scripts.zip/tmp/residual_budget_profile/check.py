from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
from collections import Counter
D=Path('tmp/residual_budget_profile');D.mkdir(exist_ok=True)
f=json.loads(Path('tmp/three_height_alternatives/remaining_frontier.json').read_text());assert len(f)==312
hist=Counter(q['t']-q['b'] for q in f)
selected=sorted(f,key=lambda q:(q['t']-q['b'],-q['b'],q['index']))[:12]
# Fixed small batch, no automatic extension after successes.
records=[];visits=0
for q in selected:
 x=q['z'];r=q['b'];k=q['t']-q['b'];bound=R(x,k);hm=H(x,r,k)
 stack=[(x,k,0)];mins={};local=0
 while stack:
  z,left,odds=stack.pop();visits+=1;local+=1
  assert visits<=100000,'independent node cap'
  if left==0:mins[odds]=min(z,mins.get(odds,z))
  if left:stack.append((2*z,left-1,odds))
  if z%3==2:stack.append(((2*z-1)//3,left,odds+1))
 assert max(mins)==bound and mins.get(r)==hm
 records.append(dict(**q,even_budget=k,max_odds=bound,min_origin=hm,excluded=hm is None or hm>=4064460795,reason='empty' if hm is None else 'height' if hm>=4064460795 else 'candidate',independent_nodes=local,independent_minima=mins))
excluded={q['index'] for q in records if q['excluded']};remain=[q for q in f if q['index'] not in excluded]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seed=Path('tmp/fair_terminal129_batch05/checkpoint.json')
assert sha(seed)==json.loads(Path('tmp/three_height_alternatives/results.json').read_text())['checkpoint_sha256']
for p,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert sha(Path(p))==h
out=dict(profile={str(k):v for k,v in sorted(hist.items())},selection='12 lowest even budgets, descending odd count, ascending index',records=records,new_excluded=sorted(excluded),total_excluded=54+len(excluded),remaining=len(remain),independent_nodes=visits,seconds=time.monotonic()-start,checkpoint_sha256=sha(seed),v9_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');(D/'remaining_frontier.json').write_text(json.dumps(remain,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='records'}));print([(q['index'],q['even_budget'],q['b'],q['max_odds'],q['reason']) for q in records],flush=True);os._exit(0)
