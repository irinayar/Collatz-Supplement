from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,time
D=Path('tmp/k081_tail_family');start=time.monotonic();rows=json.loads((D/'families.json').read_text())['results'];families={(q['e'],q['residue']):q for q in rows};checked_tails=words=paths=0
# Independent suffix enumeration uses subsets of positions, not gap vectors.
for (e,r),q in families.items():
 matches=[]
 for d in range(e+1):
  for other in itertools.combinations(range(1,4+d),3):
   pos=(0,)+other;V=sum(2**v*3**(3-i) for i,v in enumerate(pos));checked_tails+=1
   if V*pow(2,-(4+d),81)%81==r:matches.append((''.join('1' if i in pos else '0' for i in range(4+d)),d,V))
 assert matches==[(q['tail']['word'],e,q['tail']['V'])]
for t in range(4,15):
 for bits in range(2**t):
  b=bits.bit_count();e=t-b
  if b<4:continue
  V=0;w=''.join(str(bits>>i&1) for i in range(t))
  for i,x in enumerate(w):
   if x=='1':V=3*V+2**i
  q=families.get((e,V*pow(2,-t,81)%81))
  if q:assert w=='1'*(b-4)+q['tail']['word'];words+=1
for (e,r),q in families.items():
 A=q['coefficient']
 for b in range(4,81):
  Q=3**b;z0=A*pow(2,-(e+4),Q)%Q
  for shift in [1,2]:
   z=z0+Q*shift;F=2**(e+4)*z-A;assert F%Q==0;m=2**(b-4)*(F//Q)-1;assert m>0
   x=m;got=''
   for k in range(b+e):
    got+=str(x%2);x=(3*x+1)//2 if x%2 else x//2
   assert x==z and got=='1'*(b-4)+q['tail']['word'];paths+=1
c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());hits=[]
for lev,state in c['levels'].items():
 for t,z,b in state['stack']:
  q=families.get((t-b,z%81))
  if q and b>=4:
   F=2**(t-b+4)*z-q['coefficient'];v=0;u=F
   while u and u%3==0:v+=1;u//=3
   hits.append(dict(level=int(lev),t=t,z=z,b=b,e=t-b,residue=z%81,valuation=v,excluded=F%3**b!=0))
(D/'verification.json').write_text(json.dumps(dict(independent_suffix_checks=checked_tails,matching_full_words=words,actual_paths=paths,frontier_hits=hits,seconds=time.monotonic()-start),indent=2));print(json.dumps(dict(suffix_checks=checked_tails,full_words=words,actual_paths=paths,frontier_hits=len(hits),excluded=sum(q['excluded'] for q in hits),valuations=[q['valuation'] for q in hits],seconds=time.monotonic()-start)),flush=True);os._exit(0)
