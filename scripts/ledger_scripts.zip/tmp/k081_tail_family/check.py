from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,time
D=Path('tmp/k081_tail_family');start=time.monotonic();old=json.loads(Path('tmp/integer_height_envelope/certificates.json').read_text());out=[]
def tail(gaps):
 w=''.join('1'+'0'*g for g in gaps);V=b=0
 for i,x in enumerate(w):
  if x=='1':V=3*V+2**i;b+=1
 return w,V
for row in old['certificates']:
 q=row['state'];h=4;e=q['t']-q['b'];r=q['z']%3**h;matches=[]
 for g in itertools.product(range(e+1),repeat=h):
  if sum(g)>e:continue
  w,V=tail(g)
  if V*pow(2,-len(w),3**h)%3**h==r:matches.append(dict(gaps=g,word=w,V=V,evens=sum(g)))
 assert len(matches)==1 and matches[0]['evens']==e
 v=matches[0];A=v['V']-3**h;b=q['b'];formula=3**b+2**(b-h)*A
 assert formula==row['certificate']['numerator_min']==row['certificate']['numerator_max']
 full_ok=(2**q['t']*q['z']-formula)%3**b==0
 assert not full_ok
 out.append(dict(state=q,h=h,e=e,residue=r,tail=v,coefficient=A,full_compatible=full_ok))
(D/'families.json').write_text(json.dumps(dict(results=out,seconds=time.monotonic()-start),indent=2));print(json.dumps(out),flush=True);os._exit(0)
