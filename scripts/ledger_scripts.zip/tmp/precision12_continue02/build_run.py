from pathlib import Path
p=Path('tmp/cutoff_compare12/k5/check.py').read_text(encoding='utf-8-sig')
p=p.replace("D=Path('tmp/cutoff_compare12/k5')","D=Path('tmp/precision12_continue02')")
p=p.replace("tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())","""for n in json.loads(Path('tmp/cutoff_compare12/k5/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
for n in json.loads(Path('tmp/cutoff_compare12/k6/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text())""")
p=p.replace('calls-local_start>500','calls-local_start>1000').replace('per_root_budget=500','per_root_budget=1000')
Path('tmp/precision12_continue02').mkdir(exist_ok=True);Path('tmp/precision12_continue02/check.py').write_text(p,encoding='utf8');exec(compile(p,'precision12_continue02','exec'))
