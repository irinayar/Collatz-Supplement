from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21f');calls=0
@lru_cache(maxsize=50000)
def feasible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return (x+1)%3**r==0 and 2**r*(x+1)//3**r-1>0
 y=x
 for ell in range(r+1):
  if feasible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
qs=json.loads((D/'different_even_queries.json').read_text())
for q in qs:assert q['status']=='empty_layer_exact' and not feasible(q['x'],q['k']+q['dk'],q['r']+q['dr'])
rows=[];replays=0
for length in range(1,4):
 for pattern in itertools.product([1,2,3],repeat=length):
  A=B=0;A=1;den=1
  for s in pattern:
   a=3**(s+1);b=5*3**s-2**(s+2);d=2**(s+2)
   A,B,den=a*A,a*B+b*den,d*den
  delta=A-den;assert delta>0 and B>0
  for N in range(1,13):
   modulus=16*den**N;coef=27*delta;const=19*delta+8*B
   x=(-const*pow(coef,-1,modulus))%modulus;assert x>0
   assert coef*x>=modulus-const
   for start in [x,x+modulus]:
    y=start;vals=[1,1,1]+sum(([2]+[1]*s for s in pattern),[])*N
    for e in vals:
     z=3*y+1;actual=(z&-z).bit_length()-1;assert actual==e;y=z>>e;assert y>start
    replays+=1
   rows.append({'pattern':pattern,'N':N,'A':A,'B':B,'D':den,'least_start':x,'modulus':modulus})
out={'target_queries':len(qs),'independent_states':calls,'empty_confirmed':True,'patterns':39,'cylinders':len(rows),'trajectory_replays':replays}
(D/'mixed_cylinders.json').write_text(json.dumps(rows,indent=2));(D/'independent_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
