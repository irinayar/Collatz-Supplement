from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_g1');D.mkdir(exist_ok=True);cases=overlaps=takeovers=original=0;examples=[]
for w in range(1,3001):
 G=4*w-1
 if a3(G)!=1:continue
 h=G//3;P=lambda s:H(6*w-1,s,3);Q=lambda s:H(3*w-1,s,4)
 assert P(1)==8*G and Q(1)==8*G-8
 assert P(2)==16*h+1 and Q(2)==16*h-8
 assert R(6*w-1,3)==2+a3(8*h+1)
 for s in range(2,R(6*w-1,3)+1):
  assert P(s)==2**(s-1)*((8*h+1)//3**(s-2))-1
  if s==3:assert Q(s)==8*(4*h-1)//3-4 and P(s)-Q(s)==7
  if s==4:
   j=(4*h-1)//3;assert Q(s)==4*(4*j-1)//3-2 and P(s)-Q(s)==5
  if s>=5:assert Q(s) is None
  if Q(s) is not None:assert P(s)>Q(s);overlaps+=1
 if P(5) is not None:
  j=(4*h-1)//3
  assert h%27==10 and j%9==4 and R(3*w-1,4)==4
  assert Q(4)-P(5)==(16*j-37)//9==(64*h-127)//27>=19
  takeovers+=1
 vals=[min(v for v in (P(s),Q(s)) if v is not None) for s in range(1,max(R(6*w-1,3),R(3*w-1,4))+1)]
 assert all(a>b for a,b in zip(vals,vals[1:]));cases+=1
for u in range(1,3001,3):
 C=4*u-1;c=a3(C);v=C//3**c;w=2**(c-1)*v;G=4*w-1
 if a3(G)!=1:continue
 x=3*u-1
 for r in range(c+1,R(x,5)+2):
  assert H(6*u-2,r,4)==H(6*w-1,r-c,3)
  assert H(4*u-2,r-1,4)==H(3*w-1,r-c,4)
 vals=[H(x,r,5) for r in range(R(x,5)+1)]
 assert all(a>b for a,b in zip(vals,vals[1:]));original+=1
 if len(examples)<5:examples.append(dict(x=x,u=u,G=G))
# Independent inverse-edge tree on a small sample, without the last-even recurrence.
independent=0
for w in range(1,101):
 if a3(4*w-1)!=1:continue
 for x,k in ((6*w-1,3),(3*w-1,4)):
  tr=tree(x,k)
  assert {r:min(v) for r,v in tr.items()}=={r:H(x,r,k) for r in range(R(x,k)+1)};independent+=1
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out=dict(reduced_cases=cases,overlaps=overlaps,takeovers=takeovers,original_endpoint_series=original,independent_tree_cases=independent,examples=examples,seconds=time.monotonic()-start,v10_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
