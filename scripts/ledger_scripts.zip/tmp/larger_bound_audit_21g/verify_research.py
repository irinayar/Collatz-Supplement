from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from fractions import Fraction as F
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21g');calls=0
@lru_cache(maxsize=50000)
def least(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return 2**r*(x+1)//3**r-1 if (x+1)%3**r==0 else None
 y=x;opts=[]
 for ell in range(r+1):
  a=least(2*y,k-1,r-ell)
  if a is not None and a>0:opts.append(a)
  if y%3!=2:break
  y=(2*y-1)//3
 return min(opts) if opts else None
qs=json.loads((D/'different_even_queries.json').read_text())
for q in qs:assert least(q['x'],q['k']+2,q['r']+1)==q['m']>=q['n']
records=[];checks=0
for kind in range(2):
 for length in range(1,33):
  ss=[1+((j.bit_count()%2) if kind==0 else j.bit_count()%3) for j in range(length)]
  vals=[1,1,1]+sum(([2]+[1]*s for s in ss),[])
  A=1;B=0;den=1
  for e in vals:A,B,den=3*A,3*B+den,den*2**e
  modulus=2*den;x=((den-B)*pow(A,-1,modulus))%modulus;assert x>=15
  y=x;G=F(1);bound=1+F(25,9*x)
  for e in vals:
   z=3*y+1;assert (z&-z).bit_length()-1==e;G*=F(z,3*y);y=z//2**e
   assert G<bound<F(3,2);checks+=1
  # independently replay at block boundaries and verify potential absorption
  y=(27*x+19)//8
  for s in ss:
   a=3**(s+1);b=5*3**s-2**(s+2);d=2**(s+2);z=(a*y+b)//d
   g=F(d*z,a*y);assert g*(1+F(7,z))<=1+F(7,y)
   assert g== (1+F(b,(a-d)*y))/(1+F(b,(a-d)*z));y=z
  records.append({'kind':kind,'length':length,'recovery_lengths':ss,'least_start':x,'modulus':modulus,'product':str(G),'bound':str(bound)})
out={'target_queries':44,'independent_states':calls,'minimum_origins':sorted({q['m'] for q in qs}),'cylinders':len(records),'prefix_checks':checks,'all_checks_passed':True}
(D/'aperiodic_potential_tests.json').write_text(json.dumps(records,indent=2));(D/'independent_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
