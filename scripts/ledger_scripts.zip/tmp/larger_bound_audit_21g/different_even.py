from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21g');calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return (x,'')
 options=[]
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:options.append((a[0],a[1]+'1'))
 if k:
  a=inv(2*x,k-1,r)
  if a:options.append((a[0],a[1]+'0'))
 return min(options) if options else None
rows=[]
for suffix in ['21b','21c']:
 rows += [q for q in json.loads(Path('tmp/larger_bound_audit_'+suffix+'/k123_queries.json').read_text()) if q['n']==18839651253368551]
assert sorted(q['depth'] for q in rows)==list(range(11,55))
queries=[];pending=False
for q in sorted(rows,key=lambda q:q['depth']):
 for dk,dr in [(2,1)]:
  v={key:q[key] for key in ['n','depth','x','k','r','source_word']};v.update(dk=dk,dr=dr)
  try:a=inv(q['x'],q['k']+dk,q['r']+dr)
  except Budget:v['status']='budget_pending';queries.append(v);pending=True;break
  if a:
   m,w=a;z=m
   for bit in w:
    assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
   assert z==q['x'] and w.count('0')==q['k']+dk and w.count('1')==q['r']+dr
   v.update(m=m,target_word=w,status='witness' if m<q['n'] else 'minimum_not_smaller')
   if m<q['n']:
    z=m;steps=0
    while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
    assert z==1;v['convergence_steps']=steps
  else:v['status']='empty_layer_exact'
  queries.append(v)
  (D/'different_even_queries.json').write_text(json.dumps(queries,indent=2))
 if pending:break
out={'queries':len(queries),'nodes':calls,'pending':pending,'statuses':{s:sum(q['status']==s for q in queries) for s in ['witness','minimum_not_smaller','empty_layer_exact','budget_pending']}}
(D/'different_even_queries.json').write_text(json.dumps(queries,indent=2));(D/'different_even_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
