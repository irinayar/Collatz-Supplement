from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
out=Path('tmp/primitive_truncation');start=time.time()
def T(n): return (3*n+1)//2 if n%2 else n//2
def affine(mask,j):
 a=U=0
 for i in range(j):
  if mask>>i&1: U=3*U+(1<<i);a+=1
 return a,U
def trim(mask,b,c):
 for i in range(mask.bit_length()):
  if b==c:break
  if mask>>i&1:mask^=1<<i;b-=1
 return mask
def replay(n,mask,j):
 for i in range(j):
  assert n%2==(mask>>i&1);n=T(n)
 return n
rows=[]
for j in range(1,11):
 B=1<<j;ws=[(*affine(v,j),v) for v in range(B)];count=0
 for a,U,w in ws:
  r=(-U*pow(3**a,-1,B))%B
  for b,V,v in ws:
   if b<a+2 or (V-U)%3**a:continue
   q=3**(b-a);h=((V-U)//3**a)%q
   n=r+B*(((h-r)*pow(B,-1,q))%q);period=B*q
   while n<B or 3**a*n+U<=V:n+=period
   m=(3**a*n+U-V)//3**b
   vt=trim(v,b,a+1);bt,Vt=affine(vt,j)
   assert bt==a+1 and (V-Vt)%3**(a+1)==0 and 0<=Vt<=V
   num=3**a*n+U-Vt;assert num%3**(a+1)==0
   mt=num//3**(a+1)
   assert 0<mt<n and 0<m<n
   y=replay(n,w,j);assert replay(m,v,j)==y==replay(mt,vt,j)
   count+=1
 rows.append(dict(j=j,compatible_high_pairs=count))
 (out/'checkpoint.json').write_text(json.dumps(rows))
# Find a concrete small-height failure of this PARTICULAR transformation.
fail=None; controls=0
for j in range(1,21):
 if fail:break
 fibres={}
 for n in range(1,1025):
  x=n;mask=0
  for i in range(j):mask|=(x%2)<<i;x=T(x)
  a,U=affine(mask,j)
  for m,b,v in fibres.get(x,[]):
   if b<a+2:continue
   vt=trim(v,b,a+1);bt,Vt=affine(vt,j);mt=(3**a*n+U-Vt)//3**(a+1)
   assert replay(mt,vt,j)==x
   controls+=1
   if mt>=n:
    fail=dict(j=j,n=n,m=m,source_odd=a,partner_odd=b,endpoint=x,truncated_origin=mt,source_word=''.join(str(mask>>i&1) for i in range(j)),partner_word=''.join(str(v>>i&1) for i in range(j)),truncated_word=''.join(str(vt>>i&1) for i in range(j)))
    break
  fibres.setdefault(x,[]).append((n,a,mask))
  if fail:break
res=dict(rows=rows,small_transform_checks=controls,small_transform_failure=fail,seconds=time.time()-start,limits='Windows job 1GiB; 55 CPU and wall seconds')
(out/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
