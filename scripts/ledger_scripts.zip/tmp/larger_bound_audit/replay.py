from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
from fractions import Fraction as F
D=Path('tmp/larger_bound_audit');start=time.monotonic();count=0;steps=0
for line in (D/'trajectory_counts.jsonl').open():
 m,L,r=json.loads(line);assert m==3+2*count;u=m;ll=rr=0
 while u!=1:
  if u%2:rr+=1;u=(3*u+1)//2
  else:u//=2
  ll+=1;assert ll<=10000
 assert (ll,rr)==(L,r);count+=1;steps+=ll
 if count%4096==0:assert time.monotonic()-start<42
assert count==131070
# New ChatGPT excursion identities: exact actual transitions, not assumed words.
exc=0
for N in range(1,20):
 for a in range(1,10):
  u0=2**(N+2)*a-1;u=u0;G=F(1)
  for i in range(N):
   z=3*u+1;assert z%4==2;v=z//2;assert v==3**(i+1)*2**(N+1-i)*a-1 and v>u
   G*=F(z,3*u);u=v
  assert G==1+(1-F(2,3)**N)/u0;exc+=1
res={'all_starts_checked':count,'elementary_steps':steps,'excursion_checks':exc,'seconds':time.monotonic()-start};(D/'independent_replay.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
