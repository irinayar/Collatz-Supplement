from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from fractions import Fraction as F
D=Path('tmp/larger_bound_audit');start=time.monotonic();H=2**18-3;Qn=2**61;Qd=3**32*993;maxn,maxd=1,1;at=[];count=0;maxsteps=0;maxstate=0
with (D/'trajectory_counts.jsonl').open('w') as out:
 for m in range(3,H+1,2):
  u=m;L=r=0
  while u!=1:
   z=3*u+1;v=(z&-z).bit_length()-1;u=z>>v;L+=v;r+=1
   maxstate=max(maxstate,u);assert r<10000
  n=1<<L;d=3**r*m
  assert n*Qd<=Qn*d
  if n*maxd>maxn*d:maxn,maxd=n,d;at=[m]
  elif n*maxd==maxn*d:at.append(m)
  out.write(json.dumps([m,L,r],separators=(',',':'))+'\n');count+=1;maxsteps=max(maxsteps,L)
  if count%4096==0:
   out.flush();(D/'checkpoint.json').write_text(json.dumps({'last_start':m,'processed':count,'complete':False}));assert time.monotonic()-start<42
assert F(maxn,maxd)==F(Qn,Qd)
qden=3*(H+2);qnum=qden+1
# Binary-search exact rational exponent cutoff. No floating logs.
def passes(r):return 2*Qn*pow(qnum,r)<3*Qd*pow(qden,r)
lo,hi=0,200000
assert passes(lo) and not passes(hi)
while hi-lo>1:
 mid=(lo+hi)//2
 if passes(mid):lo=mid
 else:hi=mid
assert passes(lo) and not passes(lo+1)
res={'H':H,'odd_starts_excluding1':count,'Q':str(F(Qn,Qd)),'maximizers':at,'r_max':lo,'q':[qnum,qden],'max_steps':maxsteps,'max_odd_state':maxstate,'seconds':time.monotonic()-start,'counts_sha256':hashlib.sha256((D/'trajectory_counts.jsonl').read_bytes()).hexdigest()}
(D/'results.json').write_text(json.dumps(res,indent=2));(D/'checkpoint.json').write_text(json.dumps({'last_start':H,'processed':count,'complete':True}));print(json.dumps(res),flush=True);os._exit(0)
