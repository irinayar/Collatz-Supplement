from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json,time
start=time.time();A=F(47,32);budget=50000;nodes=0;rows=[]
def trajectory(u,j):
 x=u;a=U=0;seen=set();floor=True
 for i in range(j):
  seen.add(x);floor&=x>=u;odd=x%2;U=3*U+2**i if odd else U;a+=odd;x=(3*x+1)//2 if odd else x//2
 return x,a,U,floor,len(seen)==j
queries=[(1,2)]+[(u,j) for u in [871,4064460795] for j in [8,12,16,20,24]]+[(23207,27),(68711,27)]
for u,j in queries:
 y,a,U,floor,distinct=trajectory(u,j);R=F(2**j,3**a);G=F(3**a*u+U,3**a*u)
 front={y:0};done=True
 for depth in range(j):
  if nodes+len(front)>budget:done=False;break
  nxt={}
  for z,b in front.items():
   nodes+=1;nxt[2*z]=b
   if z%3==2:
    m=(2*z-1)//3
    if m>0 and m%2:nxt[m]=b+1
  front=nxt
 if not done:
  rows.append(dict(u=u,j=j,status='budget_incomplete',completed_depth=depth));break
 assert front[u]==a
 H=max(front.values());same=min(m for m,b in front.items() if b==a);least=min(front);b=front[least]
 yy,bb,V,_,_=trajectory(least,j);assert yy==y and bb==b
 witness=None
 if least<u:
  z=least;steps=0;seen=set()
  while z!=1 and z not in seen and steps<2000:
   seen.add(z);z=(3*z+1)//2 if z%2 else z//2;steps+=1
  witness=dict(m=least,b=b,V=str(V),to_one=z==1,verification_steps=steps)
 rows.append(dict(u=u,j=j,y=y,a=a,R=str(R),G=str(G),floor=floor,distinct=distinct,narrow=1<R<A,nondescending=y>=u,max_count=H,same_count_min=same,joint_maximal=H==a and same==u,fibre_size=len(front),witness=witness))
 Path('tmp/joint_strip_fibre/checkpoint.json').write_text(json.dumps(dict(nodes=nodes,completed=rows),indent=2))
# Exact integer odd-count strip at the historical target depth.
allowed129=[a for a in range(130) if 3**a<2**129 and 32*2**129<47*3**a]
actual129={str(u):dict(zip(['y','a','U','floor','distinct'],trajectory(u,129))) for u in [871,4064460795]}
out=dict(status='PASS',node_budget=budget,nodes=nodes,queries=rows,allowed_narrow_counts_depth129=allowed129,actual129=actual129,seconds=time.time()-start)
Path('tmp/joint_strip_fibre/audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
