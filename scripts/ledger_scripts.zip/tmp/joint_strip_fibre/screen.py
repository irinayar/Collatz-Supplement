from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json,time
start=time.time();rows=[];prefixes=0
ps=json.loads(Path('tmp/numerator_code_audit/audit.json').read_text())['saved']
for p in ps:
 u=int(p['u']);x=u;j=a=U=0;seen=set()
 for e in p['word']:
  for _ in range(e):
   seen.add(x);odd=x%2;U=3*U+2**j if odd else U;a+=odd;j+=1;x=(3*x+1)//2 if odd else x//2;prefixes+=1
   R=F(2**j,3**a);G=F(3**a*u+U,3**a*u)
   if 1<R<F(47,32):rows.append(dict(u=u,j=j,a=a,y=x,R=str(R),G=str(G),non_descending=x>=u,high=u>=2**71))
out=dict(prefixes=prefixes,paths=len(ps),candidates=rows,seconds=time.time()-start)
Path('tmp/joint_strip_fibre/screen.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
