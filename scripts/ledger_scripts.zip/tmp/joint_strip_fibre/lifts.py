from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json
out=[]
for u,y in [(23207,22331),(68711,66113)]:
 j=27;a=17;x=u;bits=[];count=0;coeff=[]
 for i in range(j):
  odd=x%2;bits.append(odd);count+=odd;x=(3*x+1)//2 if odd else x//2
  if i+1<j:assert 3**count>=2**(i+1)
 assert x==y and count==a
 lifts=[]
 for t in [0,1,2**80]:
  n=u+2**j*3**(j-a)*t;z=n;seen=set()
  for i,b in enumerate(bits):
   assert z%2==b and z>=n and z not in seen;seen.add(z);z=(3*z+1)//2 if b else z//2
  assert z==y+3**j*t<n
  G=F(2**j*z,3**a*n);assert G<F(47,32)
  lifts.append(dict(t=str(t),n=str(n),end=str(z),G=str(G)))
 out.append(dict(u=u,y=y,j=j,a=a,word=''.join(map(str,bits)),source_step=2**j*3**10,endpoint_step=3**j,lifts=lifts))
# Record already-known descents as controls, not new inverse witnesses.
controls=[]
for n in [871,4064460795]:
 x=n;k=0
 while x>=n and k<256:x=(3*x+1)//2 if x%2 else x//2;k+=1
 m=x;z=m;q=0
 while z!=1 and q<2000:z=(3*z+1)//2 if z%2 else z//2;q+=1
 assert m<n and z==1;controls.append(dict(n=n,first_descent_step=k,m=m,steps_from_m_to_one=q))
Path('tmp/joint_strip_fibre/lifts.json').write_text(json.dumps(dict(status='PASS',families=out,known_descent_controls=controls),indent=2));print(json.dumps(dict(status='PASS',families=2,known_descent_controls=controls)),flush=True);os._exit(0)
