from pathlib import Path
exec(Path('tmp/adaptive_tail_review/check.py').read_text(encoding='utf-8-sig').split('counts={}')[0])
from fractions import Fraction as F
bounds4={4:F(11,16),5:F(7,8),7:F(43,32),8:F(11,8),10:F(7,4),11:F(83,54)}
checks=0
for x,h in bounds4.items():
 assert h>F(32*x,243)
 for k in range(13):
  a=exact(x,k,4);b=exact(x,k,5)
  if a:assert F(a[0],2**k)>=h
  if a and b:assert b[1]<a[0];checks+=1
Path('tmp/optimized_cap/layer4.json').write_text(json.dumps({'bounds':{str(x):str(v) for x,v in bounds4.items()},'nonempty_comparisons_through_k12':checks,'cache_states':exact.cache_info().currsize},indent=2));print('layer4 exact comparisons:',checks,flush=True);os._exit(0)
