from pathlib import Path
exec(Path('tmp/adaptive_tail_review/check.py').read_text(encoding='utf-8-sig').split('counts={}')[0])
D=Path('tmp/optimized_cap')
def cap(x,k,b,j,M):
 L=k+b;B=2**L*x;power=3**j;Q=3**(b-j);den=3**b;n=b-j;d=Q-2**n;ans=[]
 for tail in combinations(range(L),j):
  t=tail[0] if j else L
  if t<n:continue
  T=sum(3**(j-1-i)*2**p for i,p in enumerate(tail))
  if (B-T)%power:continue
  u=2**(t-n)*d;lo=max(d,-(-(B-T-den*M)//power));hi=min(u,(B-T-den)//power);res=(B-T)//power%Q
  first=lo+(res-lo)%Q;last=hi-(hi-res)%Q
  if first<=last:ans.append({'tail':tail,'first':first,'last':last,'count':(last-first)//Q+1,'origin_min':(B-T-power*last)//den,'origin_max':(B-T-power*first)//den})
 return ans

def words(x,k,b):
 vals=[];L=k+b
 for ps in combinations(range(L),b):
  V=sum(3**(b-i-1)*2**p for i,p in enumerate(ps));num=2**L*x-V
  if num<=0 or num%3**b:continue
  m=num//3**b;z=m;bits=[]
  for i in range(L):bits.append(z%2);z=(3*z+1)//2 if z%2 else z//2
  assert z==x and tuple(i for i,v in enumerate(bits) if v)==ps
  vals.append({'origin':m,'odd_positions':ps})
 return vals
out={}
for x,k,b in [(17,9,6),(4,4,4)]:
 old,new=words(x,k,b),words(x,k,b+1);M=min(z['origin'] for z in new);rows=[]
 for m in sorted(set([M,max(z['origin'] for z in new)])):
  for j in range(min(b,4)+1):
   a=cap(x,k,b,j,m);rows.append({'M':m,'j':j,'tails':len(a),'candidates':sum(z['count'] for z in a),'survivors':a if x==4 else []})
 out[str((x,k,b))]={'old':old,'successor':new,'rows':rows}
# General stronger layer via endpoint lower bounds: explore exact minima for four odd inputs.
out['four_odd_minima']={str(x):[(k,exact(x,k,4)) for k in range(13)] for x in [4,5,7,8,10,11]}
(D/'results.json').write_text(json.dumps(out,indent=2));print(json.dumps({'cases':{key:{'old_min':min(v['origin'] for v in val['old']),'new_min':min(v['origin'] for v in val['successor']),'rows':val['rows']} for key,val in out.items() if key!='four_odd_minima'},'four':out['four_odd_minima']},indent=2),flush=True);os._exit(0)
