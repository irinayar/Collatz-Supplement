from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from itertools import product
from functools import lru_cache
import json
D=Path('tmp/larger_bound_audit_21l');old=json.loads(Path('tmp/larger_bound_audit_21h/k126_target_queries.json').read_text());patterns={q['word']:q for q in old};rows=[];mins=[]
for w,q in patterns.items():
 L=len(w);M=2**(L+1);n0=q['n']-q['lift']*M;x0=q['x']-2*3**q['r']*q['lift'];K=q['k']+2;R=q['r']+3
 assert 5*n0>=27*2**K;mins.append(5*n0-27*2**K)
 U=2**K*(3**R-2**R)
 for t in range(27):
  n=n0+M*t;z=x0+2*3**q['r']*t;y=n
  for bit in w:assert y%2==int(bit);y=(3*y+1)//2 if bit=='1' else y//2
  assert y==z
  lower_num=2**(L+5)*z-U;assert lower_num>=3**R*n
  rows.append({'word':w,'lift':t,'n':n,'endpoint':z,'M':M,'K':K,'R':R,'lower_origin_numerator':lower_num,'denominator':3**R,'status':'no_smaller_by_height'})
# Independent exhaustive coefficient maximum check on short words.
count=0
for L in range(1,13):
 maxima={}
 for bits in product([0,1],repeat=L):
  b=0;d=1
  for bit in bits:b=3*b+d if bit else b;d*=2
  r=sum(bits);maxima[r]=max(maxima.get(r,0),b);count+=1
 for r,b in maxima.items():assert b==2**(L-r)*(3**r-2**r)
# Independently check new ChatGPT ZIP's nine representative target minima.
calls=0
@lru_cache(maxsize=50000)
def least(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return (2**r*(x+1)//3**r-1 if (x+1)%3**r==0 else None)
 y=x;opts=[]
 for ell in range(r+1):
  a=least(2*y,k-1,r-ell)
  if a is not None and a>0:opts.append(a)
  if y%3!=2:break
  y=(2*y-1)//3
 return min(opts) if opts else None
ziprows=[]
for t in range(9):
 n=61159+65536*t;y=n;states=[n]
 for bit in '111011101100111':assert y%2==int(bit);y=(3*y+1)//2 if bit=='1' else y//2;states.append(y)
 assert y==330641+354294*t and min(states)==n and states[9]>2*n+1
 m=least(y,5,13);expected=(8*n-{2:7,4:5,8:10}[n%9])//9 if n%9 in [2,4,8] else None;assert m==expected
 if m:
  p=m;steps=0
  while p!=1 and steps<10000:p=(3*p+1)//2 if p%2 else p//2;steps+=1
  assert p==1
 ziprows.append({'t':t,'n':n,'minimum':m})
(D/'height_exclusions.json').write_text(json.dumps(rows,indent=2));res={'patterns':len(patterns),'lift_rows':len(rows),'minimum_simple_margin':min(mins),'short_words_checked':count,'ZIP_nine_minima':ziprows,'ZIP_inverse_states':calls,'remaining_queries':0};(D/'checks.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)

