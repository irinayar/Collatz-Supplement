from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
start=time.time();out=Path('tmp/first_meeting_counts');N=4096;H=128
values=list(range(N+1));counts=[0]*(N+1);alive=[True]*(N+1);seen=[set() for _ in range(N+1)];met=[False]*(N+1);records=[];totals={'surplus':0,'same_only':0,'lower_only':0}
for j in range(1,H+1):
 fibres={}
 for n in range(1,N+1):
  x=values[n]
  if x<n or x in seen[n]:alive[n]=False
  if alive[n]:seen[n].add(x)
  counts[n]+=x%2;values[n]=(3*x+1)//2 if x%2 else x//2
  if values[n]<n or values[n] in seen[n]:alive[n]=False
  y=values[n];a=counts[n];f=fibres.setdefault(y,{})
  if f and not met[n]:
   met[n]=True
   if n>=3 and n%2 and alive[n]:
    assert (1<<j)*y<3**(a+1)*n
    higher=[b for b in f if b>a]
    kind='surplus' if higher else 'same_only' if a in f else 'lower_only'
    totals[kind]+=1
    records.append(dict(n=n,j=j,y=y,a=a,kind=kind,partners_min_by_count=dict(f),H_exact=max([a]+list(f)),P_num=(1<<j)*y,P_den=3**a*n))
  f.setdefault(a,n)
 (out/'checkpoint.json').write_text(json.dumps(dict(completed_depth=j,totals=totals)))
# Independent whole-prefix and every-smaller-origin replay of first same-only example.
same=next((r for r in records if r['kind']=='same_only'),None);certificate=None
if same:
 n=same['n'];j=same['j'];trajectories={};rows=[]
 for m in range(1,n+1):
  x=m;a=0;path=[x]
  for k in range(j):a+=x%2;x=(3*x+1)//2 if x%2 else x//2;path.append(x)
  rows.append(dict(m=m,y=x,a=a));trajectories[m]=path
 source=trajectories[n]
 assert len(set(source))==len(source) and min(source)==n
 for k in range(1,j):assert all(trajectories[m][k]!=source[k] for m in range(1,n))
 matches=[r for r in rows[:-1] if r['y']==source[-1]]
 assert matches and max(r['a'] for r in matches)==same['a']
 certificate=dict(source=same,path=source,matching_smaller=matches,all_smaller_outputs=rows[:-1])
 (out/'same_only_certificate.json').write_text(json.dumps(certificate,indent=2))
result=dict(N=N,depth=H,totals=totals,first_same_only=same,first_lower_only=next((r for r in records if r['kind']=='lower_only'),None),records=records,seconds=time.time()-start,scope='First synchronous meetings; odd sources before any descent or repeated state; exact H inferred using P<3 and exhaustive smaller origins')
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True);os._exit(0)
