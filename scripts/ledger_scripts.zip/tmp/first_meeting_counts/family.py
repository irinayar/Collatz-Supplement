from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
out=Path('tmp/first_meeting_counts')
def affine(mask,j):
 a=V=0
 for i in range(j):
  if mask>>i&1:V=3*V+(1<<i);a+=1
 return a,V
j6=[dict(mask=w,a=affine(w,6)[0],V=affine(w,6)[1]) for w in range(64)]
compatible=[r for r in j6 if r['a']>4 and (r['V']-65)%81==0]
assert [(r['a'],r['V']) for r in compatible]==[(5,227)]
assert affine(int('101110',2),6)==(4,146) # chronological word011101
controls=0
for t in range(100):
 n=15+64*t;x=n;z=n-1;xp=[x];zp=[z];ax=az=0
 for j in range(1,7):
  ax+=x%2;az+=z%2;x=(3*x+1)//2 if x%2 else x//2;z=(3*z+1)//2 if z%2 else z//2;xp.append(x);zp.append(z)
 assert x==z and ax==az==4 and min(xp)==n and len(set(xp))==7
 # Complete search of smaller starts at depth5, valid for these modest controls.
 target=xp[5]
 for m in range(1,n):
  q=m
  for _ in range(5):q=(3*q+1)//2 if q%2 else q//2
  assert q!=target
 controls+=1
res=dict(j6_higher_compatible=compatible,same_count_numerator=146,source_numerator=65,controls=controls,family='n=15 or79 mod192: first meeting at6 with n-1; H_6=4=A_6',all_n15mod64_first_meeting=6)
(out/'family_certificate.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
