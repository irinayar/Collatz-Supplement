from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
start=time.time();out=Path('tmp/predescent_product');N=2048;H=128
values=list(range(N+1));counts=[0]*(N+1);valid=[True]*(N+1);seen=[set() for _ in range(N+1)];checks=matches=outside=0;examples=[]
for j in range(1,H+1):
 fibres={}
 for n in range(1,N+1):
  x=values[n]
  if x<n or x in seen[n]:valid[n]=False
  if valid[n]:seen[n].add(x)
  counts[n]+=x%2;values[n]=(3*x+1)//2 if x%2 else x//2
  if values[n]<n or values[n] in seen[n]:valid[n]=False
  y=values[n];a=counts[n];f=fibres.setdefault(y,{})
  if a not in f:f[a]=[n,n]
  else:f[a][1]=n
 for n in range(3,N+1,2):
  if not valid[n]:continue
  y=values[n];a=counts[n];B=1<<j;Q=3**a
  assert a>0 and a<=364*(n-1)
  assert (B*y)**6*(n-1)<(Q*n)**6*(n+2*a-1)
  assert B*y<3*Q*n
  checks+=1
  candidates=[(b,lo,hi) for b,(lo,hi) in fibres[y].items() if b>a]
  for b,lo,hi in candidates:assert hi<n
  if candidates:
   matches+=1
   if 12*n<B:
    outside+=1
    if len(examples)<5:
     b,m,_=candidates[0];x=m;bits=[]
     for i in range(j):bits.append(x%2);x=(3*x+1)//2 if x%2 else x//2
     drop=b-a-1
     for i in range(j):
      if drop and bits[i]:bits[i]=0;drop-=1
     V=0;c=0
     for i,bit in enumerate(bits):
      if bit:V=3*V+(1<<i);c+=1
     mt=(B*y-V)//3**c;assert c==a+1 and 0<mt<n
     x=mt
     for bit in bits:assert x%2==bit;x=(3*x+1)//2 if bit else x//2
     assert x==y
     examples.append(dict(j=j,n=n,endpoint=y,source_odd=a,partner=m,partner_odd=b,primitive_partner=mt,outside_old_cutoff=True))
 (out/'checkpoint.json').write_text(json.dumps(dict(completed_depth=j,checks=checks,matches=matches,outside=outside)))
res=dict(N=N,horizon=H,predescent_distinct_prefix_checks=checks,higher_count_meeting_cases=matches,outside_old_cutoff=outside,examples=examples,seconds=time.time()-start,limits='1GiB process memory,55 CPU and wall seconds')
(out/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
