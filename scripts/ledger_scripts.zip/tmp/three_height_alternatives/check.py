from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/three_height_alternatives');D.mkdir(exist_ok=True)
prior=json.loads(Path('tmp/four_even_height/results.json').read_text());remaining=json.loads(Path('tmp/four_even_height/remaining_frontier.json').read_text());N=4064460795
results=[];visits=0
for row in prior['frontier_records']:
 branches=[]
 # Independently regenerate the complete suffix list by compositions of even gaps.
 e=row['t']-row['b'];suffixes=[]
 for g1 in range(e+1):
  for g2 in range(e-g1+1):
   for g3 in range(e-g1-g2+1):
    for g4 in range(e-g1-g2-g3+1):
     w='10'*0+'1'+'0'*g1+'1'+'0'*g2+'1'+'0'*g3+'1'+'0'*g4
     V=0
     for i,c in enumerate(w):
      if c=='1':V=3*V+2**i
     num=2**len(w)*row['z']-V
     if num%81==0:suffixes.append(w)
 assert sorted(suffixes)==sorted(v['suffix']['word'] for v in row['branches'])
 for v in row['branches']:
  x=v['endpoint'];k=v['suffix']['k'];r=row['prefix_odds'];hm=H(x,r,k);bound=R(x,k)
  # Independent inverse-edge traversal retaining only extrema and counts.
  stack=[(x,k,0)];minima={};counts={};local=0
  while stack:
   z,left,odds=stack.pop();visits+=1;local+=1
   assert visits<=100000
   if left==0:minima[odds]=min(z,minima.get(odds,z));counts[odds]=counts.get(odds,0)+1
   if left:stack.append((2*z,left-1,odds))
   if z%3==2:stack.append(((2*z-1)//3,left,odds+1))
  assert max(minima)==bound and set(minima)==set(range(bound+1))
  assert hm==minima.get(r)
  branches.append(dict(**v,computed_minimum=hm,computed_maximum=bound,independent_nodes=local,independent_minima=minima,independent_counts=counts,excluded=hm is None or hm>=N))
 results.append(dict(index=row['index'],level=row['level'],t=row['t'],z=row['z'],b=row['b'],prefix_odds=row['prefix_odds'],branches=branches,excluded=all(v['excluded'] for v in branches)))
excluded={v['index'] for v in results if v['excluded']};new_remaining=[q for q in remaining if q['index'] not in excluded]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();seed=Path('tmp/fair_terminal129_batch05/checkpoint.json')
assert sha(seed)==prior['checkpoint_sha256']
for p,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert sha(Path(p))==h
out=dict(results=results,new_excluded=sorted(excluded),total_excluded=51+len(excluded),remaining=len(new_remaining),independent_nodes=visits,seconds=time.monotonic()-start,v9_unchanged=True,checkpoint_sha256=sha(seed))
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');(D/'remaining_frontier.json').write_text(json.dumps(new_remaining,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='results'}))
for q in results:
 for v in q['branches']:
  if v['status']=='unresolved_budget':print(dict(index=q['index'],endpoint=v['endpoint'],budget=v['suffix']['k'],required=q['prefix_odds'],maximum=v['computed_maximum'],minimum=v['computed_minimum']))
print('complete',flush=True);os._exit(0)
