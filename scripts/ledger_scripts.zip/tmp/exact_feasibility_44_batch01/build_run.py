from pathlib import Path
p=Path('tmp/feasible_five_height/check.py').read_text(encoding='utf-8-sig')
p=p.replace("D=Path('tmp/feasible_five_height')","D=Path('tmp/exact_feasibility_44_batch01')")
p=p.replace("proof={};leaves={};results=[];calls=0;found=None;attempts=[];local_start=0;local_leaves=0","""for n in json.loads(Path('tmp/feasible_five_height/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
proof={};leaves={};results=[];calls=0;found=None;attempts=[];local_start=0;local_leaves=0""")
p=p.replace("if len(leaves)>=500 or len(leaves)-local_leaves>=10 or time.monotonic()-start>30:raise Cap()","if time.monotonic()-start>30:raise Cap()")
p=p.replace("top=R(x,k);low=H(x,top,k);at=H(x,r,k)\n  leaves[key]=dict(x=x,r=r,k=k,R=top,global_min=low,requested_min=at,all_counts_too_high=low>=N)","top=R(x,k);at=H(x,r,k) if r<=top else None\n  leaves[key]=dict(x=x,r=r,k=k,R=top,requested_min=at)")
p=p.replace("  if z['all_counts_too_high']:proof[key]=dict(rule='five_height');return True\n  if z['requested_min']>=N:proof[key]=dict(rule='five_exact');return True","  assert z['requested_min']<N # K093: every feasible full-word origin is smaller")
p=p.replace("  if m>=N:proof[key]=dict(rule='all_even_height');return True","  assert m<N # positive feasible prefix plus saved suffix")
p=p.replace(";assert max(actual)==z['R'] and min(actual.values())==z['global_min']\n assert actual[z['R']]==z['global_min']",";assert max(actual)==z['R']")
p=p.replace("assert (z['global_min']>=N if rule=='five_height' else z['requested_min'] is None if rule=='five_empty' else z['requested_min']>=N)","assert rule=='five_empty' and z['requested_min'] is None and z['r']>z['R']")
p=p.replace("fresh_all_counts_too_high=sum(z['all_counts_too_high'] for z in leaves.values()),","")
p=p.replace(" (D/'progress.json').write_text(json.dumps(dict(results=results,attempts=attempts,calls=calls)),encoding='utf8')"," (D/'progress.json').write_text(json.dumps(dict(results=results,attempts=attempts,calls=calls)),encoding='utf8')")
# Save progress for capped roots as well.
p=p.replace("leaves=len(leaves)-local_leaves));continue","leaves=len(leaves)-local_leaves))\n  (D/'progress.json').write_text(json.dumps(dict(results=results,attempts=attempts,calls=calls)),encoding='utf8');continue")
Path('tmp/exact_feasibility_44_batch01').mkdir(exist_ok=True)
Path('tmp/exact_feasibility_44_batch01/check.py').write_text(p,encoding='utf8');exec(compile(p,'exact_feasibility','exec'))
