from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
start=time.time();out=Path('tmp/primitive_small_origin');j=42;n=251;B=1<<j;lift=n+3*B
def run(m):
 x=m;a=0;mask=0
 for i in range(j):
  bit=x%2;a+=bit;mask|=bit<<i;x=(3*x+1)//2 if bit else x//2
 return x,a,mask
assert run(n)[:2]==(2,22);assert run(2)[:2]==(2,21)
rows=[dict(origin=m,endpoint=run(m)[0],odd=run(m)[1]) for m in range(1,n)]
fibre=[r for r in rows if r['endpoint']==2]
assert max(r['odd'] for r in fibre)==21
bound=(2*B)//3**23;assert bound==93 and bound<n
assert not any(run(m)[:2]==(2,23) for m in range(1,bound+1))
y,a,mask=run(lift);assert a==22 and y==2+3**23 and mask==run(n)[2]
res=dict(j=j,n=n,source_endpoint=2,source_odd=22,smaller_partner=2,partner_odd=21,all_smaller_origins=rows,matching_smaller_origins=fibre,extra_odd_origin_bound=bound,lift=lift,lift_endpoint=y,lift_odd=a,primitive_at_original=False,primitive_at_lift=False,nonminimal_original=True,minimal_lift_by_arbitrary_depth_theorem=True,proof='Equal-count lifted partner pulls back by3B to a positive smaller original partner; extra-count pulls back byB to a positive endpoint2 origin <=93. Neither exists. Large-origin primitive theorem excludes every other smaller partner.',seconds=time.time()-start,inverse_attempt='Stopped safely at250000 frontier cap; incomplete and not used in proof; replaced by affine bound93')
(out/'period_counterexample.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ('all_smaller_origins','matching_smaller_origins')}),flush=True);os._exit(0)
