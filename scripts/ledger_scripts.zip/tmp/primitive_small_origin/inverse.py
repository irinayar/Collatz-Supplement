from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
out=Path('tmp/primitive_small_origin');start=time.time();front=[(2,0)];sizes=[];cap=250000
for depth in range(1,43):
 nxt=[]
 for y,a in front:
  nxt.append((2*y,a))
  if y%3==2:nxt.append(((2*y-1)//3,a+1))
  assert len(nxt)<=cap,'configured state cap reached'
 front=nxt;sizes.append(len(front))
mins={}
for x,a in front:mins[a]=min(x,mins.get(a,x))
assert mins[22]==251
j=42;n=251;B=1<<j;lift=n+3*B
# For a fixed endpoint, minimize origin in each odd-count stratum.
# The maximum numerator of that stratum gives its minimum origin after lifting.
cert=[];possible=[]
for b,x in sorted(mins.items()):
 V=B*2-3**b*x
 num=3**22*lift+(B*2-3**22*n)-V
 if num%3**b==0:
  m=num//3**b
  cert.append(dict(odd=b,least_original=x,least_lifted=m,smaller=0<m<lift))
  if 0<m<lift:possible.append(m)
# Primitive strata suffice above B by the proved theorem. Their absence decides lift even if other words were not positive at endpoint2.
# Every integral affine word ending at positive2 already has a positive origin, so inverse enumeration includes every relevant word.
assert not any(z['smaller'] for z in cert if z['odd'] in (22,23))
x=lift;a=0
for i in range(j):a+=x%2;x=(3*x+1)//2 if x%2 else x//2
assert a==22 and x==2+3**23
res=dict(depth=j,endpoint=2,frontier_sizes=sizes,complete=True,min_origin_by_odd_count=mins,source=n,lift=lift,lift_endpoint=x,lift_count=a,lifted_minima=cert,any_smaller_lift=bool(possible),seconds=time.time()-start)
(out/'inverse_certificate.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
