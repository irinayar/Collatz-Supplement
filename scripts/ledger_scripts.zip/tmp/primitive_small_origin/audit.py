from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
start=time.time();out=Path('tmp/primitive_small_origin');N=4096;values=list(range(N+1));counts=[0]*(N+1);first=None;failures=[]
for j in range(1,101):
 fibres={}
 for n in range(1,N+1):
  odd=values[n]%2;counts[n]+=odd;values[n]=(3*values[n]+1)//2 if odd else values[n]//2
  y=values[n];a=counts[n];f=fibres.setdefault(y,{})
  if f and a not in f and a+1 not in f:
   row=dict(j=j,n=n,source_odd=a,endpoint=y,smaller_count_minima=sorted(f.items()))
   if first is None:first=row
   if n<=32 and len(failures)<15:failures.append(row)
  f.setdefault(a,n)
 if first:break
# Independently replay every smaller origin for the first counterexample.
n=first['n'];j=first['j'];all_rows=[]
for m in range(1,n+1):
 x=m;a=0;path=[x]
 for i in range(j):
  a+=x%2;x=(3*x+1)//2 if x%2 else x//2;path.append(x)
 if x==first['endpoint']:all_rows.append(dict(m=m,odd=a,path=path))
assert len(all_rows)>1 and all(z['odd'] not in (first['source_odd'],first['source_odd']+1) for z in all_rows if z['m']<n)
res=dict(first_counterexample=first,complete_smaller_fibre=all_rows,failures=failures,search=dict(N=N,completed_depth=j),seconds=time.time()-start)
(out/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k!='complete_smaller_fibre'}),flush=True);os._exit(0)
