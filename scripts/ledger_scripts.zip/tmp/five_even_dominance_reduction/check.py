from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_dominance_reduction');D.mkdir(exist_ok=True)
counts=dict(branch_cells=0,dominance=0,takeovers=0,transferred_series=0,word_replays=0)
def mn(*v):
 v=[z for z in v if z is not None];return min(v) if v else None
def replay(m,w,y):
 for b in w:
  assert m%2==int(b);m=(3*m+1)//2 if b=='1' else m//2
 assert m==y
compatible=[]
for pos in itertools.combinations(range(7),3):
 w=''.join('1' if i in pos else '0' for i in range(7));V=sum(2**i*3**(2-j) for j,i in enumerate(pos))
 if V%27==20:compatible.append((w,V))
assert sorted(compatible)==[('0101010',74),('1100010',47)]
for q in range(1,1501):
 if q%3==0:continue
 A=64*q-7;z=6*q-1
 for s in range(2,max(R(9*q-1,5),R(z,5)+1)+2):
  S=H(18*q-2,s,4);M=H(12*q-2,s-1,4);B=H(8*q-2,s-2,4)
  assert mn(M,B)==H(z,s-1,5)
  assert mn(S,M,B)==H(9*q-1,s,5);counts['branch_cells']+=1
  if S is not None:
   assert A%3**(s-2)==0 and S==2**(s-1)*(A//3**(s-2))-1
   if mn(M,B) is not None:assert S>mn(M,B);counts['dominance']+=1
   if s in (3,4):
    assert M==S-(13-2*s)
    replay(M,'001010' if s==3 else '0101010',12*q-2);counts['word_replays']+=1
   if s>=3:assert B is None
   if s>=5:assert M is None
  elif q%3==2:assert H(9*q-1,s,5)==H(z,s-1,5) # s=2 short always finite
 if q%27==25:
  assert R(12*q-2,4)==3
  assert H(12*q-2,3,4)==8*A//9-6
  assert H(9*q-1,4,5)-H(9*q-1,5,5)==8*A//27-5>0
  for w,V in compatible:replay((128*(12*q-2)-V)//27,w,12*q-2);counts['word_replays']+=1
  counts['takeovers']+=1
 if q%3==1:
  vals=[H(9*q-1,r,5) for r in range(R(9*q-1,5)+1)]
  assert all(a>b for a,b in zip(vals,vals[1:]));counts['transferred_series']+=1
# General a reduction and its initial bridge, across both unit classes.
for a in range(2,7):
 for u in range(1,101):
  if u%3==0:continue
  q=2**(a-2)*u;x=3**a*u-1
  assert H(x,a-1,5)-H(x,a,5)==32*2**(a-1)*u
  for r in range(a,R(x,5)+2):assert H(x,r,5)==H(9*q-1,r-a+2,5)
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out=dict(**counts,compatible_words=compatible,seconds=time.monotonic()-start,v10_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
