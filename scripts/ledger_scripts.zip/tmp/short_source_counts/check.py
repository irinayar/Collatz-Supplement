from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys
from fractions import Fraction as F
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
D=Path('tmp/short_source_counts');seeds=json.loads((I/'exact_compensation_seeds.json').read_text());rows=[];bands={};seen=set();synthetic=0
ceil=lambda a,b:-((-a)//b)
def ap_count(L,U,r,M):
 first=r+ceil(L-r,M)*M
 return max(0,(U-first)//M+1),first
# Independent small-grid tests of interval/residue counting, including negative caps and strict endpoints.
for M in [4,8,16,32]:
 for r in range(1,M,2):
  for L in range(1,20,3):
   for U in range(-2,40,5):
    count,first=ap_count(L,U,r,M);assert count==sum(x%M==r for x in range(L,U+1));synthetic+=1
n0=2**71+1
assert F(15*n0,3*n0-35)<5+F(3,400000)
for group in seeds['groups']:
 n=int(group['n'])
 if n<2**71:continue
 H=(4*n-2)//3;P=source_count(n);B=5+F(n,100000*P);band=bands.setdefault(str(n),{str(k):{'phase_words':0,'canonical_survivors':0,'actual_survivors':0} for k in [2,3]})
 for item in group['sources']:
  key=(n,tuple(item['word']));assert key not in seen;seen.add(key)
  p=replay(n,item);u=p['u'];word=item['word'];N=len(word);E=Dnum=0;states=[];L=n;U=H
  for g,e in enumerate(word,1):
   Dnum=3*Dnum+2**E;E+=e;states.append((g,E,Dnum))
   if g<N:L=max(L,(2**E*H-Dnum)//3**g+1)
  L=max(L,ceil(2**E*n-Dnum,3**N));U=min(U,(2**E*H-Dnum)//3**N);M=2**(E+1);res=(2**E-Dnum)*pow(3**N,-1,M)%M
  total,first=ap_count(L,U,res,M);assert total>=1 and first==u
  Q=F(Dnum,3**N);phase=[];start=0
  for end,e in enumerate(word,1):
   if e<2:continue
   if end-start==2 and e==2 and start>0:
    g,Eg,Dg=states[start-1];q=F(Dg,3**g)
    if B<q<Q-B:phase.append((g,(2**E-Dg-1)//3**g))
   start=end
  core=actual_core(p,P);actual=sum((r['s'],r['e'])==(2,2) for j,r in enumerate(p['runs']) if j in core)
  out=dict(n=str(n),u=str(u),N=N,E=E,phase_count=len(phase),actual_count=actual,counts={})
  for k in [2,3]:
   if len(phase)<k:c=0;cap=None
   else:
    cap=phase[k-1][1];c,first=ap_count(L,min(U,cap),res,M);assert c in [0,1]
    if c:assert first==res==u and 2*3**(16+2*(k-1))*(u+B)<M
   assert int(actual>=k)<=c
   if actual>=k:
    assert N>=30+2*k and E>=n.bit_length()+((3**(14+2*k)).bit_length()-1)
   band[str(k)]['phase_words']+=len(phase)>=k;band[str(k)]['canonical_survivors']+=c;band[str(k)]['actual_survivors']+=actual>=k
   out['counts'][str(k)]=dict(canonical_survivors=c,actual_survivors=int(actual>=k),cap_above_source=cap is not None and cap>=u)
  rows.append(out)
summary={str(k):{field:sum(b[str(k)][field] for b in bands.values()) for field in ['phase_words','canonical_survivors','actual_survivors']} for k in [2,3]}
result=dict(status='PASS',source_words=len(rows),bands=bands,catalogue_totals=summary,small_grid_count_tests=synthetic,horizons={'2':{'odd_transitions':34,'shortcut_steps':'m+28'},'3':{'odd_transitions':36,'shortcut_steps':'m+31'}},rows=rows,scope='Counts apply only to saved distinct completed-word catalogues, separately at each threshold. Global unenumerated word tail remains open.')
(D/'checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True);os._exit(0)
