from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
from collections import Counter
D=Path('tmp/five_even_height_application');D.mkdir(exist_ok=True);N=4064460795;endpoint=7821397930
seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');seedsha=hashlib.sha256(seed.read_bytes()).hexdigest()
f=json.loads(Path('tmp/claude_reconcile_batch02/remaining_frontier.json').read_text())
old={}
for n in json.loads(Path('tmp/claude_reconcile_batch02/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
proof={};leaves={};results=[];calls=0;found=None
class Cap(Exception):pass
def leaf(x,r,k):
 key=(x,r,k)
 if key not in leaves:
  if len(leaves)>=500 or time.monotonic()-start>30:raise Cap()
  top=R(x,k);low=H(x,top,k);at=H(x,r,k)
  leaves[key]=dict(x=x,r=r,k=k,R=top,global_min=low,requested_min=at,all_counts_too_high=low>=N)
 return leaves[key]
def reject(x,r,k):
 global calls,found
 key=(x,r,k)
 if key in old or key in proof:return True
 calls+=1
 if calls>50000 or time.monotonic()-start>30:raise Cap()
 if k<=5:
  z=leaf(x,r,k)
  if z['all_counts_too_high']:proof[key]=dict(rule='five_height');return True
  if z['requested_min'] is None:proof[key]=dict(rule='five_empty');return True
  if z['requested_min']>=N:proof[key]=dict(rule='five_exact');return True
  found=z['requested_min'];return False
 if r==0:
  m=x*2**k
  if m>=N:proof[key]=dict(rule='all_even_height');return True
  found=m;return False
 if x%3==0:proof[key]=dict(rule='multiple3');return True
 if 2*3**r>2**r*(2**k*x+1):proof[key]=dict(rule='height_empty');return True
 a=a3(x+1);children=[]
 for l in range(min(a,r)+1):
  child=(2*(2**l*((x+1)//3**l)-1),r-l,k-1)
  if not reject(*child):return False
  children.append(child)
 proof[key]=dict(rule='union',children=children);return True
# Bounded profile of already saved five-even subproblems; not new exclusions.
samples=[]
for key in old:
 if key[2]==5:
  x,r,k=key;top=R(x,k);low=H(x,top,k)
  samples.append(dict(x=x,r=r,k=k,R=top,global_min=low,requested_empty=r>top,all_counts_too_high=low>=N))
  if len(samples)==64:break
for q in sorted(f,key=lambda q:(q['t']-q['b'],q['index'])):
 try:excluded=reject(q['z'],q['b'],q['t']-q['b'])
 except Cap:break
 results.append(dict(**q,excluded=excluded))
 (D/'progress.json').write_text(json.dumps(dict(results=results,calls=calls)),encoding='utf8')
 if not excluded:break
# Independent inverse-edge enumeration verifies every new small-budget leaf and sample.
for z in list(leaves.values())+samples:
 tr=tree(z['x'],z['k']);actual={r:min(v) for r,v in tr.items()};assert max(actual)==z['R'] and min(actual.values())==z['global_min']
 assert actual[z['R']]==z['global_min']
 if 'requested_min' in z:assert actual.get(z['r'])==z['requested_min']
for (x,r,k),n in proof.items():
 rule=n['rule']
 if rule=='union':
  expected=[(2*(2**l*((x+1)//3**l)-1),r-l,k-1) for l in range(min(a3(x+1),r)+1)]
  assert n['children']==expected and all(z in old or z in proof for z in expected)
 elif rule.startswith('five_'):
  z=leaves[(x,r,k)]
  assert (z['global_min']>=N if rule=='five_height' else z['requested_min'] is None if rule=='five_empty' else z['requested_min']>=N)
 elif rule=='all_even_height':assert r==0 and x*2**k>=N
 elif rule=='multiple3':assert x%3==0 and r>0
 elif rule=='height_empty':assert 2*3**r>2**r*(2**k*x+1)
 else:raise AssertionError(rule)
if found is not None:
 q=results[-1];z=found;ones=0
 for i in range(q['t']):ones+=z%2;z=(3*z+1)//2 if z%2 else z//2
 assert z==q['z'] and ones==q['b'] and 0<found<N
 for i in range(129-q['t']):z=(3*z+1)//2 if z%2 else z//2
 assert z==endpoint
 z=found;steps=0
 while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
 assert z==1
excluded={q['index'] for q in results if q['excluded']};remaining=[q for q in f if q['index'] not in excluded]
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out=dict(source=N,endpoint=endpoint,root_budget_histogram=dict(Counter(q['t']-q['b'] for q in f)),old_sample_count=len(samples),old_sample_all_counts_too_high=sum(z['all_counts_too_high'] for z in samples),fresh_leaf_count=len(leaves),fresh_all_counts_too_high=sum(z['all_counts_too_high'] for z in leaves.values()),fresh_requested_empty=sum(z['requested_min'] is None for z in leaves.values()),calls=calls,new_proof_nodes=len(proof),new_excluded=len(excluded),total_target_excluded=109+len(excluded),remaining=len(remaining),found=found,rule_counts=dict(Counter(n['rule'] for n in proof.values())),seconds=time.monotonic()-start,seed_sha256=seedsha,v10_unchanged=True)
for name,data in [('results',out),('root_results',results),('remaining_frontier',remaining),('sample',samples),('leaves',list(leaves.values())),('proof',[dict(x=x,r=r,k=k,**n) for (x,r,k),n in proof.items()])]:
 (D/(name+'.json')).write_text(json.dumps(data,indent=2),encoding='utf8')
print(out,flush=True);os._exit(0)
