from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_height_application');leaves=json.loads((D/'leaves.json').read_text());tests=0
def first_count(x,k,N):
 top=R(x,k)
 if H(x,top,k)>=N:return None
 lo=0;hi=top
 while lo<hi:
  mid=(lo+hi)//2
  if H(x,mid,k)<N:hi=mid
  else:lo=mid+1
 return lo
for z in leaves[:64]:
 x=z['x'];k=z['k'];tr=tree(x,k);actual={r:min(v) for r,v in tr.items()}
 for N in {z['global_min'],z['global_min']+1,2**k*x,2**k*x+1,4064460795}:
  expected=[r for r in sorted(actual) if actual[r]<N];got=first_count(x,k,N)
  assert got==(expected[0] if expected else None)
  assert expected==([] if got is None else list(range(got,R(x,k)+1)));tests+=1
# All height leaves also have empty requested counts; thus the new certificate proves emptiness, not merely a threshold exclusion.
assert all(z['requested_min'] is None and z['r']>z['R'] for z in leaves)
root=json.loads((D/'root_results.json').read_text())[0]
seed=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text())
full=[dict(level=int(k),t=t,z=z,b=b) for k,v in seed['levels'].items() for t,z,b in v['stack']]
assert all(root[k]==v for k,v in full[root['index']].items())
out=dict(threshold_boundary_tests=tests,all_new_leaves_requested_empty=True,root_identity_checked=True,global_min_range=[min(z['global_min'] for z in leaves),max(z['global_min'] for z in leaves)],leaf_even_budgets=sorted(set(z['k'] for z in leaves)),seconds=time.monotonic()-start)
(D/'threshold_results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
