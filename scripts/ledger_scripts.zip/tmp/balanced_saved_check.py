from pathlib import Path
s=Path('tmp/run_refund_audit/signed_check.py').read_text(encoding='utf-8-sig');exec(s[:s.index('records=[];')])
data=json.loads(Path('tmp/balanced_pair_audit/audit.json').read_text());families=data['families'];words=[f['word'] for f in families];K=F(data['Kmax']);minimum=int(data['minima'][8][0]);pairwords=[[1,2,1,2,2,1,2,1,2,1,2,2],[1,2,1,2,1,2,2,1,2,1,2,2]]
assert K>=F(1669158,7153)
for g in json.loads(Path('tmp/compensation_packet_audit/input/exact_compensation_seeds.json').read_text())['groups']:
 for p in g['sources']:items.append(dict(p,n=g['n']))
unique={}
for p in items:
 key=(int(p['n']),int(p['u']))
 if key in unique:assert unique[key]['word']==p['word']
 unique[key]=p

def replay(a,word,n):
 x=a;Y=F();J=F();i=0;anchor=a;floor=a;kap=1-F(4,3*n+1)
 for j,e in enumerate(word,1):
  z=3*x+1;assert (z&-z).bit_length()-1==e;x=z>>e;floor=min(floor,x)
  if e>=2:
   psi=max(F(),kap*(1-F(2,3)**(j-i))/anchor+F(1,anchor)-F(1,x));Y+=psi;J+=anchor*psi;i=j;anchor=x
 return x,Y,J,floor
records=[];newgroups=0
for p in unique.values():
 n=int(p['n']);H=(4*n-2)//3;x=int(p['u']);xs=[x]
 for e in p['word']:
  z=3*x+1;assert (z&-z).bit_length()-1==e;x=z>>e;xs.append(x)
 for i in range(len(p['word'])):
  if i and p['word'][i-1]==1:continue
  codes=[];j=i
  while p['word'][j:j+24] in words:codes.append(words.index(p['word'][j:j+24]));j+=24
  tail=p['word'][j:j+12] in pairwords
  if tail:j+=12
  if not codes and not tail:continue
  a=xs[i];b,Y,J,floor=replay(a,p['word'][i:j],n);assert floor>=n and Y<=K*(F(1,a)-F(1,b)) and J<=F(20*len(codes)+10*tail,3)
  if len(codes)>=8:assert a>=minimum
  if a>H and n<2**272:assert Y<=F(56,H+1)
  new=any(families[c]['code'] in [[2,2,3,3],[3,3,2,2]] for c in codes);newgroups+=new
  records.append(dict(n=str(n),u=str(p['u']),offset=i,blocks=codes,terminal_pair=tail,new_unpaired_block=new,whole_core_claim=False))
local=[]
patterns=[([f]*N,tail) for f in range(6) for N in [1,8] for tail in [None,0]]+ [([(j*j+3*j+k)%6 for j in range(N)],1) for N in [8,9,17] for k in [0,1]]
for index,(codes,tail) in enumerate(patterns):
 n=[2**71+1,2**272-1,2**272+1][index%3];H=(4*n-2)//3;word=sum([words[c] for c in codes],[])+(pairwords[tail] if tail is not None else [])
 num=E=0;lam=F(1);minlam=F(1)
 for e in word:num=3*num+2**E;E+=e;lam*=F(3,2**e);minlam=min(minlam,lam)
 mod=2**(E+1);r=((2**E-num)*pow(3**len(word),-1,mod))%mod;need=F(H+1)/minlam;lo=-(-need.numerator//need.denominator);a=r+max(0,-((r-lo)//mod))*mod
 b,Y,J,floor=replay(a,word,n);assert floor>H and Y<=K*(F(1,a)-F(1,b))<K/a
 assert J<=F(20*len(codes)+10*(tail is not None),3)
 if len(codes)>=8:assert a>=minimum
 if n<2**272:assert Y<=F(56,H+1)
 local.append(dict(n=str(n),blocks=codes,terminal_pair=tail,source=str(a),local_only=True))
result=dict(status='PASS',unique_saved_profiles=len(unique),saved_groups=len(records),new_unpaired_saved_groups=newgroups,local_controls=len(local),records=records,controls=local,seconds=time.time()-start)
Path('tmp/balanced_pair_audit/saved_tests.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['records','controls']}),flush=True);os._exit(0)
