from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from functools import lru_cache
D=Path('tmp/fair_terminal129_batch05');start=time.monotonic();n=4064460795;J=129;H=4;tables=[[{0:0}]]
for j in range(1,J+1):
 new=[{} for _ in range(j+1)]
 for b,layer in enumerate(tables[-1]):
  for V in layer.values():
   for bb,Z in [(b,V),(b+1,3*V+2**(j-1))]:
    r=Z%3**min(H,bb);new[bb][r]=max(new[bb].get(r,-1),Z)
 tables.append(new)
work=0
@lru_cache(maxsize=100000)
def R(t,b,h,r):
 global work
 work+=1
 if work>500000:raise RuntimeError('precision work cap')
 if b<0 or b>t:return -1
 h=min(h,b);r%=3**h
 if h<=4:return tables[t][b].get(r,-1) if h==min(4,b) else max((V for rr,V in tables[t][b].items() if rr%3**h==r),default=-1)
 best=R(t-1,b,h,r) if b<t else -1
 p=2**(t-1)
 if b and (r-p)%3==0:
  V=R(t-1,b-1,h-1,((r-p)//3)%3**(h-1))
  if V>=0:best=max(best,3*V+p)
 return best
seed=json.loads((D/'seed_checkpoint.json').read_text());c=json.loads((D/'checkpoint.json').read_text());r=json.loads((D/'results.json').read_text());checks=0;new_states=0;integer_gap_only=0;deltas={}
assert c['nodes']==350000==sum(z['nodes'] for z in c['levels'].values())==sum(z['nodes'] for z in c['turns'])
assert c['nodes']-seed['nodes']==100000 and c['turns'][:len(seed['turns'])]==seed['turns']
assert hashlib.sha256((D/'seed_checkpoint.json').read_bytes()).hexdigest()==c['seed_hash']
for lev,z in c['levels'].items():
 old=seed['levels'][lev];deltas[lev]=z['nodes']-old['nodes']
 if int(lev)<=81:assert z==old;continue
 seen={tuple(v) for v in z['seen']};before={tuple(v) for v in old['seen']};pending={tuple(v) for v in z['stack']};assert before<=seen and all(tuple(v) in seen or tuple(v) in pending for v in old['stack']);assert bool(pending)==(z['status']=='pending')
 for t,x,b in seen-before:
  new_states+=1
  if b<0 or b>t:continue
  assert t>0 or not(b==0 and 0<x<n)
  if t==0:continue
  children=[(t-1,2*x,b)]+([(t-1,(2*x-1)//3,b-1)] if b and x%3==2 else [])
  if all(v in seen or v in pending for v in children):continue
  T=2**t*x-3**b*n;top=2**(t-b)*(3**b-2**b)
  safe=(2**t*x-top)%3**b!=0 and (b==t or b>=1 and top-3**(b-1)*2**(t-b-1)<=T)
  M=tables[t][b].get(2**t*x%3**min(4,b))
  old_safe=safe or M is None or M<=T
  safe=(2**t*x-top)%3**b!=0 and (b==t or b>=1 and top-3**(b-1)*2**(t-b-1)<T+3**b)
  assert safe or M is None or M<T+3**b,(lev,t,x,b)
  integer_gap_only+=not old_safe;checks+=1
assert sum(deltas.values())==100000
for name,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
(D/'verification.json').write_text(json.dumps(dict(verified=True,integer_gap_only=integer_gap_only,new_prune_leaves=checks,new_unique_states=new_states,level_new_nodes={k:v for k,v in deltas.items() if v},previous_exhausted_levels_unchanged=True,v9_unchanged=True),indent=2));print('Verified continuation;',checks,'new prunes;',new_states,'new states;', {k:v for k,v in deltas.items() if v},flush=True);os._exit(0)
