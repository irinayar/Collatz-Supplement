from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,heapq
start=time.monotonic();D=Path('tmp/residue_feasibility_44');D.mkdir(exist_ok=True);INF=10**9;tables=[[0]];checks=0
for p in range(1,11):
 mod=3**p;prev=tables[-1];cost=[INF]*mod;cycle=[];a=1
 while not cycle or a!=1:cycle.append(a);a=2*a%mod
 assert len(cycle)==2*3**(p-1)
 best=INF
 for i in range(2*len(cycle)-1,-1,-1):
  a=cycle[i%len(cycle)];base=prev[((2*a-1)//3)%(mod//3)] if a%3==2 else INF
  best=min(base,best+1,INF)
  if i<len(cycle):cost[a]=best
 for a in range(mod):
  base=prev[((2*a-1)//3)%(mod//3)] if a%3==2 else INF
  assert cost[a]==min(base,1+cost[2*a%mod],INF);checks+=1
 if p<=5:
  independent=[INF]*mod;heap=[]
  for a in range(2,mod,3):
   z=prev[((2*a-1)//3)%(mod//3)]
   if z<INF:independent[a]=z;heapq.heappush(heap,(z,a))
  inv2=pow(2,-1,mod)
  while heap:
   d,a=heapq.heappop(heap)
   if d!=independent[a]:continue
   b=a*inv2%mod
   if d+1<independent[b]:independent[b]=d+1;heapq.heappush(heap,(d+1,b))
  assert independent==cost
 tables.append(cost)
(D/'tables.json').write_text(json.dumps(tables),encoding='utf8')
f=json.loads(Path('tmp/five_even_height_application/remaining_frontier.json').read_text());claimed=json.loads(Path('tmp/collatz_two_arc/frontier_emptiness_claude_results.json').read_text());roots=[q for q in f if claimed[q['index']]['status']=='unresolved'];cuts=[]
for q in roots:
 p=min(10,q['b']);need=tables[p][q['z']%3**p]
 if need>q['t']-q['b']:cuts.append(q['index'])
out=dict(precision=10,bellman_cells=checks,independent_graph_precisions=5,finite_cost_max=[max(z for z in t if z<INF) for t in tables],immediate_root_cuts=cuts,seconds=time.monotonic()-start)
(D/'table_results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
