from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools
D=Path('tmp/residue_feasibility_44');stack=[(2,20,0)];mins={};nodes=0
while stack:
 x,k,r=stack.pop();nodes+=1
 if k==0:mins[r]=min(x,mins.get(r,x))
 if k:stack.append((2*x,k-1,r))
 if x%3==2:stack.append(((2*x-1)//3,k,r+1))
assert mins[21]==1 and mins[22]==251 and max(mins)==24
res={sum(2**i*3**(2-j) for j,i in enumerate(pos))%27 for pos in itertools.combinations(range(8),3)}
assert 1 not in res and len(res)==17
z=355
for b in '1100000':assert z%2==int(b);z=(3*z+1)//2 if b=='1' else z//2
assert z==25
out=dict(counterexample={str(r):mins[r] for r in range(17,25)},nodes=nodes,max_odd=24,mod27_residues=sorted(res),word_355_to_25_verified=True,k19_global_claim='source-reported; not independently replayed')
(D/'late_note_checks.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
