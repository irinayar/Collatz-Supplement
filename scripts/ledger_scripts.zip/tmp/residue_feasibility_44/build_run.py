from pathlib import Path
p=Path('tmp/exact_feasibility_44_batch01/check.py').read_text(encoding='utf-8-sig')
p=p.replace("D=Path('tmp/exact_feasibility_44_batch01')","D=Path('tmp/residue_feasibility_44')")
p=p.replace("proof={};leaves={};results=[];calls=0;found=None;attempts=[];local_start=0;local_leaves=0","""for n in json.loads(Path('tmp/exact_feasibility_44_batch01/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
tables=json.loads((D/'tables.json').read_text());moduli=[3**p for p in range(len(tables))]
proof={};leaves={};results=[];calls=0;found=None;attempts=[];local_start=0;local_leaves=0""")
p=p.replace(" if k<=5:\n  z=leaf(x,r,k)",""" if r>0 and x%3!=0:
  prec=min(r,10);need=tables[prec][x%moduli[prec]]
  if need>k:proof[key]=dict(rule='residue_even_cost',precision=prec,minimum_even_cost=need);return True
 if k<=5:
  z=leaf(x,r,k)""")
p=p.replace(" elif rule.startswith('five_'):",""" elif rule=='residue_even_cost':
  prec=n['precision'];assert 1<=prec<=min(r,10) and tables[prec][x%moduli[prec]]==n['minimum_even_cost']>k
 elif rule.startswith('five_'):""")
p=p.replace("out=dict(source=N,", """residue_keys=[key for key,n in proof.items() if n['rule']=='residue_even_cost']
independent_residue=0
for x,r,k in residue_keys:
 if k<=8 and independent_residue<64:
  tr=tree(x,k);assert max(tr)<min(r,10);independent_residue+=1
out=dict(residue_cuts_by_budget=dict(Counter(k for x,r,k in residue_keys)),independent_residue_checks=independent_residue,source=N,""")
Path('tmp/residue_feasibility_44/check.py').write_text(p,encoding='utf8');exec(compile(p,'residue_search','exec'))
