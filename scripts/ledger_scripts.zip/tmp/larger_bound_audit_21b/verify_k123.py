from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
from fractions import Fraction as F
import json
D=Path('tmp/larger_bound_audit_21b');calls=0
@lru_cache(maxsize=50000)
def feasible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return (x+1)%3**r==0 and (2**r*(x+1)//3**r-1)>0
 y=x
 for ell in range(r+1):
  if feasible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
queries=json.loads((D/'k123_queries.json').read_text())
for v in queries:
 assert v['status']=='empty_layer_exact' and '00' not in v['source_word']
 assert not feasible(v['x'],v['k'],v['r']+1)
# Reset-order note: exact finite realizations and affine products, no numerical logs.
rows=[]
for t in range(1,13):
 es=[2]*t+[1]*t;U=0;P=1
 for e in es:U=3*U+P;P*=2**e
 residue=(-U*pow(3**(2*t),-1,P))%P
 a=next(v for v in [residue,residue+P] if v>0 and ((3**(2*t)*v+U)//P)%2)
 b=a;G=F(1)
 for e in es:
  z=3*b+1;assert (z&-z)==2**e;G*=F(z,3*b);b=z//(2**e)
 DD=F(8,9)**t;A=DD*b-a;assert A>=F(4,3)**t-1 and G==1+A/a
 rows.append({'t':t,'a':a,'b':b,'Cmin':str(A/(1-DD))})
(D/'independent_k123.json').write_text(json.dumps({'queries':len(queries),'recurrence_states':calls,'all_empty_confirmed':True,'reset_order_controls':rows},indent=2));print('confirmed',len(queries),'empty queries in',calls,'states;12 reset controls',flush=True);os._exit(0)

