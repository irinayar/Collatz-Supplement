from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,hashlib,time
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21b');source=Path('tmp/height_filter_survivors/survivor_representatives.json');allrows=json.loads(source.read_text());selected=[]
for j in [3,4,5]:selected.extend([dict(row,saved_index=i) for i,row in enumerate(allrows) if row['j']==j][16:32])
selected.extend([{'n':n,'j':3,'saved_index':None} for n in [4064460795,18839651253368551]])
previous={(q['n'],q['depth']) for q in json.loads(Path('tmp/larger_bound_audit_21/k123_queries.json').read_text())}
skipped=0
calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return (x,'')
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:return a[0],a[1]+'1'
 if k:
  a=inv(2*x,k-1,r)
  if a:return a[0],a[1]+'0'
 return None
queries=[];stopped=False
for row in selected:
 n=row['n'];x=n;k=r=0;word=''
 for depth in range(1,33):
  bit=x%2;word+=str(bit);r+=bit;k+=1-bit;x=(3*x+1)//2 if bit else x//2
  if x<n or '00' in word:break
  if depth<row['j']+8:continue
  if (n,depth) in previous:skipped+=1;continue
  assert '00' not in word
  result={'saved_index':row['saved_index'],'j':row['j'],'n':n,'depth':depth,'x':x,'k':k,'r':r,'source_word':word}
  try:w=inv(x,k,r+1)
  except Budget:result['status']='budget_pending';queries.append(result);stopped=True;break
  if w:
   m,target=w;z=m;assert 0<m<n and len(target)==depth+1
   for c in target:
    assert z%2==int(c);z=(3*z+1)//2 if c=='1' else z//2
   assert z==x
   z=m;cert=[m]
   while z!=1 and len(cert)<10000:z=(3*z+1)//2 if z%2 else z//2;cert.append(z)
   assert z==1
   result.update(status='witness',m=m,target_word=target,convergence_path=cert)
  else:result['status']='empty_layer_exact'
  queries.append(result)
 if stopped:break
out={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'selection':'saved rows16..31 in each j=3,4,5 plus two historical difficult starts; depths j+8..32, stop at descent or00; prior queries skipped','selected_count':len(selected),'queries':len(queries),'witnesses':sum(v['status']=='witness' for v in queries),'empty':sum(v['status']=='empty_layer_exact' for v in queries),'budget_pending':stopped,'nodes':calls,'prior_queries_skipped':skipped,'distinct_witness_sources':len({v['n'] for v in queries if v['status']=='witness'})}
(D/'k123_queries.json').write_text(json.dumps(queries,indent=2));(D/'k123_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);print('example',json.dumps(next(({k:v for k,v in z.items() if k!='convergence_path'} for z in queries if z['status']=='witness'),None)),flush=True);os._exit(0)
