from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/five_even_complete');D.mkdir(exist_ok=True);counts={};overlaps=takeovers=0
for w in range(2,6001,3):
 C=8*w-1;c=a3(C);v=C//3**c;P=lambda s:H(6*w-1,s,3);Q=lambda s:H(3*w-1,s,4)
 rp=R(6*w-1,3);rq=R(3*w-1,4)
 assert P(1)-Q(1)==8 and P(2)-Q(2)==2
 if c>=2:
  case='c>=2';assert rq==2 and rp>=3
  assert Q(2)-P(3)==8*C//9-2>0
 elif v%3==1:
  f=a3(4*v-1)
  assert P(3)-Q(3)==1
  if f>=2:
   case='v1_f>=2';assert rq==3 and rp>=4
   assert Q(3)-P(4)==(16*v-13)//9>0
  elif v%9==1:
   case='v1_f1_v1mod9';assert v>1 and rq==3 and rp>=4
   assert Q(3)-P(4)==(16*v-16)//9>0
  else:
   case='v1_f1_v4mod9';assert v%9==4 and rp==3 and rq>=4
 else:
  assert v%3==2;f=a3(8*v-1);assert rp==2+f and P(3)-Q(3)==3
  if f==1:case='v2_f1';assert rq>=3
  else:
   assert v%9==8 and P(4)-Q(4)==2
   if f==2:case='v2_f2';assert rq>=4
   else:
    case='v2_f>=3';assert v%27==17 and rq==4 and rp>=5
    assert Q(4)-P(5)==(32*v-58)//27>=18
 counts[case]=counts.get(case,0)+1
 for s in range(1,min(rp,rq)+1):assert Q(s)<P(s);overlaps+=1
 if rq<rp:assert Q(rq)>P(rq+1);takeovers+=1
 vals=[min(z for z in (P(s),Q(s)) if z is not None) for s in range(1,max(rp,rq)+1)]
 assert all(a>b for a,b in zip(vals,vals[1:]))
# Independent inverse-edge enumeration checks the complete five-even theorem.
series=0
for x in range(1,1001):
 tr=tree(x,5);vals=[min(tr[r]) for r in range(max(tr)+1)]
 assert set(tr)==set(range(R(x,5)+1)) and vals==[H(x,r,5) for r in range(len(vals))]
 assert all(a>b for a,b in zip(vals,vals[1:]));series+=1
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out=dict(cases=counts,overlaps=overlaps,takeovers=takeovers,independent_full_series=series,seconds=time.monotonic()-start,v10_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
