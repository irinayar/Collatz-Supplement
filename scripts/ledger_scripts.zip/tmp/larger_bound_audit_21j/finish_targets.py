from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21j');calls=[0,0]
@lru_cache(maxsize=50000)
def direct(x,k,r):
 calls[0]+=1;assert calls[0]<=50000
 if k==r==0:return(x,'')
 opts=[]
 if r and x%3==2:
  a=direct((2*x-1)//3,k,r-1)
  if a:opts.append((a[0],a[1]+'1'))
 if k:
  a=direct(2*x,k-1,r)
  if a:opts.append((a[0],a[1]+'0'))
 return min(opts) if opts else None
@lru_cache(maxsize=50000)
def other(x,k,r):
 calls[1]+=1;assert calls[1]<=50000
 if k==0:return 2**r*(x+1)//3**r-1 if (x+1)%3**r==0 else None
 y=x;opts=[]
 for ell in range(r+1):
  a=other(2*y,k-1,r-ell)
  if a is not None and a>0:opts.append(a)
  if y%3!=2:break
  y=(2*y-1)//3
 return min(opts) if opts else None
qs=json.loads(Path('tmp/larger_bound_audit_21i/remaining_queries.json').read_text());out=[]
for q in qs:
 a=direct(q['x'],q['k']+q['dk'],q['r']+q['dr']);b=other(q['x'],q['k']+q['dk'],q['r']+q['dr']);assert b==(a[0] if a else None)
 if a:
  m,w=a;z=m
  for bit in w:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
  assert z==q['x'];q.update(m=m,target_word=w,status='witness' if m<q['n'] else 'minimum_not_smaller')
  if m<q['n']:
   z=m;steps=0
   while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
   assert z==1;q['convergence_steps']=steps
 else:q['status']='empty_layer_exact'
 out.append(q);(D/'completed_pending_queries.json').write_text(json.dumps(out,indent=2))
res={'completed':len(out),'nodes_direct':calls[0],'nodes_independent':calls[1],'remaining':0,'answers':[{k:q[k] for k in ['n','status','m'] if k in q} for q in out]};(D/'target_results.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
