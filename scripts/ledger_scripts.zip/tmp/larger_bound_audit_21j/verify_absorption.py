from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
from itertools import product
import json
D=Path('tmp/larger_bound_audit_21j');C=F(517,31);maxima=[]
for e,first in [(2,1),(3,3),(4,5)]:
 previous=None
 for s in range(1,41):
  a=3**(s+1);d=2**(s+e);b=3**s*(1+2**e)-d
  assert (a>d)==(s>=first)
  if a>d:
   c=F(b,a-d);assert c<=C
   if previous is not None:assert c<previous
   previous=c
   if s==first:maxima.append(str(c))
assert 1+(19+8*C)/405==F(128,93)<F(3,2)
checks=0;cases=0
for seq in product([(2,1),(2,2),(3,3),(3,4),(4,5),(4,6)],repeat=2):
 w=[1,1,1]+sum(([e]+[1]*s for e,s in seq),[]);a=1;b=0;d=1
 for e in w:a,b,d=3*a,3*b+d,d*2**e
 x=((d-b)*pow(a,-1,2*d))%(2*d);assert x>=15;y=x;G=F(1);cap=1+(19+8*C)/(27*x)
 for e in w:
  z=3*y+1;assert (z&-z).bit_length()-1==e;G*=F(z,3*y);y=z>>e;assert G<cap<=F(128,93);checks+=1
 assert G*(1+C/y)<=cap;cases+=1
res={'potential':str(C),'maxima':maxima,'block_parameter_pairs':120,'cylinders':cases,'exact_prefix_checks':checks,'cap_at15':'128/93'};(D/'absorption_checks.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
