from pathlib import Path
from fractions import Fraction
from functools import lru_cache
from math import gcd
import json
D=Path(__file__).parent;O=D.parents[1]
inv=json.loads((O/'tmp/m83_100000/counting_inventory_augmented.json').read_text())
ledger=[(z['residue'],z['modulus']) for z in inv['finite_ledger']]
C103=[(91,2592),(1063,2592),(1147,1152),(103,576)]
fs=json.loads((D/'cancelled_families.json').read_text())['families']
old=[(f['n0']%f['P'],f['P']) for f in fs if f['original_L']<=12]
new=[(f['n0']%f['P'],f['P']) for f in fs]
def normalize(xs):
 out=[]
 for r,m in sorted(set(xs),key=lambda z:z[1]):
  if not any(m%n==0 and r%n==a for a,n in out):out.append((r,m))
 return out
old=normalize(old);new=normalize(new)
base=normalize(ledger+C103+old)
def crt(z,w):
 a,m=z;b,n=w;g=gcd(m,n)
 if (b-a)%g:return None
 k=n//g;t=((b-a)//g*pow(m//g,-1,k))%k if k>1 else 0
 return ((a+m*t)%(m*k),m*k)
def subtract(z,w):
 if crt(z,w) is None:return [z]
 a,m=z;b,n=w
 if m%n==0:return []
 p=2 if (n//gcd(n,m))%2==0 else 3
 return sum((subtract((a+t*m,p*m),w) for t in range(p)),[])
# New union is made disjoint before any coverage accounting.
new_disjoint=[]
for z in new:
 left=[z]
 for w in new_disjoint:left=sum((subtract(x,w) for x in left),[])
 new_disjoint+=left
# Disjoint subtraction supplies an independently structured overlap calculation.
remaining=[]
for z in new_disjoint:
 left=[z]
 for w in base:left=sum((subtract(x,w) for x in left),[])
 remaining+=left
terms={}
for z in base:
 delta={z:1}
 for w,c in terms.items():
  hit=crt(z,w)
  if hit:delta[hit]=delta.get(hit,0)-c
 for w,c in delta.items():terms[w]=terms.get(w,0)+c
 terms={w:c for w,c in terms.items() if c}
certs=json.loads((O/inv['C85']['file']).read_text())['certificates'];c85=[(z['n'],2**27) for z in certs if z['meeting'] is not None and z['descent'] is None]
T=32
@lru_cache(None)
def tail(l,a):
 if l==T:return 1
 return sum(tail(l+1,a+b) for b in [0,1] if 3**(a+b)>=2**(l+1))
@lru_cache(None)
def survive(z):
 r,m=z;L=(m&-m).bit_length()-1;x=r;a=0
 for i in range(1,min(L,T)+1):
  bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
  if 3**a<2**i:return Fraction()
 return Fraction(1,m) if L>=T else Fraction(tail(L,a),m*2**(T-L))
def residual(z):
 return survive(z)-sum((c*survive(hit) for w,c in terms.items() if (hit:=crt(z,w))),Fraction())
def c08(k):
 m=2**(k+2);return (-(3**k-2**k)*pow(3**k,-1,m))%m,m
J=100 # >= all counted binary precisions and stopping depths

def gain(nodes,f):
 raw=sum((f(z) for z in nodes),Fraction());inf=Fraction();parent=Fraction()
 for z in nodes:
  for k in range(1,J):
   hit=crt(z,c08(k))
   if hit:inf+=f(hit)
  hit=crt(z,(2**J-1,2**J))
  if hit:inf+=f(hit)/2
  for w in c85:
   hit=crt(z,w)
   if hit:parent+=f(hit)
 return dict(after_finite=str(raw),C08_overlap=str(inf),C85_overlap=str(parent),net=str(raw-inf-parent))
results={}
for depth in [32,100]:
 T=depth;tail.cache_clear();survive.cache_clear()
 a=gain(new_disjoint,residual);b=gain(remaining,survive);assert a==b,(a,b)
 assert Fraction(a['net'])>=0
 results[str(T)]=a;print(T,a,flush=True)
out=dict(base_finite_count=len(base),inclusion_exclusion_terms=len(terms),new_disjoint_count=len(new_disjoint),after_finite_disjoint_count=len(remaining),remaining_cylinders=remaining,new_disjoint=new_disjoint,base=base,gains=results,scope='Increment E16 beyond named C91/C92 ledger + C103 + E12 source families + C08+C85+coefficient-descent depth T; finite height exceptions omitted only for density. Two exact overlap algorithms agree.')
(D/'cancelled_overlap.json').write_text(json.dumps(out,indent=2))
