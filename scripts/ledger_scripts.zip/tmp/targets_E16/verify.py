from pathlib import Path
from fractions import Fraction
import json,random
D=Path(__file__).parent
fs=json.loads((D/'cancelled_families.json').read_text())['families'];unique={ (f['n0'],f['P']):f for f in fs};out=[];checks=0
for f in unique.values():
 n,P,m,Q=f['n0'],f['P'],f['m0'],f['Q']
 def coeff(w):
  A=0;B=0
  for i,b in enumerate(w):
   if b=='1':A+=1;B=3*B+2**i
  return A,B
 a,U=coeff(f['source']);b,V=coeff(f['target']);L=len(f['source']);ell=len(f['target'])
 assert 2**ell*(3**a*n+U)==2**L*(3**b*m+V)
 assert 2**ell*3**a*P==2**L*3**b*Q and 0<Q<P and 0<m<n
 assert P%2**L==0 and Q%2**ell==0
 for t in range(1000):
  x=n+P*t;y=m+Q*t
  for bit in f['source']:
   assert x%2==int(bit);x=(3*x+1)//2 if x%2 else x//2
  for bit in f['target']:
   assert y%2==int(bit);y=(3*y+1)//2 if y%2 else y//2
  assert x==y;checks+=1
 x=m;path=[x]
 while x!=1:
  x=(3*x+1)//2 if x%2 else x//2;path.append(x);assert len(path)<10000
 out.append(dict(family=f,base_target_trajectory=path))
# A reverse-tree implementation independent of affine coefficients verifies raw catalogue membership.
rng=random.Random(20261119);reversechecks=0
for j in [3,4,5]:
 a=json.loads((D/f'j{j}.json').read_text());rules=a['levels']['16'];K=a['K']
 for k in [rng.randrange(K,10**7) for _ in range(2000)]:
  n=2**j*k-1;nodes={3**j*k-1};hit=False
  for _ in range(16):
   nxt=set()
   for y in nodes:
    nxt.add(2*y)
    if y%3==2:nxt.add((2*y-1)//3)
   nodes=nxt;hit|=any(0<m<n for m in nodes)
  predicted=any(k%z['mod']==z['r'] for z in rules)
  assert hit==predicted,(j,k,hit,predicted);reversechecks+=1
(D/'family_certificates.json').write_text(json.dumps(out,indent=2));(D/'verification.json').write_text(json.dumps(dict(unique_families=len(unique),affine_parameter_checks=checks,independent_reverse_tree_cases=reversechecks,base_targets_certified_to_one=len(out)),indent=2));print(checks,reversechecks)
