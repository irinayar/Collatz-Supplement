from pathlib import Path
import json,math
from fractions import Fraction
D=Path(__file__).parent;O=D.parents[1];rules={j:[] for j in [3,4,5]};K={j:1 for j in rules};thresholds={};counts=0

def walk(w='',b=0,U=0):
 global counts
 L=len(w);counts+=1
 for j in rules:
  a=2**L*3**j-2**j*3**b;c=3**b-2**L-U
  if a:K[j]=max(K[j],(-c)//a+1)
  K[j]=max(K[j],(2**L+U)//(2**L*3**j)+1)
  if not(a<0 or a==0 and c<0):continue
  g=3**min(j,b);rhs=2**L+U
  if rhs%g:continue
  mod=3**b//g;coef=2**L*3**j//g
  r=rhs//g*pow(coef,-1,mod)%mod if mod>1 else 0
  rules[j].append(dict(r=r,mod=mod,word=w,L=L,b=b,U=U))
 if L<16:
  walk(w+'0',b,U);walk(w+'1',b+1,3*U+2**L)
walk()
def normalize(rs):
 out=[]
 for z in sorted(rs,key=lambda x:(x['mod'],x['L'],x['word'])):
  if not any(z['r']%q['mod']==q['r'] for q in out):out.append(z)
 return out
summ=[]
for j in rules:
 levels={E:normalize([r for r in rules[j] if r['L']<=E]+[dict(r=0,mod=3,word='I0',L=0,b=0,U=0)]) for E in [12,14,16]}
 old=levels[12]
 def diff(z):
  if any(z['mod']>=q['mod'] and z['r']%q['mod']==q['r'] for q in old):return []
  overlaps=[q for q in old if q['mod']>z['mod'] and q['r']%z['mod']==z['r']]
  if not overlaps:return [z]
  out=[]
  for a in range(3):out+=diff(dict(z,r=z['r']+a*z['mod'],mod=3*z['mod']))
  return out
 new=sum((diff(z) for z in levels[16]),[])
 saved=json.loads((O/f'tmp/residue_rigidity/automaton_j{j}_E12.json').read_text());bs=saved['binary_survivors']
 checks=0
 for z in new:
  k=z['r']+max(0,(K[j]-z['r']+z['mod']-1)//z['mod'])*z['mod']
  for t in [0,1,2,99]:
   kk=k+t*z['mod'];n=2**j*kk-1;y=3**j*kk-1;num=2**z['L']*y-z['U'];assert num%3**z['b']==0;m=num//3**z['b'];assert 0<m<n;x=m
   for bit in z['word']:
    assert x%2==int(bit);x=(3*x+1)//2 if x%2 else x//2
   assert x==y;checks+=1
 density=sum((Fraction(1,z['mod']) for z in new),Fraction())*Fraction(len(bs),256)
 out=dict(j=j,E=16,K=K[j],all_words=counts,levels={str(E):v for E,v in levels.items()},new_ternary_cylinders=new,binary_survivors=bs,local_new_parameter_density=str(density),checks=checks)
 (D/f'j{j}.json').write_text(json.dumps(out,indent=2));summ.append(dict(j=j,K=K[j],normalized_counts={E:len(v) for E,v in levels.items()},new_cylinders=len(new),local_new_parameter_density=str(density),checks=checks));print(summ[-1],flush=True)
(D/'summary.json').write_text(json.dumps(summ,indent=2))
