from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
import json
@lru_cache(maxsize=100000)
def inv(x,k,r):
 if k==r==0:return (x,'')
 options=[]
 if k:
  a=inv(2*x,k-1,r)
  if a:options.append((a[0],a[1]+'0'))
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:options.append((a[0],a[1]+'1'))
 return min(options) if options else None
checks=hits=0;examples=[]
for n in range(3,200,2):
 x=n;k=r=0;source=''
 for j in range(1,13):
  bit=x%2;source+=str(bit);r+=bit;k+=1-bit;x=(3*x+1)//2 if bit else x//2
  if x<3:break
  checks+=1;w=inv(x,k,r+1)
  if not w:continue
  m,word=w;assert 0<m<n and len(word)==j+1;z=m
  for c0 in word:
   assert z%2==int(c0);z=(3*z+1)//2 if c0=='1' else z//2
  assert z==x
  # certify witness independently to1 in this small experiment
  y=m;steps=0
  while y!=1 and steps<1000:y=(3*y+1)//2 if y%2 else y//2;steps+=1
  assert y==1;hits+=1
  if len(examples)<6:examples.append({'n':n,'endpoint':x,'k':k,'r':r,'source_word':source,'m':m,'target_word':word,'certification_steps':steps})
result={'prefixes':checks,'feasible_extra_odd_layers':hits,'examples':examples,'cache':inv.cache_info().currsize}
Path('tmp/larger_bound_audit_20d/combination_test.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);os._exit(0)
