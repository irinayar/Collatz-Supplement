from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,time,hashlib
from functools import lru_cache
D=Path('tmp/four_even_height');D.mkdir(exist_ok=True);start=time.monotonic()
def a3(n):
 a=0
 while n%3==0:a+=1;n//=3
 return a
@lru_cache(maxsize=50000)
def R(x,k):
 a=a3(x+1)
 if k==0:return a
 return max(l+R(2*(2**l*((x+1)//3**l)-1),k-1) for l in range(a+1))
def origins(x,r,k):
 a=a3(x+1)
 if r<0 or r>R(x,k):return []
 if k==0:return [(2**r*((x+1)//3**r)-1,'1'*r)]
 return [(m,w+'0'+'1'*l) for l in range(min(a,r)+1) for m,w in origins(2*(2**l*((x+1)//3**l)-1),r-l,k-1)]
# Independent inverse-edge tree, with no odd-count cutoff.
def tree(x,k):
 out={};stack=[(x,k,0)]
 while stack:
  z,left,r=stack.pop()
  if left==0:out.setdefault(r,[]).append(z)
  if left:stack.append((2*z,left-1,r))
  if z%3==2:stack.append(((2*z-1)//3,left,r+1))
 return out
@lru_cache(maxsize=50000)
def H(x,r,k):
 if r<0 or r>R(x,k):return None
 if k==0:return 2**r*((x+1)//3**r)-1
 vals=[H(2*(2**l*((x+1)//3**l)-1),r-l,k-1) for l in range(min(a3(x+1),r)+1)]
 vals=[m for m in vals if m is not None]
 return min(vals) if vals else None
def LB(x,r,k):
 Q=3**r;num=2**(r+k)*(x+1)-2**k*Q
 return max(1,-((-num)//Q))
cells=height_cases=0
for x in range(1,201):
 k=4;got=tree(x,k);assert set(got)==set(range(R(x,k)+1))
 for r in range(R(x,k)+2):
  actual=origins(x,r,k);assert sorted(m for m,w in actual)==sorted(got.get(r,[]))
  minimum=min(got[r]) if r in got else None
  assert H(x,r,k)==minimum
  if minimum is not None:
   assert LB(x,r,k)<=minimum
   assert 2*3**r<=2**r*(2**k*x+1)
   assert max(got[r])<=(2**(r+k)*x-3**r+2**r)//3**r
  for N in [2,10,100,4064460795]:
   assert (minimum is not None and minimum<N)==any(m<N for m in got.get(r,[]));height_cases+=1
 cells+=1
catalog={};families=[]
for e in range(9):
 by={}
 for d in range(e+1):
  for rest in itertools.combinations(range(1,4+d),3):
   pos=(0,)+rest;w=''.join('1' if i in pos else '0' for i in range(4+d));V=sum(2**p*3**(3-j) for j,p in enumerate(pos));rr=V*pow(2,-len(w),81)%81
   by.setdefault(rr,[]).append(dict(word=w,V=V,d=d,k=e-d))
 catalog[e]=by
 for rr,ss in by.items():
  if max(v['k'] for v in ss)==4:families.append(dict(e=e,residue=rr,suffixes=ss))
seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');c=json.loads(seed.read_text(encoding='utf8'));frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']]
old={v['index'] for v in json.loads(Path('tmp/integer_height_envelope/lattice_results.json').read_text())['bounds'] if v['excluded']}
for p in ['multisuffix_family','two_even_family','finite_even_recursion']:old|={v['index'] for v in json.loads(Path('tmp/'+p+'/results.json').read_text())['additional_exclusions']}
old|={v['index'] for v in json.loads(Path('tmp/integer_height_envelope/results.json').read_text())['results'][-1]['cuts']}
assert len(old)==51
records=[];cert=[]
for index,q in enumerate(frontier):
 if index in old:continue
 e=q['t']-q['b'];r=q['b']-4
 if e not in catalog or r<0:continue
 ss=catalog[e].get(q['z']%81,[])
 if not ss:continue
 branches=[];hits=[]
 for v in ss:
  num=2**len(v['word'])*q['z']-v['V'];assert num%81==0;x=num//81;assert x>0
  if v['k']>4:
   branches.append(dict(suffix=v,endpoint=x,status='unresolved_budget'));continue
  bound=R(x,v['k']);ind=tree(x,v['k']);assert max(ind)==bound and set(ind)==set(range(bound+1))
  hm=H(x,r,v['k']);assert hm==(min(ind[r]) if r in ind else None)
  branches.append(dict(suffix=v,endpoint=x,status='excluded' if hm is None or hm>=4064460795 else 'height_feasible',max_prefix_odds=bound,min_origin=hm,origin_lower_bound=LB(x,r,v['k']),independent_origin_counts={str(r):len(ms) for r,ms in ind.items()}))
  hits.extend(dict(m=m,word=w+v['word']) for m,w in origins(x,r,v['k']) if m<4064460795)
 row=dict(index=index,**q,prefix_odds=r,branches=branches,candidates=hits,excluded=not hits and all(v['status']=='excluded' for v in branches));records.append(row)
 if row['excluded']:
  assert all(v['min_origin'] is None or v['min_origin']>=4064460795 for v in branches)
  cert.append(row)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(seed)==json.loads(Path('tmp/integer_height_envelope/results.json').read_text())['seed_sha256']
for p,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert sha(Path(p))==h
partial_counts={status:sum(v['status']==status for q in records for v in q['branches']) for status in ['excluded','height_feasible','unresolved_budget']}
result=dict(partial_counts=partial_counts,states_with_partial_exclusions=sum(any(v['status']=='excluded' for v in q['branches']) for q in records),height_threshold_checks=height_cases,universal_height_cuts=[i for i,q in enumerate(frontier) if i not in old and LB(q['z'],q['b'],q['t']-q['b'])>=4064460795],independent_cells=cells,old_exclusions=len(old),remaining_before=315,families=families,frontier_records=records,additional_exclusions=cert,total_excluded=51+len(cert),remaining_after=315-len(cert),v9_unchanged=True,checkpoint_unchanged=True,checkpoint_sha256=sha(seed),seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');(D/'remaining_frontier.json').write_text(json.dumps([dict(index=i,**q) for i,q in enumerate(frontier) if i not in old|{v['index'] for v in cert}],indent=2),encoding='utf8')
print(json.dumps({k:result[k] for k in ['independent_cells','total_excluded','remaining_after','seconds','height_threshold_checks','universal_height_cuts','partial_counts','states_with_partial_exclusions']}));print('families',len(families),'matches',len(records),'new',[(q['index'],q['prefix_odds'],max(v['max_prefix_odds'] for v in q['branches'])) for q in cert],flush=True);os._exit(0)


