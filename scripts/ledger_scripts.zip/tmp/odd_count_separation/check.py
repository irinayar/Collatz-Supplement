from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from fractions import Fraction as F
import json,time,hashlib
D=Path('tmp/odd_count_separation');t0=time.monotonic()
def step(u):
 z=(3*u+1)//2;e=0
 while z%2==0:z//=2;e+=1
 return z,e
S={1};paths={}
for seed in range(3,1024,2):
 u=seed;path=[];seen=set()
 while u!=1:
  assert u not in seen and len(path)<1000
  seen.add(u);path.append(u);u,e=step(u)
 S.update(path);paths[seed]=path
H={1:F(1)}
for seed in S:
 u=seed;stack=[]
 while u not in H:
  stack.append(u);u,e=step(u);assert u in S
 for v in reversed(stack):H[v]=F(3*v+1,3*v)*H[step(v)[0]]
Q=max(H.values());argmax=[u for u in S if H[u]==Q];f=F(3076,3075);B=Q;R=0
while B*f<F(3,2):B*=f;R+=1
assert B<F(3,2)<=B*f
P=F(1)
for u in range(5,36,2):P*=F(3*u+1,3*u)
B21=P*F(112,111)**5
assert B21==F(1104357077636685680869376,737660800217054109614805)<F(3,2)
# Independent accelerated replay of each closed-state potential.
for m in S-{1}:
 u=m;L=r=0;g=F(1)
 while u!=1:
  if u%2:r+=1;g*=F(3*u+1,3*u);u=(3*u+1)//2
  else:u//=2
  L+=1;assert L<10000
 assert g==H[m]==F(2**L,3**r*m)
# Forward trajectory prefixes, all exact, ending >=3; checks include 5/6-odd prefixes.
checks=0;counts={}
for m in range(1,2049):
 u=m;g=F(1);r=k=0
 for L in range(400):
  if u<3:break
  if u%2:g*=F(3*u+1,3*u);r+=1;u=(3*u+1)//2
  else:k+=1;u//=2
  if u<3:break
  assert g==F(2**(k+r)*u,3**r*m)
  if r<=R:assert g<F(3,2);assert F(2**k*2**(r+1)*u,3**(r+1))<m;checks+=1
  counts[r]=counts.get(r,0)+1
out={'closed_odd_states':len(S),'maximum_state':max(S),'Q':str(Q),'argmax':argmax,'R':R,'bound_at_R':str(B),'next_bound':str(B*f),'ChatGPT21_bound':str(B21),'prefix_checks':checks,'prefixes_with_five_odds':counts.get(5,0),'prefixes_with_six_odds':counts.get(6,0),'seconds':time.monotonic()-t0}
(D/'results.json').write_text(json.dumps(out,indent=2));(D/'closure.json').write_text(json.dumps({'paths':paths,'H':{u:str(h) for u,h in H.items()}},indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['bound_at_R','next_bound']},indent=2),flush=True);os._exit(0)
