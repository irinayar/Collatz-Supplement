from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time
from fractions import Fraction as F
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
start=time.monotonic();old=json.loads(Path('tmp/short_source_counts/checks.json').read_text());wanted={(int(r['n']),int(r['u'])) for r in old['rows'] if r['counts']['2']['canonical_survivors']};resolution={(int(r['n']),int(r['u'])):r['resolution_depth'] for r in json.loads(Path('tmp/shared_prefix_counts/checks.json').read_text())['rows']};seeds=json.loads((I/'exact_compensation_seeds.json').read_text());rows=[];checks=mono=improve=positive=0;crossings=0
for group in seeds['groups']:
 n=int(group['n'])
 for item in group['sources']:
  u=int(item['u'])
  if (n,u) not in wanted:continue
  p=replay(n,item);H=p['H'];P=source_count(n);B=5+F(n,100000*P);amin=H+1+(11-(H+1))%16;delta=F(5,9*amin);C=p['kappa']+F(9*(amin+5),5*(9*amin+5));core=set(actual_core(p,P));runs=p['runs'];N=len(p['word']);rd=resolution[n,u];boundary=next((r['i'] for r in runs if r['i']>=rd),N)
  selected=[j for j,r in enumerate(runs) if j in core and (r['s'],r['e'])==(2,2)]
  def V(q,Qcap):
   T=Qcap-B;L=max(q,B)
   if L>=T:return F(0)
   Z=min(Qcap,T+delta*(u+T))
   return C*(Z-L)/(u+L)
  assert p['phases'][rd]>=p['Q']-B
  out=dict(n=str(n),u=str(u),resolution=rd,boundary=boundary,core_R=len(selected),remaining_core_R=sum(runs[j]['i']>=boundary for j in selected),total_core_charge=str(sum((runs[j]['psi'] for j in selected),F(0))),phase_cutoff_passed_at_resolution=True,samples=[])
  for Qcap,label in [(p['Q'],'completed_phase'),(F(15*u,32),'unresolved_cap')]:
   for j,r in enumerate(runs):
    q=r['q'];future=[jj for jj in selected if jj>=j];charge=sum((runs[jj]['psi'] for jj in future),F(0));v=V(q,Qcap);assert charge<=v;checks+=1
    paid=r['psi'] if j in selected else F(0)
    assert paid+V(r['qend'],Qcap)<=v;mono+=1
    occ=C*delta*len(future);assert charge<=occ
    oldbound=F(2*len(future),3*(H+1));assert occ<=oldbound
    if label=='completed_phase' and charge>0:
     positive+=1;improve+=v<oldbound
    if j in selected and r['qend']>Qcap-B:crossings+=1
    if r['i']==boundary:out['samples'].append(dict(cap=label,exact_charge=str(charge),phase_bound=str(v),occurrence_bound=str(occ),combined_bound=str(min(v,occ)),phase_to_old=float(v/oldbound) if oldbound else None))
  rows.append(out)
# Exact algebraic controls: final selected run can overshoot T; naive truncation undercounts.
u=100;B=F(1);Qcap=F(5);delta=F(1,200);q=F(399,100);qp=q+delta*(u+q);assert q<Qcap-B<qp<Qcap
naive=(Qcap-B-q)/(u+q);assert naive<delta
Z=min(Qcap,Qcap-B+delta*(u+Qcap-B));assert delta<=(Z-q)/(u+q)
r=dict(status='PASS',surviving_sources=len(rows),remaining_charge_checks=checks,monotonicity_checks=mono,positive_completed_phase_cases=positive,phase_improvements_over_count_bound=improve,observed_upper_boundary_crossings=crossings,overshoot_control='PASS',rows=rows,runtime_seconds=time.monotonic()-start,limits='1GiB/120sec',scope='Five saved singleton survivors at separate thresholds; completed Q is not a bound for unseen source cones.')
Path('tmp/singleton_charge_bounds/checks.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='rows'}),flush=True);os._exit(0)


