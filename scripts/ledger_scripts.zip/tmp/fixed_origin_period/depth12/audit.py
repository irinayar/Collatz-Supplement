from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from datetime import datetime
from zoneinfo import ZoneInfo
start=time.time(); out=Path('tmp/fixed_origin_period/depth12'); rows=[]
def T(x): return (3*x+1)//2 if x%2 else x//2
for j in range(1,13):
    B=1<<j; words=[]
    for mask in range(B):
        a=U=0
        for i in range(j):
            if mask>>i&1: U=3*U+(1<<i); a+=1
        r=(-U*pow(3**a,-1,B))%B or B
        words.append((a,U,r,mask))
    total=0; pairs=0; finite_checks=0; primitive_checks=0
    membership={}
    for a,U,r,mask in words:
        primitive=[]; higher=[]
        for b,V,rv,mv in words:
            pairs+=1
            if b<a: continue
            if (V-U)%3**a: continue
            if b==a:
                if V>U: primitive.append((0,1,b,V,mv))
            else:
                q=3**(b-a); h=((V-U)//3**a)%q
                (primitive if b==a+1 else higher).append((h,q,b,V,mv))
        covered={c for c in range(3) if any((c-h)%q==0 for h,q,b,V,mv in primitive)}
        assert all(h%3 in covered for h,q,b,V,mv in higher),(j,r,'higher odd-count obstruction')
        for c3 in range(3):
            n=r+B*((c3-r)*pow(B,-1,3)%3)
            membership[n]=c3 in covered
            if c3 not in covered: total+=1; continue
            valid=[]
            for h,q,b,V,mv in primitive:
                if (n-h)%q: continue
                num=3**a*n+U-V
                if num%3**b: continue
                m=num//3**b
                if 0<m<n:
                    xx=m; yy=n
                    for i in range(j):
                        assert xx%2==(mv>>i&1)
                        xx=T(xx); yy=T(yy)
                    assert xx==yy
                    valid.append((b,V))
            assert valid,(j,n,'first-representative exception')
            primitive_checks+=1
        # n>2^j cannot have a smaller meeting origin with fewer odd steps.
    least={}
    for n in range(1,B+1):
        x=n
        for i in range(j):x=T(x)
        actual=x in least
        assert actual==membership[n],(j,n,'small-height exception')
        least.setdefault(x,n);finite_checks+=1
    row=dict(j=j,period=3*B,survivor_count=total,all_word_pairs=pairs,first_representative_certificates=primitive_checks,small_height_checks=finite_checks,all_positive_integers_verified=True)
    rows.append(row)
    (out/'checkpoint.json').write_text(json.dumps(dict(completed_depth=j,rows=rows),indent=2))
# Independent all-odd-prefix obstruction controls, no inverse enumeration needed.
odd_controls=0
for j in range(1,41):
    for t in (1,2,7):
        n=(1<<j)*t-1;x=n
        for i in range(j):assert x%2; x=T(x)
        assert x+1==3**j*t;odd_controls+=1
result=dict(rows=rows,odd_prefix_controls=odd_controls,seconds=time.time()-start,limits='1 GiB process memory; 55 CPU and wall seconds',scope='Exact all-positive-integer periodicity for j=1..12, not all depths')
(out/'results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
os._exit(0)

