from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,hashlib
D=Path('tmp/multisuffix_family');r=json.loads((D/'results.json').read_text());total=0;proofs=[];family_count=multi_count=0
catalog={}
for e in range(9):
 by={}
 for d in range(e+1):
  for rest in itertools.combinations(range(1,4+d),3):
   positions=(0,)+rest;w=''.join('1' if j in positions else '0' for j in range(4+d));V=sum(2**j*3**(3-i) for i,j in enumerate(positions));rr=V*pow(2,-len(w),81)%81;by.setdefault(rr,[]).append(dict(word=w,d=d,V=V,k=e-d))
 catalog[e]=by
 for rr,ss in by.items():
  if max(z['k'] for z in ss)<=1 and any(z['k']==1 for z in ss):family_count+=1;multi_count+=len(ss)>1
for state in r['additional_exclusions']:
 ss=catalog[state['e']][state['z']%81];assert len(ss)==state['suffix_count'] and max(q['k'] for q in ss)<=1;branches=[];rr=state['b']-4
 for v in ss:
  x=(2**len(v['word'])*state['z']-v['V'])//81;assert x>0
  a=0;u=x+1
  while u%3==0:a+=1;u//=3
  defect=2**(a+1)*u-1;dd=defect;vv=0
  while dd%3==0:vv+=1;dd//=3
  candidates=[]
  for i in (range(rr+1) if v['k'] else [rr]):
   w='1'*i+('0'+'1'*(rr-i) if v['k'] else '')+v['word'];V=0
   for j,bit in enumerate(w):
    if bit=='1':V=3*V+2**j
   B=2**len(w)*state['z'];Q=3**state['b'];total+=1
   if (B-V)%Q==0 and 1<=(B-V)//Q<4064460795:candidates.append((B-V)//Q)
  assert not candidates
  branches.append(dict(suffix=v,intermediate=x,prefix_odds=rr,a=a,defect=defect,defect_v3=vv,max_prefix_odds=a+(vv if v['k'] else 0)))
 proofs.append(dict(state=state,branches=branches))
for name,h in json.loads(Path('tmp/residue_height/baseline.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
seed=Path('tmp/fair_terminal129_batch05/checkpoint.json');assert hashlib.sha256(seed.read_bytes()).hexdigest()==json.loads(Path('tmp/integer_height_envelope/results.json').read_text())['seed_sha256']
(D/'certificates.json').write_text(json.dumps(dict(verified=True,all_unsaturated_rows=family_count,multi_rows=multi_count,full_word_checks=total,proofs=proofs,checkpoint_unchanged=True,v9_unchanged=True),indent=2));print(dict(rows=family_count,multi=multi_count,full_word_checks=total,certificates=len(proofs)),flush=True);os._exit(0)
