from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,itertools,time
D=Path('tmp/multisuffix_family');start=time.monotonic();H=4;catalog={}
for e in range(9):
 by={}
 for g in itertools.product(range(e+1),repeat=4):
  d=sum(g)
  if d>e:continue
  w=''.join('1'+'0'*v for v in g);V=0
  for j,x in enumerate(w):
   if x=='1':V=3*V+2**j
  zmod=V*pow(2,-len(w),81)%81;by.setdefault(zmod,[]).append(dict(word=w,V=V,d=d,k=e-d))
 catalog[e]=by
families=[dict(e=e,residue=r,suffixes=ss) for e,by in catalog.items() for r,ss in by.items() if len(ss)>1 and max(s['k'] for s in ss)<=1 and any(s['k']==1 for s in ss)]
def val3(x):
 a=0
 while x%3==0:a+=1;x//=3
 return a,x
def prefix(x,r,k):
 if k==0:
  if (x+1)%3**r:return None
  m=2**r*((x+1)//3**r)-1;return (m,'1'*r) if m>0 else None
 a,u=val3(x+1);i=max(0,r-a)
 if i==0:m=2**(r+1)*((x+1)//3**r)-2
 else:
  defect=2**(a+1)*u-1
  if defect%3**i:return None
  m=2**i*(defect//3**i)-1
 return (m,'1'*i+'0'+'1'*(r-i)) if m>0 else None
checks=0
for x in range(1,301):
 for r in range(13):
  for k in [0,1]:
   actual=[]
   for i in (range(r+1) if k else [r]):
    w='1'*i+('0'+'1'*(r-i) if k else '');V=0
    for j,bit in enumerate(w):
     if bit=='1':V=3*V+2**j
    if (2**len(w)*x-V)%3**r==0:
     m=(2**len(w)*x-V)//3**r
     if m>0:actual.append((m,w))
   found=prefix(x,r,k);assert actual==([] if found is None else [found]);checks+=1
c=json.loads(Path('tmp/fair_terminal129_batch05/checkpoint.json').read_text());N=4064460795;frontier=[dict(level=int(k),t=t,z=z,b=b) for k,v in c['levels'].items() for t,z,b in v['stack']];records=[]
for index,q in enumerate(frontier):
 e=q['t']-q['b'];b=q['b'];z=q['z']
 if e not in catalog or b<4:continue
 ss=catalog[e].get(z%81,[])
 if not ss or any(v['k']>1 for v in ss):continue
 candidates=[]
 for v in ss:
  x=(2**len(v['word'])*z-v['V'])//81;assert x>0 and (2**len(v['word'])*z-v['V'])%81==0
  hit=prefix(x,b-4,v['k'])
  if hit:
   m,w=hit;w+=v['word'];xx=m;count=0
   for bit in w:
    assert xx%2==int(bit);count+=xx%2;xx=(3*xx+1)//2 if xx%2 else xx//2
   assert xx==z and count==b and len(w)==q['t']
   if m<N:candidates.append(dict(m=m,word=w))
 records.append(dict(index=index,**q,e=e,suffix_count=len(ss),unsaturated=any(v['k']==1 for v in ss),candidates=candidates,excluded=not candidates))
old=json.loads(Path('tmp/integer_height_envelope/lattice_results.json').read_text());oldcuts={v['index'] for v in old['bounds'] if v['excluded']};extra=[v for v in records if v['excluded'] and v['index'] not in oldcuts]
res=dict(families=families,prefix_checks=checks,frontier_records=records,additional_exclusions=extra,seconds=time.monotonic()-start)
(D/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(dict(families=len(families),prefix_checks=checks,frontier_matches=len(records),multisuffix_unsaturated=sum(v['suffix_count']>1 and v['unsaturated'] for v in records),excluded=sum(v['excluded'] for v in records),extra=extra,witnesses=sum(len(v['candidates']) for v in records),seconds=res['seconds'])),flush=True);os._exit(0)
