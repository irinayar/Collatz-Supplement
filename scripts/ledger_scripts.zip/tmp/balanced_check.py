from pathlib import Path
prefix=Path('tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0]
exec(prefix.replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
from fractions import Fraction as F
from itertools import permutations
import json,time
start=time.time();outdir=Path('tmp/balanced_pair_audit');outdir.mkdir(exist_ok=True)
blocks={2:[1,2,1,2,2],3:[1,2,1,2,1,2,2]};families=[]
for code in sorted(set(permutations([2,2,3,3]))):
 word=sum([blocks[b] for b in code],[]);num=E=0;lam=F(1);C0=F();minlam=F(1);s=0
 for e in word:
  num=3*num+2**E;E+=e;s+=1
  if e==2:
   assert s in [1,2]
   if s==2:C0+=F(2,3)/lam
   lam*=F(3**s,2**(s+1));minlam=min(minlam,lam);s=0
 A=3**len(word);D=2**E;assert A==3**24 and D==2**38
 families.append(dict(code=code,word=word,B=num,C0=str(C0),K=str(C0*A/(A-D)),minlam=str(minlam)))
K=max(F(f['K']) for f in families);ct=F(96,274*5000);b0=F(3000,2797);a0=F(8850,170617);T=F(327,3904)
assert 5000**22<2**272 and max(159*ct,b0*56*ct+a0,b0*K*ct+a0)<T
N=8;Ds=[D**j for j in range(N+1)];mods=[2*d for d in Ds];inv=[pow(A**j,-1,mods[j]) for j in range(N+1)];ia=pow(A,-1,mods[N]);Bs=[f['B'] for f in families]
mins=[None]*(N+1);counts=[0]*(N+1);reverse=0
checkpoint=outdir/'checkpoint.json';done=0
if checkpoint.exists():
 cp=json.loads(checkpoint.read_text());assert cp['families']==[list(f['code']) for f in families];done=cp['completed_first_choices'];mins=cp['minima'];counts=cp['counts'];reverse=cp['reverse_checks']
 def fix(row):return None if row is None else [int(row[0]),row[1]]
 mins=list(map(fix,mins))

def dfs(j,num,code):
 global reverse
 r=((Ds[j]-num)*inv[j])%mods[j];assert r&1;counts[j]+=1
 if mins[j] is None or r<mins[j][0]:mins[j]=[r,code]
 if j==N:
  v=1
  for bit in reversed(code):v=((D*v-Bs[bit])*ia)%mods[N]
  assert v==r;reverse+=1;return
 for bit,B in enumerate(Bs):dfs(j+1,A*num+Ds[j]*B,code+[bit])
for bit in range(done,6):
 dfs(1,Bs[bit],[bit]);checkpoint.write_text(json.dumps(dict(families=[f['code'] for f in families],completed_first_choices=bit+1,minima=[[str(x[0]),x[1]] if x else None for x in mins],counts=counts,reverse_checks=reverse)))
 print(json.dumps(dict(completed_first_choices=bit+1,leaves=reverse,seconds=time.time()-start)),flush=True)
for j in range(1,N+1):
 assert counts[j]==6**j;x=mins[j][0]
 for bit in mins[j][1]:
  for e in families[bit]['word']:
   z=3*x+1;assert (z&-z).bit_length()-1==e;x=z>>e
sufficient=56*3*mins[N][0]>=K*(4*(2**272-1)+1)
assert F(20*(N-1),3)<=56
out=dict(status='PASS' if sufficient else 'HEIGHT_GAP',families=families,Kmax=str(K),threshold_bits=272,depth=N,leaves=reverse,minima=[[str(x[0]),x[1]] if x else None for x in mins],counts=counts,finite_paid=sufficient,tail_ratio=str(ct),tail_core_bound=str(b0*K*ct+a0),tail_margin=str(T-(b0*K*ct+a0)),seconds=time.time()-start)
(outdir/'audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['families','minima','counts']}),flush=True);os._exit(0)
