from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
from fractions import Fraction as F
import sys,json
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
D=Path('tmp/short_run_occupation');seeds=json.loads((I/'exact_compensation_seeds.json').read_text());rows=[];counts=dict(profiles=0,high_profiles=0,all_R=0,proper_R=0,phase_R=0,canonical_R=0,core_R=0,identity_checks=0,phase_only_nonempty=0,canonical_removed_profiles=0)
for group in seeds['groups']:
 n=int(group['n']);H=(4*n-2)//3;P=source_count(n) if n>=2**71 else None
 for item in group['sources']:
  p=replay(n,item);Q=p['Q'];counts['profiles']+=1;u=p['u'];N=len(p['word']);E=p['E'];M=2**(E+1);R=[(j,r) for j,r in enumerate(p['runs']) if (r['s'],r['e'])==(2,2)];counts['all_R']+=len(R)
  for j,r in R:
   a=r['a'];b=r['b'];assert a%16==11 and 8*b==9*a+5
   assert r['delta']==F(5,9*a) and r['flux']==F(a+5,a*(9*a+5))
   assert r['psi']==p['kappa']*r['delta']+r['flux']>0
   assert r['psi']<=F(2,3*a) and r['psi']<6*r['flux']
   g=r['i'];U=p['phases'][g]*3**g;assert U.denominator==1;cap=(2**E-int(U)-1)//3**g
   if g>0:
    assert r['q']<F(u*g,3*u-g) if g<3*u else True
    remaining=N-g
    assert Q-r['q']<(u+r['q'])*F(remaining,3*p['H']-remaining) if remaining<3*p['H'] else True
   interior=r['time']+(a.bit_length()-1)<E
   assert interior==(u<=cap);counts['identity_checks']+=1
  if P is None:continue
  counts['high_profiles']+=1;B=5+F(n,100000*P);Q=p['Q'];core=actual_core(p,P);proper=[(j,r) for j,r in R if r['i']>0];phase=[(j,r) for j,r in proper if B<r['q']<Q-B]
  caprows=[]
  for j,r in phase:
   g=r['i'];U=int(r['q']*3**g);cap=(2**E-U-1)//3**g;caprows.append((g,cap,j,r))
  assert all(caprows[i][1]>=caprows[i+1][1] for i in range(len(caprows)-1))
  canon=[(g,c,j,r) for g,c,j,r in caprows if u<=c];actual=[r for j,r in R if j in core]
  gmin=(F(3*u)*B/(u+B)).__floor__()+1
  assert P<=H and gmin>=16
  rmin=(F(3*H)*B/(u+Q)).__floor__()+1
  gmax=-1;power=1
  for g in range(N+1):
   if power*(u+B)<2**E:gmax=g
   power*=3
  gmax=min(gmax,N-rmin)
  simple=max(0,1+(gmax-gmin)//2)
  assert len(canon)<=simple
  for g,c,j,r in canon:
   assert g>=gmin and N-g>=rmin
   assert u<M and u==(((2**E-int(Q*3**N))*pow(3**N,-1,M))%M)
  for k,(g,c,j,r) in enumerate(canon,1):
   assert g>=gmin+2*(k-1)
   assert 2*3**(gmin+2*(k-1))*(u+B)<M
  assert len(actual)<=len(canon)
  charge=sum((r['psi'] for r in actual),F(0));assert charge<=F(2*len(canon),3*(H+1))
  counts['proper_R']+=len(proper);counts['phase_R']+=len(phase);counts['canonical_R']+=len(canon);counts['core_R']+=len(actual)
  counts['phase_only_nonempty']+=bool(phase);counts['canonical_removed_profiles']+=bool(phase) and not bool(canon)
  # All eligible counts obey the exact kth-cap rule, not merely a sampled inequality.
  for k in range(1,len(caprows)+1):assert (len(canon)>=k)==(u<=caprows[k-1][1])
  rows.append(dict(n=str(n),u=str(u),odd_count=N,halving_count=E,proper_R=len(proper),phase_R=len(phase),canonical_R=len(canon),core_R=len(actual),gmin=gmin,gmax=gmax,coarse_count_bound=simple,actual_R_charge=str(charge),cap_indices=[g for g,c,j,r in caprows],cap_pass=[u<=c for g,c,j,r in caprows]))
result=dict(status='PASS',counts=counts,rows=rows,scope='Exact per-word occupation cap; aggregate source-count tail not proved. No actual core removed by a necessary test.')
(D/'checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'PASS','counts':counts,'nonempty_rows':[{k:r[k] for k in ['proper_R','phase_R','canonical_R','core_R','gmin','gmax','coarse_count_bound']} for r in rows if r['core_R']]}),flush=True);os._exit(0)


