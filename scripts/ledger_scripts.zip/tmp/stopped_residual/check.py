from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time,runpy
from fractions import Fraction as F
D=Path('tmp/stopped_residual');beg=time.monotonic();sys.set_int_max_str_digits(50000)
if not (D/'replay.json').exists():
 sys.argv=['verify_stopped_aggregate.py','--output',str(D/'replay.json')];runpy.run_path(str(D/'verify_stopped_aggregate.py'),run_name='__main__')
assert json.loads((D/'replay.json').read_text())==json.loads((D/'stopped_aggregate_certificate.json').read_text())
# Independent cumulative-count recurrence, distinct from supplied append-exponent loop.
A=F(1001,1000);row=[1];paid=F(0)
for g in range(64):
 paid+=F(sum(row),3**(g+1));limit=0
 while 1000*2**(limit+1)<=1001*3**(g+1):limit+=1
 nxt=[];acc=0
 for e in range(limit+1):
  nxt.append(acc)
  if e<len(row):acc+=row[e]
 row=nxt
cap=paid+A*sum((F(c,2**e) for e,c in enumerate(row)),F(0))
assert cap==F(json.loads((D/'replay.json').read_text())['first_moment_bellman']['upper'])
# Elementary independent exponential supersolution F=4, theta=750/1001.
theta=F(750,1001);z=F(4501,1001);poly=term=F(1)
for j in range(1,25):term*=z/j;poly+=term
rcharge=1/(theta*poly);allcharge=F(5,3)/(theta*poly)
assert rcharge<F(149,10000) and allcharge<F(249,10000)<F(116073,3904000)
# Exact finite prefix-antichain transfers, using a known constant Bellman tail.
controls=0
for n in range(15,256,2):
 H=(4*n-2)//3;W=H-n;groups={}
 for u in range(n,H+1,2):
  x=u;E=0;q=F(0);word=[];live=True
  for g in range(2):
   lam=F(2**E,3**g)
   if lam>A or 2**(E+1)>2*W:live=False;break
   q+=lam/3;z=3*x+1;e=(z&-z).bit_length()-1;x=z//2**e;E+=e;word.append(e)
   if x<=H:live=False;break
  if not live or 2**(E+1)>2*W or F(2**E,9)>A:continue
  entry=groups.setdefault(tuple(word),{'E':E,'cost':F(0),'count':0})
  entry['count']+=1
  for g in range(2,12):
   if x<=H or 2**(E+1)>2*W or F(2**E,3**g)>A:break
   entry['cost']+=F(1,x);z=3*x+1;e=(z&-z).bit_length()-1;x=z//2**e;E+=e
 for v in groups.values():
  assert v['count']<=F(W,2**v['E'])
  assert v['cost']<=F(3*W,n)*F(1,2**v['E'])*A;controls+=1
# Saved exact genuine paths; caps routine sees prefix only.
src=Path('tmp/unresolved_phase_caps/check.py').read_text();exec(src[src.index('from fractions import'):src.index("I=Path('tmp/compensation")])
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
rows=[];groups={};seen=set();all_profiles=0;all_R=early_Rinputs=late_Rinputs=0;positive_shortfalls=0;occ_bearing=0
for group in json.loads((I/'exact_compensation_seeds.json').read_text())['groups']:
 n=int(group['n'])
 if n<2**71:continue
 P=source_count(n);B=5+F(n,100000*P)
 for item in group['sources']:
  u=int(item['u'])
  if (n,u) in seen:continue
  seen.add((n,u));p=replay(n,item);all_profiles+=1;H=p['H'];W=H-n
  selected=[r for j,r in enumerate(p['runs']) if j in set(actual_core(p,P)) and (r['s'],r['e'])==(2,2)]
  for rr in selected:
   all_R+=1
   for j in range(rr['i'],rr['j']):
    if 2**(p['times'][j]+1)<=2*W:early_Rinputs+=1
    else:late_Rinputs+=1
  counts=[];lower=n
  for j in range(len(p['word'])):
   exp=p['times'][j];num=int(p['phases'][j]*3**j);mod=2**(exp+1)
   if j:lower=max(lower,(2**exp*H-num)//3**j+1)
   residue=(2**exp-num)*pow(3**j,-1,mod)%mod;first=lower+(residue-lower)%mod
   counts.append(max(0,(H-first)//mod+1));assert counts[-1]>=1
  boundaries=[r for r in p['runs'] if counts[r['i']]==1]
  if not boundaries:continue
  r=boundaries[0];g=r['i'];q=p['phases'][g];Qbar,meta=caps(n,u,p['odd'][:g],q);b=F(meta['b'])
  a0=H+1+(11-H-1)%16;delta=F(5,9*a0);gap=B-delta*(u+Qbar-B);assert gap>0
  entry=max(F(0),6*(B-q)/(2*u+B+q));tail=6*gap/(2*(u+Qbar)-gap);t=entry+tail;res=max(F(0),b-t)
  cut=next((j for j in range(g,len(p['word'])) if 2**(p['times'][j]+1)>2*W),len(p['word']))
  late=F(0) if cut==len(p['word']) else F(caps(n,u,p['odd'][:cut],p['phases'][cut])[1]['b'])
  # No prospective beyond-prefix claim: cut prefix is saved and replayed exactly.
  xmax=2**(64*n.bit_length())-5;beta=F(1,xmax)+F(2,3*xmax+1)
  shortfall=max(F(0),beta+t-late);positive_shortfalls+=shortfall>0
  early=sum((F(1,x) for x in p['odd'][g:cut]),F(0));actual_late=sum((F(1,x) for x in p['odd'][cut:-1]),F(0));assert actual_late<=late
  future=[rr for rr in selected if rr['i']>=g];bearing=bool(future);occ_bearing+=bearing
  if bearing:
   assert shortfall<=early
   cost=sum((F(1,p['odd'][j]) for rr in future for j in range(rr['i'],rr['j'])),F(0));assert cost<=res
  gr=groups.setdefault(n,{'weights':[],'actual_cost':F(0),'actual_residual':F(0),'early':F(0)})
  gr['weights'].append((res,shortfall));gr['early']+=early
  if bearing:gr['actual_residual']+=res
  rows.append({'n':str(n),'u':str(u),'depth':g,'E':p['times'][g],'past_cutoff':2**(p['times'][g]+1)>2*W,'future_R':len(future),'shortfall_positive':shortfall>0,'residual':str(res),'shortfall':str(shortfall)})
grouprows=[]
for n,v in groups.items():
 Acap=F(3*((4*n-2)//3-n),n)*cap;assert v['early']<=Acap
 candidates=[F(0)]+[r/h for r,h in v['weights'] if h]
 dual=min(lam*Acap+sum((max(F(0),r-lam*h) for r,h in v['weights']),F(0)) for lam in candidates)
 raw=sum((r for r,h in v['weights']),F(0));assert v['actual_residual']<=dual<=raw
 grouprows.append({'n':str(n),'sources':len(v['weights']),'old_sum':str(raw),'dual_bound':str(dual),'strict_improvement':dual<raw})
# Independent finite-subset verification of the dual/count statement, including a strict control.
from itertools import combinations
weights=[(F(5),F(3)),(F(4),F(2)),(F(2),F(0))];allow=F(3);dual=min(l*allow+sum(max(F(0),r-l*h) for r,h in weights) for l in [F(0)]+[r/h for r,h in weights if h]);subtests=0
for mask in range(8):
 ss=[weights[i] for i in range(3) if mask>>i&1]
 if sum(h for r,h in ss)<=allow:assert sum(r for r,h in ss)<=dual;subtests+=1
assert dual<sum(r for r,h in weights)
fresh=json.loads(Path('tmp/unresolved_phase_caps/checks.json').read_text())['new_unresolved'];fresh_past=2**(fresh['E']+1)>2*(int(fresh['H'])-int(fresh['n']));assert fresh_past
out={'status':'PASS','limits':'1GiB/120s','independent_C64':str(cap),'elementary_R_charge_upper':str(rcharge),'elementary_alltype_charge_upper':str(allcharge),'finite_antichain_controls':controls,'saved_high_floor_profiles':all_profiles,'selected_R_runs':all_R,'early_selected_inputs':early_Rinputs,'late_selected_inputs':late_Rinputs,'singleton_frontiers':len(rows),'frontiers_past_cutoff':sum(r['past_cutoff'] for r in rows),'occurrence_bearing_frontiers':occ_bearing,'positive_shortfalls':positive_shortfalls,'strict_group_improvements':sum(r['strict_improvement'] for r in grouprows),'dual_subset_controls':subtests,'fresh_depth_unchanged':fresh['depth'],'fresh_past_cutoff':fresh_past,'rows':rows,'groups':grouprows,'seconds':time.monotonic()-beg,'scope':'Finite saved catalogue only; moment-certificate import not audited; no new global residual bound.'}
(D/'checks.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['rows','groups','independent_C64','elementary_R_charge_upper','elementary_alltype_charge_upper']}),flush=True);os._exit(0)
