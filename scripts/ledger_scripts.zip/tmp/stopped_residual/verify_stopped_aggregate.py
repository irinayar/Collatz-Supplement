#!/usr/bin/env python3
"""Exact controls for the stopped aggregate reciprocal-budget corollary.

The exponential-moment theorem is an identified import for phase-tail bounds.
The phase-free Bellman tail is proved here. No trajectory
census, undiscounted late-atom theorem, or cap-remainder aggregate is claimed.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import json
from pathlib import Path

if not __debug__:
    raise SystemExit("Run without -O or -OO: exact assertions are required.")


def exp_lower(x, degree):
    assert x >= 0
    total = term = F(1)
    for k in range(1, degree+1):
        term *= x/k
        total += term
    return total


def first_moment():
    A=F(1001,1000)
    rows={0:1}
    cost=F(0)
    previous=A
    levels=[]
    for g in range(65):
        survival=sum((F(c,2**E) for E,c in rows.items()),F(0))
        cap=cost+A*survival
        assert cap<=previous
        previous=cap
        levels.append({"depth":g,"live_E_states":len(rows),
                       "prefix_count":str(sum(rows.values())),
                       "survival_weight":str(survival),
                       "cost_through_previous_depth":str(cost),
                       "tail_included":str(A*survival),
                       "first_moment_upper":str(cap)})
        if g==64:
            break
        cost+=F(sum(rows.values()),3**(g+1))
        nxt={}
        for E,count in rows.items():
            e=1
            while 1000*2**(E+e)<=1001*3**(g+1):
                nxt[E+e]=nxt.get(E+e,0)+count
                e+=1
        rows=nxt
    assert F(levels[1]["first_moment_upper"])==F(5003,6000)
    assert cap==F(80147532093873483207202441389202356216370417427993932413259609,
                  116072302821007019464487645911519890966854661759054802751324160)
    assert cap<F(1381,2000)
    # Exact controls of the analytic constant supersolution at its equality
    # points. The proof in the note covers every real multiplier in (0,A].
    for m in range(2,81):
        lam=3*A/(2**m)
        assert 0<lam<=A and A*F(1,2**m)==lam/3
    return {"tail_supersolution":"h(lambda)=1001/1000",
            "depth":64,"upper":str(cap),"simple_upper":"1381/2000",
            "levels":levels,
            "scope":"Exact Bellman iteration with a proved full future tail; no exponential-moment import required."}


def verify():
    cases = 0
    for W in range(1, 1025):
        M = 1
        while M <= 2*W:
            maximum_count = W//M+1
            assert maximum_count*M <= 2*W
            cases += 1
            M *= 2
    # Inclusive endpoint controls and failure beyond the permitted range.
    assert (16//16+1)*16 == 2*16
    assert (16//32+1)*32 == 2*16
    assert F(1) > F(2*16, 64)
    # Actual high-floor all-one prefixes can also be occupied beyond it.
    m = 72
    n, H, u = 3*2**(m-2)+1, 2**m, 2**m-1
    W, M = H-n, 2**m
    assert n <= u <= H and M > 2*W
    assert F(2*W, M) < 1

    theta, J, eta = F(200,143), F(82262531839,10**10), F(1,2000)
    assert 1+F(1,3*2**64-1) < F(1001,1000)
    first_moment_result=first_moment()
    phase_free = F(1507,1000)
    sharper_phase_free = F(753371,500000)
    assert exp_lower(theta*phase_free,30) > J
    assert exp_lower(theta*sharper_phase_free,30) > J
    table = []
    for b in range(5,11):
        denominator_exp = exp_lower(theta*b+1-eta,48)
        assert denominator_exp > 1/eta
        cap = (J-1)/(theta*denominator_exp)
        table.append({"phase_threshold":b,"rational_occupation_upper":str(cap),
                      "decimal_informational":float(cap)})
    sharp_tail = F(table[0]["rational_occupation_upper"])
    assert sharp_tail < F(1746295,10**9) < F(7,4000)
    run_mass = F(8563637,26873856)
    assert run_mass*sharp_tail < F(557,10**6)
    assert F(1,12)*sharp_tail < F(7,48000)
    return {"status":"PASS","integer_count_controls":cases,
            "extended_modulus_cutoff":"M <= 2*(H-n)",
            "phase_moment_import":{
                "certificate":"phase_frontier_work/killed_phase_certificate.json",
                "sha256":"c3273a03d5e5108be6ff0f4c8d60effab46f40a02cee175d89082800b7c89d63",
                "initial_mgf_upper":str(J),"theta":str(theta)},
            "actual_stopped_reciprocal_upper":"1381/2000",
            "first_moment_bellman":first_moment_result,
            "superseded_jensen_upper":str(phase_free),
            "sharper_superseded_jensen_upper":str(sharper_phase_free),
            "phase_5_reciprocal_upper":"1746295/1000000000",
            "complete_run_extended_cutoff_upper":"557/1000000",
            "phase_table":table,
            "scope":"All actual band-source excursion prefixes through M<=2W; no future completion needed for reciprocal bound. Genuine completed-profile hypotheses retained for run-charge bound.",
            "unresolved":"Actual occupation after M>2W, aggregate K188 cap remainders, and unrestricted signed central aggregate."}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("stopped_aggregate_certificate.json"))
    args=parser.parse_args()
    result=verify()
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ("status","integer_count_controls",
          "extended_modulus_cutoff","actual_stopped_reciprocal_upper",
          "phase_5_reciprocal_upper","complete_run_extended_cutoff_upper")},indent=2))


if __name__=="__main__":
    main()
