from pathlib import Path
src=Path('tmp/four_even_height/check.py').read_text(encoding='utf-8-sig');exec(src[:src.index('cells=height_cases=0')])
D=Path('tmp/four_even_transition');D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();baseline={p.name:sha(p) for p in Path.cwd().glob('Collatz_v10.*')};(D/'baseline.json').write_text(json.dumps(baseline),encoding='utf8')
counts={};overlaps=takeovers=0
for u in range(1,3001):
 if u%3==0:continue
 x=3*u-1;A=6*u-2;B=4*u-2;C=4*u-1;c=a3(C)
 pp=R(A,3);qq=1+R(B,3)
 vals=[H(x,r,4) for r in range(R(x,4)+1)];assert all(vals[i]>vals[i+1] for i in range(len(vals)-1))
 for r in range(1,min(pp,qq)+1):
  diff=H(A,r,3)-H(B,r-1,3);assert diff==(4 if r<=c+1 else 1);overlaps+=1
 if u%3==2:
  case='u2';assert qq==1 and H(B,0,3)-H(A,2,3)==(8*C-14)//3>0
 else:
  v=C//3**c;G=2**(c+1)*v-1;J=2*G+1
  if G%3==0:
   case='G0';assert pp==c+1 and qq>pp
  else:
   assert G%3==1;d=a3(J);j=J//3**d
   assert H(A,c+2,3)-H(B,c+1,3)==1
   assert min(pp,qq)==c+2
   if d>=2:
    case='d2';assert qq==c+2 and pp>qq
    assert H(B,c+1,3)-H(A,c+3,3)==4*J//9-1>0
   elif j%3==1:
    case='d1j1';assert j>1 and qq==c+2 and pp>qq
    assert H(B,c+1,3)-H(A,c+3,3)==(4*j-4)//3>0
   else:
    case='d1j2';assert j%3==2 and pp==c+2 and qq>pp
 counts[case]=counts.get(case,0)+1
 if qq<pp:
  assert H(A,qq+1,3)<H(B,qq-1,3);takeovers+=1
# Direct formal-word enumeration, independent of grouped recursion.
wordcells=0
for x in range(1,81):
 for r in range(9):
  best=None
  for zeros in itertools.combinations(range(r+4),4):
   V=0
   for i in range(r+4):
    if i not in zeros:V=3*V+2**i
   num=2**(r+4)*x-V
   if num>0 and num%3**r==0:
    m=num//3**r;best=m if best is None else min(best,m)
  assert best==H(x,r,4);wordcells+=1
# General-a reduction and monotonicity checked independently of case predictions.
series=0
for x in range(1,1001):
 vals=tree(x,4);mm=[min(vals[r]) for r in range(max(vals)+1)]
 assert all(mm[i]>mm[i+1] for i in range(len(mm)-1));series+=1
for p,h in baseline.items():assert sha(Path(p))==h
result=dict(case_counts=counts,overlap_checks=overlaps,takeover_checks=takeovers,direct_word_cells=wordcells,independent_series=series,seconds=time.monotonic()-start,v10_unchanged=True)
(D/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(result,flush=True);os._exit(0)
