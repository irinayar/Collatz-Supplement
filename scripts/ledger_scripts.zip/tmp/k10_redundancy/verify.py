from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
O=Path.cwd();D=O/'tmp/k10_redundancy';start=time.time()
def family(k,s):
 r=2
 while 3**(r+s)<=2**(r+2*s+1+k):r+=1
 q=3**(r+s);p=2**(r+2*s+1+k);u=q+p//2**k-2**r*3**(s+1)
 return dict(k=k,s=s,r=r,q=q,p=p,U=u,rho=u*pow(p,-1,q)%q,word='1'*r+'01'*s+'0'*(k+1))
rows=[];checks=0
for s in range(101):
 f=family(10,s)
 if s:assert f['rho']%9==4
 else:
  prev=family(8,1);assert f['q']%prev['q']==0 and f['rho']%prev['q']==prev['rho']
 for t in [0,1]:
  n=f['rho']+f['q']*t;m=(f['p']*n-f['U'])//f['q'];assert 0<m<n;x=m
  for b in f['word']:
   assert x%2==int(b);x=(3*x+1)//2 if x%2 else x//2
  assert x==n;checks+=1
 rows.append(f)
reductions=[]
for k0 in range(2,101,2):
 a=family(k0,0);b=family(k0-2,1)
 assert a['q']%b['q']==0 and a['rho']%b['q']==b['rho']
 reductions.append({'k':k0,'r_s0':a['r'],'parent_r':b['r'],'modulus_ratio':a['q']//b['q']})
residue_controls=0
for k0 in range(4,101,6):
 for s in [1,2,6,20,100]:assert family(k0,s)['rho']%9==4;residue_controls+=1
odd_controls=0
for k0 in range(1,100,2):
 for s in [0,1,6]:assert family(k0,s)['rho']%3==2;odd_controls+=1
base=O/'tmp/k8_tail/coverage_extension.json';source=json.loads(base.read_text())
result={'new_marginal':0,'k10_s0':rows[0],'parent_C115_s1':family(8,1),'all_s_ge1':'C110s0:4mod9','k10_actual_path_checks':checks,'general_even_s0_controls':reductions,'k_mod6_controls':residue_controls,'odd_k_controls':odd_controls,'coverage_unchanged':{t:v['rounded_percent_10dp'] for t,v in source['depths'].items()},'base_file':str(base.relative_to(O)),'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'elapsed_seconds':time.time()-start,'scope':'Finite controls supplement the analytic all-k/all-s containment proof; no new density increment.'}
(D/'checkpoint.json').write_text(json.dumps(result,indent=2));(D/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps({'k10_s0':{a:rows[0][a] for a in ['r','q','rho']},'parent':{a:family(8,1)[a] for a in ['r','q','rho']},'checks':checks,'seconds':result['elapsed_seconds']}),flush=True);os._exit(0)
