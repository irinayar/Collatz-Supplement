from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib,itertools
from collections import Counter
from functools import lru_cache
D=Path('tmp/k081_precision12');D.mkdir(exist_ok=True);start=time.monotonic();N=4064460795;H=4;tables=[[{0:(0,0)}]]
for t in range(1,130):
 new=[{} for _ in range(t+1)]
 for b,layer in enumerate(tables[-1]):
  for lo,hi in layer.values():
   for bb,L,U in [(b,lo,hi),(b+1,3*lo+2**(t-1),3*hi+2**(t-1))]:
    res=L%3**min(H,bb);assert res==U%3**min(H,bb);prev=new[bb].get(res);new[bb][res]=(min(L,prev[0]),max(U,prev[1])) if prev else (L,U)
 tables.append(new)
 assert time.monotonic()-start<30
residue=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text());proof=json.loads(Path('tmp/precision12_continue02/proof.json').read_text());claimed=json.loads(Path('tmp/collatz_two_arc/frontier_emptiness_claude_results.json').read_text());front=json.loads(Path('tmp/five_even_height_application/remaining_frontier.json').read_text());roots=[q for q in front if claimed[q['index']]['status']=='unresolved']
def test(x,r,k):
 t=r+k;B=2**t*x;Q=3**r;ex=tables[t][r].get(B%3**min(H,r))
 if ex is None:return dict(excluded=True,reason='empty_coarse_cell')
 lo,hi=ex;L=max(lo,B-Q*(N-1));U=min(hi,B-Q);first=L+(B-L)%Q
 return dict(excluded=L>U or first>U,reason='empty_real_interval' if L>U else 'empty_full_lattice' if first>U else 'survives',lo=lo,hi=hi,L=L,U=U,first=first)
rows=[];counts=Counter();byrule=Counter()
for z in proof:
 x,r,k=z['x'],z['r'],z['k'];v=test(x,r,k);counts[v['reason']]+=1
 if v['excluded']:
  byrule[z['rule']]+=1;rows.append(dict(x=x,r=r,k=k,baseline_rule=z['rule'],**v))
  if z['rule']=='union':counts['additional_before_union']+=1
root_rows=[dict(**q,**test(q['z'],q['b'],q['t']-q['b'])) for q in roots];rootcuts=[q['index'] for q in root_rows if q['excluded']]
# Independent recursive extrema for every new union/root cut (bounded cache).
@lru_cache(maxsize=50000)
def extrema(t,b,h,res):
 if b<0 or b>t:return None
 h=min(h,b);res%=3**h
 if h==0:return (3**b-2**b,2**(t-b)*(3**b-2**b))
 choices=[]
 if b<t:
  q=extrema(t-1,b,h,res)
  if q:choices.append(q)
 p=2**(t-1)
 if b and (res-p)%3==0:
  q=extrema(t-1,b-1,h-1,(res-p)//3)
  if q:choices.append((3*q[0]+p,3*q[1]+p))
 return (min(q[0] for q in choices),max(q[1] for q in choices)) if choices else None
checks=0
for q in [z for z in rows if z['baseline_rule']=='union']:
 t=q['r']+q['k'];B=2**t*q['x'];ex=extrema(t,q['r'],4,B%3**min(4,q['r']))
 assert ex==(None if q['reason']=='empty_coarse_cell' else (q['lo'],q['hi']));checks+=1
 assert time.monotonic()-start<40
# Exhaustive positive controls test the exact formulas, including equality at the bound.
controls=0
for t in range(1,9):
 for bits in itertools.product((0,1),repeat=t):
  r=sum(bits);k=t-r;V=0
  for i,b in enumerate(bits):
   if b:V=3*V+2**i
  for m in (1,2,7):
   x=m;valid=True
   for b in bits:
    if x%2!=b:valid=False;break
    x=(3*x+1)//2 if b else x//2
   if valid:assert not test(x,r,k)['excluded'];controls+=1
for p,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out=dict(saved_states=len(proof),numerator_precision=4,baseline_residue_precision=12,counts=dict(counts),cuts_by_baseline_rule=dict(byrule),root_count=len(roots),root_cuts=rootcuts,independent_new_cut_checks=checks,actual_word_positive_controls=controls,seconds=time.monotonic()-start,v10_unchanged=True)
for name,data in [('results',out),('cut_certificates',rows),('root_results',root_rows)]: (D/(name+'.json')).write_text(json.dumps(data,indent=2),encoding='utf8')
print(out,flush=True);os._exit(0)
