from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
import json
src=Path('tmp/integer_height_envelope/verify.py').read_text(encoding='utf-8-sig');start=src.index('@lru_cache');end=src.index('\ncert=[]');exec(src[start:end].replace('maxsize=100000','maxsize=50000'))
D=Path('tmp/k081_precision12');rows=json.loads((D/'cut_certificates.json').read_text());checks=0
for q in [z for z in rows if z['reason']=='empty_full_lattice'][:64]:
 x,r,k=q['x'],q['r'],q['k'];B=2**(r+k)*x;Q=3**r;assert extrema(r+k,r,4,B%81)==(q['lo'],q['hi']);assert q['L']<=q['U'] and (B-q['L'])%Q>q['U']-q['L'];checks+=1
roots=json.loads((D/'root_results.json').read_text());candidates=[];found=[]
for q in roots:
 x,r,t=q['z'],q['b'],q['t'];B=2**t*x;Q=3**r
 assert extrema(t,r,4,B%81)==(q['lo'],q['hi'])
 for side in ('lo','hi'):
  numerator=B-q[side]
  status='nonintegral' if numerator%Q else 'nonpositive' if numerator<=0 else 'positive_integer'
  row=dict(index=q['index'],side=side,status=status)
  if status=='positive_integer':
   m=numerator//Q;z=m;odd=0
   for i in range(t):odd+=z%2;z=(3*z+1)//2 if z%2 else z//2
   assert z==x and odd==r and m<4064460795
   for i in range(129-t):z=(3*z+1)//2 if z%2 else z//2
   assert z==7821397930
   z=m;steps=0
   while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
   row.update(m=m,convergence_verified=z==1,steps=steps);found.append(row)
  candidates.append(row)
# Replay the base trajectory for incoming all-k counterexample extension.
z=251;odd=even=0
for i in range(42):
 if z%2:odd+=1;z=(3*z+1)//2
 else:even+=1;z//=2
assert (z,odd,even)==(2,22,20)
out=dict(independent_lattice_checks=checks,independent_root_extrema_checks=len(roots),extremal_candidates=len(candidates),candidate_status_counts={s:sum(q['status']==s for q in candidates) for s in ['nonintegral','nonpositive','positive_integer']},witnesses=found,base251_path_verified=True)
(D/'verification.json').write_text(json.dumps(out,indent=2),encoding='utf8');(D/'candidate_checks.json').write_text(json.dumps(candidates,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
