from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time
from fractions import Fraction as F
from collections import defaultdict
start=time.monotonic();I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
D=Path('tmp/shared_prefix_counts');seeds=json.loads((I/'exact_compensation_seeds.json').read_text());old=json.loads(Path('tmp/short_source_counts/checks.json').read_text());oldrows={(int(r['n']),int(r['u'])):r for r in old['rows']};rows=[];prefix_checks=0;cones={2:{},3:{}}; horizon_checks=0
for group in seeds['groups']:
 n=int(group['n'])
 if n<2**71:continue
 H=(4*n-2)//3;B=5+F(n,100000*source_count(n));R=0
 while 47*3**R<=32*n:R+=1
 for item in group['sources']:
  p=replay(n,item);u=p['u'];w=item['word'];N=len(w);assert 32*p['Q']<15*u
  E=num=0;lo=n;resolved=None;nodes=[]
  for g,e in enumerate(w[:-1],1):
   num=3*num+2**E;E+=e;q=F(num,3**g)
   lo=max(lo,(2**E*H-num)//3**g+1,(32*q.numerator)//(15*q.denominator)+1)
   M=2**(E+1);res=(2**E-num)*pow(3**g,-1,M)%M;first=lo+(res-lo)%M;count=max(0,(H-first)//M+1)
   assert first<=u<=H and (u-first)%M==0 and count>=1;prefix_checks+=1
   if count==1 and resolved is None:resolved=g;assert first==u
   nodes.append(dict(depth=g,capacity=count,first=str(first),E=E))
  # Short control words may complete before their prefix resolves.
  row=dict(n=str(n),u=str(u),N=N,resolution_depth=resolved,resolution_E=nodes[resolved-1]['E'] if resolved else None,r_min=R,classes={})
  previous=oldrows[n,u]
  for k in [2,3]:
   target=previous['counts'][str(k)]['canonical_survivors'];phase=previous['phase_count']>=k
   if target:
    assert N>=16+2*(k-1)+R
    eligible=[r for r in p['runs'] if r['i']>0 and (r['s'],r['e'])==(2,2) and B<r['q']<p['Q']-B]
    g=eligible[k-1]['i'];assert 3**(N-g)*(u+p['Q'])>n*(u+eligible[k-1]['q']);horizon_checks+=1
   if phase:
    assert resolved is not None
    key=(n,tuple(w[:resolved]));assert key not in cones[k];cones[k][key]=dict(source=str(u),target=target)
   row['classes'][str(k)]=dict(phase_candidate=phase,survivor=target)
  rows.append(row)
# A union of these singleton prefixes covers all completions in its cones,
# not just listed terminal words. Actual deterministic first returns have been replayed.
for k,C in cones.items():
 keys=list(C)
 for i,(n,p) in enumerate(keys):
  for nn,q in keys[i+1:]:
   if n==nn:assert p[:len(q)]!=q and q[:len(p)]!=p
# Independent bounded branching partition tests, all exponents retained up to exact max.
partition_tests=0;height_rejections=0
for n in [101,151,201]:
 H=(4*n-2)//3
 # Direct trajectories grouped by an observed one-transition prefix; no asymptotic cap here.
 groups=defaultdict(list)
 for u in range(n,H+1,2):
  e=((3*u+1)&-(3*u+1)).bit_length()-1;x=(3*u+1)>>e
  if x>H:groups[e].append(u)
 for e,us in groups.items():
  E=e;num=1;M=2**(E+1);res=(2**E-num)*pow(3,-1,M)%M;lo=max(n,(2**E*H-num)//3+1);first=lo+(res-lo)%M;c=max(0,(H-first)//M+1)
  assert c==len(us)
  buckets=defaultdict(list)
  for u in us:
   x=(3*u+1)>>e;ee=((3*x+1)&-(3*x+1)).bit_length()-1;y=(3*x+1)>>ee
   buckets[(ee,'active' if y>H else 'return' if y>=n else 'below')].append(u)
  total=0
  for (ee,kind),vals in buckets.items():
   dd=3+2**e;EE=e+ee;mm=2**(EE+1);rr=(2**EE-dd)*pow(9,-1,mm)%mm
   ll=lo;hh=H
   if kind=='active':ll=max(ll,(2**EE*H-dd)//9+1)
   elif kind=='return':ll=max(ll,-((-(2**EE*n-dd))//9));hh=min(hh,(2**EE*H-dd)//9)
   else:hh=min(hh,(2**EE*n-dd-1)//9)
   ff=ll+(rr-ll)%mm;cc=max(0,(hh-ff)//mm+1);assert cc==len(vals);total+=cc;partition_tests+=1
   if kind!='active':height_rejections+=cc
  assert total==c
result=dict(status='PASS',prefix_checks=prefix_checks,horizon_checks=horizon_checks,partition_tests=partition_tests,small_control_stopped_sources=height_rejections,profiles=len(rows),resolution_depth_range=[min(r['resolution_depth'] for r in rows if r['resolution_depth']),max(r['resolution_depth'] for r in rows if r['resolution_depth'])],cones={str(k):dict(singleton_cones=len(c),surviving_words=sum(x['target'] for x in c.values()),scope='Separate thresholds; all completions inside listed prefix cones only') for k,c in cones.items()},rows=rows,runtime_seconds=time.monotonic()-start,limits='1GiB/120sec',scope='No whole-band high-floor enumeration; unlisted prefix cones remain open.')
(D/'checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True);os._exit(0)

