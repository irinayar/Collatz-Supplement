from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21k');calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return x,''
 opts=[]
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:opts.append((a[0],a[1]+'1'))
 if k:
  a=inv(2*x,k-1,r)
  if a:opts.append((a[0],a[1]+'0'))
 return min(opts) if opts else None
old=json.loads(Path('tmp/larger_bound_audit_21h/k126_target_queries.json').read_text());patterns={q['word']:q for q in old};records=[]
for w,q in patterns.items():
 M=2**(len(w)+1);n0=q['n']-q['lift']*M;x0=q['x']-2*3**q['r']*q['lift']
 for t in range(9):
  n=n0+M*t;x=x0+2*3**q['r']*t
  status='covered_C61' if n%3==2 else 'empty_by_previous_layer' if n%3==0 else 'known_C110' if n%9==4 else 'pending'
  v={'word':w,'n':n,'x':x,'k':q['k'],'r':q['r'],'lift':t,'M':M,'status':status}
  if status=='known_C110':v.update(m=(8*n-5)//9,target_word='110'+w,height_threshold_h=0)
  records.append(v)
for v in records:
 if v['status']=='pending':
  try:a=inv(v['x'],v['k']+1,v['r']+2)
  except Budget:break
  if a:
   m,w=a;h=max(0,(m-v['n'])//v['M']+1);v.update(m=m,target_word=w,height_threshold_h=h,status='new_feasible')
  else:v['status']='empty_layer_exact'
 for_write=json.dumps(records,indent=2);(D/'nine_lift_queries.json').write_text(for_write)
# Independently validate actual target words and certify only the finite examples, not whole progressions.
for v in records:
 if 'm' not in v:continue
 h=v['height_threshold_h'];m=v['m']+8*v['M']*h;n=v['n']+9*v['M']*h;x=v['x']+18*3**v['r']*h;assert 0<m<n
 z=m
 for bit in v['target_word']:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
 assert z==x;path=[m]
 while z!=1 and len(path)<10000:
  # Convergence starts afresh at m, separately from endpoint replay.
  break
 z=m
 while z!=1 and len(path)<10000:z=(3*z+1)//2 if z%2 else z//2;path.append(z)
 assert z==1;v.update(certified_m=m,certified_n=n,convergence_path=path)
(D/'nine_lift_queries.json').write_text(json.dumps(records,indent=2));res={'patterns':len(patterns),'residue_rows':len(records),'nodes':calls,'statuses':{s:sum(q['status']==s for q in records) for s in sorted({q['status'] for q in records})}};(D/'target_results.json').write_text(json.dumps(res,indent=2));(D/'remaining_queries.json').write_text(json.dumps([q for q in records if q['status']=='pending'],indent=2));print(json.dumps(res),flush=True);os._exit(0)
