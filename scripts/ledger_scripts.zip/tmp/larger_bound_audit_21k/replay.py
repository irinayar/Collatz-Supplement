from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
from fractions import Fraction as F
D=Path('tmp/larger_bound_audit_21k');start=time.monotonic();count=0;steps=0
for line in (D/'trajectory_counts.jsonl').open():
 m,L,r=json.loads(line);assert m==17*2**18-1+2*count;u=m;ll=rr=0
 while u!=1:
  if u%2:rr+=1;u=(3*u+1)//2
  else:u//=2
  ll+=1;assert ll<=10000
 assert (ll,rr)==(L,r);count+=1;steps+=ll
 if count%4096==0:assert time.monotonic()-start<42
assert count==131072
res={'all_starts_checked':count,'elementary_steps':steps,'seconds':time.monotonic()-start};(D/'independent_replay.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
