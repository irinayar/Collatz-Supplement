from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
from fractions import Fraction as F
D=Path('tmp/larger_bound_audit_21k');calls=0
@lru_cache(maxsize=50000)
def possible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return(x+1)%3**r==0 and 2**r*(x+1)//3**r-1>0
 y=x
 for ell in range(r+1):
  if possible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
qs=json.loads((D/'nine_lift_queries.json').read_text());witnesses=[]
for q in qs:
 z=q['n']
 for bit in q['word']:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
 assert z==q['x']
 if q['status']=='empty_layer_exact':assert not possible(z,q['k']+1,q['r']+2)
 if q['status']=='known_C110':
  m=q['m'];assert 9*m==8*q['n']-5 and m<q['n']
  p=q['convergence_path'];assert p[0]==m and p[-1]==1
  for a,b in zip(p,p[1:]):assert b==((3*a+1)//2 if a%2 else a//2)
  witnesses.append([q['n'],m,len(p)-1])
# Exact constant in Claude's e<=7 extension, monotonicity already proved symbolically.
cs=[]
for e in range(2,8):
 s=1
 while 3**(s+1)<=2**(s+e):s+=1
 a=3**(s+1);d=2**(s+e);b=3**s*(1+2**e)-d;cs.append([e,s,str(F(b,a-d))])
C=max(F(c[2]) for c in cs);assert C==F(7486249,46075)
threshold=2*(19+8*C)/27;assert 95<threshold<111;assert 1+(19+8*C)/(27*111)<F(3,2)
res={'source_rows_replayed':len(qs),'fresh_empty_checked':42,'independent_states':calls,'certified_known_witnesses':len(witnesses),'witness_examples':witnesses[:3],'Claude_e7_constants':cs,'e7_height_threshold':str(threshold)};(D/'independent_checks.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
