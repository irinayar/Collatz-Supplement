from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,hashlib
D=Path('tmp/residue_precision_compare');tables=json.loads((D/'tables.json').read_text());a=json.loads((D/'p10/results.json').read_text());b=json.loads((D/'p12/results.json').read_text())
proof=json.loads((D/'p10/proof.json').read_text());counts=dict(eligible=0,cut10=0,cut12=0,additional12=0,lost=0,additional_above_five=0)
for z in proof:
 x,r,k=z['x'],z['r'],z['k']
 if r==0 or x%3==0:continue
 p=min(10,r);q=min(12,r);d10=tables[p][x%3**p];d12=tables[q][x%3**q];assert d12>=d10
 c10=d10>k;c12=d12>k;counts['eligible']+=1;counts['cut10']+=c10;counts['cut12']+=c12;counts['additional12']+=c12 and not c10;counts['lost']+=c10 and not c12;counts['additional_above_five']+=c12 and not c10 and k>5
assert a['calls']==b['calls']==22044 and a['attempted_roots']==b['attempted_roots']==44
at=json.loads((D/'p10/attempts.json').read_text());bt=json.loads((D/'p12/attempts.json').read_text());assert [q['index'] for q in at]==[q['index'] for q in bt]
# The generated search sources differ only by precision, output path and reporting.
s10=(D/'p10/check.py').read_text().replace('/p10','/pXX').replace('min(r,10)','min(r,XX)').replace('precision=10','precision=XX')
s12=(D/'p12/check.py').read_text().replace('/p12','/pXX').replace('min(r,12)','min(r,XX)').replace('precision=12','precision=XX');assert s10==s12
out=dict(fixed_baseline_state_counts=counts,common_search_source_verified=True,combined_calls=a['calls']+b['calls'],five_even_checks=[a['fresh_leaf_count'],b['fresh_leaf_count']],reduction_percent=100*(a['fresh_leaf_count']-b['fresh_leaf_count'])/a['fresh_leaf_count'],single_run_seconds=[a['seconds'],b['seconds']],table_build_seconds=json.loads((D/'table_results.json').read_text())['seconds'],table_file_bytes=[Path('tmp/residue_feasibility_44/tables.json').stat().st_size,(D/'tables.json').stat().st_size])
(D/'comparison.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
