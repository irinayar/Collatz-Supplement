from pathlib import Path
p=Path('tmp/residue_feasibility_44/build_tables.py').read_text(encoding='utf-8-sig')
p=p.replace("D=Path('tmp/residue_feasibility_44')","D=Path('tmp/residue_precision_compare')")
p=p.replace('tables=[[0]]','tables=json.loads(Path("tmp/residue_feasibility_44/tables.json").read_text())').replace('range(1,11)','range(11,13)')
p=p.replace("assert cost[a]==min(base,1+cost[2*a%mod],INF);checks+=1","assert cost[a]==min(base,1+cost[2*a%mod],INF);assert cost[a]>=prev[a%(mod//3)];checks+=1")
p=p.replace('p=min(10,q[\'b\'])','p=min(12,q[\'b\'])').replace('precision=10','precision=12').replace('independent_graph_precisions=5','independent_graph_precisions=0')
Path('tmp/residue_precision_compare').mkdir(exist_ok=True);Path('tmp/residue_precision_compare/build_tables.py').write_text(p,encoding='utf8');exec(compile(p,'extend_tables','exec'))
