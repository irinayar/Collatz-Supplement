from pathlib import Path
base=Path('tmp/residue_feasibility_44/check.py').read_text(encoding='utf-8-sig')
for precision in (10,12):
 p=base.replace("D=Path('tmp/residue_feasibility_44')",f"D=Path('tmp/residue_precision_compare/p{precision}')")
 p=p.replace("tables=json.loads((D/'tables.json').read_text());moduli=[3**p for p in range(len(tables))]","""for n in json.loads(Path('tmp/residue_feasibility_44/proof.json').read_text()):old[(n['x'],n['r'],n['k'])]=n
tables=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text());moduli=[3**p for p in range(len(tables))]""")
 p=p.replace('calls-local_start>1000','calls-local_start>500').replace('min(r,10)',f'min(r,{precision})')
 p=p.replace('out=dict(residue_cuts_by_budget=',f'out=dict(precision={precision},per_root_budget=500,residue_cuts_by_budget=')
 d=Path(f'tmp/residue_precision_compare/p{precision}');d.mkdir(exist_ok=True);(d/'check.py').write_text(p,encoding='utf8')
p=Path('tmp/residue_precision_compare/p10/check.py').read_text();exec(compile(p,'matched_p10','exec'))
