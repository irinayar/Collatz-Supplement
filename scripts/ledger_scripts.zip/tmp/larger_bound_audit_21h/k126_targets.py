from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21h');calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return x,''
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:return a[0],a[1]+'1'
 if k:
  a=inv(2*x,k-1,r)
  if a:return a[0],a[1]+'0'
 return None
rows=json.loads(Path('tmp/larger_bound_audit_21g/aperiodic_potential_tests.json').read_text());queries=[];skip=0;seen=set()
for row in rows:
 if row['length']>12:continue
 for lift in range(3):
  n=row['least_start']+lift*row['modulus'];vals=[1,1,1]+sum(([2]+[1]*s for s in row['recovery_lengths']),[])
  if (n,tuple(vals)) in seen:continue
  seen.add((n,tuple(vals)))
  if n%3==2:skip+=1;continue
  x=n;word=''
  for e in vals:
   assert ((3*x+1)&-(3*x+1)).bit_length()-1==e
   x=(3*x+1)//2**e;word+='1'+'0'*(e-1)
  k=word.count('0');r=word.count('1');v={'n':n,'x':x,'k':k,'r':r,'word':word,'lift':lift,'kind':row['kind'],'length':row['length']}
  try:a=inv(x,k,r+1)
  except Budget:v['status']='budget_pending';queries.append(v);break
  if a:
   m,w=a;assert 0<m<n;z=m
   for bit in w:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
   assert z==x;z=m;steps=0
   while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
   assert z==1;v.update(status='certified_witness',m=m,target_word=w,convergence_steps=steps)
  else:v['status']='empty_layer_exact'
  queries.append(v);(D/'k126_target_queries.json').write_text(json.dumps(queries,indent=2))
 else:continue
 break
out={'queries':len(queries),'nodes':calls,'elementary_C61_skipped':skip,'statuses':{s:sum(q['status']==s for q in queries) for s in ['certified_witness','empty_layer_exact','budget_pending']}}
(D/'k126_target_queries.json').write_text(json.dumps(queries,indent=2));(D/'k126_target_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
