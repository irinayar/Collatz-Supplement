from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,zipfile
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21h');calls=0
@lru_cache(maxsize=50000)
def feasible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return (x+1)%3**r==0 and 2**r*(x+1)//3**r-1>0
 y=x
 for ell in range(r+1):
  if feasible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
qs=json.loads((D/'k126_target_queries.json').read_text())
for q in qs:assert q['status']=='empty_layer_exact' and not feasible(q['x'],q['k'],q['r']+1)
checks=0
for w in [[2,1],[2,1,1],[2,1,2,1,1],[2,1,1,2,1],[1,2,1,1,2,1],[2,1,2,1,2,1,1,1]]:
 a=1;b=0;d=1
 for e in w:a,b,d=3*a,3*b+d,d*2**e
 for N in range(1,9):
  A=1;B=0;den=1
  for e in w*N:A,B,den=3*A,3*B+den,den*2**e
  x=((den-B)*pow(A,-1,2*den))%(2*den);y=x
  for e in w*N:
   z=3*y+1;assert (z&-z).bit_length()-1==e;y=z>>e
  q=a-d;assert(q*x+b)%(2*d**N)==0 and x>=-((b-2*d**N)//q);checks+=1
out={'empty_layers':len(qs),'independent_states':calls,'interrupted_motif_cases_exactly_replayed':checks}
(D/'independent_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
