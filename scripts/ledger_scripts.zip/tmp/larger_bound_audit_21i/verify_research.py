from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
from fractions import Fraction as F
import itertools,json
D=Path('tmp/larger_bound_audit_21i');calls=0
@lru_cache(maxsize=50000)
def least(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return 2**r*(x+1)//3**r-1 if (x+1)%3**r==0 else None
 y=x;opts=[]
 for ell in range(r+1):
  a=least(2*y,k-1,r-ell)
  if a is not None and a>0:opts.append(a)
  if y%3!=2:break
  y=(2*y-1)//3
 return min(opts) if opts else None
qs=json.loads((D/'changed_even_queries.json').read_text());completed=[q for q in qs if q['status']!='budget_pending']
for q in completed:
 a=least(q['x'],q['k']+q['dk'],q['r']+q['dr']);assert a==q.get('m')
def cylinder(w):
 a=1;b=0;d=1
 for e in w:a,b,d=3*a,3*b+d,d*2**e
 return ((d-b)*pow(a,-1,2*d))%(2*d)
def replay(w,x):
 y=x;g=F(1)
 for e in w:
  z=3*y+1;assert (z&-z).bit_length()-1==e;g*=F(z,3*y);y=z>>e
 return y,g
for e in range(2,11):
 for s in range(1,25):
  w=[e]+[1]*s;y=cylinder(w);z,g=replay(w,y)
  a=3**(s+1);d=2**(s+e);b=3**s*(1+2**e)-d;delta=3**s*(2**e-20)+6*d
  assert b+7*(d-a)==delta and (delta<=0)==(e==2 or e==3 and s>=4 or e==4 and s>=8)
  assert g*(1+F(7,z))-(1+F(7,y))==F(delta,a*y)
choices=[(2,1),(2,2),(3,4),(3,5),(4,8),(4,9)];checks=0
for seq in itertools.product(choices,repeat=2):
 w=[1,1,1]+sum(([e]+[1]*s for e,s in seq),[]);x=cylinder(w);y=x;g=F(1)
 for e in w:
  z=3*y+1;assert (z&-z).bit_length()-1==e;g*=F(z,3*y);y=z>>e;assert g<1+F(25,9*x)<=F(32,27);checks+=1
old=json.loads(Path('tmp/larger_bound_audit_21h/k126_target_queries.json').read_text());done={(q['n'],q['word'],q['dk'],q['dr']) for q in completed};remaining=[];seen=set()
for row in old:
 for dk,dr in [(-1,0),(1,1)]:
  if dk==-1 and row['word'] in seen:continue
  if dk==-1:seen.add(row['word'])
  if (row['n'],row['word'],dk,dr) not in done:remaining.append(dict(row,dk=dk,dr=dr,status='pending'))
(D/'remaining_queries.json').write_text(json.dumps(remaining,indent=2));out={'independent_completed_queries':len(completed),'independent_states':calls,'remaining_queries':len(remaining),'defect_parameter_pairs':216,'two_block_cylinders':36,'exact_prefix_checks':checks};(D/'independent_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
