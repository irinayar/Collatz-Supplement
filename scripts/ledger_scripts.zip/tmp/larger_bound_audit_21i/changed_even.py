from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json
from functools import lru_cache
D=Path('tmp/larger_bound_audit_21i');calls=0
class Budget(Exception):pass
@lru_cache(maxsize=50000)
def inv(x,k,r):
 global calls
 calls+=1
 if calls>50000:raise Budget()
 if k==r==0:return x,''
 opts=[]
 if r and x%3==2:
  a=inv((2*x-1)//3,k,r-1)
  if a:opts.append((a[0],a[1]+'1'))
 if k:
  a=inv(2*x,k-1,r)
  if a:opts.append((a[0],a[1]+'0'))
 return min(opts) if opts else None
rows=json.loads(Path('tmp/larger_bound_audit_21h/k126_target_queries.json').read_text());qs=[];seen=set();stopped=False
for row in rows:
 for dk,dr in [(-1,0),(1,1)]:
  if dk==-1 and row['word'] in seen:continue
  if dk==-1:seen.add(row['word'])
  q={k:row[k] for k in ['n','x','k','r','word','lift','kind','length']};q.update(dk=dk,dr=dr)
  try:a=inv(q['x'],q['k']+dk,q['r']+dr)
  except Budget:q['status']='budget_pending';qs.append(q);stopped=True;break
  if a:
   m,w=a;z=m
   for bit in w:assert z%2==int(bit);z=(3*z+1)//2 if bit=='1' else z//2
   assert z==q['x'];q.update(m=m,target_word=w,status='witness' if m<q['n'] else 'minimum_not_smaller')
   if m<q['n']:
    z=m;steps=0
    while z!=1 and steps<10000:z=(3*z+1)//2 if z%2 else z//2;steps+=1
    assert z==1;q['convergence_steps']=steps
  else:q['status']='empty_layer_exact'
  qs.append(q);(D/'changed_even_queries.json').write_text(json.dumps(qs,indent=2))
 if stopped:break
out={'queries':len(qs),'nodes':calls,'pending':stopped,'statuses':{s:sum(q['status']==s for q in qs) for s in ['witness','minimum_not_smaller','empty_layer_exact','budget_pending']}}
(D/'changed_even_queries.json').write_text(json.dumps(qs,indent=2));(D/'changed_even_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True);os._exit(0)
