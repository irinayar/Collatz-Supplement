from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
import json,sys,time
from fractions import Fraction as F
src=Path('tmp/unresolved_phase_caps/check.py').read_text();exec(src[src.index('from fractions import'):src.index("I=Path('tmp/compensation")])
I=Path('tmp/compensation_packet_audit/input');sys.path.insert(0,str(I.resolve()))
from exact_compensation_profile_support import replay,source_count,actual_core
start=time.monotonic();old=json.loads(Path('tmp/singleton_charge_bounds/checks.json').read_text());wanted={(int(r['n']),int(r['u'])) for r in old['rows']};rows=[];checks=positive=better=0;count_tests=0
cost=lambda a:F(1,a)+F(2,3*a+1)
def constants(n):
 H=(4*n-2)//3;a0=H+1+(11-H-1)%16;C=F(n-1,n+1)+F(9*(a0+5),5*(9*a0+5));gamma=C*F(5*(3*a0+1),9*(5*a0+1));A=2**(64*n.bit_length())-1;amax=A-(A-11)%16
 return gamma,{k:sum((cost(amax-16*j) for j in range(k)),F(0)) for k in [2,3]}
for group in json.loads((I/'exact_compensation_seeds.json').read_text())['groups']:
 n=int(group['n'])
 for item in group['sources']:
  u=int(item['u'])
  if (n,u) not in wanted:continue
  p=replay(n,item);P=source_count(n);B=5+F(n,100000*P);selected=[r for j,r in enumerate(p['runs']) if j in actual_core(p,P) and (r['s'],r['e'])==(2,2)];gamma,beta=constants(n);samples=[]
  for r in p['runs']:
   d=r['i'];q=r['q'];cap,meta=caps(n,u,p['odd'][:d],q);b=F(meta['b']);future=[rr for rr in selected if rr['i']>=d];charge=sum((rr['psi'] for rr in future),F(0));paircost=sum((cost(rr['a']) for rr in future),F(0));bound=gamma*b;v=potential(n,u,B,q,cap)
   assert paircost<=b and charge<=gamma*paircost<=bound;checks+=1
   if charge>0:positive+=1;better+=bound<v
   for k in [2,3]:
    if len(future)>=k:assert beta[k]<=paircost<=b;count_tests+=1
   if d==next(rr['i'] for rr in p['runs'] if rr['i']>=next(x['resolution'] for x in old['rows'] if int(x['n'])==n and int(x['u'])==u)):
    samples.append(dict(depth=d,new_bound=str(bound),old_phase_bound=str(v),ratio=float(bound/v) if v else None,positive_potential=cap-q>B,k2_excluded=b<beta[2],k3_excluded=b<beta[3]))
  rows.append(dict(n=str(n),u=str(u),samples=samples))
f=json.loads(Path('tmp/unresolved_phase_caps/checks.json').read_text())['new_unresolved'];n=int(f['n']);u=int(f['u']);b=F(f['checkpoints'][-1]['b']);gamma,beta=constants(n);new=gamma*b;v=F(f['potential']);assert new<v
# Exact local ratio checks, without high-floor aggregate assumptions.
for a in range(11,3212,16):
 delta=F(5,9*a);assert delta/cost(a)==F(5*(3*a+1),9*(5*a+1));assert cost(a+16)<cost(a)
result=dict(status='PASS',charge_checks=checks,positive_charge_cases=positive,improved_vs_K188_phase_in_positive_cases=better,occurrence_necessity_checks=count_tests,rows=rows,fresh=dict(new_bound=str(new),old_phase_bound=str(v),ratio=float(new/v),k2_excluded=b<beta[2],k3_excluded=b<beta[3],checkpoint_depth=256,positive_potential=F(f['checkpoints'][-1]['cap'])-F(f['q'])>F(f['B'])),seconds=time.monotonic()-start,scope='Bounds on selected R charge; no upper bound on total number of positive-potential singleton sources.')
Path('tmp/occurrence_budget/checks.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['rows','fresh']}));print(json.dumps({k:v for k,v in result['fresh'].items() if k not in ['new_bound','old_phase_bound']}),flush=True);os._exit(0)
