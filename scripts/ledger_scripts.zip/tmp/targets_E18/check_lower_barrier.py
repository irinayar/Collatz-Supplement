from pathlib import Path
import json
D=Path(__file__).parent;checks=zero=0
for n in list(range(1,1001))+[4064460795,18839651253368551]:
 x=n;A=0;seen={x}
 for N in range(1,10001):
  bit=x%2;A+=bit;x=(3*x+1)//2 if bit else x//2
  if A:assert 3**6*2**(6*N)<=3**(6*A)*(4*n)**6*(2*A-1);checks+=1
  else:assert 2**N<=n;zero+=1
  if x in seen:break
  seen.add(x)
(D/'lower_barrier_checks.json').write_text(json.dumps({'starts':1002,'positive_odd_count_tests':checks,'zero_odd_count_tests':zero,'stop':'first repeated output; preceding input states distinct'},indent=2));print(checks,zero)
