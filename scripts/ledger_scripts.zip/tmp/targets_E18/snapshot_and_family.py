from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,getcontext
import json,math
D=Path(__file__).parent;O=D.parents[1];getcontext().prec=45
old=json.loads((O/'tmp/targets_E16/counting_inventory_updated.json').read_text());cov=json.loads((D/'independent_density.json').read_text());fs=json.loads((D/'candidate_new_families.json').read_text())
old['scope']='Named v6 E16 ledger augmented with finite C109 E18 families; exact natural density of conditional rules; C110 infinite-family tail not counted.'
old['parent_inventory']='tmp/targets_E16/counting_inventory_updated.json'
for i,f in enumerate(fs,1):old['finite_ledger'].append({'id':f'C109-{i:02d}','residue':f['n0']%f['P'],'modulus':f['P'],'certificate':f})
for T,row in cov.items():
 total=F(row['combined']);gain=F(row['net']);row['percent']=str(Decimal(total.numerator)*100/Decimal(total.denominator));row['percentage_point_gain']=str(Decimal(gain.numerator)*100/Decimal(gain.denominator));old['expected'][T]={'combined':str(total),'baseline':row['baseline'],'increment':str(gain),'percent':row['percent']}
(D/'coverage_update.json').write_text(json.dumps(cov,indent=2));(D/'counting_inventory_updated.json').write_text(json.dumps(old,indent=2))
# Explicit unbounded target family: 1^r (01)^s 0.
rows=[];direct=0;pairchecks=0
for s in range(101):
 r=2
 while 3**(r+s)<=2**(r+2*s+1):r+=1
 q=3**(r+s);P=2**(r+2*s+1);w='1'*r+'01'*s+'0';n0=(1-3**(s+1)*pow(2**(2*s+1),-1,q))%q
 m0=(P*(n0-1)+2**r*3**(s+1))//q-1
 assert 0<m0<n0 and n0%3==1
 v=n0-1;val=0
 while v%3==0:v//=3;val+=1
 assert val==s+1
 for t in [0,1,2,17,1000]:
  n=n0+q*t;m=m0+P*t;x=m
  for b in w:assert x%2==int(b);x=(3*x+1)//2 if x%2 else x//2
  assert x==n and 0<m<n;direct+=1
 for prev in rows:
  g=math.gcd(q,prev['P']);assert (n0-prev['n0'])%g;pairchecks+=1
 rows.append(dict(s=s,r=r,source='',target=w,n0=n0,P=q,m0=m0,Q=P))
partial=sum((F(1,f['P']) for f in rows),F());nexts=101;r=2
while 3**(r+nexts)<=2**(r+2*nexts+1):r+=1
tail=F(3,2*3**(r+nexts))
# Check membership in the whole finite E18 ledger (separate from stopping/C08/C85).
for f in rows[:10]:
 f['contained_in_E18_finite_ledger']=any(f['P']%z['modulus']==0 and f['n0']%z['modulus']==z['residue']%z['modulus'] for z in old['finite_ledger'])
result=dict(rows=rows,exact_path_checks=direct,disjoint_pair_checks=pairchecks,density_lower=str(partial),density_upper=str(partial+tail),scope='Disjoint C110 family own density, not a marginal increment over any ledger; first101 s-values tested, theorem covers all s>=0.')
(D/'infinite_family_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(cov,indent=2));print('Infinite-family examples:',json.dumps(rows[:7],indent=2))
