from pathlib import Path
from fractions import Fraction
import json,hashlib
D=Path(__file__).parent;O=D.parents[1]
ns={'__file__':str(D/'account_total.py')};exec((D/'account_total.py').read_text().split('results={}')[0],ns)
x=json.loads((D/'counting_inventory_updated.json').read_text());terms={}
for v in x['finite_ledger']:
 z=(v['residue']%v['modulus'],v['modulus']);delta={z:1}
 for w,c in terms.items():
  hit=ns['crt'](z,w)
  if hit:delta[hit]=delta.get(hit,0)-c
 for w,c in delta.items():terms[w]=terms.get(w,0)+c
 terms={w:c for w,c in terms.items() if c}
ns['terms']=terms;out={}
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear()
 ans=1-Fraction(ns['tail'](0,0),2**T)
 ans+=sum((c*ns['survive'](z) for z,c in terms.items()),Fraction())
 ans+=sum((ns['residual'](ns['c08'](k)) for k in range(1,100)),Fraction())+ns['residual']((2**100-1,2**100))/2
 ans+=sum((ns['residual'](z) for z in ns['c85']),Fraction())
 assert ans==Fraction(x['expected'][str(T)]['combined']);out[str(T)]=str(ans)
(D/'snapshot_verification.json').write_text(json.dumps(out,indent=2));print('Updated machine-readable inventory reproduces both exact totals.')
