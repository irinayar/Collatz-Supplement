from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json
D=Path(__file__).parent;O=D.parents[1];inv=json.loads((D/'counting_inventory_updated.json').read_text());answer=json.loads((D/'infinite_family_accounting.json').read_text());binary=[]
for z in inv['finite_ledger']:
 m=z['modulus'];r=z['residue'];p2=m&-m;p3=m//p2;t=p3
 while t%3==0:t//=3
 assert t==1
 if r%p3==1%p3:binary.append((r%p2,p2))
certs=json.loads((O/inv['C85']['file']).read_text())['certificates'];binary +=[(z['n']%(2**27),2**27) for z in certs if z['meeting'] is not None and z['descent'] is None]
keep=[]
for r,m in sorted(set(binary),key=lambda z:z[1]):
 if not any(m>=q and r%q==a for a,q in keep):keep.append((r,m))
# Binary cylinders are either nested or disjoint, so no general CRT/IE is used.
def inter(x,y):
 a,m=x;b,q=y
 if m<q:return y if b%m==a else None
 return x if a%q==b else None
out={}
for T in [32,100]:
 @lru_cache(None)
 def measure(z):
  r,m=z;L=m.bit_length()-1;x=r;a=0
  for i in range(1,min(L,T)+1):
   bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
   if 3**a<2**i:return F()
  if L>=T:return F(1,m)
  dp={a:1}
  for i in range(L+1,T+1):
   nxt={}
   for aa,count in dp.items():
    for bit in [0,1]:
     if 3**(aa+bit)>=2**i:nxt[aa+bit]=nxt.get(aa+bit,0)+count
   dp=nxt
  return F(sum(dp.values()),2**T)
 def remaining(z):return measure(z)-sum((measure(hit) for w in keep if (hit:=inter(z,w))),F())
 theta=remaining((0,1))
 for k in range(1,100):
  mod=2**(k+2);r=(-(3**k-2**k)*pow(3**k,-1,mod))%mod;theta-=remaining((r,mod))
 theta-=remaining((2**100-1,2**100))/2
 assert theta==F(answer['depths'][str(T)]['theta'])
 lo=F(answer['depths'][str(T)]['combined_lower'])*100;hi=F(answer['depths'][str(T)]['combined_upper'])*100
 roundedlo=(lo*10**10+F(1,2)).numerator//(lo*10**10+F(1,2)).denominator
 roundedhi=(hi*10**10+F(1,2)).numerator//(hi*10**10+F(1,2)).denominator
 assert roundedlo==roundedhi
 out[str(T)]={'theta':str(theta),'binary_disjoint_cylinders':len(keep),'certified_rounded_percent_10dp':f'{roundedlo//10**10}.{roundedlo%10**10:010d}'}
 print(T,out[str(T)],flush=True)
(D/'independent_binary_tail.json').write_text(json.dumps(out,indent=2))
inv['scope']='E18 named finite rule union plus C110 infinite disjoint alternating-tail family; conditional-rule natural density expressed by a convergent exact series with certified rational bounds.'
inv['schema_version']=3
inv['C110']={'word':'1^r_s (01)^s 0','s_min':0,'r_s':'least integer r>=2 with 3^(r+s)>2^(r+2*s+1)','modulus':'3^(r_s+s)','residue':'1-3^(s+1)*inverse(2^(2*s+1)) modulo modulus','uniform_tail_start':answer['uniform_tail_starts_s'],'accounting_file':'tmp/targets_E18/infinite_family_accounting.json'}
inv['expected']={T:dict(combined_lower=row['combined_lower'],combined_upper=row['combined_upper'],rounded_percent_10dp=out[T]['certified_rounded_percent_10dp'],expression='E18 baseline + head_gain + theta * sum_(s>=20)3^(-r_s-s)') for T,row in answer['depths'].items()}
(D/'counting_inventory_with_C110.json').write_text(json.dumps(inv,indent=2))
