from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import json
D=Path(__file__).parent
ns={'__file__':str(D/'account_total.py')};exec((D/'account_total.py').read_text().split('results={}')[0],ns)
@lru_cache(None)
def forward(L,a,T):
 counts={a:1}
 for i in range(L+1,T+1):
  nxt={}
  for b,c in counts.items():
   for v in [b,b+1]:
    if 3**v>=2**i:nxt[v]=nxt.get(v,0)+c
  counts=nxt
 return sum(counts.values())
expected=json.loads((D/'total_increment.json').read_text());old=ns['inv'];results={}
for T in [32,100]:
 @lru_cache(None)
 def measure(z):
  r,m=z;L=(m&-m).bit_length()-1;a=0;x=r
  for i in range(1,min(L,T)+1):
   a+=x%2;x=(3*x+1)//2 if x%2 else x//2
   if 3**a<2**i:return Fraction()
  if L>=T:return Fraction(1,m)
  return Fraction(forward(L,a,T),m*2**(T-L))
 ns['T']=T;ns['survive']=measure
 delta=ns['gain'](ns['remaining'],measure);assert delta==expected['gains'][str(T)]
 finite=sum((c*measure(z) for z,c in ns['terms'].items()),Fraction())
 inf=sum((ns['residual'](ns['c08'](k)) for k in range(1,100)),Fraction())+ns['residual']((2**100-1,2**100))/2
 extra=sum((ns['residual'](z) for z in ns['c85']),Fraction())
 baseline=1-Fraction(forward(0,0,T),2**T)+finite+inf+extra
 assert baseline==Fraction(old['expected'][str(T)]['combined'])
 results[str(T)]=dict(baseline=str(baseline),net=delta['net'],combined=str(baseline+Fraction(delta['net'])))
(D/'independent_density.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
