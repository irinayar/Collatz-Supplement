from pathlib import Path
from fractions import Fraction
import json,runpy,contextlib,io
D=Path(__file__).parent;O=D.parents[1]
def coeff(w):
 a=U=0
 for i,c in enumerate(w):
  if c=='1':a+=1;U=3*U+2**i
 return a,U
fs={}
for j in [3,4,5]:
 dat=json.loads((D/f'j{j}.json').read_text())
 for z in dat['levels']['18']:
  if z['word']=='I0':continue
  u='1'*j;v=z['word'];original=v;c=0
  while u and v and u[-1]==v[-1]:u=u[:-1];v=v[:-1];c+=1
  k=z['r']+max(0,(dat['K']-z['r']+z['mod']-1)//z['mod'])*z['mod'];n=2**j*k-1
  a,U=coeff(u);b,V=coeff(v);L=len(u);ell=len(v)
  P=2**L*3**max(b-a,0);Q=2**ell*3**max(a-b,0)
  assert P>Q
  m=Fraction(2**ell*(3**a*n+U)-2**L*V,2**L*3**b);assert m.denominator==1;m=int(m)
  shift=n//P;n-=shift*P;m-=shift*Q
  shift=max(0,(-n)//P+1,(-m)//Q+1,(m-n)//(P-Q)+1)
  n+=shift*P;m+=shift*Q
  f=dict(original_j=j,original_target=original,original_L=len(original),cancelled=c,source=u,target=v,n0=n,P=P,m0=m,Q=Q)
  key=(n%P,P)
  if key not in fs or len(v)<len(fs[key]['target']):fs[key]=f
out=sorted(fs.values(),key=lambda f:(f['P'],f['n0']))
(D/'cancelled_families.json').write_text(json.dumps({'families':out},indent=2))
old=json.loads((O/'tmp/targets_E16/counting_inventory_updated.json').read_text());pairs={(f['residue']%f['modulus'],f['modulus']) for f in old['finite_ledger']}
fresh=[f for f in out if not any(f['P']%p==0 and f['n0']%p==r for r,p in pairs)]
(D/'candidate_new_families.json').write_text(json.dumps(fresh,indent=2));print('All normalized',len(out),'not contained in a prior finite class',len(fresh))
# Replay the incoming experiment without its hard-coded /mnt/data output.
ns=runpy.run_path(str(D/'incoming/canonical_residue_experiment.py'))
with contextlib.redirect_stdout(io.StringIO()):res=ns['run']()
expected=json.loads((D/'incoming/Collatz_Canonical_Residue_Experiment_Results_2026-11-19.json').read_text());assert res==expected
ns2=runpy.run_path(str(D/'incoming/verify_canonical_residue.py'));checks=ns2['verify']()
(D/'incoming_replay.json').write_text(json.dumps({'exact_result_match':True,'direct_checks':checks,'result':res},indent=2));print('Incoming exact match, direct checks',checks)
