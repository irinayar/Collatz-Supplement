from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from decimal import Decimal,getcontext
import json
D=Path(__file__).parent;O=D.parents[1];getcontext().prec=60
# Instantiate the exact accounting kernel against E18, not the v6 baseline.
s=(D/'account_total.py').read_text().split('results={}')[0].replace('tmp/targets_E16/counting_inventory_updated.json','tmp/targets_E18/counting_inventory_updated.json')
ns={'__file__':str(D/'account_total.py')};exec(s,ns)
inv=ns['inv']
def v3(x):
 a=0
 while x%3==0:a+=1;x//=3
 return a
B=max(v3(z['modulus']) for z in inv['finite_ledger']);S0=B-1
rows=json.loads((D/'infinite_family_checks.json').read_text())['rows'];assert S0<100
out={'max_finite_ternary_precision':B,'uniform_tail_starts_s':S0,'depths':{}}
# Independent forward DP for binary stopping survival.
@lru_cache(None)
def forward(L,a,T):
 counts={a:1}
 for i in range(L+1,T+1):
  nxt={}
  for k,c in counts.items():
   for b in [0,1]:
    if 3**(k+b)>=2**i:nxt[k+b]=nxt.get(k+b,0)+c
  counts=nxt
 return sum(counts.values())
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear()
 values=[]
 for f in rows[:S0+3]:values.append(F(ns['gain']([(f['n0'],f['P'])],ns['residual'])['net']))
 theta=F(ns['gain']([(1,3**B)],ns['residual'])['net'])*3**B
 assert all(values[s]*rows[s]['P']==theta for s in range(S0,S0+3))
 head=sum(values[:S0],F());ser=sum((F(1,f['P']) for f in rows[S0:]),F());nxt=101;r=2
 while 3**(r+nxt)<=2**(r+2*nxt+1):r+=1
 err=F(3,2*3**(r+nxt));gainlo=head+theta*ser;gainhi=gainlo+theta*err
 @lru_cache(None)
 def measure(z):
  r,m=z;L=(m&-m).bit_length()-1;x=r;a=0
  for i in range(1,min(L,T)+1):
   bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
   if 3**a<2**i:return F()
  return F(1,m) if L>=T else F(forward(L,a,T),m*2**(T-L))
 original=ns['survive'];ns['survive']=measure
 independent=[]
 for f in rows[:S0+1]:independent.append(F(ns['gain']([(f['n0'],f['P'])],ns['residual'])['net']))
 independent_theta=F(ns['gain']([(1,3**B)],ns['residual'])['net'])*3**B
 assert independent==values[:S0+1] and independent_theta==theta
 ns['survive']=original
 base=F(inv['expected'][str(T)]['combined']);pct=lambda z:str(Decimal(z.numerator)*100/Decimal(z.denominator))
 out['depths'][str(T)]={'individual_head_marginals':[str(x) for x in values[:S0]],'theta':str(theta),'head_gain':str(head),'tail_series_lower':str(ser),'tail_series_upper':str(ser+err),'increment_lower':str(gainlo),'increment_upper':str(gainhi),'combined_lower':str(base+gainlo),'combined_upper':str(base+gainhi),'percent_lower':pct(base+gainlo),'percent_upper':pct(base+gainhi),'percentage_point_gain_lower':pct(gainlo),'independent_forward_DP_match':True}
 print(T,'B',B,'theta',theta,'percent',pct(base+gainlo),flush=True)
(D/'infinite_family_accounting.json').write_text(json.dumps(out,indent=2))
