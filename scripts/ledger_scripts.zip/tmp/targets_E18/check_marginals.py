from pathlib import Path
from fractions import Fraction as F
import json
D=Path(__file__).parent;ns={'__file__':str(D/'account_total.py')};exec((D/'account_total.py').read_text().split('results={}')[0],ns)
fs=json.loads((D/'candidate_new_families.json').read_text());out=[]
for f in fs:
 row={'family':f,'marginal_against_v6':{}}
 for T in [32,100]:
  ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear()
  row['marginal_against_v6'][str(T)]=ns['gain']([(f['n0']%f['P'],f['P'])],ns['residual'])['net']
 out.append(row)
(D/'individual_marginals.json').write_text(json.dumps(out,indent=2))
print('Individual positive marginal counts',{T:sum(F(x['marginal_against_v6'][str(T)])>0 for x in out) for T in [32,100]})
allfs=json.loads((D/'cancelled_families.json').read_text())['families'];hits={str(n):[f for f in allfs if n>=f['n0'] and (n-f['n0'])%f['P']==0] for n in [4064460795,18839651253368551]};(D/'exact_start_membership.json').write_text(json.dumps(hits,indent=2));print('Exact-start hits', {k:len(v) for k,v in hits.items()})
# Additional independent theorem tests for nonminimal r, not just r_s.
checks=0
for s in range(31):
 r0=2
 while 3**(r0+s)<=2**(r0+2*s+1):r0+=1
 for r in range(r0,r0+6):
  q=3**(r+s);P=2**(r+2*s+1);rho=(1-3**(s+1)*pow(2**(2*s+1),-1,q))%q
  for t in [0,1,100]:
   n=rho+q*t;num=P*(n-1)+2**r*3**(s+1);assert num%q==0;m=num//q-1;assert 0<m<n
   x=m
   for b in '1'*r+'01'*s+'0':assert x%2==int(b);x=(3*x+1)//2 if x%2 else x//2
   assert x==n;checks+=1
(D/'general_r_checks.json').write_text(json.dumps({'checks':checks,'s_range':[0,30],'r_offsets':[0,5],'parameters':[0,1,100]},indent=2));print('General-r exact checks',checks)
