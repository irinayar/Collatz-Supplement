from pathlib import Path
from fractions import Fraction as F
import json,runpy,contextlib,io
D=Path(__file__).parent
s=(D/'account_total.py').read_text().split('results={}')[0].replace('tmp/targets_E16/counting_inventory_updated.json','tmp/targets_E18/counting_inventory_updated.json');ns={'__file__':str(D/'account_total.py')};exec(s,ns)
res=json.loads((D/'infinite_family_accounting.json').read_text());rows=json.loads((D/'infinite_family_checks.json').read_text())['rows'][:res['uniform_tail_starts_s']];left=[]
for f in rows:
 nodes=[(f['n0'],f['P'])]
 for w in ns['base']:nodes=[v for z in nodes for v in ns['subtract'](z,w)]
 left+=nodes
out={}
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear();got=ns['gain'](left,ns['survive']);assert F(got['net'])==F(res['depths'][str(T)]['head_gain']);out[str(T)]=got
(D/'independent_head_subtraction.json').write_text(json.dumps({'remaining_cylinders':len(left),'results':out},indent=2));print('Independent disjoint head subtraction passed',len(left))
buf=io.StringIO()
with contextlib.redirect_stdout(buf):runpy.run_path(str(D/'incoming/hybrid/check.py'))
(D/'hybrid_replay.txt').write_text(buf.getvalue());print(buf.getvalue())
# Independent small rational-anchor checks, including negative numerators.
checks=0
for q in [1,3,5,17]:
 for k0 in range(-50,51):
  xs=[k0]
  for j in range(50):
   k=xs[-1];xs.append((3*k+q)//2 if k%2 else k//2)
   assert 2*(abs(xs[-1])+q)<=3*(abs(k)+q)
  for i in range(25):
   for h in range(i+1,25):
    L=0
    while L<25 and xs[i+L]%2==xs[h+L]%2:L+=1
    assert (xs[i]-xs[h])%2**L==0
    if xs[i]!=xs[h]:assert abs(xs[i]-xs[h])>=2**L
    checks+=1
(D/'rational_anchor_checks.json').write_text(json.dumps({'rational_orbits':404,'pair_checks':checks,'steps':50,'q_values':[1,3,5,17]},indent=2));print('Rational-anchor pairs',checks)
