from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
from functools import lru_cache
from fractions import Fraction as F
import json
D=Path('tmp/larger_bound_audit_21d');calls=0
@lru_cache(maxsize=50000)
def feasible(x,k,r):
 global calls
 calls+=1;assert calls<=50000
 if k==0:return (x+1)%3**r==0 and (2**r*(x+1)//3**r-1)>0
 y=x
 for ell in range(r+1):
  if feasible(2*y,k-1,r-ell):return True
  if y%3!=2:break
  y=(2*y-1)//3
 return False
queries=json.loads((D/'different_even_queries.json').read_text())
for v in queries:
 assert v['status']=='empty_layer_exact' and '00' not in v['source_word']
 assert not feasible(v['x'],v['k']+v['dk'],v['r']+v['dr'])

(D/'independent_different_even.json').write_text(json.dumps({'queries':len(queries),'recurrence_states':calls,'all_empty_confirmed':True},indent=2));print('confirmed',len(queries),'empty queries in',calls,'states',flush=True);os._exit(0)

