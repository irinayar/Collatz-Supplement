from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
O=Path.cwd();D=O/'tmp/k12_bridge';start=time.time()
def params(n):
 R=n.bit_length()-1
 for r in range(2,R+1):
  s=0
  while 3**(r+s)>2**(r+2*s+1):
   q=3**(r+s);p0=2**(r+2*s+1);u=q+p0-2**r*3**(s+1);k=0
   while q>p0*2**k:
    yield r,s,k,q,p0*2**k,u;k+=1
   s+=1
def H(n):
 R=n.bit_length()-1;return (3**R*n-2**R)//2**(R+1)
controls=0
for n in range(3,65):
 for r,s,k,q,p,u in params(n):
  for m in range(1,n):
   if (q*m+u)%p:continue
   x=(q*m+u)//p;assert x<=H(n);y=m
   for bit in '1'*r+'01'*s+'0'*(k+1):
    assert y%2==int(bit);y=(3*y+1)//2 if y%2 else y//2
   assert y==x;controls+=1
rows=[]
for n,x in [(4064460795,7821397930),(18839651253368551,27937390841126308)]:
 triples=list(params(n));hits=[];shift=0
 while 4**shift*(3*x+1)<=3*H(n)+1:
  y=(4**shift*(3*x+1)-1)//3
  for r,s,k,q,p,u in triples:
   if (p*y-u)%q:continue
   m=(p*y-u)//q
   if 0<m<n:
    z=m
    for bit in '1'*r+'01'*s+'0'*(k+1):
     assert z%2==int(bit);z=(3*z+1)//2 if z%2 else z//2
    assert z==y;hits.append({'r':r,'s':s,'k':k,'shift':shift,'origin':m,'target':y})
  shift+=1
 rows.append({'n':n,'saved_endpoint':x,'R':n.bit_length()-1,'H':H(n),'parameter_triples':len(triples),'nonnegative_shifts_examined':shift,'hits':hits})
res={'theorem':'H(n)=floor((3^R*n-2^R)/2^(R+1)),R=floorlog2n. All smaller origins in growth-certified zero-tail family terminate at x<=H. Shift t requires4^t(3x+1)<=3H+1.','small_path_controls':controls,'saved_endpoints':rows,'elapsed_seconds':time.time()-start}
(D/'fixed_origin.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True);os._exit(0)
