from pathlib import Path
O=Path.cwd();src=(O/'tmp/k6_tail/audit.py').read_text().replace('family.__defaults__=(6,)','family.__defaults__=(12,)')
a=src.index('f0=family(0)');b=src.index('result=',a)
src=src[:a]+'''f0=family(0);assert f0['rho']%9==4
rows=[family(s) for s in range(101)]
assert all(f['rho']%9==1 for f in rows[1:])
assert rows[1]['rho']%81==46 and rows[2]['rho']%81==64 and all(f['rho']%81==37 for f in rows[3:])
assert (32768*rows[1]['rho']+1)%19683==0
assert ((64*rows[1]['rho'])-(1-27*pow(32,-1,19683)))%19683!=0
assert (64*rows[2]['rho'])%81==46 and all((64*f['rho'])%81==19 for f in rows[3:])
'''+src[b:]
src=src.replace("if (64*z['residue']-1)%p3==0:","if (4096*z['residue']-1)%p3==0:").replace('rho=pow(64,-1,q)','rho=pow(4096,-1,q)').replace('tmp/k2_tail/coverage_extension.json','tmp/k8_tail/coverage_extension.json').replace('increment_vs_C113_ledger','increment_vs_C115_ledger')
(O/'tmp/k12_bridge/audit.py').write_text(src)
