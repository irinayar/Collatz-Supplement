from pathlib import Path
here=Path(__file__).parent
# Reuse resource guard and accounting definitions only, not the previous completed calculation.
exec((here.parent/'k2_overlap/audit.py').read_text().split('rows=[family')[0])
# out/root now refer to this script's directory and project root.
family.__defaults__=(12,)
B=max(next(a for a in range(100) if z['modulus']//(z['modulus']&-z['modulus'])==3**a) for z in ns['inv']['finite_ledger']);S=B-1
assert B==21 and S==20
f0=family(0);assert f0['rho']%9==4
rows=[family(s) for s in range(101)]
assert all(f['rho']%9==1 for f in rows[1:])
assert rows[1]['rho']%81==46 and rows[2]['rho']%81==64 and all(f['rho']%81==37 for f in rows[3:])
assert (32768*rows[1]['rho']+1)%19683==0
assert ((64*rows[1]['rho'])-(1-27*pow(32,-1,19683)))%19683!=0
assert (64*rows[2]['rho'])%81==46 and all((64*f['rho'])%81==19 for f in rows[3:])
result={'B':B,'tail_start_s':S,'s0_C110_containment':[4,9],'families':rows,'depths':{}}
# Independent binary projection of finite ledger on the limiting ternary class 4n=1.
binary=[]
for z in ns['inv']['finite_ledger']:
 mod=z['modulus'];p2=mod&-mod;p3=mod//p2
 if (4096*z['residue']-1)%p3==0:binary.append((z['residue']%p2,p2))
binary+=ns['c85'];keep=[]
for a,m in sorted(set(binary),key=lambda z:z[1]):
 if not any(m%q==0 and a%q==b for b,q in keep):keep.append((a,m))
def intersect(z,w):
 a,m=z;b,q=w
 if m<q:return w if b%m==a else None
 return z if a%q==b else None
old=json.loads((root/'tmp/k2_overlap/results.json').read_text());base={'expected':json.loads((root/'tmp/k8_tail/coverage_extension.json').read_text())['depths']}
for T in [32,100]:
 ns['T']=T;ns['tail'].cache_clear();ns['survive'].cache_clear()
 @lru_cache(None)
 def measure(z):
  r,mod=z;L=(mod&-mod).bit_length()-1;x=r;a=0
  for i in range(1,min(L,T)+1):
   bit=x%2;a+=bit;x=(3*x+1)//2 if bit else x//2
   if 3**a<2**i:return F()
  if L>=T:return F(1,mod)
  dp={a:1}
  for i in range(L+1,T+1):
   nxt={}
   for aa,num in dp.items():
    for bit in [0,1]:
     if 3**(aa+bit)>=2**i:nxt[aa+bit]=nxt.get(aa+bit,0)+num
   dp=nxt
  return F(sum(dp.values()),mod*2**(T-L))
 vals=[F()];counts=[]
 for f in rows[1:S]:
  z=(f['rho'],f['q']);v=ns['gain']([z],ns['residual'])
  left=[z]
  for w0 in ns['base']:left=[y for x in left for y in ns['subtract'](x,w0)]
  check=ns['gain'](left,measure);assert check==v
  vals.append(F(v['net']));counts.append(len(left))
 def rem(z):return measure(z)-sum((measure(hit) for w0 in keep if (hit:=intersect(z,w0))),F())
 theta=rem((0,1))-sum((rem(ns['c08'](k)) for k in range(1,100)),F())-rem((2**100-1,2**100))/2
 q=3**B;rho=pow(4096,-1,q);theta2=F(ns['gain']([(rho,q)],ns['residual'])['net'])*q;assert theta==theta2
 for f in rows[S:S+3]:assert F(ns['gain']([(f['rho'],f['q'])],ns['residual'])['net'])*f['q']==theta
 assert all(v>=0 for v in vals)
 head=sum(vals,F());series=sum((F(1,f['q']) for f in rows[S:]),F());err=F(3,2*family(101)['q']);lo=head+theta*series;hi=lo+theta*err
 total_lo=F(base['expected'][str(T)]['combined_lower'])+lo;total_hi=F(base['expected'][str(T)]['combined_upper'])+hi
 def rounded(x):
  z=x*100*10**10+F(1,2);return z.numerator//z.denominator
 rr=rounded(total_lo);assert rr==rounded(total_hi)
 result['depths'][str(T)]={'head_marginals':[str(x) for x in vals],'head':str(head),'theta':str(theta),'projected_binary_cylinders':len(keep),'head_disjoint_counts':counts,'independent_checks':True,'tail_series_lower':str(series),'tail_series_upper':str(series+err),'increment_vs_C115_ledger_lower':str(lo),'increment_vs_C115_ledger_upper':str(hi),'combined_lower':str(total_lo),'combined_upper':str(total_hi),'rounded_percent_10dp':f'{rr//10**10}.{rr%10**10:010d}'}
 (out/'checkpoint.json').write_text(json.dumps(result,indent=2));print(T,'theta',theta,'percent',result['depths'][str(T)]['rounded_percent_10dp'],flush=True)
# Small path controls for every tested s, not a substitute for the algebraic proof.
for f in rows:
 n=f['rho'];m=(f['p']*n-f['U'])//f['q'];assert 0<m<n;x=m
 for bit in f['word']:
  assert x%2==int(bit);x=(3*x+1)//2 if x%2 else x//2
 assert x==n
result['elapsed_seconds']=time.time()-start
result['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'tmp/k8_tail/coverage_extension.json',D/'counting_inventory_with_C110.json',root/'tmp/k2_overlap/audit.py',D/'account_total.py']}
(out/'results.json').write_text(json.dumps(result,indent=2));print('seconds',result['elapsed_seconds'],flush=True);os._exit(0)
