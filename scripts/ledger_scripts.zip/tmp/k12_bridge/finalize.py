from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,hashlib
O=Path.cwd();D=O/'tmp/k12_bridge';r=json.loads((D/'results.json').read_text());f=json.loads((D/'fixed_origin.json').read_text());base=O/'tmp/k8_tail/coverage_extension.json'
for row in f['saved_endpoints']:
 x=row['n'];seen=[]
 for j in range(1000):
  if x==row['saved_endpoint']:seen.append(j);break
  x=(3*x+1)//2 if x%2 else x//2
 row['endpoint_first_step']=seen[0] if seen else None
 assert seen
f['shift_scope']='Algebraic queries G_t(x); no arbitrary shifted value is asserted to return to x without the canonical-meeting hypotheses.'
(D/'fixed_origin.json').write_text(json.dumps(f,indent=2))
(D/'coverage_extension.json').write_text(json.dumps({'class':'C116','base':'tmp/k8_tail/coverage_extension.json','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'family':'k12,minimal r,s>=1; s0 coveredC110','scope':'Conditional-rule density; positive exact infinite-series increment, rounded headlines unchanged','depths':r['depths']},indent=2))
print('endpoint steps',[z['endpoint_first_step'] for z in f['saved_endpoints']],flush=True);os._exit(0)
