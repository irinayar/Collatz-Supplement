from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
from functools import lru_cache
D=Path('tmp/fair_terminal129_batch03');start=time.monotonic();n=4064460795;J=129;H=4;tables=[[{0:0}]]
for j in range(1,J+1):
 new=[{} for _ in range(j+1)]
 for b,layer in enumerate(tables[-1]):
  for V in layer.values():
   for bb,Z in [(b,V),(b+1,3*V+2**(j-1))]:
    r=Z%3**min(H,bb);new[bb][r]=max(new[bb].get(r,-1),Z)
 tables.append(new)
work=0
@lru_cache(maxsize=100000)
def R(t,b,h,r):
 global work
 work+=1
 if work>500000:raise RuntimeError('precision work cap')
 if b<0 or b>t:return -1
 h=min(h,b);r%=3**h
 if h<=4:return tables[t][b].get(r,-1) if h==min(4,b) else max((V for rr,V in tables[t][b].items() if rr%3**h==r),default=-1)
 best=R(t-1,b,h,r) if b<t else -1
 p=2**(t-1)
 if b and (r-p)%3==0:
  V=R(t-1,b-1,h-1,((r-p)//3)%3**(h-1))
  if V>=0:best=max(best,3*V+p)
 return best
comparisons=gains=0
for j in range(1,9):
 endpoint=[];counts=[]
 for n0 in range(1,81):
  x=n0;a0=0
  for k in range(j):
   a0+=x%2;x=(3*x+1)//2 if x%2 else x//2
  endpoint.append(x);counts.append(a0)
 for n0 in range(1,81):
  y0=endpoint[n0-1];actual={counts[m-1] for m in range(1,n0) if endpoint[m-1]==y0}
  for b0 in range(j+1):
   for h in range(3):
    rr=2**j*y0%3**min(h,b0);M=max((V for r,V in tables[j][b0].items() if r%3**min(h,b0)==rr),default=-1);T=2**j*y0-3**b0*n0
    old=M<0 or M<=T;new=M<0 or M<T+3**b0
    assert not old or new
    if new:assert b0 not in actual
    comparisons+=1;gains+=new and not old
# Equality at the sharper threshold must remain feasible.
assert 2**6*20-3**4*(15-1)==146
x=14;b=V=0
for k in range(6):
 if x%2:b+=1;V=3*V+2**k
 x=(3*x+1)//2 if x%2 else x//2
assert x==20 and b==4 and V==146
(D/'integer_gap_check.json').write_text(json.dumps(dict(comparisons=comparisons,additional_exclusions=gains,equality_example=dict(n=15,m=14,j=6,b=4,V=146),failures=0),indent=2));print(comparisons,gains,'integer-gap validation passed',flush=True);os._exit(0)
