from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0].replace('lim.basic.p=55*10**7','lim.basic.p=120*10**7').replace('threading.Timer(55,','threading.Timer(120,'))
from fractions import Fraction as F
import json,time
start=time.monotonic();prefix_checks=0;set_checks=0
# Finite source fibres: check actual parity prefix partitions and refinement additivity.
for n in [101,151,201]:
 H=(4*n-2)//3;sources=list(range(n,H+1,2));codes={u:[] for u in sources};states={u:u for u in sources};previous={():set(sources)}
 for depth in range(1,13):
  groups={}
  for u in sources:
   x=states[u];bit=x%2;codes[u].append(bit);states[u]=(3*x+1)//2 if bit else x//2
   groups.setdefault(tuple(codes[u]),set()).add(u)
  assert sum(map(len,groups.values()))==len(sources)
  for p,S in previous.items():
   child=[v for k,v in groups.items() if k[:-1]==p];assert set().union(*child)==S;assert sum(map(len,child))==len(S);prefix_checks+=1
  previous=groups
 assert all(len(S)==1 for S in groups.values())
 # The source-count symmetric difference metric retains singleton atoms.
 A=set(sources[:3]);B=set(sources[1:5]);C=set(sources[-3:]);dist=lambda X,Y:len(X^Y)
 assert dist(A,C)<=dist(A,B)+dist(B,C);set_checks+=1
# Countermodel: uniform pointwise decay does not control sums over growing frontiers.
for d in range(25):assert 2**d*F(1,2**d)==1
# Existing saved singleton caps remain positive; no inference from cylinder depth to zero mass.
p=json.loads(Path('tmp/unresolved_phase_caps/checks.json').read_text());f=p['new_unresolved'];assert f['resolution_depth']==253 and f['depth']==256 and F(f['potential'])>0
assert all(F(row['samples'][0]['cap'])>0 for row in p['rows'])
result=dict(status='PASS',prefix_partition_checks=prefix_checks,finite_set_metric_checks=set_checks,binary_mass_counterexample_depths=25,saved_singleton_positive_caps=6,fresh_checkpoint_unchanged=True,seconds=time.monotonic()-start,scope='Finite algebra/partition tests and exact countermodels; no global tightness or zero-limit theorem proved.')
Path('tmp/topological_capacity/checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);os._exit(0)
