from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time,hashlib
D=Path('tmp/mixed_shell_words');D.mkdir(exist_ok=True);start=time.monotonic();S={x['u'] for x in json.loads(Path('tmp/closed_tail_potential/closure.json').read_text())};tab=json.loads(Path('tmp/residue_precision_compare/tables.json').read_text());ceildiv=lambda n,d:-((-n)//d)
blocks=[r for r in json.loads(Path('tmp/shell_exact_paths/exact_paths.json').read_text()) if r['shells'][0]==r['shells'][2]]
for i,b in enumerate(blocks):b['id']=i
by={j:[b for b in blocks if b['shells'][0]==j] for j in range(3)};edges={};labels={}
for b in blocks:
 for u,v,w in b['paths']:assert u not in edges;edges[u]=w;labels[u]=b['id']
paths={}
for u in edges:
 chain=[u];seen={u};v=u
 while v in edges:
  v=edges[v];assert v not in seen;seen.add(v);chain.append(v)
 paths[u]=chain
maximum=max(len(c)-1 for c in paths.values());assert maximum<10
old={}
for r in json.loads(Path('tmp/repeated_shell_words/certificates.json').read_text()):
 old[(tuple(r['shells']),tuple(tuple(p) for p in r['runs']),r['repeat'])]=r
front=[]
for b in blocks:
 j=b['shells'][0];A=1;B=L=R=E=0;lo=1024*2**j;hi=1024*2**(j+1)-1
 for (s,e),jj in zip(b['runs'],b['shells'][1:]):
  B=3**s*B+(3**s-2**s)*2**L;A*=3**s;L+=s+e;R+=s;E+=e;lo=max(lo,ceildiv(2**L*1024*2**jj-B,A));hi=min(hi,(2**L*(1024*2**(jj+1)-1)-B)//A)
 front.append(dict(ids=[b['id']],j=j,A=A,B=B,L=L,R=R,E=E,lo=lo,hi=hi,sources=[p[0] for p in b['paths']]))
stats=[];cert=[];totalprobes=0
for depth in range(2,maximum+2):
 st=dict(depth=depth,cells=0,height_empty=0,early_cost=0,early_endpoint_empty=0,exact_empty=0,survivors=0,sources=0,cached_repeats=0,endpoint_checks=0);nxt=[]
 for node in front:
  for b in by[node['j']]:
   st['cells']+=1;assert st['cells']<20000
   z=dict(node);z['ids']=node['ids']+[b['id']];A=z['A'];B=z['B'];L=z['L'];R=z['R'];E=z['E'];lo=z['lo'];hi=z['hi']
   for (s,e),jj in zip(b['runs'],b['shells'][1:]):
    B=3**s*B+(3**s-2**s)*2**L;A*=3**s;L+=s+e;R+=s;E+=e;lo=max(lo,ceildiv(2**L*1024*2**jj-B,A));hi=min(hi,(2**L*(1024*2**(jj+1)-1)-B)//A)
   z.update(A=A,B=B,L=L,R=R,E=E,lo=lo,hi=hi)
   truth=[u for u in node['sources'] if len(paths[u])-1>=depth and labels[paths[u][depth-1]]==b['id']]
   if len(set(z['ids']))==1:
    cached=old[(tuple(b['shells']),tuple(tuple(p) for p in b['runs']),depth)];assert truth==cached.get('sources',[]);found=truth;st['cached_repeats']+=1;status='cached_repeat'
   elif lo+(1-lo)%2>hi:
    assert not truth;st['height_empty']+=1;found=[];status='height_empty'
   else:
    wl=ceildiv(A*lo+B,2**L);wh=(A*hi+B)//2**L;prec=min(R,12);eligible=0;ok=False
    for w in range(wl+(1-wl)%2,wh+1,2):
     if w in S:continue
     eligible+=1;totalprobes+=1;st['endpoint_checks']+=1;assert totalprobes<50000
     if tab[prec][w%3**prec]<=E:ok=True;break
    if not ok:
     assert not truth;found=[];status='early_cost' if eligible else 'early_endpoint_empty';st[status]+=1
     # Full check below independently validates early cuts without claiming saved audit time.
    mod=2**(L+1);rho=((2**L-B)*pow(A,-1,mod))%mod
    candidates=list(range(lo+(rho-lo)%mod,hi+1,mod));found=[u for u in candidates if u in node['sources'] and len(paths[u])-1>=depth and labels[paths[u][depth-1]]==b['id']]
    assert found==truth
    if ok:status='surviving' if found else 'exact_empty';st['exact_empty']+=not found
   z['sources']=found
   if found:st['survivors']+=1;st['sources']+=len(found);nxt.append(z)
   cert.append(dict(ids=z['ids'],lo=lo,hi=hi,A=A,B=B,L=L,R=R,E=E,status=status,sources=found))
 assert sum(len(n['sources']) for n in nxt)==sum(len(v)-1>=depth for v in paths.values())
 stats.append(st);front=nxt
 (D/'progress.json').write_text(json.dumps(dict(depth=depth,stats=stats,frontier=front)))
assert not front
# Fresh elementary-step replay of every source's full mixed-chain certificate.
steps=0
for u,chain in paths.items():
 x=u
 for i in range(len(chain)-1):
  b=blocks[labels[x]]
  for s,e in b['runs']:
   for _ in range(s):assert x%2;x=(3*x+1)//2;steps+=1
   for _ in range(e):assert x%2==0;x//=2;steps+=1
   assert x%2 and x not in S
  assert x==chain[i+1]
for f,h in json.loads(Path('tmp/v10_audit/release_manifest.json').read_text())['files'].items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h
out=dict(blocks=len(blocks),source_states=len(edges),maximum_blocks=maximum,maximal_chains=[v for v in paths.values() if len(v)-1==maximum],stats=stats,endpoint_checks=totalprobes,elementary_replay_steps=steps,seconds=time.monotonic()-start,v10_unchanged=True)
(D/'results.json').write_text(json.dumps(out,indent=2));(D/'certificates.json').write_text(json.dumps(cert));(D/'graph.json').write_text(json.dumps([dict(u=u,v=v,block=labels[u]) for u,v in sorted(edges.items())]));print(json.dumps(out),flush=True);os._exit(0)
