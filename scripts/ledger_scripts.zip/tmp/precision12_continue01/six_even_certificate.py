from pathlib import Path
exec((Path.cwd()/'tmp/k2_overlap/audit.py').read_text().split('from pathlib import Path')[0])
import json,time
start=time.monotonic();D=Path('tmp/precision12_continue01');pairs={};traces={};maxsteps=0
for m in range(1,188):
 x=m;k=r=steps=0
 while k<=6:
  if k==6 and (x,r) not in pairs:pairs[(x,r)]=m
  if x%2:r+=1;x=(3*x+1)//2
  else:k+=1;x//=2
  steps+=1;assert steps<10000
 maxsteps=max(maxsteps,steps)
# Independently enumerate inverse edges instead of the supplied valuation recurrence.
for x,r in pairs:
 if x in traces:continue
 stack=[(x,6,0)];mins={}
 while stack:
  z,k,t=stack.pop()
  if k==0:mins[t]=min(z,mins.get(t,z))
  if k:stack.append((2*z,k-1,t))
  if z%3==2:stack.append(((2*z-1)//3,k,t+1))
 traces[x]=mins
nonterminal=terminal=0
for (x,r),m in pairs.items():
 assert traces[x][r]==m
 if r<max(traces[x]):assert pairs.get((x,r+1),188)<m;nonterminal+=1
 else:terminal+=1
assert (len(pairs),nonterminal,terminal)==(168,102,66)
out=dict(exceptional_pairs=len(pairs),nonterminal=nonterminal,terminal=terminal,independent_endpoint_trees=len(traces),max_forward_steps=maxsteps,seconds=time.monotonic()-start)
(D/'six_even_certificate.json').write_text(json.dumps(dict(summary=out,pairs=[dict(x=x,r=r,m=m,R=max(traces[x])) for (x,r),m in sorted(pairs.items())]),indent=2),encoding='utf8');print(out,flush=True);os._exit(0)
